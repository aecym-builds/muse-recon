.class public final Lcom/facebook/aura/activation/repo/InvitePageResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/InvitePageResponseJson$Companion;


# instance fields
.field public final code:Ljava/lang/String;

.field public final gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

.field public final has_redeemed_invite_code:Z

.field public final invite_link:Ljava/lang/String;

.field public final invite_state:Ljava/lang/String;

.field public final redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

.field public final redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

.field public final reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

.field public final share_text:Ljava/lang/String;

.field public final show_gift:Z

.field public final show_redeem_button:Z

.field public final story_share_text:Ljava/lang/String;

.field public final subtitle:Ljava/lang/String;

.field public final subtitle_link_text:Ljava/lang/String;

.field public final subtitle_link_url:Ljava/lang/String;

.field public final title:Ljava/lang/String;

.field public final uses_remaining:Ljava/lang/Integer;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->Companion:Lcom/facebook/aura/activation/repo/InvitePageResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 17

    .line 0
    const/4 v1, 0x0

    .line 1
    const/4 v11, 0x1

    .line 2
    const/4 v12, 0x0

    .line 3
    move-object/from16 v0, p0

    .line 4
    .line 5
    move-object v2, v1

    .line 6
    move-object v3, v1

    .line 7
    move-object v4, v1

    .line 8
    move-object v5, v1

    .line 9
    move-object v6, v1

    .line 10
    move-object v7, v1

    .line 11
    move-object v8, v1

    .line 12
    move-object v9, v1

    .line 13
    move-object v10, v1

    .line 14
    move v13, v12

    .line 15
    move-object v14, v1

    .line 16
    move-object v15, v1

    .line 17
    move-object/from16 v16, v1

    .line 18
    .line 19
    move-object/from16 p0, v1

    .line 20
    .line 21
    invoke-direct/range {v0 .. v17}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;LX/5Xm;)V
    .locals 3

    .line 538178753
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 538178754
    and-int/lit8 v0, p1, 0x1

    const/4 v1, 0x0

    if-nez v0, :cond_f

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    :goto_0
    and-int/lit8 v0, p1, 0x2

    if-nez v0, :cond_e

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    :goto_1
    and-int/lit8 v0, p1, 0x4

    if-nez v0, :cond_d

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    :goto_2
    and-int/lit8 v0, p1, 0x8

    if-nez v0, :cond_c

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    :goto_3
    and-int/lit8 v0, p1, 0x10

    if-nez v0, :cond_b

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    :goto_4
    and-int/lit8 v0, p1, 0x20

    if-nez v0, :cond_a

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    :goto_5
    and-int/lit8 v0, p1, 0x40

    if-nez v0, :cond_9

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    :goto_6
    and-int/lit16 v0, p1, 0x80

    if-nez v0, :cond_8

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    :goto_7
    and-int/lit16 v0, p1, 0x100

    if-nez v0, :cond_7

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    :goto_8
    and-int/lit16 v0, p1, 0x200

    if-nez v0, :cond_6

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    :goto_9
    and-int/lit16 v0, p1, 0x400

    if-nez v0, :cond_5

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    :goto_a
    and-int/lit16 v0, p1, 0x800

    const/4 v2, 0x0

    if-nez v0, :cond_4

    iput-boolean v2, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    :goto_b
    and-int/lit16 v0, p1, 0x1000

    if-nez v0, :cond_3

    iput-boolean v2, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    :goto_c
    and-int/lit16 v0, p1, 0x2000

    if-nez v0, :cond_2

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    :goto_d
    and-int/lit16 v0, p1, 0x4000

    if-nez v0, :cond_1

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    :goto_e
    const v0, 0x8000

    and-int/2addr v0, p1

    if-nez v0, :cond_0

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    :goto_f
    const/high16 v0, 0x10000

    and-int/2addr p1, v0

    if-nez p1, :cond_10

    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    return-void

    :cond_0
    move-object/from16 v0, p17

    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    goto :goto_f

    :cond_1
    move-object/from16 v0, p16

    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    goto :goto_e

    :cond_2
    move-object/from16 v0, p15

    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    goto :goto_d

    :cond_3
    move/from16 v0, p14

    iput-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    goto :goto_c

    :cond_4
    move/from16 v0, p13

    iput-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    goto :goto_b

    :cond_5
    iput-boolean p12, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    goto :goto_a

    :cond_6
    iput-object p11, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    goto :goto_9

    :cond_7
    iput-object p10, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    goto :goto_8

    :cond_8
    iput-object p9, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    goto :goto_7

    :cond_9
    iput-object p8, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    goto :goto_6

    :cond_a
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    goto :goto_5

    :cond_b
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    goto :goto_4

    :cond_c
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    goto/16 :goto_3

    :cond_d
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    goto/16 :goto_2

    :cond_e
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    goto/16 :goto_1

    :cond_f
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    goto/16 :goto_0

    :cond_10
    move-object/from16 v0, p18

    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 268435462
    .line 268435463
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 268435464
    .line 268435465
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 268435466
    .line 268435467
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 268435470
    .line 268435471
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 268435472
    .line 268435473
    iput-object p8, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 268435474
    .line 268435475
    iput-object p9, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 268435476
    .line 268435477
    iput-object p10, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 268435478
    .line 268435479
    iput-boolean p11, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 268435480
    .line 268435481
    iput-boolean p12, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 268435482
    .line 268435483
    iput-boolean p13, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 268435484
    .line 268435485
    iput-object p14, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 268435486
    .line 268435487
    move-object/from16 v0, p15

    .line 268435488
    .line 268435489
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 268435490
    .line 268435491
    move-object/from16 v0, p16

    .line 268435492
    .line 268435493
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 268435494
    .line 268435495
    move-object/from16 v0, p17

    .line 268435496
    .line 268435497
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 268435498
    .line 268435499
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;ILX/04f;)V
    .locals 19

    .line 806614221
    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-object/from16 v10, p9

    move-object/from16 v11, p10

    move/from16 v12, p11

    move/from16 v13, p12

    move-object/from16 v15, p14

    move-object/from16 v16, p15

    move-object/from16 v17, p16

    move-object/from16 v18, p17

    move/from16 v0, p18

    and-int/lit8 v1, p18, 0x1

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    :cond_0
    and-int/lit8 v1, p18, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    :cond_1
    and-int/lit8 v1, p18, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    :cond_2
    and-int/lit8 v1, p18, 0x8

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    :cond_3
    and-int/lit8 v1, p18, 0x10

    if-eqz v1, :cond_4

    const/4 v6, 0x0

    :cond_4
    and-int/lit8 v1, p18, 0x20

    if-eqz v1, :cond_5

    const/4 v7, 0x0

    :cond_5
    and-int/lit8 v1, p18, 0x40

    if-eqz v1, :cond_6

    const/4 v8, 0x0

    :cond_6
    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_7

    const/4 v9, 0x0

    :cond_7
    and-int/lit16 v1, v0, 0x100

    if-eqz v1, :cond_8

    const/4 v10, 0x0

    :cond_8
    and-int/lit16 v1, v0, 0x200

    if-eqz v1, :cond_9

    const/4 v11, 0x0

    :cond_9
    and-int/lit16 v1, v0, 0x400

    if-eqz v1, :cond_a

    const/4 v12, 0x1

    :cond_a
    and-int/lit16 v1, v0, 0x800

    const/4 v14, 0x0

    if-eqz v1, :cond_b

    const/4 v13, 0x0

    :cond_b
    and-int/lit16 v1, v0, 0x1000

    if-nez v1, :cond_c

    move/from16 v14, p13

    :cond_c
    and-int/lit16 v1, v0, 0x2000

    if-eqz v1, :cond_d

    const/4 v15, 0x0

    :cond_d
    and-int/lit16 v1, v0, 0x4000

    if-eqz v1, :cond_e

    const/16 v16, 0x0

    :cond_e
    const v1, 0x8000

    and-int v1, p18, v1

    if-eqz v1, :cond_f

    const/16 v17, 0x0

    :cond_f
    const/high16 v1, 0x10000

    and-int v0, p18, v1

    if-eqz v0, :cond_10

    const/16 v18, 0x0

    :cond_10
    move-object/from16 v1, p0

    invoke-direct/range {v1 .. v18}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/InvitePageResponseJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/InvitePageResponseJson;
    .locals 15

    .line 0
    move-object/from16 v14, p5

    .line 1
    .line 2
    move-object/from16 v13, p6

    .line 3
    .line 4
    move-object/from16 v12, p7

    .line 5
    .line 6
    move-object/from16 v11, p8

    .line 7
    .line 8
    move-object/from16 v10, p9

    .line 9
    .line 10
    move-object/from16 v9, p10

    .line 11
    .line 12
    move/from16 v8, p11

    .line 13
    .line 14
    move/from16 v7, p12

    .line 15
    .line 16
    move/from16 v6, p13

    .line 17
    .line 18
    move-object/from16 v5, p14

    .line 19
    .line 20
    move-object/from16 v4, p15

    .line 21
    .line 22
    move-object/from16 v3, p16

    .line 23
    .line 24
    move/from16 v2, p18

    .line 25
    .line 26
    move-object/from16 v1, p17

    .line 27
    .line 28
    and-int/lit8 v0, p18, 0x1

    .line 29
    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 33
    .line 34
    move-object/from16 p1, v0

    .line 35
    .line 36
    :cond_0
    and-int/lit8 v0, p18, 0x2

    .line 37
    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 41
    .line 42
    move-object/from16 p2, v0

    .line 43
    .line 44
    :cond_1
    and-int/lit8 v0, p18, 0x4

    .line 45
    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 49
    .line 50
    move-object/from16 p3, v0

    .line 51
    .line 52
    :cond_2
    and-int/lit8 v0, p18, 0x8

    .line 53
    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 57
    .line 58
    move-object/from16 p4, v0

    .line 59
    .line 60
    :cond_3
    and-int/lit8 v0, p18, 0x10

    .line 61
    .line 62
    if-eqz v0, :cond_4

    .line 63
    .line 64
    iget-object v14, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 65
    .line 66
    :cond_4
    and-int/lit8 v0, p18, 0x20

    .line 67
    .line 68
    if-eqz v0, :cond_5

    .line 69
    .line 70
    iget-object v13, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 71
    .line 72
    :cond_5
    and-int/lit8 v0, p18, 0x40

    .line 73
    .line 74
    if-eqz v0, :cond_6

    .line 75
    .line 76
    iget-object v12, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 77
    .line 78
    :cond_6
    and-int/lit16 v0, v2, 0x80

    .line 79
    .line 80
    if-eqz v0, :cond_7

    .line 81
    .line 82
    iget-object v11, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 83
    .line 84
    :cond_7
    and-int/lit16 v0, v2, 0x100

    .line 85
    .line 86
    if-eqz v0, :cond_8

    .line 87
    .line 88
    iget-object v10, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 89
    .line 90
    :cond_8
    and-int/lit16 v0, v2, 0x200

    .line 91
    .line 92
    if-eqz v0, :cond_9

    .line 93
    .line 94
    iget-object v9, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 95
    .line 96
    :cond_9
    and-int/lit16 v0, v2, 0x400

    .line 97
    .line 98
    if-eqz v0, :cond_a

    .line 99
    .line 100
    iget-boolean v8, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 101
    .line 102
    :cond_a
    and-int/lit16 v0, v2, 0x800

    .line 103
    .line 104
    if-eqz v0, :cond_b

    .line 105
    .line 106
    iget-boolean v7, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 107
    .line 108
    :cond_b
    and-int/lit16 v0, v2, 0x1000

    .line 109
    .line 110
    if-eqz v0, :cond_c

    .line 111
    .line 112
    iget-boolean v6, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 113
    .line 114
    :cond_c
    and-int/lit16 v0, v2, 0x2000

    .line 115
    .line 116
    if-eqz v0, :cond_d

    .line 117
    .line 118
    iget-object v5, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 119
    .line 120
    :cond_d
    and-int/lit16 v0, v2, 0x4000

    .line 121
    .line 122
    if-eqz v0, :cond_e

    .line 123
    .line 124
    iget-object v4, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 125
    .line 126
    :cond_e
    const v0, 0x8000

    .line 127
    .line 128
    .line 129
    and-int v0, p18, v0

    .line 130
    .line 131
    if-eqz v0, :cond_f

    .line 132
    .line 133
    iget-object v3, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 134
    .line 135
    :cond_f
    const/high16 v0, 0x10000

    .line 136
    .line 137
    and-int v2, p18, v0

    .line 138
    .line 139
    if-eqz v2, :cond_10

    .line 140
    .line 141
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 142
    .line 143
    :cond_10
    new-instance p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 144
    .line 145
    move-object/from16 p16, v3

    .line 146
    .line 147
    move-object/from16 p17, v1

    .line 148
    .line 149
    move/from16 p11, v8

    .line 150
    .line 151
    move/from16 p12, v7

    .line 152
    .line 153
    move/from16 p13, v6

    .line 154
    .line 155
    move-object/from16 p14, v5

    .line 156
    .line 157
    move-object/from16 p15, v4

    .line 158
    .line 159
    move-object/from16 p6, v13

    .line 160
    .line 161
    move-object/from16 p7, v12

    .line 162
    .line 163
    move-object/from16 p8, v11

    .line 164
    .line 165
    move-object/from16 p9, v10

    .line 166
    .line 167
    move-object/from16 p10, v9

    .line 168
    .line 169
    move-object/from16 p5, v14

    .line 170
    .line 171
    invoke-direct/range {p0 .. p17}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)V

    .line 172
    .line 173
    .line 174
    return-object p0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/InvitePageResponseJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v4

    .line 5
    if-nez v4, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v4, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v3, 0x2

    .line 33
    if-nez v4, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    const/4 v3, 0x3

    .line 47
    if-nez v4, :cond_6

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v0, :cond_7

    .line 52
    .line 53
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_7
    const/4 v3, 0x4

    .line 61
    if-nez v4, :cond_8

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_9

    .line 66
    .line 67
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 70
    .line 71
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 72
    .line 73
    .line 74
    :cond_9
    const/4 v3, 0x5

    .line 75
    if-nez v4, :cond_a

    .line 76
    .line 77
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v0, :cond_b

    .line 80
    .line 81
    :cond_a
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 84
    .line 85
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 86
    .line 87
    .line 88
    :cond_b
    const/4 v3, 0x6

    .line 89
    if-nez v4, :cond_c

    .line 90
    .line 91
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 92
    .line 93
    if-eqz v0, :cond_d

    .line 94
    .line 95
    :cond_c
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 96
    .line 97
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 98
    .line 99
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 100
    .line 101
    .line 102
    :cond_d
    const/4 v3, 0x7

    .line 103
    if-nez v4, :cond_e

    .line 104
    .line 105
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 106
    .line 107
    if-eqz v0, :cond_f

    .line 108
    .line 109
    :cond_e
    sget-object v1, LX/DYo;->A00:LX/DYo;

    .line 110
    .line 111
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 112
    .line 113
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 114
    .line 115
    .line 116
    :cond_f
    const/16 v3, 0x8

    .line 117
    .line 118
    if-nez v4, :cond_10

    .line 119
    .line 120
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 121
    .line 122
    if-eqz v0, :cond_11

    .line 123
    .line 124
    :cond_10
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 125
    .line 126
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 127
    .line 128
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 129
    .line 130
    .line 131
    :cond_11
    const/16 v3, 0x9

    .line 132
    .line 133
    if-nez v4, :cond_12

    .line 134
    .line 135
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 136
    .line 137
    if-eqz v0, :cond_13

    .line 138
    .line 139
    :cond_12
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 140
    .line 141
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 142
    .line 143
    invoke-interface {p1, v0, v1, p2, v3}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 144
    .line 145
    .line 146
    :cond_13
    const/16 v1, 0xa

    .line 147
    .line 148
    if-nez v4, :cond_14

    .line 149
    .line 150
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 151
    .line 152
    if-eq v0, v2, :cond_15

    .line 153
    .line 154
    :cond_14
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 155
    .line 156
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 157
    .line 158
    .line 159
    :cond_15
    const/16 v1, 0xb

    .line 160
    .line 161
    if-nez v4, :cond_16

    .line 162
    .line 163
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 164
    .line 165
    if-eqz v0, :cond_17

    .line 166
    .line 167
    :cond_16
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 168
    .line 169
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 170
    .line 171
    .line 172
    :cond_17
    const/16 v1, 0xc

    .line 173
    .line 174
    if-nez v4, :cond_18

    .line 175
    .line 176
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 177
    .line 178
    if-eqz v0, :cond_19

    .line 179
    .line 180
    :cond_18
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 181
    .line 182
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 183
    .line 184
    .line 185
    :cond_19
    const/16 v2, 0xd

    .line 186
    .line 187
    if-nez v4, :cond_1a

    .line 188
    .line 189
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 190
    .line 191
    if-eqz v0, :cond_1b

    .line 192
    .line 193
    :cond_1a
    sget-object v1, Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;

    .line 194
    .line 195
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 196
    .line 197
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 198
    .line 199
    .line 200
    :cond_1b
    const/16 v2, 0xe

    .line 201
    .line 202
    if-nez v4, :cond_1c

    .line 203
    .line 204
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 205
    .line 206
    if-eqz v0, :cond_1d

    .line 207
    .line 208
    :cond_1c
    sget-object v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;

    .line 209
    .line 210
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 211
    .line 212
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 213
    .line 214
    .line 215
    :cond_1d
    const/16 v2, 0xf

    .line 216
    .line 217
    if-nez v4, :cond_1e

    .line 218
    .line 219
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 220
    .line 221
    if-eqz v0, :cond_1f

    .line 222
    .line 223
    :cond_1e
    sget-object v1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

    .line 224
    .line 225
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 226
    .line 227
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 228
    .line 229
    .line 230
    :cond_1f
    const/16 v2, 0x10

    .line 231
    .line 232
    if-nez v4, :cond_20

    .line 233
    .line 234
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 235
    .line 236
    if-eqz v0, :cond_21

    .line 237
    .line 238
    :cond_20
    sget-object v1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;

    .line 239
    .line 240
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 241
    .line 242
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 243
    .line 244
    .line 245
    :cond_21
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component12()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component13()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component14()Lcom/facebook/aura/activation/repo/InviteRewardJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component15()Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component16()Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component17()Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)Lcom/facebook/aura/activation/repo/InvitePageResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p17}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 91
    .line 92
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 93
    .line 94
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_0

    .line 109
    .line 110
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 111
    .line 112
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 113
    .line 114
    if-ne v1, v0, :cond_0

    .line 115
    .line 116
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 117
    .line 118
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 119
    .line 120
    if-ne v1, v0, :cond_0

    .line 121
    .line 122
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 123
    .line 124
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 125
    .line 126
    if-ne v1, v0, :cond_0

    .line 127
    .line 128
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 129
    .line 130
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 131
    .line 132
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_0

    .line 137
    .line 138
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 139
    .line 140
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 141
    .line 142
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 143
    .line 144
    .line 145
    move-result v0

    .line 146
    if-eqz v0, :cond_0

    .line 147
    .line 148
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 149
    .line 150
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 151
    .line 152
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-eqz v0, :cond_0

    .line 157
    .line 158
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 159
    .line 160
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 161
    .line 162
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-nez v0, :cond_1

    .line 167
    .line 168
    :cond_0
    return v2

    .line 169
    :cond_1
    return v3
.end method

.method public final getCode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getGift_video()Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHas_redeemed_invite_code()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getInvite_link()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getInvite_state()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRedeem_invite_code_screen()Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRedeem_invite_code_success_screen()Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReward()Lcom/facebook/aura/activation/repo/InviteRewardJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShare_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShow_gift()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getShow_redeem_button()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getStory_share_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitle_link_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitle_link_url()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUses_remaining()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->title:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 37
    .line 38
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v1, v0

    .line 43
    mul-int/lit8 v1, v1, 0x1f

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 46
    .line 47
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    add-int/2addr v1, v0

    .line 52
    mul-int/lit8 v1, v1, 0x1f

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    add-int/2addr v1, v0

    .line 61
    mul-int/lit8 v1, v1, 0x1f

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->uses_remaining:Ljava/lang/Integer;

    .line 64
    .line 65
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    add-int/2addr v1, v0

    .line 70
    mul-int/lit8 v1, v1, 0x1f

    .line 71
    .line 72
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    add-int/2addr v1, v0

    .line 79
    mul-int/lit8 v1, v1, 0x1f

    .line 80
    .line 81
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 82
    .line 83
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    add-int/2addr v1, v0

    .line 88
    mul-int/lit8 v1, v1, 0x1f

    .line 89
    .line 90
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 91
    .line 92
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 97
    .line 98
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 99
    .line 100
    .line 101
    move-result v1

    .line 102
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 105
    .line 106
    .line 107
    move-result v1

    .line 108
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 109
    .line 110
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    add-int/2addr v1, v0

    .line 115
    mul-int/lit8 v1, v1, 0x1f

    .line 116
    .line 117
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 118
    .line 119
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    add-int/2addr v1, v0

    .line 124
    mul-int/lit8 v1, v1, 0x1f

    .line 125
    .line 126
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 127
    .line 128
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    add-int/2addr v1, v0

    .line 133
    mul-int/lit8 v1, v1, 0x1f

    .line 134
    .line 135
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 136
    .line 137
    if-eqz v0, :cond_0

    .line 138
    .line 139
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    :cond_0
    add-int/2addr v1, v2

    .line 144
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/activation/data/HatchInvitePage;
    .locals 31

    .line 0
    move-object/from16 v14, p0

    .line 1
    .line 2
    iget-object v0, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_state:Ljava/lang/String;

    .line 3
    .line 4
    invoke-static {v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepositoryJsonKt;->toInviteStateOrNull(Ljava/lang/String;)Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 5
    .line 6
    .line 7
    move-result-object v17

    .line 8
    iget-object v0, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle:Ljava/lang/String;

    .line 9
    .line 10
    move-object/from16 v18, v0

    .line 11
    .line 12
    iget-object v15, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_text:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v13, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->subtitle_link_url:Ljava/lang/String;

    .line 15
    .line 16
    iget-boolean v12, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->has_redeemed_invite_code:Z

    .line 17
    .line 18
    iget-boolean v11, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_redeem_button:Z

    .line 19
    .line 20
    iget-object v10, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->code:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v9, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->invite_link:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v8, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->share_text:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v7, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->story_share_text:Ljava/lang/String;

    .line 27
    .line 28
    iget-boolean v6, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->show_gift:Z

    .line 29
    .line 30
    iget-object v2, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->reward:Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 31
    .line 32
    if-eqz v2, :cond_4

    .line 33
    .line 34
    iget-object v0, v2, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_4

    .line 41
    .line 42
    iget-object v0, v2, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_4

    .line 49
    .line 50
    iget-object v1, v2, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, v2, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 53
    .line 54
    new-instance v5, Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 55
    .line 56
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/activation/data/HatchInviteReward;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    :goto_0
    iget-object v1, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->gift_video:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 60
    .line 61
    if-eqz v1, :cond_3

    .line 62
    .line 63
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_3

    .line 70
    .line 71
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 72
    .line 73
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-nez v0, :cond_3

    .line 78
    .line 79
    iget v0, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 80
    .line 81
    if-lez v0, :cond_3

    .line 82
    .line 83
    iget v3, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 84
    .line 85
    if-lez v3, :cond_3

    .line 86
    .line 87
    iget-object v2, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 88
    .line 89
    iget-object v1, v1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 90
    .line 91
    int-to-float v0, v0

    .line 92
    int-to-float v3, v3

    .line 93
    div-float/2addr v0, v3

    .line 94
    new-instance v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 95
    .line 96
    invoke-direct {v4, v2, v1, v0}, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;-><init>(Ljava/lang/String;Ljava/lang/String;F)V

    .line 97
    .line 98
    .line 99
    :goto_1
    iget-object v0, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 100
    .line 101
    if-eqz v0, :cond_2

    .line 102
    .line 103
    iget-object v1, v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 104
    .line 105
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-nez v1, :cond_2

    .line 110
    .line 111
    iget-object v3, v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 112
    .line 113
    if-eqz v3, :cond_1

    .line 114
    .line 115
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-nez v1, :cond_1

    .line 120
    .line 121
    :goto_2
    iget-object v2, v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 122
    .line 123
    iget-object v1, v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 124
    .line 125
    new-instance v0, Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 126
    .line 127
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    :goto_3
    iget-object v2, v14, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->redeem_invite_code_success_screen:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 131
    .line 132
    if-eqz v2, :cond_0

    .line 133
    .line 134
    iget-object v1, v2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;->title:Ljava/lang/String;

    .line 135
    .line 136
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    if-nez v1, :cond_0

    .line 141
    .line 142
    iget-object v1, v2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;->subtitle:Ljava/lang/String;

    .line 143
    .line 144
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    if-nez v1, :cond_0

    .line 149
    .line 150
    iget-object v3, v2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;->title:Ljava/lang/String;

    .line 151
    .line 152
    iget-object v2, v2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;->subtitle:Ljava/lang/String;

    .line 153
    .line 154
    new-instance v1, Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 155
    .line 156
    invoke-direct {v1, v3, v2}, Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    :goto_4
    new-instance v16, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 160
    .line 161
    move-object/from16 v29, v4

    .line 162
    .line 163
    move-object/from16 v30, v0

    .line 164
    .line 165
    move-object/from16 p0, v1

    .line 166
    .line 167
    move/from16 v27, v6

    .line 168
    .line 169
    move-object/from16 v28, v5

    .line 170
    .line 171
    move-object/from16 v24, v9

    .line 172
    .line 173
    move-object/from16 v25, v8

    .line 174
    .line 175
    move-object/from16 v26, v7

    .line 176
    .line 177
    move/from16 v21, v12

    .line 178
    .line 179
    move/from16 v22, v11

    .line 180
    .line 181
    move-object/from16 v23, v10

    .line 182
    .line 183
    move-object/from16 v19, v15

    .line 184
    .line 185
    move-object/from16 v20, v13

    .line 186
    .line 187
    invoke-direct/range {v16 .. v31}, Lcom/facebook/aura/activation/data/HatchInvitePage;-><init>(Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 188
    .line 189
    .line 190
    return-object v16

    .line 191
    :cond_0
    const/4 v1, 0x0

    .line 192
    goto :goto_4

    .line 193
    :cond_1
    const/4 v3, 0x0

    .line 194
    goto :goto_2

    .line 195
    :cond_2
    const/4 v0, 0x0

    .line 196
    goto :goto_3

    .line 197
    :cond_3
    const/4 v4, 0x0

    .line 198
    goto :goto_1

    .line 199
    :cond_4
    const/4 v5, 0x0

    .line 200
    goto/16 :goto_0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
