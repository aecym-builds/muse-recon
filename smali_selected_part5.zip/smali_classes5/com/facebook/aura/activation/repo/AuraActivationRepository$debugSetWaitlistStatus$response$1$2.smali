.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/IUt;


# instance fields
.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DT0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$2;->$continuation:LX/DT0;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Throwable;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$2;->$continuation:LX/DT0;

    .line 5
    .line 6
    new-instance v0, LX/2PH;

    .line 7
    .line 8
    invoke-direct {v0, p1}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {p0, v0}, LX/2M4;->resumeWith(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
