.class public abstract Lcom/facebook/aura/activation/repo/AuraActivationRepositoryKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "AuraActivationRepository"
