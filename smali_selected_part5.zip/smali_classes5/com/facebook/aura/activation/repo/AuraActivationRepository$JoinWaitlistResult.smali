.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;
.super LX/07H;
.source ""


# instance fields
.field public final eligibilityError:Ljava/lang/String;

.field public final status:LX/7Kq;


# direct methods
.method public constructor <init>(LX/7Kq;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 6
    .line 7
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;LX/7Kq;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;

    .line 13
    .line 14
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;-><init>(LX/7Kq;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method


# virtual methods
.method public final component1()LX/7Kq;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(LX/7Kq;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;-><init>(LX/7Kq;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    :cond_0
    return v2

    .line 27
    :cond_1
    return v3
.end method

.method public final getEligibilityError()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStatus()LX/7Kq;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->eligibilityError:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    :cond_0
    add-int/2addr v1, v2

    .line 18
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
