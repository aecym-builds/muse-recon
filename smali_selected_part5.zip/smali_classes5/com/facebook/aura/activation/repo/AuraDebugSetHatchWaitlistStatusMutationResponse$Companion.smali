.class public final Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getBUILD_CONFIG_NAME()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;->BUILD_CONFIG_NAME:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFRAGMENT_NAME_HASH()I
    .locals 0

    .line 0
    sget p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;->FRAGMENT_NAME_HASH:I

    .line 1
    .line 2
    return p0
.end method
