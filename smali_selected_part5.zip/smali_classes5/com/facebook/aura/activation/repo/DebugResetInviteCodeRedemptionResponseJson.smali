.class public final Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson$Companion;


# instance fields
.field public final redemptions_deleted:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->Companion:Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 805306368
    const/4 v0, 0x0

    .line 805306369
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;-><init>(I)V

    .line 805306370
    .line 805306371
    .line 805306372
    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    iput p1, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 536870916
    .line 536870917
    return-void
.end method

.method public synthetic constructor <init>(IILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(IILX/5Xm;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    if-nez v0, :cond_0

    .line 268435462
    .line 268435463
    const/4 v0, 0x0

    .line 268435464
    iput v0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 268435465
    .line 268435466
    return-void

    .line 268435467
    :cond_0
    iput p2, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 268435468
    .line 268435469
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;IILjava/lang/Object;)Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 5
    .line 6
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;LX/Da8;LX/Da5;)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 12
    .line 13
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 14
    .line 15
    .line 16
    :cond_1
    return-void
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(I)Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;

    .line 1
    .line 2
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;-><init>(I)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return v2

    .line 17
    :cond_1
    return v3
.end method

.method public final getRedemptions_deleted()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
