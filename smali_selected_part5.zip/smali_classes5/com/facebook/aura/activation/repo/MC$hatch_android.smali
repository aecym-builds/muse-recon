.class public final Lcom/facebook/aura/activation/repo/MC$hatch_android;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x1c335

.field public static final INSTANCE:Lcom/facebook/aura/activation/repo/MC$hatch_android;

.field public static final __CONFIG__:I = 0x203

.field public static final artifact_sharing_enabled:LX/0d8;

.field public static final artifacts_path_segment:LX/0d8;

.field public static final attachment_inline_size_threshold_mb:LX/0d8;

.field public static final attachment_inline_video_size_threshold_mb:LX/0d8;

.field public static final color_idea_icons_enabled:LX/0d8;

.field public static final confidential_vm_enabled:LX/0d8;

.field public static final data_controls_learn_more_url:LX/0d8;

.field public static final data_controls_privacy_url:LX/0d8;

.field public static final default_avatar_size:LX/0d8;

.field public static final dictation_service:LX/0d8;

.field public static final disable_post_consolidation_refresh:LX/0d8;

.field public static final enable_add_credit_card_url:LX/0d8;

.field public static final enable_add_credit_card_url_native:LX/0d8;

.field public static final enable_add_to_home_shortcut:LX/0d8;

.field public static final enable_app_update_check:LX/0d8;

.field public static final enable_ask_hatch_text_selection:LX/0d8;

.field public static final enable_biz_connector_in_settings:LX/0d8;

.field public static final enable_chathead_hatch_avatar:LX/0d8;

.field public static final enable_conversation_threads:LX/0d8;

.field public static final enable_conversation_threads_bot_status:LX/0d8;

.field public static final enable_custom_emoji:LX/0d8;

.field public static final enable_cvm_dictation:LX/0d8;

.field public static final enable_dictation_stop:LX/0d8;

.field public static final enable_dictation_with_text:LX/0d8;

.field public static final enable_emergency_push:LX/0d8;

.field public static final enable_emergency_push_restart:LX/0d8;

.field public static final enable_entry_context_token_send:LX/0d8;

.field public static final enable_feed:LX/0d8;

.field public static final enable_google_play_soft_nudge:LX/0d8;

.field public static final enable_hatch_links_settings:LX/0d8;

.field public static final enable_hatch_lock:LX/0d8;

.field public static final enable_internal_settings:LX/0d8;

.field public static final enable_markdown_soft_line_break_reflow:LX/0d8;

.field public static final enable_native_data_export:LX/0d8;

.field public static final enable_native_local_map:LX/0d8;

.field public static final enable_native_subscription_flow:LX/0d8;

.field public static final enable_native_xe_consent:LX/0d8;

.field public static final enable_offline_message_queue:LX/0d8;

.field public static final enable_product_details_prefetch:LX/0d8;

.field public static final enable_product_entity_chips:LX/0d8;

.field public static final enable_reaction_animation:LX/0d8;

.field public static final enable_reset_hatch:LX/0d8;

.field public static final enable_shared_artifact_report:LX/0d8;

.field public static final enable_shopping_result_pdp:LX/0d8;

.field public static final enable_shopping_result_pdp_buy_button:LX/0d8;

.field public static final enable_shopping_result_pdp_buy_button_for_browser:LX/0d8;

.field public static final enable_shopping_result_pdp_marketplace_enrichment:LX/0d8;

.field public static final enable_shopping_result_pdp_marketplace_hydration:LX/0d8;

.field public static final enable_snp_attestation_verifier:LX/0d8;

.field public static final enable_space_share:LX/0d8;

.field public static final enable_state_based_composer_input:LX/0d8;

.field public static final enable_static_response_redaction:LX/0d8;

.field public static final enable_subgoals:LX/0d8;

.field public static final enable_surveys:LX/0d8;

.field public static final enable_swipeable_recording:LX/0d8;

.field public static final enable_voice_dictation:LX/0d8;

.field public static final experimental_vllm_proxy_api_key:LX/0d8;

.field public static final experimental_vllm_proxy_smc_tier:LX/0d8;

.field public static final external_request_interceptor_credential_domain_allowlist:LX/0d8;

.field public static final facebook_account_learn_more_url:LX/0d8;

.field public static final file_viewer_max_render_size_mb:LX/0d8;

.field public static final file_webview_enabled:LX/0d8;

.field public static final freshning_state_enabled:LX/0d8;

.field public static final goals_sort_automatically_enabled:LX/0d8;

.field public static final goals_sorting_enabled:LX/0d8;

.field public static final hatch_agreement_url:LX/0d8;

.field public static final health_connect_connector_enabled:LX/0d8;

.field public static final invite_story_code_text:LX/0d8;

.field public static final is_share_avatar_enabled:LX/0d8;

.field public static final leak_prevention_key:LX/0d8;

.field public static final lobster_domains:LX/0d8;

.field public static final max_upload_size_limit_mb:LX/0d8;

.field public static final messenger_min_version:LX/0d8;

.field public static final native_ac_oauth_enabled:LX/0d8;

.field public static final native_strava_linking_enabled:LX/0d8;

.field public static final offline_conversation_main_message_cap:LX/0d8;

.field public static final offline_conversation_max_cached_subthreads:LX/0d8;

.field public static final offline_conversation_max_total_mb:LX/0d8;

.field public static final offline_conversation_subthread_message_cap:LX/0d8;

.field public static final play_store_min_version_force_update:LX/0d8;

.field public static final proactive_notification_sync_debounce_seconds:LX/0d8;

.field public static final share_websocket_secure_tcp_client:LX/0d8;

.field public static final should_show_tombstoned_cards:LX/0d8;

.field public static final show_browser_banner_always:LX/0d8;

.field public static final show_checkout_beta_label:LX/0d8;

.field public static final show_messenger_channel:LX/0d8;

.field public static final show_telegram_channel:LX/0d8;

.field public static final show_whatsapp_channel:LX/0d8;

.field public static final skip_fbpay_cert_verification:LX/0d8;

.field public static final tab_sorting_enabled:LX/0d8;

.field public static final tracking_to_goals_enabled:LX/0d8;

.field public static final typing_indicator_show_state:LX/0d8;

.field public static final vm_locked_push_enabled:LX/0d8;

.field public static final vm_unavailable_troubleshoot_url:LX/0d8;

.field public static final wearable_device_page_enabled:LX/0d8;

.field public static final whatsapp_settings_learn_more_url:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->INSTANCE:Lcom/facebook/aura/activation/repo/MC$hatch_android;

    .line 6
    .line 7
    const-wide v1, 0x81020300bf00edL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->artifact_sharing_enabled:LX/0d8;

    .line 18
    .line 19
    const-wide v1, 0x8302030043001eL    # 3.3835110873332E-306

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    new-instance v0, LX/0d8;

    .line 25
    .line 26
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->artifacts_path_segment:LX/0d8;

    .line 30
    .line 31
    const-wide v1, 0x82020300600a7bL

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    new-instance v0, LX/0d8;

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->attachment_inline_size_threshold_mb:LX/0d8;

    .line 42
    .line 43
    const-wide v1, 0x820203005f0a7aL

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    new-instance v0, LX/0d8;

    .line 49
    .line 50
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 51
    .line 52
    .line 53
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->attachment_inline_video_size_threshold_mb:LX/0d8;

    .line 54
    .line 55
    const-wide v1, 0x81020300b800e6L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    new-instance v0, LX/0d8;

    .line 61
    .line 62
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 63
    .line 64
    .line 65
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->color_idea_icons_enabled:LX/0d8;

    .line 66
    .line 67
    const-wide v1, 0x810203008200d4L

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    new-instance v0, LX/0d8;

    .line 73
    .line 74
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->confidential_vm_enabled:LX/0d8;

    .line 78
    .line 79
    const-wide v1, 0x8302030042001dL

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    new-instance v0, LX/0d8;

    .line 85
    .line 86
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 87
    .line 88
    .line 89
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->data_controls_learn_more_url:LX/0d8;

    .line 90
    .line 91
    const-wide v1, 0x83020300ca002aL

    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    new-instance v0, LX/0d8;

    .line 97
    .line 98
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 99
    .line 100
    .line 101
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->data_controls_privacy_url:LX/0d8;

    .line 102
    .line 103
    const-wide v1, 0x83020300c50029L

    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    new-instance v0, LX/0d8;

    .line 109
    .line 110
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 111
    .line 112
    .line 113
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->default_avatar_size:LX/0d8;

    .line 114
    .line 115
    const-wide v1, 0x83020300df002cL

    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    new-instance v0, LX/0d8;

    .line 121
    .line 122
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 123
    .line 124
    .line 125
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->dictation_service:LX/0d8;

    .line 126
    .line 127
    const-wide v1, 0x810203011300feL

    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    new-instance v0, LX/0d8;

    .line 133
    .line 134
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 135
    .line 136
    .line 137
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->disable_post_consolidation_refresh:LX/0d8;

    .line 138
    .line 139
    const-wide v1, 0x810203006500c9L

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    new-instance v0, LX/0d8;

    .line 145
    .line 146
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 147
    .line 148
    .line 149
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_add_credit_card_url:LX/0d8;

    .line 150
    .line 151
    const-wide v1, 0x810203006800caL

    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    new-instance v0, LX/0d8;

    .line 157
    .line 158
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 159
    .line 160
    .line 161
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_add_credit_card_url_native:LX/0d8;

    .line 162
    .line 163
    const-wide v1, 0x810203002400c0L

    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    new-instance v0, LX/0d8;

    .line 169
    .line 170
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 171
    .line 172
    .line 173
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_add_to_home_shortcut:LX/0d8;

    .line 174
    .line 175
    const-wide v1, 0x810203000300baL

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    new-instance v0, LX/0d8;

    .line 181
    .line 182
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 183
    .line 184
    .line 185
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_app_update_check:LX/0d8;

    .line 186
    .line 187
    const-wide v1, 0x810203003600c2L

    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    new-instance v0, LX/0d8;

    .line 193
    .line 194
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 195
    .line 196
    .line 197
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_ask_hatch_text_selection:LX/0d8;

    .line 198
    .line 199
    const-wide v1, 0x81020300ee00f9L

    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    new-instance v0, LX/0d8;

    .line 205
    .line 206
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 207
    .line 208
    .line 209
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_biz_connector_in_settings:LX/0d8;

    .line 210
    .line 211
    const-wide v1, 0x81020300a100deL

    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    new-instance v0, LX/0d8;

    .line 217
    .line 218
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 219
    .line 220
    .line 221
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_chathead_hatch_avatar:LX/0d8;

    .line 222
    .line 223
    const-wide v1, 0x810203003a00c4L

    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    new-instance v0, LX/0d8;

    .line 229
    .line 230
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 231
    .line 232
    .line 233
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_conversation_threads:LX/0d8;

    .line 234
    .line 235
    const-wide v1, 0x810203008700d6L

    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    new-instance v0, LX/0d8;

    .line 241
    .line 242
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 243
    .line 244
    .line 245
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_conversation_threads_bot_status:LX/0d8;

    .line 246
    .line 247
    const-wide v1, 0x81020300c300f0L

    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    new-instance v0, LX/0d8;

    .line 253
    .line 254
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 255
    .line 256
    .line 257
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_custom_emoji:LX/0d8;

    .line 258
    .line 259
    const-wide v1, 0x81020300f300fbL

    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    new-instance v0, LX/0d8;

    .line 265
    .line 266
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 267
    .line 268
    .line 269
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_cvm_dictation:LX/0d8;

    .line 270
    .line 271
    const-wide v1, 0x81020300f600fcL

    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    new-instance v0, LX/0d8;

    .line 277
    .line 278
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 279
    .line 280
    .line 281
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_dictation_stop:LX/0d8;

    .line 282
    .line 283
    const-wide v1, 0x81020300f700fdL

    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    new-instance v0, LX/0d8;

    .line 289
    .line 290
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 291
    .line 292
    .line 293
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_dictation_with_text:LX/0d8;

    .line 294
    .line 295
    const-wide v1, 0x81020300ba00e8L

    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    new-instance v0, LX/0d8;

    .line 301
    .line 302
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 303
    .line 304
    .line 305
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_emergency_push:LX/0d8;

    .line 306
    .line 307
    const-wide v1, 0x81020300bb00e9L

    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    new-instance v0, LX/0d8;

    .line 313
    .line 314
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 315
    .line 316
    .line 317
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_emergency_push_restart:LX/0d8;

    .line 318
    .line 319
    const-wide v1, 0x2081020300c100efL    # 4.059212878984532E-152

    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    new-instance v0, LX/0d8;

    .line 325
    .line 326
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 327
    .line 328
    .line 329
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_entry_context_token_send:LX/0d8;

    .line 330
    .line 331
    const-wide v1, 0x81020300a900e0L

    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    new-instance v0, LX/0d8;

    .line 337
    .line 338
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 339
    .line 340
    .line 341
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_feed:LX/0d8;

    .line 342
    .line 343
    const-wide v1, 0x810203008b00d9L

    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    new-instance v0, LX/0d8;

    .line 349
    .line 350
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 351
    .line 352
    .line 353
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_google_play_soft_nudge:LX/0d8;

    .line 354
    .line 355
    const-wide v1, 0x810203006900cbL

    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    new-instance v0, LX/0d8;

    .line 361
    .line 362
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 363
    .line 364
    .line 365
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_hatch_links_settings:LX/0d8;

    .line 366
    .line 367
    const-wide v1, 0x810203003400c1L

    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    new-instance v0, LX/0d8;

    .line 373
    .line 374
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 375
    .line 376
    .line 377
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_hatch_lock:LX/0d8;

    .line 378
    .line 379
    const-wide v1, 0x810203005300c6L

    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    new-instance v0, LX/0d8;

    .line 385
    .line 386
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 387
    .line 388
    .line 389
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_internal_settings:LX/0d8;

    .line 390
    .line 391
    const-wide v1, 0x81020300ab00e1L

    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    new-instance v0, LX/0d8;

    .line 397
    .line 398
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 399
    .line 400
    .line 401
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_markdown_soft_line_break_reflow:LX/0d8;

    .line 402
    .line 403
    const-wide v1, 0x81020300b700e5L

    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    new-instance v0, LX/0d8;

    .line 409
    .line 410
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 411
    .line 412
    .line 413
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_native_data_export:LX/0d8;

    .line 414
    .line 415
    const-wide v1, 0x810203009900dcL

    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    new-instance v0, LX/0d8;

    .line 421
    .line 422
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 423
    .line 424
    .line 425
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_native_local_map:LX/0d8;

    .line 426
    .line 427
    const-wide v1, 0x810203006200c8L

    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    new-instance v0, LX/0d8;

    .line 433
    .line 434
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 435
    .line 436
    .line 437
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_native_subscription_flow:LX/0d8;

    .line 438
    .line 439
    const-wide v1, 0x810203007400cdL

    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    new-instance v0, LX/0d8;

    .line 445
    .line 446
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 447
    .line 448
    .line 449
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_native_xe_consent:LX/0d8;

    .line 450
    .line 451
    const-wide v1, 0x810203001c00bdL

    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    new-instance v0, LX/0d8;

    .line 457
    .line 458
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 459
    .line 460
    .line 461
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_offline_message_queue:LX/0d8;

    .line 462
    .line 463
    const-wide v1, 0x810203007800ceL

    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    new-instance v0, LX/0d8;

    .line 469
    .line 470
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 471
    .line 472
    .line 473
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_product_details_prefetch:LX/0d8;

    .line 474
    .line 475
    const-wide v1, 0x81020300b600e4L

    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    new-instance v0, LX/0d8;

    .line 481
    .line 482
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 483
    .line 484
    .line 485
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_product_entity_chips:LX/0d8;

    .line 486
    .line 487
    const-wide v1, 0x81020300b900e7L

    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    new-instance v0, LX/0d8;

    .line 493
    .line 494
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 495
    .line 496
    .line 497
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_reaction_animation:LX/0d8;

    .line 498
    .line 499
    const-wide v1, 0x810203002200bfL

    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    new-instance v0, LX/0d8;

    .line 505
    .line 506
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 507
    .line 508
    .line 509
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_reset_hatch:LX/0d8;

    .line 510
    .line 511
    const-wide v1, 0x81020300b000e3L

    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    new-instance v0, LX/0d8;

    .line 517
    .line 518
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 519
    .line 520
    .line 521
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shared_artifact_report:LX/0d8;

    .line 522
    .line 523
    const-wide v1, 0x810203006c00ccL

    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    new-instance v0, LX/0d8;

    .line 529
    .line 530
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 531
    .line 532
    .line 533
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shopping_result_pdp:LX/0d8;

    .line 534
    .line 535
    const-wide v1, 0x810203007f00d3L

    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    new-instance v0, LX/0d8;

    .line 541
    .line 542
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 543
    .line 544
    .line 545
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shopping_result_pdp_buy_button:LX/0d8;

    .line 546
    .line 547
    const-wide v1, 0x81020300a800dfL

    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    new-instance v0, LX/0d8;

    .line 553
    .line 554
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 555
    .line 556
    .line 557
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shopping_result_pdp_buy_button_for_browser:LX/0d8;

    .line 558
    .line 559
    const-wide v1, 0x81020300be00ecL

    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    new-instance v0, LX/0d8;

    .line 565
    .line 566
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 567
    .line 568
    .line 569
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shopping_result_pdp_marketplace_enrichment:LX/0d8;

    .line 570
    .line 571
    const-wide v1, 0x81020300bd00ebL

    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    new-instance v0, LX/0d8;

    .line 577
    .line 578
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 579
    .line 580
    .line 581
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_shopping_result_pdp_marketplace_hydration:LX/0d8;

    .line 582
    .line 583
    const-wide v1, 0x810203007e00d2L

    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    new-instance v0, LX/0d8;

    .line 589
    .line 590
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 591
    .line 592
    .line 593
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_snp_attestation_verifier:LX/0d8;

    .line 594
    .line 595
    const-wide v1, 0x810203007c00d1L

    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    new-instance v0, LX/0d8;

    .line 601
    .line 602
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 603
    .line 604
    .line 605
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_space_share:LX/0d8;

    .line 606
    .line 607
    const-wide v1, 0x810203008500d5L

    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    new-instance v0, LX/0d8;

    .line 613
    .line 614
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 615
    .line 616
    .line 617
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_state_based_composer_input:LX/0d8;

    .line 618
    .line 619
    const-wide v1, 0x20810203009a00ddL

    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    new-instance v0, LX/0d8;

    .line 625
    .line 626
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 627
    .line 628
    .line 629
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_static_response_redaction:LX/0d8;

    .line 630
    .line 631
    const-wide v1, 0x81020300ae00e2L

    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    new-instance v0, LX/0d8;

    .line 637
    .line 638
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 639
    .line 640
    .line 641
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_subgoals:LX/0d8;

    .line 642
    .line 643
    const-wide v1, 0x810203008900d7L

    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    new-instance v0, LX/0d8;

    .line 649
    .line 650
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 651
    .line 652
    .line 653
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_surveys:LX/0d8;

    .line 654
    .line 655
    const-wide v1, 0x20810203000900bbL    # 4.059212868759797E-152

    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    new-instance v0, LX/0d8;

    .line 661
    .line 662
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 663
    .line 664
    .line 665
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_swipeable_recording:LX/0d8;

    .line 666
    .line 667
    const-wide v1, 0x20810203001f00beL    # 4.059212869982317E-152

    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    new-instance v0, LX/0d8;

    .line 673
    .line 674
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 675
    .line 676
    .line 677
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->enable_voice_dictation:LX/0d8;

    .line 678
    .line 679
    const-wide v1, 0x83020300720020L

    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    new-instance v0, LX/0d8;

    .line 685
    .line 686
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 687
    .line 688
    .line 689
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->experimental_vllm_proxy_api_key:LX/0d8;

    .line 690
    .line 691
    const-wide v1, 0x83020300730021L

    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    new-instance v0, LX/0d8;

    .line 697
    .line 698
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 699
    .line 700
    .line 701
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->experimental_vllm_proxy_smc_tier:LX/0d8;

    .line 702
    .line 703
    const-wide v1, 0x830203009b0026L

    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    new-instance v0, LX/0d8;

    .line 709
    .line 710
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 711
    .line 712
    .line 713
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->external_request_interceptor_credential_domain_allowlist:LX/0d8;

    .line 714
    .line 715
    const-wide v1, 0x8302030045001fL

    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    new-instance v0, LX/0d8;

    .line 721
    .line 722
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 723
    .line 724
    .line 725
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->facebook_account_learn_more_url:LX/0d8;

    .line 726
    .line 727
    const-wide v1, 0x82020300610a7cL

    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    new-instance v0, LX/0d8;

    .line 733
    .line 734
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 735
    .line 736
    .line 737
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->file_viewer_max_render_size_mb:LX/0d8;

    .line 738
    .line 739
    const-wide v1, 0x81020300c000eeL

    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    new-instance v0, LX/0d8;

    .line 745
    .line 746
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 747
    .line 748
    .line 749
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->file_webview_enabled:LX/0d8;

    .line 750
    .line 751
    const-wide v1, 0x81020300c700f1L

    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    new-instance v0, LX/0d8;

    .line 757
    .line 758
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 759
    .line 760
    .line 761
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->freshning_state_enabled:LX/0d8;

    .line 762
    .line 763
    const-wide v1, 0x81020300d400f7L

    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    new-instance v0, LX/0d8;

    .line 769
    .line 770
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 771
    .line 772
    .line 773
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->goals_sort_automatically_enabled:LX/0d8;

    .line 774
    .line 775
    const-wide v1, 0x81020300d200f5L

    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    new-instance v0, LX/0d8;

    .line 781
    .line 782
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 783
    .line 784
    .line 785
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->goals_sorting_enabled:LX/0d8;

    .line 786
    .line 787
    const-wide v1, 0x83020300810023L

    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    new-instance v0, LX/0d8;

    .line 793
    .line 794
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 795
    .line 796
    .line 797
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->hatch_agreement_url:LX/0d8;

    .line 798
    .line 799
    const-wide v1, 0x810203008f00daL

    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    new-instance v0, LX/0d8;

    .line 805
    .line 806
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 807
    .line 808
    .line 809
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->health_connect_connector_enabled:LX/0d8;

    .line 810
    .line 811
    const-wide v1, 0x83020300c40028L

    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    new-instance v0, LX/0d8;

    .line 817
    .line 818
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 819
    .line 820
    .line 821
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->invite_story_code_text:LX/0d8;

    .line 822
    .line 823
    const-wide v1, 0x81020300bc00eaL

    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    new-instance v0, LX/0d8;

    .line 829
    .line 830
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 831
    .line 832
    .line 833
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->is_share_avatar_enabled:LX/0d8;

    .line 834
    .line 835
    const-wide v1, 0x83020300a20027L

    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    new-instance v0, LX/0d8;

    .line 841
    .line 842
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 843
    .line 844
    .line 845
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->leak_prevention_key:LX/0d8;

    .line 846
    .line 847
    const-wide v1, 0x830203000e001cL

    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    new-instance v0, LX/0d8;

    .line 853
    .line 854
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 855
    .line 856
    .line 857
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->lobster_domains:LX/0d8;

    .line 858
    .line 859
    const-wide v1, 0x820203003e0a78L

    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    new-instance v0, LX/0d8;

    .line 865
    .line 866
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 867
    .line 868
    .line 869
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->max_upload_size_limit_mb:LX/0d8;

    .line 870
    .line 871
    const-wide v1, 0x82020300390a77L

    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    new-instance v0, LX/0d8;

    .line 877
    .line 878
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 879
    .line 880
    .line 881
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->messenger_min_version:LX/0d8;

    .line 882
    .line 883
    const-wide v1, 0x810203001a00bcL

    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    new-instance v0, LX/0d8;

    .line 889
    .line 890
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 891
    .line 892
    .line 893
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->native_ac_oauth_enabled:LX/0d8;

    .line 894
    .line 895
    const-wide v1, 0x810203005700c7L

    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    new-instance v0, LX/0d8;

    .line 901
    .line 902
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 903
    .line 904
    .line 905
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->native_strava_linking_enabled:LX/0d8;

    .line 906
    .line 907
    const-wide v1, 0x82020300710a80L

    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    new-instance v0, LX/0d8;

    .line 913
    .line 914
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 915
    .line 916
    .line 917
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->offline_conversation_main_message_cap:LX/0d8;

    .line 918
    .line 919
    const-wide v1, 0x820203006f0a7eL

    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    new-instance v0, LX/0d8;

    .line 925
    .line 926
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 927
    .line 928
    .line 929
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->offline_conversation_max_cached_subthreads:LX/0d8;

    .line 930
    .line 931
    const-wide v1, 0x82020300700a7fL

    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    new-instance v0, LX/0d8;

    .line 937
    .line 938
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 939
    .line 940
    .line 941
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->offline_conversation_max_total_mb:LX/0d8;

    .line 942
    .line 943
    const-wide v1, 0x820203006e0a7dL

    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    new-instance v0, LX/0d8;

    .line 949
    .line 950
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 951
    .line 952
    .line 953
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->offline_conversation_subthread_message_cap:LX/0d8;

    .line 954
    .line 955
    const-wide v1, 0x83020300800022L

    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    new-instance v0, LX/0d8;

    .line 961
    .line 962
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 963
    .line 964
    .line 965
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->play_store_min_version_force_update:LX/0d8;

    .line 966
    .line 967
    const-wide v1, 0x82020300500a79L

    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    new-instance v0, LX/0d8;

    .line 973
    .line 974
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 975
    .line 976
    .line 977
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->proactive_notification_sync_debounce_seconds:LX/0d8;

    .line 978
    .line 979
    const-wide v1, 0x810203009100dbL

    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    new-instance v0, LX/0d8;

    .line 985
    .line 986
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 987
    .line 988
    .line 989
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->share_websocket_secure_tcp_client:LX/0d8;

    .line 990
    .line 991
    const-wide v1, 0x81020300ce00f3L

    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    new-instance v0, LX/0d8;

    .line 997
    .line 998
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 999
    .line 1000
    .line 1001
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->should_show_tombstoned_cards:LX/0d8;

    .line 1002
    .line 1003
    const-wide v1, 0x81020300cc00f2L

    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    new-instance v0, LX/0d8;

    .line 1009
    .line 1010
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1011
    .line 1012
    .line 1013
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->show_browser_banner_always:LX/0d8;

    .line 1014
    .line 1015
    const-wide v1, 0x81020300d000f4L

    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    new-instance v0, LX/0d8;

    .line 1021
    .line 1022
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1023
    .line 1024
    .line 1025
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->show_checkout_beta_label:LX/0d8;

    .line 1026
    .line 1027
    const-wide v1, 0x810203003700c3L

    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    new-instance v0, LX/0d8;

    .line 1033
    .line 1034
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1035
    .line 1036
    .line 1037
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->show_messenger_channel:LX/0d8;

    .line 1038
    .line 1039
    const-wide v1, 0x810203007a00cfL

    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    new-instance v0, LX/0d8;

    .line 1045
    .line 1046
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1047
    .line 1048
    .line 1049
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->show_telegram_channel:LX/0d8;

    .line 1050
    .line 1051
    const-wide v1, 0x810203007b00d0L

    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    new-instance v0, LX/0d8;

    .line 1057
    .line 1058
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1059
    .line 1060
    .line 1061
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->show_whatsapp_channel:LX/0d8;

    .line 1062
    .line 1063
    const-wide v1, 0x810203005200c5L

    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    new-instance v0, LX/0d8;

    .line 1069
    .line 1070
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1071
    .line 1072
    .line 1073
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->skip_fbpay_cert_verification:LX/0d8;

    .line 1074
    .line 1075
    const-wide v1, 0x81020300e200f8L

    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    new-instance v0, LX/0d8;

    .line 1081
    .line 1082
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1083
    .line 1084
    .line 1085
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->tab_sorting_enabled:LX/0d8;

    .line 1086
    .line 1087
    const-wide v1, 0x81020300d300f6L

    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    new-instance v0, LX/0d8;

    .line 1093
    .line 1094
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1095
    .line 1096
    .line 1097
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->tracking_to_goals_enabled:LX/0d8;

    .line 1098
    .line 1099
    const-wide v1, 0x83020300d1002bL

    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    new-instance v0, LX/0d8;

    .line 1105
    .line 1106
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1107
    .line 1108
    .line 1109
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->typing_indicator_show_state:LX/0d8;

    .line 1110
    .line 1111
    const-wide v1, 0x810203008a00d8L

    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    new-instance v0, LX/0d8;

    .line 1117
    .line 1118
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1119
    .line 1120
    .line 1121
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->vm_locked_push_enabled:LX/0d8;

    .line 1122
    .line 1123
    const-wide v1, 0x83020300960025L

    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    new-instance v0, LX/0d8;

    .line 1129
    .line 1130
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1131
    .line 1132
    .line 1133
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->vm_unavailable_troubleshoot_url:LX/0d8;

    .line 1134
    .line 1135
    const-wide v1, 0x81020300f000faL

    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    new-instance v0, LX/0d8;

    .line 1141
    .line 1142
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1143
    .line 1144
    .line 1145
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->wearable_device_page_enabled:LX/0d8;

    .line 1146
    .line 1147
    const-wide v1, 0x83020300900024L

    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    new-instance v0, LX/0d8;

    .line 1153
    .line 1154
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 1155
    .line 1156
    .line 1157
    sput-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->whatsapp_settings_learn_more_url:LX/0d8;

    .line 1158
    .line 1159
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
