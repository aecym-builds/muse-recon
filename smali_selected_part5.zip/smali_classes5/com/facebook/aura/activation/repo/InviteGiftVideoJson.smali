.class public final Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$Companion;


# instance fields
.field public final height:I

.field public final url_dark:Ljava/lang/String;

.field public final url_light:Ljava/lang/String;

.field public final width:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->Companion:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const-string v1, ""

    .line 805306369
    .line 805306370
    const/4 v0, 0x0

    .line 805306371
    invoke-direct {p0, v1, v1, v0, v0}, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;IILX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const-string v1, ""

    .line 536870918
    .line 536870919
    if-nez v0, :cond_2

    .line 536870920
    .line 536870921
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 536870922
    .line 536870923
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870924
    .line 536870925
    if-nez v0, :cond_1

    .line 536870926
    .line 536870927
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 536870928
    .line 536870929
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870930
    .line 536870931
    const/4 v1, 0x0

    .line 536870932
    if-nez v0, :cond_0

    .line 536870933
    .line 536870934
    iput v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 536870935
    .line 536870936
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 536870937
    .line 536870938
    if-nez v0, :cond_3

    .line 536870939
    .line 536870940
    iput v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 536870941
    .line 536870942
    return-void

    .line 536870943
    :cond_0
    iput p4, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 536870944
    .line 536870945
    goto :goto_2

    .line 536870946
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 536870947
    .line 536870948
    goto :goto_1

    .line 536870949
    :cond_2
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 536870950
    .line 536870951
    goto :goto_0

    .line 536870952
    :cond_3
    iput p5, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 536870953
    .line 536870954
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;II)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 9
    .line 10
    iput p3, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 11
    .line 12
    iput p4, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;IIILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p5, 0x1

    .line 268435457
    .line 268435458
    const-string v1, ""

    .line 268435459
    .line 268435460
    if-eqz v0, :cond_0

    .line 268435461
    .line 268435462
    move-object p1, v1

    .line 268435463
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 268435464
    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 268435469
    .line 268435470
    if-eqz v0, :cond_2

    .line 268435471
    .line 268435472
    const/4 p3, 0x0

    .line 268435473
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 268435474
    .line 268435475
    if-eqz v0, :cond_3

    .line 268435476
    .line 268435477
    const/4 p4, 0x0

    .line 268435478
    :cond_3
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    .line 268435479
    .line 268435480
    .line 268435481
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/Object;)Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget p3, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 23
    .line 24
    :cond_3
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 28
    .line 29
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    .line 30
    .line 31
    .line 32
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    const-string v2, ""

    .line 6
    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x1

    .line 23
    if-nez v3, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    const/4 v1, 0x2

    .line 39
    if-nez v3, :cond_4

    .line 40
    .line 41
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 42
    .line 43
    if-eqz v0, :cond_5

    .line 44
    .line 45
    :cond_4
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 46
    .line 47
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 48
    .line 49
    .line 50
    :cond_5
    const/4 v1, 0x3

    .line 51
    if-nez v3, :cond_6

    .line 52
    .line 53
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 54
    .line 55
    if-eqz v0, :cond_7

    .line 56
    .line 57
    :cond_6
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 58
    .line 59
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 60
    .line 61
    .line 62
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 1
    .line 2
    return p0
.end method

.method public final component4()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;II)Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 31
    .line 32
    iget v0, p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget v1, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 37
    .line 38
    iget v0, p1, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 39
    .line 40
    if-eq v1, v0, :cond_1

    .line 41
    .line 42
    :cond_0
    return v2

    .line 43
    :cond_1
    return v3
.end method

.method public final getHeight()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 1
    .line 2
    return p0
.end method

.method public final getUrl_dark()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUrl_light()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getWidth()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_light:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->url_dark:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->width:I

    .line 15
    .line 16
    add-int/2addr v1, v0

    .line 17
    mul-int/lit8 v1, v1, 0x1f

    .line 18
    .line 19
    iget v0, p0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;->height:I

    .line 20
    .line 21
    add-int/2addr v1, v0

    .line 22
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
