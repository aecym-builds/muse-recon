.class public final synthetic Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/repo/InvitePageResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x11

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.activation.repo.InvitePageResponseJson"

    .line 10
    .line 11
    new-instance v2, LX/DZp;

    .line 12
    .line 13
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "invite_state"

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "title"

    .line 23
    .line 24
    invoke-static {v0, v2, v1}, LX/602;->A1N(Ljava/lang/String;LX/DZp;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "subtitle_link_text"

    .line 28
    .line 29
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "subtitle_link_url"

    .line 33
    .line 34
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "code"

    .line 38
    .line 39
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "invite_link"

    .line 43
    .line 44
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    const-string v0, "uses_remaining"

    .line 48
    .line 49
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    const-string v0, "share_text"

    .line 53
    .line 54
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    const-string v0, "story_share_text"

    .line 58
    .line 59
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 60
    .line 61
    .line 62
    const-string v0, "show_gift"

    .line 63
    .line 64
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 65
    .line 66
    .line 67
    const-string v0, "has_redeemed_invite_code"

    .line 68
    .line 69
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 70
    .line 71
    .line 72
    const-string v0, "show_redeem_button"

    .line 73
    .line 74
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 75
    .line 76
    .line 77
    const-string v0, "reward"

    .line 78
    .line 79
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 80
    .line 81
    .line 82
    const-string v0, "gift_video"

    .line 83
    .line 84
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 85
    .line 86
    .line 87
    const-string v0, "redeem_invite_code_screen"

    .line 88
    .line 89
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 90
    .line 91
    .line 92
    const-string v0, "redeem_invite_code_success_screen"

    .line 93
    .line 94
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 95
    .line 96
    .line 97
    sput-object v2, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->descriptor:LX/Da5;

    .line 98
    .line 99
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 19
    .line 20
    .line 21
    move-result-object v6

    .line 22
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 27
    .line 28
    .line 29
    move-result-object v8

    .line 30
    sget-object v0, LX/DYo;->A00:LX/DYo;

    .line 31
    .line 32
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 33
    .line 34
    .line 35
    move-result-object v9

    .line 36
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 37
    .line 38
    .line 39
    move-result-object v10

    .line 40
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 41
    .line 42
    .line 43
    move-result-object v11

    .line 44
    sget-object v12, LX/DYz;->A00:LX/DYz;

    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;

    .line 47
    .line 48
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 49
    .line 50
    .line 51
    move-result-object v15

    .line 52
    sget-object v0, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;

    .line 53
    .line 54
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 55
    .line 56
    .line 57
    move-result-object v16

    .line 58
    sget-object v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

    .line 59
    .line 60
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 61
    .line 62
    .line 63
    move-result-object v17

    .line 64
    sget-object v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;

    .line 65
    .line 66
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    move-object v13, v12

    .line 71
    move-object v14, v12

    .line 72
    filled-new-array/range {v2 .. v18}, [LX/DZ7;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/InvitePageResponseJson;
    .locals 22

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v1, p1

    .line 2
    .line 3
    invoke-static {v1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v1, v0}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/16 p0, 0x0

    .line 13
    .line 14
    move-object/from16 v9, p0

    .line 15
    .line 16
    move-object v8, v9

    .line 17
    move-object/from16 v21, v9

    .line 18
    .line 19
    move-object/from16 v20, v9

    .line 20
    .line 21
    move-object/from16 v19, v9

    .line 22
    .line 23
    move-object v14, v9

    .line 24
    move-object v13, v9

    .line 25
    move-object v12, v9

    .line 26
    move-object v10, v9

    .line 27
    move-object v11, v9

    .line 28
    move-object v15, v9

    .line 29
    move-object v6, v9

    .line 30
    move-object v7, v9

    .line 31
    const/4 v5, 0x0

    .line 32
    const/16 v17, 0x0

    .line 33
    .line 34
    const/16 v16, 0x0

    .line 35
    .line 36
    const/16 v18, 0x0

    .line 37
    .line 38
    :goto_0
    invoke-interface {v1, v0}, LX/Da7;->A8S(LX/Da5;)I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    packed-switch v2, :pswitch_data_0

    .line 43
    .line 44
    .line 45
    new-instance v0, Lkotlinx/serialization/UnknownFieldException;

    .line 46
    .line 47
    invoke-direct {v0, v2}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 48
    .line 49
    .line 50
    throw v0

    .line 51
    :pswitch_0
    invoke-static {v0, v1, v4}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    or-int/lit8 v5, v5, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :pswitch_1
    sget-object v3, LX/DYp;->A01:LX/DYp;

    .line 59
    .line 60
    const/4 v2, 0x1

    .line 61
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v7

    .line 65
    check-cast v7, Ljava/lang/String;

    .line 66
    .line 67
    or-int/lit8 v5, v5, 0x2

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :pswitch_2
    invoke-static {v0, v1}, LX/3Rs;->A0U(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v8

    .line 74
    or-int/lit8 v5, v5, 0x4

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :pswitch_3
    sget-object v3, LX/DYp;->A01:LX/DYp;

    .line 78
    .line 79
    const/4 v2, 0x3

    .line 80
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    check-cast v9, Ljava/lang/String;

    .line 85
    .line 86
    or-int/lit8 v5, v5, 0x8

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :pswitch_4
    invoke-static {v0, v1}, LX/3Rs;->A0W(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v10

    .line 93
    or-int/lit8 v5, v5, 0x10

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :pswitch_5
    invoke-static {v0, v1}, LX/3Rs;->A0X(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    or-int/lit8 v5, v5, 0x20

    .line 101
    .line 102
    goto :goto_0

    .line 103
    :pswitch_6
    invoke-static {v0, v1}, LX/3Rs;->A0Y(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v12

    .line 107
    or-int/lit8 v5, v5, 0x40

    .line 108
    .line 109
    goto :goto_0

    .line 110
    :pswitch_7
    sget-object v3, LX/DYo;->A00:LX/DYo;

    .line 111
    .line 112
    const/4 v2, 0x7

    .line 113
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v13

    .line 117
    check-cast v13, Ljava/lang/Integer;

    .line 118
    .line 119
    or-int/lit16 v5, v5, 0x80

    .line 120
    .line 121
    goto :goto_0

    .line 122
    :pswitch_8
    invoke-static {v0, v1}, LX/3Rs;->A0a(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v14

    .line 126
    or-int/lit16 v5, v5, 0x100

    .line 127
    .line 128
    goto :goto_0

    .line 129
    :pswitch_9
    invoke-static {v0, v1}, LX/3Rs;->A0b(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v15

    .line 133
    or-int/lit16 v5, v5, 0x200

    .line 134
    .line 135
    goto :goto_0

    .line 136
    :pswitch_a
    const/16 v2, 0xa

    .line 137
    .line 138
    invoke-interface {v1, v0, v2}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 139
    .line 140
    .line 141
    move-result v16

    .line 142
    or-int/lit16 v5, v5, 0x400

    .line 143
    .line 144
    goto :goto_0

    .line 145
    :pswitch_b
    const/16 v2, 0xb

    .line 146
    .line 147
    invoke-interface {v1, v0, v2}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 148
    .line 149
    .line 150
    move-result v17

    .line 151
    or-int/lit16 v5, v5, 0x800

    .line 152
    .line 153
    goto :goto_0

    .line 154
    :pswitch_c
    const/16 v2, 0xc

    .line 155
    .line 156
    invoke-interface {v1, v0, v2}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 157
    .line 158
    .line 159
    move-result v18

    .line 160
    or-int/lit16 v5, v5, 0x1000

    .line 161
    .line 162
    goto :goto_0

    .line 163
    :pswitch_d
    sget-object v3, Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteRewardJson$$serializer;

    .line 164
    .line 165
    const/16 v2, 0xd

    .line 166
    .line 167
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v19

    .line 171
    check-cast v19, Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 172
    .line 173
    or-int/lit16 v5, v5, 0x2000

    .line 174
    .line 175
    goto/16 :goto_0

    .line 176
    .line 177
    :pswitch_e
    sget-object v3, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/InviteGiftVideoJson$$serializer;

    .line 178
    .line 179
    const/16 v2, 0xe

    .line 180
    .line 181
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v20

    .line 185
    check-cast v20, Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;

    .line 186
    .line 187
    or-int/lit16 v5, v5, 0x4000

    .line 188
    .line 189
    goto/16 :goto_0

    .line 190
    .line 191
    :pswitch_f
    sget-object v3, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

    .line 192
    .line 193
    const/16 v2, 0xf

    .line 194
    .line 195
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v21

    .line 199
    check-cast v21, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 200
    .line 201
    const v2, 0x8000

    .line 202
    .line 203
    .line 204
    goto :goto_1

    .line 205
    :pswitch_10
    sget-object v3, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson$$serializer;

    .line 206
    .line 207
    const/16 v2, 0x10

    .line 208
    .line 209
    invoke-interface {v1, v3, v0, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p0

    .line 213
    check-cast p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;

    .line 214
    .line 215
    const/high16 v2, 0x10000

    .line 216
    .line 217
    :goto_1
    or-int/2addr v5, v2

    .line 218
    goto/16 :goto_0

    .line 219
    .line 220
    :pswitch_11
    invoke-interface {v1, v0}, LX/Da7;->AAi(LX/Da5;)V

    .line 221
    .line 222
    .line 223
    const/16 p1, 0x0

    .line 224
    .line 225
    new-instance v4, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 226
    .line 227
    invoke-direct/range {v4 .. v23}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ZZZLcom/facebook/aura/activation/repo/InviteRewardJson;Lcom/facebook/aura/activation/repo/InviteGiftVideoJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Lcom/facebook/aura/activation/repo/RedeemInviteCodeSuccessScreenJson;LX/5Xm;)V

    .line 228
    .line 229
    .line 230
    return-object v4

    .line 231
    nop

    .line 232
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_11
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
        :pswitch_10
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/InvitePageResponseJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/InvitePageResponseJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/InvitePageResponseJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
