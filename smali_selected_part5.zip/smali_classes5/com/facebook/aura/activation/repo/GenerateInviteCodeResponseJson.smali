.class public final Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson$Companion;


# instance fields
.field public final code:Ljava/lang/String;

.field public final invite_link:Ljava/lang/String;

.field public final max_uses:Ljava/lang/Integer;

.field public final share_text:Ljava/lang/String;

.field public final use_count:Ljava/lang/Integer;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->Companion:Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v0, p0

    .line 2
    move-object v2, v1

    .line 3
    move-object v3, v1

    .line 4
    move-object v4, v1

    .line 5
    move-object p0, v1

    .line 6
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const/4 v1, 0x0

    .line 268435462
    if-nez v0, :cond_3

    .line 268435463
    .line 268435464
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 268435465
    .line 268435466
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    if-nez v0, :cond_2

    .line 268435469
    .line 268435470
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 268435471
    .line 268435472
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435473
    .line 268435474
    if-nez v0, :cond_1

    .line 268435475
    .line 268435476
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 268435477
    .line 268435478
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 268435479
    .line 268435480
    if-nez v0, :cond_0

    .line 268435481
    .line 268435482
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 268435483
    .line 268435484
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 268435485
    .line 268435486
    if-nez v0, :cond_4

    .line 268435487
    .line 268435488
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 268435489
    .line 268435490
    return-void

    .line 268435491
    :cond_0
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 268435492
    .line 268435493
    goto :goto_3

    .line 268435494
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 268435495
    .line 268435496
    goto :goto_2

    .line 268435497
    :cond_2
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 268435498
    .line 268435499
    goto :goto_1

    .line 268435500
    :cond_3
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 268435501
    .line 268435502
    goto :goto_0

    .line 268435503
    :cond_4
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 268435504
    .line 268435505
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 805306368
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 805306369
    .line 805306370
    .line 805306371
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 805306372
    .line 805306373
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 805306374
    .line 805306375
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 805306376
    .line 805306377
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 805306378
    .line 805306379
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 805306380
    .line 805306381
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p6, 0x1

    .line 536870913
    .line 536870914
    const/4 v1, 0x0

    .line 536870915
    if-eqz v0, :cond_0

    .line 536870916
    .line 536870917
    move-object p1, v1

    .line 536870918
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    move-object p2, v1

    .line 536870923
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 536870924
    .line 536870925
    if-eqz v0, :cond_2

    .line 536870926
    .line 536870927
    move-object p3, v1

    .line 536870928
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 536870929
    .line 536870930
    if-eqz v0, :cond_3

    .line 536870931
    .line 536870932
    move-object p4, v1

    .line 536870933
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 536870934
    .line 536870935
    if-eqz v0, :cond_4

    .line 536870936
    .line 536870937
    move-object p5, v1

    .line 536870938
    :cond_4
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 536870939
    .line 536870940
    .line 536870941
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->copy(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v3, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, LX/DYo;->A00:LX/DYo;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DYo;->A00:LX/DYo;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    const/4 v2, 0x3

    .line 47
    if-nez v3, :cond_6

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v0, :cond_7

    .line 52
    .line 53
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_7
    const/4 v2, 0x4

    .line 61
    if-nez v3, :cond_8

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_9

    .line 66
    .line 67
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 70
    .line 71
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 72
    .line 73
    .line 74
    :cond_9
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getCode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getInvite_link()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMax_uses()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShare_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUse_count()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 37
    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    :cond_0
    add-int/2addr v1, v2

    .line 45
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
