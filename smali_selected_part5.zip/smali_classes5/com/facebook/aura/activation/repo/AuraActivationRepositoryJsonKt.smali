.class public abstract Lcom/facebook/aura/activation/repo/AuraActivationRepositoryJsonKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final synthetic access$toInviteStateOrNull(Ljava/lang/String;)Lcom/facebook/aura/activation/data/HatchInviteState;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepositoryJsonKt;->toInviteStateOrNull(Ljava/lang/String;)Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final toInviteStateOrNull(Ljava/lang/String;)Lcom/facebook/aura/activation/data/HatchInviteState;
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const v0, -0x65d3c23d

    .line 14
    .line 15
    .line 16
    if-eq v1, v0, :cond_2

    .line 17
    .line 18
    const v0, 0x60139d7

    .line 19
    .line 20
    .line 21
    if-eq v1, v0, :cond_1

    .line 22
    .line 23
    const v0, 0x5a41bf49

    .line 24
    .line 25
    .line 26
    if-ne v1, v0, :cond_0

    .line 27
    .line 28
    const-string v0, "exhausted"

    .line 29
    .line 30
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    sget-object v3, Lcom/facebook/aura/activation/data/HatchInviteState;->EXHAUSTED:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 37
    .line 38
    :cond_0
    return-object v3

    .line 39
    :cond_1
    const-string v0, "eligible"

    .line 40
    .line 41
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_0

    .line 46
    .line 47
    sget-object v3, Lcom/facebook/aura/activation/data/HatchInviteState;->ELIGIBLE:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 48
    .line 49
    return-object v3

    .line 50
    :cond_2
    const-string v0, "not_eligible"

    .line 51
    .line 52
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_0

    .line 57
    .line 58
    sget-object v3, Lcom/facebook/aura/activation/data/HatchInviteState;->NOT_ELIGIBLE:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 59
    .line 60
    return-object v3
.end method

.method public static final toWaitlistStatusOrNull(Ljava/lang/String;)LX/7Kq;
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, LX/7Kq;->A05:LX/7Kq;

    .line 10
    .line 11
    invoke-static {v0, v1}, Lcom/facebook/graphql/enums/EnumHelper;->A00(Ljava/lang/String;Ljava/lang/Enum;)Ljava/lang/Enum;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    check-cast v0, LX/7Kq;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    if-eq v0, v1, :cond_0

    .line 23
    .line 24
    return-object v0

    .line 25
    :cond_0
    return-object v2
.end method
