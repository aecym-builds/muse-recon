.class public final synthetic Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v0, "com.facebook.aura.activation.repo.RedeemInviteCodeScreenJson"

    .line 9
    .line 10
    new-instance v2, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "title"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-static {v0, v2, v1}, LX/602;->A1N(Ljava/lang/String;LX/DZp;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "disclaimer"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    sput-object v2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->descriptor:LX/Da5;

    .line 27
    .line 28
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    filled-new-array {v0, p0, p0}, [LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
    .locals 10

    .line 0
    const/4 v6, 0x0

    .line 1
    invoke-static {p1, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->descriptor:LX/Da5;

    .line 5
    .line 6
    invoke-interface {p1, v5}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    const/4 v3, 0x2

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v8, 0x0

    .line 13
    move-object v9, v8

    .line 14
    move-object p0, v8

    .line 15
    const/4 v7, 0x0

    .line 16
    :goto_0
    invoke-interface {v4, v5}, LX/Da7;->A8S(LX/Da5;)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, -0x1

    .line 21
    if-eq v1, v0, :cond_3

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    if-eq v1, v2, :cond_0

    .line 26
    .line 27
    if-ne v1, v3, :cond_2

    .line 28
    .line 29
    invoke-interface {v4, v5, v3}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    or-int/lit8 v7, v7, 0x4

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-interface {v4, v5, v2}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v9

    .line 40
    or-int/lit8 v7, v7, 0x2

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    invoke-static {v5, v4, v6}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v8

    .line 47
    or-int/lit8 v7, v7, 0x1

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    new-instance v0, Lkotlinx/serialization/UnknownFieldException;

    .line 51
    .line 52
    invoke-direct {v0, v1}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 53
    .line 54
    .line 55
    throw v0

    .line 56
    :cond_3
    invoke-interface {v4, v5}, LX/Da7;->AAi(LX/Da5;)V

    .line 57
    .line 58
    .line 59
    const/4 p1, 0x0

    .line 60
    new-instance v6, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 61
    .line 62
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 63
    .line 64
    .line 65
    return-object v6
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
