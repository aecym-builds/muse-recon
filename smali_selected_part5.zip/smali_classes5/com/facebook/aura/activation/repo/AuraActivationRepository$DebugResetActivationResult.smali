.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;
.super LX/07H;
.source ""


# instance fields
.field public final consentRevoked:Z

.field public final redemptionsDeleted:I

.field public final waitlistReset:Z


# direct methods
.method public constructor <init>(ZIZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;ZIZILjava/lang/Object;)Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 17
    .line 18
    :cond_2
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 19
    .line 20
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;-><init>(ZIZ)V

    .line 21
    .line 22
    .line 23
    return-object v0
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component2()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(ZIZ)Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;-><init>(ZIZ)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 17
    .line 18
    iget v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 23
    .line 24
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 25
    .line 26
    if-eq v1, v0, :cond_1

    .line 27
    .line 28
    :cond_0
    return v2

    .line 29
    :cond_1
    return v3
.end method

.method public final getConsentRevoked()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getRedemptionsDeleted()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final getWaitlistReset()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->waitlistReset:Z

    .line 1
    .line 2
    const/16 v0, 0x4d5

    .line 3
    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    const/16 v0, 0x4cf

    .line 7
    .line 8
    :cond_0
    mul-int/lit8 v1, v0, 0x1f

    .line 9
    .line 10
    iget v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->redemptionsDeleted:I

    .line 11
    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v2, v1, 0x1f

    .line 14
    .line 15
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;->consentRevoked:Z

    .line 16
    .line 17
    const/16 v0, 0x4d5

    .line 18
    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    const/16 v0, 0x4cf

    .line 22
    .line 23
    :cond_1
    add-int/2addr v2, v0

    .line 24
    return v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
