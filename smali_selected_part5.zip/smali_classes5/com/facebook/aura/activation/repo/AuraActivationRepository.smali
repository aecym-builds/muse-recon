.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;


# instance fields
.field public final agreementUrl$delegate:LX/1zE;

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "agreementUrl"

    .line 1
    .line 2
    const-string v1, "getAgreementUrl()Ljava/lang/String;"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 268435460
    .line 268435461
    sget-object v0, Lcom/facebook/aura/activation/repo/MC$hatch_android;->hatch_agreement_url:LX/0d8;

    .line 268435462
    .line 268435463
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object v0

    .line 268435467
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->agreementUrl$delegate:LX/1zE;

    .line 268435468
    .line 268435469
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;-><init>(LX/AHE;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic acceptTosConsent$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Ljava/lang/String;Ljava/lang/String;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p1, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p2, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->acceptTosConsent(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/activation/repo/AuraActivationRepository;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static synthetic debugSetWaitlistStatus$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/7Kq;ZLX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->debugSetWaitlistStatus(LX/7Kq;ZLX/2M4;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method private final getAgreementUrl()Ljava/lang/String;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->agreementUrl$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    aget-object v0, v1, v0

    .line 6
    .line 7
    invoke-interface {v2, p0, v0}, LX/1zE;->getValue(Ljava/lang/Object;LX/Dqa;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/String;

    .line 12
    .line 13
    return-object v0
.end method

.method private final parseAgreementIds()LX/IBK;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const-string v5, "AuraActivationRepository"

    .line 1
    .line 2
    const/4 v4, 0x0

    .line 3
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->getAgreementUrl()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 v1, 0x2

    .line 20
    if-ge v0, v1, :cond_0

    .line 21
    .line 22
    const-string v0, "hatch_agreement_url missing recipient_view_id/nonce_code segments"

    .line 23
    .line 24
    invoke-static {v5, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object v4

    .line 28
    :cond_0
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    sub-int/2addr v0, v1

    .line 33
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    add-int/lit8 v0, v0, -0x1

    .line 42
    .line 43
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    new-instance v0, LX/IBK;

    .line 48
    .line 49
    invoke-direct {v0, v2, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    return-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 53
    :catch_0
    move-exception v1

    .line 54
    const-string v0, "Failed to parse hatch_agreement_url"

    .line 55
    .line 56
    invoke-static {v5, v0, v1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 57
    .line 58
    .line 59
    return-object v4
.end method

.method public static synthetic redeemInviteCode$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Ljava/lang/String;ZZLX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x1

    .line 5
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    const/4 p3, 0x0

    .line 10
    :cond_1
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->redeemInviteCode(Ljava/lang/String;ZZLX/2M4;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method private final updateHasRedeemedInviteCode(Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;)V
    .locals 2

    .line 0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->Companion:Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    sget-object v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateHasRedeemedInviteCode$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateHasRedeemedInviteCode$1;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->atomicUpdate(LX/JDM;)V

    .line 11
    .line 12
    .line 13
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 14
    :catch_0
    move-exception p0

    .line 15
    const-string v1, "Failed to update hasRedeemedInviteCode"

    .line 16
    .line 17
    const-string v0, "AuraActivationRepository"

    .line 18
    .line 19
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method private final updateLocalHasAcceptedTos(Z)V
    .locals 2

    .line 0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->Companion:Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalHasAcceptedTos$1;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalHasAcceptedTos$1;-><init>(Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->atomicUpdate(LX/JDM;)V

    .line 14
    .line 15
    .line 16
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception p0

    .line 18
    const-string v1, "Failed to update local TOS consent"

    .line 19
    .line 20
    const-string v0, "AuraActivationRepository"

    .line 21
    .line 22
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method private final updateLocalIsNdaRequired(Z)V
    .locals 2

    .line 0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->Companion:Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalIsNdaRequired$1;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalIsNdaRequired$1;-><init>(Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->atomicUpdate(LX/JDM;)V

    .line 14
    .line 15
    .line 16
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception p0

    .line 18
    const-string v1, "Failed to update local NDA required"

    .line 19
    .line 20
    const-string v0, "AuraActivationRepository"

    .line 21
    .line 22
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method private final updateLocalWaitlistStatus(LX/7Kq;)V
    .locals 2

    .line 0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->Companion:Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalWaitlistStatus$1;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$updateLocalWaitlistStatus$1;-><init>(LX/7Kq;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->atomicUpdate(LX/JDM;)V

    .line 14
    .line 15
    .line 16
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception p0

    .line 18
    const-string v1, "Failed to update local waitlist status"

    .line 19
    .line 20
    const-string v0, "AuraActivationRepository"

    .line 21
    .line 22
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final acceptNdaAgreement(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const-string v7, "acceptNdaAgreement failed: HTTP "

    .line 1
    .line 2
    const-string v6, " ("

    .line 3
    .line 4
    move-object/from16 v3, p3

    .line 5
    .line 6
    instance-of v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;

    .line 7
    .line 8
    move-object/from16 v4, p0

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    move-object v8, v3

    .line 13
    check-cast v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;

    .line 14
    .line 15
    iget v2, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->label:I

    .line 16
    .line 17
    const/high16 v1, -0x80000000

    .line 18
    .line 19
    and-int v0, v2, v1

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    sub-int/2addr v2, v1

    .line 24
    iput v2, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v1, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v2, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->label:I

    .line 31
    .line 32
    const-string v3, "AuraActivationRepository"

    .line 33
    .line 34
    const/4 v0, 0x1

    .line 35
    if-eqz v2, :cond_2

    .line 36
    .line 37
    if-ne v2, v0, :cond_1

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;

    .line 41
    .line 42
    invoke-direct {v8, v4, v3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :goto_1
    :try_start_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    const/4 v2, 0x0

    .line 50
    goto :goto_2
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 51
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 52
    .line 53
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 54
    .line 55
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw v0

    .line 59
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    invoke-direct {v4}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->parseAgreementIds()LX/IBK;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    if-eqz v1, :cond_a

    .line 67
    .line 68
    iget-object v2, v1, LX/IBK;->first:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v2, Ljava/lang/String;

    .line 71
    .line 72
    iget-object v1, v1, LX/IBK;->second:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v1, Ljava/lang/String;

    .line 75
    .line 76
    :try_start_1
    sget-object v11, Lcom/facebook/aura/network/stefi/AuraStefiClient;->INSTANCE:Lcom/facebook/aura/network/stefi/AuraStefiClient;

    .line 77
    .line 78
    new-instance v12, Lcom/facebook/aura/network/api/StefiHatchPath$OneClickAgreementAccept;

    .line 79
    .line 80
    invoke-direct {v12, v2, v1}, Lcom/facebook/aura/network/api/StefiHatchPath$OneClickAgreementAccept;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    const-string v13, "hatch_accept_nda"

    .line 84
    .line 85
    sget-object v9, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 86
    .line 87
    new-instance v2, Lcom/facebook/aura/activation/repo/NdaAcceptRequestJson;

    .line 88
    .line 89
    move-object/from16 v10, p1

    .line 90
    .line 91
    move-object/from16 v1, p2

    .line 92
    .line 93
    invoke-direct {v2, v10, v1}, Lcom/facebook/aura/activation/repo/NdaAcceptRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sget-object v1, Lcom/facebook/aura/activation/repo/NdaAcceptRequestJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaAcceptRequestJson$$serializer;

    .line 97
    .line 98
    invoke-static {v2, v1, v9}, LX/Bi9;->A0N(Ljava/lang/Object;LX/DZE;LX/Dcb;)[B

    .line 99
    .line 100
    .line 101
    move-result-object v14

    .line 102
    const/4 v1, 0x0

    .line 103
    iput-object v1, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->L$0:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object v1, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->L$1:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v1, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->L$2:Ljava/lang/Object;

    .line 108
    .line 109
    iput-object v1, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->L$3:Ljava/lang/Object;

    .line 110
    .line 111
    iput v0, v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptNdaAgreement$1;->label:I

    .line 112
    .line 113
    const/4 v2, 0x0

    .line 114
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 115
    .line 116
    .line 117
    move-result-object v15

    .line 118
    const/16 v9, 0x3d

    .line 119
    .line 120
    invoke-static {v9}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v16

    .line 124
    sget-object p2, Lcom/facebook/aura/network/stefi/AuraStefiClient$post$2;->INSTANCE:Lcom/facebook/aura/network/stefi/AuraStefiClient$post$2;

    .line 125
    .line 126
    move-object/from16 v19, v1

    .line 127
    .line 128
    move/from16 v20, v2

    .line 129
    .line 130
    move-object/from16 p0, v1

    .line 131
    .line 132
    move/from16 p1, v0

    .line 133
    .line 134
    move-object/from16 p3, v8

    .line 135
    .line 136
    move-object/from16 v17, v1

    .line 137
    .line 138
    move/from16 v18, v0

    .line 139
    .line 140
    invoke-virtual/range {v11 .. v24}, Lcom/facebook/aura/network/stefi/AuraStefiClient;->post(Lcom/facebook/aura/network/api/StefiPath;Ljava/lang/String;[BLjava/util/Map;Ljava/lang/String;Ljava/lang/Long;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLX/AHE;ZLkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    if-ne v1, v5, :cond_3

    .line 145
    .line 146
    return-object v5

    .line 147
    :cond_3
    :goto_2
    check-cast v1, Lcom/facebook/aura/network/AuraHttpResponse;

    .line 148
    .line 149
    iget-boolean v0, v1, Lcom/facebook/aura/network/AuraHttpResponse;->isSuccessful:Z

    .line 150
    .line 151
    const/4 v5, 0x0

    .line 152
    if-nez v0, :cond_6

    .line 153
    .line 154
    iget v4, v1, Lcom/facebook/aura/network/AuraHttpResponse;->code:I

    .line 155
    .line 156
    iget-object v1, v1, Lcom/facebook/aura/network/AuraHttpResponse;->errorMessage:Ljava/lang/String;

    .line 157
    .line 158
    if-eqz v1, :cond_4

    .line 159
    .line 160
    const-string v0, ")"

    .line 161
    .line 162
    invoke-static {v6, v1, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v5

    .line 166
    :cond_4
    if-nez v5, :cond_5

    .line 167
    .line 168
    const-string v5, ""

    .line 169
    .line 170
    :cond_5
    invoke-static {v7, v4, v5}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-static {v3, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 178
    .line 179
    .line 180
    move-result-object v5

    .line 181
    return-object v5
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    .line 182
    :cond_6
    :try_start_2
    invoke-virtual {v1}, Lcom/facebook/aura/network/AuraHttpResponse;->bodyString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v1

    .line 186
    if-eqz v1, :cond_8

    .line 187
    .line 188
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 189
    .line 190
    .line 191
    move-result v0

    .line 192
    if-nez v0, :cond_7

    .line 193
    .line 194
    move-object v5, v1

    .line 195
    :cond_7
    if-eqz v5, :cond_8

    .line 196
    .line 197
    sget-object v1, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 198
    .line 199
    sget-object v0, Lcom/facebook/aura/activation/repo/NdaAcceptResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaAcceptResponseJson$$serializer;

    .line 200
    .line 201
    invoke-virtual {v1, v5, v0}, LX/Dcb;->A00(Ljava/lang/String;LX/Dci;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    check-cast v0, Lcom/facebook/aura/activation/repo/NdaAcceptResponseJson;

    .line 206
    .line 207
    iget-object v0, v0, Lcom/facebook/aura/activation/repo/NdaAcceptResponseJson;->success:Ljava/lang/Boolean;

    .line 208
    .line 209
    invoke-static {v0, v2}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    goto :goto_3
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1

    .line 214
    :catch_0
    :cond_8
    const/4 v0, 0x0

    .line 215
    :goto_3
    if-eqz v0, :cond_9

    .line 216
    .line 217
    :try_start_3
    const-string v0, "acceptNdaAgreement returned success=false"

    .line 218
    .line 219
    invoke-static {v3, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 223
    .line 224
    .line 225
    move-result-object v5

    .line 226
    return-object v5

    .line 227
    :cond_9
    invoke-direct {v4, v2}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateLocalIsNdaRequired(Z)V

    .line 228
    .line 229
    .line 230
    const/4 v0, 0x1

    .line 231
    goto :goto_4
    :try_end_3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 232
    :catch_1
    move-exception v0

    .line 233
    throw v0

    .line 234
    :catch_2
    move-exception v2

    .line 235
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    const-string v0, "acceptNdaAgreement failed: "

    .line 240
    .line 241
    invoke-static {v0, v1, v3, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 242
    .line 243
    .line 244
    :cond_a
    const/4 v0, 0x0

    .line 245
    :goto_4
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 246
    .line 247
    .line 248
    move-result-object v5

    .line 249
    return-object v5
.end method

.method public final acceptTosConsent(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p3

    .line 1
    .line 2
    instance-of v0, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;

    .line 3
    .line 4
    move-object/from16 v2, p0

    .line 5
    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    move-object v4, v5

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;

    .line 10
    .line 11
    iget v3, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v3, v1

    .line 16
    .line 17
    if-eqz v0, :cond_4

    .line 18
    .line 19
    sub-int/2addr v3, v1

    .line 20
    iput v3, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v1, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->label:I

    .line 27
    .line 28
    const/4 v8, 0x0

    .line 29
    const/4 v13, 0x1

    .line 30
    if-eqz v1, :cond_3

    .line 31
    .line 32
    if-ne v1, v13, :cond_5

    .line 33
    .line 34
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    check-cast v3, LX/2PJ;

    .line 38
    .line 39
    iget-object v1, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 40
    .line 41
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-nez v0, :cond_2

    .line 46
    .line 47
    check-cast v1, Lcom/facebook/aura/activation/repo/SuccessResponseJson;

    .line 48
    .line 49
    iget-boolean v0, v1, Lcom/facebook/aura/activation/repo/SuccessResponseJson;->success:Z

    .line 50
    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    invoke-direct {v2, v13}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateLocalHasAcceptedTos(Z)V

    .line 54
    .line 55
    .line 56
    :cond_1
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    return-object v0

    .line 61
    :cond_2
    const/4 v0, 0x0

    .line 62
    goto :goto_1

    .line 63
    :cond_3
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    sget-object v5, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 67
    .line 68
    sget-object v9, Lcom/facebook/aura/network/api/StefiHatchPath$AcceptTos;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$AcceptTos;

    .line 69
    .line 70
    new-instance v10, Lcom/facebook/aura/activation/repo/AcceptTosRequestJson;

    .line 71
    .line 72
    move-object/from16 v1, p2

    .line 73
    .line 74
    move-object/from16 v3, p1

    .line 75
    .line 76
    invoke-direct {v10, v3, v1}, Lcom/facebook/aura/activation/repo/AcceptTosRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    sget-object v11, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 80
    .line 81
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 82
    .line 83
    .line 84
    move-result-object v12

    .line 85
    sget-object p1, LX/0wX;->A00:LX/0wX;

    .line 86
    .line 87
    sget-object v6, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 88
    .line 89
    sget-object v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 90
    .line 91
    const/4 v14, 0x0

    .line 92
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$0:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$1:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$2:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$3:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$4:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$5:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$6:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v14, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->L$7:Ljava/lang/Object;

    .line 107
    .line 108
    iput v13, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->I$0:I

    .line 109
    .line 110
    iput v8, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->I$1:I

    .line 111
    .line 112
    iput v8, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->I$2:I

    .line 113
    .line 114
    iput v8, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->I$3:I

    .line 115
    .line 116
    iput v13, v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;->label:I

    .line 117
    .line 118
    move v15, v8

    .line 119
    move-object/from16 v16, v14

    .line 120
    .line 121
    move-object/from16 v17, v14

    .line 122
    .line 123
    move/from16 p0, v8

    .line 124
    .line 125
    move/from16 p2, v8

    .line 126
    .line 127
    move-object/from16 p3, v4

    .line 128
    .line 129
    invoke-virtual/range {v5 .. v21}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    if-ne v1, v0, :cond_0

    .line 134
    .line 135
    return-object v0

    .line 136
    :cond_4
    new-instance v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;

    .line 137
    .line 138
    invoke-direct {v4, v2, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$acceptTosConsent$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 139
    .line 140
    .line 141
    goto :goto_0

    .line 142
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 143
    .line 144
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 145
    .line 146
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw v0
.end method

.method public clearUserData()V
    .locals 0

    .line 0
    return-void
.end method

.method public final debugResetActivation(LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v3, p1

    .line 1
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p1, v3

    .line 6
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;

    .line 7
    .line 8
    iget v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v1, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->label:I

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v0, :cond_4

    .line 29
    .line 30
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    check-cast v2, LX/2PJ;

    .line 34
    .line 35
    iget-object v3, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 36
    .line 37
    :cond_0
    invoke-static {v3}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-nez v0, :cond_3

    .line 42
    .line 43
    check-cast v3, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;

    .line 44
    .line 45
    iget-boolean v2, v3, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 46
    .line 47
    iget v1, v3, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 48
    .line 49
    iget-boolean v0, v3, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 50
    .line 51
    new-instance v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 52
    .line 53
    invoke-direct {v4, v2, v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;-><init>(ZIZ)V

    .line 54
    .line 55
    .line 56
    return-object v4

    .line 57
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    sget-object v5, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 61
    .line 62
    sget-object v8, Lcom/facebook/aura/network/api/StefiHatchPath$DebugResetActivation;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$DebugResetActivation;

    .line 63
    .line 64
    sget-object v9, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 65
    .line 66
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 67
    .line 68
    .line 69
    move-result-object v12

    .line 70
    sget-object v6, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 71
    .line 72
    const/4 v7, 0x0

    .line 73
    const/4 v10, 0x0

    .line 74
    iput-object v10, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->L$0:Ljava/lang/Object;

    .line 75
    .line 76
    iput-object v10, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->L$1:Ljava/lang/Object;

    .line 77
    .line 78
    iput-object v10, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->L$2:Ljava/lang/Object;

    .line 79
    .line 80
    iput-object v10, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->L$3:Ljava/lang/Object;

    .line 81
    .line 82
    iput-object v10, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->L$4:Ljava/lang/Object;

    .line 83
    .line 84
    iput v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;->label:I

    .line 85
    .line 86
    move-object v11, v10

    .line 87
    move-object v13, v12

    .line 88
    move-object p0, v10

    .line 89
    invoke-virtual/range {v5 .. v15}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    if-ne v3, v4, :cond_0

    .line 94
    .line 95
    return-object v4

    .line 96
    :cond_2
    new-instance p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;

    .line 97
    .line 98
    invoke-direct {p1, p0, v3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetActivation$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 99
    .line 100
    .line 101
    goto :goto_0

    .line 102
    :cond_3
    const/4 v4, 0x0

    .line 103
    return-object v4

    .line 104
    :cond_4
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 105
    .line 106
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 107
    .line 108
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    throw v0
.end method

.method public final debugResetInviteCodeRedemptions(LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetInviteCodeRedemptionsResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v13, p1

    .line 5
    check-cast v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;

    .line 6
    .line 7
    iget v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    if-ne v1, v0, :cond_4

    .line 28
    .line 29
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    check-cast v3, LX/2PJ;

    .line 33
    .line 34
    iget-object v1, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 35
    .line 36
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-nez v0, :cond_3

    .line 41
    .line 42
    check-cast v1, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;

    .line 43
    .line 44
    iget v0, v1, Lcom/facebook/aura/activation/repo/DebugResetInviteCodeRedemptionResponseJson;->redemptions_deleted:I

    .line 45
    .line 46
    new-instance v2, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetInviteCodeRedemptionsResult;

    .line 47
    .line 48
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetInviteCodeRedemptionsResult;-><init>(I)V

    .line 49
    .line 50
    .line 51
    return-object v2

    .line 52
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 56
    .line 57
    sget-object v6, Lcom/facebook/aura/network/api/StefiHatchPath$DebugResetInviteCodeRedemption;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$DebugResetInviteCodeRedemption;

    .line 58
    .line 59
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 60
    .line 61
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 62
    .line 63
    .line 64
    move-result-object v10

    .line 65
    sget-object v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 66
    .line 67
    const/4 v5, 0x0

    .line 68
    const/4 v8, 0x0

    .line 69
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->L$0:Ljava/lang/Object;

    .line 70
    .line 71
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->L$1:Ljava/lang/Object;

    .line 72
    .line 73
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->L$2:Ljava/lang/Object;

    .line 74
    .line 75
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->L$3:Ljava/lang/Object;

    .line 76
    .line 77
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->L$4:Ljava/lang/Object;

    .line 78
    .line 79
    iput v0, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;->label:I

    .line 80
    .line 81
    move-object v9, v8

    .line 82
    move-object v11, v10

    .line 83
    move-object v12, v8

    .line 84
    invoke-virtual/range {v3 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    if-ne v1, v2, :cond_0

    .line 89
    .line 90
    return-object v2

    .line 91
    :cond_2
    new-instance v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;

    .line 92
    .line 93
    invoke-direct {v13, p0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugResetInviteCodeRedemptions$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 94
    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_3
    const/4 v2, 0x0

    .line 98
    return-object v2

    .line 99
    :cond_4
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 100
    .line 101
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 102
    .line 103
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    throw v0
.end method

.method public final debugSetWaitlistStatus(LX/7Kq;ZLX/2M4;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/7Kq;",
            "Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    const/4 v2, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v2, :cond_1

    .line 29
    .line 30
    iget-boolean p2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->Z$0:Z

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_0
    new-instance v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;

    .line 34
    .line 35
    invoke-direct {v5, p0, p3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v0

    .line 47
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    :try_start_0
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;

    .line 51
    .line 52
    invoke-direct {v1}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;-><init>()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-interface {v0}, LX/0Dj;->build()LX/0Dk;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    iput-object v3, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput-object v6, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    iput-boolean p2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->Z$0:Z

    .line 72
    .line 73
    iput v2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$1;->label:I

    .line 74
    .line 75
    invoke-static {v5}, LX/008;->A1I(LX/2M4;)LX/DSD;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    sget-object v4, Lcom/facebook/aura/graphql/AuraGraphQLService;->INSTANCE:Lcom/facebook/aura/graphql/AuraGraphQLService;

    .line 80
    .line 81
    iget-object v2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->userSession:LX/AHE;

    .line 82
    .line 83
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$1;

    .line 84
    .line 85
    invoke-direct {v1, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$1;-><init>(LX/DT0;)V

    .line 86
    .line 87
    .line 88
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$2;

    .line 89
    .line 90
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$2;-><init>(LX/DT0;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v4, v2, v6, v1, v0}, Lcom/facebook/aura/graphql/AuraGraphQLService;->execute(LX/AHE;LX/0Eb;LX/0HU;LX/IUt;)LX/ISN;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    if-ne v4, v7, :cond_3

    .line 101
    .line 102
    return-object v7

    .line 103
    :goto_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    :cond_3
    check-cast v4, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;

    .line 107
    .line 108
    invoke-virtual {v4}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;->getXabDebugSetHatchWaitlistStatus$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$XabDebugSetHatchWaitlistStatus;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    if-eqz v0, :cond_5

    .line 113
    .line 114
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$XabDebugSetHatchWaitlistStatus;->getStatus$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()LX/7Kq;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    :goto_2
    invoke-virtual {v4}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;->getXabDebugSetHatchWaitlistStatus$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$XabDebugSetHatchWaitlistStatus;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    if-eqz v0, :cond_4

    .line 123
    .line 124
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$XabDebugSetHatchWaitlistStatus;->getSuccess$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    :goto_3
    new-instance v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 129
    .line 130
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;-><init>(LX/7Kq;Z)V

    .line 131
    .line 132
    .line 133
    iget-boolean v0, v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 134
    .line 135
    goto :goto_4

    .line 136
    :cond_4
    const/4 v0, 0x0

    .line 137
    goto :goto_3

    .line 138
    :cond_5
    move-object v1, v3

    .line 139
    goto :goto_2

    .line 140
    :goto_4
    if-eqz v0, :cond_6

    .line 141
    .line 142
    if-eqz p2, :cond_6

    .line 143
    .line 144
    iget-object v0, v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 145
    .line 146
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateLocalWaitlistStatus(LX/7Kq;)V

    .line 147
    .line 148
    .line 149
    :cond_6
    return-object v7
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 150
    :catch_0
    move-exception v2

    .line 151
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    const-string v0, "AuraDebugSetHatchWaitlistStatusMutation failed: "

    .line 156
    .line 157
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    const-string v0, "AuraActivationRepository"

    .line 162
    .line 163
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 164
    .line 165
    .line 166
    return-object v3

    .line 167
    :catch_1
    move-exception v0

    .line 168
    throw v0
.end method

.method public final fetchInvitePage(LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/data/HatchInvitePage;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v13, p1

    .line 5
    check-cast v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;

    .line 6
    .line 7
    iget v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    if-ne v1, v0, :cond_4

    .line 28
    .line 29
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    check-cast v3, LX/2PJ;

    .line 33
    .line 34
    iget-object v1, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 35
    .line 36
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-nez v0, :cond_3

    .line 41
    .line 42
    check-cast v1, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;

    .line 43
    .line 44
    invoke-virtual {v1}, Lcom/facebook/aura/activation/repo/InvitePageResponseJson;->toDomain()Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    return-object v2

    .line 49
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 53
    .line 54
    sget-object v6, Lcom/facebook/aura/network/api/StefiHatchPath$Invite;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$Invite;

    .line 55
    .line 56
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 57
    .line 58
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 59
    .line 60
    .line 61
    move-result-object v10

    .line 62
    sget-object v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 63
    .line 64
    const/4 v5, 0x0

    .line 65
    const/4 v8, 0x0

    .line 66
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->L$0:Ljava/lang/Object;

    .line 67
    .line 68
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->L$1:Ljava/lang/Object;

    .line 69
    .line 70
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->L$2:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->L$3:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->L$4:Ljava/lang/Object;

    .line 75
    .line 76
    iput v0, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;->label:I

    .line 77
    .line 78
    move-object v9, v8

    .line 79
    move-object v11, v10

    .line 80
    move-object v12, v8

    .line 81
    invoke-virtual/range {v3 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    if-ne v1, v2, :cond_0

    .line 86
    .line 87
    return-object v2

    .line 88
    :cond_2
    new-instance v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;

    .line 89
    .line 90
    invoke-direct {v13, p0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchInvitePage$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 91
    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_3
    const/4 v2, 0x0

    .line 95
    return-object v2

    .line 96
    :cond_4
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 97
    .line 98
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 99
    .line 100
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw v0
.end method

.method public final fetchNdaAgreement(LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/data/HatchNdaAgreement;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v3, p1

    .line 1
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    move-object p1, v3

    .line 6
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;

    .line 7
    .line 8
    iget v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_3

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v1, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->label:I

    .line 24
    .line 25
    const/4 v9, 0x0

    .line 26
    const/4 v2, 0x1

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    if-ne v0, v2, :cond_5

    .line 30
    .line 31
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v1, LX/2PJ;

    .line 35
    .line 36
    iget-object v1, v1, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    if-nez v0, :cond_4

    .line 43
    .line 44
    check-cast v1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 45
    .line 46
    invoke-virtual {v1}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->toDomain()Lcom/facebook/aura/activation/data/HatchNdaAgreement;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    return-object v0

    .line 51
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-direct {p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->parseAgreementIds()LX/IBK;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    return-object v9

    .line 61
    :cond_2
    iget-object v1, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v1, Ljava/lang/String;

    .line 64
    .line 65
    iget-object v0, v0, LX/IBK;->second:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v0, Ljava/lang/String;

    .line 68
    .line 69
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 70
    .line 71
    new-instance v7, Lcom/facebook/aura/network/api/StefiHatchPath$OneClickAgreement;

    .line 72
    .line 73
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/network/api/StefiHatchPath$OneClickAgreement;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    sget-object v8, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 77
    .line 78
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 79
    .line 80
    .line 81
    move-result-object v11

    .line 82
    sget-object v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 83
    .line 84
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$0:Ljava/lang/Object;

    .line 85
    .line 86
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$1:Ljava/lang/Object;

    .line 87
    .line 88
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$2:Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$3:Ljava/lang/Object;

    .line 91
    .line 92
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$4:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$5:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v9, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->L$6:Ljava/lang/Object;

    .line 97
    .line 98
    iput v2, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;->label:I

    .line 99
    .line 100
    const/4 v6, 0x0

    .line 101
    move-object v10, v9

    .line 102
    move-object v12, v11

    .line 103
    move-object p0, v9

    .line 104
    invoke-virtual/range {v4 .. v14}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    if-ne v1, v3, :cond_0

    .line 109
    .line 110
    return-object v3

    .line 111
    :cond_3
    new-instance p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;

    .line 112
    .line 113
    invoke-direct {p1, p0, v3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchNdaAgreement$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 114
    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_4
    return-object v9

    .line 118
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 119
    .line 120
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 121
    .line 122
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    throw v0
.end method

.method public final fetchTosMetadata(LX/2M4;)Ljava/lang/Object;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;

    .line 3
    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    move-object v13, v3

    .line 7
    check-cast v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;

    .line 8
    .line 9
    iget v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v3, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v1, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->label:I

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    if-eqz v1, :cond_1

    .line 28
    .line 29
    if-ne v1, v0, :cond_d

    .line 30
    .line 31
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v3, LX/2PJ;

    .line 35
    .line 36
    iget-object v3, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    invoke-static {v3}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    const/16 p1, 0x0

    .line 43
    .line 44
    if-nez v0, :cond_c

    .line 45
    .line 46
    check-cast v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 47
    .line 48
    iget-boolean v6, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 49
    .line 50
    iget-object v7, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v8, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 55
    .line 56
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 57
    .line 58
    .line 59
    move-result-object v9

    .line 60
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_3

    .line 69
    .line 70
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 75
    .line 76
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosEntityJson;->toDomain()Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-virtual {v9, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 88
    .line 89
    sget-object v6, Lcom/facebook/aura/network/api/StefiHatchPath$TosStatus;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$TosStatus;

    .line 90
    .line 91
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 92
    .line 93
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 94
    .line 95
    .line 96
    move-result-object v10

    .line 97
    sget-object v4, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 98
    .line 99
    const/4 v5, 0x0

    .line 100
    const/4 v8, 0x0

    .line 101
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->L$0:Ljava/lang/Object;

    .line 102
    .line 103
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->L$1:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->L$2:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->L$3:Ljava/lang/Object;

    .line 108
    .line 109
    iput-object v8, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->L$4:Ljava/lang/Object;

    .line 110
    .line 111
    iput v0, v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;->label:I

    .line 112
    .line 113
    move-object v9, v8

    .line 114
    move-object v11, v10

    .line 115
    move-object v12, v8

    .line 116
    invoke-virtual/range {v3 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    if-ne v3, v2, :cond_0

    .line 121
    .line 122
    return-object v2

    .line 123
    :cond_2
    new-instance v13, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;

    .line 124
    .line 125
    invoke-direct {v13, p0, v3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$fetchTosMetadata$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 126
    .line 127
    .line 128
    goto :goto_0

    .line 129
    :cond_3
    iget-object v10, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 130
    .line 131
    iget-object v11, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 132
    .line 133
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 134
    .line 135
    new-instance v4, Ljava/util/ArrayList;

    .line 136
    .line 137
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 138
    .line 139
    .line 140
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    :cond_4
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_5

    .line 149
    .line 150
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    move-object v1, v2

    .line 155
    check-cast v1, Lcom/facebook/aura/activation/repo/TosSectionJson;

    .line 156
    .line 157
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/TosSectionJson;->title:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-nez v0, :cond_4

    .line 164
    .line 165
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/TosSectionJson;->description:Ljava/lang/String;

    .line 166
    .line 167
    invoke-static {v0, v2, v4}, LX/3Rs;->A15(Ljava/lang/CharSequence;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 168
    .line 169
    .line 170
    goto :goto_2

    .line 171
    :cond_5
    invoke-static {v4}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 172
    .line 173
    .line 174
    move-result-object v12

    .line 175
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 176
    .line 177
    .line 178
    move-result-object v5

    .line 179
    :goto_3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    if-eqz v0, :cond_6

    .line 184
    .line 185
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    check-cast v0, Lcom/facebook/aura/activation/repo/TosSectionJson;

    .line 190
    .line 191
    iget-object v4, v0, Lcom/facebook/aura/activation/repo/TosSectionJson;->title:Ljava/lang/String;

    .line 192
    .line 193
    iget-object v2, v0, Lcom/facebook/aura/activation/repo/TosSectionJson;->description:Ljava/lang/String;

    .line 194
    .line 195
    iget-object v1, v0, Lcom/facebook/aura/activation/repo/TosSectionJson;->icon:Ljava/lang/String;

    .line 196
    .line 197
    new-instance v0, Lcom/facebook/aura/activation/data/HatchDisclosureSection;

    .line 198
    .line 199
    invoke-direct {v0, v4, v2, v1}, Lcom/facebook/aura/activation/data/HatchDisclosureSection;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v12, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    goto :goto_3

    .line 206
    :cond_6
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 207
    .line 208
    if-eqz v0, :cond_8

    .line 209
    .line 210
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosUpsellCellJson;->toDomain()Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 211
    .line 212
    .line 213
    move-result-object v13

    .line 214
    :goto_4
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 215
    .line 216
    if-eqz v0, :cond_7

    .line 217
    .line 218
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosUpsellCellJson;->toDomain()Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 219
    .line 220
    .line 221
    move-result-object v14

    .line 222
    :goto_5
    iget-object v2, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 223
    .line 224
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    if-nez v0, :cond_9

    .line 229
    .line 230
    if-eqz v2, :cond_9

    .line 231
    .line 232
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 233
    .line 234
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 235
    .line 236
    .line 237
    move-result-object v1

    .line 238
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 239
    .line 240
    .line 241
    move-result-object v4

    .line 242
    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    if-eqz v0, :cond_a

    .line 247
    .line 248
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    check-cast v0, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 253
    .line 254
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosEntityJson;->toDomain()Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 255
    .line 256
    .line 257
    move-result-object v0

    .line 258
    invoke-virtual {v1, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    goto :goto_6

    .line 262
    :cond_7
    move-object/from16 v14, p1

    .line 263
    .line 264
    goto :goto_5

    .line 265
    :cond_8
    move-object/from16 v13, p1

    .line 266
    .line 267
    goto :goto_4

    .line 268
    :cond_9
    move-object/from16 p0, p1

    .line 269
    .line 270
    goto :goto_7

    .line 271
    :cond_a
    new-instance p0, Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 272
    .line 273
    invoke-direct {p0, v2, v1}, Lcom/facebook/aura/activation/data/HatchDisclosureText;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 274
    .line 275
    .line 276
    :goto_7
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 277
    .line 278
    if-eqz v0, :cond_b

    .line 279
    .line 280
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->toDomain()Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 281
    .line 282
    .line 283
    move-result-object p1

    .line 284
    :cond_b
    new-instance v5, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 285
    .line 286
    invoke-direct/range {v5 .. v16}, Lcom/facebook/aura/activation/data/HatchTosMetadata;-><init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;)V

    .line 287
    .line 288
    .line 289
    return-object v5

    .line 290
    :cond_c
    return-object p1

    .line 291
    :cond_d
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 292
    .line 293
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 294
    .line 295
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 296
    .line 297
    .line 298
    throw v0
.end method

.method public final generateInviteCode(LX/2M4;)Ljava/lang/Object;
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;

    .line 3
    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    move-object v11, v3

    .line 7
    check-cast v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;

    .line 8
    .line 9
    iget v2, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v2, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v12, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v1, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->label:I

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    if-eqz v1, :cond_1

    .line 28
    .line 29
    if-ne v1, v0, :cond_6

    .line 30
    .line 31
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v2, LX/2PJ;

    .line 35
    .line 36
    iget-object v0, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    if-nez v2, :cond_3

    .line 43
    .line 44
    check-cast v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;

    .line 45
    .line 46
    iget-object v13, v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->code:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v14, v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->max_uses:Ljava/lang/Integer;

    .line 49
    .line 50
    iget-object v15, v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->use_count:Ljava/lang/Integer;

    .line 51
    .line 52
    iget-object v1, v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->invite_link:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v0, v0, Lcom/facebook/aura/activation/repo/GenerateInviteCodeResponseJson;->share_text:Ljava/lang/String;

    .line 55
    .line 56
    const/16 p1, 0x0

    .line 57
    .line 58
    new-instance v12, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;

    .line 59
    .line 60
    move-object/from16 v16, v1

    .line 61
    .line 62
    move-object/from16 p0, v0

    .line 63
    .line 64
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-object v12

    .line 68
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    sget-object v1, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 72
    .line 73
    sget-object v4, Lcom/facebook/aura/network/api/StefiHatchPath$InviteCodeGenerate;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$InviteCodeGenerate;

    .line 74
    .line 75
    sget-object v5, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 76
    .line 77
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 78
    .line 79
    .line 80
    move-result-object v8

    .line 81
    sget-object v2, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 82
    .line 83
    const/4 v3, 0x0

    .line 84
    const/4 v6, 0x0

    .line 85
    iput-object v6, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->L$0:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v6, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->L$1:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v6, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->L$2:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v6, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->L$3:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v6, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->L$4:Ljava/lang/Object;

    .line 94
    .line 95
    iput v0, v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;->label:I

    .line 96
    .line 97
    move-object v7, v6

    .line 98
    move-object v9, v8

    .line 99
    move-object v10, v6

    .line 100
    invoke-virtual/range {v1 .. v11}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    if-ne v0, v12, :cond_0

    .line 105
    .line 106
    return-object v12

    .line 107
    :cond_2
    new-instance v11, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;

    .line 108
    .line 109
    move-object/from16 v0, p0

    .line 110
    .line 111
    invoke-direct {v11, v0, v3}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$generateInviteCode$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 112
    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_3
    instance-of v0, v2, Lcom/facebook/aura/json/NetworkException;

    .line 116
    .line 117
    const/4 v13, 0x0

    .line 118
    if-eqz v0, :cond_4

    .line 119
    .line 120
    check-cast v2, Lcom/facebook/aura/json/NetworkException;

    .line 121
    .line 122
    if-eqz v2, :cond_4

    .line 123
    .line 124
    iget v1, v2, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 125
    .line 126
    const/16 v0, 0xc8

    .line 127
    .line 128
    if-gt v0, v1, :cond_5

    .line 129
    .line 130
    const/16 v0, 0x12c

    .line 131
    .line 132
    if-ge v1, v0, :cond_5

    .line 133
    .line 134
    :cond_4
    return-object v13

    .line 135
    :cond_5
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    new-instance v12, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;

    .line 140
    .line 141
    move-object v14, v13

    .line 142
    move-object v15, v13

    .line 143
    move-object/from16 v16, v13

    .line 144
    .line 145
    move-object/from16 p0, v13

    .line 146
    .line 147
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    return-object v12

    .line 151
    :cond_6
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 152
    .line 153
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 154
    .line 155
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    throw v0
.end method

.method public final joinWaitlist(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p2

    .line 1
    .line 2
    instance-of v0, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;

    .line 3
    .line 4
    move-object/from16 v2, p0

    .line 5
    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    move-object v1, v5

    .line 9
    check-cast v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;

    .line 10
    .line 11
    iget v4, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->label:I

    .line 12
    .line 13
    const/high16 v3, -0x80000000

    .line 14
    .line 15
    and-int v0, v4, v3

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    sub-int/2addr v4, v3

    .line 20
    iput v4, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v4, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->label:I

    .line 27
    .line 28
    const/4 v13, 0x1

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    if-ne v0, v13, :cond_4

    .line 32
    .line 33
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    check-cast v4, LX/2PJ;

    .line 37
    .line 38
    iget-object v1, v4, LX/2PJ;->value:Ljava/lang/Object;

    .line 39
    .line 40
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-nez v0, :cond_3

    .line 45
    .line 46
    check-cast v1, Lcom/facebook/aura/activation/repo/JoinWaitlistResponseJson;

    .line 47
    .line 48
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/JoinWaitlistResponseJson;->status:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepositoryJsonKt;->toWaitlistStatusOrNull(Ljava/lang/String;)LX/7Kq;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/JoinWaitlistResponseJson;->eligibility_error:Ljava/lang/String;

    .line 55
    .line 56
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;

    .line 57
    .line 58
    invoke-direct {v1, v3, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;-><init>(LX/7Kq;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$JoinWaitlistResult;->status:LX/7Kq;

    .line 62
    .line 63
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateLocalWaitlistStatus(LX/7Kq;)V

    .line 64
    .line 65
    .line 66
    return-object v1

    .line 67
    :cond_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    sget-object v5, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 71
    .line 72
    sget-object v9, Lcom/facebook/aura/network/api/StefiHatchPath$WaitlistJoin;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$WaitlistJoin;

    .line 73
    .line 74
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 75
    .line 76
    move-object/from16 v4, p1

    .line 77
    .line 78
    invoke-virtual {v4, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    new-instance v10, Lcom/facebook/aura/activation/repo/JoinWaitlistRequestJson;

    .line 83
    .line 84
    invoke-direct {v10, v0}, Lcom/facebook/aura/activation/repo/JoinWaitlistRequestJson;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    sget-object v11, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 88
    .line 89
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 90
    .line 91
    .line 92
    move-result-object v12

    .line 93
    sget-object p0, LX/0wX;->A00:LX/0wX;

    .line 94
    .line 95
    sget-object v6, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 96
    .line 97
    sget-object v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 98
    .line 99
    const/4 v8, 0x0

    .line 100
    const/4 v14, 0x0

    .line 101
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$0:Ljava/lang/Object;

    .line 102
    .line 103
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$1:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$2:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$3:Ljava/lang/Object;

    .line 108
    .line 109
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$4:Ljava/lang/Object;

    .line 110
    .line 111
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$5:Ljava/lang/Object;

    .line 112
    .line 113
    iput-object v14, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->L$6:Ljava/lang/Object;

    .line 114
    .line 115
    iput v13, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->I$0:I

    .line 116
    .line 117
    iput v8, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->I$1:I

    .line 118
    .line 119
    iput v8, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->I$2:I

    .line 120
    .line 121
    iput v8, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->I$3:I

    .line 122
    .line 123
    iput v13, v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;->label:I

    .line 124
    .line 125
    move v15, v8

    .line 126
    move-object/from16 v16, v14

    .line 127
    .line 128
    move-object/from16 v17, v14

    .line 129
    .line 130
    move/from16 v18, v8

    .line 131
    .line 132
    move/from16 p1, v8

    .line 133
    .line 134
    move-object/from16 p2, v1

    .line 135
    .line 136
    invoke-virtual/range {v5 .. v21}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    if-ne v1, v3, :cond_0

    .line 141
    .line 142
    return-object v3

    .line 143
    :cond_2
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;

    .line 144
    .line 145
    invoke-direct {v1, v2, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$joinWaitlist$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 146
    .line 147
    .line 148
    goto :goto_0

    .line 149
    :cond_3
    const/4 v3, 0x0

    .line 150
    return-object v3

    .line 151
    :cond_4
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 152
    .line 153
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 154
    .line 155
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    throw v0
.end method

.method public final redeemInviteCode(Ljava/lang/String;ZZLX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "ZZ",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move/from16 v3, p2

    .line 1
    .line 2
    move/from16 v2, p3

    .line 3
    .line 4
    move-object/from16 v7, p4

    .line 5
    .line 6
    instance-of v0, v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;

    .line 7
    .line 8
    move-object/from16 v4, p0

    .line 9
    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    move-object v0, v7

    .line 13
    check-cast v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;

    .line 14
    .line 15
    iget v6, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->label:I

    .line 16
    .line 17
    const/high16 v5, -0x80000000

    .line 18
    .line 19
    and-int v1, v6, v5

    .line 20
    .line 21
    if-eqz v1, :cond_3

    .line 22
    .line 23
    sub-int/2addr v6, v5

    .line 24
    iput v6, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v6, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v5, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->label:I

    .line 31
    .line 32
    const/4 v9, 0x0

    .line 33
    const/4 v14, 0x1

    .line 34
    if-eqz v5, :cond_2

    .line 35
    .line 36
    if-ne v5, v14, :cond_8

    .line 37
    .line 38
    iget-boolean v2, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->Z$1:Z

    .line 39
    .line 40
    iget-boolean v3, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->Z$0:Z

    .line 41
    .line 42
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    check-cast v6, LX/2PJ;

    .line 46
    .line 47
    iget-object v0, v6, LX/2PJ;->value:Ljava/lang/Object;

    .line 48
    .line 49
    :cond_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 50
    .line 51
    .line 52
    move-result-object v6

    .line 53
    const/4 v5, 0x0

    .line 54
    if-nez v6, :cond_4

    .line 55
    .line 56
    check-cast v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeResponseJson;

    .line 57
    .line 58
    iget-object v0, v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeResponseJson;->waitlist_status:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepositoryJsonKt;->toWaitlistStatusOrNull(Ljava/lang/String;)LX/7Kq;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;

    .line 65
    .line 66
    invoke-direct {v1, v14, v0, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;-><init>(ZLX/7Kq;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    if-eqz v3, :cond_1

    .line 70
    .line 71
    invoke-direct {v4, v1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateHasRedeemedInviteCode(Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;)V

    .line 72
    .line 73
    .line 74
    :cond_1
    return-object v1

    .line 75
    :cond_2
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    sget-object v6, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 79
    .line 80
    sget-object v10, Lcom/facebook/aura/network/api/StefiHatchPath$InviteCodeRedeem;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$InviteCodeRedeem;

    .line 81
    .line 82
    new-instance v11, Lcom/facebook/aura/activation/repo/RedeemInviteCodeRequestJson;

    .line 83
    .line 84
    move-object/from16 v5, p1

    .line 85
    .line 86
    invoke-direct {v11, v5}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeRequestJson;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    sget-object v12, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 90
    .line 91
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 92
    .line 93
    .line 94
    move-result-object v13

    .line 95
    sget-object p2, LX/0wX;->A00:LX/0wX;

    .line 96
    .line 97
    sget-object v7, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 98
    .line 99
    sget-object v8, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 100
    .line 101
    const/4 v15, 0x0

    .line 102
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$0:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$1:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$2:Ljava/lang/Object;

    .line 107
    .line 108
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$3:Ljava/lang/Object;

    .line 109
    .line 110
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$4:Ljava/lang/Object;

    .line 111
    .line 112
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$5:Ljava/lang/Object;

    .line 113
    .line 114
    iput-object v15, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->L$6:Ljava/lang/Object;

    .line 115
    .line 116
    iput-boolean v3, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->Z$0:Z

    .line 117
    .line 118
    iput-boolean v2, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->Z$1:Z

    .line 119
    .line 120
    iput v14, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->I$0:I

    .line 121
    .line 122
    iput v9, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->I$1:I

    .line 123
    .line 124
    iput v9, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->I$2:I

    .line 125
    .line 126
    iput v9, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->I$3:I

    .line 127
    .line 128
    iput v14, v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;->label:I

    .line 129
    .line 130
    move/from16 v16, v9

    .line 131
    .line 132
    move-object/from16 v17, v15

    .line 133
    .line 134
    move-object/from16 p0, v15

    .line 135
    .line 136
    move/from16 p1, v9

    .line 137
    .line 138
    move/from16 p3, v9

    .line 139
    .line 140
    move-object/from16 p4, v0

    .line 141
    .line 142
    invoke-virtual/range {v6 .. v22}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    if-ne v0, v1, :cond_0

    .line 147
    .line 148
    return-object v1

    .line 149
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;

    .line 150
    .line 151
    invoke-direct {v0, v4, v7}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$redeemInviteCode$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 152
    .line 153
    .line 154
    goto :goto_0

    .line 155
    :cond_4
    instance-of v0, v6, Lcom/facebook/aura/json/NetworkException;

    .line 156
    .line 157
    if-eqz v0, :cond_5

    .line 158
    .line 159
    check-cast v6, Lcom/facebook/aura/json/NetworkException;

    .line 160
    .line 161
    if-eqz v6, :cond_5

    .line 162
    .line 163
    iget v1, v6, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 164
    .line 165
    const/16 v0, 0xc8

    .line 166
    .line 167
    if-gt v0, v1, :cond_6

    .line 168
    .line 169
    const/16 v0, 0x12c

    .line 170
    .line 171
    if-ge v1, v0, :cond_6

    .line 172
    .line 173
    :cond_5
    return-object v5

    .line 174
    :cond_6
    if-eqz v2, :cond_7

    .line 175
    .line 176
    iget-object v0, v6, Lcom/facebook/aura/json/NetworkException;->serverRetryable:Ljava/lang/Boolean;

    .line 177
    .line 178
    invoke-static {v0, v14}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-nez v0, :cond_5

    .line 183
    .line 184
    :cond_7
    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    new-instance v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;

    .line 189
    .line 190
    invoke-direct {v1, v9, v5, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;-><init>(ZLX/7Kq;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    return-object v1

    .line 194
    :cond_8
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 195
    .line 196
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 197
    .line 198
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    throw v0
.end method

.method public final refreshTosStatus(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_0
    new-instance v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;

    .line 32
    .line 33
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 38
    .line 39
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_0
    iput v0, v5, Lcom/facebook/aura/activation/repo/AuraActivationRepository$refreshTosStatus$1;->label:I

    .line 49
    .line 50
    invoke-virtual {p0, v5}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->fetchTosMetadata(LX/2M4;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    if-ne v4, v2, :cond_3

    .line 55
    .line 56
    return-object v2

    .line 57
    :goto_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_3
    check-cast v4, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 61
    .line 62
    if-eqz v4, :cond_4

    .line 63
    .line 64
    iget-boolean v0, v4, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 65
    .line 66
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->updateLocalHasAcceptedTos(Z)V

    .line 67
    .line 68
    .line 69
    iget-boolean v0, v4, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 70
    .line 71
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    :cond_4
    return-object v3
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 76
    :catch_0
    move-exception v2

    .line 77
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    const-string v0, "refreshTosStatus failed: "

    .line 82
    .line 83
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    const-string v0, "AuraActivationRepository"

    .line 88
    .line 89
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 90
    .line 91
    .line 92
    return-object v3

    .line 93
    :catch_1
    move-exception v0

    .line 94
    throw v0
.end method
