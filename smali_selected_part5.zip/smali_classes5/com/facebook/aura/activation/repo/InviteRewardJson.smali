.class public final Lcom/facebook/aura/activation/repo/InviteRewardJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/InviteRewardJson$Companion;


# instance fields
.field public final body:Ljava/lang/String;

.field public final title:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteRewardJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->Companion:Lcom/facebook/aura/activation/repo/InviteRewardJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 805306368
    const-string v0, ""

    .line 805306369
    .line 805306370
    invoke-direct {p0, v0, v0}, Lcom/facebook/aura/activation/repo/InviteRewardJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 805306371
    .line 805306372
    .line 805306373
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const-string v1, ""

    .line 536870918
    .line 536870919
    if-nez v0, :cond_0

    .line 536870920
    .line 536870921
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 536870922
    .line 536870923
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870924
    .line 536870925
    if-nez v0, :cond_1

    .line 536870926
    .line 536870927
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 536870928
    .line 536870929
    return-void

    .line 536870930
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 536870931
    .line 536870932
    goto :goto_0

    .line 536870933
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 536870934
    .line 536870935
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p3, 0x1

    .line 268435457
    .line 268435458
    const-string v1, ""

    .line 268435459
    .line 268435460
    if-eqz v0, :cond_0

    .line 268435461
    .line 268435462
    move-object p1, v1

    .line 268435463
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 268435464
    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/repo/InviteRewardJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/InviteRewardJson;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/InviteRewardJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 16
    .line 17
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/repo/InviteRewardJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/InviteRewardJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    const-string v2, ""

    .line 6
    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x1

    .line 23
    if-nez v3, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/InviteRewardJson;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/repo/InviteRewardJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/InviteRewardJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getBody()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteRewardJson;->body:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    add-int/2addr v1, v0

    .line 15
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
