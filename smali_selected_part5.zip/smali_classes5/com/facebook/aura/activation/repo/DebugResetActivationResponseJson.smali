.class public final Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson$Companion;


# instance fields
.field public final ccv_orders_deleted:I

.field public final consent_revoked:Z

.field public final redemptions_deleted:I

.field public final waitlist_reset:Z

.field public final wearables_link_reset:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->Companion:Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v0, p0

    .line 2
    move v2, v1

    .line 3
    move v3, v1

    .line 4
    move v4, v1

    .line 5
    move p0, v1

    .line 6
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;-><init>(ZIZIZ)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(IZIZIZLX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const/4 v1, 0x0

    .line 268435462
    if-nez v0, :cond_3

    .line 268435463
    .line 268435464
    iput-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 268435465
    .line 268435466
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    if-nez v0, :cond_2

    .line 268435469
    .line 268435470
    iput v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 268435471
    .line 268435472
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435473
    .line 268435474
    if-nez v0, :cond_1

    .line 268435475
    .line 268435476
    iput-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 268435477
    .line 268435478
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 268435479
    .line 268435480
    if-nez v0, :cond_0

    .line 268435481
    .line 268435482
    iput v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 268435483
    .line 268435484
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 268435485
    .line 268435486
    if-nez v0, :cond_4

    .line 268435487
    .line 268435488
    iput-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 268435489
    .line 268435490
    return-void

    .line 268435491
    :cond_0
    iput p5, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 268435492
    .line 268435493
    goto :goto_3

    .line 268435494
    :cond_1
    iput-boolean p4, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 268435495
    .line 268435496
    goto :goto_2

    .line 268435497
    :cond_2
    iput p3, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 268435498
    .line 268435499
    goto :goto_1

    .line 268435500
    :cond_3
    iput-boolean p2, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 268435501
    .line 268435502
    goto :goto_0

    .line 268435503
    :cond_4
    iput-boolean p6, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 268435504
    .line 268435505
    return-void
.end method

.method public constructor <init>(ZIZIZ)V
    .locals 0

    .line 805306368
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 805306369
    .line 805306370
    .line 805306371
    iput-boolean p1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 805306372
    .line 805306373
    iput p2, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 805306374
    .line 805306375
    iput-boolean p3, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 805306376
    .line 805306377
    iput p4, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 805306378
    .line 805306379
    iput-boolean p5, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 805306380
    .line 805306381
    return-void
.end method

.method public synthetic constructor <init>(ZIZIZILX/04f;)V
    .locals 1

    .line 536870912
    and-int/lit8 v0, p6, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    const/4 p1, 0x0

    .line 536870917
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 536870918
    .line 536870919
    if-eqz v0, :cond_1

    .line 536870920
    .line 536870921
    const/4 p2, 0x0

    .line 536870922
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 536870923
    .line 536870924
    if-eqz v0, :cond_2

    .line 536870925
    .line 536870926
    const/4 p3, 0x0

    .line 536870927
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 536870928
    .line 536870929
    if-eqz v0, :cond_3

    .line 536870930
    .line 536870931
    const/4 p4, 0x0

    .line 536870932
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 536870933
    .line 536870934
    if-eqz v0, :cond_4

    .line 536870935
    .line 536870936
    const/4 p5, 0x0

    .line 536870937
    :cond_4
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;-><init>(ZIZIZ)V

    .line 536870938
    .line 536870939
    .line 536870940
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;ZIZIZILjava/lang/Object;)Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget p2, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->copy(ZIZIZ)Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;LX/Da8;LX/Da5;)V
    .locals 3

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    if-nez v2, :cond_0

    .line 6
    .line 7
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 12
    .line 13
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 14
    .line 15
    .line 16
    :cond_1
    const/4 v1, 0x1

    .line 17
    if-nez v2, :cond_2

    .line 18
    .line 19
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 20
    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    :cond_2
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 24
    .line 25
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 26
    .line 27
    .line 28
    :cond_3
    const/4 v1, 0x2

    .line 29
    if-nez v2, :cond_4

    .line 30
    .line 31
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 32
    .line 33
    if-eqz v0, :cond_5

    .line 34
    .line 35
    :cond_4
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 36
    .line 37
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 38
    .line 39
    .line 40
    :cond_5
    const/4 v1, 0x3

    .line 41
    if-nez v2, :cond_6

    .line 42
    .line 43
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 44
    .line 45
    if-eqz v0, :cond_7

    .line 46
    .line 47
    :cond_6
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 48
    .line 49
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 50
    .line 51
    .line 52
    :cond_7
    const/4 v1, 0x4

    .line 53
    if-nez v2, :cond_8

    .line 54
    .line 55
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 56
    .line 57
    if-eqz v0, :cond_9

    .line 58
    .line 59
    :cond_8
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 60
    .line 61
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 62
    .line 63
    .line 64
    :cond_9
    return-void
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component2()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(ZIZIZ)Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;-><init>(ZIZIZ)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 17
    .line 18
    iget v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 23
    .line 24
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 25
    .line 26
    if-ne v1, v0, :cond_0

    .line 27
    .line 28
    iget v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 29
    .line 30
    iget v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 31
    .line 32
    if-ne v1, v0, :cond_0

    .line 33
    .line 34
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 35
    .line 36
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 37
    .line 38
    if-eq v1, v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getCcv_orders_deleted()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final getConsent_revoked()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getRedemptions_deleted()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 1
    .line 2
    return p0
.end method

.method public final getWaitlist_reset()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getWearables_link_reset()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->waitlist_reset:Z

    .line 1
    .line 2
    const/16 v0, 0x4d5

    .line 3
    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    const/16 v0, 0x4cf

    .line 7
    .line 8
    :cond_0
    mul-int/lit8 v1, v0, 0x1f

    .line 9
    .line 10
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->redemptions_deleted:I

    .line 11
    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->consent_revoked:Z

    .line 16
    .line 17
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    iget v0, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->ccv_orders_deleted:I

    .line 22
    .line 23
    add-int/2addr v1, v0

    .line 24
    mul-int/lit8 v2, v1, 0x1f

    .line 25
    .line 26
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/DebugResetActivationResponseJson;->wearables_link_reset:Z

    .line 27
    .line 28
    const/16 v0, 0x4d5

    .line 29
    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    const/16 v0, 0x4cf

    .line 33
    .line 34
    :cond_1
    add-int/2addr v2, v0

    .line 35
    return v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
