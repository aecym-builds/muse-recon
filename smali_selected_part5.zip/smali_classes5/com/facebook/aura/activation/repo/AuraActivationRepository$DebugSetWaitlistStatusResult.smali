.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;
.super LX/07H;
.source ""


# instance fields
.field public final status:LX/7Kq;

.field public final success:Z


# direct methods
.method public constructor <init>(LX/7Kq;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 6
    .line 7
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;LX/7Kq;ZILjava/lang/Object;)Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 11
    .line 12
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 13
    .line 14
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;-><init>(LX/7Kq;Z)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method


# virtual methods
.method public final component1()LX/7Kq;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(LX/7Kq;Z)Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;-><init>(LX/7Kq;Z)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 17
    .line 18
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 19
    .line 20
    if-eq v1, v0, :cond_1

    .line 21
    .line 22
    :cond_0
    return v2

    .line 23
    :cond_1
    return v3
.end method

.method public final getStatus()LX/7Kq;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSuccess()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->status:LX/7Kq;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v2, v0, 0x1f

    .line 7
    .line 8
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 9
    .line 10
    const/16 v0, 0x4d5

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    const/16 v0, 0x4cf

    .line 15
    .line 16
    :cond_0
    add-int/2addr v2, v0

    .line 17
    return v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
