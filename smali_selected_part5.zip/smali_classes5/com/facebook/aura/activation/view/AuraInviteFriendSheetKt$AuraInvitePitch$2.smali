.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$changed1:I

.field public final synthetic $$default:I

.field public final synthetic $giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

.field public final synthetic $hasLoadedSinceOpen:Z

.field public final synthetic $inviteCode:Ljava/lang/String;

.field public final synthetic $isInviteCodeRevealed:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onCopyCode:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onInviteCodeRevealed:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

.field public final synthetic $showsGift:Z

.field public final synthetic $subtitle:Ljava/lang/String;

.field public final synthetic $subtitleLinkText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;III)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;",
            "Z",
            "Lcom/facebook/aura/activation/data/HatchInviteReward;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "III)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$subtitle:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$subtitleLinkText:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$inviteCode:Ljava/lang/String;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$isInviteCodeRevealed:Z

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$showsGift:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$hasLoadedSinceOpen:Z

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onCopyCode:LX/JDM;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onInviteCodeRevealed:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    iput-object p11, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 21
    .line 22
    iput-object p12, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$modifier:LX/3C1;

    .line 23
    .line 24
    iput p13, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$changed:I

    .line 25
    .line 26
    iput p14, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$changed1:I

    .line 27
    .line 28
    move/from16 v0, p15

    .line 29
    .line 30
    iput v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$default:I

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 34
    .line 35
    .line 36
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/lang/Number;

    .line 268435459
    .line 268435460
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->invoke(LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 16

    .line 0
    move-object/from16 v1, p0

    .line 1
    .line 2
    iget-object v2, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$subtitle:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$subtitleLinkText:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v4, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$inviteCode:Ljava/lang/String;

    .line 7
    .line 8
    iget-boolean v5, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$isInviteCodeRevealed:Z

    .line 9
    .line 10
    iget-boolean v6, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$showsGift:Z

    .line 11
    .line 12
    iget-object v7, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 13
    .line 14
    iget-boolean v8, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$hasLoadedSinceOpen:Z

    .line 15
    .line 16
    iget-object v9, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 17
    .line 18
    iget-object v10, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onCopyCode:LX/JDM;

    .line 19
    .line 20
    iget-object v11, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onInviteCodeRevealed:Lkotlin/jvm/functions/Function0;

    .line 21
    .line 22
    iget-object v12, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 23
    .line 24
    iget-object v13, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$modifier:LX/3C1;

    .line 25
    .line 26
    iget v0, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$changed:I

    .line 27
    .line 28
    or-int/lit8 v0, v0, 0x1

    .line 29
    .line 30
    invoke-static {v0}, LX/0z0;->A01(I)I

    .line 31
    .line 32
    .line 33
    move-result v15

    .line 34
    iget v0, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$changed1:I

    .line 35
    .line 36
    invoke-static {v0}, LX/0z0;->A01(I)I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    iget v0, v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;->$$default:I

    .line 41
    .line 42
    move-object/from16 v14, p1

    .line 43
    .line 44
    move/from16 p1, v0

    .line 45
    .line 46
    invoke-static/range {v2 .. v17}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInvitePitch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 47
    .line 48
    .line 49
    return-void
.end method
