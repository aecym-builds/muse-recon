.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/sharesheet/HatchShareLogContext;Landroid/content/Context;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;->invoke(Ljava/lang/String;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/sharesheet/HatchShareLogging;->INSTANCE:Lcom/facebook/aura/sharesheet/HatchShareLogging;

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/sharesheet/HatchShareDestination;->COPY_LINK:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 9
    .line 10
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/sharesheet/HatchShareLogging;->logDestination(Lcom/facebook/aura/sharesheet/HatchShareDestination;Lcom/facebook/aura/sharesheet/HatchShareLogContext;)V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;->$context:Landroid/content/Context;

    .line 14
    .line 15
    const-string v1, "invite_message"

    .line 16
    .line 17
    const v0, 0x7f1204b9

    .line 18
    .line 19
    .line 20
    invoke-static {v2, v1, p1, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->copyToClipboard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method
