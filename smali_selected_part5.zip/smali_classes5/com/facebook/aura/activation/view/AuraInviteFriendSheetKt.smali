.class public abstract Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CODE_CLIP_LABEL:Ljava/lang/String; = "invite_code"

.field public static final INVITE_CLIP_LABEL:Ljava/lang/String; = "invite_message"

.field public static final INVITE_GIFT_RENDER_TIMEOUT_MS:J = 0x1388L

.field public static final INVITE_GIFT_SURFACE_TAG:Ljava/lang/String; = "invite_gift"

.field public static final INVITE_SHARE_TAG:Ljava/lang/String; = "HatchInviteShare"

.field public static final SUBTITLE_LINK_TAG:Ljava/lang/String; = "invite_subtitle_link"


# direct methods
.method public static final AuraInviteEarnedUsageCard(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 54

    .line 0
    move-object/from16 v5, p2

    .line 1
    .line 2
    const v1, -0x7d4c1131

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p3

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v1, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v13, p0

    .line 15
    .line 16
    if-nez v1, :cond_9

    .line 17
    .line 18
    invoke-static {v0, v13}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    or-int v6, v6, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v3, p4, 0x30

    .line 25
    .line 26
    const/16 v1, 0x20

    .line 27
    .line 28
    move-object/from16 v9, p1

    .line 29
    .line 30
    if-nez v3, :cond_0

    .line 31
    .line 32
    invoke-static {v0, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    or-int/2addr v6, v3

    .line 37
    :cond_0
    and-int/lit8 v7, p5, 0x4

    .line 38
    .line 39
    if-eqz v7, :cond_8

    .line 40
    .line 41
    or-int/lit16 v6, v6, 0x180

    .line 42
    .line 43
    :cond_1
    :goto_1
    invoke-static {v6}, LX/005;->A1I(I)Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    and-int/lit8 v3, v6, 0x1

    .line 48
    .line 49
    invoke-interface {v0, v3, v4}, LX/2d4;->Afw(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_7

    .line 54
    .line 55
    if-eqz v7, :cond_2

    .line 56
    .line 57
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 60
    .line 61
    const/4 v7, 0x6

    .line 62
    invoke-virtual {v10, v0, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getShapes(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    iget-object v8, v3, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->card:LX/2bW;

    .line 67
    .line 68
    sget-object v3, LX/2sI;->A02:LX/2wD;

    .line 69
    .line 70
    invoke-interface {v5, v3}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 71
    .line 72
    .line 73
    move-result-object v12

    .line 74
    const/high16 v11, 0x3f800000    # 1.0f

    .line 75
    .line 76
    invoke-virtual {v10, v0, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevatedBorder:J

    .line 81
    .line 82
    invoke-static {v12, v8, v11, v3, v4}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v36

    .line 86
    sget-object v15, Lcom/facebook/aura/vds/compose/card/AuraCardStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/card/AuraCardStyles;

    .line 87
    .line 88
    sget-object v16, LX/2Id;->A04:LX/2rU;

    .line 89
    .line 90
    invoke-virtual {v10, v0, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->card:J

    .line 95
    .line 96
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 97
    .line 98
    new-instance v7, LX/1Ot;

    .line 99
    .line 100
    invoke-direct {v7, v10}, LX/1Ot;-><init>(F)V

    .line 101
    .line 102
    .line 103
    const/16 v21, 0xc06

    .line 104
    .line 105
    const/16 v46, 0x0

    .line 106
    .line 107
    const/4 v14, 0x0

    .line 108
    const/4 v10, 0x1

    .line 109
    move/from16 v22, v46

    .line 110
    .line 111
    move-wide/from16 v17, v3

    .line 112
    .line 113
    move-object/from16 v19, v7

    .line 114
    .line 115
    move-object/from16 v20, v0

    .line 116
    .line 117
    invoke-virtual/range {v15 .. v22}, Lcom/facebook/aura/vds/compose/card/AuraCardStyles;->list-oAWOtXo(LX/2rU;JLX/1Ot;LX/2d4;II)Lcom/facebook/aura/vds/compose/card/AuraCardStyle;

    .line 118
    .line 119
    .line 120
    move-result-object v37

    .line 121
    and-int/lit8 v3, v6, 0x70

    .line 122
    .line 123
    if-eq v3, v1, :cond_3

    .line 124
    .line 125
    const/4 v10, 0x0

    .line 126
    :cond_3
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    if-nez v10, :cond_4

    .line 131
    .line 132
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 133
    .line 134
    if-ne v1, v3, :cond_5

    .line 135
    .line 136
    :cond_4
    sget-object v3, LX/0wV;->A00:LX/0wV;

    .line 137
    .line 138
    new-instance v1, LX/2iK;

    .line 139
    .line 140
    invoke-direct {v1, v9, v3}, LX/2iK;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 141
    .line 142
    .line 143
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_5
    check-cast v1, LX/2iK;

    .line 147
    .line 148
    const-wide/16 v50, 0x0

    .line 149
    .line 150
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 151
    .line 152
    .line 153
    move-result-object v15

    .line 154
    const v23, 0x7fffffff

    .line 155
    .line 156
    .line 157
    const/16 v27, 0x1

    .line 158
    .line 159
    sget-wide v31, LX/JOw;->A07:J

    .line 160
    .line 161
    new-instance v12, Lcom/facebook/aura/vds/compose/card/AuraCardContent;

    .line 162
    .line 163
    move-object/from16 v16, v14

    .line 164
    .line 165
    move-object/from16 v18, v14

    .line 166
    .line 167
    move-object/from16 v19, v14

    .line 168
    .line 169
    move-object/from16 v20, v14

    .line 170
    .line 171
    move-object/from16 v21, v14

    .line 172
    .line 173
    move-object/from16 v22, v14

    .line 174
    .line 175
    move/from16 v24, v23

    .line 176
    .line 177
    move/from16 v25, v23

    .line 178
    .line 179
    move-object/from16 v26, v14

    .line 180
    .line 181
    move/from16 v28, v27

    .line 182
    .line 183
    move-object/from16 v29, v14

    .line 184
    .line 185
    move-object/from16 v30, v14

    .line 186
    .line 187
    move-wide/from16 v33, v31

    .line 188
    .line 189
    move-object/from16 v35, v14

    .line 190
    .line 191
    move-object/from16 v17, v1

    .line 192
    .line 193
    invoke-direct/range {v12 .. v35}, Lcom/facebook/aura/vds/compose/card/AuraCardContent;-><init>(Ljava/lang/String;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;LX/0Xl;LX/JOw;LX/2iK;LX/JDM;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndBodyStyle;LX/JOw;Ljava/lang/String;LX/2hg;IIILjava/lang/String;ZZLjava/lang/String;LX/2hg;JJLX/2wS;)V

    .line 194
    .line 195
    .line 196
    sget-object v40, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$262492019:LX/JDN;

    .line 197
    .line 198
    const p4, 0x3dfe8

    .line 199
    .line 200
    .line 201
    const/16 p2, 0x6000

    .line 202
    .line 203
    move-object/from16 v38, v12

    .line 204
    .line 205
    move-object/from16 v39, v14

    .line 206
    .line 207
    move-object/from16 v41, v14

    .line 208
    .line 209
    move-object/from16 v42, v14

    .line 210
    .line 211
    move-object/from16 v43, v14

    .line 212
    .line 213
    move-object/from16 v44, v14

    .line 214
    .line 215
    move-object/from16 v45, v14

    .line 216
    .line 217
    move/from16 v47, v46

    .line 218
    .line 219
    move-object/from16 v48, v14

    .line 220
    .line 221
    move-object/from16 v49, v8

    .line 222
    .line 223
    move/from16 v52, v46

    .line 224
    .line 225
    move-object/from16 v53, v14

    .line 226
    .line 227
    move-object/from16 p0, v14

    .line 228
    .line 229
    move-object/from16 p1, v0

    .line 230
    .line 231
    move/from16 p3, v46

    .line 232
    .line 233
    invoke-static/range {v36 .. v58}, Lcom/facebook/aura/vds/compose/card/AuraCardKt;->AuraCard-jQVUvHA(LX/3C1;Lcom/facebook/aura/vds/compose/card/AuraCardStyle;Lcom/facebook/aura/vds/compose/card/AuraCardContent;Lcom/facebook/aura/vds/compose/card/AuraCardType;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;Ljava/lang/Boolean;LX/JDM;LX/JDM;ZZLX/346;LX/2bW;JZLX/JDQ;LX/JDQ;LX/2d4;III)V

    .line 234
    .line 235
    .line 236
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    if-eqz v1, :cond_6

    .line 241
    .line 242
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteEarnedUsageCard$2;

    .line 243
    .line 244
    move-object/from16 p0, v0

    .line 245
    .line 246
    move-object/from16 p1, v13

    .line 247
    .line 248
    move-object/from16 p2, v9

    .line 249
    .line 250
    move-object/from16 p3, v5

    .line 251
    .line 252
    move/from16 p4, v2

    .line 253
    .line 254
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteEarnedUsageCard$2;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 255
    .line 256
    .line 257
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 258
    .line 259
    :cond_6
    return-void

    .line 260
    :cond_7
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 261
    .line 262
    .line 263
    goto :goto_2

    .line 264
    :cond_8
    and-int/lit16 v3, v2, 0x180

    .line 265
    .line 266
    if-nez v3, :cond_1

    .line 267
    .line 268
    invoke-static {v0, v5}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    or-int/2addr v6, v3

    .line 273
    goto/16 :goto_1

    .line 274
    .line 275
    :cond_9
    move v6, v2

    .line 276
    goto/16 :goto_0
.end method

.method public static final AuraInviteFriendSheet(LX/3C1;LX/2d4;II)V
    .locals 22

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    const v1, 0x6fc0ad76

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p1

    .line 6
    .line 7
    invoke-interface {v3, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p3

    .line 11
    .line 12
    and-int/lit8 v8, p3, 0x1

    .line 13
    .line 14
    const/4 v6, 0x2

    .line 15
    move/from16 v2, p2

    .line 16
    .line 17
    if-eqz v8, :cond_4

    .line 18
    .line 19
    or-int/lit8 v7, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v5, v7, 0x3

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    invoke-static {v5, v6}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    and-int/lit8 v5, v7, 0x1

    .line 29
    .line 30
    invoke-interface {v3, v5, v6}, LX/2d4;->Afw(IZ)Z

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    if-eqz v5, :cond_3

    .line 35
    .line 36
    if-eqz v8, :cond_0

    .line 37
    .line 38
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 39
    .line 40
    :cond_0
    invoke-static {v3, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteFriendContent(LX/2d4;I)Lcom/facebook/aura/activation/view/InviteFriendContent;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    iget-object v5, v7, Lcom/facebook/aura/activation/view/InviteFriendContent;->modifier:LX/3C1;

    .line 45
    .line 46
    invoke-interface {v0, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 47
    .line 48
    .line 49
    move-result-object v10

    .line 50
    const v5, 0x7f1204bb

    .line 51
    .line 52
    .line 53
    invoke-static {v3, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v15

    .line 57
    iget-boolean v5, v7, Lcom/facebook/aura/activation/view/InviteFriendContent;->canRedeem:Z

    .line 58
    .line 59
    if-eqz v5, :cond_2

    .line 60
    .line 61
    sget-object v5, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 62
    .line 63
    invoke-virtual {v5}, Lcom/facebook/aura/utils/HatchUtil;->isRedeemInviteEnabled()Z

    .line 64
    .line 65
    .line 66
    move-result v5

    .line 67
    if-eqz v5, :cond_2

    .line 68
    .line 69
    const v9, 0x7f1204bd

    .line 70
    .line 71
    .line 72
    const v8, 0x7f1204be

    .line 73
    .line 74
    .line 75
    iget-object v6, v7, Lcom/facebook/aura/activation/view/InviteFriendContent;->onRedeemClick:Lkotlin/jvm/functions/Function0;

    .line 76
    .line 77
    new-instance v5, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;

    .line 78
    .line 79
    invoke-direct {v5, v9, v8, v6}, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;-><init>(IILkotlin/jvm/functions/Function0;)V

    .line 80
    .line 81
    .line 82
    :goto_1
    const/4 v9, 0x0

    .line 83
    sget-object v20, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;->DEFAULT:Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;

    .line 84
    .line 85
    const p0, 0x7fffffff

    .line 86
    .line 87
    .line 88
    new-instance v14, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;

    .line 89
    .line 90
    move-object/from16 v16, v9

    .line 91
    .line 92
    move-object/from16 v17, v9

    .line 93
    .line 94
    move-object/from16 v18, v9

    .line 95
    .line 96
    move-object/from16 v19, v9

    .line 97
    .line 98
    move-object/from16 v21, v5

    .line 99
    .line 100
    invoke-direct/range {v14 .. v22}, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;I)V

    .line 101
    .line 102
    .line 103
    iget-object v15, v7, Lcom/facebook/aura/activation/view/InviteFriendContent;->footer:LX/JDN;

    .line 104
    .line 105
    sget-object v13, LX/Dn6;->A06:LX/Dps;

    .line 106
    .line 107
    iget-object v5, v7, Lcom/facebook/aura/activation/view/InviteFriendContent;->items:LX/JDM;

    .line 108
    .line 109
    const/16 p2, 0x6

    .line 110
    .line 111
    const/16 p3, 0xb8d

    .line 112
    .line 113
    const/16 v19, 0x1

    .line 114
    .line 115
    const/16 p1, 0x6000

    .line 116
    .line 117
    move-object v11, v9

    .line 118
    move-object v12, v9

    .line 119
    move-object/from16 v20, v9

    .line 120
    .line 121
    move-object/from16 p0, v3

    .line 122
    .line 123
    move/from16 v18, v1

    .line 124
    .line 125
    move-object/from16 v21, v5

    .line 126
    .line 127
    invoke-static/range {v9 .. v25}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetLazyColumnContent(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3C1;Landroidx/compose/foundation/lazy/LazyListState;LX/Dps;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/JDM;LX/2d4;III)V

    .line 128
    .line 129
    .line 130
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    if-eqz v3, :cond_1

    .line 135
    .line 136
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteFriendSheet$1;

    .line 137
    .line 138
    invoke-direct {v1, v0, v2, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteFriendSheet$1;-><init>(LX/3C1;II)V

    .line 139
    .line 140
    .line 141
    iput-object v1, v3, LX/J7V;->A06:LX/JDN;

    .line 142
    .line 143
    :cond_1
    return-void

    .line 144
    :cond_2
    const/4 v5, 0x0

    .line 145
    goto :goto_1

    .line 146
    :cond_3
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 147
    .line 148
    .line 149
    goto :goto_2

    .line 150
    :cond_4
    and-int/lit8 v1, p2, 0x6

    .line 151
    .line 152
    if-nez v1, :cond_5

    .line 153
    .line 154
    invoke-static {v3, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 155
    .line 156
    .line 157
    move-result v7

    .line 158
    or-int v7, v7, p2

    .line 159
    .line 160
    goto/16 :goto_0

    .line 161
    .line 162
    :cond_5
    move v7, v2

    .line 163
    goto/16 :goto_0
.end method

.method public static final AuraInviteGift(Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZLX/3C1;LX/2d4;II)V
    .locals 23

    .line 0
    move-object/from16 v6, p3

    .line 1
    .line 2
    const v0, -0x110ebe9d

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p4

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v0, :cond_e

    .line 17
    .line 18
    invoke-static {v3, v4}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    or-int v8, v8, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move/from16 v18, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move/from16 v0, v18

    .line 31
    .line 32
    invoke-static {v3, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v8, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 38
    .line 39
    move/from16 v17, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    move/from16 v0, v17

    .line 44
    .line 45
    invoke-static {v3, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v8, v0

    .line 50
    :cond_1
    and-int/lit8 v7, p6, 0x8

    .line 51
    .line 52
    if-eqz v7, :cond_d

    .line 53
    .line 54
    or-int/lit16 v8, v8, 0xc00

    .line 55
    .line 56
    :cond_2
    :goto_1
    and-int/lit16 v1, v8, 0x493

    .line 57
    .line 58
    const/16 v0, 0x492

    .line 59
    .line 60
    const/4 v2, 0x0

    .line 61
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    and-int/lit8 v0, v8, 0x1

    .line 66
    .line 67
    invoke-interface {v3, v0, v1}, LX/2d4;->Afw(IZ)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_17

    .line 72
    .line 73
    if-eqz v7, :cond_3

    .line 74
    .line 75
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 76
    .line 77
    :cond_3
    const/4 v15, 0x0

    .line 78
    if-eqz p0, :cond_c

    .line 79
    .line 80
    iget-object v0, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->lightUrl:Ljava/lang/String;

    .line 81
    .line 82
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    iget-object v0, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->darkUrl:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    new-instance v7, LX/IBK;

    .line 101
    .line 102
    invoke-direct {v7, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    :goto_2
    invoke-interface {v3, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v9

    .line 113
    if-nez v0, :cond_4

    .line 114
    .line 115
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 116
    .line 117
    if-ne v9, v0, :cond_5

    .line 118
    .line 119
    :cond_4
    invoke-static {v3, v2}, LX/Bi9;->A04(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 120
    .line 121
    .line 122
    move-result-object v9

    .line 123
    :cond_5
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .line 124
    .line 125
    invoke-interface {v3, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v8

    .line 133
    if-nez v0, :cond_6

    .line 134
    .line 135
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 136
    .line 137
    if-ne v8, v0, :cond_7

    .line 138
    .line 139
    :cond_6
    invoke-static {v3, v2}, LX/Bi9;->A04(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 140
    .line 141
    .line 142
    move-result-object v8

    .line 143
    :cond_7
    check-cast v8, Landroidx/compose/runtime/MutableState;

    .line 144
    .line 145
    invoke-static {v3, v7, v8, v9}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    if-nez v1, :cond_8

    .line 154
    .line 155
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 156
    .line 157
    if-ne v0, v1, :cond_9

    .line 158
    .line 159
    :cond_8
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$1$1;

    .line 160
    .line 161
    invoke-direct {v0, v7, v8, v9, v15}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$1$1;-><init>(LX/IBK;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    :cond_9
    check-cast v0, LX/JDN;

    .line 168
    .line 169
    invoke-static {v3, v7, v0}, LX/CdB;->A06(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 170
    .line 171
    .line 172
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    const/4 v7, 0x0

    .line 177
    if-eqz v0, :cond_a

    .line 178
    .line 179
    const/high16 v7, 0x3f800000    # 1.0f

    .line 180
    .line 181
    :cond_a
    const/16 v16, 0xc00

    .line 182
    .line 183
    const/16 v1, 0x16

    .line 184
    .line 185
    const/16 p3, 0x0

    .line 186
    .line 187
    move/from16 v0, v16

    .line 188
    .line 189
    invoke-static {v15, v3, v7, v0, v1}, LX/34R;->A01(LX/DwJ;LX/2d4;FII)LX/16A;

    .line 190
    .line 191
    .line 192
    move-result-object v7

    .line 193
    if-eqz p0, :cond_18

    .line 194
    .line 195
    invoke-static {v9}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-nez v0, :cond_18

    .line 200
    .line 201
    const v0, -0x2cb6760

    .line 202
    .line 203
    .line 204
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 205
    .line 206
    .line 207
    sget-object v11, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 208
    .line 209
    const/4 v0, 0x0

    .line 210
    if-eqz p2, :cond_b

    .line 211
    .line 212
    const v0, 0x3ecccccd    # 0.4f

    .line 213
    .line 214
    .line 215
    :cond_b
    invoke-static {v6, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->overlappedBy(LX/3C1;F)LX/3C1;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    sget-object v0, LX/2sI;->A02:LX/2wD;

    .line 220
    .line 221
    invoke-interface {v1, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    iget v0, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->aspectRatio:F

    .line 226
    .line 227
    invoke-static {v1, v0, v2}, LX/7b5;->A00(LX/3C1;FZ)LX/3C1;

    .line 228
    .line 229
    .line 230
    move-result-object v10

    .line 231
    invoke-static {v3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->modal:J

    .line 236
    .line 237
    invoke-static {v10, v0, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->fadeEdgesInto-4WTKRHQ(LX/3C1;J)LX/3C1;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    invoke-static {v11, v2}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 242
    .line 243
    .line 244
    move-result-object v14

    .line 245
    move-object v1, v3

    .line 246
    check-cast v1, LX/J7I;

    .line 247
    .line 248
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 249
    .line 250
    .line 251
    move-result v13

    .line 252
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 253
    .line 254
    .line 255
    move-result-object v12

    .line 256
    invoke-static {v3, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 257
    .line 258
    .line 259
    move-result-object v11

    .line 260
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 261
    .line 262
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 263
    .line 264
    if-nez v0, :cond_f

    .line 265
    .line 266
    invoke-static {}, LX/1VY;->A00()V

    .line 267
    .line 268
    .line 269
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 270
    .line 271
    .line 272
    move-result-object v0

    .line 273
    throw v0

    .line 274
    :cond_c
    move-object v7, v15

    .line 275
    goto/16 :goto_2

    .line 276
    .line 277
    :cond_d
    and-int/lit16 v0, v5, 0xc00

    .line 278
    .line 279
    if-nez v0, :cond_2

    .line 280
    .line 281
    invoke-static {v3, v6}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 282
    .line 283
    .line 284
    move-result v0

    .line 285
    or-int/2addr v8, v0

    .line 286
    goto/16 :goto_1

    .line 287
    .line 288
    :cond_e
    move v8, v5

    .line 289
    goto/16 :goto_0

    .line 290
    .line 291
    :cond_f
    invoke-static {v3, v1, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 292
    .line 293
    .line 294
    invoke-static {v3, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 295
    .line 296
    .line 297
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 298
    .line 299
    .line 300
    move-result v0

    .line 301
    if-nez v0, :cond_16

    .line 302
    .line 303
    const v0, -0x4b20fa61

    .line 304
    .line 305
    .line 306
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 307
    .line 308
    .line 309
    const/16 p2, 0x7

    .line 310
    .line 311
    const-wide/16 v21, 0x0

    .line 312
    .line 313
    move-object/from16 v19, v15

    .line 314
    .line 315
    move-object/from16 v20, v15

    .line 316
    .line 317
    move-object/from16 p0, v3

    .line 318
    .line 319
    move/from16 p1, v2

    .line 320
    .line 321
    invoke-static/range {v19 .. v25}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerKt;->AuraSpinner-FNF3uiM(LX/3C1;Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;JLX/2d4;II)V

    .line 322
    .line 323
    .line 324
    :goto_3
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 325
    .line 326
    .line 327
    iget-object v12, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->lightUrl:Ljava/lang/String;

    .line 328
    .line 329
    iget-object v11, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->darkUrl:Ljava/lang/String;

    .line 330
    .line 331
    iget v10, v4, Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;->aspectRatio:F

    .line 332
    .line 333
    invoke-interface {v3, v9}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 334
    .line 335
    .line 336
    move-result v13

    .line 337
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    if-nez v13, :cond_10

    .line 342
    .line 343
    sget-object v13, LX/2d6;->A00:Ljava/lang/Object;

    .line 344
    .line 345
    if-ne v0, v13, :cond_11

    .line 346
    .line 347
    :cond_10
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$1$1;

    .line 348
    .line 349
    invoke-direct {v0, v9}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 350
    .line 351
    .line 352
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 353
    .line 354
    .line 355
    :cond_11
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 356
    .line 357
    invoke-interface {v3, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 358
    .line 359
    .line 360
    move-result v13

    .line 361
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 362
    .line 363
    .line 364
    move-result-object v9

    .line 365
    if-nez v13, :cond_12

    .line 366
    .line 367
    sget-object v13, LX/2d6;->A00:Ljava/lang/Object;

    .line 368
    .line 369
    if-ne v9, v13, :cond_13

    .line 370
    .line 371
    :cond_12
    new-instance v9, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$2$1;

    .line 372
    .line 373
    invoke-direct {v9, v8}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 374
    .line 375
    .line 376
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 377
    .line 378
    .line 379
    :cond_13
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 380
    .line 381
    sget-object v14, LX/2sI;->A01:LX/2wD;

    .line 382
    .line 383
    invoke-interface {v3, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 384
    .line 385
    .line 386
    move-result v13

    .line 387
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v8

    .line 391
    if-nez v13, :cond_14

    .line 392
    .line 393
    sget-object v13, LX/2d6;->A00:Ljava/lang/Object;

    .line 394
    .line 395
    if-ne v8, v13, :cond_15

    .line 396
    .line 397
    :cond_14
    new-instance v8, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$3$1;

    .line 398
    .line 399
    invoke-direct {v8, v7}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$2$3$1;-><init>(LX/16A;)V

    .line 400
    .line 401
    .line 402
    invoke-interface {v3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 403
    .line 404
    .line 405
    :cond_15
    check-cast v8, LX/JDM;

    .line 406
    .line 407
    invoke-static {v14, v8}, LX/2uT;->A01(LX/3C1;LX/JDM;)LX/3C1;

    .line 408
    .line 409
    .line 410
    move-result-object p2

    .line 411
    const-string v22, "invite_gift"

    .line 412
    .line 413
    move-object/from16 p0, v0

    .line 414
    .line 415
    move-object/from16 p1, v9

    .line 416
    .line 417
    move-object/from16 p3, v3

    .line 418
    .line 419
    move/from16 p4, v16

    .line 420
    .line 421
    move/from16 p5, v2

    .line 422
    .line 423
    move-object/from16 v19, v12

    .line 424
    .line 425
    move-object/from16 v20, v11

    .line 426
    .line 427
    move/from16 v21, v10

    .line 428
    .line 429
    invoke-static/range {v19 .. v28}, Lcom/facebook/aura/common/video/HatchThemedLoopingVideoKt;->HatchThemedLoopingVideo(Ljava/lang/String;Ljava/lang/String;FLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 430
    .line 431
    .line 432
    const/4 v0, 0x1

    .line 433
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 434
    .line 435
    .line 436
    goto :goto_4

    .line 437
    :cond_16
    const v0, -0x4b208602

    .line 438
    .line 439
    .line 440
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 441
    .line 442
    .line 443
    goto :goto_3

    .line 444
    :cond_17
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 445
    .line 446
    .line 447
    goto :goto_5

    .line 448
    :cond_18
    if-nez p0, :cond_1a

    .line 449
    .line 450
    if-nez p1, :cond_1a

    .line 451
    .line 452
    const v0, -0x2bc34c1

    .line 453
    .line 454
    .line 455
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 456
    .line 457
    .line 458
    :goto_4
    move-object v0, v3

    .line 459
    check-cast v0, LX/J7I;

    .line 460
    .line 461
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 462
    .line 463
    .line 464
    :goto_5
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 465
    .line 466
    .line 467
    move-result-object v1

    .line 468
    if-eqz v1, :cond_19

    .line 469
    .line 470
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$3;

    .line 471
    .line 472
    move-object/from16 p0, v0

    .line 473
    .line 474
    move-object/from16 p1, v4

    .line 475
    .line 476
    move/from16 p2, v18

    .line 477
    .line 478
    move/from16 p3, v17

    .line 479
    .line 480
    move-object/from16 p4, v6

    .line 481
    .line 482
    move/from16 p5, v5

    .line 483
    .line 484
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteGift$3;-><init>(Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZLX/3C1;II)V

    .line 485
    .line 486
    .line 487
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 488
    .line 489
    :cond_19
    return-void

    .line 490
    :cond_1a
    const v0, -0x2bf3a0f

    .line 491
    .line 492
    .line 493
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 494
    .line 495
    .line 496
    const v0, 0x7f0801dd

    .line 497
    .line 498
    .line 499
    invoke-static {v3, v0, v2}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 500
    .line 501
    .line 502
    move-result-object p0

    .line 503
    const/high16 v1, 0x434c0000    # 204.0f

    .line 504
    .line 505
    const/high16 v0, 0x42f00000    # 120.0f

    .line 506
    .line 507
    invoke-static {v6, v1, v0}, LX/2sI;->A0C(LX/3C1;FF)LX/3C1;

    .line 508
    .line 509
    .line 510
    move-result-object v21

    .line 511
    sget v0, LX/2l9;->$stable:I

    .line 512
    .line 513
    or-int/lit8 p4, v0, 0x30

    .line 514
    .line 515
    const/16 p5, 0x78

    .line 516
    .line 517
    move-object/from16 v22, v15

    .line 518
    .line 519
    move-object/from16 p1, v15

    .line 520
    .line 521
    move-object/from16 p2, v15

    .line 522
    .line 523
    move-object/from16 v19, v3

    .line 524
    .line 525
    move-object/from16 v20, v15

    .line 526
    .line 527
    invoke-static/range {v19 .. v28}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 528
    .line 529
    .line 530
    goto :goto_4
.end method

.method public static final AuraInviteGift$lambda$2(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraInviteGift$lambda$3(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraInviteGift$lambda$5(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraInviteGift$lambda$6(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraInvitePitch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 41
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;",
            "Z",
            "Lcom/facebook/aura/activation/data/HatchInviteReward;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    move-object/from16 v3, p11

    const v0, -0x23142fc5

    .line 1296108
    move-object/from16 v5, p12

    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    move/from16 v4, p13

    and-int/lit8 v0, p13, 0x6

    move-object/from16 v19, p0

    if-nez v0, :cond_f

    .line 1296109
    move-object/from16 v0, v19

    invoke-static {v5, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    move-result v18

    .line 1296110
    or-int v18, v18, p13

    :goto_0
    and-int/lit8 v0, p13, 0x30

    if-nez v0, :cond_0

    .line 1296111
    move-object/from16 v0, p1

    invoke-static {v5, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296112
    or-int v18, v18, v0

    :cond_0
    and-int/lit16 v0, v4, 0x180

    move-object/from16 v7, p2

    if-nez v0, :cond_1

    .line 1296113
    invoke-static {v5, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296114
    or-int v18, v18, v0

    :cond_1
    and-int/lit16 v0, v4, 0xc00

    move/from16 p0, p3

    if-nez v0, :cond_2

    .line 1296115
    move/from16 v0, p0

    invoke-static {v5, v0}, LX/004;->A0l(LX/2d4;Z)I

    move-result v0

    .line 1296116
    or-int v18, v18, v0

    :cond_2
    and-int/lit16 v0, v4, 0x6000

    move/from16 v15, p4

    if-nez v0, :cond_3

    .line 1296117
    invoke-static {v5, v15}, LX/004;->A0m(LX/2d4;Z)I

    move-result v0

    .line 1296118
    or-int v18, v18, v0

    :cond_3
    const/high16 v0, 0x30000

    and-int v0, v0, p13

    move-object/from16 v30, p5

    if-nez v0, :cond_4

    .line 1296119
    move-object/from16 v0, v30

    invoke-static {v5, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296120
    or-int v18, v18, v0

    :cond_4
    const/high16 v0, 0x180000

    and-int v0, v0, p13

    move/from16 v40, p6

    if-nez v0, :cond_5

    .line 1296121
    move/from16 v0, v40

    invoke-static {v5, v0}, LX/004;->A0o(LX/2d4;Z)I

    move-result v0

    .line 1296122
    or-int v18, v18, v0

    :cond_5
    const/high16 v0, 0xc00000

    and-int v0, p13, v0

    move-object/from16 v6, p7

    if-nez v0, :cond_6

    .line 1296123
    invoke-static {v5, v6}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296124
    or-int v18, v18, v0

    :cond_6
    const/high16 v0, 0x6000000

    and-int v0, p13, v0

    move-object/from16 v39, p8

    if-nez v0, :cond_7

    .line 1296125
    move-object/from16 v0, v39

    invoke-static {v5, v0}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296126
    or-int v18, v18, v0

    :cond_7
    const/high16 v0, 0x30000000

    and-int v0, p13, v0

    move-object/from16 v38, p9

    if-nez v0, :cond_8

    .line 1296127
    move-object/from16 v0, v38

    invoke-static {v5, v0}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296128
    or-int v18, v18, v0

    :cond_8
    move/from16 v29, p14

    and-int/lit8 v0, p14, 0x6

    move-object/from16 v28, p10

    if-nez v0, :cond_e

    .line 1296129
    move-object/from16 v0, v28

    invoke-static {v5, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296130
    or-int v17, p14, v0

    :goto_1
    move/from16 v37, p15

    move/from16 v0, v37

    and-int/lit16 v8, v0, 0x800

    if-eqz v8, :cond_d

    or-int/lit8 v17, v17, 0x30

    :cond_9
    :goto_2
    const v0, 0x12492493

    and-int v1, v18, v0

    const v0, 0x12492492

    if-ne v1, v0, :cond_a

    and-int/lit8 v2, v17, 0x13

    const/16 v0, 0x12

    const/4 v1, 0x0

    if-eq v2, v0, :cond_b

    :cond_a
    const/4 v1, 0x1

    :cond_b
    and-int/lit8 v0, v18, 0x1

    invoke-interface {v5, v0, v1}, LX/2d4;->Afw(IZ)Z

    move-result v0

    if-eqz v0, :cond_15

    if-eqz v8, :cond_c

    .line 1296131
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    :cond_c
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v14, v0, 0xe

    and-int/lit8 v16, v0, 0x70

    and-int/lit8 v1, v0, 0x7e

    .line 1296132
    move/from16 v0, p0

    invoke-static {v7, v0, v5, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->isInviteCodeFoilCovering(Ljava/lang/String;ZLX/2d4;I)Z

    move-result v1

    .line 1296133
    sget-object v8, LX/2Id;->A00:LX/2sS;

    .line 1296134
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 1296135
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    move-result-object v2

    .line 1296136
    invoke-static {v3, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->claimTouches(LX/3C1;Z)LX/3C1;

    move-result-object v0

    const/16 v33, 0x0

    .line 1296137
    sget-object v10, LX/2sI;->A02:LX/2wD;

    invoke-interface {v0, v10}, LX/3C1;->then(LX/3C1;)LX/3C1;

    move-result-object v1

    .line 1296138
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 1296139
    const/4 v9, 0x0

    .line 1296140
    invoke-static {v1, v9, v9, v9, v0}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v0

    .line 1296141
    const/16 v1, 0x30

    .line 1296142
    invoke-static {v2, v5, v8, v1}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    move-result-object v13

    .line 1296143
    move-object v2, v5

    check-cast v2, LX/J7I;

    .line 1296144
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    move-result v12

    .line 1296145
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v11

    .line 1296146
    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v8

    .line 1296147
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 1296148
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 1296149
    if-nez v0, :cond_10

    invoke-static {}, LX/1VY;->A00()V

    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    move-result-object v0

    throw v0

    .line 1296150
    :cond_d
    and-int/lit8 v0, p14, 0x30

    if-nez v0, :cond_9

    .line 1296151
    invoke-static {v5, v3}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1296152
    or-int v17, v17, v0

    goto :goto_2

    :cond_e
    move/from16 v17, v29

    goto/16 :goto_1

    :cond_f
    move/from16 v18, v4

    goto/16 :goto_0

    .line 1296153
    :cond_10
    invoke-static {v5, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 1296154
    invoke-static {v5, v13, v11, v8, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 1296155
    if-eqz p4, :cond_14

    const v0, 0x22826d65

    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1296156
    invoke-static {v7}, LX/003;->A1Q(Ljava/lang/Object;)Z

    move-result v32

    .line 1296157
    shr-int/lit8 v0, v18, 0xf

    and-int/lit8 v35, v0, 0x7e

    const/16 v36, 0x8

    .line 1296158
    move/from16 v31, v40

    move-object/from16 v34, v5

    invoke-static/range {v30 .. v36}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteGift(Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZLX/3C1;LX/2d4;II)V

    .line 1296159
    :goto_3
    const/4 v0, 0x0

    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1296160
    if-eqz p2, :cond_13

    const v1, 0x22858043

    .line 1296161
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    .line 1296162
    or-int/lit16 v11, v14, 0x6000

    or-int v11, v11, v16

    shr-int/lit8 v8, v18, 0x12

    and-int/lit16 v1, v8, 0x380

    or-int/2addr v11, v1

    and-int/lit16 v1, v8, 0x1c00

    or-int/2addr v11, v1

    .line 1296163
    move-object/from16 v22, v39

    move-object/from16 v23, v38

    move-object/from16 v24, v10

    move-object/from16 v25, v5

    move/from16 v26, v11

    move/from16 v27, v0

    move-object/from16 v20, v7

    move/from16 v21, p0

    invoke-static/range {v20 .. v27}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->InviteCodeScratcher(Ljava/lang/String;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1296164
    :goto_4
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1296165
    if-eqz v19, :cond_12

    const v1, 0x22898152

    .line 1296166
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    .line 1296167
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 1296168
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 1296169
    invoke-static {v8, v1, v9}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    move-result-object v11

    .line 1296170
    and-int/lit8 v13, v18, 0x7e

    shl-int/lit8 v1, v17, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/2addr v13, v1

    .line 1296171
    move-object/from16 v8, v19

    move-object/from16 v9, p1

    move-object/from16 v10, v28

    move-object v12, v5

    move v14, v0

    invoke-static/range {v8 .. v14}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1296172
    :goto_5
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1296173
    if-eqz p7, :cond_11

    const v1, 0x228d3120

    .line 1296174
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    .line 1296175
    iget-object v8, v6, Lcom/facebook/aura/activation/data/HatchInviteReward;->title:Ljava/lang/String;

    .line 1296176
    iget-object v1, v6, Lcom/facebook/aura/activation/data/HatchInviteReward;->body:Ljava/lang/String;

    .line 1296177
    const/16 v36, 0x4

    move-object/from16 v31, v8

    move-object/from16 v32, v1

    move-object/from16 v34, v5

    move/from16 v35, v0

    invoke-static/range {v31 .. v36}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteEarnedUsageCard(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1296178
    :goto_6
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 1296179
    goto :goto_7

    .line 1296180
    :cond_11
    const v0, 0x228e6131

    .line 1296181
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    goto :goto_6

    .line 1296182
    :cond_12
    const v1, 0x228cc671

    .line 1296183
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    goto :goto_5

    .line 1296184
    :cond_13
    const v1, 0x2288fdb1

    .line 1296185
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    goto :goto_4

    .line 1296186
    :cond_14
    const v0, 0x2284f311

    .line 1296187
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    goto/16 :goto_3

    .line 1296188
    :cond_15
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 1296189
    :goto_7
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    move-result-object v1

    if-eqz v1, :cond_16

    .line 1296190
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;

    move/from16 v20, v15

    move-object/from16 v21, v30

    move/from16 v22, v40

    move-object/from16 v23, v6

    move-object/from16 v24, v39

    move-object/from16 v25, v38

    move-object/from16 v26, v28

    move-object/from16 v27, v3

    move/from16 v28, v4

    move/from16 v30, v37

    move-object v15, v0

    move-object/from16 v16, v19

    move-object/from16 v17, p1

    move-object/from16 v18, v7

    move/from16 v19, p0

    invoke-direct/range {v15 .. v30}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInvitePitch$2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;III)V

    .line 1296191
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 1296192
    :cond_16
    return-void
.end method

.method public static final AuraInviteSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 25
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v11, p3

    .line 1
    .line 2
    const v0, -0x5bd87e33

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    const/4 v8, 0x4

    .line 15
    move-object/from16 v4, p0

    .line 16
    .line 17
    if-nez v0, :cond_b

    .line 18
    .line 19
    invoke-static {v2, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 20
    .line 21
    .line 22
    move-result v7

    .line 23
    or-int v7, v7, p5

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 26
    .line 27
    move-object/from16 v3, p1

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    invoke-static {v2, v3}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    or-int/2addr v7, v0

    .line 36
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 37
    .line 38
    move-object/from16 v6, p2

    .line 39
    .line 40
    if-nez v0, :cond_1

    .line 41
    .line 42
    invoke-static {v2, v6}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    or-int/2addr v7, v0

    .line 47
    :cond_1
    and-int/lit8 v10, p6, 0x8

    .line 48
    .line 49
    if-eqz v10, :cond_a

    .line 50
    .line 51
    or-int/lit16 v7, v7, 0xc00

    .line 52
    .line 53
    :cond_2
    :goto_1
    and-int/lit16 v5, v7, 0x493

    .line 54
    .line 55
    const/16 v0, 0x492

    .line 56
    .line 57
    const/4 v9, 0x0

    .line 58
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 59
    .line 60
    .line 61
    move-result v5

    .line 62
    and-int/lit8 v0, v7, 0x1

    .line 63
    .line 64
    invoke-interface {v2, v0, v5}, LX/2d4;->Afw(IZ)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_9

    .line 69
    .line 70
    if-eqz v10, :cond_3

    .line 71
    .line 72
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 73
    .line 74
    :cond_3
    if-eqz p1, :cond_5

    .line 75
    .line 76
    const v0, -0x2e828ebc

    .line 77
    .line 78
    .line 79
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 80
    .line 81
    .line 82
    and-int/lit16 v0, v7, 0x3fe

    .line 83
    .line 84
    invoke-static {v4, v3, v6, v2, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->rememberLinkedSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/2iK;

    .line 85
    .line 86
    .line 87
    move-result-object v10

    .line 88
    :goto_2
    move-object v0, v2

    .line 89
    check-cast v0, LX/J7I;

    .line 90
    .line 91
    const/4 v5, 0x0

    .line 92
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 93
    .line 94
    .line 95
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 96
    .line 97
    const/4 v9, 0x6

    .line 98
    invoke-virtual {v8, v2, v9}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    iget-object v14, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineRegular:LX/2hg;

    .line 103
    .line 104
    invoke-virtual {v8, v2, v9}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    iget-wide v12, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 109
    .line 110
    const/4 v8, 0x3

    .line 111
    new-instance v0, LX/2wS;

    .line 112
    .line 113
    invoke-direct {v0, v8}, LX/2wS;-><init>(I)V

    .line 114
    .line 115
    .line 116
    shr-int/2addr v7, v9

    .line 117
    and-int/lit8 p3, v7, 0x70

    .line 118
    .line 119
    const/16 p5, 0x7fb0

    .line 120
    .line 121
    const/4 v15, 0x0

    .line 122
    const-wide/16 v18, 0x0

    .line 123
    .line 124
    move-object/from16 v16, v15

    .line 125
    .line 126
    move/from16 v21, v5

    .line 127
    .line 128
    move/from16 v22, v5

    .line 129
    .line 130
    move/from16 v23, v5

    .line 131
    .line 132
    move-object/from16 v24, v15

    .line 133
    .line 134
    move-object/from16 p0, v15

    .line 135
    .line 136
    move-object/from16 p1, v15

    .line 137
    .line 138
    move-object/from16 p2, v2

    .line 139
    .line 140
    move/from16 p4, v5

    .line 141
    .line 142
    move-object/from16 v17, v0

    .line 143
    .line 144
    move/from16 v20, v5

    .line 145
    .line 146
    invoke-static/range {v10 .. v30}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 147
    .line 148
    .line 149
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 150
    .line 151
    .line 152
    move-result-object v2

    .line 153
    if-eqz v2, :cond_4

    .line 154
    .line 155
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteSubtitle$2;

    .line 156
    .line 157
    move-object/from16 p1, v4

    .line 158
    .line 159
    move-object/from16 p2, v3

    .line 160
    .line 161
    move-object/from16 p3, v6

    .line 162
    .line 163
    move-object/from16 p4, v11

    .line 164
    .line 165
    move/from16 p5, v1

    .line 166
    .line 167
    move-object/from16 p0, v0

    .line 168
    .line 169
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$AuraInviteSubtitle$2;-><init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 170
    .line 171
    .line 172
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 173
    .line 174
    :cond_4
    return-void

    .line 175
    :cond_5
    const v0, -0x2e813e75

    .line 176
    .line 177
    .line 178
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 179
    .line 180
    .line 181
    and-int/lit8 v0, v7, 0xe

    .line 182
    .line 183
    if-ne v0, v8, :cond_6

    .line 184
    .line 185
    const/4 v9, 0x1

    .line 186
    :cond_6
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v10

    .line 190
    if-nez v9, :cond_7

    .line 191
    .line 192
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 193
    .line 194
    if-ne v10, v0, :cond_8

    .line 195
    .line 196
    :cond_7
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 197
    .line 198
    new-instance v10, LX/2iK;

    .line 199
    .line 200
    invoke-direct {v10, v4, v0}, LX/2iK;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 201
    .line 202
    .line 203
    invoke-interface {v2, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    :cond_8
    check-cast v10, LX/2iK;

    .line 207
    .line 208
    goto :goto_2

    .line 209
    :cond_9
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 210
    .line 211
    .line 212
    goto :goto_3

    .line 213
    :cond_a
    and-int/lit16 v0, v1, 0xc00

    .line 214
    .line 215
    if-nez v0, :cond_2

    .line 216
    .line 217
    invoke-static {v2, v11}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 218
    .line 219
    .line 220
    move-result v0

    .line 221
    or-int/2addr v7, v0

    .line 222
    goto/16 :goto_1

    .line 223
    .line 224
    :cond_b
    move v7, v1

    .line 225
    goto/16 :goto_0
.end method

.method public static final synthetic access$AuraInviteEarnedUsageCard(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteEarnedUsageCard(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraInviteGift(Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteGift(Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraInviteGift$lambda$3(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraInviteGift$lambda$5(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$AuraInviteGift$lambda$6(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraInvitePitch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p15}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInvitePitch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraInviteSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInviteSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$copyToClipboard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->copyToClipboard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$inviteFriendContent$lambda$1(LX/16A;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$inviteFriendContent$lambda$2(LX/16A;)Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$inviteFriendContent$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$inviteFriendContent$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$openServedLink(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->openServedLink(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final copyToClipboard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 2

    .line 0
    const-string v0, "clipboard"

    .line 1
    .line 2
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Landroid/content/ClipboardManager;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Landroid/content/ClipboardManager;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    :try_start_0
    invoke-static {p1, p2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v1, v0}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    .line 20
    .line 21
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/16 v0, 0x21

    .line 24
    .line 25
    if-ge v1, v0, :cond_0

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-static {p0, p3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :catch_0
    move-exception p0

    .line 37
    const/16 v0, 0x19

    .line 38
    .line 39
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    const-string v0, "HatchInviteShare"

    .line 44
    .line 45
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    return-void
.end method

.method public static final fadeEdgesInto-4WTKRHQ(LX/3C1;J)LX/3C1;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;

    .line 1
    .line 2
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;-><init>(J)V

    .line 3
    .line 4
    .line 5
    invoke-static {p0, v0}, LX/2pJ;->A02(LX/3C1;LX/JDM;)LX/3C1;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getClipIdentity(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public static final inviteFriendContent(LX/2d4;I)Lcom/facebook/aura/activation/view/InviteFriendContent;
    .locals 49

    .line 0
    sget-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->A01:LX/Ip3;

    .line 1
    .line 2
    move-object/from16 v0, p0

    .line 3
    .line 4
    invoke-interface {v0, v1}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    check-cast v1, Landroid/content/Context;

    .line 9
    .line 10
    sget-object v2, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 11
    .line 12
    invoke-interface {v0, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v8

    .line 16
    check-cast v8, LX/AHE;

    .line 17
    .line 18
    new-instance v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;

    .line 19
    .line 20
    invoke-direct {v6, v8}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;-><init>(LX/AHE;)V

    .line 21
    .line 22
    .line 23
    invoke-static {v0}, LX/3Rq;->A02(LX/2d4;)Landroidx/activity/ComponentActivity;

    .line 24
    .line 25
    .line 26
    move-result-object v5

    .line 27
    invoke-static {v5}, LX/004;->A14(LX/15O;)LX/13i;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    const-class v2, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 32
    .line 33
    new-instance v3, LX/Ddf;

    .line 34
    .line 35
    invoke-direct {v3, v2}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 36
    .line 37
    .line 38
    const/4 v7, 0x0

    .line 39
    const/16 v20, 0x0

    .line 40
    .line 41
    move-object/from16 v2, v20

    .line 42
    .line 43
    invoke-static {v6, v5, v4, v2, v3}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 48
    .line 49
    sget-object v12, Lcom/facebook/aura/navigation/key/ShareType;->INVITE:Lcom/facebook/aura/navigation/key/ShareType;

    .line 50
    .line 51
    const/16 v21, 0x3fc

    .line 52
    .line 53
    const/16 v47, 0x0

    .line 54
    .line 55
    new-instance v10, Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel$Factory;

    .line 56
    .line 57
    move-object v14, v2

    .line 58
    move-object v15, v2

    .line 59
    move-object/from16 v16, v2

    .line 60
    .line 61
    move-object/from16 v17, v2

    .line 62
    .line 63
    move-object/from16 v18, v2

    .line 64
    .line 65
    move-object/from16 v19, v2

    .line 66
    .line 67
    move-object/from16 v22, v2

    .line 68
    .line 69
    move-object v11, v8

    .line 70
    move v13, v7

    .line 71
    invoke-direct/range {v10 .. v22}, Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel$Factory;-><init>(LX/AHE;Lcom/facebook/aura/navigation/key/ShareType;ZLjava/lang/String;LX/JDN;LX/JDN;Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareLogContext;Lcom/facebook/aura/model/HatchDanceShare;Lcom/facebook/aura/navigation/key/HatchAvatarVideoShare;ILX/04f;)V

    .line 72
    .line 73
    .line 74
    invoke-static {v0}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    if-eqz v6, :cond_1e

    .line 79
    .line 80
    invoke-static {v6}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 81
    .line 82
    .line 83
    move-result-object v5

    .line 84
    const-class v4, Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 85
    .line 86
    invoke-static {v10, v6, v5, v4, v2}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 87
    .line 88
    .line 89
    move-result-object v15

    .line 90
    check-cast v15, Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 91
    .line 92
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 97
    .line 98
    if-ne v4, v2, :cond_0

    .line 99
    .line 100
    iget-object v4, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->uiState:LX/2J3;

    .line 101
    .line 102
    invoke-interface {v4}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 107
    .line 108
    iget v4, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->completedLoads:I

    .line 109
    .line 110
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_0
    check-cast v4, Ljava/lang/Number;

    .line 118
    .line 119
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v36

    .line 123
    iget-object v4, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->uiState:LX/2J3;

    .line 124
    .line 125
    invoke-static {v0, v4, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 126
    .line 127
    .line 128
    move-result-object v19

    .line 129
    iget-object v4, v15, Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;->uiState:LX/2J3;

    .line 130
    .line 131
    invoke-static {v0, v4, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 132
    .line 133
    .line 134
    move-result-object v18

    .line 135
    new-array v5, v7, [Ljava/lang/Object;

    .line 136
    .line 137
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    if-ne v4, v2, :cond_1

    .line 142
    .line 143
    sget-object v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$isInviteCodeRevealed$2$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$isInviteCodeRevealed$2$1;

    .line 144
    .line 145
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_1
    invoke-static {v0, v4, v5}, LX/39E;->A01(LX/2d4;Ljava/lang/Object;[Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 149
    .line 150
    .line 151
    move-result-object v17

    .line 152
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v6

    .line 156
    if-ne v6, v2, :cond_2

    .line 157
    .line 158
    new-instance v6, Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 159
    .line 160
    move-object/from16 v21, v6

    .line 161
    .line 162
    move-object/from16 v22, v12

    .line 163
    .line 164
    move-object/from16 v23, v14

    .line 165
    .line 166
    move-object/from16 v24, v14

    .line 167
    .line 168
    move/from16 v25, v7

    .line 169
    .line 170
    move-object/from16 v26, v14

    .line 171
    .line 172
    move-object/from16 v27, v14

    .line 173
    .line 174
    invoke-direct/range {v21 .. v27}, Lcom/facebook/aura/sharesheet/HatchShareLogContext;-><init>(Lcom/facebook/aura/navigation/key/ShareType;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    :cond_2
    check-cast v6, Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 181
    .line 182
    sget-object v5, Lcom/facebook/aura/sharesheet/HatchShareLogging;->INSTANCE:Lcom/facebook/aura/sharesheet/HatchShareLogging;

    .line 183
    .line 184
    sget v4, Lcom/facebook/aura/sharesheet/HatchShareLogContext;->$stable:I

    .line 185
    .line 186
    or-int/lit8 v4, v4, 0x30

    .line 187
    .line 188
    invoke-virtual {v5, v6, v0, v4}, Lcom/facebook/aura/sharesheet/HatchShareLogging;->rememberShareSheetDismissLogging(Lcom/facebook/aura/sharesheet/HatchShareLogContext;LX/2d4;I)Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;

    .line 189
    .line 190
    .line 191
    move-result-object v16

    .line 192
    sget-object v9, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 193
    .line 194
    invoke-interface {v0, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v5

    .line 198
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v4

    .line 202
    if-nez v5, :cond_3

    .line 203
    .line 204
    if-ne v4, v2, :cond_4

    .line 205
    .line 206
    :cond_3
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$1$1;

    .line 207
    .line 208
    invoke-direct {v4, v3}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$1$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;)V

    .line 209
    .line 210
    .line 211
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_4
    check-cast v4, LX/JDM;

    .line 215
    .line 216
    invoke-static {v0, v9, v4}, LX/CdB;->A05(LX/2d4;Ljava/lang/Object;LX/JDM;)V

    .line 217
    .line 218
    .line 219
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v4

    .line 223
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 224
    .line 225
    iget-object v5, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->inviteLink:Ljava/lang/String;

    .line 226
    .line 227
    if-eqz v5, :cond_5

    .line 228
    .line 229
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 230
    .line 231
    .line 232
    move-result v4

    .line 233
    if-eqz v4, :cond_6

    .line 234
    .line 235
    :cond_5
    const/4 v5, 0x0

    .line 236
    :cond_6
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v4

    .line 240
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 241
    .line 242
    iget-object v10, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 243
    .line 244
    if-eqz v10, :cond_7

    .line 245
    .line 246
    invoke-static {v10}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 247
    .line 248
    .line 249
    move-result v4

    .line 250
    if-eqz v4, :cond_8

    .line 251
    .line 252
    :cond_7
    const/4 v10, 0x0

    .line 253
    :cond_8
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v4

    .line 257
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 258
    .line 259
    iget-object v4, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->shareText:Ljava/lang/String;

    .line 260
    .line 261
    invoke-static {v4, v5, v0, v7}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->resolveInviteShareText(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v11

    .line 265
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v4

    .line 269
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 270
    .line 271
    iget-object v9, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->shareText:Ljava/lang/String;

    .line 272
    .line 273
    if-eqz v9, :cond_1d

    .line 274
    .line 275
    invoke-static {v9}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 276
    .line 277
    .line 278
    move-result v4

    .line 279
    if-nez v4, :cond_1d

    .line 280
    .line 281
    if-eqz v5, :cond_1d

    .line 282
    .line 283
    move-object/from16 v47, v9

    .line 284
    .line 285
    move-object/from16 v46, v5

    .line 286
    .line 287
    :goto_0
    const v4, 0x7f1204bf

    .line 288
    .line 289
    .line 290
    invoke-static {v0, v4}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v12

    .line 294
    invoke-static {v0, v1, v12}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v9

    .line 298
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object v4

    .line 302
    if-nez v9, :cond_9

    .line 303
    .line 304
    if-ne v4, v2, :cond_a

    .line 305
    .line 306
    :cond_9
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onInviteUnavailable$1$1;

    .line 307
    .line 308
    invoke-direct {v4, v1, v12}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onInviteUnavailable$1$1;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 309
    .line 310
    .line 311
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    :cond_a
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 315
    .line 316
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v9

    .line 320
    check-cast v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 321
    .line 322
    iget-boolean v9, v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 323
    .line 324
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 325
    .line 326
    .line 327
    move-result-object v13

    .line 328
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object v9

    .line 332
    check-cast v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 333
    .line 334
    iget-object v12, v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->shareText:Ljava/lang/String;

    .line 335
    .line 336
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v9

    .line 340
    check-cast v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 341
    .line 342
    iget-object v9, v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyCardUri:Ljava/lang/String;

    .line 343
    .line 344
    filled-new-array {v13, v12, v5, v11, v9}, [Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v13

    .line 348
    move-object/from16 v9, v19

    .line 349
    .line 350
    invoke-static {v0, v9, v5, v11}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result v9

    .line 354
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v12

    .line 358
    if-nez v9, :cond_b

    .line 359
    .line 360
    if-ne v12, v2, :cond_c

    .line 361
    .line 362
    :cond_b
    new-instance v12, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;

    .line 363
    .line 364
    move-object/from16 v9, v19

    .line 365
    .line 366
    invoke-direct {v12, v5, v11, v9}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;-><init>(Ljava/lang/String;Ljava/lang/String;LX/16A;)V

    .line 367
    .line 368
    .line 369
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 370
    .line 371
    .line 372
    :cond_c
    check-cast v12, LX/JDM;

    .line 373
    .line 374
    invoke-static {v0, v12, v13}, LX/CdB;->A07(LX/2d4;LX/JDM;[Ljava/lang/Object;)V

    .line 375
    .line 376
    .line 377
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v9

    .line 381
    check-cast v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 382
    .line 383
    iget-object v13, v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyShareText:Ljava/lang/String;

    .line 384
    .line 385
    if-nez v13, :cond_1c

    .line 386
    .line 387
    const v9, 0x6e768e3d

    .line 388
    .line 389
    .line 390
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 391
    .line 392
    .line 393
    const v9, 0x7f1204c2

    .line 394
    .line 395
    .line 396
    invoke-static {v0, v9}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 397
    .line 398
    .line 399
    move-result-object v13

    .line 400
    :goto_1
    move-object v12, v0

    .line 401
    check-cast v12, LX/J7I;

    .line 402
    .line 403
    invoke-static {v12, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 404
    .line 405
    .line 406
    if-nez v10, :cond_1a

    .line 407
    .line 408
    const v9, 0x605d32f5

    .line 409
    .line 410
    .line 411
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 412
    .line 413
    .line 414
    invoke-static {v12, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 415
    .line 416
    .line 417
    const/4 v9, 0x0

    .line 418
    :goto_2
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 419
    .line 420
    .line 421
    move-result-object v7

    .line 422
    check-cast v7, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 423
    .line 424
    iget-boolean v7, v7, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 425
    .line 426
    if-eqz v7, :cond_d

    .line 427
    .line 428
    const/4 v13, 0x0

    .line 429
    :cond_d
    invoke-interface {v0, v13}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 430
    .line 431
    .line 432
    move-result v7

    .line 433
    invoke-static {v0, v3, v1, v9, v7}, LX/005;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 434
    .line 435
    .line 436
    move-result v12

    .line 437
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v7

    .line 441
    if-nez v12, :cond_e

    .line 442
    .line 443
    if-ne v7, v2, :cond_f

    .line 444
    .line 445
    :cond_e
    new-instance v7, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;

    .line 446
    .line 447
    invoke-direct {v7, v13, v3, v1, v9}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;Landroid/content/Context;Ljava/lang/String;)V

    .line 448
    .line 449
    .line 450
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 451
    .line 452
    .line 453
    :cond_f
    check-cast v7, LX/JDM;

    .line 454
    .line 455
    invoke-static {v0, v13, v9, v7}, LX/CdB;->A03(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;LX/JDM;)V

    .line 456
    .line 457
    .line 458
    invoke-interface {v0, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 459
    .line 460
    .line 461
    move-result v7

    .line 462
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 463
    .line 464
    .line 465
    move-result-object v3

    .line 466
    if-nez v7, :cond_10

    .line 467
    .line 468
    if-ne v3, v2, :cond_11

    .line 469
    .line 470
    :cond_10
    new-instance v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onCopyCode$1$1;

    .line 471
    .line 472
    invoke-direct {v3, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onCopyCode$1$1;-><init>(Landroid/content/Context;)V

    .line 473
    .line 474
    .line 475
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 476
    .line 477
    .line 478
    :cond_11
    check-cast v3, LX/JDM;

    .line 479
    .line 480
    invoke-static {v0}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 481
    .line 482
    .line 483
    move-result-object v12

    .line 484
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 485
    .line 486
    .line 487
    move-result-object v7

    .line 488
    check-cast v7, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 489
    .line 490
    iget-object v9, v7, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->subtitleLinkUrl:Ljava/lang/String;

    .line 491
    .line 492
    invoke-interface {v0, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 493
    .line 494
    .line 495
    move-result v7

    .line 496
    invoke-static {v0, v8, v12, v9, v7}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 497
    .line 498
    .line 499
    move-result v13

    .line 500
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v7

    .line 504
    if-nez v13, :cond_12

    .line 505
    .line 506
    if-ne v7, v2, :cond_13

    .line 507
    .line 508
    :cond_12
    new-instance v7, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;

    .line 509
    .line 510
    move-object/from16 v21, v7

    .line 511
    .line 512
    move-object/from16 v22, v9

    .line 513
    .line 514
    move-object/from16 v23, v6

    .line 515
    .line 516
    move-object/from16 v24, v16

    .line 517
    .line 518
    move-object/from16 v25, v8

    .line 519
    .line 520
    move-object/from16 v26, v1

    .line 521
    .line 522
    move-object/from16 v27, v12

    .line 523
    .line 524
    invoke-direct/range {v21 .. v27}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareLogContext;Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 525
    .line 526
    .line 527
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 528
    .line 529
    .line 530
    :cond_13
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 531
    .line 532
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 533
    .line 534
    invoke-static {v8, v6}, Lcom/facebook/aura/sharesheet/HatchShareLoggingKt;->shareSheetImpression(LX/3C1;Lcom/facebook/aura/sharesheet/HatchShareLogContext;)LX/3C1;

    .line 535
    .line 536
    .line 537
    move-result-object v21

    .line 538
    sget-object v22, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 539
    .line 540
    sget-object v23, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 541
    .line 542
    sget-object v25, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_FRIENDS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 543
    .line 544
    sget-object v26, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_FRIENDS_SHEET:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 545
    .line 546
    const-wide/16 v30, 0x1f4

    .line 547
    .line 548
    const/16 v32, 0x0

    .line 549
    .line 550
    move-object/from16 v27, v20

    .line 551
    .line 552
    move-object/from16 v28, v20

    .line 553
    .line 554
    move-object/from16 v29, v20

    .line 555
    .line 556
    move-object/from16 v33, v20

    .line 557
    .line 558
    move-object/from16 v34, v20

    .line 559
    .line 560
    move-object/from16 v35, v20

    .line 561
    .line 562
    move-object/from16 v24, v20

    .line 563
    .line 564
    invoke-static/range {v21 .. v35}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 565
    .line 566
    .line 567
    move-result-object v13

    .line 568
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v8

    .line 572
    check-cast v8, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 573
    .line 574
    iget-boolean v8, v8, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 575
    .line 576
    if-nez v8, :cond_14

    .line 577
    .line 578
    invoke-interface/range {v19 .. v19}, LX/16A;->getValue()Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v8

    .line 582
    check-cast v8, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 583
    .line 584
    iget-boolean v8, v8, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->showRedeemButton:Z

    .line 585
    .line 586
    const/4 v14, 0x1

    .line 587
    if-nez v8, :cond_15

    .line 588
    .line 589
    :cond_14
    const/4 v14, 0x0

    .line 590
    :cond_15
    move-object/from16 v8, v16

    .line 591
    .line 592
    invoke-static {v0, v8, v12}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 593
    .line 594
    .line 595
    move-result v8

    .line 596
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 597
    .line 598
    .line 599
    move-result-object v9

    .line 600
    if-nez v8, :cond_16

    .line 601
    .line 602
    if-ne v9, v2, :cond_17

    .line 603
    .line 604
    :cond_16
    new-instance v9, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$4$1;

    .line 605
    .line 606
    move-object/from16 v8, v16

    .line 607
    .line 608
    invoke-direct {v9, v8, v12}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$4$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 609
    .line 610
    .line 611
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 612
    .line 613
    .line 614
    :cond_17
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 615
    .line 616
    move-object/from16 v8, v19

    .line 617
    .line 618
    invoke-interface {v0, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 619
    .line 620
    .line 621
    move-result v12

    .line 622
    move-object/from16 v8, v17

    .line 623
    .line 624
    invoke-static {v0, v10, v8, v3, v12}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 625
    .line 626
    .line 627
    move-result v12

    .line 628
    move-object/from16 v8, v18

    .line 629
    .line 630
    invoke-static {v0, v7, v8, v11, v12}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 631
    .line 632
    .line 633
    move-result v8

    .line 634
    invoke-static {v0, v15, v1, v4, v8}, LX/005;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 635
    .line 636
    .line 637
    move-result v12

    .line 638
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v8

    .line 642
    if-nez v12, :cond_18

    .line 643
    .line 644
    if-ne v8, v2, :cond_19

    .line 645
    .line 646
    :cond_18
    new-instance v8, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;

    .line 647
    .line 648
    move-object/from16 v35, v10

    .line 649
    .line 650
    move-object/from16 v37, v3

    .line 651
    .line 652
    move-object/from16 v38, v17

    .line 653
    .line 654
    move-object/from16 v39, v7

    .line 655
    .line 656
    move-object/from16 v40, v19

    .line 657
    .line 658
    move-object/from16 v41, v18

    .line 659
    .line 660
    move-object/from16 v42, v11

    .line 661
    .line 662
    move-object/from16 v43, v15

    .line 663
    .line 664
    move-object/from16 v44, v1

    .line 665
    .line 666
    move-object/from16 v45, v4

    .line 667
    .line 668
    move-object/from16 v34, v8

    .line 669
    .line 670
    invoke-direct/range {v34 .. v45}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;-><init>(Ljava/lang/String;ILX/JDM;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;LX/16A;LX/16A;Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 671
    .line 672
    .line 673
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 674
    .line 675
    .line 676
    :cond_19
    check-cast v8, LX/JDM;

    .line 677
    .line 678
    new-instance v2, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;

    .line 679
    .line 680
    move-object/from16 v40, v2

    .line 681
    .line 682
    move-object/from16 v41, v5

    .line 683
    .line 684
    move-object/from16 v42, v11

    .line 685
    .line 686
    move-object/from16 v43, v4

    .line 687
    .line 688
    move-object/from16 v44, v15

    .line 689
    .line 690
    move-object/from16 v45, v1

    .line 691
    .line 692
    move-object/from16 v48, v6

    .line 693
    .line 694
    move-object/from16 p0, v19

    .line 695
    .line 696
    move-object/from16 p1, v18

    .line 697
    .line 698
    invoke-direct/range {v40 .. v50}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;-><init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareLogContext;LX/16A;LX/16A;)V

    .line 699
    .line 700
    .line 701
    const v1, -0x7cef0213

    .line 702
    .line 703
    .line 704
    invoke-static {v0, v2, v1}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 705
    .line 706
    .line 707
    move-result-object v17

    .line 708
    new-instance v12, Lcom/facebook/aura/activation/view/InviteFriendContent;

    .line 709
    .line 710
    move-object v15, v9

    .line 711
    move-object/from16 v16, v8

    .line 712
    .line 713
    invoke-direct/range {v12 .. v17}, Lcom/facebook/aura/activation/view/InviteFriendContent;-><init>(LX/3C1;ZLkotlin/jvm/functions/Function0;LX/JDM;LX/JDN;)V

    .line 714
    .line 715
    .line 716
    return-object v12

    .line 717
    :cond_1a
    const v9, 0x605d32f6

    .line 718
    .line 719
    .line 720
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 721
    .line 722
    .line 723
    sget-object v9, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 724
    .line 725
    invoke-virtual {v9}, Lcom/facebook/aura/utils/HatchUtil;->getInviteStoryCodeText()Ljava/lang/String;

    .line 726
    .line 727
    .line 728
    move-result-object v14

    .line 729
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    .line 730
    .line 731
    .line 732
    move-result v9

    .line 733
    if-lez v9, :cond_1b

    .line 734
    .line 735
    const v9, -0x695b4b2a

    .line 736
    .line 737
    .line 738
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 739
    .line 740
    .line 741
    const v9, 0x7f1204c1

    .line 742
    .line 743
    .line 744
    invoke-static {v0, v14, v10, v9}, LX/18b;->A09(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;

    .line 745
    .line 746
    .line 747
    move-result-object v9

    .line 748
    invoke-static {v12, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 749
    .line 750
    .line 751
    :goto_3
    invoke-static {v12, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 752
    .line 753
    .line 754
    goto/16 :goto_2

    .line 755
    .line 756
    :cond_1b
    const v9, -0x6958a65f

    .line 757
    .line 758
    .line 759
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 760
    .line 761
    .line 762
    const v9, 0x7f1204c0

    .line 763
    .line 764
    .line 765
    invoke-static {v0, v10, v9}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 766
    .line 767
    .line 768
    move-result-object v9

    .line 769
    invoke-static {v12, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 770
    .line 771
    .line 772
    goto :goto_3

    .line 773
    :cond_1c
    const v9, 0x6e768965

    .line 774
    .line 775
    .line 776
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 777
    .line 778
    .line 779
    goto/16 :goto_1

    .line 780
    .line 781
    :cond_1d
    move-object/from16 v46, v11

    .line 782
    .line 783
    goto/16 :goto_0

    .line 784
    .line 785
    :cond_1e
    const-string v1, "No ViewModelStoreOwner was provided via LocalViewModelStoreOwner"

    .line 786
    .line 787
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 788
    .line 789
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 790
    .line 791
    .line 792
    throw v0
.end method

.method public static final inviteFriendContent$lambda$1(LX/16A;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final inviteFriendContent$lambda$2(LX/16A;)Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;",
            ">;)",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final inviteFriendContent$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final inviteFriendContent$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/sharesheet/HatchShareDestination;",
            "Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p3}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareDestination;Lkotlin/jvm/functions/Function0;)V

    .line 5
    .line 6
    .line 7
    :goto_0
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    if-nez p2, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return-object v0

    .line 14
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;

    .line 15
    .line 16
    invoke-direct {v0, p0, p4, p2}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;-><init>(Lcom/facebook/aura/sharesheet/HatchShareDestination;LX/JDM;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    goto :goto_0
.end method

.method public static final openServedLink(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 4

    .line 0
    sget-object v1, Lcom/facebook/aura/deeplink/AuraDeeplinkRouteMapper;->INSTANCE:Lcom/facebook/aura/deeplink/AuraDeeplinkRouteMapper;

    .line 1
    .line 2
    move-object v2, p1

    .line 3
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v1, v0}, Lcom/facebook/aura/deeplink/AuraDeeplinkRouteMapper;->hasRouteForUri(Landroid/net/Uri;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    move-object v1, p0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/uicontrol/UiControlActionSink;->Companion:Lcom/facebook/aura/uicontrol/UiControlActionSink$Companion;

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Lcom/facebook/aura/uicontrol/UiControlActionSink$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/uicontrol/UiControlActionSink;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0, p1}, Lcom/facebook/aura/uicontrol/UiControlActionSink;->publishNavigation(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    const/4 p1, 0x0

    .line 25
    move-object v3, p2

    .line 26
    move-object p0, p3

    .line 27
    move-object p2, p1

    .line 28
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/conversation/links/HatchUrlClickHandlerKt;->handleUrlClick(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/JDN;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public static final overlappedBy(LX/3C1;F)LX/3C1;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;

    .line 1
    .line 2
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;-><init>(F)V

    .line 3
    .line 4
    .line 5
    invoke-static {p0, v0}, LX/2ub;->A00(LX/3C1;LX/JDQ;)LX/3C1;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final rememberLinkedSubtitle(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/2iK;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)",
            "LX/2iK;"
        }
    .end annotation

    .line 0
    invoke-static {p3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v7, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 5
    .line 6
    const-string v0, " "

    .line 7
    .line 8
    move-object v6, p1

    .line 9
    invoke-static {p0, v0, p1}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v5

    .line 13
    invoke-interface {p3, v5}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    and-int/lit8 v0, p4, 0x70

    .line 18
    .line 19
    xor-int/lit8 v0, v0, 0x30

    .line 20
    .line 21
    const/4 v3, 0x0

    .line 22
    const/16 v2, 0x20

    .line 23
    .line 24
    if-le v0, v2, :cond_0

    .line 25
    .line 26
    invoke-interface {p3, p1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    :cond_0
    and-int/lit8 v1, p4, 0x30

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    if-ne v1, v2, :cond_2

    .line 36
    .line 37
    :cond_1
    const/4 v0, 0x1

    .line 38
    :cond_2
    or-int/2addr v4, v0

    .line 39
    invoke-interface {p3, v7, v8}, LX/2d4;->A68(J)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v4, v0

    .line 44
    and-int/lit16 v0, p4, 0x380

    .line 45
    .line 46
    xor-int/lit16 v0, v0, 0x180

    .line 47
    .line 48
    const/16 v1, 0x100

    .line 49
    .line 50
    move-object p1, p2

    .line 51
    if-le v0, v1, :cond_3

    .line 52
    .line 53
    invoke-interface {p3, p2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-nez v0, :cond_4

    .line 58
    .line 59
    :cond_3
    and-int/lit16 v0, p4, 0x180

    .line 60
    .line 61
    if-ne v0, v1, :cond_5

    .line 62
    .line 63
    :cond_4
    const/4 v3, 0x1

    .line 64
    :cond_5
    or-int/2addr v4, v3

    .line 65
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    if-nez v4, :cond_6

    .line 70
    .line 71
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 72
    .line 73
    if-ne v1, v0, :cond_7

    .line 74
    .line 75
    :cond_6
    const-string p0, "invite_subtitle_link"

    .line 76
    .line 77
    invoke-static/range {v5 .. v10}, Lcom/facebook/aura/linktext/HatchInlineLinkTextKt;->buildInlineLinkText-XO-JAsU(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Lkotlin/jvm/functions/Function0;)LX/2iK;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-interface {p3, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    :cond_7
    check-cast v1, LX/2iK;

    .line 85
    .line 86
    return-object v1
.end method

.method public static final resolveInviteShareText(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)Ljava/lang/String;
    .locals 1

    .line 0
    const v0, 0x5488a6d2

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-nez p1, :cond_0

    .line 8
    .line 9
    invoke-static {p2}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    if-eqz p0, :cond_1

    .line 14
    .line 15
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    const v0, 0x54fa4ba2    # 8.600086E12f

    .line 22
    .line 23
    .line 24
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 25
    .line 26
    .line 27
    :goto_0
    check-cast p2, LX/J7I;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-static {p2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 31
    .line 32
    .line 33
    invoke-static {p2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 34
    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_1
    const v0, 0x54fa520d

    .line 38
    .line 39
    .line 40
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 41
    .line 42
    .line 43
    const p0, 0x7f1204ba

    .line 44
    .line 45
    .line 46
    const-string v0, "Muse"

    .line 47
    .line 48
    invoke-static {p2, v0, p1, p0}, LX/18b;->A09(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    goto :goto_0
.end method
