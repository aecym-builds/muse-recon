.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/1O1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $completedLoadsAtOpen:I

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $inviteCode:Ljava/lang/String;

.field public final synthetic $inviteState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onCopyCode:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onInviteUnavailable:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shareState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shareText:Ljava/lang/String;

.field public final synthetic $shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILX/JDM;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;LX/16A;LX/16A;Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;",
            "LX/16A<",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;",
            ">;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$inviteCode:Ljava/lang/String;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$completedLoadsAtOpen:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onCopyCode:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$inviteState$delegate:LX/16A;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareState$delegate:LX/16A;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareText:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$context:Landroid/content/Context;

    .line 19
    .line 20
    iput-object p11, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1O1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->invoke(LX/1O1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/1O1;)V
    .locals 10

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$inviteCode:Ljava/lang/String;

    .line 5
    .line 6
    iget v5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$completedLoadsAtOpen:I

    .line 7
    .line 8
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onCopyCode:LX/JDM;

    .line 9
    .line 10
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 11
    .line 12
    iget-object v8, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iget-object v9, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$inviteState$delegate:LX/16A;

    .line 15
    .line 16
    new-instance v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;

    .line 17
    .line 18
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;-><init>(Ljava/lang/String;ILX/JDM;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;LX/16A;)V

    .line 19
    .line 20
    .line 21
    const v2, 0x43bb9359

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    new-instance v1, LX/Ddo;

    .line 26
    .line 27
    invoke-direct {v1, v3, v2, v0}, LX/Ddo;-><init>(Ljava/lang/Object;IZ)V

    .line 28
    .line 29
    .line 30
    const-string v0, "invite_pitch"

    .line 31
    .line 32
    invoke-interface {p1, v0, v0, v1}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$inviteState$delegate:LX/16A;

    .line 36
    .line 37
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 42
    .line 43
    iget-boolean v0, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 44
    .line 45
    if-nez v0, :cond_0

    .line 46
    .line 47
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareState$delegate:LX/16A;

    .line 48
    .line 49
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    check-cast v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 54
    .line 55
    iget-object v1, v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->loadingState:Lcom/facebook/aura/sharesheet/HatchShareSheetLoadingState;

    .line 56
    .line 57
    sget-object v0, Lcom/facebook/aura/sharesheet/HatchShareSheetLoadingState;->LOADING:Lcom/facebook/aura/sharesheet/HatchShareSheetLoadingState;

    .line 58
    .line 59
    if-eq v1, v0, :cond_0

    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareState$delegate:LX/16A;

    .line 62
    .line 63
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 68
    .line 69
    iget-object v0, v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->data:Lcom/facebook/aura/sharesheet/HatchShareSheetData;

    .line 70
    .line 71
    iget-object v6, v0, Lcom/facebook/aura/sharesheet/HatchShareSheetData;->recipients:LX/Ddn;

    .line 72
    .line 73
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareState$delegate:LX/16A;

    .line 74
    .line 75
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 80
    .line 81
    iget-object v5, v0, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->recipientSendStates:Ljava/util/Map;

    .line 82
    .line 83
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareText:Ljava/lang/String;

    .line 84
    .line 85
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 86
    .line 87
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$context:Landroid/content/Context;

    .line 88
    .line 89
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 90
    .line 91
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$2;

    .line 92
    .line 93
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$2;-><init>(Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 94
    .line 95
    .line 96
    invoke-static {p1, v6, v5, v0}, Lcom/facebook/aura/sharesheet/HatchShareSheetKt;->HatchShareRecipientsSection(LX/1O1;LX/Ddn;Ljava/util/Map;LX/JDM;)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_0
    sget-object v2, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$748256670:LX/JDQ;

    .line 101
    .line 102
    const-string v1, "loading"

    .line 103
    .line 104
    const-string v0, "status"

    .line 105
    .line 106
    invoke-interface {p1, v1, v0, v2}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 107
    .line 108
    .line 109
    return-void
.end method
