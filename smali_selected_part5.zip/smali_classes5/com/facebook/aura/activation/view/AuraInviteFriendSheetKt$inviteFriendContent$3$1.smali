.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $inviteViewModel:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

.field public final synthetic $storyAccessCodeText:Ljava/lang/String;

.field public final synthetic $storyCardMessage:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$storyCardMessage:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$inviteViewModel:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$storyAccessCodeText:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$storyCardMessage:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz v3, :cond_0

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$inviteViewModel:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$context:Landroid/content/Context;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->$storyAccessCodeText:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v2, v1, v3, v0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderStoryCard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1$invoke$$inlined$onDispose$1;

    .line 14
    .line 15
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$3$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
