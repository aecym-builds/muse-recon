.class public final Lcom/facebook/aura/activation/view/InviteFriendContent;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final canRedeem:Z

.field public final footer:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final items:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "LX/1O1;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final modifier:LX/3C1;

.field public final onRedeemClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/3C1;ZLkotlin/jvm/functions/Function0;LX/JDM;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/1O1;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, p3, p4, p5, v0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->modifier:LX/3C1;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->canRedeem:Z

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->onRedeemClick:Lkotlin/jvm/functions/Function0;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->items:LX/JDM;

    .line 14
    .line 15
    iput-object p5, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->footer:LX/JDN;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final getCanRedeem()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->canRedeem:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getFooter()LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->footer:LX/JDN;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getItems()LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDM<",
            "LX/1O1;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->items:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getModifier()LX/3C1;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->modifier:LX/3C1;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOnRedeemClick()Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteFriendContent;->onRedeemClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method
