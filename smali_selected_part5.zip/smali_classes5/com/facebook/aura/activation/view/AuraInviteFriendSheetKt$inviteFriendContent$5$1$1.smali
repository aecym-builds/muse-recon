.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $completedLoadsAtOpen:I

.field public final synthetic $inviteCode:Ljava/lang/String;

.field public final synthetic $inviteState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onCopyCode:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;ILX/JDM;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteCode:Ljava/lang/String;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$completedLoadsAtOpen:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$onCopyCode:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    check-cast p3, Ljava/lang/Number;

    .line 5
    .line 6
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->invoke(LX/1Xg;LX/2d4;I)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 17

    .line 268435456
    const/4 v1, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435460
    .line 268435461
    .line 268435462
    and-int/lit8 v2, p3, 0x11

    .line 268435463
    .line 268435464
    const/16 v0, 0x10

    .line 268435465
    .line 268435466
    const/4 v11, 0x0

    .line 268435467
    invoke-static {v2, v0}, LX/003;->A1H(II)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v3

    .line 268435471
    and-int/lit8 v0, p3, 0x1

    .line 268435472
    .line 268435473
    move-object/from16 v2, p2

    .line 268435474
    .line 268435475
    invoke-interface {v2, v0, v3}, LX/2d4;->Afw(IZ)Z

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    if-eqz v0, :cond_3

    .line 268435480
    .line 268435481
    move-object/from16 v4, p0

    .line 268435482
    .line 268435483
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435484
    .line 268435485
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435486
    .line 268435487
    .line 268435488
    move-result-object v0

    .line 268435489
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435490
    .line 268435491
    iget-object v5, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->subtitle:Ljava/lang/String;

    .line 268435492
    .line 268435493
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435494
    .line 268435495
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435496
    .line 268435497
    .line 268435498
    move-result-object v0

    .line 268435499
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435500
    .line 268435501
    iget-object v6, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->subtitleLinkText:Ljava/lang/String;

    .line 268435502
    .line 268435503
    iget-object v7, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteCode:Ljava/lang/String;

    .line 268435504
    .line 268435505
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435506
    .line 268435507
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 268435508
    .line 268435509
    .line 268435510
    move-result v8

    .line 268435511
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435512
    .line 268435513
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435514
    .line 268435515
    .line 268435516
    move-result-object v0

    .line 268435517
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435518
    .line 268435519
    iget-boolean v9, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->showsGift:Z

    .line 268435520
    .line 268435521
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435522
    .line 268435523
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435524
    .line 268435525
    .line 268435526
    move-result-object v0

    .line 268435527
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435528
    .line 268435529
    iget-object v10, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 268435530
    .line 268435531
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435532
    .line 268435533
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435534
    .line 268435535
    .line 268435536
    move-result-object v0

    .line 268435537
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435538
    .line 268435539
    iget v3, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->completedLoads:I

    .line 268435540
    .line 268435541
    iget v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$completedLoadsAtOpen:I

    .line 268435542
    .line 268435543
    if-le v3, v0, :cond_0

    .line 268435544
    .line 268435545
    const/4 v11, 0x1

    .line 268435546
    :cond_0
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$inviteState$delegate:LX/16A;

    .line 268435547
    .line 268435548
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435549
    .line 268435550
    .line 268435551
    move-result-object v0

    .line 268435552
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 268435553
    .line 268435554
    iget-object v12, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 268435555
    .line 268435556
    iget-object v13, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$onCopyCode:LX/JDM;

    .line 268435557
    .line 268435558
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435559
    .line 268435560
    invoke-interface {v2, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435561
    .line 268435562
    .line 268435563
    move-result v0

    .line 268435564
    iget-object v3, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$isInviteCodeRevealed$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435565
    .line 268435566
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435567
    .line 268435568
    .line 268435569
    move-result-object v14

    .line 268435570
    if-nez v0, :cond_1

    .line 268435571
    .line 268435572
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435573
    .line 268435574
    if-ne v14, v0, :cond_2

    .line 268435575
    .line 268435576
    :cond_1
    new-instance v14, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1$1$1;

    .line 268435577
    .line 268435578
    invoke-direct {v14, v3}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 268435579
    .line 268435580
    .line 268435581
    invoke-interface {v2, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435582
    .line 268435583
    .line 268435584
    :cond_2
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 268435585
    .line 268435586
    iget-object v15, v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$5$1$1;->$onSubtitleLinkClick:Lkotlin/jvm/functions/Function0;

    .line 268435587
    .line 268435588
    const/16 v16, 0x0

    .line 268435589
    .line 268435590
    const/16 p3, 0x800

    .line 268435591
    .line 268435592
    move/from16 p2, v1

    .line 268435593
    .line 268435594
    move/from16 p1, v1

    .line 268435595
    .line 268435596
    move-object/from16 p0, v2

    .line 268435597
    .line 268435598
    invoke-static/range {v5 .. v20}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->AuraInvitePitch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZLcom/facebook/aura/activation/data/HatchInviteReward;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 268435599
    .line 268435600
    .line 268435601
    return-void

    .line 268435602
    :cond_3
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 268435603
    .line 268435604
    .line 268435605
    return-void
.end method
