.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $dismissLogging:Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;

.field public final synthetic $logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $subtitleLinkUrl:Ljava/lang/String;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareLogContext;Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$subtitleLinkUrl:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$dismissLogging:Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$context:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$subtitleLinkUrl:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/sharesheet/HatchShareLogging;->INSTANCE:Lcom/facebook/aura/sharesheet/HatchShareLogging;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 7
    .line 8
    invoke-virtual {v1, v0}, Lcom/facebook/aura/sharesheet/HatchShareLogging;->logInviteLearnMore(Lcom/facebook/aura/sharesheet/HatchShareLogContext;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$dismissLogging:Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, v1, Lcom/facebook/aura/sharesheet/HatchShareDismissLogging;->isSuppressed:Z

    .line 15
    .line 16
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$userSession:LX/AHE;

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$subtitleLinkUrl:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$context:Landroid/content/Context;

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$onSubtitleLinkClick$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 23
    .line 24
    invoke-static {v3, v2, v1, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->openServedLink(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    return-void
.end method
