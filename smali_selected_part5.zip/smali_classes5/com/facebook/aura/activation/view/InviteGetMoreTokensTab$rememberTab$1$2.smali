.class public final Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lcom/facebook/aura/subscription/api/GetMoreTokensTabContent;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;->INSTANCE:Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)Lcom/facebook/aura/subscription/api/GetMoreTokensTabContent;
    .locals 4

    .line 0
    const v0, 0x6b0b08de

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    invoke-static {p1, p0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteFriendContent(LX/2d4;I)Lcom/facebook/aura/activation/view/InviteFriendContent;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v3, v0, Lcom/facebook/aura/activation/view/InviteFriendContent;->modifier:LX/3C1;

    .line 12
    .line 13
    iget-object v2, v0, Lcom/facebook/aura/activation/view/InviteFriendContent;->items:LX/JDM;

    .line 14
    .line 15
    iget-object v1, v0, Lcom/facebook/aura/activation/view/InviteFriendContent;->footer:LX/JDN;

    .line 16
    .line 17
    new-instance v0, Lcom/facebook/aura/subscription/api/GetMoreTokensTabContent;

    .line 18
    .line 19
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/subscription/api/GetMoreTokensTabContent;-><init>(LX/3C1;LX/JDM;LX/JDN;)V

    .line 20
    .line 21
    .line 22
    check-cast p1, LX/J7I;

    .line 23
    .line 24
    invoke-static {p1, p0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 25
    .line 26
    .line 27
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/lang/Number;

    .line 268435459
    .line 268435460
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;->invoke(LX/2d4;I)Lcom/facebook/aura/subscription/api/GetMoreTokensTabContent;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object v0

    .line 268435468
    return-object v0
.end method
