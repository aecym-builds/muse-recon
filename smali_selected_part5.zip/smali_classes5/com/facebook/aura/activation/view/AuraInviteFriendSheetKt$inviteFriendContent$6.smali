.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $feedCaption:Ljava/lang/String;

.field public final synthetic $feedShareText:Ljava/lang/String;

.field public final synthetic $inviteLink:Ljava/lang/String;

.field public final synthetic $inviteState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

.field public final synthetic $onInviteUnavailable:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shareState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shareText:Ljava/lang/String;

.field public final synthetic $shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/sharesheet/HatchShareLogContext;LX/16A;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/sharesheet/HatchShareLogContext;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;",
            "LX/16A<",
            "Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteLink:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$feedShareText:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$feedCaption:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteState$delegate:LX/16A;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareState$delegate:LX/16A;

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/lang/Number;

    .line 268435459
    .line 268435460
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->invoke(LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 30

    .line 0
    and-int/lit8 v1, p2, 0x3

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    const/4 v2, 0x0

    .line 4
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 5
    .line 6
    .line 7
    move-result v3

    .line 8
    and-int/lit8 v1, p2, 0x1

    .line 9
    .line 10
    move-object/from16 v0, p1

    .line 11
    .line 12
    invoke-interface {v0, v1, v3}, LX/2d4;->Afw(IZ)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1d

    .line 17
    .line 18
    move-object/from16 v3, p0

    .line 19
    .line 20
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteState$delegate:LX/16A;

    .line 21
    .line 22
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 27
    .line 28
    iget-boolean v1, v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 29
    .line 30
    if-nez v1, :cond_1c

    .line 31
    .line 32
    const v1, 0x566095bb

    .line 33
    .line 34
    .line 35
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 36
    .line 37
    .line 38
    sget-object v1, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 39
    .line 40
    invoke-virtual {v1}, Lcom/facebook/aura/utils/HatchUtil;->isSharingInviteToInstagramStoryEnabled()Z

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareState$delegate:LX/16A;

    .line 45
    .line 46
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    check-cast v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 51
    .line 52
    iget-object v1, v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->data:Lcom/facebook/aura/sharesheet/HatchShareSheetData;

    .line 53
    .line 54
    iget-object v1, v1, Lcom/facebook/aura/sharesheet/HatchShareSheetData;->destinations:LX/Ddn;

    .line 55
    .line 56
    invoke-static {v0, v1, v5}, LX/003;->A1P(LX/2d4;Ljava/lang/Object;Z)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    iget-object v4, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareState$delegate:LX/16A;

    .line 61
    .line 62
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v12

    .line 66
    if-nez v1, :cond_0

    .line 67
    .line 68
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 69
    .line 70
    if-ne v12, v1, :cond_4

    .line 71
    .line 72
    :cond_0
    invoke-interface {v4}, LX/16A;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 77
    .line 78
    iget-object v1, v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->data:Lcom/facebook/aura/sharesheet/HatchShareSheetData;

    .line 79
    .line 80
    iget-object v12, v1, Lcom/facebook/aura/sharesheet/HatchShareSheetData;->destinations:LX/Ddn;

    .line 81
    .line 82
    if-nez v5, :cond_3

    .line 83
    .line 84
    new-instance v6, Ljava/util/ArrayList;

    .line 85
    .line 86
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 87
    .line 88
    .line 89
    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 90
    .line 91
    .line 92
    move-result-object v5

    .line 93
    :cond_1
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    if-eqz v1, :cond_2

    .line 98
    .line 99
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v4

    .line 103
    sget-object v1, Lcom/facebook/aura/sharesheet/HatchShareDestination;->INSTAGRAM_STORIES:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 104
    .line 105
    if-eq v4, v1, :cond_1

    .line 106
    .line 107
    invoke-virtual {v6, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_2
    invoke-static {v6}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 112
    .line 113
    .line 114
    move-result-object v12

    .line 115
    :cond_3
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :cond_4
    check-cast v12, LX/Ddn;

    .line 119
    .line 120
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteLink:Ljava/lang/String;

    .line 121
    .line 122
    if-eqz v1, :cond_5

    .line 123
    .line 124
    const/4 v2, 0x1

    .line 125
    :cond_5
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareState$delegate:LX/16A;

    .line 126
    .line 127
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    check-cast v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;

    .line 132
    .line 133
    iget-object v13, v1, Lcom/facebook/aura/sharesheet/HatchShareSheetUiState;->loadingDestination:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 134
    .line 135
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->OS_SHARE_TO:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 136
    .line 137
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 138
    .line 139
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 140
    .line 141
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 142
    .line 143
    .line 144
    move-result v4

    .line 145
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 146
    .line 147
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 148
    .line 149
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    if-nez v4, :cond_6

    .line 154
    .line 155
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 156
    .line 157
    if-ne v1, v4, :cond_7

    .line 158
    .line 159
    :cond_6
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$1$1;

    .line 160
    .line 161
    invoke-direct {v1, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$1$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    :cond_7
    check-cast v1, LX/JDM;

    .line 168
    .line 169
    invoke-static {v9, v2, v8, v7, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 170
    .line 171
    .line 172
    move-result-object v14

    .line 173
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->INSTAGRAM_DIRECT:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 174
    .line 175
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 176
    .line 177
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 178
    .line 179
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 180
    .line 181
    .line 182
    move-result v4

    .line 183
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 184
    .line 185
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 186
    .line 187
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    if-nez v4, :cond_8

    .line 192
    .line 193
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 194
    .line 195
    if-ne v1, v4, :cond_9

    .line 196
    .line 197
    :cond_8
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$2$1;

    .line 198
    .line 199
    invoke-direct {v1, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$2$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 200
    .line 201
    .line 202
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 203
    .line 204
    .line 205
    :cond_9
    check-cast v1, LX/JDM;

    .line 206
    .line 207
    invoke-static {v9, v2, v8, v7, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 208
    .line 209
    .line 210
    move-result-object v15

    .line 211
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->INSTAGRAM_STORIES:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 212
    .line 213
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteState$delegate:LX/16A;

    .line 214
    .line 215
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    check-cast v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 220
    .line 221
    iget-object v8, v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyCardUri:Ljava/lang/String;

    .line 222
    .line 223
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 224
    .line 225
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 226
    .line 227
    .line 228
    move-result v4

    .line 229
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 230
    .line 231
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 232
    .line 233
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    if-nez v4, :cond_a

    .line 238
    .line 239
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 240
    .line 241
    if-ne v1, v4, :cond_b

    .line 242
    .line 243
    :cond_a
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$3$1;

    .line 244
    .line 245
    invoke-direct {v1, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$3$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 246
    .line 247
    .line 248
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 249
    .line 250
    .line 251
    :cond_b
    check-cast v1, LX/JDM;

    .line 252
    .line 253
    invoke-static {v9, v2, v8, v7, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 254
    .line 255
    .line 256
    move-result-object v16

    .line 257
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->FACEBOOK_STORIES:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 258
    .line 259
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$inviteState$delegate:LX/16A;

    .line 260
    .line 261
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v1

    .line 265
    check-cast v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 266
    .line 267
    iget-object v8, v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyCardUri:Ljava/lang/String;

    .line 268
    .line 269
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 270
    .line 271
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 272
    .line 273
    .line 274
    move-result v4

    .line 275
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 276
    .line 277
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 278
    .line 279
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    if-nez v4, :cond_c

    .line 284
    .line 285
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 286
    .line 287
    if-ne v1, v4, :cond_d

    .line 288
    .line 289
    :cond_c
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$4$1;

    .line 290
    .line 291
    invoke-direct {v1, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$4$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 292
    .line 293
    .line 294
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 295
    .line 296
    .line 297
    :cond_d
    check-cast v1, LX/JDM;

    .line 298
    .line 299
    invoke-static {v9, v2, v8, v7, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 300
    .line 301
    .line 302
    move-result-object v24

    .line 303
    sget-object v10, Lcom/facebook/aura/sharesheet/HatchShareDestination;->FACEBOOK_FEED:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 304
    .line 305
    iget-object v9, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$feedShareText:Ljava/lang/String;

    .line 306
    .line 307
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 308
    .line 309
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 310
    .line 311
    .line 312
    move-result v11

    .line 313
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$feedCaption:Ljava/lang/String;

    .line 314
    .line 315
    invoke-interface {v0, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    move-result v1

    .line 319
    or-int/2addr v11, v1

    .line 320
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 321
    .line 322
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 323
    .line 324
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$feedCaption:Ljava/lang/String;

    .line 325
    .line 326
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v4

    .line 330
    if-nez v11, :cond_e

    .line 331
    .line 332
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 333
    .line 334
    if-ne v4, v1, :cond_f

    .line 335
    .line 336
    :cond_e
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$5$1;

    .line 337
    .line 338
    invoke-direct {v4, v7, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$5$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 342
    .line 343
    .line 344
    :cond_f
    check-cast v4, LX/JDM;

    .line 345
    .line 346
    invoke-static {v10, v2, v9, v8, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 347
    .line 348
    .line 349
    move-result-object v25

    .line 350
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->WHATSAPP:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 351
    .line 352
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 353
    .line 354
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 355
    .line 356
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 357
    .line 358
    .line 359
    move-result v4

    .line 360
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 361
    .line 362
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 363
    .line 364
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    if-nez v4, :cond_10

    .line 369
    .line 370
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 371
    .line 372
    if-ne v1, v4, :cond_11

    .line 373
    .line 374
    :cond_10
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$6$1;

    .line 375
    .line 376
    invoke-direct {v1, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$6$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 377
    .line 378
    .line 379
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 380
    .line 381
    .line 382
    :cond_11
    check-cast v1, LX/JDM;

    .line 383
    .line 384
    invoke-static {v9, v2, v8, v7, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 385
    .line 386
    .line 387
    move-result-object v17

    .line 388
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->MESSENGER:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 389
    .line 390
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 391
    .line 392
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 393
    .line 394
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 399
    .line 400
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 401
    .line 402
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 403
    .line 404
    .line 405
    move-result-object v4

    .line 406
    if-nez v1, :cond_12

    .line 407
    .line 408
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 409
    .line 410
    if-ne v4, v1, :cond_13

    .line 411
    .line 412
    :cond_12
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$7$1;

    .line 413
    .line 414
    invoke-direct {v4, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$7$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 415
    .line 416
    .line 417
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 418
    .line 419
    .line 420
    :cond_13
    check-cast v4, LX/JDM;

    .line 421
    .line 422
    invoke-static {v9, v2, v8, v7, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 423
    .line 424
    .line 425
    move-result-object v18

    .line 426
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->THREADS:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 427
    .line 428
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 429
    .line 430
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 431
    .line 432
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 433
    .line 434
    .line 435
    move-result v1

    .line 436
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 437
    .line 438
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 439
    .line 440
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v4

    .line 444
    if-nez v1, :cond_14

    .line 445
    .line 446
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 447
    .line 448
    if-ne v4, v1, :cond_15

    .line 449
    .line 450
    :cond_14
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$8$1;

    .line 451
    .line 452
    invoke-direct {v4, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$8$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 453
    .line 454
    .line 455
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 456
    .line 457
    .line 458
    :cond_15
    check-cast v4, LX/JDM;

    .line 459
    .line 460
    invoke-static {v9, v2, v8, v7, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 461
    .line 462
    .line 463
    move-result-object v19

    .line 464
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->X:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 465
    .line 466
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 467
    .line 468
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 469
    .line 470
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 471
    .line 472
    .line 473
    move-result v1

    .line 474
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 475
    .line 476
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 477
    .line 478
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 479
    .line 480
    .line 481
    move-result-object v4

    .line 482
    if-nez v1, :cond_16

    .line 483
    .line 484
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 485
    .line 486
    if-ne v4, v1, :cond_17

    .line 487
    .line 488
    :cond_16
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$9$1;

    .line 489
    .line 490
    invoke-direct {v4, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$9$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 491
    .line 492
    .line 493
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 494
    .line 495
    .line 496
    :cond_17
    check-cast v4, LX/JDM;

    .line 497
    .line 498
    invoke-static {v9, v2, v8, v7, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 499
    .line 500
    .line 501
    move-result-object v20

    .line 502
    sget-object v9, Lcom/facebook/aura/sharesheet/HatchShareDestination;->OS_MESSAGES:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 503
    .line 504
    iget-object v8, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 505
    .line 506
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 507
    .line 508
    invoke-static {v0, v3}, LX/DRv;->A05(LX/2d4;Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;)Z

    .line 509
    .line 510
    .line 511
    move-result v1

    .line 512
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareViewModel:Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;

    .line 513
    .line 514
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 515
    .line 516
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v4

    .line 520
    if-nez v1, :cond_18

    .line 521
    .line 522
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 523
    .line 524
    if-ne v4, v1, :cond_19

    .line 525
    .line 526
    :cond_18
    new-instance v4, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$10$1;

    .line 527
    .line 528
    invoke-direct {v4, v6, v5}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$10$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareSheetViewModel;Landroid/content/Context;)V

    .line 529
    .line 530
    .line 531
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 532
    .line 533
    .line 534
    :cond_19
    check-cast v4, LX/JDM;

    .line 535
    .line 536
    invoke-static {v9, v2, v8, v7, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 537
    .line 538
    .line 539
    move-result-object v21

    .line 540
    sget-object v8, Lcom/facebook/aura/sharesheet/HatchShareDestination;->COPY_LINK:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 541
    .line 542
    iget-object v7, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$shareText:Ljava/lang/String;

    .line 543
    .line 544
    iget-object v6, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$onInviteUnavailable:Lkotlin/jvm/functions/Function0;

    .line 545
    .line 546
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 547
    .line 548
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 549
    .line 550
    .line 551
    move-result v9

    .line 552
    iget-object v1, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 553
    .line 554
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 555
    .line 556
    .line 557
    move-result v1

    .line 558
    or-int/2addr v9, v1

    .line 559
    iget-object v5, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$logContext:Lcom/facebook/aura/sharesheet/HatchShareLogContext;

    .line 560
    .line 561
    iget-object v4, v3, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6;->$context:Landroid/content/Context;

    .line 562
    .line 563
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 564
    .line 565
    .line 566
    move-result-object v1

    .line 567
    if-nez v9, :cond_1a

    .line 568
    .line 569
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 570
    .line 571
    if-ne v1, v3, :cond_1b

    .line 572
    .line 573
    :cond_1a
    new-instance v1, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;

    .line 574
    .line 575
    invoke-direct {v1, v5, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$6$11$1;-><init>(Lcom/facebook/aura/sharesheet/HatchShareLogContext;Landroid/content/Context;)V

    .line 576
    .line 577
    .line 578
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 579
    .line 580
    .line 581
    :cond_1b
    check-cast v1, LX/JDM;

    .line 582
    .line 583
    invoke-static {v8, v2, v7, v6, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt;->inviteShareAction(Lcom/facebook/aura/sharesheet/HatchShareDestination;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDM;)Lkotlin/jvm/functions/Function0;

    .line 584
    .line 585
    .line 586
    move-result-object v22

    .line 587
    const/16 v23, 0x0

    .line 588
    .line 589
    const p2, 0x1c800

    .line 590
    .line 591
    .line 592
    const/16 v26, 0x0

    .line 593
    .line 594
    move-object/from16 v27, v26

    .line 595
    .line 596
    move-object/from16 v28, v26

    .line 597
    .line 598
    move-object/from16 v29, v0

    .line 599
    .line 600
    move/from16 p0, v23

    .line 601
    .line 602
    move/from16 p1, v23

    .line 603
    .line 604
    invoke-static/range {v12 .. v32}, Lcom/facebook/aura/sharesheet/HatchShareDestinationsFooterKt;->HatchShareDestinationsFooter(LX/Ddn;Lcom/facebook/aura/sharesheet/HatchShareDestination;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;LX/2d4;III)V

    .line 605
    .line 606
    .line 607
    goto :goto_1

    .line 608
    :cond_1c
    const v1, 0x56aaa2f5

    .line 609
    .line 610
    .line 611
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 612
    .line 613
    .line 614
    :goto_1
    invoke-static {v0}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 615
    .line 616
    .line 617
    return-void

    .line 618
    :cond_1d
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 619
    .line 620
    .line 621
    return-void
.end method
