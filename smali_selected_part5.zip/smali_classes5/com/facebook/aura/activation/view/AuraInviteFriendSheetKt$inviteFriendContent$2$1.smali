.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $inviteLink:Ljava/lang/String;

.field public final synthetic $inviteState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shareText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteLink:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$shareText:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteState$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 7

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteState$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 7
    .line 8
    iget-boolean v6, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteLink:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    invoke-static {v0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v5

    .line 17
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteState$delegate:LX/16A;

    .line 18
    .line 19
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->shareText:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    const/4 v0, 0x0

    .line 34
    if-eqz v1, :cond_1

    .line 35
    .line 36
    :cond_0
    const/4 v0, 0x1

    .line 37
    :cond_1
    xor-int/lit8 v3, v0, 0x1

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$shareText:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->$inviteState$delegate:LX/16A;

    .line 46
    .line 47
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 52
    .line 53
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyCardUri:Ljava/lang/String;

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    const/4 v4, 0x1

    .line 58
    :cond_2
    const-string v0, "Invite sheet state loading="

    .line 59
    .line 60
    new-instance v1, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    const-string v0, " inviteLinkAvailable="

    .line 69
    .line 70
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v0, " serverShareTextAvailable="

    .line 77
    .line 78
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    const-string v0, " resolvedShareTextAvailable="

    .line 85
    .line 86
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v0, " storyCardAvailable="

    .line 93
    .line 94
    invoke-static {v0, v1, v4}, LX/602;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;Z)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    const-string v0, "HatchInviteShare"

    .line 99
    .line 100
    invoke-static {v0, v1}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1$invoke$$inlined$onDispose$1;

    .line 104
    .line 105
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 106
    .line 107
    .line 108
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteFriendContent$2$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
