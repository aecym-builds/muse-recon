.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $action:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $destination:Lcom/facebook/aura/sharesheet/HatchShareDestination;

.field public final synthetic $resolvedPayload:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/sharesheet/HatchShareDestination;LX/JDM;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/sharesheet/HatchShareDestination;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$destination:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$action:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$resolvedPayload:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$destination:Lcom/facebook/aura/sharesheet/HatchShareDestination;

    .line 1
    .line 2
    const-string v0, "Invite destination tapped destination="

    .line 3
    .line 4
    invoke-static {v0, v1}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-string v0, "HatchInviteShare"

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$action:LX/JDM;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$inviteShareAction$2;->$resolvedPayload:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    return-void
.end method
