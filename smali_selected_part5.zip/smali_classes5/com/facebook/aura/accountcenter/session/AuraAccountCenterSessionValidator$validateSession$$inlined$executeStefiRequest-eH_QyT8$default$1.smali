.class public final Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/DZ7<",
        "Lkotlin/Unit;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/DZ7;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/DZ7<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 1
    .line 2
    iget-object p0, v0, LX/Dcb;->A02:LX/DZG;

    .line 3
    .line 4
    const-class v0, Lkotlin/Unit;

    .line 5
    .line 6
    invoke-static {v0}, LX/DC8;->A00(Ljava/lang/Class;)LX/DQw;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0, p0}, LX/Dah;->A03(LX/Das;LX/DZG;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;->invoke()LX/DZ7;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
