.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/AHE;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;->$userSession:LX/AHE;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;->$userSession:LX/AHE;

    .line 10
    .line 11
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 12
    .line 13
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;-><init>(Landroid/content/Context;LX/AHE;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;->invoke()Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
