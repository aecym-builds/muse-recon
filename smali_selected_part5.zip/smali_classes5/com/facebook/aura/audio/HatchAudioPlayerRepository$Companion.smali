.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getActiveInstance()Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getInstance(LX/AHE;Landroid/content/Context;)Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;

    .line 4
    .line 5
    invoke-direct {p0, p2, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion$getInstance$1;-><init>(Landroid/content/Context;LX/AHE;)V

    .line 6
    .line 7
    .line 8
    const-class v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 9
    .line 10
    invoke-virtual {p1, v0, p0}, LX/0HF;->A03(Ljava/lang/Class;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 15
    .line 16
    return-object v0
.end method
