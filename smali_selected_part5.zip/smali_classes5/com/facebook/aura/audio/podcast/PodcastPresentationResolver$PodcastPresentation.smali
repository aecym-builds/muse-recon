.class public final Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;
.super LX/07H;
.source ""


# instance fields
.field public final coverPath:Ljava/lang/String;

.field public final episodeId:Ljava/lang/String;

.field public final episodeTitle:Ljava/lang/String;

.field public final feedTitle:Ljava/lang/String;

.field public final seriesId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p5, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getCoverPath()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEpisodeId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEpisodeTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFeedTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSeriesId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeTitle:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->feedTitle:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->coverPath:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->episodeId:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastPresentationResolver$PodcastPresentation;->seriesId:Ljava/lang/String;

    .line 37
    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    :cond_0
    add-int/2addr v1, v2

    .line 45
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
