.class public final Lcom/facebook/aura/audio/podcast/CachedCatalog;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final catalog:Lcom/facebook/aura/audio/podcast/PodcastCatalog;

.field public final fetchedAtMs:J


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/podcast/PodcastCatalog;J)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->catalog:Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 8
    .line 9
    iput-wide p2, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->fetchedAtMs:J

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getCatalog()Lcom/facebook/aura/audio/podcast/PodcastCatalog;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->catalog:Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFetchedAtMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->fetchedAtMs:J

    .line 1
    .line 2
    return-wide v0
.end method
