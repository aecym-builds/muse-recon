.class public final Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final CATALOG_TTL_MS:J = 0x7530L

.field public static final Companion:Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$Companion;

.field public static final TAG:Ljava/lang/String; = "PodcastCatalogRepository"


# instance fields
.field public volatile cached:Lcom/facebook/aura/audio/podcast/CachedCatalog;

.field public final fetchMutex:LX/3Hh;

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->Companion:Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->userSession:LX/AHE;

    .line 268435460
    .line 268435461
    new-instance v0, LX/DSP;

    .line 268435462
    .line 268435463
    invoke-direct {v0}, LX/DSP;-><init>()V

    .line 268435464
    .line 268435465
    .line 268435466
    iput-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->fetchMutex:LX/3Hh;

    .line 268435467
    .line 268435468
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;-><init>(LX/AHE;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$fetchAndCache(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->fetchAndCache(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method private final fetchAndCache(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/podcast/PodcastCatalog;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    const/4 v2, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v2, :cond_1

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_0
    new-instance v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;

    .line 32
    .line 33
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;-><init>(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 38
    .line 39
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_0
    new-instance v1, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$catalog$1;

    .line 49
    .line 50
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$catalog$1;-><init>(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;LX/2M4;)V

    .line 51
    .line 52
    .line 53
    iput v2, v5, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$fetchAndCache$1;->label:I

    .line 54
    .line 55
    invoke-static {v1, v5}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    if-ne v4, v3, :cond_3

    .line 60
    .line 61
    return-object v3

    .line 62
    :goto_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_3
    check-cast v4, Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 66
    .line 67
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 68
    .line 69
    .line 70
    move-result-wide v2

    .line 71
    new-instance v1, Lcom/facebook/aura/audio/podcast/CachedCatalog;

    .line 72
    .line 73
    invoke-direct {v1, v4, v2, v3}, Lcom/facebook/aura/audio/podcast/CachedCatalog;-><init>(Lcom/facebook/aura/audio/podcast/PodcastCatalog;J)V

    .line 74
    .line 75
    .line 76
    iput-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->cached:Lcom/facebook/aura/audio/podcast/CachedCatalog;

    .line 77
    .line 78
    return-object v4
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 79
    :catch_0
    move-exception v3

    .line 80
    const-string v2, "Failed to fetch podcast catalog"

    .line 81
    .line 82
    const-string v1, "PodcastCatalogRepository"

    .line 83
    .line 84
    invoke-static {v1, v2, v3}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 85
    .line 86
    .line 87
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->cached:Lcom/facebook/aura/audio/podcast/CachedCatalog;

    .line 88
    .line 89
    if-eqz v1, :cond_4

    .line 90
    .line 91
    iget-object v0, v1, Lcom/facebook/aura/audio/podcast/CachedCatalog;->catalog:Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 92
    .line 93
    :cond_4
    return-object v0

    .line 94
    :catch_1
    move-exception v0

    .line 95
    throw v0
.end method

.method private final freshCatalog()Lcom/facebook/aura/audio/podcast/PodcastCatalog;
    .locals 6

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->cached:Lcom/facebook/aura/audio/podcast/CachedCatalog;

    .line 1
    .line 2
    const/4 v5, 0x0

    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 6
    .line 7
    .line 8
    move-result-wide v3

    .line 9
    iget-wide v0, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->fetchedAtMs:J

    .line 10
    .line 11
    sub-long/2addr v3, v0

    .line 12
    const-wide/16 v1, 0x7530

    .line 13
    .line 14
    cmp-long v0, v3, v1

    .line 15
    .line 16
    if-gez v0, :cond_0

    .line 17
    .line 18
    iget-object v5, p0, Lcom/facebook/aura/audio/podcast/CachedCatalog;->catalog:Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 19
    .line 20
    :cond_0
    return-object v5
.end method

.method public static synthetic getCatalog$default(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;ZLX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->getCatalog(ZLX/2M4;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method


# virtual methods
.method public clearUserData()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->cached:Lcom/facebook/aura/audio/podcast/CachedCatalog;

    .line 2
    .line 3
    return-void
.end method

.method public final getCatalog(ZLX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/podcast/PodcastCatalog;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x2

    .line 25
    const/4 v3, 0x1

    .line 26
    const/4 v2, 0x0

    .line 27
    if-eqz v1, :cond_2

    .line 28
    .line 29
    if-eq v1, v3, :cond_4

    .line 30
    .line 31
    if-ne v1, v4, :cond_1

    .line 32
    .line 33
    iget-object v1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->L$0:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, LX/3Hh;

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    new-instance v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;

    .line 39
    .line 40
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;-><init>(Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;LX/2M4;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw v0

    .line 52
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    if-nez p1, :cond_3

    .line 56
    .line 57
    invoke-direct {p0}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->freshCatalog()Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz v0, :cond_3

    .line 62
    .line 63
    return-object v0

    .line 64
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->fetchMutex:LX/3Hh;

    .line 65
    .line 66
    iput-object v1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->L$0:Ljava/lang/Object;

    .line 67
    .line 68
    iput-boolean p1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->Z$0:Z

    .line 69
    .line 70
    iput v3, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->label:I

    .line 71
    .line 72
    invoke-interface {v1, v2, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    if-ne v0, v5, :cond_5

    .line 77
    .line 78
    return-object v5

    .line 79
    :cond_4
    iget-boolean p1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->Z$0:Z

    .line 80
    .line 81
    iget-object v1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->L$0:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v1, LX/3Hh;

    .line 84
    .line 85
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    :cond_5
    if-nez p1, :cond_6

    .line 89
    .line 90
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->freshCatalog()Lcom/facebook/aura/audio/podcast/PodcastCatalog;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    if-eqz v0, :cond_6

    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_6
    iput-object v1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->L$0:Ljava/lang/Object;

    .line 98
    .line 99
    iput-boolean p1, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->Z$0:Z

    .line 100
    .line 101
    iput v4, v6, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository$getCatalog$1;->label:I

    .line 102
    .line 103
    invoke-direct {p0, v6}, Lcom/facebook/aura/audio/podcast/PodcastCatalogRepository;->fetchAndCache(LX/2M4;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    if-ne v0, v5, :cond_7

    .line 108
    .line 109
    return-object v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 110
    :goto_1
    :try_start_1
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_7
    check-cast v0, Lcom/facebook/aura/audio/podcast/PodcastCatalog;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 114
    .line 115
    :goto_2
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    return-object v0

    .line 119
    :catchall_0
    move-exception v0

    .line 120
    goto :goto_3

    .line 121
    :catchall_1
    move-exception v0

    .line 122
    :goto_3
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    throw v0
.end method
