.class public abstract Lcom/facebook/aura/analytics/waterfall/SubsWaterfallEventWriterKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "SubsWaterfallEventWriter"


# direct methods
.method public static final logSubsWaterfallEvent(LX/ES4;LX/C5p;LX/C5o;LX/C6n;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/ES4<",
            "*>;",
            "LX/C5p;",
            "LX/C5o;",
            "LX/C6n;",
            "LX/JDM<",
            "-",
            "LX/C6p;",
            "+",
            "LX/C6p;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const-string v0, "subs_waterfall_event"

    .line 4
    .line 5
    invoke-interface {p0, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance p0, LX/C6o;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, LX/I8F;->A00:LX/I2T;

    .line 15
    .line 16
    invoke-interface {v0}, LX/I2T;->isSampled()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    :try_start_0
    const-string v0, "surface"

    .line 23
    .line 24
    invoke-virtual {p0, p1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const-string v0, "event"

    .line 28
    .line 29
    invoke-virtual {p0, p2, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const-string v0, "product_type"

    .line 33
    .line 34
    invoke-virtual {p0, p3, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-interface {p4, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, LX/C6p;

    .line 42
    .line 43
    invoke-interface {v0}, LX/B9M;->AQ5()V

    .line 44
    .line 45
    .line 46
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    :catch_0
    move-exception p1

    .line 48
    invoke-virtual {p2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    const-string v0, "Failed to log "

    .line 53
    .line 54
    invoke-static {v0, p0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    const-string v0, "SubsWaterfallEventWriter"

    .line 59
    .line 60
    invoke-static {v0, p0, p1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :cond_0
    return-void
.end method

.method public static final subsWaterfallTier(J)LX/C6m;
    .locals 7

    .line 0
    invoke-static {}, LX/C6m;->values()[LX/C6m;

    .line 1
    .line 2
    .line 3
    move-result-object v6

    .line 4
    array-length v5, v6

    .line 5
    const/4 v4, 0x0

    .line 6
    :goto_0
    if-ge v4, v5, :cond_0

    .line 7
    .line 8
    aget-object v3, v6, v4

    .line 9
    .line 10
    iget-wide v1, v3, LX/C6m;->mValue:J

    .line 11
    .line 12
    cmp-long v0, v1, p0

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    add-int/lit8 v4, v4, 0x1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v3, 0x0

    .line 20
    :cond_1
    return-object v3
.end method
