.class public final Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/C6p;",
        "LX/C6p;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $entrypoint:LX/8OS;

.field public final synthetic $event:LX/C5o;

.field public final synthetic $eventTarget:LX/C5n;

.field public final synthetic $selectedTier:Ljava/lang/Long;

.field public final synthetic $stage:LX/EKV;

.field public final synthetic $stringExtrasMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $surface:LX/C5p;

.field public final synthetic this$0:Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;Ljava/lang/Long;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;",
            "LX/C5p;",
            "LX/EKV;",
            "LX/C5o;",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "LX/C5n;",
            "Ljava/lang/Long;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->this$0:Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$surface:LX/C5p;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$stage:LX/EKV;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$event:LX/C5o;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$entrypoint:LX/8OS;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$stringExtrasMap:Ljava/util/Map;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$eventTarget:LX/C5n;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$selectedTier:Ljava/lang/Long;

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(LX/C6p;)LX/C6p;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$stage:LX/EKV;

    .line 5
    .line 6
    move-object v3, p1

    .line 7
    check-cast v3, LX/I8F;

    .line 8
    .line 9
    const-string v0, "stage"

    .line 10
    .line 11
    invoke-virtual {v3, v1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$entrypoint:LX/8OS;

    .line 15
    .line 16
    const-string v0, "entrypoint"

    .line 17
    .line 18
    invoke-virtual {v3, v1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v2, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$stringExtrasMap:Ljava/util/Map;

    .line 22
    .line 23
    const-string v1, "event_data"

    .line 24
    .line 25
    iget-object v0, v3, LX/I8F;->A00:LX/I2T;

    .line 26
    .line 27
    invoke-interface {v0, v1, v2}, LX/I2T;->A3g(Ljava/lang/String;Ljava/util/Map;)V

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$eventTarget:LX/C5n;

    .line 31
    .line 32
    const-string v0, "event_target"

    .line 33
    .line 34
    invoke-virtual {v3, v1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->$selectedTier:Ljava/lang/Long;

    .line 38
    .line 39
    if-eqz v0, :cond_0

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 42
    .line 43
    .line 44
    move-result-wide v0

    .line 45
    invoke-static {v0, v1}, Lcom/facebook/aura/analytics/waterfall/SubsWaterfallEventWriterKt;->subsWaterfallTier(J)LX/C6m;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    :goto_0
    const-string v0, "selected_tier"

    .line 50
    .line 51
    invoke-virtual {v3, v1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object p1

    .line 55
    :cond_0
    const/4 v1, 0x0

    .line 56
    goto :goto_0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/C6p;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;->invoke(LX/C6p;)LX/C6p;

    .line 268435459
    .line 268435460
    .line 268435461
    return-object p1
.end method
