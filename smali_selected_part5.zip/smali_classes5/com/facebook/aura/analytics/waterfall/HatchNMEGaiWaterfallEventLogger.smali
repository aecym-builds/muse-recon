.class public final Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final logger:LX/ES4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ES4<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 536870912
    const/4 v1, 0x0

    .line 536870913
    const/4 v0, 0x1

    .line 536870914
    invoke-direct {p0, v1, v0, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;-><init>(LX/ES4;ILX/04f;)V

    .line 536870915
    .line 536870916
    .line 536870917
    return-void
.end method

.method public constructor <init>(LX/ES4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/ES4<",
            "*>;)V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;->logger:LX/ES4;

    .line 268435464
    .line 268435465
    return-void
.end method

.method public synthetic constructor <init>(LX/ES4;ILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;-><init>(LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static final synthetic access$logDebugInfo(Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;)V
    .locals 0

    .line 0
    return-void
.end method

.method private final logDebugInfo(LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/C5p;",
            "LX/EKV;",
            "LX/C5o;",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "LX/C5n;",
            ")V"
        }
    .end annotation

    .line 0
    return-void
.end method

.method public static synthetic logDebugInfo$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;ILjava/lang/Object;)V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic logEvent$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;Ljava/lang/Long;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p8, 0x10

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p5, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x20

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p6, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p8, 0x40

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p7, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p7}, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;->logEvent(LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;Ljava/lang/Long;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final logEvent(LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;Ljava/lang/Long;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/C5p;",
            "LX/EKV;",
            "LX/C5o;",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "LX/C5n;",
            "Ljava/lang/Long;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;->logger:LX/ES4;

    .line 4
    .line 5
    sget-object v0, LX/C6n;->A01:LX/C6n;

    .line 6
    .line 7
    new-instance v2, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;

    .line 8
    .line 9
    invoke-direct/range {v2 .. v10}, Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger$logEvent$1;-><init>(Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLogger;LX/C5p;LX/EKV;LX/C5o;LX/8OS;Ljava/util/Map;LX/C5n;Ljava/lang/Long;)V

    .line 10
    .line 11
    .line 12
    invoke-static {v1, p1, p3, v0, v2}, Lcom/facebook/aura/analytics/waterfall/SubsWaterfallEventWriterKt;->logSubsWaterfallEvent(LX/ES4;LX/C5p;LX/C5o;LX/C6n;LX/JDM;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
