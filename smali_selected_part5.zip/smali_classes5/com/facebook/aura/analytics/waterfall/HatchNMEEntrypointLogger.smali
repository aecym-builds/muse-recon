.class public final Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchNMEEntrypointLogger"


# instance fields
.field public final logger:LX/ES4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ES4<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->Companion:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 536870912
    const/4 v1, 0x0

    .line 536870913
    const/4 v0, 0x1

    .line 536870914
    invoke-direct {p0, v1, v0, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;-><init>(LX/ES4;ILX/04f;)V

    .line 536870915
    .line 536870916
    .line 536870917
    return-void
.end method

.method public constructor <init>(LX/ES4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/ES4<",
            "*>;)V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logger:LX/ES4;

    .line 268435464
    .line 268435465
    return-void
.end method

.method public synthetic constructor <init>(LX/ES4;ILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;-><init>(LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic logClick$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;LX/8OS;Ljava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logClick(LX/8OS;Ljava/util/Map;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logDismiss$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;LX/8OS;Ljava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logDismiss(LX/8OS;Ljava/util/Map;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final logEntrypointEvent(LX/EJ1;LX/8OS;Ljava/util/Map;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/EJ1;",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const-string v3, "HatchNMEEntrypointLogger"

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logger:LX/ES4;

    .line 3
    .line 4
    const-string v0, "nme_entrypoint_event"

    .line 5
    .line 6
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    invoke-interface {v2}, LX/I2T;->isSampled()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    :try_start_0
    const-string v0, "event"

    .line 17
    .line 18
    invoke-interface {v2, p1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "entrypoint"

    .line 22
    .line 23
    invoke-interface {v2, p2, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sget-object v1, LX/C6q;->A01:LX/C6q;

    .line 27
    .line 28
    const-string v0, "product_type"

    .line 29
    .line 30
    invoke-interface {v2, v1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    const/16 v0, 0x31

    .line 34
    .line 35
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-interface {v2, v0, p3}, LX/I2T;->A3g(Ljava/lang/String;Ljava/util/Map;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v2}, LX/I2T;->AQ5()V

    .line 43
    .line 44
    .line 45
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    :catch_0
    move-exception v1

    .line 47
    const-string v0, "Failed to log entrypoint event"

    .line 48
    .line 49
    invoke-static {v3, v0, v1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    return v0

    .line 54
    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 55
    return v0
.end method

.method public static synthetic logEntrypointEvent$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;LX/EJ1;LX/8OS;Ljava/util/Map;ILjava/lang/Object;)Z
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logEntrypointEvent(LX/EJ1;LX/8OS;Ljava/util/Map;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public static synthetic logImpression$default(Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;LX/8OS;Ljava/util/Map;ILjava/lang/Object;)Z
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logImpression(LX/8OS;Ljava/util/Map;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method


# virtual methods
.method public final logClick(LX/8OS;Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, LX/EJ1;->A01:LX/EJ1;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logEntrypointEvent(LX/EJ1;LX/8OS;Ljava/util/Map;)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final logDismiss(LX/8OS;Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, LX/EJ1;->A02:LX/EJ1;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logEntrypointEvent(LX/EJ1;LX/8OS;Ljava/util/Map;)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final logImpression(LX/8OS;Ljava/util/Map;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/8OS;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, LX/EJ1;->A03:LX/EJ1;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logEntrypointEvent(LX/EJ1;LX/8OS;Ljava/util/Map;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0
.end method
