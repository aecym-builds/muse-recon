.class public final Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/analytics/AuraAnalyticsHolder;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/analytics/AuraAnalyticsHolder;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->access$getAppAnalyticsLogger(Lcom/facebook/aura/analytics/AuraAnalytics;)LX/H4A;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/analytics/AuraAnalyticsHolder;

    .line 7
    .line 8
    invoke-direct {v0, p0}, Lcom/facebook/aura/analytics/AuraAnalyticsHolder;-><init>(LX/H4A;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;->invoke()Lcom/facebook/aura/analytics/AuraAnalyticsHolder;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
