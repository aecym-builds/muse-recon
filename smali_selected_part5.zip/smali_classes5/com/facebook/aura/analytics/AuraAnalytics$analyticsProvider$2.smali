.class public final Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;
    .locals 1

    .line 0
    const-string p0, "All"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {p0, v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 268435456
    const-string p0, "All"

    .line 268435457
    .line 268435458
    const/4 v0, 0x0

    .line 268435459
    invoke-static {p0, v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 268435460
    .line 268435461
    .line 268435462
    move-result-object v0

    .line 268435463
    return-object v0
.end method
