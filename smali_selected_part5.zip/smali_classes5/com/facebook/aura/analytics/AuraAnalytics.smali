.class public final Lcom/facebook/aura/analytics/AuraAnalytics;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

.field public static final analyticsProvider$delegate:Lkotlin/Lazy;

.field public static final deviceInstance$delegate:Lkotlin/Lazy;

.field public static final ranOnce:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static singletonInstanceBackingField:LX/H4A;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$analyticsProvider$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 17
    .line 18
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 19
    .line 20
    .line 21
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->ranOnce:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;

    .line 24
    .line 25
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->deviceInstance$delegate:Lkotlin/Lazy;

    .line 30
    .line 31
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getAnalyticsProvider(Lcom/facebook/aura/analytics/AuraAnalytics;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 7
    .line 8
    return-object p0
.end method

.method public static final synthetic access$getAppAnalyticsLogger(Lcom/facebook/aura/analytics/AuraAnalytics;)LX/H4A;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getAppAnalyticsLogger()LX/H4A;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final getAnalyticsProvider()Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 7
    .line 8
    return-object p0
.end method

.method private final getAppAnalyticsLogger()LX/H4A;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;->getAppAnalyticsLogger()LX/H4A;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_0
    const-string p0, "Required value was null."

    .line 18
    .line 19
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw v0
.end method


# virtual methods
.method public final getDeviceInstance()LX/H4A;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->deviceInstance$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/H4A;

    .line 7
    .line 8
    return-object p0
.end method

.method public final getInstance()LX/H4A;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSessionUnchecked()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    if-eqz v2, :cond_2

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$instance$analyticsInstance$1;

    .line 9
    .line 10
    const-class v0, Lcom/facebook/aura/analytics/AuraAnalyticsHolder;

    .line 11
    .line 12
    invoke-virtual {v2, v0, v1}, LX/0HF;->A03(Ljava/lang/Class;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/analytics/AuraAnalyticsHolder;

    .line 17
    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    iget-object v2, v0, Lcom/facebook/aura/analytics/AuraAnalyticsHolder;->instance:LX/H4A;

    .line 21
    .line 22
    if-eqz v2, :cond_2

    .line 23
    .line 24
    :cond_0
    :goto_0
    sget-object v1, Lcom/facebook/aura/analytics/AuraAnalytics;->ranOnce:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/analytics/AuraEarlyAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraEarlyAnalytics;

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Lcom/facebook/aura/analytics/AuraEarlyAnalytics;->onInitialized$fbandroid_express_aura_java_com_facebook_aura_analytics_analytics(LX/H4A;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    return-object v2

    .line 39
    :cond_2
    sget-object v2, Lcom/facebook/aura/analytics/AuraAnalytics;->singletonInstanceBackingField:LX/H4A;

    .line 40
    .line 41
    if-nez v2, :cond_0

    .line 42
    .line 43
    invoke-direct {p0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getAppAnalyticsLogger()LX/H4A;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    sput-object v2, Lcom/facebook/aura/analytics/AuraAnalytics;->singletonInstanceBackingField:LX/H4A;

    .line 48
    .line 49
    goto :goto_0
.end method

.method public final notifyUserConsentChanged()V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 7
    .line 8
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->notifyUserConsentChanged()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
