.class public final Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static sCacheId:I = -0x1

.field public static sIsNeeded:Ljava/lang/Boolean;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static isNeeded(ILjava/util/concurrent/atomic/AtomicInteger;LX/BrY;)Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sIsNeeded:Ljava/lang/Boolean;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    sget v0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sCacheId:I

    .line 5
    .line 6
    if-eq v0, p0, :cond_1

    .line 7
    .line 8
    :cond_0
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    :try_start_0
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sput-object v1, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sIsNeeded:Ljava/lang/Boolean;

    .line 17
    .line 18
    sput p0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sCacheId:I

    .line 19
    .line 20
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    :catch_0
    move-exception v0

    .line 22
    :try_start_1
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 23
    :catchall_0
    move-exception v0

    .line 24
    throw v0

    .line 25
    :cond_1
    :goto_0
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    return v0
.end method

.method public static peekIsNeeded(I)Ljava/lang/Boolean;
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sCacheId:I

    .line 1
    .line 2
    if-eq v0, p0, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    return-object v0

    .line 6
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitchCacheWrapper;->sIsNeeded:Ljava/lang/Boolean;

    .line 7
    .line 8
    return-object v0
.end method
