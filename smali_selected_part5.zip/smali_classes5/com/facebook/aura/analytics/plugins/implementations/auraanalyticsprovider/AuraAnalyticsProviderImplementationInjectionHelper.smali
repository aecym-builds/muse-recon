.class public Lcom/facebook/aura/analytics/plugins/implementations/auraanalyticsprovider/AuraAnalyticsProviderImplementationInjectionHelper;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getImplementationInstance()Lcom/facebook/aura/analytics/plugins/implementations/auraanalyticsprovider/AuraAnalyticsProviderImplementation;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/implementations/auraanalyticsprovider/AuraAnalyticsProviderImplementation;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method
