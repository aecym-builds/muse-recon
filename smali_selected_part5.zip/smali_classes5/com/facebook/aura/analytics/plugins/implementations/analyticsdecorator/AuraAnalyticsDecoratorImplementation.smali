.class public final Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Companion;

.field public static final TIME_SPENT_APP_UID:Ljava/lang/String; = "app_uid"

.field public static final TIME_SPENT_IS_CVM:Ljava/lang/String; = "is_cvm"

.field public static final TIME_SPENT_PARAM_APP_IN_BACKGROUND:Ljava/lang/String; = "app_in_background"

.field public static final TIME_SPENT_VM_HOSTNAME:Ljava/lang/String; = "vm_hostname"

.field public static final TIME_SPENT_VM_ID:Ljava/lang/String; = "vm_id"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->Companion:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final decorate(Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator<",
            "TT;>;TT;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    const-string v1, "app_uid"

    .line 7
    .line 8
    invoke-direct {p0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->getAppUid()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p1, p2, v1, v0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;->decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v1, "app_in_background"

    .line 16
    .line 17
    invoke-direct {p0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->isAppInBackground()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {p1, p2, v1, v0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;->decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string v1, "vm_id"

    .line 25
    .line 26
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {p1, p2, v1, v0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;->decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v1, "vm_hostname"

    .line 32
    .line 33
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {p1, p2, v1, v0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;->decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    const-string v1, "is_cvm"

    .line 39
    .line 40
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 41
    .line 42
    invoke-virtual {p1, p2, v1, v0}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;->decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method private final getAppUid()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSession()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    check-cast p0, LX/AHu;

    .line 9
    .line 10
    iget-object p0, p0, LX/AHu;->A01:Ljava/lang/String;

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    const/4 p0, 0x0

    .line 14
    return-object p0
.end method

.method private final isAppInBackground()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForeground()Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    xor-int/lit8 p0, p0, 0x1

    .line 7
    .line 8
    invoke-static {p0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method


# virtual methods
.method public final decorateTimeSpentAppStateEvent(LX/H49;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$EventBuilderDecorator;->INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$EventBuilderDecorator;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->decorate(Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final decorateTimeSpentInteractionEvent(LX/CkS;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;->INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->decorate(Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final decorateTimeSpentNavigationEvent(LX/H49;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$EventBuilderDecorator;->INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$EventBuilderDecorator;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation;->decorate(Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onTimeSpentAppBackgrounded()V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentBackground()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onTimeSpentAppForegrounded()V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentForeground()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onTimeSpentBitArray(J[II)V
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentBitArray(J[II)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onTimeSpentNavigation()V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentNavigation()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
