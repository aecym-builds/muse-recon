.class public final Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;
.super Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$Decorator<",
        "LX/CkS;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;->INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public decorate(LX/CkS;Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 0

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    if-eqz p3, :cond_0

    .line 268435460
    .line 268435461
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result p0

    .line 268435465
    invoke-interface {p1, p2, p0}, LX/CkS;->addParameter(Ljava/lang/String;Z)LX/CkS;

    .line 268435466
    .line 268435467
    .line 268435468
    :cond_0
    return-void
.end method

.method public decorate(LX/CkS;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 805306368
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 805306369
    .line 805306370
    .line 805306371
    if-eqz p3, :cond_0

    .line 805306372
    .line 805306373
    invoke-interface {p1, p2, p3}, LX/CkS;->addParameter(Ljava/lang/String;Ljava/lang/String;)LX/CkS;

    .line 805306374
    .line 805306375
    .line 805306376
    :cond_0
    return-void
.end method

.method public bridge synthetic decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 0

    .line 536870912
    check-cast p1, LX/CkS;

    .line 536870913
    .line 536870914
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;->decorate(LX/CkS;Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 536870915
    .line 536870916
    .line 536870917
    return-void
.end method

.method public bridge synthetic decorate(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    check-cast p1, LX/CkS;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/plugins/implementations/analyticsdecorator/AuraAnalyticsDecoratorImplementation$TimeSpentLoggerEventDecorator;->decorate(LX/CkS;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
