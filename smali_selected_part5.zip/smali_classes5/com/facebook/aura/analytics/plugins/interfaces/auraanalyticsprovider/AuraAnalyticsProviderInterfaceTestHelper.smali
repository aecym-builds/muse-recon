.class public final Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;

.field public static sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static checkTestRunner(Ljava/lang/String;)V
    .locals 3

    .line 0
    const-string v0, "buck.testrunner_classes"

    .line 1
    .line 2
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const-string v2, "java.class.path"

    .line 9
    .line 10
    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v0, "testrunner_classes"

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const-string v0, "test_config_properties.jar"

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    :try_start_0
    const-string v0, "com.facebook.testing.uitest.runner.UITestRunner"

    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    return-void
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    :catch_0
    const-string v0, " can only be used in tests!"

    .line 41
    .line 42
    invoke-static {p0, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    new-instance v0, Ljava/lang/RuntimeException;

    .line 47
    .line 48
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw v0

    .line 52
    :cond_0
    return-void
.end method

.method public static getDelegateFactoryForTesting()Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    sput-object v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;

    .line 4
    .line 5
    return-object v1
.end method

.method public static getDelegateForTesting()Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    sput-object v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 4
    .line 5
    return-object v1
.end method

.method public static setDelegateFactoryForTesting(Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const-string v0, "AuraAnalyticsProviderInterfaceTestHelper.setDelegateFactoryForTesting()"

    .line 5
    .line 6
    invoke-static {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->checkTestRunner(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    const-string p0, "Already set a delegate in AuraAnalyticsProviderInterfaceTestHelper. Delegate and DelegateFactory are not allowed to be configured at the same time."

    .line 13
    .line 14
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw v0
.end method

.method public static setDelegateForTesting(Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const-string v0, "AuraAnalyticsProviderInterfaceTestHelper.setDelegateForTesting()"

    .line 5
    .line 6
    invoke-static {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->checkTestRunner(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    const-string p0, "Already set a delegateFactory in AuraAnalyticsProviderInterfaceTestHelper. Delegate and DelegateFactory are not allowed to be configured at the same time."

    .line 13
    .line 14
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw v0
.end method
