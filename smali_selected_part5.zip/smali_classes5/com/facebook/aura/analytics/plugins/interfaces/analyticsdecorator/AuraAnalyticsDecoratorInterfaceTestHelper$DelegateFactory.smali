.class public interface abstract Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper$DelegateFactory;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;
.end method
