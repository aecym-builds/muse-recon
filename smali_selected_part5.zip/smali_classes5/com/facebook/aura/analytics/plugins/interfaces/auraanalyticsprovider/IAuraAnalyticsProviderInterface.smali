.class public interface abstract Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getAppAnalyticsLogger()LX/H4A;
.end method

.method public abstract getDeviceAnalyticsLogger()LX/H4A;
.end method

.method public abstract notifyUserConsentChanged()V
.end method
