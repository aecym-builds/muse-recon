.class public Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$AuraAnalyticsDecorator;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static newBuilder()Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;
    .locals 2

    .line 0
    const-string v1, "AuraAnalyticsDecorator"

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;

    .line 3
    .line 4
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method
