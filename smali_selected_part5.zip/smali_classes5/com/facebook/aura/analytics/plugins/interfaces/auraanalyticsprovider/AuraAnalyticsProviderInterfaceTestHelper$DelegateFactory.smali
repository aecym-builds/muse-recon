.class public interface abstract Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterfaceTestHelper$DelegateFactory;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;
.end method
