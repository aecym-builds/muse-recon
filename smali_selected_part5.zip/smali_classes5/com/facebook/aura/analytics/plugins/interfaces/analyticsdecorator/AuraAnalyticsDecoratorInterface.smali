.class public final Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;


# direct methods
.method public static bridge synthetic -$$Nest$smcreate(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public constructor <init>(Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 4
    .line 5
    return-void
.end method

.method public static create(Ljava/lang/String;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p0, v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 268435458
    .line 268435459
    .line 268435460
    move-result-object v0

    .line 268435461
    return-object v0
.end method

.method public static create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    sput-object v1, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper;->sOneTimeUseDelegateForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper$DelegateFactory;

    .line 6
    .line 7
    sput-object v1, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper;->sOneTimeUseDelegateFactoryForTesting:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper$DelegateFactory;

    .line 8
    .line 9
    if-nez v2, :cond_0

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-interface {v0, p0, p1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterfaceTestHelper$DelegateFactory;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    :cond_0
    :goto_0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 18
    .line 19
    invoke-direct {v0, v2}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;-><init>(Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;)V

    .line 20
    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_1
    const/4 v0, 0x1

    .line 24
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    new-instance v2, LX/Ccs;

    .line 28
    .line 29
    invoke-direct {v2, p1, p0}, LX/Ccs;-><init>(LX/BrY;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0
.end method

.method public static newBuilder(Ljava/lang/String;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;

    .line 1
    .line 2
    invoke-direct {v0, p0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;-><init>(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method


# virtual methods
.method public decorateTimeSpentAppStateEvent(LX/H49;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0, p1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->decorateTimeSpentAppStateEvent(LX/H49;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public decorateTimeSpentInteractionEvent(LX/CkS;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0, p1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->decorateTimeSpentInteractionEvent(LX/CkS;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public decorateTimeSpentNavigationEvent(LX/H49;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0, p1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->decorateTimeSpentNavigationEvent(LX/H49;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onTimeSpentAppBackgrounded()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->onTimeSpentAppBackgrounded()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onTimeSpentAppForegrounded()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->onTimeSpentAppForegrounded()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onTimeSpentBitArray(J[II)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->onTimeSpentBitArray(J[II)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onTimeSpentNavigation()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    invoke-interface {p0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;->onTimeSpentNavigation()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
