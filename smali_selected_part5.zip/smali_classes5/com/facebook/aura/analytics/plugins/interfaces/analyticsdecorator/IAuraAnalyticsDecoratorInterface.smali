.class public interface abstract Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/IAuraAnalyticsDecoratorInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract decorateTimeSpentAppStateEvent(LX/H49;)V
.end method

.method public abstract decorateTimeSpentInteractionEvent(LX/CkS;)V
.end method

.method public abstract decorateTimeSpentNavigationEvent(LX/H49;)V
.end method

.method public abstract onTimeSpentAppBackgrounded()V
.end method

.method public abstract onTimeSpentAppForegrounded()V
.end method

.method public abstract onTimeSpentBitArray(J[II)V
.end method

.method public abstract onTimeSpentNavigation()V
.end method
