.class public interface abstract Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract build()Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
.end method

.method public abstract setCustomLogger(LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;
.end method
