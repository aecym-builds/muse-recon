.class public Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$BuilderImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$Builder;


# instance fields
.field public mCustomLogger:LX/BrY;

.field public final mRegistryName:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$BuilderImpl;->mRegistryName:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public build()Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$BuilderImpl;->mRegistryName:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$BuilderImpl;->mCustomLogger:LX/BrY;

    .line 3
    .line 4
    invoke-static {v1, v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->create(Ljava/lang/String;LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public setCustomLogger(LX/BrY;)Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$Builder;
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface$BuilderImpl;->mCustomLogger:LX/BrY;

    .line 1
    .line 2
    return-object p0
.end method
