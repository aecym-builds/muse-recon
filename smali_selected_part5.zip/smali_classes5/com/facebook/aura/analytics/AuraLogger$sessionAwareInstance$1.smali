.class public final Lcom/facebook/aura/analytics/AuraLogger$sessionAwareInstance$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/ES4;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/ES4<",
        "LX/EXf;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public acquireEvent(Ljava/lang/String;)LX/I2T;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "LX/I2T<",
            "*>;"
        }
    .end annotation

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 268435461
    .line 268435462
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object p0

    .line 268435466
    invoke-interface {p0, p1}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object p0

    .line 268435470
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 268435471
    .line 268435472
    .line 268435473
    return-object p0
.end method

.method public acquireEvent(Ljava/lang/String;LX/EXf;)LX/I2T;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/EXf;",
            ")",
            "LX/I2T<",
            "*>;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 4
    .line 5
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-interface {p0, p1, p2}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    return-object p0
.end method

.method public bridge synthetic acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;
    .locals 0

    .line 536870912
    check-cast p2, LX/EXf;

    .line 536870913
    .line 536870914
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/AuraLogger$sessionAwareInstance$1;->acquireEvent(Ljava/lang/String;LX/EXf;)LX/I2T;

    .line 536870915
    .line 536870916
    .line 536870917
    move-result-object p0

    .line 536870918
    return-object p0
.end method
