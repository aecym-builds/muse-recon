.class public final Lcom/facebook/aura/analytics/AuraLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

.field public static final deviceInstance$delegate:Lkotlin/Lazy;

.field public static final instanceInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final sessionAwareInstance:LX/ES4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation
.end field

.field public static singletonInstanceBackingField:LX/ES4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 9
    .line 10
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 11
    .line 12
    .line 13
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger;->instanceInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/analytics/AuraLogger$sessionAwareInstance$1;

    .line 16
    .line 17
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraLogger$sessionAwareInstance$1;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger;->sessionAwareInstance:LX/ES4;

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;

    .line 23
    .line 24
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger;->deviceInstance$delegate:Lkotlin/Lazy;

    .line 29
    .line 30
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getDeviceInstance()LX/ES4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->deviceInstance$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/ES4;

    .line 7
    .line 8
    return-object p0
.end method

.method public final getInstance()LX/ES4;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSessionUnchecked()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p0, :cond_1

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;

    .line 9
    .line 10
    const-class v0, Lcom/facebook/aura/analytics/AuraLoggerHolder;

    .line 11
    .line 12
    invoke-virtual {p0, v0, v1}, LX/0HF;->A03(Ljava/lang/Class;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/analytics/AuraLoggerHolder;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    iget-object p0, v0, Lcom/facebook/aura/analytics/AuraLoggerHolder;->logger:LX/ES4;

    .line 21
    .line 22
    if-eqz p0, :cond_1

    .line 23
    .line 24
    :cond_0
    :goto_0
    sget-object v1, Lcom/facebook/aura/analytics/AuraLogger;->instanceInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->singletonInstanceBackingField:LX/ES4;

    .line 32
    .line 33
    if-nez p0, :cond_0

    .line 34
    .line 35
    const-string v0, "AuraLogger"

    .line 36
    .line 37
    invoke-static {v0}, LX/I6a;->A00(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 41
    .line 42
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    new-instance p0, LX/Der;

    .line 47
    .line 48
    invoke-direct {p0, v0}, LX/Der;-><init>(LX/H4A;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    .line 50
    .line 51
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 52
    .line 53
    .line 54
    sput-object p0, Lcom/facebook/aura/analytics/AuraLogger;->singletonInstanceBackingField:LX/ES4;

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :catchall_0
    move-exception v0

    .line 58
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 59
    .line 60
    .line 61
    throw v0
.end method

.method public final getSessionAwareInstance()LX/ES4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->sessionAwareInstance:LX/ES4;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isInitialized()Z
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraLogger;->instanceInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method
