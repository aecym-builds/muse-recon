.class public final Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CP0;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $isAppForeground:Z

.field public final synthetic $vmState:LX/9sE;


# direct methods
.method public constructor <init>(LX/9sE;Z)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;->$vmState:LX/9sE;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;->$isAppForeground:Z

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CP0;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;->invoke(LX/CP0;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/CP0;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;->$vmState:LX/9sE;

    .line 5
    .line 6
    if-eqz v2, :cond_0

    .line 7
    .line 8
    move-object v1, p1

    .line 9
    check-cast v1, LX/I8F;

    .line 10
    .line 11
    const-string v0, "vm_state"

    .line 12
    .line 13
    invoke-virtual {v1, v2, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;->$isAppForeground:Z

    .line 17
    .line 18
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    check-cast p1, LX/I8F;

    .line 23
    .line 24
    const-string v1, "is_app_foreground"

    .line 25
    .line 26
    iget-object v0, p1, LX/I8F;->A00:LX/I2T;

    .line 27
    .line 28
    invoke-interface {v0, v1, v2}, LX/I2T;->A3P(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
