.class public abstract synthetic Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I

.field public static final synthetic $EnumSwitchMapping$2:[I

.field public static final synthetic $EnumSwitchMapping$3:[I

.field public static final synthetic $EnumSwitchMapping$4:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;->values()[Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;->ATTEMPT:Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;

    .line 9
    .line 10
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    :catch_0
    const/4 v2, 0x2

    .line 14
    :try_start_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;->SUCCESS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;

    .line 15
    .line 16
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 17
    .line 18
    .line 19
    :catch_1
    const/4 v4, 0x3

    .line 20
    :try_start_2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;->FAILURE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;

    .line 21
    .line 22
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 23
    .line 24
    .line 25
    :catch_2
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 26
    .line 27
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->values()[Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    array-length v0, v0

    .line 32
    new-array v1, v0, [I

    .line 33
    .line 34
    :try_start_3
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 35
    .line 36
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 37
    .line 38
    .line 39
    :catch_3
    :try_start_4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 40
    .line 41
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 42
    .line 43
    .line 44
    :catch_4
    :try_start_5
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 45
    .line 46
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 47
    .line 48
    .line 49
    :catch_5
    const/4 v6, 0x4

    .line 50
    :try_start_6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->FEED:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 51
    .line 52
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 53
    .line 54
    .line 55
    :catch_6
    const/4 v5, 0x5

    .line 56
    :try_start_7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->GOALS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 57
    .line 58
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 59
    .line 60
    .line 61
    :catch_7
    :try_start_8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->IDEAS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 62
    .line 63
    invoke-static {v0, v1}, LX/007;->A1L(Ljava/lang/Enum;[I)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 64
    .line 65
    .line 66
    :catch_8
    :try_start_9
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 67
    .line 68
    invoke-static {v0, v1}, LX/3Rr;->A17(Ljava/lang/Enum;[I)V
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 69
    .line 70
    .line 71
    :catch_9
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;->$EnumSwitchMapping$1:[I

    .line 72
    .line 73
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->values()[Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    array-length v0, v0

    .line 78
    new-array v1, v0, [I

    .line 79
    .line 80
    :try_start_a
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->RENEW:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 81
    .line 82
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    .line 83
    .line 84
    .line 85
    :catch_a
    :try_start_b
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 86
    .line 87
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    .line 88
    .line 89
    .line 90
    :catch_b
    :try_start_c
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->STATUS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 91
    .line 92
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_c} :catch_c

    .line 93
    .line 94
    .line 95
    :catch_c
    :try_start_d
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 96
    .line 97
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_d .. :try_end_d} :catch_d

    .line 98
    .line 99
    .line 100
    :catch_d
    :try_start_e
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;->OTHER:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;

    .line 101
    .line 102
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_e .. :try_end_e} :catch_e

    .line 103
    .line 104
    .line 105
    :catch_e
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;->$EnumSwitchMapping$2:[I

    .line 106
    .line 107
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;->values()[Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    array-length v0, v0

    .line 112
    new-array v1, v0, [I

    .line 113
    .line 114
    :try_start_f
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;->SUBSCRIBE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;

    .line 115
    .line 116
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_f .. :try_end_f} :catch_f

    .line 117
    .line 118
    .line 119
    :catch_f
    :try_start_10
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;->UPGRADE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;

    .line 120
    .line 121
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_10 .. :try_end_10} :catch_10

    .line 122
    .line 123
    .line 124
    :catch_10
    :try_start_11
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;->DOWNGRADE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;

    .line 125
    .line 126
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_11
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_11} :catch_11

    .line 127
    .line 128
    .line 129
    :catch_11
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;->$EnumSwitchMapping$3:[I

    .line 130
    .line 131
    invoke-static {}, Lcom/facebook/aura/common/HatchCvmChipPinPurpose;->values()[Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    array-length v0, v0

    .line 136
    new-array v1, v0, [I

    .line 137
    .line 138
    :try_start_12
    sget-object v0, Lcom/facebook/aura/common/HatchCvmChipPinPurpose;->HARD_REPLACEMENT:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 139
    .line 140
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_12} :catch_12

    .line 141
    .line 142
    .line 143
    :catch_12
    :try_start_13
    sget-object v0, Lcom/facebook/aura/common/HatchCvmChipPinPurpose;->PROVISIONING:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 144
    .line 145
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_13
    .catch Ljava/lang/NoSuchFieldError; {:try_start_13 .. :try_end_13} :catch_13

    .line 146
    .line 147
    .line 148
    :catch_13
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$WhenMappings;->$EnumSwitchMapping$4:[I

    .line 149
    .line 150
    return-void
.end method
