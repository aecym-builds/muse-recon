.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 4

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    iget v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 3
    .line 4
    add-int/lit8 v0, v0, 0x1

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 8
    .line 9
    invoke-direct {v1, v3, v3, v3, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 18
    .line 19
    move p1, v2

    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;-><init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V

    .line 21
    .line 22
    .line 23
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;->apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
