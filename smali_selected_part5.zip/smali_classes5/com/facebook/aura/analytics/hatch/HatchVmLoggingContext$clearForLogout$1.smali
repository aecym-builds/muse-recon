.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 4

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    iget v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 3
    .line 4
    const/4 v3, 0x0

    .line 5
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 6
    .line 7
    invoke-direct {v1, v3, v3, v3, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    const/4 p1, 0x0

    .line 16
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 17
    .line 18
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;-><init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;->apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
