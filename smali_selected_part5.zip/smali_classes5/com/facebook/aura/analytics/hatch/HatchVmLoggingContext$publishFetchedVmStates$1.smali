.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $states:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;->$states:Ljava/util/Map;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 4

    .line 0
    move-object v0, p1

    .line 1
    iget-boolean v2, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 2
    .line 3
    if-nez v2, :cond_0

    .line 4
    .line 5
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;->$states:Ljava/util/Map;

    .line 6
    .line 7
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 8
    .line 9
    iget-object v3, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 10
    .line 11
    iget-boolean p1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 12
    .line 13
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->copy(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    :cond_0
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;->apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
