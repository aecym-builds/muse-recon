.class public final Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CP0;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $sessionId:J

.field public final synthetic $startTimeSec:J

.field public final synthetic $tosArray:[I

.field public final synthetic $tosLen:I


# direct methods
.method public constructor <init>(JJ[II)V
    .locals 1

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$sessionId:J

    .line 1
    .line 2
    iput-wide p3, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$startTimeSec:J

    .line 3
    .line 4
    iput-object p5, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$tosArray:[I

    .line 5
    .line 6
    iput p6, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$tosLen:I

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CP0;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->invoke(LX/CP0;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/CP0;)V
    .locals 6

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$sessionId:J

    .line 5
    .line 6
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    check-cast p1, LX/I8F;

    .line 11
    .line 12
    const-string v0, "client_session_id"

    .line 13
    .line 14
    invoke-virtual {p1, v0, v1}, LX/I8F;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 15
    .line 16
    .line 17
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$startTimeSec:J

    .line 18
    .line 19
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "tos_start_time"

    .line 24
    .line 25
    invoke-virtual {p1, v0, v1}, LX/I8F;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 26
    .line 27
    .line 28
    iget-object v5, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$tosArray:[I

    .line 29
    .line 30
    array-length v4, v5

    .line 31
    new-instance v3, Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 34
    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    :goto_0
    if-ge v2, v4, :cond_0

    .line 38
    .line 39
    aget v0, v5, v2

    .line 40
    .line 41
    int-to-long v0, v0

    .line 42
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    add-int/lit8 v2, v2, 0x1

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_0
    const-string v1, "tos_array"

    .line 53
    .line 54
    iget-object v0, p1, LX/I8F;->A00:LX/I2T;

    .line 55
    .line 56
    invoke-interface {v0, v1, v3}, LX/I2T;->A43(Ljava/lang/String;Ljava/util/List;)V

    .line 57
    .line 58
    .line 59
    iget v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;->$tosLen:I

    .line 60
    .line 61
    int-to-long v0, v0

    .line 62
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    const-string v0, "tos_len"

    .line 67
    .line 68
    invoke-virtual {p1, v0, v1}, LX/I8F;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 69
    .line 70
    .line 71
    return-void
.end method
