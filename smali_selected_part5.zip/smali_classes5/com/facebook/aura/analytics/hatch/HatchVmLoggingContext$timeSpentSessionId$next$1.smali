.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $sessionGeneration:I

.field public final synthetic $vmId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$vmId:Ljava/lang/String;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$sessionGeneration:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 11

    .line 0
    move-object v7, p1

    .line 1
    iget-object v2, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 2
    .line 3
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    if-eqz v2, :cond_1

    .line 8
    .line 9
    iget-object v1, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->vmId:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$vmId:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget v1, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionGeneration:I

    .line 20
    .line 21
    iget v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$sessionGeneration:I

    .line 22
    .line 23
    if-ne v1, v0, :cond_1

    .line 24
    .line 25
    :cond_0
    return-object v7

    .line 26
    :cond_1
    iget-object v6, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$vmId:Ljava/lang/String;

    .line 27
    .line 28
    iget v5, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->$sessionGeneration:I

    .line 29
    .line 30
    const-wide/16 v3, 0x1

    .line 31
    .line 32
    const-wide v1, 0x7fffffffffffffffL

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    sget-object v0, LX/Fqh;->A01:LX/Fqh;

    .line 38
    .line 39
    invoke-virtual {v0, v3, v4, v1, v2}, LX/Fqh;->A08(JJ)J

    .line 40
    .line 41
    .line 42
    move-result-wide v0

    .line 43
    new-instance v10, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 44
    .line 45
    invoke-direct {v10, v6, v5, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;-><init>(Ljava/lang/String;IJ)V

    .line 46
    .line 47
    .line 48
    iget-object v8, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 49
    .line 50
    iget-boolean v9, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 51
    .line 52
    iget-object p0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 53
    .line 54
    iget-boolean p1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 55
    .line 56
    invoke-virtual/range {v7 .. v12}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->copy(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 57
    .line 58
    .line 59
    move-result-object v7

    .line 60
    return-object v7
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;->apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
