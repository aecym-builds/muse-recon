.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final isCvm:Ljava/lang/Boolean;

.field public final sessionGeneration:I

.field public final vmHostname:Ljava/lang/String;

.field public final vmId:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 536870912
    const/4 v1, 0x0

    .line 536870913
    const/4 v0, 0x0

    .line 536870914
    invoke-direct {p0, v1, v1, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 536870915
    .line 536870916
    .line 536870917
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 8
    .line 9
    iput p4, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;IILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p5, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    const/4 p4, 0x0

    .line 268435477
    :cond_3
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 268435478
    .line 268435479
    .line 268435480
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;IILjava/lang/Object;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 23
    .line 24
    :cond_3
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 25
    .line 26
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 41
    .line 42
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 43
    .line 44
    if-eq v1, v0, :cond_1

    .line 45
    .line 46
    :cond_0
    return v2

    .line 47
    :cond_1
    return v3
.end method

.method public final getSessionGeneration()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 1
    .line 2
    return p0
.end method

.method public final getVmHostname()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVmId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    :cond_0
    add-int/2addr v1, v2

    .line 27
    mul-int/lit8 v1, v1, 0x1f

    .line 28
    .line 29
    iget v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 30
    .line 31
    add-int/2addr v1, v0

    .line 32
    return v1
.end method

.method public final isCvm()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
