.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

.field public static final state:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    new-instance v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 10
    .line 11
    invoke-direct {v2, v4, v4, v4, v3}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 12
    .line 13
    .line 14
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 19
    .line 20
    move v6, v3

    .line 21
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;-><init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V

    .line 22
    .line 23
    .line 24
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 25
    .line 26
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 30
    .line 31
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final clearForLogout()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$clearForLogout$1;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->INSTANCE:Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 16
    .line 17
    iget-object p0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->_isCvm:LX/2J2;

    .line 20
    .line 21
    invoke-interface {v0, p0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final fetchedVmState(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 11
    .line 12
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 13
    .line 14
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    check-cast p0, Ljava/lang/String;

    .line 19
    .line 20
    return-object p0
.end method

.method public final publish(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->INSTANCE:Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 20
    .line 21
    iget-object v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 22
    .line 23
    iget-object p0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->_isCvm:LX/2J2;

    .line 26
    .line 27
    invoke-interface {v0, p0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 35
    .line 36
    iget-object p0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    invoke-static {p0, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_0

    .line 44
    .line 45
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 46
    .line 47
    if-nez v0, :cond_0

    .line 48
    .line 49
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;

    .line 50
    .line 51
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->clear()V

    .line 52
    .line 53
    .line 54
    :cond_0
    return-void
.end method

.method public final publishFetchedVmStates(Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publishFetchedVmStates$1;-><init>(Ljava/util/Map;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final reopenForSession()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$reopenForSession$1;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->INSTANCE:Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 16
    .line 17
    iget-object p0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->_isCvm:LX/2J2;

    .line 20
    .line 21
    invoke-interface {v0, p0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 9
    .line 10
    return-object p0
.end method

.method public final timeSpentSessionId(Ljava/lang/String;I)Ljava/lang/Long;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;

    .line 7
    .line 8
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$timeSpentSessionId$next$1;-><init>(Ljava/lang/String;I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 16
    .line 17
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 23
    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-wide v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionId:J

    .line 27
    .line 28
    invoke-static {v0, p0}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    :cond_0
    return-object p0
.end method
