.class public final Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

.field public static final VM_ATTRIBUTED_EVENT_NAMES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/COq;",
            ">;"
        }
    .end annotation
.end field

.field public static final downgradeRun:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/aura/analytics/hatch/CvmRun;",
            ">;"
        }
    .end annotation
.end field

.field public static final pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 6
    .line 7
    sget-object v2, LX/COq;->A06:LX/COq;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    sget-object v0, LX/COq;->A0R:LX/COq;

    .line 11
    .line 12
    filled-new-array {v2, v0}, [LX/COq;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->VM_ATTRIBUTED_EVENT_NAMES:Ljava/util/Set;

    .line 21
    .line 22
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 23
    .line 24
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 25
    .line 26
    .line 27
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 28
    .line 29
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 30
    .line 31
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 32
    .line 33
    .line 34
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 38
    .line 39
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->downgradeRun:Ljava/util/concurrent/atomic/AtomicReference;

    .line 43
    .line 44
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toCvmAttribution(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;)Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method private final log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/COq;",
            "Lcom/facebook/aura/analytics/hatch/CvmAttribution;",
            "LX/EJd;",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "LX/CP0;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v0, "hatch_client_cvm_event"

    .line 7
    .line 8
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    new-instance v2, LX/COy;

    .line 13
    .line 14
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, v2, LX/I8F;->A00:LX/I2T;

    .line 18
    .line 19
    invoke-interface {v0}, LX/I2T;->isSampled()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    const-string v0, "event_name"

    .line 26
    .line 27
    invoke-virtual {v2, p1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-direct {p0, v2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->withInternalTraffic(LX/CP0;)LX/CP0;

    .line 31
    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->VM_ATTRIBUTED_EVENT_NAMES:Ljava/util/Set;

    .line 34
    .line 35
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    iget-object v1, p2, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->vmId:Ljava/lang/String;

    .line 42
    .line 43
    const-string v0, "vm_id"

    .line 44
    .line 45
    invoke-virtual {v2, v0, v1}, LX/I8F;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object p4, p2, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->vmHostname:Ljava/lang/String;

    .line 49
    .line 50
    if-eqz p4, :cond_0

    .line 51
    .line 52
    const-string v0, "vm_hostname"

    .line 53
    .line 54
    :goto_0
    invoke-virtual {v2, v0, p4}, LX/I8F;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    :cond_0
    if-eqz p3, :cond_1

    .line 58
    .line 59
    const-string v0, "event_result"

    .line 60
    .line 61
    invoke-virtual {v2, p3, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    :cond_1
    invoke-interface {p5, v2}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v2}, LX/I8F;->AQ5()V

    .line 68
    .line 69
    .line 70
    :cond_2
    return-void

    .line 71
    :cond_3
    if-nez p4, :cond_4

    .line 72
    .line 73
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;

    .line 74
    .line 75
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->getOrCreate()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p4

    .line 79
    :cond_4
    const-string v0, "client_cvm_uuid"

    .line 80
    .line 81
    goto :goto_0
.end method

.method public static synthetic log$default(Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sget-object p5, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 16
    .line 17
    :cond_2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method private final logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v0, "hatch_client_cvm_event"

    .line 7
    .line 8
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    new-instance v2, LX/COy;

    .line 13
    .line 14
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, v2, LX/I8F;->A00:LX/I2T;

    .line 18
    .line 19
    invoke-interface {v0}, LX/I2T;->isSampled()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    const-string v0, "event_name"

    .line 26
    .line 27
    invoke-virtual {v2, p1, v0}, LX/I8F;->A00(LX/DfA;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-direct {p0, v2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->withInternalTraffic(LX/CP0;)LX/CP0;

    .line 31
    .line 32
    .line 33
    if-eqz p2, :cond_0

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 36
    .line 37
    invoke-direct {v0, p2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toStruct(Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;)LX/COz;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    const-string v0, "chip_budget"

    .line 42
    .line 43
    invoke-virtual {v2, v1, v0}, LX/I8F;->A01(LX/EXN;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    if-eqz p3, :cond_3

    .line 47
    .line 48
    const-string v0, "vm_id"

    .line 49
    .line 50
    :goto_0
    invoke-virtual {v2, v0, p3}, LX/I8F;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    invoke-virtual {v2}, LX/I8F;->AQ5()V

    .line 54
    .line 55
    .line 56
    :cond_2
    return-void

    .line 57
    :cond_3
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 58
    .line 59
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iget-object v1, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 64
    .line 65
    const/4 v0, 0x1

    .line 66
    invoke-static {v1, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_1

    .line 71
    .line 72
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;

    .line 73
    .line 74
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->getOrCreate()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p3

    .line 78
    const-string v0, "client_cvm_uuid"

    .line 79
    .line 80
    goto :goto_0
.end method

.method private final logTimeSpentMarker(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;)V
    .locals 5

    .line 0
    move-object v2, p0

    .line 1
    move-object v4, p2

    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->timeSpentSessionId(Lcom/facebook/aura/analytics/hatch/CvmAttribution;)Ljava/lang/Long;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    new-instance p2, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentMarker$1;

    .line 13
    .line 14
    invoke-direct {p2, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentMarker$1;-><init>(J)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    move-object v3, p1

    .line 19
    move-object p1, p0

    .line 20
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method private final openDowngradeRun(Lcom/facebook/aura/analytics/hatch/CvmRun;)Z
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->downgradeRun:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;-><init>(Lcom/facebook/aura/analytics/hatch/CvmRun;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0, p1}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method private final takeDowngradeRun()Lcom/facebook/aura/analytics/hatch/CvmRun;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->downgradeRun:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v2

    .line 7
    check-cast v2, Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 12
    .line 13
    iget v1, v0, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->sessionGeneration:I

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 16
    .line 17
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 22
    .line 23
    if-ne v1, v0, :cond_0

    .line 24
    .line 25
    return-object v2

    .line 26
    :cond_0
    return-object p0
.end method

.method private final timeSpentSessionId(Lcom/facebook/aura/analytics/hatch/CvmAttribution;)Ljava/lang/Long;
    .locals 2

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 1
    .line 2
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->vmId:Ljava/lang/String;

    .line 3
    .line 4
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->sessionGeneration:I

    .line 5
    .line 6
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->timeSpentSessionId(Ljava/lang/String;I)Ljava/lang/Long;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method private final toCvmAttribution(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;)Lcom/facebook/aura/analytics/hatch/CvmAttribution;
    .locals 3

    .line 0
    iget-object p0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmId:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {v1, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->vmHostname:Ljava/lang/String;

    .line 14
    .line 15
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 16
    .line 17
    new-instance v2, Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 18
    .line 19
    invoke-direct {v2, p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/CvmAttribution;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 20
    .line 21
    .line 22
    return-object v2

    .line 23
    :cond_0
    const/4 v2, 0x0

    .line 24
    return-object v2
.end method

.method private final toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;)LX/COq;
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eq p1, p0, :cond_4

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    if-eq p1, p0, :cond_3

    .line 9
    .line 10
    const/4 p0, 0x2

    .line 11
    if-eq p1, p0, :cond_2

    .line 12
    .line 13
    const/4 p0, 0x3

    .line 14
    if-eq p1, p0, :cond_1

    .line 15
    .line 16
    const/4 p0, 0x4

    .line 17
    if-ne p1, p0, :cond_0

    .line 18
    .line 19
    sget-object p0, LX/COq;->A0Z:LX/COq;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 23
    .line 24
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 25
    .line 26
    .line 27
    throw p0

    .line 28
    :cond_1
    sget-object p0, LX/COq;->A0W:LX/COq;

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_2
    sget-object p0, LX/COq;->A0c:LX/COq;

    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_3
    sget-object p0, LX/COq;->A0b:LX/COq;

    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_4
    sget-object p0, LX/COq;->A0a:LX/COq;

    .line 38
    .line 39
    return-object p0
.end method

.method private final toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;)LX/COq;
    .locals 0

    .line 536870912
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 536870913
    .line 536870914
    .line 536870915
    move-result p1

    .line 536870916
    const/4 p0, 0x0

    .line 536870917
    if-eq p1, p0, :cond_2

    .line 536870918
    .line 536870919
    const/4 p0, 0x1

    .line 536870920
    if-eq p1, p0, :cond_1

    .line 536870921
    .line 536870922
    const/4 p0, 0x2

    .line 536870923
    if-ne p1, p0, :cond_0

    .line 536870924
    .line 536870925
    sget-object p0, LX/COq;->A0Y:LX/COq;

    .line 536870926
    .line 536870927
    return-object p0

    .line 536870928
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 536870929
    .line 536870930
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 536870931
    .line 536870932
    .line 536870933
    throw p0

    .line 536870934
    :cond_1
    sget-object p0, LX/COq;->A0f:LX/COq;

    .line 536870935
    .line 536870936
    return-object p0

    .line 536870937
    :cond_2
    sget-object p0, LX/COq;->A0d:LX/COq;

    .line 536870938
    .line 536870939
    return-object p0
.end method

.method private final toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;)LX/COq;
    .locals 0

    .line 268435456
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p0

    .line 268435460
    packed-switch p0, :pswitch_data_0

    .line 268435461
    .line 268435462
    .line 268435463
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 268435464
    .line 268435465
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 268435466
    .line 268435467
    .line 268435468
    throw p0

    .line 268435469
    :pswitch_0
    sget-object p0, LX/COq;->A02:LX/COq;

    .line 268435470
    .line 268435471
    return-object p0

    .line 268435472
    :pswitch_1
    sget-object p0, LX/COq;->A04:LX/COq;

    .line 268435473
    .line 268435474
    return-object p0

    .line 268435475
    :pswitch_2
    sget-object p0, LX/COq;->A05:LX/COq;

    .line 268435476
    .line 268435477
    return-object p0

    .line 268435478
    :pswitch_3
    sget-object p0, LX/COq;->A0y:LX/COq;

    .line 268435479
    .line 268435480
    return-object p0

    .line 268435481
    :pswitch_4
    sget-object p0, LX/COq;->A0z:LX/COq;

    .line 268435482
    .line 268435483
    return-object p0

    .line 268435484
    :pswitch_5
    sget-object p0, LX/COq;->A10:LX/COq;

    .line 268435485
    .line 268435486
    return-object p0

    .line 268435487
    :pswitch_6
    sget-object p0, LX/COq;->A11:LX/COq;

    .line 268435488
    .line 268435489
    return-object p0

    .line 268435490
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method private final toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eq p1, p0, :cond_2

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    if-eq p1, p0, :cond_1

    .line 9
    .line 10
    const/4 p0, 0x2

    .line 11
    if-ne p1, p0, :cond_0

    .line 12
    .line 13
    sget-object p0, LX/EJd;->A02:LX/EJd;

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 17
    .line 18
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 19
    .line 20
    .line 21
    throw p0

    .line 22
    :cond_1
    sget-object p0, LX/EJd;->A03:LX/EJd;

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_2
    sget-object p0, LX/EJd;->A01:LX/EJd;

    .line 26
    .line 27
    return-object p0
.end method

.method private final toLogValue(Ljava/lang/String;)LX/9sE;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$EntriesMappings;->entries$0:LX/0vk;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_2

    .line 11
    .line 12
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    move-object v0, v1

    .line 17
    check-cast v0, LX/9sE;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    :goto_0
    check-cast v1, LX/9sE;

    .line 30
    .line 31
    if-nez v1, :cond_1

    .line 32
    .line 33
    sget-object v1, LX/9sE;->A01:LX/9sE;

    .line 34
    .line 35
    :cond_1
    return-object v1

    .line 36
    :cond_2
    const/4 v1, 0x0

    .line 37
    goto :goto_0
.end method

.method private final toLogValue(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;)LX/C76;
    .locals 0

    .line 268435456
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p1

    .line 268435460
    const/4 p0, 0x1

    .line 268435461
    if-eq p1, p0, :cond_1

    .line 268435462
    .line 268435463
    const/4 p0, 0x0

    .line 268435464
    if-ne p1, p0, :cond_0

    .line 268435465
    .line 268435466
    sget-object p0, LX/C76;->A01:LX/C76;

    .line 268435467
    .line 268435468
    return-object p0

    .line 268435469
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 268435470
    .line 268435471
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 268435472
    .line 268435473
    .line 268435474
    throw p0

    .line 268435475
    :cond_1
    sget-object p0, LX/C76;->A02:LX/C76;

    .line 268435476
    .line 268435477
    return-object p0
.end method

.method private final toStruct(Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;)LX/COz;
    .locals 4

    .line 0
    new-instance v2, LX/COz;

    .line 1
    .line 2
    invoke-direct {v2}, LX/EXN;-><init>()V

    .line 3
    .line 4
    .line 5
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 6
    .line 7
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toLogValue(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;)LX/C76;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v0, "budget_type"

    .line 12
    .line 13
    invoke-virtual {v2, v1, v0}, LX/EXN;->A01(LX/DfA;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 17
    .line 18
    int-to-long v0, v0

    .line 19
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "budget_chips_spent"

    .line 24
    .line 25
    invoke-virtual {v2, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 26
    .line 27
    .line 28
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 29
    .line 30
    int-to-long v0, v0

    .line 31
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    const-string v0, "budget_chips_limit"

    .line 36
    .line 37
    invoke-virtual {v2, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 38
    .line 39
    .line 40
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 41
    .line 42
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const-string v0, "is_try_again"

    .line 47
    .line 48
    iget-object p0, v2, LX/EXN;->A00:Ljava/util/Map;

    .line 49
    .line 50
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 54
    .line 55
    const/4 v3, 0x0

    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    int-to-long v0, v0

    .line 63
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    :goto_0
    const-string v0, "chips_submitted_count"

    .line 68
    .line 69
    invoke-virtual {v2, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 73
    .line 74
    if-eqz v0, :cond_1

    .line 75
    .line 76
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    int-to-long v0, v0

    .line 81
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    :goto_1
    const-string v0, "chips_drawn_count"

    .line 86
    .line 87
    invoke-virtual {v2, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 88
    .line 89
    .line 90
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 91
    .line 92
    const-string v0, "is_over_budget"

    .line 93
    .line 94
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 98
    .line 99
    const-string v0, "is_rebid"

    .line 100
    .line 101
    invoke-interface {p0, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 105
    .line 106
    if-eqz v0, :cond_0

    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    int-to-long v0, v0

    .line 113
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    :cond_0
    const-string v0, "remembered_chips_count"

    .line 118
    .line 119
    invoke-virtual {v2, v0, v3}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 120
    .line 121
    .line 122
    return-object v2

    .line 123
    :cond_1
    move-object v1, v3

    .line 124
    goto :goto_1

    .line 125
    :cond_2
    move-object v1, v3

    .line 126
    goto :goto_0
.end method

.method private final withInternalTraffic(LX/CP0;)LX/CP0;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->isViewerEmployee()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    move-object p0, p1

    .line 11
    check-cast p0, LX/I8F;

    .line 12
    .line 13
    const-string v1, "is_employee"

    .line 14
    .line 15
    iget-object v0, p0, LX/I8F;->A00:LX/I2T;

    .line 16
    .line 17
    invoke-interface {v0, v1, v2}, LX/I2T;->A3P(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    const-string v1, "is_internal_build"

    .line 26
    .line 27
    iget-object v0, p0, LX/I8F;->A00:LX/I2T;

    .line 28
    .line 29
    invoke-interface {v0, v1, v2}, LX/I2T;->A3P(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 30
    .line 31
    .line 32
    return-object p1
.end method


# virtual methods
.method public final currentCvmVmId()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    if-eqz p0, :cond_0

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->vmId:Ljava/lang/String;

    .line 7
    .line 8
    return-object p0

    .line 9
    :cond_0
    const/4 p0, 0x0

    .line 10
    return-object p0
.end method

.method public final logAccountSwitchClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0A:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logAppStartup(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A01:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logClientOpen()V
    .locals 10

    .line 0
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 v3, 0x1

    .line 3
    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-static {v0, v1}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    invoke-virtual {v4, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void

    .line 25
    :cond_1
    move-object v5, p0

    .line 26
    invoke-direct {p0, v2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toCvmAttribution(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;)Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 27
    .line 28
    .line 29
    move-result-object v7

    .line 30
    if-eqz v7, :cond_0

    .line 31
    .line 32
    invoke-virtual {v4, v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    sget-object v6, LX/COq;->A03:LX/COq;

    .line 39
    .line 40
    const/4 v8, 0x0

    .line 41
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 42
    .line 43
    move-object v9, v8

    .line 44
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final logConnectVm(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;Z)V
    .locals 6

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v2, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    if-eqz v4, :cond_0

    .line 10
    .line 11
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 12
    .line 13
    iget-object v0, v4, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->vmId:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->fetchedVmState(Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toLogValue(Ljava/lang/String;)LX/9sE;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    :goto_0
    sget-object v3, LX/COq;->A06:LX/COq;

    .line 26
    .line 27
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    new-instance p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;

    .line 32
    .line 33
    invoke-direct {p1, v0, p2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logConnectVm$1;-><init>(LX/9sE;Z)V

    .line 34
    .line 35
    .line 36
    const/4 p0, 0x0

    .line 37
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    return-void

    .line 41
    :cond_1
    const/4 v0, 0x0

    .line 42
    goto :goto_0
.end method

.method public final logCvmAccessErrorRetryClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A07:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmAccessErrorSettingsClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A08:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmAccessErrorView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A09:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmActivationComplete()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0B:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmDowngrade(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    move-object v3, p0

    .line 9
    if-eq v1, v0, :cond_0

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    if-eq v1, v0, :cond_2

    .line 13
    .line 14
    const/4 v0, 0x2

    .line 15
    if-eq v1, v0, :cond_2

    .line 16
    .line 17
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 18
    .line 19
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 20
    .line 21
    .line 22
    throw v0

    .line 23
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    if-eqz v2, :cond_3

    .line 28
    .line 29
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmUuid;->getOrCreate()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    new-instance v1, Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 36
    .line 37
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/analytics/hatch/CvmRun;-><init>(Lcom/facebook/aura/analytics/hatch/CvmAttribution;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 41
    .line 42
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->openDowngradeRun(Lcom/facebook/aura/analytics/hatch/CvmRun;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_3

    .line 47
    .line 48
    :cond_1
    sget-object v4, LX/COq;->A0C:LX/COq;

    .line 49
    .line 50
    iget-object v5, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 51
    .line 52
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    iget-object p0, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->clientCvmUuid:Ljava/lang/String;

    .line 57
    .line 58
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 59
    .line 60
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :cond_2
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->takeDowngradeRun()Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    if-nez v1, :cond_1

    .line 69
    .line 70
    :cond_3
    return-void
.end method

.method public final logCvmDowngradeRefused()V
    .locals 7

    .line 0
    move-object v2, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->takeDowngradeRun()Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    sget-object v3, LX/COq;->A0r:LX/COq;

    .line 8
    .line 9
    iget-object v4, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 10
    .line 11
    iget-object v6, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->clientCvmUuid:Ljava/lang/String;

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 15
    .line 16
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 17
    .line 18
    .line 19
    sget-object v3, LX/COq;->A0C:LX/COq;

    .line 20
    .line 21
    iget-object v4, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;->FAILURE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;

    .line 24
    .line 25
    invoke-direct {v2, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    iget-object v6, v1, Lcom/facebook/aura/analytics/hatch/CvmRun;->clientCvmUuid:Ljava/lang/String;

    .line 30
    .line 31
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void
.end method

.method public final logCvmEncryptionSettingsView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0E:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmMaintenanceSettingsClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0H:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmMaintenanceView(Ljava/lang/String;Ljava/util/concurrent/atomic/AtomicReference;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    move-object v1, p0

    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    if-eqz v3, :cond_0

    .line 9
    .line 10
    invoke-virtual {p2, p1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    sget-object v2, LX/COq;->A0I:LX/COq;

    .line 21
    .line 22
    const/4 p0, 0x0

    .line 23
    sget-object p2, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 24
    .line 25
    move-object p1, p0

    .line 26
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method public final logCvmReadyConfirmClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0J:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmReadyView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0K:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmReplacementChipAllowlistRejected()V
    .locals 2

    .line 0
    sget-object v1, LX/COq;->A0L:LX/COq;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logCvmReplacementChipBid(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A0M:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logCvmReplacementChipBudgetExhausted(Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, LX/COq;->A0N:LX/COq;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final logCvmReplacementChipBudgetSettingsClick()V
    .locals 2

    .line 0
    sget-object v1, LX/COq;->A0O:LX/COq;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logCvmReplacementChipBudgetSupportClick()V
    .locals 2

    .line 0
    sget-object v1, LX/COq;->A0P:LX/COq;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logCvmReplacementChipSubmitted(Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v3, LX/COq;->A0Q:LX/COq;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz p2, :cond_0

    .line 8
    .line 9
    iget-object v1, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    invoke-static {v1, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    :goto_0
    invoke-direct {p0, v3, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logChipBudget(LX/COq;Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    move-object p2, v2

    .line 23
    goto :goto_0
.end method

.method public final logCvmReplacementPushReceived()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0R:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logCvmReplacementUnlock(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A0S:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logCvmSwitchStartFreshCompleted()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0u:LX/COq;

    .line 8
    .line 9
    sget-object v3, LX/EJd;->A03:LX/EJd;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 13
    .line 14
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final logCvmSwitchStartFreshFailed()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0u:LX/COq;

    .line 8
    .line 9
    sget-object v3, LX/EJd;->A02:LX/EJd;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 13
    .line 14
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final logCvmSwitchTransferCompleted()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0v:LX/COq;

    .line 8
    .line 9
    sget-object v3, LX/EJd;->A03:LX/EJd;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 13
    .line 14
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final logCvmSwitchTransferFailed()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0v:LX/COq;

    .line 8
    .line 9
    sget-object v3, LX/EJd;->A02:LX/EJd;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 13
    .line 14
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final logEncryptionSettingsClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0D:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logHelpClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0F:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logLogoutClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0G:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logPendingAppOpen()V
    .locals 8

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    iget-object v0, v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-static {v0, v2}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 16
    .line 17
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 18
    .line 19
    .line 20
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 21
    .line 22
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 23
    .line 24
    .line 25
    :cond_0
    move-object v3, p0

    .line 26
    invoke-direct {p0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toCvmAttribution(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;)Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    if-eqz v5, :cond_2

    .line 31
    .line 32
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 33
    .line 34
    const/4 v1, 0x1

    .line 35
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    sget-object v0, LX/COq;->A1M:LX/COq;

    .line 42
    .line 43
    invoke-direct {p0, v0, v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentMarker(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_2

    .line 53
    .line 54
    sget-object v4, LX/COq;->A03:LX/COq;

    .line 55
    .line 56
    const/4 v6, 0x0

    .line 57
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 58
    .line 59
    move-object v7, v6

    .line 60
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void
.end method

.method public final logRecoveryPinChange(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A12:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logRecoveryPinChangeClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A13:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinCreate(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A14:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logRecoveryPinHelpChangePinClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A15:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinHelpDismissClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A16:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinHelpManageAccountClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A17:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinHelpSupportClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A18:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinHelpView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A19:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinLogoutClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1A:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinLookupFailedRetryClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1B:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinLookupFailedView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1C:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinReminderPromptView(Ljava/lang/String;Ljava/util/concurrent/atomic/AtomicReference;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    move-object v1, p0

    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    if-eqz v3, :cond_0

    .line 9
    .line 10
    invoke-virtual {p2, p1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    sget-object v2, LX/COq;->A1D:LX/COq;

    .line 21
    .line 22
    const/4 p0, 0x0

    .line 23
    sget-object p2, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 24
    .line 25
    move-object p1, p0

    .line 26
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method public final logRecoveryPinReminderVerify(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A1E:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logRecoveryPinReminderView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1F:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinReset(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A1G:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logRecoveryPinResetClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1H:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logRecoveryPinVerify(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A1I:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logSendMessage()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1J:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionEndedContinueClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0T:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionEndedRenewClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0U:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionEndedView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0V:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionPaywallDismissClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0X:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionPaywallPlanClick(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPlanChange;)LX/COq;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v3, 0x0

    .line 16
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 17
    .line 18
    move-object p0, v3

    .line 19
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final logSubscriptionPaywallTopUpClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0e:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionPaywallView(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmPaywallEntry;)LX/COq;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v3, 0x0

    .line 16
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 17
    .line 18
    move-object p0, v3

    .line 19
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final logSubscriptionPurchase(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A0g:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logSubscriptionPurchaseCancelled()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0h:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSubscriptionRenewed()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0i:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackCancelClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0j:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0k:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackDeleteCancelClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0l:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackDismissClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0m:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackDownloadClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0n:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackKeepDataClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0o:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackKeepDataOptionClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0p:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackLearnMoreClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0q:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackStartFreshClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0s:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logSwitchBackStartFreshOptionClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A0t:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logTabClick(Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventName(Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;)LX/COq;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v3, 0x0

    .line 16
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 17
    .line 18
    move-object p0, v3

    .line 19
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final logTimeSpentBackground()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    sget-object v0, LX/COq;->A1K:LX/COq;

    .line 13
    .line 14
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentMarker(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final logTimeSpentBitArray(J[II)V
    .locals 12

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v11, p3

    .line 2
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    move-object v1, p0

    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    if-eqz v3, :cond_0

    .line 11
    .line 12
    invoke-direct {p0, v3}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->timeSpentSessionId(Lcom/facebook/aura/analytics/hatch/CvmAttribution;)Ljava/lang/Long;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 19
    .line 20
    .line 21
    move-result-wide v7

    .line 22
    sget-object v2, LX/COq;->A1L:LX/COq;

    .line 23
    .line 24
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;

    .line 25
    .line 26
    move-wide v9, p1

    .line 27
    move/from16 p0, p4

    .line 28
    .line 29
    invoke-direct/range {v6 .. v12}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$logTimeSpentBitArray$1;-><init>(JJ[II)V

    .line 30
    .line 31
    .line 32
    const/4 v4, 0x0

    .line 33
    move-object v5, v4

    .line 34
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    return-void
.end method

.method public final logTimeSpentForeground()V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingForeground:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 v3, 0x1

    .line 3
    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext;->snapshot()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v0, v1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->isCvm:Ljava/lang/Boolean;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-static {v0, v2}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    invoke-virtual {v4, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void

    .line 25
    :cond_1
    invoke-direct {p0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toCvmAttribution(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;)Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    invoke-virtual {v4, v3, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    sget-object v0, LX/COq;->A1M:LX/COq;

    .line 38
    .line 39
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentMarker(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final logTimeSpentNavigation()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    sget-object v0, LX/COq;->A1N:LX/COq;

    .line 7
    .line 8
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logTimeSpentMarker(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final logVoiceDictation(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A1O:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logWebMediaToggle(Z)V
    .locals 4

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    if-eqz p1, :cond_1

    .line 8
    .line 9
    sget-object v1, LX/COq;->A0w:LX/COq;

    .line 10
    .line 11
    :goto_0
    const/4 v3, 0x0

    .line 12
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 13
    .line 14
    move-object p0, v3

    .line 15
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void

    .line 19
    :cond_1
    sget-object v1, LX/COq;->A0x:LX/COq;

    .line 20
    .line 21
    goto :goto_0
.end method

.method public final logWhatsAppConnect(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    sget-object v1, LX/COq;->A1P:LX/COq;

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->toEventResult(Lcom/facebook/aura/analytics/hatch/HatchClientCvmOutcome;)LX/EJd;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const/4 p0, 0x0

    .line 18
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final logWhatsAppUpdateClick()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1Q:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final logWhatsAppUpdatePromptView()V
    .locals 5

    .line 0
    move-object v0, p0

    .line 1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->cvmAttribution()Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    sget-object v1, LX/COq;->A1R:LX/COq;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$log$1;

    .line 11
    .line 12
    move-object v4, v3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->log(LX/COq;Lcom/facebook/aura/analytics/hatch/CvmAttribution;LX/EJd;Ljava/lang/String;LX/JDM;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final onAppBackgrounded()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->pendingClientOpen:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
