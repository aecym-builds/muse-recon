.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
.super LX/07H;
.source ""


# instance fields
.field public final attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

.field public final fetchedVmStates:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final hasReachedCvm:Z

.field public final isSealed:Z

.field public final timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;",
            "Z",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 7
    .line 8
    iput-boolean p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 11
    .line 12
    iput-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 13
    .line 14
    iput-boolean p5, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;ZILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p6, 0x4

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    const/4 p3, 0x0

    .line 268435461
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 268435462
    .line 268435463
    if-eqz v0, :cond_1

    .line 268435464
    .line 268435465
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p4

    .line 268435469
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 268435470
    .line 268435471
    if-eqz v0, :cond_2

    .line 268435472
    .line 268435473
    const/4 p5, 0x0

    .line 268435474
    :cond_2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;-><init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V

    .line 268435475
    .line 268435476
    .line 268435477
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;ZILjava/lang/Object;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->copy(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;",
            "Z",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)",
            "Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;-><init>(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-boolean v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 47
    .line 48
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 49
    .line 50
    if-eq v1, v0, :cond_1

    .line 51
    .line 52
    :cond_0
    return v2

    .line 53
    :cond_1
    return v3
.end method

.method public final getAttribution()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFetchedVmStates()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHasReachedCvm()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getTimeSpentStream()Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 15
    .line 16
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    add-int/2addr v1, v0

    .line 21
    mul-int/lit8 v1, v1, 0x1f

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 24
    .line 25
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    iget-boolean v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 30
    .line 31
    const/16 v0, 0x4d5

    .line 32
    .line 33
    if-eqz v1, :cond_0

    .line 34
    .line 35
    const/16 v0, 0x4cf

    .line 36
    .line 37
    :cond_0
    add-int/2addr v2, v0

    .line 38
    return v2
.end method

.method public final isSealed()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
