.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $isCvm:Ljava/lang/Boolean;

.field public final synthetic $vmHostname:Ljava/lang/String;

.field public final synthetic $vmId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$vmId:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$vmHostname:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$isCvm:Ljava/lang/Boolean;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;
    .locals 9

    .line 0
    move-object v5, p1

    .line 1
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 2
    .line 3
    if-nez v0, :cond_3

    .line 4
    .line 5
    iget-object v4, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$vmId:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v4, :cond_4

    .line 9
    .line 10
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_4

    .line 15
    .line 16
    :goto_0
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$vmHostname:Ljava/lang/String;

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    move-object v3, v1

    .line 27
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->$isCvm:Ljava/lang/Boolean;

    .line 28
    .line 29
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->attribution:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 30
    .line 31
    iget v0, v0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;->sessionGeneration:I

    .line 32
    .line 33
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;

    .line 34
    .line 35
    invoke-direct {v6, v4, v3, v2, v0}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;I)V

    .line 36
    .line 37
    .line 38
    iget-boolean v1, p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->hasReachedCvm:Z

    .line 39
    .line 40
    const/4 v0, 0x1

    .line 41
    if-nez v1, :cond_1

    .line 42
    .line 43
    invoke-static {v2, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    const/4 p1, 0x0

    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    :cond_1
    const/4 p1, 0x1

    .line 51
    :cond_2
    iget-boolean v7, v5, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->isSealed:Z

    .line 52
    .line 53
    iget-object v8, v5, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->timeSpentStream:Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;

    .line 54
    .line 55
    iget-object p0, v5, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->fetchedVmStates:Ljava/util/Map;

    .line 56
    .line 57
    invoke-virtual/range {v5 .. v10}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;->copy(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$Attribution;ZLcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;Ljava/util/Map;Z)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    :cond_3
    return-object v5

    .line 62
    :cond_4
    move-object v4, v3

    .line 63
    goto :goto_0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$publish$published$1;->apply(Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;)Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
