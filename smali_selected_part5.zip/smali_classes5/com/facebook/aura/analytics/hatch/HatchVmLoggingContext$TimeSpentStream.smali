.class public final Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final sessionGeneration:I

.field public final sessionId:J

.field public final vmId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;IJ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->vmId:Ljava/lang/String;

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionGeneration:I

    .line 10
    .line 11
    iput-wide p3, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionId:J

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final getSessionGeneration()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionGeneration:I

    .line 1
    .line 2
    return p0
.end method

.method public final getSessionId()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->sessionId:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getVmId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchVmLoggingContext$TimeSpentStream;->vmId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
