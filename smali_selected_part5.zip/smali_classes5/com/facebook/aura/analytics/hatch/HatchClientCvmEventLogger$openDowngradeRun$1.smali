.class public final Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $started:Lcom/facebook/aura/analytics/hatch/CvmRun;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/CvmRun;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;->$started:Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/analytics/hatch/CvmRun;)Lcom/facebook/aura/analytics/hatch/CvmRun;
    .locals 3

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;->$started:Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 3
    .line 4
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 5
    .line 6
    iget v1, v0, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->sessionGeneration:I

    .line 7
    .line 8
    iget-object v0, v2, Lcom/facebook/aura/analytics/hatch/CvmRun;->vm:Lcom/facebook/aura/analytics/hatch/CvmAttribution;

    .line 9
    .line 10
    iget v0, v0, Lcom/facebook/aura/analytics/hatch/CvmAttribution;->sessionGeneration:I

    .line 11
    .line 12
    if-ne v1, v0, :cond_0

    .line 13
    .line 14
    return-object p1

    .line 15
    :cond_0
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;->$started:Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 16
    .line 17
    return-object p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger$openDowngradeRun$1;->apply(Lcom/facebook/aura/analytics/hatch/CvmRun;)Lcom/facebook/aura/analytics/hatch/CvmRun;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
