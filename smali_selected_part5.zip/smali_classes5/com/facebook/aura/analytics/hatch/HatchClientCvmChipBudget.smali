.class public final Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final budgetChipsLimit:I

.field public final budgetChipsSpent:I

.field public final budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

.field public final chipsDrawnCount:Ljava/lang/Integer;

.field public final chipsSubmittedCount:Ljava/lang/Integer;

.field public final isOverBudget:Ljava/lang/Boolean;

.field public final isRebid:Ljava/lang/Boolean;

.field public final isTryAgain:Z

.field public final rememberedChipsCount:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 268435464
    .line 268435465
    iput p2, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 268435466
    .line 268435467
    iput p3, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 268435468
    .line 268435469
    iput-boolean p4, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 268435470
    .line 268435471
    iput-object p5, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 268435472
    .line 268435473
    iput-object p6, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 268435474
    .line 268435475
    iput-object p7, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 268435476
    .line 268435477
    iput-object p8, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 268435478
    .line 268435479
    iput-object p9, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 268435480
    .line 268435481
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;ILX/04f;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p10, 0x10

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p5, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x20

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p6, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p10, 0x40

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p7, v1

    .line 16
    :cond_2
    and-int/lit16 v0, p10, 0x80

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p8, v1

    .line 21
    :cond_3
    and-int/lit16 v0, p10, 0x100

    .line 22
    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    move-object p9, v1

    .line 26
    :cond_4
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;-><init>(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;ILjava/lang/Object;)Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget p2, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget p3, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p10, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 53
    .line 54
    :cond_8
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->copy(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/common/HatchCvmChipPinPurpose;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 1
    .line 2
    return p0
.end method

.method public final component3()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;-><init>(Lcom/facebook/aura/common/HatchCvmChipPinPurpose;IIZLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 17
    .line 18
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 23
    .line 24
    iget v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 25
    .line 26
    if-ne v1, v0, :cond_0

    .line 27
    .line 28
    iget-boolean v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 29
    .line 30
    iget-boolean v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 31
    .line 32
    if-ne v1, v0, :cond_0

    .line 33
    .line 34
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 35
    .line 36
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 45
    .line 46
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 47
    .line 48
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_0

    .line 53
    .line 54
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 55
    .line 56
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 65
    .line 66
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 67
    .line 68
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 75
    .line 76
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_1

    .line 83
    .line 84
    :cond_0
    return v2

    .line 85
    :cond_1
    return v3
.end method

.method public final getBudgetChipsLimit()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 1
    .line 2
    return p0
.end method

.method public final getBudgetChipsSpent()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 1
    .line 2
    return p0
.end method

.method public final getBudgetType()Lcom/facebook/aura/common/HatchCvmChipPinPurpose;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChipsDrawnCount()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChipsSubmittedCount()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRememberedChipsCount()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetType:Lcom/facebook/aura/common/HatchCvmChipPinPurpose;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsSpent:I

    .line 9
    .line 10
    add-int/2addr v1, v0

    .line 11
    mul-int/lit8 v1, v1, 0x1f

    .line 12
    .line 13
    iget v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->budgetChipsLimit:I

    .line 14
    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsSubmittedCount:Ljava/lang/Integer;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    add-int/2addr v1, v0

    .line 32
    mul-int/lit8 v1, v1, 0x1f

    .line 33
    .line 34
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->chipsDrawnCount:Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    add-int/2addr v1, v0

    .line 41
    mul-int/lit8 v1, v1, 0x1f

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 44
    .line 45
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    add-int/2addr v1, v0

    .line 50
    mul-int/lit8 v1, v1, 0x1f

    .line 51
    .line 52
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 53
    .line 54
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    add-int/2addr v1, v0

    .line 59
    mul-int/lit8 v1, v1, 0x1f

    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->rememberedChipsCount:Ljava/lang/Integer;

    .line 62
    .line 63
    if-eqz v0, :cond_0

    .line 64
    .line 65
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    :cond_0
    add-int/2addr v1, v2

    .line 70
    return v1
.end method

.method public final isOverBudget()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isOverBudget:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isRebid()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isRebid:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isTryAgain()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmChipBudget;->isTryAgain:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
