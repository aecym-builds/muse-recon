.class public final Lcom/facebook/aura/analytics/AuraLoggerHolder;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# instance fields
.field public final logger:LX/ES4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/ES4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/analytics/AuraLoggerHolder;->logger:LX/ES4;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public clearUserData()V
    .locals 0

    .line 0
    return-void
.end method

.method public final getLogger()LX/ES4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "LX/EXf;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/AuraLoggerHolder;->logger:LX/ES4;

    .line 1
    .line 2
    return-object p0
.end method
