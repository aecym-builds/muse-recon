.class public final Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CkS;


# instance fields
.field public final analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

.field public final event:LX/CkS;

.field public startTimeSec:Ljava/lang/Long;

.field public tosArray:[I

.field public tosLen:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(LX/CkS;Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 9
    .line 10
    return-void
.end method

.method private final parseBitArrayWords(Ljava/lang/String;)[I
    .locals 2

    .line 0
    const-string v1, "["

    .line 1
    .line 2
    const-string v0, "]"

    .line 3
    .line 4
    invoke-static {v1, v0, p1}, LX/AdT;->A0O(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v1, 0x0

    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    new-array p1, v1, [I

    .line 16
    .line 17
    :cond_0
    return-object p1

    .line 18
    :cond_1
    const-string v0, ","

    .line 19
    .line 20
    filled-new-array {v0}, [Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-static {p0, v0, v1}, LX/AdT;->A0k(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Ljava/lang/String;

    .line 48
    .line 49
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-static {v0}, LX/0wP;->A00(Ljava/lang/String;)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-eqz v0, :cond_0

    .line 58
    .line 59
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_2
    invoke-static {p0}, LX/B89;->A10(Ljava/util/Collection;)[I

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    return-object p1
.end method


# virtual methods
.method public addParameter(Ljava/lang/String;D)LX/CkS;
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    .line 268435461
    .line 268435462
    invoke-interface {v0, p1, p2, p3}, LX/CkS;->addParameter(Ljava/lang/String;D)LX/CkS;

    .line 268435463
    .line 268435464
    .line 268435465
    return-object p0
.end method

.method public addParameter(Ljava/lang/String;I)LX/CkS;
    .locals 1

    .line 806646988
    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 806646989
    const-string v0, "tos_len"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 806646990
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->tosLen:Ljava/lang/Integer;

    .line 806646991
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    invoke-interface {v0, p1, p2}, LX/CkS;->addParameter(Ljava/lang/String;I)LX/CkS;

    .line 806646992
    return-object p0
.end method

.method public addParameter(Ljava/lang/String;J)LX/CkS;
    .locals 1

    .line 1075082449
    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 1075082450
    const-string v0, "start_time"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1075082451
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->startTimeSec:Ljava/lang/Long;

    .line 1075082452
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    invoke-interface {v0, p1, p2, p3}, LX/CkS;->addParameter(Ljava/lang/String;J)LX/CkS;

    .line 1075082453
    return-object p0
.end method

.method public addParameter(Ljava/lang/String;Ljava/lang/String;)LX/CkS;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v0, "tos_array"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    if-eqz p2, :cond_1

    .line 13
    .line 14
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->parseBitArrayWords(Ljava/lang/String;)[I

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :goto_0
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->tosArray:[I

    .line 19
    .line 20
    if-eqz p2, :cond_0

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    const-string v1, "TimeSpentAnalytics"

    .line 25
    .line 26
    const-string v0, "Rejecting malformed time spent bit array; its CVM copy is not logged"

    .line 27
    .line 28
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    .line 32
    .line 33
    invoke-interface {v0, p1, p2}, LX/CkS;->addParameter(Ljava/lang/String;Ljava/lang/String;)LX/CkS;

    .line 34
    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_1
    const/4 v0, 0x0

    .line 38
    goto :goto_0
.end method

.method public addParameter(Ljava/lang/String;Z)LX/CkS;
    .locals 1

    .line 536870912
    const/4 v0, 0x0

    .line 536870913
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 536870914
    .line 536870915
    .line 536870916
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    .line 536870917
    .line 536870918
    invoke-interface {v0, p1, p2}, LX/CkS;->addParameter(Ljava/lang/String;Z)LX/CkS;

    .line 536870919
    .line 536870920
    .line 536870921
    return-object p0
.end method

.method public logAndRelease()V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->event:LX/CkS;

    .line 1
    .line 2
    invoke-interface {v0}, LX/CkS;->logAndRelease()V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->startTimeSec:Ljava/lang/Long;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 10
    .line 11
    .line 12
    move-result-wide v2

    .line 13
    iget-object v4, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->tosArray:[I

    .line 14
    .line 15
    if-eqz v4, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->tosLen:Ljava/lang/Integer;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 26
    .line 27
    invoke-virtual {v0, v2, v3, v4, v1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->onTimeSpentBitArray(J[II)V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method
