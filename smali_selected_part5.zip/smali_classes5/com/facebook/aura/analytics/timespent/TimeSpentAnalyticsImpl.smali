.class public final Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/timespent/TimeSpentAnalytics;


# instance fields
.field public final analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

.field public final timeSpentBitArray:LX/DWy;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v1, "AuraAnalyticsDecorator"

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;

    .line 6
    .line 7
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;->build()Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 18
    .line 19
    new-instance v2, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;

    .line 20
    .line 21
    invoke-direct {v2, p0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;-><init>(Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$2;->INSTANCE:Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$2;

    .line 25
    .line 26
    new-instance v0, LX/DWy;

    .line 27
    .line 28
    invoke-direct {v0, v2, v1}, LX/DWy;-><init>(Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;Lkotlin/jvm/functions/Function0;)V

    .line 29
    .line 30
    .line 31
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->timeSpentBitArray:LX/DWy;

    .line 32
    .line 33
    return-void
.end method

.method public static final synthetic access$getAnalyticsDecorator$p(Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;)Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 1
    .line 2
    return-object p0
.end method

.method private final now()J
    .locals 1

    .line 0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method private final processTimeSpentInteractionEvent(I)V
    .locals 10

    .line 0
    iget-object v5, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->timeSpentBitArray:LX/DWy;

    .line 1
    .line 2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 3
    .line 4
    .line 5
    move-result-wide v1

    .line 6
    const-wide/16 v3, 0x3e8

    .line 7
    .line 8
    if-eqz p1, :cond_1

    .line 9
    .line 10
    const/4 v9, 0x1

    .line 11
    if-eq p1, v9, :cond_2

    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    if-eq p1, v0, :cond_1

    .line 15
    .line 16
    const/4 v0, 0x3

    .line 17
    if-eq p1, v0, :cond_1

    .line 18
    .line 19
    const/4 v0, 0x5

    .line 20
    if-eq p1, v0, :cond_1

    .line 21
    .line 22
    const/4 v0, 0x6

    .line 23
    if-eq p1, v0, :cond_1

    .line 24
    .line 25
    const/4 v0, 0x7

    .line 26
    if-eq p1, v0, :cond_1

    .line 27
    .line 28
    :cond_0
    return-void

    .line 29
    :cond_1
    iget-object v0, v5, LX/DWy;->A06:[I

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    div-long/2addr v1, v3

    .line 34
    invoke-static {v5, p1, v1, v2}, LX/DWy;->A00(LX/DWy;IJ)LX/CkS;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    const/4 v0, 0x0

    .line 39
    iput-object v0, v5, LX/DWy;->A06:[I

    .line 40
    .line 41
    const-wide/16 v0, 0x0

    .line 42
    .line 43
    iput-wide v0, v5, LX/DWy;->A03:J

    .line 44
    .line 45
    goto :goto_2

    .line 46
    :cond_2
    div-long/2addr v1, v3

    .line 47
    iget-wide v3, v5, LX/DWy;->A03:J

    .line 48
    .line 49
    cmp-long v0, v1, v3

    .line 50
    .line 51
    if-lez v0, :cond_0

    .line 52
    .line 53
    iget-wide v6, v5, LX/DWy;->A02:J

    .line 54
    .line 55
    sub-long v3, v1, v6

    .line 56
    .line 57
    const-wide/16 v6, 0x0

    .line 58
    .line 59
    cmp-long v0, v3, v6

    .line 60
    .line 61
    if-ltz v0, :cond_5

    .line 62
    .line 63
    const-wide/16 v6, 0x40

    .line 64
    .line 65
    cmp-long v0, v3, v6

    .line 66
    .line 67
    if-gez v0, :cond_5

    .line 68
    .line 69
    const/4 v6, 0x0

    .line 70
    :goto_0
    iget-object v7, v5, LX/DWy;->A06:[I

    .line 71
    .line 72
    if-nez v7, :cond_4

    .line 73
    .line 74
    iput-wide v1, v5, LX/DWy;->A03:J

    .line 75
    .line 76
    iput-wide v1, v5, LX/DWy;->A02:J

    .line 77
    .line 78
    const/4 v0, 0x2

    .line 79
    new-array v1, v0, [I

    .line 80
    .line 81
    iput-object v1, v5, LX/DWy;->A06:[I

    .line 82
    .line 83
    const/4 v0, 0x0

    .line 84
    aput v9, v1, v0

    .line 85
    .line 86
    aput v0, v1, v9

    .line 87
    .line 88
    iget-object v0, v5, LX/DWy;->A05:Lkotlin/jvm/functions/Function0;

    .line 89
    .line 90
    if-eqz v0, :cond_3

    .line 91
    .line 92
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    check-cast v0, Ljava/lang/String;

    .line 97
    .line 98
    iput-object v0, v5, LX/DWy;->A04:Ljava/lang/String;

    .line 99
    .line 100
    :cond_3
    iget v0, v5, LX/DWy;->A01:I

    .line 101
    .line 102
    add-int/lit8 v0, v0, 0x1

    .line 103
    .line 104
    iput v0, v5, LX/DWy;->A01:I

    .line 105
    .line 106
    :goto_1
    iget v0, v5, LX/DWy;->A00:I

    .line 107
    .line 108
    add-int/lit8 v0, v0, 0x1

    .line 109
    .line 110
    iput v0, v5, LX/DWy;->A00:I

    .line 111
    .line 112
    :goto_2
    if-eqz v6, :cond_0

    .line 113
    .line 114
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 115
    .line 116
    invoke-virtual {v0, v6}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->decorateTimeSpentInteractionEvent(LX/CkS;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {v6}, LX/CkS;->logAndRelease()V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :cond_4
    long-to-int v0, v3

    .line 124
    shr-int/lit8 v4, v0, 0x5

    .line 125
    .line 126
    aget v3, v7, v4

    .line 127
    .line 128
    and-int/lit8 v0, v0, 0x1f

    .line 129
    .line 130
    shl-int/2addr v9, v0

    .line 131
    or-int/2addr v9, v3

    .line 132
    aput v9, v7, v4

    .line 133
    .line 134
    iput-wide v1, v5, LX/DWy;->A03:J

    .line 135
    .line 136
    goto :goto_1

    .line 137
    :cond_5
    invoke-static {v5, v9, v1, v2}, LX/DWy;->A00(LX/DWy;IJ)LX/CkS;

    .line 138
    .line 139
    .line 140
    move-result-object v6

    .line 141
    const/4 v0, 0x0

    .line 142
    iput-object v0, v5, LX/DWy;->A06:[I

    .line 143
    .line 144
    const-wide/16 v7, 0x0

    .line 145
    .line 146
    iput-wide v7, v5, LX/DWy;->A03:J

    .line 147
    .line 148
    goto :goto_0
.end method


# virtual methods
.method public recordAppBackgrounded()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->processTimeSpentInteractionEvent(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public recordAppForegrounded()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->processTimeSpentInteractionEvent(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public recordUserInteraction()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->processTimeSpentInteractionEvent(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public reportTimeChangeEvent()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->processTimeSpentInteractionEvent(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
