.class public final Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;->this$0:Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public acquireEvent(Ljava/lang/String;)LX/CkS;
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    new-instance v2, LX/DXI;

    .line 11
    .line 12
    invoke-direct {v2, v0, p1}, LX/DXI;-><init>(LX/H4A;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl$timeSpentBitArray$1;->this$0:Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;

    .line 16
    .line 17
    iget-object v1, v0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;

    .line 20
    .line 21
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/analytics/timespent/ObservedBitArrayEvent;-><init>(LX/CkS;Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method
