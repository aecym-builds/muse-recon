.class public final Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/timespent/AppStateAnalytics;


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl$Companion;

.field public static final EVENT_NAME:Ljava/lang/String; = "app_state"

.field public static final KEY_MODULE_INFO:Ljava/lang/String; = "module_info"

.field public static final KEY_STATE:Ljava/lang/String; = "state"

.field public static final MODULE_NAME:Ljava/lang/String; = "aura"

.field public static final VALUE_BACKGROUND:Ljava/lang/String; = "background"

.field public static final VALUE_BACKGROUND_IMMEDIATE:Ljava/lang/String; = "background_immediate"

.field public static final VALUE_FOREGROUND:Ljava/lang/String; = "foreground"


# instance fields
.field public final analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

.field public freshUIAppStart:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->Companion:Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v1, "AuraAnalyticsDecorator"

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;

    .line 6
    .line 7
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;->build()Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 18
    .line 19
    const/4 v0, 0x1

    .line 20
    iput-boolean v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->freshUIAppStart:Z

    .line 21
    .line 22
    return-void
.end method

.method private final recordAppState(Ljava/lang/String;Z)V
    .locals 5

    .line 0
    const-string v0, "foreground"

    .line 1
    .line 2
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v4

    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    const-string v2, "aura"

    .line 13
    .line 14
    const-string v1, "app_state"

    .line 15
    .line 16
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-static {v3, v0, v2, v1, p2}, LX/H4A;->A01(LX/H4A;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Z)LX/H49;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v2}, LX/H49;->A0A()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->freshUIAppStart:Z

    .line 34
    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 38
    .line 39
    invoke-interface {v0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->getModuleInfo()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    const-string v0, "module_info"

    .line 44
    .line 45
    invoke-virtual {v2, v0, v1}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    const-string v0, "state"

    .line 49
    .line 50
    invoke-virtual {v2, v0, p1}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 54
    .line 55
    invoke-virtual {v0, v2}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->decorateTimeSpentAppStateEvent(LX/H49;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2}, LX/H49;->A05()V

    .line 59
    .line 60
    .line 61
    :cond_1
    if-eqz v4, :cond_2

    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    iput-boolean v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->freshUIAppStart:Z

    .line 65
    .line 66
    :cond_2
    return-void
.end method

.method public static synthetic recordAppState$default(Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;Ljava/lang/String;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->recordAppState(Ljava/lang/String;Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final shouldLogEvent()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method


# virtual methods
.method public markFreshUIAppStart()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->freshUIAppStart:Z

    .line 2
    .line 3
    return-void
.end method

.method public recordAppBackgrounded()V
    .locals 2

    .line 0
    const-string v1, "background"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->recordAppState(Ljava/lang/String;Z)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->onTimeSpentAppBackgrounded()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public recordAppBackgroundedImmediate()V
    .locals 2

    .line 0
    const-string v1, "background_immediate"

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->recordAppState(Ljava/lang/String;Z)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public recordAppForegrounded()V
    .locals 2

    .line 0
    const-string v1, "foreground"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->recordAppState(Ljava/lang/String;Z)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/AppStateAnalyticsImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->onTimeSpentAppForegrounded()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
