.class public final Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;

.field public static final TAG:Ljava/lang/String; = "AuraNavigationLogger"

.field public static final instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->INSTANCE:Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;

    .line 6
    .line 7
    const v0, 0xc002

    .line 8
    .line 9
    .line 10
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->getNavigationLoggingEnabled()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;

    .line 23
    .line 24
    invoke-direct {v0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;-><init>()V

    .line 25
    .line 26
    .line 27
    :goto_0
    check-cast v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerNoOp;

    .line 33
    .line 34
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 35
    .line 36
    .line 37
    goto :goto_0
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getInstance()Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 1
    .line 2
    return-object p0
.end method
