.class public final Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;


# static fields
.field public static final CLICK_POINT_CONTEXT:Ljava/lang/String; = "click_point_context"

.field public static final CLICK_POINT_KEY:Ljava/lang/String; = "click_point"

.field public static final Companion:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl$Companion;

.field public static final DEVICE_TYPE_KEY:Ljava/lang/String; = "device_type"

.field public static final EVENT_SUBTYPE_KEY:Ljava/lang/String; = "event_subtype"

.field public static final MODULE_NAME:Ljava/lang/String; = "aura"

.field public static final NAVIGATION_EVENT_NAME:Ljava/lang/String; = "navigation"

.field public static final PIGEON_MODULE_KEYWORD:Ljava/lang/String; = "pigeon_reserved_keyword_module"

.field public static final URL_PARAM:Ljava/lang/String; = "url"


# instance fields
.field public final analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

.field public currNavEventData:LX/DXZ;

.field public navigationsSinceForegrounding:I

.field public prevNavEventData:LX/DXZ;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->Companion:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v1, "AuraAnalyticsDecorator"

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;

    .line 6
    .line 7
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$BuilderImpl;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface$Builder;->build()Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 18
    .line 19
    new-instance v0, LX/DXZ;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 25
    .line 26
    new-instance v0, LX/DXZ;

    .line 27
    .line 28
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->prevNavEventData:LX/DXZ;

    .line 32
    .line 33
    return-void
.end method

.method public static final synthetic access$getNavigationsSinceForegrounding$p(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->navigationsSinceForegrounding:I

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$reportNavigationEvent(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;LX/DXZ;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->reportNavigationEvent(LX/DXZ;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final addInstallerName(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    :try_start_0
    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    const-string v1, ""

    .line 21
    .line 22
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    :catch_0
    move-exception p0

    .line 24
    const-string v1, "PackageUtil"

    .line 25
    .line 26
    const-string v0, "Failed to get installer package name due to invalid package name"

    .line 27
    .line 28
    invoke-static {v1, p0, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v1, "unknown"

    .line 32
    .line 33
    :cond_0
    :goto_0
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_1

    .line 38
    .line 39
    const-string v0, "installer_name"

    .line 40
    .line 41
    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    :cond_1
    return-void
.end method

.method private final appendDestModuleUri(Ljava/util/Map;Landroid/net/Uri;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .line 0
    const-string p0, "dest_module_uri"

    .line 1
    .line 2
    invoke-interface {p1, p0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method private final findNearestAnalyticsActivityAncestor(Landroidx/fragment/app/Fragment;)LX/DXc;
    .locals 1

    .line 0
    iget-object v0, p1, Landroidx/fragment/app/Fragment;->mParentFragment:Landroidx/fragment/app/Fragment;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->findNearestAnalyticsActivityAncestor(Landroidx/fragment/app/Fragment;)LX/DXc;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    return-object v0
.end method

.method private final getModuleClass(Ljava/lang/Object;)Ljava/lang/String;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-static {p1}, LX/I8A;->A00(Ljava/lang/Object;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0

    .line 7
    :cond_0
    const/4 p0, 0x0

    .line 8
    return-object p0
.end method

.method private final prepareForNextEvent()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 1
    .line 2
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->prevNavEventData:LX/DXZ;

    .line 3
    .line 4
    new-instance v3, LX/DXZ;

    .line 5
    .line 6
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v3, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 10
    .line 11
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->getPrevNavEventData()LX/DXZ;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget-object v0, v2, LX/DXZ;->A03:Ljava/lang/String;

    .line 16
    .line 17
    iput-object v0, v3, LX/DXZ;->A05:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v0, v2, LX/DXZ;->A02:Ljava/lang/String;

    .line 20
    .line 21
    iput-object v0, v3, LX/DXZ;->A04:Ljava/lang/String;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->navigationsSinceForegrounding:I

    .line 24
    .line 25
    add-int/lit8 v0, v0, 0x1

    .line 26
    .line 27
    iput v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->navigationsSinceForegrounding:I

    .line 28
    .line 29
    const-string v1, "dest_fragment_hash_value"

    .line 30
    .line 31
    iget-object v0, v2, LX/DXZ;->A06:Ljava/util/Map;

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    :goto_0
    const-string v0, "source_fragment_hash_value"

    .line 37
    .line 38
    invoke-virtual {v3, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :cond_0
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    goto :goto_0
.end method

.method private final reportNavigationEvent(LX/DXZ;I)V
    .locals 6

    .line 0
    new-instance v5, Ljava/util/LinkedHashMap;

    .line 1
    .line 2
    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p1}, LX/DXZ;->A00()Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string v2, "device_type"

    .line 12
    .line 13
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    instance-of v0, v1, Ljava/lang/String;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v5, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    :cond_0
    invoke-virtual {p1}, LX/DXZ;->A00()Ljava/util/Map;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    const-string v2, "manual_logging_reason"

    .line 33
    .line 34
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    if-eqz v1, :cond_1

    .line 39
    .line 40
    instance-of v0, v1, Ljava/lang/String;

    .line 41
    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    invoke-virtual {v5, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    :cond_1
    invoke-virtual {p1}, LX/DXZ;->A00()Ljava/util/Map;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    const-string v2, "click_point"

    .line 54
    .line 55
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_2

    .line 60
    .line 61
    instance-of v0, v1, Ljava/lang/String;

    .line 62
    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    invoke-virtual {v5, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    :cond_2
    invoke-virtual {p1}, LX/DXZ;->A00()Ljava/util/Map;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    const-string v2, "event_subtype"

    .line 75
    .line 76
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    if-eqz v1, :cond_3

    .line 81
    .line 82
    instance-of v0, v1, Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v0, :cond_3

    .line 85
    .line 86
    invoke-virtual {v5, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    :cond_3
    invoke-virtual {p1}, LX/DXZ;->A00()Ljava/util/Map;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    const-string v2, "device_locale"

    .line 94
    .line 95
    const/4 v1, 0x0

    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    :cond_4
    instance-of v0, v1, Ljava/lang/String;

    .line 103
    .line 104
    if-eqz v0, :cond_5

    .line 105
    .line 106
    if-eqz v1, :cond_5

    .line 107
    .line 108
    invoke-virtual {v5, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    :cond_5
    iget-object v1, p1, LX/DXZ;->A05:Ljava/lang/String;

    .line 112
    .line 113
    if-nez v1, :cond_6

    .line 114
    .line 115
    const-string v1, "unknown"

    .line 116
    .line 117
    :cond_6
    const-string v0, "pigeon_reserved_keyword_module"

    .line 118
    .line 119
    invoke-virtual {v5, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    iget-object v1, p1, LX/DXZ;->A05:Ljava/lang/String;

    .line 123
    .line 124
    const-string v2, ""

    .line 125
    .line 126
    if-nez v1, :cond_7

    .line 127
    .line 128
    move-object v1, v2

    .line 129
    :cond_7
    const-string v0, "source_module"

    .line 130
    .line 131
    invoke-virtual {v5, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    iget-object v1, p1, LX/DXZ;->A04:Ljava/lang/String;

    .line 135
    .line 136
    if-nez v1, :cond_8

    .line 137
    .line 138
    move-object v1, v2

    .line 139
    :cond_8
    const-string v0, "source_module_class"

    .line 140
    .line 141
    invoke-virtual {v5, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    iget-object v1, p1, LX/DXZ;->A03:Ljava/lang/String;

    .line 145
    .line 146
    if-nez v1, :cond_9

    .line 147
    .line 148
    move-object v1, v2

    .line 149
    :cond_9
    const-string v0, "dest_module"

    .line 150
    .line 151
    invoke-virtual {v5, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    iget-object v0, p1, LX/DXZ;->A02:Ljava/lang/String;

    .line 155
    .line 156
    if-eqz v0, :cond_a

    .line 157
    .line 158
    move-object v2, v0

    .line 159
    :cond_a
    const-string v0, "dest_module_class"

    .line 160
    .line 161
    invoke-virtual {v5, v0, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    const-string v1, "seq"

    .line 165
    .line 166
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v5, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    const-string v1, "from_ant"

    .line 174
    .line 175
    const-string v0, "true"

    .line 176
    .line 177
    invoke-virtual {v5, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    invoke-direct {p0, v5}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->addInstallerName(Ljava/util/Map;)V

    .line 181
    .line 182
    .line 183
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 184
    .line 185
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->onTimeSpentNavigation()V

    .line 186
    .line 187
    .line 188
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 189
    .line 190
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 191
    .line 192
    .line 193
    move-result-object v4

    .line 194
    iget-object v3, p1, LX/DXZ;->A05:Ljava/lang/String;

    .line 195
    .line 196
    if-nez v3, :cond_b

    .line 197
    .line 198
    const-string v3, "aura"

    .line 199
    .line 200
    :cond_b
    const-string v2, "navigation"

    .line 201
    .line 202
    sget-object v1, LX/FkO;->A00:Ljava/lang/Integer;

    .line 203
    .line 204
    const/4 v0, 0x1

    .line 205
    invoke-static {v4, v1, v3, v2, v0}, LX/H4A;->A01(LX/H4A;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Z)LX/H49;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    invoke-static {v4}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v4}, LX/H49;->A0A()Z

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    if-eqz v0, :cond_f

    .line 217
    .line 218
    invoke-virtual {v5}, Ljava/util/AbstractMap;->entrySet()Ljava/util/Set;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 223
    .line 224
    .line 225
    move-result-object v3

    .line 226
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    if-eqz v0, :cond_c

    .line 231
    .line 232
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    check-cast v0, Ljava/util/Map$Entry;

    .line 237
    .line 238
    invoke-virtual {v4}, LX/H49;->A04()LX/GFv;

    .line 239
    .line 240
    .line 241
    move-result-object v2

    .line 242
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v1

    .line 246
    check-cast v1, Ljava/lang/String;

    .line 247
    .line 248
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    invoke-static {v2, v0, v1}, LX/GFv;->A01(LX/GFv;Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    goto :goto_0

    .line 256
    :cond_c
    const-string v1, "dest_module_uri"

    .line 257
    .line 258
    iget-object v0, p1, LX/DXZ;->A06:Ljava/util/Map;

    .line 259
    .line 260
    if-eqz v0, :cond_d

    .line 261
    .line 262
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v3

    .line 266
    if-eqz v3, :cond_d

    .line 267
    .line 268
    invoke-static {}, LX/GFw;->A00()LX/GFw;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    invoke-virtual {v0}, LX/GFw;->A02()LX/GFv;

    .line 273
    .line 274
    .line 275
    move-result-object v2

    .line 276
    const-string v1, "url"

    .line 277
    .line 278
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    invoke-static {v2, v0, v1}, LX/GFv;->A01(LX/GFv;Ljava/lang/Object;Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v4}, LX/H49;->A04()LX/GFv;

    .line 286
    .line 287
    .line 288
    move-result-object v1

    .line 289
    const-string v0, "click_point_context"

    .line 290
    .line 291
    invoke-virtual {v1, v2, v0}, LX/GFv;->A0E(LX/Frc;Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    :cond_d
    iget-object v0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->analyticsDecorator:Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;

    .line 295
    .line 296
    invoke-virtual {v0, v4}, Lcom/facebook/aura/analytics/plugins/interfaces/analyticsdecorator/AuraAnalyticsDecoratorInterface;->decorateTimeSpentNavigationEvent(LX/H49;)V

    .line 297
    .line 298
    .line 299
    iget-object v0, p1, LX/DXZ;->A01:Ljava/lang/Long;

    .line 300
    .line 301
    if-eqz v0, :cond_e

    .line 302
    .line 303
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 304
    .line 305
    .line 306
    move-result-wide v0

    .line 307
    invoke-virtual {v4, v0, v1}, LX/H49;->A06(J)V

    .line 308
    .line 309
    .line 310
    :cond_e
    invoke-virtual {v4}, LX/H49;->A05()V

    .line 311
    .line 312
    .line 313
    :cond_f
    iget-object v0, p1, LX/DXZ;->A04:Ljava/lang/String;

    .line 314
    .line 315
    iget-object v1, p1, LX/DXZ;->A05:Ljava/lang/String;

    .line 316
    .line 317
    iget-object v2, p1, LX/DXZ;->A02:Ljava/lang/String;

    .line 318
    .line 319
    iget-object v3, p1, LX/DXZ;->A03:Ljava/lang/String;

    .line 320
    .line 321
    const-string v4, "AuraNavigationLogger"

    .line 322
    .line 323
    const-string v5, "Navigation from \'%s:%s\' to \'%s:%s\'."

    .line 324
    .line 325
    invoke-static/range {v0 .. v5}, LX/FnY;->A00(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    return-void
.end method

.method private final reportNavigationEvent(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    iget-object v5, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 268435457
    .line 268435458
    iput-object p1, v5, LX/DXZ;->A03:Ljava/lang/String;

    .line 268435459
    .line 268435460
    iput-object p2, v5, LX/DXZ;->A02:Ljava/lang/String;

    .line 268435461
    .line 268435462
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-wide v0

    .line 268435466
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    iput-object v0, v5, LX/DXZ;->A01:Ljava/lang/Long;

    .line 268435471
    .line 268435472
    if-eqz p3, :cond_2

    .line 268435473
    .line 268435474
    iget-object v0, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435475
    .line 268435476
    if-nez v0, :cond_0

    .line 268435477
    .line 268435478
    new-instance v0, Ljava/util/HashMap;

    .line 268435479
    .line 268435480
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 268435481
    .line 268435482
    .line 268435483
    iput-object v0, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435484
    .line 268435485
    :cond_0
    invoke-static {p3}, LX/002;->A1A(Ljava/util/Map;)Ljava/util/Iterator;

    .line 268435486
    .line 268435487
    .line 268435488
    move-result-object v4

    .line 268435489
    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 268435490
    .line 268435491
    .line 268435492
    move-result v0

    .line 268435493
    if-eqz v0, :cond_2

    .line 268435494
    .line 268435495
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268435496
    .line 268435497
    .line 268435498
    move-result-object v3

    .line 268435499
    check-cast v3, Ljava/util/Map$Entry;

    .line 268435500
    .line 268435501
    iget-object v1, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435502
    .line 268435503
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 268435504
    .line 268435505
    .line 268435506
    move-result-object v0

    .line 268435507
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435508
    .line 268435509
    .line 268435510
    move-result-object v0

    .line 268435511
    if-nez v0, :cond_1

    .line 268435512
    .line 268435513
    iget-object v2, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435514
    .line 268435515
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 268435516
    .line 268435517
    .line 268435518
    move-result-object v1

    .line 268435519
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 268435520
    .line 268435521
    .line 268435522
    move-result-object v0

    .line 268435523
    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435524
    .line 268435525
    .line 268435526
    goto :goto_0

    .line 268435527
    :cond_2
    iget-object v0, v5, LX/DXZ;->A07:Ljava/util/Map;

    .line 268435528
    .line 268435529
    if-nez v0, :cond_7

    .line 268435530
    .line 268435531
    const/4 v9, 0x0

    .line 268435532
    :cond_3
    iget-object v0, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435533
    .line 268435534
    if-nez v0, :cond_6

    .line 268435535
    .line 268435536
    iput-object v9, v5, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435537
    .line 268435538
    :cond_4
    :goto_1
    const/4 v9, 0x0

    .line 268435539
    iput-object v9, v5, LX/DXZ;->A07:Ljava/util/Map;

    .line 268435540
    .line 268435541
    iget-object v3, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 268435542
    .line 268435543
    iget-object v8, v3, LX/DXZ;->A05:Ljava/lang/String;

    .line 268435544
    .line 268435545
    iget-object v7, v3, LX/DXZ;->A04:Ljava/lang/String;

    .line 268435546
    .line 268435547
    iget-object v6, v3, LX/DXZ;->A03:Ljava/lang/String;

    .line 268435548
    .line 268435549
    iget-object v5, v3, LX/DXZ;->A02:Ljava/lang/String;

    .line 268435550
    .line 268435551
    iget-object v4, v3, LX/DXZ;->A01:Ljava/lang/Long;

    .line 268435552
    .line 268435553
    invoke-virtual {v3}, LX/DXZ;->A00()Ljava/util/Map;

    .line 268435554
    .line 268435555
    .line 268435556
    move-result-object v2

    .line 268435557
    iget-object v1, v3, LX/DXZ;->A07:Ljava/util/Map;

    .line 268435558
    .line 268435559
    if-eqz v1, :cond_5

    .line 268435560
    .line 268435561
    new-instance v0, Ljava/util/HashMap;

    .line 268435562
    .line 268435563
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 268435564
    .line 268435565
    .line 268435566
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 268435567
    .line 268435568
    .line 268435569
    move-result-object v9

    .line 268435570
    :cond_5
    iget-object v0, v3, LX/DXZ;->A00:Lcom/facebook/privacy/zone/api/ZonedValue;

    .line 268435571
    .line 268435572
    new-instance v3, LX/DXZ;

    .line 268435573
    .line 268435574
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 268435575
    .line 268435576
    .line 268435577
    iput-object v8, v3, LX/DXZ;->A05:Ljava/lang/String;

    .line 268435578
    .line 268435579
    iput-object v7, v3, LX/DXZ;->A04:Ljava/lang/String;

    .line 268435580
    .line 268435581
    iput-object v6, v3, LX/DXZ;->A03:Ljava/lang/String;

    .line 268435582
    .line 268435583
    iput-object v5, v3, LX/DXZ;->A02:Ljava/lang/String;

    .line 268435584
    .line 268435585
    iput-object v4, v3, LX/DXZ;->A01:Ljava/lang/Long;

    .line 268435586
    .line 268435587
    iput-object v2, v3, LX/DXZ;->A06:Ljava/util/Map;

    .line 268435588
    .line 268435589
    iput-object v9, v3, LX/DXZ;->A07:Ljava/util/Map;

    .line 268435590
    .line 268435591
    iput-object v0, v3, LX/DXZ;->A00:Lcom/facebook/privacy/zone/api/ZonedValue;

    .line 268435592
    .line 268435593
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 268435594
    .line 268435595
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->io()LX/BqD;

    .line 268435596
    .line 268435597
    .line 268435598
    move-result-object v0

    .line 268435599
    invoke-static {v0}, LX/EPV;->A01(LX/BqD;)LX/EQC;

    .line 268435600
    .line 268435601
    .line 268435602
    move-result-object v2

    .line 268435603
    const/4 v1, 0x0

    .line 268435604
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl$reportNavigationEvent$1;

    .line 268435605
    .line 268435606
    invoke-direct {v0, p0, v3, v1}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl$reportNavigationEvent$1;-><init>(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;LX/DXZ;LX/2M4;)V

    .line 268435607
    .line 268435608
    .line 268435609
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 268435610
    .line 268435611
    .line 268435612
    invoke-direct {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->prepareForNextEvent()V

    .line 268435613
    .line 268435614
    .line 268435615
    return-void

    .line 268435616
    :cond_6
    if-eqz v9, :cond_4

    .line 268435617
    .line 268435618
    invoke-interface {v0, v9}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    .line 268435619
    .line 268435620
    .line 268435621
    goto :goto_1

    .line 268435622
    :cond_7
    new-instance v9, Ljava/util/HashMap;

    .line 268435623
    .line 268435624
    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    .line 268435625
    .line 268435626
    .line 268435627
    invoke-static {v0}, LX/002;->A1A(Ljava/util/Map;)Ljava/util/Iterator;

    .line 268435628
    .line 268435629
    .line 268435630
    move-result-object v8

    .line 268435631
    :cond_8
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 268435632
    .line 268435633
    .line 268435634
    move-result v0

    .line 268435635
    if-eqz v0, :cond_3

    .line 268435636
    .line 268435637
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268435638
    .line 268435639
    .line 268435640
    move-result-object v7

    .line 268435641
    check-cast v7, Ljava/util/Map$Entry;

    .line 268435642
    .line 268435643
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 268435644
    .line 268435645
    .line 268435646
    move-result-object v6

    .line 268435647
    check-cast v6, LX/145;

    .line 268435648
    .line 268435649
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 268435650
    .line 268435651
    .line 268435652
    move-result-wide v3

    .line 268435653
    iget-wide v0, v6, LX/145;->A00:J

    .line 268435654
    .line 268435655
    sub-long/2addr v3, v0

    .line 268435656
    const-wide/16 v1, 0x2710

    .line 268435657
    .line 268435658
    cmp-long v0, v3, v1

    .line 268435659
    .line 268435660
    if-gez v0, :cond_8

    .line 268435661
    .line 268435662
    iget-object v1, v6, LX/145;->A01:Ljava/lang/Object;

    .line 268435663
    .line 268435664
    if-eqz v1, :cond_8

    .line 268435665
    .line 268435666
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 268435667
    .line 268435668
    .line 268435669
    move-result-object v0

    .line 268435670
    invoke-virtual {v9, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435671
    .line 268435672
    .line 268435673
    goto :goto_2
.end method

.method private final tryGetAnalyticsExtraData(LX/DXa;Ljava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DXa;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 1
    .line 2
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 3
    .line 4
    .line 5
    :try_start_0
    const-string v1, "getAnalyticsExtraData"

    .line 6
    .line 7
    new-instance v0, Ljava/lang/NullPointerException;

    .line 8
    .line 9
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    throw v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    :catch_0
    move-exception p0

    .line 14
    if-nez p2, :cond_0

    .line 15
    .line 16
    const-string p2, ""

    .line 17
    .line 18
    :cond_0
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    const-string v1, "AuraNavigationLogger"

    .line 23
    .line 24
    const-string v0, "getting analyticsExtraData has an unexpected implementation"

    .line 25
    .line 26
    invoke-static {v1, v0, p0, v2}, LX/FnY;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-object p1
.end method

.method private final tryGetAnalyticsName(LX/DXc;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 0
    :try_start_0
    const-string v1, "getAnalyticsName"

    .line 1
    .line 2
    new-instance v0, Ljava/lang/NullPointerException;

    .line 3
    .line 4
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    throw v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 8
    :catch_0
    move-exception p1

    .line 9
    if-nez p2, :cond_0

    .line 10
    .line 11
    const-string p2, ""

    .line 12
    .line 13
    :cond_0
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string v1, "AuraNavigationLogger"

    .line 18
    .line 19
    const-string v0, "getting analyticsName has an unexpected implementation"

    .line 20
    .line 21
    invoke-static {v1, v0, p1, p0}, LX/FnY;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    return-object v0
.end method


# virtual methods
.method public getCurrentNavEventData()LX/DXZ;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 1
    .line 2
    return-object p0
.end method

.method public getModuleInfo()Ljava/lang/String;
    .locals 2

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->getPrevNavEventData()LX/DXZ;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-object p0, v0, LX/DXZ;->A02:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v1, v0, LX/DXZ;->A03:Ljava/lang/String;

    .line 7
    .line 8
    const-string v0, ":"

    .line 9
    .line 10
    invoke-static {p0, v0, v1}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public getPrevNavEventData()LX/DXZ;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->prevNavEventData:LX/DXZ;

    .line 1
    .line 2
    return-object p0
.end method

.method public reportNavigationEventForActivity(Landroid/app/Activity;)V
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/I8A;->A00(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "dest_fragment_hash_value"

    .line 24
    .line 25
    invoke-virtual {v2, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 29
    .line 30
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 31
    .line 32
    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const-string v0, "dest_object_ref"

    .line 36
    .line 37
    invoke-virtual {v2, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    const/4 v2, 0x0

    .line 41
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    const-string v0, "dest_module_uri"

    .line 50
    .line 51
    invoke-virtual {v3, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    invoke-direct {p0, v2, v4, v3}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->reportNavigationEvent(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public reportNavigationEventForComposable(Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 4
    .line 5
    const-string v1, "dest_fragment_hash_value"

    .line 6
    .line 7
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v2, v0, v1}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 15
    .line 16
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 17
    .line 18
    invoke-direct {v1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "dest_object_ref"

    .line 22
    .line 23
    invoke-virtual {v2, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p0, p1, p2, p4}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->reportNavigationEvent(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public reportNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/I8A;->A00(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    new-instance v6, Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "dest_fragment_hash_value"

    .line 24
    .line 25
    invoke-virtual {v2, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->currNavEventData:LX/DXZ;

    .line 29
    .line 30
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 31
    .line 32
    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const-string v0, "dest_object_ref"

    .line 36
    .line 37
    invoke-virtual {v2, v1, v0}, LX/DXZ;->A01(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->findNearestAnalyticsActivityAncestor(Landroidx/fragment/app/Fragment;)LX/DXc;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    const/4 v3, 0x0

    .line 45
    if-eqz v0, :cond_4

    .line 46
    .line 47
    invoke-direct {p0, v0, v5}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->tryGetAnalyticsName(LX/DXc;Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-nez v0, :cond_0

    .line 56
    .line 57
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 58
    .line 59
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v2, v6}, Ljava/util/AbstractMap;->putAll(Ljava/util/Map;)V

    .line 63
    .line 64
    .line 65
    const/4 v0, 0x1

    .line 66
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    const-string v0, "use_inherited_metadata"

    .line 71
    .line 72
    invoke-virtual {v2, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-object v6, v2

    .line 76
    :cond_0
    :goto_0
    if-eqz p2, :cond_1

    .line 77
    .line 78
    const-string v0, "manual_logging_reason"

    .line 79
    .line 80
    invoke-virtual {v6, v0, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    :cond_1
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    if-eqz v0, :cond_3

    .line 94
    .line 95
    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    :goto_1
    const-string v0, "dest_module_uri"

    .line 100
    .line 101
    invoke-virtual {v6, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    invoke-direct {p0, v4, v5, v6}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerImpl;->reportNavigationEvent(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    if-eqz v0, :cond_2

    .line 112
    .line 113
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    if-eqz v0, :cond_2

    .line 118
    .line 119
    invoke-virtual {v0, v3}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 120
    .line 121
    .line 122
    :cond_2
    return-void

    .line 123
    :cond_3
    move-object v1, v3

    .line 124
    goto :goto_1

    .line 125
    :cond_4
    move-object v4, v3

    .line 126
    goto :goto_0
.end method
