.class public final Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0xf627

.field public static final INSTANCE:Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;

.field public static final __CONFIG__:I = 0x12f

.field public static final android_app_state_enabled:LX/0d8;

.field public static final android_bit_array_interaction_enabled:LX/0d8;

.field public static final android_navigation_enabled:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->INSTANCE:Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;

    .line 6
    .line 7
    const-wide v1, 0x2041012f00020021L    # 2.536525508480269E-153

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_app_state_enabled:LX/0d8;

    .line 18
    .line 19
    const-wide v1, 0x2041012f00010020L    # 2.536525508445538E-153

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    new-instance v0, LX/0d8;

    .line 25
    .line 26
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_bit_array_interaction_enabled:LX/0d8;

    .line 30
    .line 31
    const-wide v1, 0x2041012f0000001fL    # 2.536525508410807E-153

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    new-instance v0, LX/0d8;

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_navigation_enabled:LX/0d8;

    .line 42
    .line 43
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
