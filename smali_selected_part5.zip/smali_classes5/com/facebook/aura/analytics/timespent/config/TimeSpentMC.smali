.class public final Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final appStateLoggingEnabled$delegate:LX/1zE;

.field public final bitArrayInteractionLoggingEnabled$delegate:LX/1zE;

.field public final navigationLoggingEnabled$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const-string v1, "appStateLoggingEnabled"

    .line 1
    .line 2
    const-string v0, "getAppStateLoggingEnabled()Z"

    .line 3
    .line 4
    const-class v6, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;

    .line 5
    .line 6
    const/4 v5, 0x0

    .line 7
    new-instance v4, LX/DVg;

    .line 8
    .line 9
    invoke-direct {v4, v6, v1, v0, v5}, LX/DVg;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 10
    .line 11
    .line 12
    const-string v1, "bitArrayInteractionLoggingEnabled"

    .line 13
    .line 14
    const-string v0, "getBitArrayInteractionLoggingEnabled()Z"

    .line 15
    .line 16
    new-instance v3, LX/DVg;

    .line 17
    .line 18
    invoke-direct {v3, v6, v1, v0, v5}, LX/DVg;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 19
    .line 20
    .line 21
    const-string v2, "navigationLoggingEnabled"

    .line 22
    .line 23
    const-string v1, "getNavigationLoggingEnabled()Z"

    .line 24
    .line 25
    new-instance v0, LX/DVg;

    .line 26
    .line 27
    invoke-direct {v0, v6, v2, v1, v5}, LX/DVg;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 28
    .line 29
    .line 30
    filled-new-array {v4, v3, v0}, [LX/Dqa;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sput-object v0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->$$delegatedProperties:[LX/Dqa;

    .line 35
    .line 36
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_app_state_enabled:LX/0d8;

    .line 4
    .line 5
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->appStateLoggingEnabled$delegate:LX/1zE;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_bit_array_interaction_enabled:LX/0d8;

    .line 12
    .line 13
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->bitArrayInteractionLoggingEnabled$delegate:LX/1zE;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/analytics/timespent/config/MC$mwa_time_spent_killswitch;->android_navigation_enabled:LX/0d8;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->navigationLoggingEnabled$delegate:LX/1zE;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final getAppStateLoggingEnabled()Z
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->appStateLoggingEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    invoke-static {p0, v1, v0}, LX/8mk;->A1X(Ljava/lang/Object;LX/1zE;[LX/Dqa;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method public final getBitArrayInteractionLoggingEnabled()Z
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->bitArrayInteractionLoggingEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p0, v2, v1, v0}, LX/8mk;->A1Y(Ljava/lang/Object;LX/1zE;[LX/Dqa;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public final getNavigationLoggingEnabled()Z
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->navigationLoggingEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-static {p0, v2, v1, v0}, LX/8mk;->A1Y(Ljava/lang/Object;LX/1zE;[LX/Dqa;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method
