.class public final Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsNoOp;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/timespent/TimeSpentAnalytics;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public recordAppBackgrounded()V
    .locals 0

    .line 0
    return-void
.end method

.method public recordAppForegrounded()V
    .locals 0

    .line 0
    return-void
.end method

.method public recordUserInteraction()V
    .locals 0

    .line 0
    return-void
.end method

.method public reportTimeChangeEvent()V
    .locals 0

    .line 0
    return-void
.end method
