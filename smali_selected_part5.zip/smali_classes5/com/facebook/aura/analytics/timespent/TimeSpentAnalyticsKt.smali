.class public abstract Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "TimeSpentAnalytics"


# direct methods
.method public static final providesTimeSpentAnalytics()Lcom/facebook/aura/analytics/timespent/TimeSpentAnalytics;
    .locals 1

    .line 0
    const v0, 0xc002

    .line 1
    .line 2
    .line 3
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;

    .line 8
    .line 9
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/timespent/config/TimeSpentMC;->getBitArrayInteractionLoggingEnabled()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;

    .line 16
    .line 17
    invoke-direct {v0}, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsImpl;-><init>()V

    .line 18
    .line 19
    .line 20
    :goto_0
    check-cast v0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalytics;

    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/TimeSpentAnalyticsNoOp;

    .line 24
    .line 25
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 26
    .line 27
    .line 28
    goto :goto_0
.end method
