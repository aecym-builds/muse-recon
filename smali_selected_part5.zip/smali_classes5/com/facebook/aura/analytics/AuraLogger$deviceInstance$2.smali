.class public final Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/Der;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/Der;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->deviceInstance$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/H4A;

    .line 7
    .line 8
    new-instance v0, LX/Der;

    .line 9
    .line 10
    invoke-direct {v0, p0}, LX/Der;-><init>(LX/H4A;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraLogger$deviceInstance$2;->invoke()LX/Der;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
