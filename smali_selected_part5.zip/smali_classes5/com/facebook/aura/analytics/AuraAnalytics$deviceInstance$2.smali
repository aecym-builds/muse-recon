.class public final Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/H4A;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/H4A;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->analyticsProvider$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/AuraAnalyticsProviderInterface;->mDelegate:Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;

    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/aura/analytics/plugins/interfaces/auraanalyticsprovider/IAuraAnalyticsProviderInterface;->getDeviceAnalyticsLogger()LX/H4A;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_0
    const-string p0, "Required value was null."

    .line 18
    .line 19
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraAnalytics$deviceInstance$2;->invoke()LX/H4A;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
