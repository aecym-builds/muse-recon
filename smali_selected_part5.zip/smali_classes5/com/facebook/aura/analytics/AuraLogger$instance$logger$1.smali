.class public final Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/analytics/AuraLoggerHolder;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/analytics/AuraLoggerHolder;
    .locals 1

    .line 0
    const-string v0, "AuraLogger"

    .line 1
    .line 2
    invoke-static {v0}, LX/I6a;->A00(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    new-instance p0, LX/Der;

    .line 12
    .line 13
    invoke-direct {p0, v0}, LX/Der;-><init>(LX/H4A;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    .line 16
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/analytics/AuraLoggerHolder;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Lcom/facebook/aura/analytics/AuraLoggerHolder;-><init>(LX/ES4;)V

    .line 22
    .line 23
    .line 24
    return-object v0

    .line 25
    :catchall_0
    move-exception v0

    .line 26
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 27
    .line 28
    .line 29
    throw v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraLogger$instance$logger$1;->invoke()Lcom/facebook/aura/analytics/AuraLoggerHolder;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
