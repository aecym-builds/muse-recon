.class public final Lcom/facebook/aura/analytics/impl/HatchModeAttribution;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

.field public static final _isCvm:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public static final isCvm:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->INSTANCE:Lcom/facebook/aura/analytics/impl/HatchModeAttribution;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    sget-object v0, LX/Ddx;->A01:LX/ER9;

    .line 9
    .line 10
    new-instance v1, LX/Ddv;

    .line 11
    .line 12
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sput-object v1, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->_isCvm:LX/2J2;

    .line 16
    .line 17
    new-instance v0, LX/ERk;

    .line 18
    .line 19
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 20
    .line 21
    .line 22
    sput-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->isCvm:LX/2J3;

    .line 23
    .line 24
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final isCvm()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->isCvm:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final publish(Ljava/lang/Boolean;)V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->_isCvm:LX/2J2;

    .line 1
    .line 2
    invoke-interface {p0, p1}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
