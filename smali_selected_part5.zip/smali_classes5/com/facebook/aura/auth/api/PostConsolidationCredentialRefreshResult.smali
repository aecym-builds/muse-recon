.class public final enum Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum EXCHANGE_FAILED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum IDENTITY_MISMATCH:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum MISSING_SURVIVOR_CREDENTIAL:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum NON_SESSION_OUTCOME:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum PERSISTENCE_FAILED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum SESSION_CHANGED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum SUCCESS:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

.field public static final enum TEMP_TOKEN_UNAVAILABLE:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "success"

    .line 2
    .line 3
    const-string v0, "SUCCESS"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->SUCCESS:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "missing_survivor_credential"

    .line 14
    .line 15
    const-string v0, "MISSING_SURVIVOR_CREDENTIAL"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->MISSING_SURVIVOR_CREDENTIAL:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "temp_token_unavailable"

    .line 26
    .line 27
    const-string v0, "TEMP_TOKEN_UNAVAILABLE"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->TEMP_TOKEN_UNAVAILABLE:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "exchange_failed"

    .line 38
    .line 39
    const-string v0, "EXCHANGE_FAILED"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->EXCHANGE_FAILED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "persistence_failed"

    .line 50
    .line 51
    const-string v0, "PERSISTENCE_FAILED"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->PERSISTENCE_FAILED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "non_session_outcome"

    .line 62
    .line 63
    const-string v0, "NON_SESSION_OUTCOME"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->NON_SESSION_OUTCOME:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "identity_mismatch"

    .line 74
    .line 75
    const-string v0, "IDENTITY_MISMATCH"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->IDENTITY_MISMATCH:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 83
    .line 84
    const/4 v2, 0x7

    .line 85
    const-string v1, "session_changed"

    .line 86
    .line 87
    const-string v0, "SESSION_CHANGED"

    .line 88
    .line 89
    new-instance v10, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 90
    .line 91
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    sput-object v10, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->SESSION_CHANGED:Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 95
    .line 96
    filled-new-array/range {v3 .. v10}, [Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    sput-object v1, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->$VALUES:[Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 101
    .line 102
    new-instance v0, LX/DvM;

    .line 103
    .line 104
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 105
    .line 106
    .line 107
    sput-object v0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->$ENTRIES:LX/0vk;

    .line 108
    .line 109
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->$VALUES:[Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/api/PostConsolidationCredentialRefreshResult;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
