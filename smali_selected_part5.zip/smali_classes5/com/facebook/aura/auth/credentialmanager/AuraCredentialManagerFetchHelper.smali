.class public final Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;

.field public static final PROVIDER_CLASS:Ljava/lang/String; = "com.google.android.gms.auth.api.credentials.credman.service.PasswordAndPasskeyService"

.field public static final PROVIDER_PACKAGE:Ljava/lang/String; = "com.google.android.gms"

.field public static final TAG:Ljava/lang/String; = "AuraCredentialManagerFetch"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$doFetch(Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->doFetch(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final doFetch(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p6, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p6

    .line 5
    check-cast v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v4, :cond_1

    .line 28
    .line 29
    iget-object p2, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$1:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p2, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;

    .line 32
    .line 33
    goto :goto_3

    .line 34
    :cond_0
    new-instance v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;

    .line 35
    .line 36
    invoke-direct {v5, p0, p6}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;-><init>(Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;LX/2M4;)V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    throw v0

    .line 48
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    new-instance v1, Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 54
    .line 55
    .line 56
    const-string v0, "google_token"

    .line 57
    .line 58
    invoke-interface {p3, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_3

    .line 63
    .line 64
    sget-object v2, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

    .line 65
    .line 66
    invoke-virtual {v2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->isGoogleIdTokenEnabled()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_3

    .line 71
    .line 72
    if-eqz p5, :cond_7

    .line 73
    .line 74
    invoke-virtual {v2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->googleIdOption()LX/EGZ;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    :goto_1
    invoke-virtual {v1, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    :cond_3
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_4

    .line 86
    .line 87
    invoke-interface {p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialDataNull()V

    .line 88
    .line 89
    .line 90
    :goto_2
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 91
    .line 92
    return-object v6

    .line 93
    :cond_4
    const/4 v7, 0x0

    .line 94
    const/4 v3, 0x0

    .line 95
    new-instance v2, Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 98
    .line 99
    .line 100
    if-eqz p4, :cond_5

    .line 101
    .line 102
    const-string v1, "com.google.android.gms"

    .line 103
    .line 104
    const-string v0, "com.google.android.gms.auth.api.credentials.credman.service.PasswordAndPasskeyService"

    .line 105
    .line 106
    new-instance v3, Landroid/content/ComponentName;

    .line 107
    .line 108
    invoke-direct {v3, v1, v0}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    :cond_5
    invoke-static {v2}, LX/B89;->A0j(Ljava/lang/Iterable;)Ljava/util/List;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    const/4 v1, 0x0

    .line 116
    new-instance v0, LX/EGj;

    .line 117
    .line 118
    invoke-direct {v0, v3, v2, v1}, LX/EGj;-><init>(Landroid/content/ComponentName;Ljava/util/List;Z)V

    .line 119
    .line 120
    .line 121
    :try_start_0
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 122
    .line 123
    .line 124
    iput-object v7, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$0:Ljava/lang/Object;

    .line 125
    .line 126
    iput-object p2, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$1:Ljava/lang/Object;

    .line 127
    .line 128
    iput-object v7, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$2:Ljava/lang/Object;

    .line 129
    .line 130
    iput-object v7, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$3:Ljava/lang/Object;

    .line 131
    .line 132
    iput-object v7, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->L$4:Ljava/lang/Object;

    .line 133
    .line 134
    iput-boolean p4, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->Z$0:Z

    .line 135
    .line 136
    iput-boolean p5, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->Z$1:Z

    .line 137
    .line 138
    iput v4, v5, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$doFetch$1;->label:I

    .line 139
    .line 140
    invoke-static {p1, v0, v5}, LX/EGc;->A00(Landroid/content/Context;LX/EGj;LX/2M4;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    if-ne v1, v6, :cond_6

    .line 145
    .line 146
    goto :goto_4

    .line 147
    :goto_3
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_6
    check-cast v1, LX/EGW;
    :try_end_0
    .catch Landroidx/credentials/exceptions/GetCredentialException; {:try_start_0 .. :try_end_0} :catch_0

    .line 151
    .line 152
    invoke-direct {p0, v1, p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->handleResponse(LX/EGW;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;)V

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_7
    new-instance v0, LX/EGY;

    .line 157
    .line 158
    invoke-direct {v0}, LX/EGY;-><init>()V

    .line 159
    .line 160
    .line 161
    goto :goto_1

    .line 162
    :goto_4
    return-object v6

    .line 163
    :catch_0
    move-exception v0

    .line 164
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    invoke-direct {p0, v0, p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->handleException(Landroidx/credentials/exceptions/GetCredentialException;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;)V

    .line 168
    .line 169
    .line 170
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 171
    .line 172
    return-object v0
.end method

.method public static synthetic fetchCredential$default(Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const-string v0, "google_token"

    .line 5
    .line 6
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object p3

    .line 10
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    const/4 p4, 0x0

    .line 15
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    const/4 p5, 0x0

    .line 20
    :cond_2
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->fetchCredential(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZ)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method private final handleException(Landroidx/credentials/exceptions/GetCredentialException;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;)V
    .locals 1

    .line 0
    instance-of v0, p1, Landroidx/credentials/exceptions/publickeycredential/GetPublicKeyCredentialException;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v0, p1

    .line 5
    check-cast v0, Landroidx/credentials/exceptions/publickeycredential/GetPublicKeyCredentialException;

    .line 6
    .line 7
    iget-object p0, v0, Landroidx/credentials/exceptions/publickeycredential/GetPublicKeyCredentialException;->type:Ljava/lang/String;

    .line 8
    .line 9
    :goto_0
    const-string v0, "android.credentials.GetCredentialException.TYPE_USER_CANCELED"

    .line 10
    .line 11
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    const-string p0, "user_canceled"

    .line 18
    .line 19
    const-string v0, "User canceled credential selection"

    .line 20
    .line 21
    :goto_1
    invoke-interface {p2, p0, v0}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialFetchException(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    const-string v0, "android.credentials.GetCredentialException.TYPE_NO_CREDENTIAL"

    .line 26
    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    invoke-interface {p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialDataNull()V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    goto :goto_1

    .line 42
    :cond_2
    instance-of v0, p1, Landroidx/credentials/exceptions/GetCredentialCustomException;

    .line 43
    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    move-object v0, p1

    .line 47
    check-cast v0, Landroidx/credentials/exceptions/GetCredentialCustomException;

    .line 48
    .line 49
    iget-object p0, v0, Landroidx/credentials/exceptions/GetCredentialCustomException;->type:Ljava/lang/String;

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_3
    iget-object p0, p1, Landroidx/credentials/exceptions/GetCredentialException;->type:Ljava/lang/String;

    .line 53
    .line 54
    goto :goto_0
.end method

.method private final handleResponse(LX/EGW;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;)V
    .locals 3

    .line 0
    iget-object v2, p1, LX/EGW;->A00:LX/EGr;

    .line 1
    .line 2
    instance-of v0, v2, LX/EGX;

    .line 3
    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    iget-object v1, v2, LX/EGr;->A01:Ljava/lang/String;

    .line 7
    .line 8
    const-string v0, "com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL"

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    :try_start_0
    iget-object v0, v2, LX/EGr;->A00:Landroid/os/Bundle;

    .line 17
    .line 18
    invoke-static {v0}, LX/EGM;->A00(Landroid/os/Bundle;)LX/EGM;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iget-object p0, p1, LX/EGM;->A01:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v2, p1, LX/EGM;->A03:Ljava/lang/String;

    .line 25
    .line 26
    if-nez v2, :cond_0

    .line 27
    .line 28
    const-string v2, ""

    .line 29
    .line 30
    :cond_0
    iget-object v0, p1, LX/EGM;->A00:Landroid/net/Uri;

    .line 31
    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    :goto_0
    iget-object v0, p1, LX/EGM;->A02:Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {p2, p0, v2, v1, v0}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onGoogleIdTokenReceived(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    const/4 v1, 0x0

    .line 45
    goto :goto_0

    .line 46
    :goto_1
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    :catch_0
    move-exception v2

    .line 48
    const-string v1, "Failed to parse Google ID token"

    .line 49
    .line 50
    const-string v0, "AuraCredentialManagerFetch"

    .line 51
    .line 52
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 53
    .line 54
    .line 55
    const-string v1, "google_id_token_parse_error"

    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-interface {p2, v1, v0}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialFetchException(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_2
    invoke-interface {p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialDataNull()V

    .line 66
    .line 67
    .line 68
    return-void
.end method


# virtual methods
.method public final fetchCredential(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZ)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ)V"
        }
    .end annotation

    .line 0
    move-object v2, p1

    .line 1
    move-object v3, p2

    .line 2
    move-object p0, p3

    .line 3
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->isGoogleIdTokenEnabled()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-interface {p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialDataNull()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    instance-of v0, p1, LX/07p;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    move-object v0, v2

    .line 23
    check-cast v0, LX/07p;

    .line 24
    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-static {v0}, LX/AYw;->A00(LX/07p;)LX/9rK;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const/4 p3, 0x0

    .line 32
    new-instance v1, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;

    .line 33
    .line 34
    move p1, p4

    .line 35
    move p2, p5

    .line 36
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;-><init>(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)V

    .line 37
    .line 38
    .line 39
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_1
    const-string v0, "AuraCredentialManagerFetch"

    .line 44
    .line 45
    const-string v1, "Context must be a LifecycleOwner"

    .line 46
    .line 47
    invoke-static {v0, v1}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const-string v0, "invalid_context"

    .line 51
    .line 52
    invoke-interface {p2, v0, v1}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;->onCredentialFetchException(Ljava/lang/String;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return-void
.end method
