.class public final Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final GOOGLE_CLIENT_ID:Ljava/lang/String; = "138594053405-idn5m64stn93ev8t4g8c4k0ljgdte3i0.apps.googleusercontent.com"

.field public static final INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

.field public static final isGoogleIdTokenEnabled$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "isGoogleIdTokenEnabled"

    .line 1
    .line 2
    const-string v1, "isGoogleIdTokenEnabled()Z"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;->meta_ai_siwg_enabled:LX/0d8;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->isGoogleIdTokenEnabled$delegate:LX/1zE;

    .line 26
    .line 27
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final googleIdOption()LX/EGZ;
    .locals 1

    .line 0
    const-string v0, "138594053405-idn5m64stn93ev8t4g8c4k0ljgdte3i0.apps.googleusercontent.com"

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-lez v0, :cond_0

    .line 7
    .line 8
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    new-instance v0, LX/EGZ;

    .line 17
    .line 18
    invoke-direct {v0, p0}, LX/EGZ;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_0
    const-string p0, "serverClientId should not be empty"

    .line 23
    .line 24
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 25
    .line 26
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw v0
.end method

.method public final isGoogleIdTokenEnabled()Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->isGoogleIdTokenEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerConfig;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    invoke-static {p0, v1, v0}, LX/8mk;->A1X(Ljava/lang/Object;LX/1zE;[LX/Dqa;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method
