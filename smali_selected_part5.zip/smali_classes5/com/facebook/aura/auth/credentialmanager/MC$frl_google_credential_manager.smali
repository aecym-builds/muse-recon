.class public final Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x1892c

.field public static final INSTANCE:Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;

.field public static final __CONFIG__:I = 0x1d6

.field public static final meta_ai_siwg_enabled:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;

    .line 6
    .line 7
    const-wide v1, 0x4101d600000084L

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/auth/credentialmanager/MC$frl_google_credential_manager;->meta_ai_siwg_enabled:LX/0d8;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
