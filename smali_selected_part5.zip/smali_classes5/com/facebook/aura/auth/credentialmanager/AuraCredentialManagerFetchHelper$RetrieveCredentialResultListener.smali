.class public interface abstract Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onCredentialDataNull()V
.end method

.method public abstract onCredentialFetchException(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onGoogleIdTokenReceived(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end method
