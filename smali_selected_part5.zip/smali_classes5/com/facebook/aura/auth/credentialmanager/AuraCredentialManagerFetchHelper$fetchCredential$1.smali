.class public final Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.credentialmanager.AuraCredentialManagerFetchHelper$fetchCredential$1"
    f = "AuraCredentialManagerFetchHelper.kt"
    l = {
        0x2d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $credentialsToDisplay:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $displayBrandingUI:Z

.field public final synthetic $listener:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;

.field public final synthetic $useBottomSheetForGoogle:Z

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$listener:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$credentialsToDisplay:Ljava/util/List;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$displayBrandingUI:Z

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$useBottomSheetForGoogle:Z

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$listener:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$credentialsToDisplay:Ljava/util/List;

    .line 5
    .line 6
    iget-boolean v4, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$displayBrandingUI:Z

    .line 7
    .line 8
    iget-boolean p0, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$useBottomSheetForGoogle:Z

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;-><init>(Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->label:I

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    if-eqz v1, :cond_1

    .line 6
    .line 7
    if-ne v1, v0, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v2

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    sget-object v3, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->INSTANCE:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;

    .line 19
    .line 20
    iget-object v4, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$context:Landroid/content/Context;

    .line 21
    .line 22
    iget-object v5, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$listener:Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;

    .line 23
    .line 24
    iget-object v6, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$credentialsToDisplay:Ljava/util/List;

    .line 25
    .line 26
    iget-boolean v7, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$displayBrandingUI:Z

    .line 27
    .line 28
    iget-boolean v8, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->$useBottomSheetForGoogle:Z

    .line 29
    .line 30
    iput v0, p0, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$fetchCredential$1;->label:I

    .line 31
    .line 32
    invoke-static/range {v3 .. v9}, Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;->access$doFetch(Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper;Landroid/content/Context;Lcom/facebook/aura/auth/credentialmanager/AuraCredentialManagerFetchHelper$RetrieveCredentialResultListener;Ljava/util/List;ZZLX/2M4;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-ne v0, v2, :cond_0

    .line 37
    .line 38
    return-object v2

    .line 39
    :cond_2
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v0
.end method
