.class public final Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson$Companion;


# instance fields
.field public final checkpoint_id:Ljava/lang/String;

.field public final checkpoint_required:Z

.field public final checkpoint_url:Ljava/lang/String;

.field public final next_check_after_s:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->Companion:Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(IZLjava/lang/String;Ljava/lang/String;ILX/5Xm;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p1, 0x1

    .line 536870913
    .line 536870914
    const/4 v1, 0x1

    .line 536870915
    if-eq v1, v0, :cond_0

    .line 536870916
    .line 536870917
    sget-object v0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 536870918
    .line 536870919
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 536870920
    .line 536870921
    .line 536870922
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 536870923
    .line 536870924
    .line 536870925
    move-result-object v0

    .line 536870926
    throw v0

    .line 536870927
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870928
    .line 536870929
    .line 536870930
    iput-boolean p2, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 536870931
    .line 536870932
    and-int/lit8 v0, p1, 0x2

    .line 536870933
    .line 536870934
    const/4 v1, 0x0

    .line 536870935
    if-nez v0, :cond_2

    .line 536870936
    .line 536870937
    iput-object v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 536870938
    .line 536870939
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 536870940
    .line 536870941
    if-nez v0, :cond_1

    .line 536870942
    .line 536870943
    iput-object v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 536870944
    .line 536870945
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 536870946
    .line 536870947
    if-nez v0, :cond_3

    .line 536870948
    .line 536870949
    const/16 v0, 0x12c

    .line 536870950
    .line 536870951
    iput v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 536870952
    .line 536870953
    return-void

    .line 536870954
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 536870955
    .line 536870956
    goto :goto_1

    .line 536870957
    :cond_2
    iput-object p3, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 536870958
    .line 536870959
    goto :goto_0

    .line 536870960
    :cond_3
    iput p5, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 536870961
    .line 536870962
    return-void
.end method

.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 8
    .line 9
    iput p4, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/String;Ljava/lang/String;IILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p5, 0x2

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p2, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p3, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p5, 0x8

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    const/16 p4, 0x12c

    .line 268435472
    .line 268435473
    :cond_2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;I)V

    .line 268435474
    .line 268435475
    .line 268435476
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;ZLjava/lang/String;Ljava/lang/String;IILjava/lang/Object;)Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 23
    .line 24
    :cond_3
    new-instance v0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;

    .line 25
    .line 26
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_auth_checkpoint_probe_probe(Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-boolean v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 2
    .line 3
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-nez v3, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    const/4 v2, 0x2

    .line 25
    if-nez v3, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz v0, :cond_3

    .line 30
    .line 31
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    const/4 v2, 0x3

    .line 39
    if-nez v3, :cond_4

    .line 40
    .line 41
    iget v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 42
    .line 43
    const/16 v0, 0x12c

    .line 44
    .line 45
    if-eq v1, v0, :cond_5

    .line 46
    .line 47
    :cond_4
    iget v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 48
    .line 49
    invoke-interface {p1, p2, v2, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 50
    .line 51
    .line 52
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(ZLjava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;I)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 37
    .line 38
    iget v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 39
    .line 40
    if-eq v1, v0, :cond_1

    .line 41
    .line 42
    :cond_0
    return v2

    .line 43
    :cond_1
    return v3
.end method

.method public final getCheckpoint_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCheckpoint_required()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getCheckpoint_url()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getNext_check_after_s()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 1
    .line 2
    const/16 v0, 0x4d5

    .line 3
    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    const/16 v0, 0x4cf

    .line 7
    .line 8
    :cond_0
    mul-int/lit8 v1, v0, 0x1f

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    add-int/2addr v1, v0

    .line 18
    mul-int/lit8 v1, v1, 0x1f

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 21
    .line 22
    if-eqz v0, :cond_1

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    :cond_1
    add-int/2addr v1, v2

    .line 29
    mul-int/lit8 v1, v1, 0x1f

    .line 30
    .line 31
    iget v0, p0, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 32
    .line 33
    add-int/2addr v1, v0

    .line 34
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
