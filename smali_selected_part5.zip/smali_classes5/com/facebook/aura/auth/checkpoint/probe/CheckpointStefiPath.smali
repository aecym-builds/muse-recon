.class public interface abstract Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStefiPath;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/api/StefiHatchPath$Extension;
