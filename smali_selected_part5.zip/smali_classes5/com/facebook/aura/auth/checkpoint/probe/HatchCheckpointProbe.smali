.class public final Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;->INSTANCE:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final probe(LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v13, p1

    .line 5
    check-cast v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;

    .line 6
    .line 7
    iget v2, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_4

    .line 26
    .line 27
    if-ne v1, v0, :cond_7

    .line 28
    .line 29
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    check-cast v3, LX/2PJ;

    .line 33
    .line 34
    iget-object v5, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 35
    .line 36
    :cond_0
    invoke-static {v5}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-nez v0, :cond_6

    .line 41
    .line 42
    check-cast v5, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;

    .line 43
    .line 44
    iget-boolean v0, v5, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_required:Z

    .line 45
    .line 46
    if-eqz v0, :cond_3

    .line 47
    .line 48
    sget-object v4, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;->REQUIRED:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;

    .line 49
    .line 50
    :goto_1
    iget-object v3, v5, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_url:Ljava/lang/String;

    .line 51
    .line 52
    const/4 v2, 0x0

    .line 53
    if-eqz v3, :cond_2

    .line 54
    .line 55
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    :goto_2
    iget-object v1, v5, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->checkpoint_id:Ljava/lang/String;

    .line 62
    .line 63
    if-eqz v1, :cond_1

    .line 64
    .line 65
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_1

    .line 70
    .line 71
    move-object v2, v1

    .line 72
    :cond_1
    iget v0, v5, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStatusResponseJson;->next_check_after_s:I

    .line 73
    .line 74
    new-instance v1, Ljava/lang/Integer;

    .line 75
    .line 76
    invoke-direct {v1, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 77
    .line 78
    .line 79
    new-instance v0, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeResult;

    .line 80
    .line 81
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeResult;-><init>(Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 82
    .line 83
    .line 84
    return-object v0

    .line 85
    :cond_2
    move-object v3, v2

    .line 86
    goto :goto_2

    .line 87
    :cond_3
    sget-object v4, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;->CLEAR:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;

    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_4
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 94
    .line 95
    sget-object v6, Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStefiPath$CheckpointStatus;->INSTANCE:Lcom/facebook/aura/auth/checkpoint/probe/CheckpointStefiPath$CheckpointStatus;

    .line 96
    .line 97
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 98
    .line 99
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 100
    .line 101
    .line 102
    move-result-object v10

    .line 103
    sget-object v4, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 104
    .line 105
    const/4 v5, 0x0

    .line 106
    const/4 v8, 0x0

    .line 107
    iput-object v8, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->L$0:Ljava/lang/Object;

    .line 108
    .line 109
    iput-object v8, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->L$1:Ljava/lang/Object;

    .line 110
    .line 111
    iput-object v8, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->L$2:Ljava/lang/Object;

    .line 112
    .line 113
    iput-object v8, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->L$3:Ljava/lang/Object;

    .line 114
    .line 115
    iput-object v8, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->L$4:Ljava/lang/Object;

    .line 116
    .line 117
    iput v0, v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;->label:I

    .line 118
    .line 119
    move-object v9, v8

    .line 120
    move-object v11, v10

    .line 121
    move-object v12, v8

    .line 122
    invoke-virtual/range {v3 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    if-ne v5, v2, :cond_0

    .line 127
    .line 128
    return-object v2

    .line 129
    :cond_5
    new-instance v13, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;

    .line 130
    .line 131
    invoke-direct {v13, p0, p1}, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe$probe$1;-><init>(Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbe;LX/2M4;)V

    .line 132
    .line 133
    .line 134
    goto :goto_0

    .line 135
    :cond_6
    sget-object v1, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;->UNAVAILABLE:Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;

    .line 136
    .line 137
    const/4 v0, 0x0

    .line 138
    new-instance v2, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeResult;

    .line 139
    .line 140
    invoke-direct {v2, v1, v0, v0, v0}, Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeResult;-><init>(Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointProbeStatus;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 141
    .line 142
    .line 143
    return-object v2

    .line 144
    :cond_7
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 145
    .line 146
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 147
    .line 148
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    throw v0
.end method
