.class public interface abstract Lcom/facebook/aura/auth/login/challenge/intf/NativeLoginChallengeController;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract finish()V
.end method

.method public abstract start(Ljava/lang/String;)V
.end method
