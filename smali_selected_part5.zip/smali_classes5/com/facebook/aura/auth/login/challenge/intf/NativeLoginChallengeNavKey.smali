.class public interface abstract Lcom/facebook/aura/auth/login/challenge/intf/NativeLoginChallengeNavKey;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/navigation/AuraLoggedOutNavKey;
