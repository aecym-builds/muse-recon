.class public final Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError;


# instance fields
.field public final httpCode:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 4
    .line 5
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;IILjava/lang/Object;)Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 5
    .line 6
    :cond_0
    new-instance v0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(I)Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;

    .line 1
    .line 2
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;-><init>(I)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return v2

    .line 17
    :cond_1
    return v3
.end method

.method public final getHttpCode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/login/hatchauth/HatchAuthError$Failed;->httpCode:I

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
