.class public final enum Lcom/facebook/aura/auth/login/api/LoginMethod;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/login/api/LoginMethod;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum ONE_TAP:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum OTHER:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum OTP:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum PASSKEY:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum PASSWORD:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum SSO:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum STORED_CREDENTIAL:Lcom/facebook/aura/auth/login/api/LoginMethod;

.field public static final enum TWO_FACTOR:Lcom/facebook/aura/auth/login/api/LoginMethod;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const-string v1, "PASSKEY"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v2, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 4
    .line 5
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v2, Lcom/facebook/aura/auth/login/api/LoginMethod;->PASSKEY:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 9
    .line 10
    const-string v1, "PASSWORD"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/auth/login/api/LoginMethod;->PASSWORD:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 19
    .line 20
    const-string v1, "OTP"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v4, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 24
    .line 25
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v4, Lcom/facebook/aura/auth/login/api/LoginMethod;->OTP:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 29
    .line 30
    const-string v1, "SSO"

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    new-instance v5, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 34
    .line 35
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v5, Lcom/facebook/aura/auth/login/api/LoginMethod;->SSO:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 39
    .line 40
    const-string v1, "TWO_FACTOR"

    .line 41
    .line 42
    const/4 v0, 0x4

    .line 43
    new-instance v6, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 44
    .line 45
    invoke-direct {v6, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    sput-object v6, Lcom/facebook/aura/auth/login/api/LoginMethod;->TWO_FACTOR:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 49
    .line 50
    const-string v1, "ONE_TAP"

    .line 51
    .line 52
    const/4 v0, 0x5

    .line 53
    new-instance v7, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 54
    .line 55
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/auth/login/api/LoginMethod;->ONE_TAP:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 59
    .line 60
    const-string v1, "STORED_CREDENTIAL"

    .line 61
    .line 62
    const/4 v0, 0x6

    .line 63
    new-instance v8, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 64
    .line 65
    invoke-direct {v8, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v8, Lcom/facebook/aura/auth/login/api/LoginMethod;->STORED_CREDENTIAL:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 69
    .line 70
    const-string v1, "OTHER"

    .line 71
    .line 72
    const/4 v0, 0x7

    .line 73
    new-instance v9, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 74
    .line 75
    invoke-direct {v9, v1, v0}, Lcom/facebook/aura/auth/login/api/LoginMethod;-><init>(Ljava/lang/String;I)V

    .line 76
    .line 77
    .line 78
    sput-object v9, Lcom/facebook/aura/auth/login/api/LoginMethod;->OTHER:Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 79
    .line 80
    filled-new-array/range {v2 .. v9}, [Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    sput-object v1, Lcom/facebook/aura/auth/login/api/LoginMethod;->$VALUES:[Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 85
    .line 86
    new-instance v0, LX/DvM;

    .line 87
    .line 88
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 89
    .line 90
    .line 91
    sput-object v0, Lcom/facebook/aura/auth/login/api/LoginMethod;->$ENTRIES:LX/0vk;

    .line 92
    .line 93
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/login/api/LoginMethod;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/api/LoginMethod;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/login/api/LoginMethod;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/login/api/LoginMethod;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/api/LoginMethod;->$VALUES:[Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/login/api/LoginMethod;

    .line 7
    .line 8
    return-object v0
.end method
