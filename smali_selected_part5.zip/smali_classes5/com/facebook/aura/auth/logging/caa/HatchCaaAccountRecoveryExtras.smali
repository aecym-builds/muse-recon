.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;
.super LX/07H;
.source ""


# instance fields
.field public final contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

.field public final isChecked:Ljava/lang/Boolean;

.field public final pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

.field public final profilePositionAbsolute:Ljava/lang/Integer;

.field public final sourceApp:Ljava/lang/String;

.field public final totalCount:Ljava/lang/Integer;

.field public final totalProfileCount:Ljava/lang/Integer;


# direct methods
.method public constructor <init>()V
    .locals 7

    .line 536870912
    const/4 v1, 0x0

    .line 536870913
    move-object v0, p0

    .line 536870914
    move-object v2, v1

    .line 536870915
    move-object v3, v1

    .line 536870916
    move-object v4, v1

    .line 536870917
    move-object v5, v1

    .line 536870918
    move-object v6, v1

    .line 536870919
    move-object p0, v1

    .line 536870920
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;-><init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 536870921
    .line 536870922
    .line 536870923
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 268435462
    .line 268435463
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 268435464
    .line 268435465
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 268435466
    .line 268435467
    iput-object p5, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 268435468
    .line 268435469
    iput-object p6, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 268435470
    .line 268435471
    iput-object p7, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 268435472
    .line 268435473
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p8, 0x1

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p1, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p2, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p3, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p4, v1

    .line 21
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 22
    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    move-object p5, v1

    .line 26
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 27
    .line 28
    if-eqz v0, :cond_5

    .line 29
    .line 30
    move-object p6, v1

    .line 31
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 32
    .line 33
    if-eqz v0, :cond_6

    .line 34
    .line 35
    move-object p7, v1

    .line 36
    :cond_6
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;-><init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;
    .locals 8

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-object v4, p4

    .line 4
    move-object v5, p5

    .line 5
    move-object v6, p6

    .line 6
    move-object v7, p7

    .line 7
    and-int/lit8 v0, p8, 0x1

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 12
    .line 13
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 18
    .line 19
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 20
    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 24
    .line 25
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 26
    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    iget-object v4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 30
    .line 31
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 32
    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    iget-object v5, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 36
    .line 37
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 38
    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    iget-object v6, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 42
    .line 43
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 44
    .line 45
    if-eqz v0, :cond_6

    .line 46
    .line 47
    iget-object v7, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 48
    .line 49
    :cond_6
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;

    .line 50
    .line 51
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;-><init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;-><init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 23
    .line 24
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 33
    .line 34
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 43
    .line 44
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 53
    .line 54
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 55
    .line 56
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_0

    .line 61
    .line 62
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 63
    .line 64
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_1

    .line 71
    .line 72
    :cond_0
    return v2

    .line 73
    :cond_1
    return v3
.end method

.method public final getContactPointType()Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPickedMedium()Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getProfilePositionAbsolute()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSourceApp()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTotalCount()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTotalProfileCount()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v1, v0

    .line 43
    mul-int/lit8 v1, v1, 0x1f

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 46
    .line 47
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    add-int/2addr v1, v0

    .line 52
    mul-int/lit8 v1, v1, 0x1f

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 55
    .line 56
    if-eqz v0, :cond_0

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    :cond_0
    add-int/2addr v1, v2

    .line 63
    return v1
.end method

.method public final isChecked()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
