.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum ACCOUNT_RECOVERY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum ACCOUNT_SELECTOR_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CHANGE_PASSWORD_TWO_FACTOR_REDIRECT_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_CODE_SUBMITTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_CODE_SUBMIT_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_CODE_SUBMIT_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_RESEND_CODE_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_RESEND_CODE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_RESEND_CODE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_VIEWED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_VIEWED_EMAIL_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum CODE_ENTRY_VIEWED_SMS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEWED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEW_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEW_CODE_SEND_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEW_CODE_SEND_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEW_SENT_CODE_EMAIL_TRIGGERED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum INITIATE_VIEW_SENT_CODE_SMS_TRIGGERED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum LOGIN_REDIRECT_LOGIN_CHALLENGES:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum LOG_OUT_OPTION_SELECTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum LRR_HANDOFF_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum LRR_START_FALLBACK_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum NO_LONGER_HAVE_ACCESS_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_CHANGE_PASSWORD_SUBMITTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_ON_FOA_DIALOG_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_RECOVERY_FAILURE_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_RECOVERY_SUCCESS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum PASSWORD_RESET_VIEWED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum SEARCH_FAILURE_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum SEARCH_SUCCESS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum SEARCH_XAPP_DIALOG_REDIRECTION_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum SELECT_ACCOUNT_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

.field public static final enum STAY_LOGGED_IN_ON_OTHER_DEVICES_CHECKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 65

    .line 0
    const/4 v3, 0x0

    .line 1
    const-string v2, "account_recovery_start"

    .line 2
    .line 3
    const-string v1, "ACCOUNT_RECOVERY_START"

    .line 4
    .line 5
    new-instance v38, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 6
    .line 7
    move-object/from16 v0, v38

    .line 8
    .line 9
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v38, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->ACCOUNT_RECOVERY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    const-string v2, "search_success_client"

    .line 16
    .line 17
    const-string v1, "SEARCH_SUCCESS_CLIENT"

    .line 18
    .line 19
    new-instance v37, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 20
    .line 21
    move-object/from16 v0, v37

    .line 22
    .line 23
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v37, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->SEARCH_SUCCESS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 27
    .line 28
    const/4 v3, 0x2

    .line 29
    const-string v2, "search_failure_client"

    .line 30
    .line 31
    const-string v1, "SEARCH_FAILURE_CLIENT"

    .line 32
    .line 33
    new-instance v36, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 34
    .line 35
    move-object/from16 v0, v36

    .line 36
    .line 37
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sput-object v36, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->SEARCH_FAILURE_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 41
    .line 42
    const/4 v3, 0x3

    .line 43
    const-string v2, "initiate_viewed_client"

    .line 44
    .line 45
    const-string v1, "INITIATE_VIEWED_CLIENT"

    .line 46
    .line 47
    new-instance v35, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 48
    .line 49
    move-object/from16 v0, v35

    .line 50
    .line 51
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v35, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEWED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 55
    .line 56
    const/4 v3, 0x4

    .line 57
    const-string v2, "initiate_view_sent_code_email_triggered_client"

    .line 58
    .line 59
    const-string v1, "INITIATE_VIEW_SENT_CODE_EMAIL_TRIGGERED_CLIENT"

    .line 60
    .line 61
    new-instance v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 62
    .line 63
    move-object/from16 v0, v34

    .line 64
    .line 65
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    sput-object v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEW_SENT_CODE_EMAIL_TRIGGERED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 69
    .line 70
    const/4 v3, 0x5

    .line 71
    const-string v2, "initiate_view_sent_code_sms_triggered_client"

    .line 72
    .line 73
    const-string v1, "INITIATE_VIEW_SENT_CODE_SMS_TRIGGERED_CLIENT"

    .line 74
    .line 75
    new-instance v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 76
    .line 77
    move-object/from16 v0, v33

    .line 78
    .line 79
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEW_SENT_CODE_SMS_TRIGGERED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 83
    .line 84
    const/4 v3, 0x6

    .line 85
    const-string v2, "initiate_view_code_send_success"

    .line 86
    .line 87
    const-string v1, "INITIATE_VIEW_CODE_SEND_SUCCESS"

    .line 88
    .line 89
    new-instance v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 90
    .line 91
    move-object/from16 v0, v32

    .line 92
    .line 93
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sput-object v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEW_CODE_SEND_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 97
    .line 98
    const/4 v3, 0x7

    .line 99
    const-string v2, "initiate_view_code_send_failure"

    .line 100
    .line 101
    const-string v1, "INITIATE_VIEW_CODE_SEND_FAILURE"

    .line 102
    .line 103
    new-instance v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 104
    .line 105
    move-object/from16 v0, v31

    .line 106
    .line 107
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 108
    .line 109
    .line 110
    sput-object v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEW_CODE_SEND_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 111
    .line 112
    const/16 v3, 0x8

    .line 113
    .line 114
    const-string v2, "initiate_view_back_button_clicked_client"

    .line 115
    .line 116
    const-string v1, "INITIATE_VIEW_BACK_BUTTON_CLICKED_CLIENT"

    .line 117
    .line 118
    new-instance v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 119
    .line 120
    move-object/from16 v0, v30

    .line 121
    .line 122
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sput-object v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->INITIATE_VIEW_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 126
    .line 127
    const/16 v3, 0x9

    .line 128
    .line 129
    const-string v2, "code_entry_viewed"

    .line 130
    .line 131
    const-string v1, "CODE_ENTRY_VIEWED"

    .line 132
    .line 133
    new-instance v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 134
    .line 135
    move-object/from16 v0, v29

    .line 136
    .line 137
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sput-object v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_VIEWED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 141
    .line 142
    const/16 v3, 0xa

    .line 143
    .line 144
    const-string v2, "code_entry_viewed_email_client"

    .line 145
    .line 146
    const-string v1, "CODE_ENTRY_VIEWED_EMAIL_CLIENT"

    .line 147
    .line 148
    new-instance v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 149
    .line 150
    move-object/from16 v0, v28

    .line 151
    .line 152
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 153
    .line 154
    .line 155
    sput-object v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_VIEWED_EMAIL_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 156
    .line 157
    const/16 v3, 0xb

    .line 158
    .line 159
    const-string v2, "code_entry_viewed_sms_client"

    .line 160
    .line 161
    const-string v1, "CODE_ENTRY_VIEWED_SMS_CLIENT"

    .line 162
    .line 163
    new-instance v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 164
    .line 165
    move-object/from16 v0, v27

    .line 166
    .line 167
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 168
    .line 169
    .line 170
    sput-object v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_VIEWED_SMS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 171
    .line 172
    const/16 v3, 0xc

    .line 173
    .line 174
    const-string v2, "code_entry_resend_code_clicked_client"

    .line 175
    .line 176
    const-string v1, "CODE_ENTRY_RESEND_CODE_CLICKED_CLIENT"

    .line 177
    .line 178
    new-instance v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 179
    .line 180
    move-object/from16 v0, v26

    .line 181
    .line 182
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 183
    .line 184
    .line 185
    sput-object v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_RESEND_CODE_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 186
    .line 187
    const/16 v3, 0xd

    .line 188
    .line 189
    const-string v2, "code_entry_resend_code_success"

    .line 190
    .line 191
    const-string v1, "CODE_ENTRY_RESEND_CODE_SUCCESS"

    .line 192
    .line 193
    new-instance v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 194
    .line 195
    move-object/from16 v0, v25

    .line 196
    .line 197
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 198
    .line 199
    .line 200
    sput-object v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_RESEND_CODE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 201
    .line 202
    const/16 v3, 0xe

    .line 203
    .line 204
    const-string v2, "code_entry_resend_code_failure"

    .line 205
    .line 206
    const-string v1, "CODE_ENTRY_RESEND_CODE_FAILURE"

    .line 207
    .line 208
    new-instance v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 209
    .line 210
    move-object/from16 v0, v24

    .line 211
    .line 212
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 213
    .line 214
    .line 215
    sput-object v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_RESEND_CODE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 216
    .line 217
    const/16 v3, 0xf

    .line 218
    .line 219
    const-string v2, "code_entry_code_submitted_client"

    .line 220
    .line 221
    const-string v1, "CODE_ENTRY_CODE_SUBMITTED_CLIENT"

    .line 222
    .line 223
    new-instance v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 224
    .line 225
    move-object/from16 v0, v23

    .line 226
    .line 227
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 228
    .line 229
    .line 230
    sput-object v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_CODE_SUBMITTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 231
    .line 232
    const/16 v3, 0x10

    .line 233
    .line 234
    const-string v2, "code_entry_code_submit_success"

    .line 235
    .line 236
    const-string v1, "CODE_ENTRY_CODE_SUBMIT_SUCCESS"

    .line 237
    .line 238
    new-instance v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 239
    .line 240
    move-object/from16 v0, v22

    .line 241
    .line 242
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 243
    .line 244
    .line 245
    sput-object v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_CODE_SUBMIT_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 246
    .line 247
    const/16 v3, 0x11

    .line 248
    .line 249
    const-string v2, "code_entry_code_submit_failure"

    .line 250
    .line 251
    const-string v1, "CODE_ENTRY_CODE_SUBMIT_FAILURE"

    .line 252
    .line 253
    new-instance v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 254
    .line 255
    move-object/from16 v0, v21

    .line 256
    .line 257
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 258
    .line 259
    .line 260
    sput-object v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_CODE_SUBMIT_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 261
    .line 262
    const/16 v3, 0x12

    .line 263
    .line 264
    const-string v2, "code_entry_back_button_clicked_client"

    .line 265
    .line 266
    const-string v1, "CODE_ENTRY_BACK_BUTTON_CLICKED_CLIENT"

    .line 267
    .line 268
    new-instance v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 269
    .line 270
    move-object/from16 v0, v20

    .line 271
    .line 272
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 273
    .line 274
    .line 275
    sput-object v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CODE_ENTRY_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 276
    .line 277
    const/16 v3, 0x13

    .line 278
    .line 279
    const-string v2, "account_selector_page_shown"

    .line 280
    .line 281
    const-string v1, "ACCOUNT_SELECTOR_PAGE_SHOWN"

    .line 282
    .line 283
    new-instance v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 284
    .line 285
    move-object/from16 v0, v19

    .line 286
    .line 287
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 288
    .line 289
    .line 290
    sput-object v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->ACCOUNT_SELECTOR_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 291
    .line 292
    const/16 v3, 0x14

    .line 293
    .line 294
    const-string v2, "account_selected"

    .line 295
    .line 296
    const-string v1, "ACCOUNT_SELECTED"

    .line 297
    .line 298
    new-instance v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 299
    .line 300
    move-object/from16 v0, v18

    .line 301
    .line 302
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 303
    .line 304
    .line 305
    sput-object v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 306
    .line 307
    const/16 v3, 0x15

    .line 308
    .line 309
    const-string v2, "select_account_back_button_clicked_client"

    .line 310
    .line 311
    const-string v1, "SELECT_ACCOUNT_BACK_BUTTON_CLICKED_CLIENT"

    .line 312
    .line 313
    new-instance v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 314
    .line 315
    move-object/from16 v0, v17

    .line 316
    .line 317
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 318
    .line 319
    .line 320
    sput-object v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->SELECT_ACCOUNT_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 321
    .line 322
    const/16 v3, 0x16

    .line 323
    .line 324
    const-string v2, "password_reset_viewed_client"

    .line 325
    .line 326
    const-string v1, "PASSWORD_RESET_VIEWED_CLIENT"

    .line 327
    .line 328
    new-instance v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 329
    .line 330
    move-object/from16 v0, v16

    .line 331
    .line 332
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 333
    .line 334
    .line 335
    sput-object v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_VIEWED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 336
    .line 337
    const/16 v2, 0x17

    .line 338
    .line 339
    const-string v1, "log_out_option_selected_client"

    .line 340
    .line 341
    const-string v0, "LOG_OUT_OPTION_SELECTED_CLIENT"

    .line 342
    .line 343
    new-instance v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 344
    .line 345
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 346
    .line 347
    .line 348
    sput-object v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->LOG_OUT_OPTION_SELECTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 349
    .line 350
    const/16 v2, 0x18

    .line 351
    .line 352
    const-string v1, "stay_logged_in_on_other_devices_checked"

    .line 353
    .line 354
    const-string v0, "STAY_LOGGED_IN_ON_OTHER_DEVICES_CHECKED"

    .line 355
    .line 356
    new-instance v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 357
    .line 358
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 359
    .line 360
    .line 361
    sput-object v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->STAY_LOGGED_IN_ON_OTHER_DEVICES_CHECKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 362
    .line 363
    const/16 v2, 0x19

    .line 364
    .line 365
    const-string v1, "password_reset_change_password_submitted_client"

    .line 366
    .line 367
    const-string v0, "PASSWORD_RESET_CHANGE_PASSWORD_SUBMITTED_CLIENT"

    .line 368
    .line 369
    new-instance v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 370
    .line 371
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 372
    .line 373
    .line 374
    sput-object v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_CHANGE_PASSWORD_SUBMITTED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 375
    .line 376
    const/16 v2, 0x1a

    .line 377
    .line 378
    const-string v1, "password_reset_recovery_success_client"

    .line 379
    .line 380
    const-string v0, "PASSWORD_RESET_RECOVERY_SUCCESS_CLIENT"

    .line 381
    .line 382
    new-instance v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 383
    .line 384
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 385
    .line 386
    .line 387
    sput-object v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_RECOVERY_SUCCESS_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 388
    .line 389
    const/16 v2, 0x1b

    .line 390
    .line 391
    const-string v1, "change_password_two_factor_redirect_client"

    .line 392
    .line 393
    const-string v0, "CHANGE_PASSWORD_TWO_FACTOR_REDIRECT_CLIENT"

    .line 394
    .line 395
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 396
    .line 397
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 398
    .line 399
    .line 400
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->CHANGE_PASSWORD_TWO_FACTOR_REDIRECT_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 401
    .line 402
    const/16 v2, 0x1c

    .line 403
    .line 404
    const-string v1, "login_redirect_login_challenges"

    .line 405
    .line 406
    const-string v0, "LOGIN_REDIRECT_LOGIN_CHALLENGES"

    .line 407
    .line 408
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 409
    .line 410
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 411
    .line 412
    .line 413
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->LOGIN_REDIRECT_LOGIN_CHALLENGES:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 414
    .line 415
    const/16 v2, 0x1d

    .line 416
    .line 417
    const-string v1, "password_reset_recovery_failure_client"

    .line 418
    .line 419
    const-string v0, "PASSWORD_RESET_RECOVERY_FAILURE_CLIENT"

    .line 420
    .line 421
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 422
    .line 423
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 424
    .line 425
    .line 426
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_RECOVERY_FAILURE_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 427
    .line 428
    const/16 v2, 0x1e

    .line 429
    .line 430
    const-string v1, "password_reset_back_button_clicked_client"

    .line 431
    .line 432
    const-string v0, "PASSWORD_RESET_BACK_BUTTON_CLICKED_CLIENT"

    .line 433
    .line 434
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 435
    .line 436
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 437
    .line 438
    .line 439
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_BACK_BUTTON_CLICKED_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 440
    .line 441
    const/16 v2, 0x1f

    .line 442
    .line 443
    const-string v1, "no_longer_have_access_clicked"

    .line 444
    .line 445
    const-string v0, "NO_LONGER_HAVE_ACCESS_CLICKED"

    .line 446
    .line 447
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 448
    .line 449
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 450
    .line 451
    .line 452
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->NO_LONGER_HAVE_ACCESS_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 453
    .line 454
    const/16 v2, 0x20

    .line 455
    .line 456
    const-string v1, "lrr_handoff_client"

    .line 457
    .line 458
    const-string v0, "LRR_HANDOFF_CLIENT"

    .line 459
    .line 460
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 461
    .line 462
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 463
    .line 464
    .line 465
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->LRR_HANDOFF_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 466
    .line 467
    const/16 v2, 0x21

    .line 468
    .line 469
    const-string v1, "lrr_start_fallback_client"

    .line 470
    .line 471
    const-string v0, "LRR_START_FALLBACK_CLIENT"

    .line 472
    .line 473
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 474
    .line 475
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 476
    .line 477
    .line 478
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->LRR_START_FALLBACK_CLIENT:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 479
    .line 480
    const/16 v0, 0x22

    .line 481
    .line 482
    const-string v2, "search_xapp_dialog_redirection_clicked"

    .line 483
    .line 484
    const-string v1, "SEARCH_XAPP_DIALOG_REDIRECTION_CLICKED"

    .line 485
    .line 486
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 487
    .line 488
    invoke-direct {v3, v1, v0, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 489
    .line 490
    .line 491
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->SEARCH_XAPP_DIALOG_REDIRECTION_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 492
    .line 493
    const/16 v2, 0x23

    .line 494
    .line 495
    const-string v1, "password_reset_on_foa_dialog_shown"

    .line 496
    .line 497
    const-string v0, "PASSWORD_RESET_ON_FOA_DIALOG_SHOWN"

    .line 498
    .line 499
    new-instance v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 500
    .line 501
    invoke-direct {v15, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 502
    .line 503
    .line 504
    sput-object v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->PASSWORD_RESET_ON_FOA_DIALOG_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 505
    .line 506
    const/16 v0, 0x24

    .line 507
    .line 508
    new-array v1, v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 509
    .line 510
    move-object/from16 v51, v25

    .line 511
    .line 512
    move-object/from16 v52, v24

    .line 513
    .line 514
    move-object/from16 v53, v23

    .line 515
    .line 516
    move-object/from16 v54, v22

    .line 517
    .line 518
    move-object/from16 v55, v21

    .line 519
    .line 520
    move-object/from16 v56, v20

    .line 521
    .line 522
    move-object/from16 v57, v19

    .line 523
    .line 524
    move-object/from16 v58, v18

    .line 525
    .line 526
    move-object/from16 v59, v17

    .line 527
    .line 528
    move-object/from16 v60, v16

    .line 529
    .line 530
    move-object/from16 v61, v14

    .line 531
    .line 532
    move-object/from16 v62, v13

    .line 533
    .line 534
    move-object/from16 v63, v12

    .line 535
    .line 536
    move-object/from16 v64, v11

    .line 537
    .line 538
    move-object/from16 v39, v37

    .line 539
    .line 540
    move-object/from16 v40, v36

    .line 541
    .line 542
    move-object/from16 v41, v35

    .line 543
    .line 544
    move-object/from16 v42, v34

    .line 545
    .line 546
    move-object/from16 v43, v33

    .line 547
    .line 548
    move-object/from16 v44, v32

    .line 549
    .line 550
    move-object/from16 v45, v31

    .line 551
    .line 552
    move-object/from16 v46, v30

    .line 553
    .line 554
    move-object/from16 v47, v29

    .line 555
    .line 556
    move-object/from16 v48, v28

    .line 557
    .line 558
    move-object/from16 v49, v27

    .line 559
    .line 560
    move-object/from16 v50, v26

    .line 561
    .line 562
    filled-new-array/range {v38 .. v64}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 563
    .line 564
    .line 565
    move-result-object v2

    .line 566
    const/4 v11, 0x0

    .line 567
    const/16 v0, 0x1b

    .line 568
    .line 569
    invoke-static {v2, v11, v1, v11, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 570
    .line 571
    .line 572
    move-object/from16 v16, v10

    .line 573
    .line 574
    move-object/from16 v17, v9

    .line 575
    .line 576
    move-object/from16 v18, v8

    .line 577
    .line 578
    move-object/from16 v19, v7

    .line 579
    .line 580
    move-object/from16 v20, v6

    .line 581
    .line 582
    move-object/from16 v21, v5

    .line 583
    .line 584
    move-object/from16 v22, v4

    .line 585
    .line 586
    move-object/from16 v23, v3

    .line 587
    .line 588
    move-object/from16 v24, v15

    .line 589
    .line 590
    filled-new-array/range {v16 .. v24}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 591
    .line 592
    .line 593
    move-result-object v3

    .line 594
    const/16 v2, 0x1b

    .line 595
    .line 596
    const/16 v0, 0x9

    .line 597
    .line 598
    invoke-static {v3, v11, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 599
    .line 600
    .line 601
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 602
    .line 603
    new-instance v0, LX/DvM;

    .line 604
    .line 605
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 606
    .line 607
    .line 608
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->$ENTRIES:LX/0vk;

    .line 609
    .line 610
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
