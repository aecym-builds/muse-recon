.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$passwordSavingFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->passwordSavingFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;",
            "Ljava/lang/Boolean;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, LX/Imj;

    .line 1
    .line 2
    invoke-direct {p0}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    if-eqz p3, :cond_0

    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const-string v1, "is_2fa"

    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    :cond_0
    if-eqz p1, :cond_1

    .line 21
    .line 22
    const-string v1, "login_source"

    .line 23
    .line 24
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->getValue()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    :cond_1
    if-eqz p2, :cond_2

    .line 32
    .line 33
    const-string v1, "login_credential_type"

    .line 34
    .line 35
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    :cond_2
    invoke-static {p0}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0
.end method

.method public static synthetic attribution$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;ILjava/lang/Object;)Ljava/util/Map;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method private final credentialAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->getValue()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v0, "login_source"

    .line 7
    .line 8
    new-instance p0, LX/IBK;

    .line 9
    .line 10
    invoke-direct {p0, v0, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "login_credential_type"

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v1, v0, p0}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    return-object v0
.end method

.method private final flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    iget-object p0, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->SIGN_IN_WITH_GOOGLE_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 9
    .line 10
    if-ne p2, v0, :cond_1

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_SIGN_IN_WITH_GOOGLE:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 13
    .line 14
    :goto_0
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    :cond_0
    return-object p0

    .line 19
    :cond_1
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 20
    .line 21
    if-ne p1, v0, :cond_2

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 27
    .line 28
    if-ne p1, v0, :cond_3

    .line 29
    .line 30
    if-nez p0, :cond_0

    .line 31
    .line 32
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_3
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TWO_FAC_REDIRECT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 36
    .line 37
    if-eq p1, v0, :cond_4

    .line 38
    .line 39
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TOS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 40
    .line 41
    if-eq p1, v0, :cond_4

    .line 42
    .line 43
    if-nez p0, :cond_0

    .line 44
    .line 45
    :cond_4
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 46
    .line 47
    goto :goto_0
.end method

.method private final landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;",
            "Ljava/lang/Integer;",
            "Ljava/lang/Boolean;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, LX/Imj;

    .line 1
    .line 2
    invoke-direct {p0}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->putSsoSource(Ljava/util/Map;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    if-eqz p2, :cond_1

    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const-string v1, "num_accounts"

    .line 19
    .line 20
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    :cond_1
    if-eqz p3, :cond_2

    .line 28
    .line 29
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    const-string v1, "1"

    .line 36
    .line 37
    :goto_0
    const-string v0, "has_hatch"

    .line 38
    .line 39
    invoke-virtual {p0, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    :cond_2
    if-eqz p4, :cond_3

    .line 43
    .line 44
    const-string v0, "impression_id"

    .line 45
    .line 46
    invoke-virtual {p0, v0, p4}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_3
    invoke-static {p0}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    return-object v0

    .line 54
    :cond_4
    const-string v1, "0"

    .line 55
    .line 56
    goto :goto_0
.end method

.method public static synthetic landingData$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Object;)Ljava/util/Map;
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p5, 0x8

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method

.method private final landingSsoSourceData(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;)Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    if-ne p1, v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object p1, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    new-instance p0, LX/Imj;

    .line 15
    .line 16
    invoke-direct {p0}, LX/Imj;-><init>()V

    .line 17
    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 20
    .line 21
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->putSsoSource(Ljava/util/Map;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p0}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0

    .line 29
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    return-object v0
.end method

.method private final log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p6

    .line 1
    .line 2
    move-object/from16 v13, p10

    .line 3
    .line 4
    const-string v3, "HatchCaaLogging"

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 7
    .line 8
    move-object/from16 v4, p3

    .line 9
    .line 10
    if-ne p1, v0, :cond_0

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 13
    .line 14
    if-eq v4, v0, :cond_0

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->clearPasskeyOffer()V

    .line 19
    .line 20
    .line 21
    :cond_0
    const/4 v1, 0x0

    .line 22
    if-nez p6, :cond_1

    .line 23
    .line 24
    invoke-direct {p0, v4, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v9

    .line 28
    :cond_1
    sget-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;

    .line 29
    .line 30
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->getValue()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v7

    .line 34
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->getValue()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v8

    .line 38
    invoke-virtual {v4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->getValue()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v10

    .line 42
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingSsoSourceData(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;)Ljava/util/Map;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    move-object/from16 v5, p5

    .line 47
    .line 48
    invoke-static {v5, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    move-object/from16 v0, p9

    .line 53
    .line 54
    invoke-direct {p0, v4, v9, v5, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->passkeyOfferData(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)Ljava/util/Map;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-static {v2, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 59
    .line 60
    .line 61
    move-result-object v11

    .line 62
    move-object/from16 v4, p7

    .line 63
    .line 64
    if-eqz p7, :cond_3

    .line 65
    .line 66
    iget-object v12, v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 67
    .line 68
    :goto_0
    if-nez p10, :cond_2

    .line 69
    .line 70
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 71
    .line 72
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    iget-object v13, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 77
    .line 78
    :cond_2
    invoke-virtual/range {v6 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;->create(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 79
    .line 80
    .line 81
    move-result-object v7

    .line 82
    goto :goto_1

    .line 83
    :cond_3
    move-object v12, v1

    .line 84
    goto :goto_0

    .line 85
    :goto_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 86
    .line 87
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    sget-object v2, LX/EXf;->A02:LX/EXf;

    .line 92
    .line 93
    const-string v0, "caa_login_client_events_rl"

    .line 94
    .line 95
    invoke-interface {v5, v0, v2}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 96
    .line 97
    .line 98
    move-result-object v8

    .line 99
    invoke-interface {v8}, LX/I2T;->isSampled()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-nez v0, :cond_4

    .line 104
    .line 105
    const-string v1, "dropped, not sampled: %s"

    .line 106
    .line 107
    invoke-virtual {v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-static {v3, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :cond_4
    new-instance v9, LX/E8P;

    .line 120
    .line 121
    invoke-direct {v9}, LX/EXN;-><init>()V

    .line 122
    .line 123
    .line 124
    move-object/from16 v0, p4

    .line 125
    .line 126
    invoke-static {v9, v7, v0}, LX/EXN;->A00(LX/EXN;Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    if-eqz p7, :cond_5

    .line 130
    .line 131
    goto :goto_2

    .line 132
    :cond_5
    move-object v2, v1

    .line 133
    goto :goto_3

    .line 134
    :goto_2
    iget-object v2, v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 135
    .line 136
    :goto_3
    const-string v0, "exception_type"

    .line 137
    .line 138
    invoke-virtual {v9, v0, v2}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    if-eqz p7, :cond_6

    .line 142
    .line 143
    goto :goto_4

    .line 144
    :cond_6
    move-object v2, v1

    .line 145
    goto :goto_5

    .line 146
    :goto_4
    iget-object v0, v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 147
    .line 148
    if-eqz v0, :cond_6

    .line 149
    .line 150
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    int-to-long v5, v0

    .line 155
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    :goto_5
    const-string v0, "exception_code"

    .line 160
    .line 161
    invoke-virtual {v9, v0, v2}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 162
    .line 163
    .line 164
    if-eqz p7, :cond_7

    .line 165
    .line 166
    iget-object v1, v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 167
    .line 168
    :cond_7
    const-string v0, "exception_message"

    .line 169
    .line 170
    invoke-virtual {v9, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    const-string v0, "logged_in_identifier"

    .line 174
    .line 175
    move-object/from16 v1, p8

    .line 176
    .line 177
    invoke-virtual {v9, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    const-string v0, "core"

    .line 181
    .line 182
    invoke-interface {v8, v9, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    new-instance v1, LX/E8O;

    .line 186
    .line 187
    invoke-direct {v1}, LX/EXN;-><init>()V

    .line 188
    .line 189
    .line 190
    const-string v0, "login_params"

    .line 191
    .line 192
    invoke-interface {v8, v1, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    invoke-interface {v8}, LX/I2T;->AQ5()V

    .line 196
    .line 197
    .line 198
    if-eqz p7, :cond_8

    .line 199
    .line 200
    const-string v2, "logged %s %s"

    .line 201
    .line 202
    invoke-virtual {v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    invoke-virtual {v4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->describe()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-static {v1, v0, v3, v2}, LX/FnY;->A02(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    :cond_8
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 214
    :catch_0
    move-exception v2

    .line 215
    invoke-virtual {v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    const-string v0, "failed to log "

    .line 220
    .line 221
    invoke-static {v0, v1, v3, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 222
    .line 223
    .line 224
    return-void
.end method

.method public static synthetic log$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p11, 0x10

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 5
    .line 6
    .line 7
    move-result-object p5

    .line 8
    :cond_0
    and-int/lit8 v0, p11, 0x20

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    move-object p6, v1

    .line 14
    :cond_1
    and-int/lit8 v0, p11, 0x40

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    move-object p7, v1

    .line 19
    :cond_2
    and-int/lit16 v0, p11, 0x80

    .line 20
    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    move-object p8, v1

    .line 24
    :cond_3
    and-int/lit16 v0, p11, 0x100

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    move-object p9, v1

    .line 29
    :cond_4
    and-int/lit16 v0, p11, 0x200

    .line 30
    .line 31
    if-eqz v0, :cond_5

    .line 32
    .line 33
    move-object p10, v1

    .line 34
    :cond_5
    invoke-direct/range {p0 .. p10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method private final logAccountSelectorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V
    .locals 8

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->ACCOUNT_SELECTOR_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    move-object v0, p0

    .line 10
    move-object v1, p1

    .line 11
    move-object v4, p2

    .line 12
    move-object v7, v6

    .line 13
    move-object p0, v6

    .line 14
    move-object p1, v6

    .line 15
    move-object p2, v6

    .line 16
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logAymhLoginClicked$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logAymhLoginClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static synthetic logAymhPageShown$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p5, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logAymhPageShown(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logCredentialLoginStart$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    move-object p3, v1

    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x8

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object p4, v1

    .line 17
    :cond_2
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logCredentialLoginStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method private final logGoogleCredentialManager(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V
    .locals 8

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->GOOGLE_CREDENTIAL_MANAGER:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->CONTACTPOINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_SIGN_IN_WITH_GOOGLE:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v6

    .line 10
    const/4 v7, 0x0

    .line 11
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    move-object v0, p0

    .line 16
    move-object v1, p1

    .line 17
    move-object v4, p2

    .line 18
    move-object p0, v7

    .line 19
    move-object p1, v7

    .line 20
    move-object p2, v7

    .line 21
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method private final logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            ")V"
        }
    .end annotation

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v6

    .line 8
    const/4 v8, 0x0

    .line 9
    move-object v0, p0

    .line 10
    move-object v1, p1

    .line 11
    move-object v2, p2

    .line 12
    move-object v4, p3

    .line 13
    move-object v5, p4

    .line 14
    move-object v7, p5

    .line 15
    move-object p0, v8

    .line 16
    move-object p1, v8

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public static synthetic logLandingEvent$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 5
    .line 6
    .line 7
    move-result-object p4

    .line 8
    :cond_0
    and-int/lit8 v0, p6, 0x10

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    const/4 p5, 0x0

    .line 13
    :cond_1
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static synthetic logLoginAttempt$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLoginAttempt(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static synthetic logNtpLandingNext$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logNtpLandingNext(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static synthetic logNtpLandingStart$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p5, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logNtpLandingStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method private final logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;",
            ")V"
        }
    .end annotation

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 8
    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    move-object v0, p0

    .line 17
    move-object v1, p1

    .line 18
    move-object p0, p2

    .line 19
    move-object v5, p3

    .line 20
    move-object p2, p4

    .line 21
    move-object p1, v4

    .line 22
    move-object p3, v4

    .line 23
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public static synthetic logPasskeyAssertion$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 11
    .line 12
    .line 13
    move-result-object p3

    .line 14
    :cond_1
    and-int/lit8 v0, p5, 0x8

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    move-object p4, v1

    .line 19
    :cond_2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method private final logPasskeyNux(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    const-string v1, "entry_point"

    .line 5
    .line 6
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0, p5}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->PASSKEY_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    const/4 v4, 0x0

    .line 25
    move-object v0, p0

    .line 26
    move-object v1, p1

    .line 27
    move-object p1, p4

    .line 28
    move-object p0, v4

    .line 29
    move-object p2, v4

    .line 30
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public static synthetic logPasskeyNux$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x10

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 5
    .line 6
    .line 7
    move-result-object p5

    .line 8
    :cond_0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyNux(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method private final logPasswordSaving(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;ZLjava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object v0, p0

    .line 1
    move-object v3, p3

    .line 2
    invoke-direct {p0, p3, p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->passwordSavingFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v6

    .line 6
    const/4 p0, 0x0

    .line 7
    move-object v1, p1

    .line 8
    move-object v2, p2

    .line 9
    move-object v4, p4

    .line 10
    move-object v5, p6

    .line 11
    move-object p1, p0

    .line 12
    move-object p2, p0

    .line 13
    move-object p3, p0

    .line 14
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            ")V"
        }
    .end annotation

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v6

    .line 10
    const/4 v4, 0x0

    .line 11
    move-object v0, p0

    .line 12
    move-object v1, p1

    .line 13
    move-object v5, p2

    .line 14
    move-object p0, p3

    .line 15
    move-object p1, v4

    .line 16
    move-object p2, v4

    .line 17
    move-object p3, v4

    .line 18
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public static synthetic logRemoveProfile$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 7

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TWO_FAC_REDIRECT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    move-object v0, p0

    .line 10
    move-object v1, p1

    .line 11
    move-object v4, p2

    .line 12
    move-object p0, p3

    .line 13
    move-object p1, v6

    .line 14
    move-object p2, v6

    .line 15
    move-object p3, v6

    .line 16
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logSecurityKeyAssertion$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logSessionLoginFailed$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p7, 0x8

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p4, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x10

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p5, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p7, 0x20

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p6, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSessionLoginFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logSessionLoginSuccess$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;ZILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p7, 0x8

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p4, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x10

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p5, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p7, 0x20

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    const/4 p6, 0x0

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSessionLoginSuccess(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Z)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logSignupLoginSuccess$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSignupLoginSuccess(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final logTwoFactorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;)V
    .locals 7

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TWO_FAC_REDIRECT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 1
    .line 2
    const/4 v6, 0x0

    .line 3
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 4
    .line 5
    .line 6
    move-result-object v5

    .line 7
    move-object v0, p0

    .line 8
    move-object v1, p1

    .line 9
    move-object v2, p2

    .line 10
    move-object v4, p3

    .line 11
    move-object p0, v6

    .line 12
    move-object p1, v6

    .line 13
    move-object p2, v6

    .line 14
    move-object p3, v6

    .line 15
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method private final loginSourceFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;
    .locals 0

    .line 0
    if-nez p2, :cond_0

    .line 1
    .line 2
    sget-object p2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->ACCOUNTS_YOU_MAY_HAVE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    if-eq p1, p0, :cond_0

    .line 7
    .line 8
    sget-object p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    if-ne p1, p0, :cond_1

    .line 11
    .line 12
    sget-object p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->SAVED_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 13
    .line 14
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->getValue()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-static {p3, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    if-eqz p0, :cond_1

    .line 23
    .line 24
    :cond_0
    return-object p2

    .line 25
    :cond_1
    const/4 p2, 0x0

    .line 26
    return-object p2
.end method

.method public static synthetic loginSourceFor$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object p3, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 11
    .line 12
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->loginSourceFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method

.method private final passkeyLoginRoute(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)Ljava/lang/String;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->getRoute()Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->getValue()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    if-nez p0, :cond_1

    .line 13
    .line 14
    :cond_0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 15
    .line 16
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 21
    .line 22
    :cond_1
    return-object p0
.end method

.method private final passkeyOfferData(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->PASSKEY_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {p2, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    sget-object p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 13
    .line 14
    if-eq p1, p0, :cond_1

    .line 15
    .line 16
    const-string v0, "login_credential_type"

    .line 17
    .line 18
    invoke-interface {p3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 23
    .line 24
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0

    .line 39
    :cond_1
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    if-eqz p4, :cond_2

    .line 46
    .line 47
    invoke-virtual {p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->getRoute()Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->getValue()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    if-nez v3, :cond_3

    .line 58
    .line 59
    :cond_2
    iget-object v3, v2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 60
    .line 61
    if-eqz v3, :cond_0

    .line 62
    .line 63
    if-eqz p4, :cond_4

    .line 64
    .line 65
    :cond_3
    invoke-virtual {p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->getValue()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    if-nez v1, :cond_5

    .line 70
    .line 71
    :cond_4
    iget-object v1, v2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 72
    .line 73
    :cond_5
    new-instance v2, LX/Imj;

    .line 74
    .line 75
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 76
    .line 77
    .line 78
    const-string v0, "passkey_login_route"

    .line 79
    .line 80
    invoke-virtual {v2, v0, v3}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    if-eqz v1, :cond_6

    .line 84
    .line 85
    const-string v0, "passkey_offer_surface"

    .line 86
    .line 87
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    :cond_6
    if-ne p1, p0, :cond_7

    .line 91
    .line 92
    const-string v1, "login_source"

    .line 93
    .line 94
    invoke-interface {p3, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-nez v0, :cond_7

    .line 99
    .line 100
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->SAVED_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 101
    .line 102
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->getValue()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_8

    .line 111
    .line 112
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->ACCOUNTS_YOU_MAY_HAVE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 113
    .line 114
    :goto_0
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->getValue()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    :cond_7
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    return-object v0

    .line 126
    :cond_8
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 127
    .line 128
    goto :goto_0
.end method

.method private final passwordSavingFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/lang/String;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->registrationFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0

    .line 8
    :cond_0
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method private final putSsoSource(Ljava/util/Map;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;",
            ")V"
        }
    .end annotation

    .line 0
    const-string p0, "sso_source"

    .line 1
    .line 2
    iget-object v0, p2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;->ssoSource:Ljava/lang/String;

    .line 3
    .line 4
    invoke-interface {p1, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    const-string p0, "rl_sso_source"

    .line 8
    .line 9
    iget-object v0, p2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;->rlSsoSource:Ljava/lang/String;

    .line 10
    .line 11
    invoke-interface {p1, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method private final registrationFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;)Ljava/lang/String;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-nez p0, :cond_1

    .line 7
    .line 8
    :cond_0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 15
    .line 16
    if-nez p0, :cond_1

    .line 17
    .line 18
    sget-object p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_META:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 19
    .line 20
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    :cond_1
    return-object p0
.end method

.method private final removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, LX/Imj;

    .line 1
    .line 2
    invoke-direct {p0}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->putSsoSource(Ljava/util/Map;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    if-eqz p2, :cond_1

    .line 13
    .line 14
    const-string v0, "remove_stage"

    .line 15
    .line 16
    invoke-virtual {p0, v0, p2}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    :cond_1
    if-eqz p3, :cond_2

    .line 20
    .line 21
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    const-string v1, "num_remaining_profiles"

    .line 26
    .line 27
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    :cond_2
    invoke-static {p0}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0
.end method

.method public static synthetic removeProfileData$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;ILjava/lang/Object;)Ljava/util/Map;
    .locals 2

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method private final tapAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, LX/Imj;

    .line 1
    .line 2
    invoke-direct {p0}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    const-string v1, "login_credential_type"

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    :cond_0
    if-eqz p2, :cond_1

    .line 17
    .line 18
    const-string v1, "ntp_source_platform"

    .line 19
    .line 20
    iget-object v0, p2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;->ssoSource:Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    const-string v1, "rl_sso_source"

    .line 26
    .line 27
    iget-object v0, p2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;->rlSsoSource:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {p0, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_1
    invoke-static {p0}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method

.method private final toWireFlag(Z)Ljava/lang/String;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    const-string p0, "1"

    .line 3
    .line 4
    return-object p0

    .line 5
    :cond_0
    const-string p0, "0"

    .line 6
    .line 7
    return-object p0
.end method


# virtual methods
.method public final logAccountSelected(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logAccountSelectorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAccountSelectionLoginSuccess(Ljava/lang/String;ZLjava/lang/String;)V
    .locals 8

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const-string v1, "is_2fa"

    .line 7
    .line 8
    invoke-static {p2}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    const/4 v7, 0x0

    .line 17
    move-object v1, p0

    .line 18
    move-object v5, p1

    .line 19
    move-object p1, p3

    .line 20
    move-object p0, v7

    .line 21
    move-object p2, v7

    .line 22
    move-object p3, v7

    .line 23
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logAccountSelectorBack(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTOR_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logAccountSelectorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAccountSelectorPageShown(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTOR_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logAccountSelectorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAymhLogIntoAnotherAccountClicked(Ljava/lang/String;)V
    .locals 6

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_LOG_INTO_ANOTHER_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    const/4 v5, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    move-object v0, p0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logAymhLoginClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_LOGIN_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->tapAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    const/4 p0, 0x0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logAymhPageShown(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0, p2, p3, p4, p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    const/4 p0, 0x0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logAymhPageShownPerAccount(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ZLjava/lang/String;)V
    .locals 7

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PAGE_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v6, 0x0

    .line 13
    move-object v1, p0

    .line 14
    invoke-direct {p0, p2, v6, v0, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    move-object v4, p1

    .line 19
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logAymhProfileLoadFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ILcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 8

    .line 0
    const/4 v0, 0x3

    .line 1
    move-object v7, p4

    .line 2
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PROFILE_LOAD_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v0, 0x0

    .line 14
    move-object v2, p0

    .line 15
    invoke-direct {p0, p2, v1, v0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 16
    .line 17
    .line 18
    move-result-object v6

    .line 19
    move-object v5, p1

    .line 20
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final logAymhScreenSkippedNoProfiles(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;I)V
    .locals 7

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_SCREEN_SKIPPED_NO_PROFILES:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v6, 0x0

    .line 9
    move-object v1, p0

    .line 10
    invoke-direct {p0, p2, v0, v6, v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    move-object v4, p1

    .line 15
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final logContactPointContinueClicked(Ljava/lang/String;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_CONTINUE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->CONTACTPOINT_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->CONTACTPOINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v7, 0x0

    .line 13
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    move-object v0, p0

    .line 18
    move-object v4, p1

    .line 19
    move-object v8, v7

    .line 20
    move-object p0, v7

    .line 21
    move-object p1, v7

    .line 22
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final logContactPointFocus()V
    .locals 10

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_FOCUS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->CONTACTPOINT_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->CONTACTPOINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v4, 0x0

    .line 13
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    move-object v0, p0

    .line 18
    move-object v7, v4

    .line 19
    move-object v8, v4

    .line 20
    move-object v9, v4

    .line 21
    move-object p0, v4

    .line 22
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final logContactPointPageShown()V
    .locals 10

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->CONTACTPOINT_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->CONTACTPOINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v4, 0x0

    .line 13
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    move-object v0, p0

    .line 18
    move-object v7, v4

    .line 19
    move-object v8, v4

    .line 20
    move-object v9, v4

    .line 21
    move-object p0, v4

    .line 22
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final logCredentialLoginStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)V
    .locals 8

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    const/4 v7, 0x0

    .line 10
    move-object v0, p0

    .line 11
    invoke-direct {p0, p3, p4, v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    invoke-direct {p0, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v6

    .line 19
    move-object v4, p1

    .line 20
    move-object p0, v7

    .line 21
    move-object p1, v7

    .line 22
    move-object p2, v7

    .line 23
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logEnterPasswordInsteadClicked(Ljava/lang/String;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ENTER_PASSWORD_INSTEAD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    move-object v0, p0

    .line 12
    move-object v4, p1

    .line 13
    move-object v7, v6

    .line 14
    move-object v8, v6

    .line 15
    move-object p0, v6

    .line 16
    move-object p1, v6

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final logForgotPasswordButtonClicked(Ljava/lang/String;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->FORGOT_PASSWORD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    move-object v0, p0

    .line 12
    move-object v4, p1

    .line 13
    move-object v7, v6

    .line 14
    move-object v8, v6

    .line 15
    move-object p0, v6

    .line 16
    move-object p1, v6

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final logGoogleAccountSelected(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->GOOGLE_ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logGoogleCredentialManager(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logGoogleCredentialManagerLaunchAttempt()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->GOOGLE_CREDENTIAL_MANAGER_LAUNCH_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logGoogleCredentialManager(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logLoginAttempt(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)V
    .locals 9

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v4, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    const/4 v8, 0x0

    .line 10
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-object v0, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 17
    .line 18
    move-object v1, p0

    .line 19
    invoke-direct {p0, p2, p4, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->loginSourceFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 26
    .line 27
    :cond_0
    invoke-direct {p0, v0, p3, v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;

    .line 28
    .line 29
    .line 30
    move-result-object v6

    .line 31
    invoke-direct {p0, p2, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v7

    .line 35
    move-object v5, p1

    .line 36
    move-object p0, v8

    .line 37
    move-object p1, v8

    .line 38
    move-object p2, v8

    .line 39
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final logLoginStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;)V
    .locals 10

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->CONTACTPOINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    new-instance v2, LX/Imj;

    .line 7
    .line 8
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 9
    .line 10
    .line 11
    if-eqz p2, :cond_0

    .line 12
    .line 13
    const-string v1, "flow_source"

    .line 14
    .line 15
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    :cond_0
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    const/4 v8, 0x0

    .line 27
    move-object v2, p0

    .line 28
    move-object v6, p1

    .line 29
    move-object v9, v8

    .line 30
    move-object p0, v8

    .line 31
    move-object p1, v8

    .line 32
    move-object p2, v8

    .line 33
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final logNtpLandingNext(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->tapAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    const/4 p0, 0x0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logNtpLandingShownPerAccount(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ZLjava/lang/String;)V
    .locals 7

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v6, 0x0

    .line 13
    move-object v1, p0

    .line 14
    invoke-direct {p0, p2, v6, v0, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    move-object v4, p1

    .line 19
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logNtpLandingStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    move-object v0, p0

    .line 5
    invoke-direct {p0, p2, p3, p4, p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->landingData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    const/4 p0, 0x0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logNtpLandingSwitchToLogin(Ljava/lang/String;)V
    .locals 6

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_SWITCH_TO_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    const/4 v5, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    move-object v0, p0

    .line 10
    move-object v3, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logLandingEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logOtpLoginButtonClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;)V
    .locals 10

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const-string v0, "login_credential_type"

    .line 17
    .line 18
    new-instance v2, LX/IBK;

    .line 19
    .line 20
    invoke-direct {v2, v0, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    const-string v1, "flow_source"

    .line 24
    .line 25
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v1, v0, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 30
    .line 31
    .line 32
    move-result-object v7

    .line 33
    const/4 v8, 0x0

    .line 34
    move-object v2, p0

    .line 35
    move-object v6, p1

    .line 36
    move-object v9, v8

    .line 37
    move-object p0, v8

    .line 38
    move-object p1, v8

    .line 39
    move-object p2, v8

    .line 40
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final logOtpLoginFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 10

    .line 0
    move-object v9, p3

    .line 1
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    const-string v1, "flow_source"

    .line 11
    .line 12
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 21
    .line 22
    move-object v2, p0

    .line 23
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->credentialAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)Ljava/util/Map;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v1, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 28
    .line 29
    .line 30
    move-result-object v7

    .line 31
    const/4 v8, 0x0

    .line 32
    move-object v6, p1

    .line 33
    move-object p0, v8

    .line 34
    move-object p1, v8

    .line 35
    move-object p2, v8

    .line 36
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final logOtpLoginSuccess(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;ZLjava/lang/String;)V
    .locals 8

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    const-string v1, "flow_source"

    .line 11
    .line 12
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    new-instance v2, LX/IBK;

    .line 17
    .line 18
    invoke-direct {v2, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const-string v1, "is_2fa"

    .line 22
    .line 23
    invoke-static {p3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v1, v0, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 32
    .line 33
    move-object v2, p0

    .line 34
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->credentialAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)Ljava/util/Map;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {v1, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 39
    .line 40
    .line 41
    move-result-object v7

    .line 42
    const/4 p0, 0x0

    .line 43
    move-object v6, p1

    .line 44
    move-object p2, p4

    .line 45
    move-object p1, p0

    .line 46
    move-object p3, p0

    .line 47
    move-object p4, p0

    .line 48
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

.method public final logOtpPageShown(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;)V
    .locals 9

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->OTP_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    const-string v1, "flow_source"

    .line 11
    .line 12
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    const/4 v7, 0x0

    .line 21
    move-object v1, p0

    .line 22
    move-object v5, p1

    .line 23
    move-object v8, v7

    .line 24
    move-object p0, v7

    .line 25
    move-object p1, v7

    .line 26
    move-object p2, v7

    .line 27
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final logPasskeyAssertionCancel(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyCancelReason;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 4
    .line 5
    const-string v1, "cancel_reason"

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyCancelReason;->getValue()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-direct {p0, v2, v0, v1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final logPasskeyAssertionFailure(Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-direct {p0, v2, p1, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logPasskeyAssertionSuccess()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-direct {p0, v2, v1, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final logPasskeyAssertionTriggered()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-direct {p0, v2, v1, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final logPasskeyNuxCancelled(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxCancelMethod;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 0
    move-object v3, p1

    .line 1
    move-object v4, p3

    .line 2
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_CANCELLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    const-string v1, "cancel_method"

    .line 8
    .line 9
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxCancelMethod;->getValue()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    move-object v1, p0

    .line 18
    move-object p0, p4

    .line 19
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyNux(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logPasskeyNuxContinued(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 0
    move-object v2, p1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_CONTINUED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    move-object v0, p0

    .line 12
    move-object p0, p3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyNux(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final logPasskeyNuxShown(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 0
    move-object v2, p1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    move-object v0, p0

    .line 12
    move-object p0, p3

    .line 13
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasskeyNux(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyNuxEntryPoint;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final logPasswordLoginButtonClicked(Ljava/lang/String;)V
    .locals 10

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->getValue()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-string v0, "login_credential_type"

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v6

    .line 18
    const/4 v7, 0x0

    .line 19
    move-object v1, p0

    .line 20
    move-object v5, p1

    .line 21
    move-object v8, v7

    .line 22
    move-object v9, v7

    .line 23
    move-object p0, v7

    .line 24
    move-object p1, v7

    .line 25
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public final logPasswordLoginFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 9

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v8, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 12
    .line 13
    move-object v1, p0

    .line 14
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->credentialAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v6

    .line 18
    const/4 v7, 0x0

    .line 19
    move-object v5, p1

    .line 20
    move-object p0, v7

    .line 21
    move-object p1, v7

    .line 22
    move-object p2, v7

    .line 23
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logPasswordLoginSuccess(Ljava/lang/String;ZLjava/lang/String;)V
    .locals 9

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const-string v1, "is_2fa"

    .line 7
    .line 8
    invoke-static {p2}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;

    .line 17
    .line 18
    move-object v2, p0

    .line 19
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->credentialAttribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;)Ljava/util/Map;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v1, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 24
    .line 25
    .line 26
    move-result-object v7

    .line 27
    const/4 v8, 0x0

    .line 28
    move-object v6, p1

    .line 29
    move-object p1, p3

    .line 30
    move-object p0, v8

    .line 31
    move-object p2, v8

    .line 32
    move-object p3, v8

    .line 33
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final logPasswordPageShown(Ljava/lang/String;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    move-object v0, p0

    .line 12
    move-object v4, p1

    .line 13
    move-object v7, v6

    .line 14
    move-object v8, v6

    .line 15
    move-object p0, v6

    .line 16
    move-object p1, v6

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final logPasswordSavingCheckboxToggled(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZZ)V
    .locals 5

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v4, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_CHECKBOX_TOGGLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    const-string v1, "is_checked"

    .line 10
    .line 11
    if-eqz p3, :cond_0

    .line 12
    .line 13
    const-string v0, "1"

    .line 14
    .line 15
    :goto_0
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    move-object v1, p0

    .line 20
    move-object p0, p1

    .line 21
    move p1, p4

    .line 22
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasswordSaving(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;ZLjava/util/Map;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    const-string v0, "0"

    .line 27
    .line 28
    goto :goto_0
.end method

.method public final logPasswordSavingDecision(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;)V
    .locals 8

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->isChecked:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_OPT_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 9
    .line 10
    :goto_0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 11
    .line 12
    iget-object v3, p2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->step:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 13
    .line 14
    iget-object v6, p2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->flowWireValue:Ljava/lang/String;

    .line 15
    .line 16
    const/4 v7, 0x0

    .line 17
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    move-object v0, p0

    .line 22
    move-object v4, p1

    .line 23
    move-object p0, v7

    .line 24
    move-object p1, v7

    .line 25
    move-object p2, v7

    .line 26
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_OPT_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 31
    .line 32
    goto :goto_0
.end method

.method public final logPasswordSavingStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZZ)V
    .locals 5

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v4, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    const-string v1, "is_checked"

    .line 10
    .line 11
    if-eqz p3, :cond_0

    .line 12
    .line 13
    const-string v0, "1"

    .line 14
    .line 15
    :goto_0
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    move-object v1, p0

    .line 20
    move-object p0, p1

    .line 21
    move p1, p4

    .line 22
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logPasswordSaving(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;ZLjava/util/Map;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    const-string v0, "0"

    .line 27
    .line 28
    goto :goto_0
.end method

.method public final logRemoveProfileClicked(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-direct {p0, p1, v1, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final logRemoveProfileFailure(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 2

    .line 0
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-direct {p0, v1, v0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final logRemoveProfileSubmitted(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_SUBMITTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {p0, p1, p2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logRemoveProfileSuccess(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;I)V
    .locals 3

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->removeProfileData(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-direct {p0, v2, v1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logRemoveProfile(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final logResendCodeClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;)V
    .locals 9

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 9
    .line 10
    const-string v1, "flow_source"

    .line 11
    .line 12
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    const/4 v7, 0x0

    .line 21
    move-object v1, p0

    .line 22
    move-object v5, p1

    .line 23
    move-object v8, v7

    .line 24
    move-object p0, v7

    .line 25
    move-object p1, v7

    .line 26
    move-object p2, v7

    .line 27
    invoke-direct/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final logSecurityKeyAssertionCancel(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, p1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logSecurityKeyAssertionFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 5
    .line 6
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final logSecurityKeyAssertionSuccess(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, p1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logSecurityKeyAssertionTriggered(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, p1, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logSecurityKeyAssertion(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logSessionLoginFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)V
    .locals 11

    .line 0
    move-object v5, p2

    .line 1
    move-object v9, p3

    .line 2
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    move-object v2, p0

    .line 10
    move-object/from16 p0, p6

    .line 11
    .line 12
    invoke-direct {v2, p0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->passkeyLoginRoute(Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-direct {v2, p2, p4, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->loginSourceFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v10, 0x0

    .line 21
    move-object/from16 v1, p5

    .line 22
    .line 23
    invoke-direct {v2, v0, v1, v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;

    .line 24
    .line 25
    .line 26
    move-result-object v7

    .line 27
    invoke-direct {v2, p2, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v8

    .line 31
    move-object v6, p1

    .line 32
    move-object p1, v10

    .line 33
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final logSessionLoginSuccess(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Z)V
    .locals 11

    .line 0
    const/4 v0, 0x2

    .line 1
    move-object v6, p3

    .line 2
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    const/4 v10, 0x0

    .line 10
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-object v0, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 17
    .line 18
    move-object v3, p0

    .line 19
    invoke-direct {p0, p3, p4, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->loginSourceFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-static/range {p6 .. p6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    move-object/from16 v2, p5

    .line 28
    .line 29
    invoke-direct {p0, v1, v2, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->attribution(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginCredentialType;Ljava/lang/Boolean;)Ljava/util/Map;

    .line 30
    .line 31
    .line 32
    move-result-object v8

    .line 33
    invoke-direct {p0, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->flowWireValueFor(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v9

    .line 37
    move-object v7, p1

    .line 38
    move-object p0, p2

    .line 39
    move-object p1, v10

    .line 40
    move-object p2, v10

    .line 41
    invoke-direct/range {v3 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public final logSignupLoginSuccess(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;)V
    .locals 9

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TOS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const-string v1, "is_2fa"

    .line 7
    .line 8
    const-string v0, "false"

    .line 9
    .line 10
    new-instance v2, LX/IBK;

    .line 11
    .line 12
    invoke-direct {v2, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 16
    .line 17
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->getValue()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v0, "login_source"

    .line 22
    .line 23
    invoke-static {v0, v1, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 24
    .line 25
    .line 26
    move-result-object v7

    .line 27
    move-object v2, p0

    .line 28
    invoke-direct {p0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->registrationFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v8

    .line 32
    const/4 p0, 0x0

    .line 33
    move-object v6, p1

    .line 34
    move-object p1, p2

    .line 35
    move-object p2, p0

    .line 36
    move-object p3, p0

    .line 37
    invoke-direct/range {v2 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final logSilentAuthAttemptStarted()V
    .locals 10

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SILENT_AUTH_ATTEMPT_STARTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->OTP:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const/4 v4, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    move-object v0, p0

    .line 12
    move-object v6, v4

    .line 13
    move-object v7, v4

    .line 14
    move-object v8, v4

    .line 15
    move-object v9, v4

    .line 16
    move-object p0, v4

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final logTwoFactorConfirmNextClicked(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_CONFIRM_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    invoke-direct {p0, v1, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logTwoFactorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final logTwoFactorConfirmPageShown(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_CONFIRM_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    invoke-direct {p0, v1, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logTwoFactorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final logTwoFactorLoginFailed(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 8

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v7, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 8
    .line 9
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TWO_FAC_REDIRECT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 10
    .line 11
    const/4 v6, 0x0

    .line 12
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 13
    .line 14
    .line 15
    move-result-object v5

    .line 16
    move-object v0, p0

    .line 17
    move-object v4, p1

    .line 18
    move-object p0, v6

    .line 19
    move-object p1, v6

    .line 20
    move-object p2, v6

    .line 21
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final logTwoFactorLoginSuccess(Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->TWO_FAC_REDIRECT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    move-object v0, p0

    .line 12
    move-object v4, p1

    .line 13
    move-object p0, p2

    .line 14
    move-object v7, v6

    .line 15
    move-object p1, v6

    .line 16
    move-object p2, v6

    .line 17
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final logTwoFactorNextClicked(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    invoke-direct {p0, v1, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logTwoFactorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final logTwoFactorPageShown(Ljava/lang/String;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 3
    .line 4
    invoke-direct {p0, v1, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->logTwoFactorEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
