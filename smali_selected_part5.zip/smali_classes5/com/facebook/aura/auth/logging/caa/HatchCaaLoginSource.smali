.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

.field public static final enum ACCOUNTS_YOU_MAY_HAVE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

.field public static final enum LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

.field public static final enum REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

.field public static final enum SIGN_IN_WITH_GOOGLE_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "Login"

    .line 2
    .line 3
    const-string v0, "LOGIN"

    .line 4
    .line 5
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 6
    .line 7
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "AccountsYouMayHave"

    .line 14
    .line 15
    const-string v0, "ACCOUNTS_YOU_MAY_HAVE"

    .line 16
    .line 17
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 18
    .line 19
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->ACCOUNTS_YOU_MAY_HAVE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "Registration"

    .line 26
    .line 27
    const-string v0, "REGISTRATION"

    .line 28
    .line 29
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 30
    .line 31
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 35
    .line 36
    const/4 v3, 0x3

    .line 37
    const-string v2, "SignInWithGoogleLogin"

    .line 38
    .line 39
    const-string v1, "SIGN_IN_WITH_GOOGLE_LOGIN"

    .line 40
    .line 41
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 42
    .line 43
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->SIGN_IN_WITH_GOOGLE_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 47
    .line 48
    filled-new-array {v6, v5, v4, v0}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 53
    .line 54
    new-instance v0, LX/DvM;

    .line 55
    .line 56
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 57
    .line 58
    .line 59
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->$ENTRIES:LX/0vk;

    .line 60
    .line 61
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
