.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final flowWireValue:Ljava/lang/String;

.field public final isChecked:Z

.field public final step:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZZ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->step:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->isChecked:Z

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;

    .line 12
    .line 13
    invoke-static {v0, p1, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;->access$passwordSavingFlowWireValue(Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->flowWireValue:Ljava/lang/String;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final getFlowWireValue$fbandroid_express_aura_java_com_facebook_aura_auth_logging_caa_caa()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->flowWireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStep$fbandroid_express_aura_java_com_facebook_aura_auth_logging_caa_caa()Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->step:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isChecked$fbandroid_express_aura_java_com_facebook_aura_auth_logging_caa_caa()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLogger$PasswordSavingAnswer;->isChecked:Z

    .line 1
    .line 2
    return p0
.end method
