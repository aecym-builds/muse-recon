.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum ACCOUNT_SELECTOR_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum CONTACTPOINT_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum GOOGLE_CREDENTIAL_MANAGER:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LOGIN_HOME_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

.field public static final enum PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 15

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "contactpoint_page_interaction"

    .line 2
    .line 3
    const-string v0, "CONTACTPOINT_PAGE_INTERACTION"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->CONTACTPOINT_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "account_selector_page_interaction"

    .line 14
    .line 15
    const-string v0, "ACCOUNT_SELECTOR_PAGE_INTERACTION"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->ACCOUNT_SELECTOR_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "login_home_page_init"

    .line 26
    .line 27
    const-string v0, "LOGIN_HOME_PAGE_INIT"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "login_home_page_interaction"

    .line 38
    .line 39
    const-string v0, "LOGIN_HOME_PAGE_INTERACTION"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_HOME_PAGE_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "login_success"

    .line 50
    .line 51
    const-string v0, "LOGIN_SUCCESS"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "login_failure"

    .line 62
    .line 63
    const-string v0, "LOGIN_FAILURE"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "landing_page_init"

    .line 74
    .line 75
    const-string v0, "LANDING_PAGE_INIT"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LANDING_PAGE_INIT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 83
    .line 84
    const/4 v2, 0x7

    .line 85
    const-string v1, "login_attempt"

    .line 86
    .line 87
    const-string v0, "LOGIN_ATTEMPT"

    .line 88
    .line 89
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 90
    .line 91
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 95
    .line 96
    const/16 v2, 0x8

    .line 97
    .line 98
    const-string v1, "impression"

    .line 99
    .line 100
    const-string v0, "IMPRESSION"

    .line 101
    .line 102
    new-instance v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 103
    .line 104
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sput-object v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->IMPRESSION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 108
    .line 109
    const/16 v2, 0x9

    .line 110
    .line 111
    const-string v1, "interaction"

    .line 112
    .line 113
    const-string v0, "INTERACTION"

    .line 114
    .line 115
    new-instance v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 116
    .line 117
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 118
    .line 119
    .line 120
    sput-object v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 121
    .line 122
    const/16 v2, 0xa

    .line 123
    .line 124
    const-string v1, "google_credential_manager"

    .line 125
    .line 126
    const-string v0, "GOOGLE_CREDENTIAL_MANAGER"

    .line 127
    .line 128
    new-instance v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 129
    .line 130
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 131
    .line 132
    .line 133
    sput-object v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->GOOGLE_CREDENTIAL_MANAGER:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 134
    .line 135
    const/16 v2, 0xb

    .line 136
    .line 137
    const-string v1, "passkey"

    .line 138
    .line 139
    const-string v0, "PASSKEY"

    .line 140
    .line 141
    new-instance v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 142
    .line 143
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 144
    .line 145
    .line 146
    sput-object v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 147
    .line 148
    filled-new-array/range {v3 .. v14}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 153
    .line 154
    new-instance v0, LX/DvM;

    .line 155
    .line 156
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 157
    .line 158
    .line 159
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->$ENTRIES:LX/0vk;

    .line 160
    .line 161
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventCategory;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
