.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum CHANGE_PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum CODE_ENTRY:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum INITIATE_VIEW:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum SEARCH:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public static final enum XAPP_AR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "login"

    .line 2
    .line 3
    const-string v0, "LOGIN"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "search"

    .line 14
    .line 15
    const-string v0, "SEARCH"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->SEARCH:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "initiate_view"

    .line 26
    .line 27
    const-string v0, "INITIATE_VIEW"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->INITIATE_VIEW:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "code_entry"

    .line 38
    .line 39
    const-string v0, "CODE_ENTRY"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->CODE_ENTRY:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "account_selector"

    .line 50
    .line 51
    const-string v0, "ACCOUNT_SELECTOR"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "change_password"

    .line 62
    .line 63
    const-string v0, "CHANGE_PASSWORD"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->CHANGE_PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "xapp_ar"

    .line 74
    .line 75
    const-string v0, "XAPP_AR"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->XAPP_AR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 83
    .line 84
    filled-new-array/range {v3 .. v9}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 89
    .line 90
    new-instance v0, LX/DvM;

    .line 91
    .line 92
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 93
    .line 94
    .line 95
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->$ENTRIES:LX/0vk;

    .line 96
    .line 97
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
