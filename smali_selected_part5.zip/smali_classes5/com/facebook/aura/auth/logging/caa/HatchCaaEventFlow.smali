.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum ACCOUNT_RECOVERY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum AYMH:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum AYMH_FB:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum AYMH_FRL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum AYMH_IG:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum AYMH_WA:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum LOGIN_PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum LOGIN_SIGN_IN_WITH_GOOGLE:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum NEW_TO_META:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

.field public static final enum PASSKEY_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 16

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "login_manual"

    .line 2
    .line 3
    const-string v0, "LOGIN_MANUAL"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_MANUAL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "login"

    .line 14
    .line 15
    const-string v0, "LOGIN"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "aymh"

    .line 26
    .line 27
    const-string v0, "AYMH"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "aymh_fb"

    .line 38
    .line 39
    const-string v0, "AYMH_FB"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH_FB:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "aymh_ig"

    .line 50
    .line 51
    const-string v0, "AYMH_IG"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH_IG:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "aymh_frl"

    .line 62
    .line 63
    const-string v0, "AYMH_FRL"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH_FRL:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "aymh_wa"

    .line 74
    .line 75
    const-string v0, "AYMH_WA"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->AYMH_WA:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 83
    .line 84
    const/4 v2, 0x7

    .line 85
    const-string v1, "login_sign_in_with_google"

    .line 86
    .line 87
    const-string v0, "LOGIN_SIGN_IN_WITH_GOOGLE"

    .line 88
    .line 89
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 90
    .line 91
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_SIGN_IN_WITH_GOOGLE:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 95
    .line 96
    const/16 v2, 0x8

    .line 97
    .line 98
    const-string v1, "ntm"

    .line 99
    .line 100
    const-string v0, "NEW_TO_META"

    .line 101
    .line 102
    new-instance v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 103
    .line 104
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sput-object v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_META:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 108
    .line 109
    const/16 v2, 0x9

    .line 110
    .line 111
    const-string v1, "ntp"

    .line 112
    .line 113
    const-string v0, "NEW_TO_PLATFORM"

    .line 114
    .line 115
    new-instance v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 116
    .line 117
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 118
    .line 119
    .line 120
    sput-object v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 121
    .line 122
    const/16 v2, 0xa

    .line 123
    .line 124
    const-string v1, "account_recovery"

    .line 125
    .line 126
    const-string v0, "ACCOUNT_RECOVERY"

    .line 127
    .line 128
    new-instance v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 129
    .line 130
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 131
    .line 132
    .line 133
    sput-object v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->ACCOUNT_RECOVERY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 134
    .line 135
    const/16 v2, 0xb

    .line 136
    .line 137
    const-string v1, "login_passkey"

    .line 138
    .line 139
    const-string v0, "LOGIN_PASSKEY"

    .line 140
    .line 141
    new-instance v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 142
    .line 143
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 144
    .line 145
    .line 146
    sput-object v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->LOGIN_PASSKEY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 147
    .line 148
    const/16 v2, 0xc

    .line 149
    .line 150
    const-string v1, "passkey_creation"

    .line 151
    .line 152
    const-string v0, "PASSKEY_CREATION"

    .line 153
    .line 154
    new-instance v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 155
    .line 156
    invoke-direct {v15, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 157
    .line 158
    .line 159
    sput-object v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->PASSKEY_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 160
    .line 161
    filled-new-array/range {v3 .. v15}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 166
    .line 167
    new-instance v0, LX/DvM;

    .line 168
    .line 169
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 170
    .line 171
    .line 172
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->$ENTRIES:LX/0vk;

    .line 173
    .line 174
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
