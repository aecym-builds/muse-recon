.class public abstract Lcom/facebook/aura/auth/logging/caa/HatchCaaEnumsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CANCEL_METHOD_KEY:Ljava/lang/String; = "cancel_method"

.field public static final CANCEL_REASON_KEY:Ljava/lang/String; = "cancel_reason"

.field public static final CONTACT_POINT_TYPE_KEY:Ljava/lang/String; = "contact_point_type"

.field public static final ENTRY_POINT_KEY:Ljava/lang/String; = "entry_point"

.field public static final ERROR_TYPE_KEY:Ljava/lang/String; = "error_type"

.field public static final ERROR_TYPE_SOURCE_CLIENT:Ljava/lang/String; = "client_classification"

.field public static final ERROR_TYPE_SOURCE_KEY:Ljava/lang/String; = "error_type_source"

.field public static final FLOW_SOURCE_KEY:Ljava/lang/String; = "flow_source"

.field public static final HAS_HATCH_KEY:Ljava/lang/String; = "has_hatch"

.field public static final IMPRESSION_ID_KEY:Ljava/lang/String; = "impression_id"

.field public static final IS_CHECKED_KEY:Ljava/lang/String; = "is_checked"

.field public static final IS_TWO_FACTOR_KEY:Ljava/lang/String; = "is_2fa"

.field public static final LOGIN_CREDENTIAL_TYPE_KEY:Ljava/lang/String; = "login_credential_type"

.field public static final LOGIN_SOURCE_KEY:Ljava/lang/String; = "login_source"

.field public static final NTM_SWITCH_REASON_KEY:Ljava/lang/String; = "ntm_switch_reason"

.field public static final NTP_SOURCE_PLATFORM_KEY:Ljava/lang/String; = "ntp_source_platform"

.field public static final NUM_ACCOUNTS_KEY:Ljava/lang/String; = "num_accounts"

.field public static final NUM_REMAINING_PROFILES_KEY:Ljava/lang/String; = "num_remaining_profiles"

.field public static final PASSKEY_LOGIN_ROUTE_KEY:Ljava/lang/String; = "passkey_login_route"

.field public static final PASSKEY_OFFER_SURFACE_KEY:Ljava/lang/String; = "passkey_offer_surface"

.field public static final PROFILE_POSITION_ABSOLUTE_KEY:Ljava/lang/String; = "profile_position_absolute"

.field public static final RECOVERY_ARM_KEY:Ljava/lang/String; = "recovery_arm"

.field public static final REGIONAL_TOS_KEY:Ljava/lang/String; = "regional_tos"

.field public static final REGISTRATION_SOURCE_KEY:Ljava/lang/String; = "registration_source"

.field public static final REMOVE_STAGE_KEY:Ljava/lang/String; = "remove_stage"

.field public static final RL_SSO_SOURCE_KEY:Ljava/lang/String; = "rl_sso_source"

.field public static final SOURCE_APP_KEY:Ljava/lang/String; = "source_app"

.field public static final SSO_SOURCE_KEY:Ljava/lang/String; = "sso_source"

.field public static final TOS_CONTENT_VERSION_KEY:Ljava/lang/String; = "tos_content_version"

.field public static final TOTAL_COUNT_KEY:Ljava/lang/String; = "total_count"

.field public static final TOTAL_PROFILE_COUNT_KEY:Ljava/lang/String; = "total_profile_count"
