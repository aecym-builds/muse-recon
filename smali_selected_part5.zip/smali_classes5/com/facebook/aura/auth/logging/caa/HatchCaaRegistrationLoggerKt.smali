.class public abstract Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLoggerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchCaaLogging"
