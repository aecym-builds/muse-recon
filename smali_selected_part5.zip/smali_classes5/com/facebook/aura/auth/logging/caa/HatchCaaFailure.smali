.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;
.super LX/07H;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;

.field public static final MAXIMUM_MESSAGE_LENGTH:I = 0xc8


# instance fields
.field public final accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

.field public final exceptionCode:Ljava/lang/Integer;

.field public final exceptionMessage:Ljava/lang/String;

.field public final exceptionType:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;)V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 14
    .line 15
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 23
    .line 24
    :cond_3
    const/4 v0, 0x3

    .line 25
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 29
    .line 30
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;)V

    .line 31
    .line 32
    .line 33
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;)Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;
    .locals 0

    .line 0
    const/4 p0, 0x3

    .line 1
    invoke-static {p4, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public final describe()Ljava/lang/String;
    .locals 8

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 1
    .line 2
    const-string v7, "<none>"

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    move-object v1, v7

    .line 7
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;->getValue()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    move-object v7, v0

    .line 30
    :cond_1
    const-string v0, "type="

    .line 31
    .line 32
    const-string v2, " code="

    .line 33
    .line 34
    const-string v4, " error_type="

    .line 35
    .line 36
    const-string v6, " message="

    .line 37
    .line 38
    invoke-static/range {v0 .. v7}, LX/Gi8;->A13(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    return-object v0

    .line 43
    :cond_2
    move-object v3, v7

    .line 44
    goto :goto_0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 43
    .line 44
    if-eq v1, v0, :cond_1

    .line 45
    .line 46
    :cond_0
    return v2

    .line 47
    :cond_1
    return v3
.end method

.method public final getAccountErrorType()Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExceptionCode()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExceptionMessage()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExceptionType()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    :cond_0
    add-int/2addr v1, v2

    .line 27
    mul-int/lit8 v1, v1, 0x1f

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    add-int/2addr v1, v0

    .line 36
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
