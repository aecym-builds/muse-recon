.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;
.super LX/07H;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;


# instance fields
.field public final event:Ljava/lang/String;

.field public final eventCategory:Ljava/lang/String;

.field public final eventFlow:Ljava/lang/String;

.field public final eventStep:Ljava/lang/String;

.field public final extraClientData:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final waterfallId:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x5

    .line 4
    invoke-static {p6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p5, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p6, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 21
    .line 22
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 35
    .line 36
    :cond_5
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 p0, 0x5

    .line 4
    invoke-static {p6, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    new-instance p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 8
    .line 9
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public final describe()Ljava/lang/String;
    .locals 6

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v5, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 9
    .line 10
    if-nez v2, :cond_0

    .line 11
    .line 12
    const-string v2, "<none>"

    .line 13
    .line 14
    :cond_0
    const-string v0, "event="

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/002;->A18(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    const-string v0, " flow="

    .line 21
    .line 22
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    const-string v0, " step="

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const-string v0, " category="

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    const-string v0, " waterfall="

    .line 45
    .line 46
    invoke-static {v0, v2, v1}, LX/8mk;->A0k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_1

    .line 69
    .line 70
    :cond_0
    return v2

    .line 71
    :cond_1
    return v3
.end method

.method public final getEvent()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEventCategory()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEventFlow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEventStep()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExtraClientData()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getWaterfallId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->event:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventCategory:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventFlow:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->eventStep:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->waterfallId:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v1, v0

    .line 33
    mul-int/lit8 v1, v1, 0x1f

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->extraClientData:Ljava/util/Map;

    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    add-int/2addr v1, v0

    .line 42
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
