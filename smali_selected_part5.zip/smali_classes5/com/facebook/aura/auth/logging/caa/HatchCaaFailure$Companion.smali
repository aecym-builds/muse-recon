.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic clientSide$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;->SYSTEM_ERROR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    const/4 p4, 0x0

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure$Companion;->clientSide(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method


# virtual methods
.method public final clientSide(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;
    .locals 2

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const-string v0, " | "

    .line 4
    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    if-nez p4, :cond_0

    .line 17
    .line 18
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    const/4 v1, 0x0

    .line 26
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;

    .line 27
    .line 28
    invoke-direct {v0, p1, v1, p0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;)V

    .line 29
    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string v0, ": "

    .line 36
    .line 37
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    goto :goto_0
.end method
