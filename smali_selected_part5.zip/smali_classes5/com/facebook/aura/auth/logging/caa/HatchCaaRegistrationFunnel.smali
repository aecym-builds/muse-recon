.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

.field public static final enum CONFIRMATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

.field public static final enum REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;


# instance fields
.field public final category:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

.field public final eventName:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    .line 0
    const-string v3, "registration_flow_state"

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;->REGISTRATION_FUNNEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

    .line 3
    .line 4
    const-string v1, "REGISTRATION"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 8
    .line 9
    invoke-direct {v5, v1, v0, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;)V

    .line 10
    .line 11
    .line 12
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 13
    .line 14
    const-string v4, "confirmation_flow_state"

    .line 15
    .line 16
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;->CONFIRMATION_FUNNEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

    .line 17
    .line 18
    const-string v2, "CONFIRMATION"

    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 22
    .line 23
    invoke-direct {v0, v2, v1, v4, v3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;)V

    .line 24
    .line 25
    .line 26
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->CONFIRMATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 27
    .line 28
    filled-new-array {v5, v0}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 33
    .line 34
    new-instance v0, LX/DvM;

    .line 35
    .line 36
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->$ENTRIES:LX/0vk;

    .line 40
    .line 41
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->eventName:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->category:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getCategory()Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->category:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEventName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->eventName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
