.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

.field public static final enum CONTACT_POINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

.field public static final enum PICKER_AUTO:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

.field public static final enum PICKER_TAP:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

.field public static final enum SAVED_PASSKEY_SCREEN:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;


# instance fields
.field public final route:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const-string v3, "contact_point"

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->DISCOVERABLE:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 3
    .line 4
    const-string v1, "CONTACT_POINT"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 8
    .line 9
    invoke-direct {v7, v1, v0, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;)V

    .line 10
    .line 11
    .line 12
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->CONTACT_POINT:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 13
    .line 14
    const-string v2, "saved_passkey_screen"

    .line 15
    .line 16
    sget-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;->SAVED_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 17
    .line 18
    const-string v1, "SAVED_PASSKEY_SCREEN"

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 22
    .line 23
    invoke-direct {v5, v1, v0, v2, v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;)V

    .line 24
    .line 25
    .line 26
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->SAVED_PASSKEY_SCREEN:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 27
    .line 28
    const-string v2, "picker_tap"

    .line 29
    .line 30
    const-string v1, "PICKER_TAP"

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 34
    .line 35
    invoke-direct {v4, v1, v0, v2, v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;)V

    .line 36
    .line 37
    .line 38
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->PICKER_TAP:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 39
    .line 40
    const-string v3, "picker_auto"

    .line 41
    .line 42
    const-string v2, "PICKER_AUTO"

    .line 43
    .line 44
    const/4 v1, 0x3

    .line 45
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 46
    .line 47
    invoke-direct {v0, v2, v1, v3, v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;)V

    .line 48
    .line 49
    .line 50
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->PICKER_AUTO:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 51
    .line 52
    filled-new-array {v7, v5, v4, v0}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 57
    .line 58
    new-instance v0, LX/DvM;

    .line 59
    .line 60
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 61
    .line 62
    .line 63
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->$ENTRIES:LX/0vk;

    .line 64
    .line 65
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->value:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->route:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getRoute()Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->route:Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyLoginRoute;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaPasskeyOfferSurface;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
