.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final log(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Ljava/lang/String;Ljava/util/Map;ZLcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            ")V"
        }
    .end annotation

    .line 0
    const-string v3, "HatchCaaLogging"

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;

    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->getCategory()Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->ACCOUNT_RECOVERY:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v7

    .line 22
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->getValue()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v8

    .line 26
    const/4 v1, 0x0

    .line 27
    if-eqz p6, :cond_0

    .line 28
    .line 29
    iget-object p1, p6, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 30
    .line 31
    :goto_0
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iget-object p2, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 38
    .line 39
    move-object p0, p4

    .line 40
    invoke-virtual/range {v4 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;->create(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 41
    .line 42
    .line 43
    move-result-object v6

    .line 44
    goto :goto_1

    .line 45
    :cond_0
    move-object p1, v1

    .line 46
    goto :goto_0

    .line 47
    :goto_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    sget-object v2, LX/EXf;->A02:LX/EXf;

    .line 54
    .line 55
    const-string v0, "caa_account_recovery_client_events_rl"

    .line 56
    .line 57
    invoke-interface {v4, v0, v2}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    invoke-interface {v7}, LX/I2T;->isSampled()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-nez v0, :cond_1

    .line 66
    .line 67
    const-string v1, "dropped, not sampled: %s"

    .line 68
    .line 69
    invoke-virtual {v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {v3, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :cond_1
    new-instance v8, LX/E8S;

    .line 82
    .line 83
    invoke-direct {v8}, LX/EXN;-><init>()V

    .line 84
    .line 85
    .line 86
    invoke-static {v8, v6, p3}, LX/EXN;->A00(LX/EXN;Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    if-eqz p6, :cond_2

    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_2
    move-object v2, v1

    .line 93
    goto :goto_3

    .line 94
    :goto_2
    iget-object v2, p6, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 95
    .line 96
    :goto_3
    const-string v0, "exception_type"

    .line 97
    .line 98
    invoke-virtual {v8, v0, v2}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    if-eqz p6, :cond_3

    .line 102
    .line 103
    goto :goto_4

    .line 104
    :cond_3
    move-object v2, v1

    .line 105
    goto :goto_5

    .line 106
    :goto_4
    iget-object v0, p6, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 107
    .line 108
    if-eqz v0, :cond_3

    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    int-to-long v4, v0

    .line 115
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    :goto_5
    const-string v0, "exception_code"

    .line 120
    .line 121
    invoke-virtual {v8, v0, v2}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 122
    .line 123
    .line 124
    if-eqz p6, :cond_4

    .line 125
    .line 126
    iget-object v1, p6, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 127
    .line 128
    :cond_4
    const-string v0, "exception_message"

    .line 129
    .line 130
    invoke-virtual {v8, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    const-string v0, "core"

    .line 134
    .line 135
    invoke-interface {v7, v8, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    new-instance v2, LX/E8N;

    .line 139
    .line 140
    invoke-direct {v2}, LX/EXN;-><init>()V

    .line 141
    .line 142
    .line 143
    if-eqz p5, :cond_5

    .line 144
    .line 145
    const-string v1, "aymh_password_form"

    .line 146
    .line 147
    goto :goto_6

    .line 148
    :cond_5
    const-string v1, "login_home_page"

    .line 149
    .line 150
    :goto_6
    const-string v0, "event_source"

    .line 151
    .line 152
    invoke-virtual {v2, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    const-string v0, "account_recovery_params"

    .line 156
    .line 157
    invoke-interface {v7, v2, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-interface {v7}, LX/I2T;->AQ5()V

    .line 161
    .line 162
    .line 163
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 164
    :catch_0
    move-exception v2

    .line 165
    invoke-virtual {v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    const-string v0, "failed to log "

    .line 170
    .line 171
    invoke-static {v0, v1, v3, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 172
    .line 173
    .line 174
    return-void
.end method

.method public static synthetic log$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Ljava/lang/String;Ljava/util/Map;ZLcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x20

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p6, 0x0

    .line 5
    :cond_0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Ljava/lang/String;Ljava/util/Map;ZLcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logNativeRecoveryEvent$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZLcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 9

    .line 0
    move-object v1, p5

    .line 1
    and-int/lit8 v0, p7, 0x10

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    new-instance v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;

    .line 7
    .line 8
    move-object v3, v2

    .line 9
    move-object v4, v2

    .line 10
    move-object v5, v2

    .line 11
    move-object v6, v2

    .line 12
    move-object v7, v2

    .line 13
    move-object v8, v2

    .line 14
    invoke-direct/range {v1 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;-><init>(Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    and-int/lit8 v0, p7, 0x20

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    const/4 p6, 0x0

    .line 22
    :cond_1
    move-object p5, v1

    .line 23
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->logNativeRecoveryEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZLcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final toExtraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance v2, LX/Imj;

    .line 1
    .line 2
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    const-string v1, "entry_point"

    .line 6
    .line 7
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->getValue()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    if-eqz p3, :cond_8

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->ACCOUNTS_YOU_MAY_HAVE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 17
    .line 18
    :goto_0
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->getValue()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v0, "login_source"

    .line 23
    .line 24
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->contactPointType:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 28
    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    const-string v1, "contact_point_type"

    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;->getValue()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->pickedMedium:Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;

    .line 41
    .line 42
    const-string p0, "1"

    .line 43
    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaContactPointType;->getValue()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v2, v0, p0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    :cond_1
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalProfileCount:Ljava/lang/Integer;

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    const-string v1, "total_profile_count"

    .line 62
    .line 63
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    :cond_2
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->totalCount:Ljava/lang/Integer;

    .line 71
    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    const-string v1, "total_count"

    .line 79
    .line 80
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    :cond_3
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->profilePositionAbsolute:Ljava/lang/Integer;

    .line 88
    .line 89
    if-eqz v0, :cond_4

    .line 90
    .line 91
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    const-string v1, "profile_position_absolute"

    .line 96
    .line 97
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    :cond_4
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->isChecked:Ljava/lang/Boolean;

    .line 105
    .line 106
    if-eqz v0, :cond_6

    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    if-nez v0, :cond_5

    .line 113
    .line 114
    const-string p0, "0"

    .line 115
    .line 116
    :cond_5
    const-string v0, "is_checked"

    .line 117
    .line 118
    invoke-virtual {v2, v0, p0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    :cond_6
    iget-object v1, p1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;->sourceApp:Ljava/lang/String;

    .line 122
    .line 123
    if-eqz v1, :cond_7

    .line 124
    .line 125
    const-string v0, "source_app"

    .line 126
    .line 127
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    :cond_7
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    return-object v0

    .line 135
    :cond_8
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginSource;

    .line 136
    .line 137
    goto :goto_0
.end method


# virtual methods
.method public final logAccountRecoveryStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Ljava/lang/String;Z)V
    .locals 9

    .line 0
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;->ACCOUNT_RECOVERY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;

    .line 4
    .line 5
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->PASSWORD_FORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 6
    .line 7
    const-string v2, "entry_point"

    .line 8
    .line 9
    invoke-virtual {p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;->getValue()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    new-instance v1, LX/IBK;

    .line 14
    .line 15
    invoke-direct {v1, v2, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    const-string v0, "recovery_arm"

    .line 19
    .line 20
    invoke-static {v0, p3, v1}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    const/4 v8, 0x0

    .line 25
    move-object v2, p0

    .line 26
    move-object v5, p1

    .line 27
    move v7, p4

    .line 28
    invoke-direct/range {v2 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Ljava/lang/String;Ljava/util/Map;ZLcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final logNativeRecoveryEvent(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;ZLcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 4

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x4

    .line 6
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 7
    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    move-object v0, p0

    .line 11
    move p1, p4

    .line 12
    invoke-direct {p0, p5, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->toExtraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryExtras;Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEventStep;Z)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    move-object p2, p6

    .line 17
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEvent;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;Ljava/lang/String;Ljava/util/Map;ZLcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
