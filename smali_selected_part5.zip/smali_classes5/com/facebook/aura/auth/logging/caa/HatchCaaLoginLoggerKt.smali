.class public abstract Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginLoggerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchCaaLogging"
