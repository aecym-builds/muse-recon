.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final accountType(Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)LX/E3o;
    .locals 0

    .line 0
    const/4 p0, -0x1

    .line 1
    if-eqz p1, :cond_4

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eq p1, p0, :cond_4

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    if-eq p1, p0, :cond_3

    .line 11
    .line 12
    const/4 p0, 0x1

    .line 13
    if-eq p1, p0, :cond_2

    .line 14
    .line 15
    const/4 p0, 0x2

    .line 16
    if-eq p1, p0, :cond_1

    .line 17
    .line 18
    const/4 p0, 0x3

    .line 19
    if-ne p1, p0, :cond_0

    .line 20
    .line 21
    sget-object p0, LX/E3o;->A04:LX/E3o;

    .line 22
    .line 23
    return-object p0

    .line 24
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 25
    .line 26
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 27
    .line 28
    .line 29
    throw p0

    .line 30
    :cond_1
    sget-object p0, LX/E3o;->A02:LX/E3o;

    .line 31
    .line 32
    return-object p0

    .line 33
    :cond_2
    sget-object p0, LX/E3o;->A03:LX/E3o;

    .line 34
    .line 35
    return-object p0

    .line 36
    :cond_3
    sget-object p0, LX/E3o;->A01:LX/E3o;

    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_4
    const/4 p0, 0x0

    .line 40
    return-object p0
.end method

.method private final extraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    const-string p0, "registration_source"

    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {p0, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :cond_1
    return-object v0
.end method

.method private final latchedRegistrationSource(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    const-string p0, "registration_source"

    .line 5
    .line 6
    invoke-static {p0, p1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    if-nez p0, :cond_1

    .line 11
    .line 12
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    :cond_1
    return-object p0
.end method

.method private final log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Long;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    const-string v4, "HatchCaaLogging"

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 3
    .line 4
    invoke-virtual {v1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    sget-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->Companion:Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;

    .line 9
    .line 10
    invoke-virtual/range {p7 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->getEventName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v7

    .line 14
    invoke-virtual/range {p7 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->getCategory()Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventCategory;->getValue()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v8

    .line 22
    if-eqz p4, :cond_0

    .line 23
    .line 24
    invoke-virtual/range {p4 .. p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v9

    .line 28
    if-nez v9, :cond_1

    .line 29
    .line 30
    :cond_0
    iget-object v9, v2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 31
    .line 32
    if-nez v9, :cond_1

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_META:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->getValue()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v9

    .line 40
    :cond_1
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->getValue()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v10

    .line 44
    invoke-direct {p0, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->latchedRegistrationSource(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Ljava/util/Map;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    move-object/from16 v3, p5

    .line 49
    .line 50
    invoke-static {v0, v3}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 51
    .line 52
    .line 53
    move-result-object v11

    .line 54
    const/4 v3, 0x0

    .line 55
    move-object/from16 v5, p8

    .line 56
    .line 57
    if-eqz p8, :cond_2

    .line 58
    .line 59
    iget-object v12, v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->accountErrorType:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;

    .line 60
    .line 61
    :goto_0
    invoke-virtual {v1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-object v13, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual/range {v6 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;->create(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    goto :goto_1

    .line 72
    :cond_2
    move-object v12, v3

    .line 73
    goto :goto_0

    .line 74
    :goto_1
    :try_start_0
    sget-object v1, LX/EXf;->A02:LX/EXf;

    .line 75
    .line 76
    const-string v0, "caa_acquisition_client_events_rl"

    .line 77
    .line 78
    move-object/from16 v7, p11

    .line 79
    .line 80
    invoke-interface {v7, v0, v1}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    invoke-interface {v7}, LX/I2T;->isSampled()Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_3

    .line 89
    .line 90
    const-string v2, "dropped, not sampled: state=%s %s"

    .line 91
    .line 92
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->getValue()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    invoke-virtual {v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    invoke-static {v4, v2, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :cond_3
    new-instance v8, LX/E8R;

    .line 109
    .line 110
    invoke-direct {v8}, LX/EXN;-><init>()V

    .line 111
    .line 112
    .line 113
    move-object/from16 v0, p3

    .line 114
    .line 115
    invoke-static {v8, v6, v0}, LX/EXN;->A00(LX/EXN;Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    if-eqz p8, :cond_4

    .line 119
    .line 120
    goto :goto_2

    .line 121
    :cond_4
    move-object v1, v3

    .line 122
    goto :goto_3

    .line 123
    :goto_2
    iget-object v1, v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionType:Ljava/lang/String;

    .line 124
    .line 125
    :goto_3
    const-string v0, "exception_type"

    .line 126
    .line 127
    invoke-virtual {v8, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    if-eqz p8, :cond_5

    .line 131
    .line 132
    goto :goto_4

    .line 133
    :cond_5
    move-object v1, v3

    .line 134
    goto :goto_5

    .line 135
    :goto_4
    iget-object v0, v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionCode:Ljava/lang/Integer;

    .line 136
    .line 137
    if-eqz v0, :cond_5

    .line 138
    .line 139
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    int-to-long v0, v0

    .line 144
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    :goto_5
    const-string v0, "exception_code"

    .line 149
    .line 150
    invoke-virtual {v8, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 151
    .line 152
    .line 153
    if-eqz p8, :cond_6

    .line 154
    .line 155
    iget-object v3, v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->exceptionMessage:Ljava/lang/String;

    .line 156
    .line 157
    :cond_6
    const-string v0, "exception_message"

    .line 158
    .line 159
    invoke-virtual {v8, v0, v3}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    const-string v0, "logged_in_identifier"

    .line 163
    .line 164
    move-object/from16 v1, p9

    .line 165
    .line 166
    invoke-virtual {v8, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    const-string v0, "core"

    .line 170
    .line 171
    invoke-interface {v7, v8, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    new-instance v3, LX/E8Q;

    .line 175
    .line 176
    invoke-direct {v3}, LX/EXN;-><init>()V

    .line 177
    .line 178
    .line 179
    invoke-direct {p0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->regInstance()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    const-string v0, "reg_instance"

    .line 184
    .line 185
    invoke-virtual {v3, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    const-string v0, "created_userid"

    .line 189
    .line 190
    move-object/from16 v1, p6

    .line 191
    .line 192
    invoke-virtual {v3, v0, v1}, LX/EXN;->A02(Ljava/lang/String;Ljava/lang/Long;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->getValue()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    const-string v0, "state"

    .line 200
    .line 201
    invoke-virtual {v3, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    iget-object v1, v2, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 205
    .line 206
    const-string v0, "entry_point"

    .line 207
    .line 208
    invoke-virtual {v3, v0, v1}, LX/EXN;->A03(Ljava/lang/String;Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    move-object/from16 v0, p10

    .line 212
    .line 213
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->accountType(Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)LX/E3o;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    const-string v0, "ntp_source_platform"

    .line 218
    .line 219
    invoke-virtual {v3, v1, v0}, LX/EXN;->A01(LX/DfA;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    const-string v0, "acquisition_client_params"

    .line 223
    .line 224
    invoke-interface {v7, v3, v0}, LX/I2T;->A40(LX/EXN;Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    invoke-interface {v7}, LX/I2T;->AQ5()V

    .line 228
    .line 229
    .line 230
    if-eqz p8, :cond_7

    .line 231
    .line 232
    const-string v3, "logged state=%s %s %s"

    .line 233
    .line 234
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->getValue()Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v2

    .line 238
    invoke-virtual {v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    invoke-virtual {v5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;->describe()Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-static {v2, v1, v0, v4, v3}, LX/FnY;->A01(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    :cond_7
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 250
    :catch_0
    move-exception v5

    .line 251
    invoke-virtual {p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->getValue()Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    invoke-virtual {v6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;->describe()Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object v2

    .line 259
    const-string v1, "failed to log state="

    .line 260
    .line 261
    const-string v0, " "

    .line 262
    .line 263
    invoke-static {v1, v3, v0, v2}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-static {v4, v0, v5}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 268
    .line 269
    .line 270
    return-void
.end method

.method public static synthetic log$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p12, 0x8

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p4, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p12, 0x10

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 11
    .line 12
    .line 13
    move-result-object p5

    .line 14
    :cond_1
    and-int/lit8 v0, p12, 0x20

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    move-object p6, v1

    .line 19
    :cond_2
    and-int/lit8 v0, p12, 0x40

    .line 20
    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    sget-object p7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 24
    .line 25
    :cond_3
    and-int/lit16 v0, p12, 0x80

    .line 26
    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    move-object p8, v1

    .line 30
    :cond_4
    and-int/lit16 v0, p12, 0x100

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    move-object p9, v1

    .line 35
    :cond_5
    and-int/lit16 v0, p12, 0x200

    .line 36
    .line 37
    if-eqz v0, :cond_6

    .line 38
    .line 39
    move-object p10, v1

    .line 40
    :cond_6
    and-int/lit16 v0, p12, 0x400

    .line 41
    .line 42
    if-eqz v0, :cond_7

    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 45
    .line 46
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 47
    .line 48
    .line 49
    move-result-object p11

    .line 50
    :cond_7
    invoke-direct/range {p0 .. p11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method private final logAcOptIn(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 12

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_CENTER_OPT_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v1, p1

    .line 19
    move-object v3, p2

    .line 20
    move-object v10, p3

    .line 21
    move-object v8, v6

    .line 22
    move-object v9, v6

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;",
            "Ljava/lang/Long;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->CONFIRMATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 1
    .line 2
    const-string v1, "flow_source"

    .line 3
    .line 4
    invoke-virtual {p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 9
    .line 10
    .line 11
    move-result-object v5

    .line 12
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->CONFIRMATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    move-object v0, p0

    .line 16
    move-object v1, p1

    .line 17
    move-object v3, p2

    .line 18
    move-object p0, p4

    .line 19
    move-object v6, p5

    .line 20
    move-object p1, p6

    .line 21
    move-object p2, p7

    .line 22
    move-object/from16 p3, p8

    .line 23
    .line 24
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public static synthetic logConfirmation$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p9, 0x8

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p4, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p9, 0x10

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p5, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p9, 0x20

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p6, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p9, 0x40

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p7, v1

    .line 21
    :cond_3
    and-int/lit16 v0, p9, 0x80

    .line 22
    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 26
    .line 27
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 28
    .line 29
    .line 30
    move-result-object p8

    .line 31
    :cond_4
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public static synthetic logConfirmationFailure$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p4, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmationFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logConfirmationNext$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmationNext(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logConfirmationResendCodeClicked$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmationResendCodeClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logConfirmationStart$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p3, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmationStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logConfirmationSuccess$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p4, 0x0

    .line 5
    :cond_0
    and-int/lit8 v0, p6, 0x10

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 12
    .line 13
    .line 14
    move-result-object p5

    .line 15
    :cond_1
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmationSuccess(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public static synthetic logCreateAttempt$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p5, 0x8

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logCreateAttempt(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logCreateFailure$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x8

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logCreateFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logCreateSuccess$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p5, v1

    .line 16
    :cond_2
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logCreateSuccess(Ljava/lang/String;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static synthetic logLinkFailure$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logLinkFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static synthetic logLinkSuccess$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logLinkSuccess(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static synthetic logRegistrationStart$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtmSwitchReason;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p8, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p8, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p5, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p8, 0x20

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p6, v1

    .line 21
    :cond_3
    and-int/lit8 v0, p8, 0x40

    .line 22
    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    move-object p7, v1

    .line 26
    :cond_4
    invoke-virtual/range {p0 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logRegistrationStart(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtmSwitchReason;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static synthetic logTosAccepted$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegionalTos;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p6, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x8

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p6, 0x10

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p5, v1

    .line 21
    :cond_3
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logTosAccepted(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegionalTos;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method private final logUpsell(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->UPSELL_AT_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v1, p1

    .line 19
    move-object v3, p2

    .line 20
    move-object v8, v6

    .line 21
    move-object v9, v6

    .line 22
    move-object v10, v6

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final regInstance()Ljava/lang/String;
    .locals 2

    .line 0
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;->get()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 7
    :catch_0
    move-exception p0

    .line 8
    const-string v1, "reg_instance unavailable, logging blank"

    .line 9
    .line 10
    const-string v0, "HatchCaaLogging"

    .line 11
    .line 12
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 13
    .line 14
    .line 15
    const-string v0, ""

    .line 16
    .line 17
    return-object v0
.end method


# virtual methods
.method public final logAcOptInBack(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPT_IN_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logAcOptIn(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAcOptInStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPT_IN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logAcOptIn(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAcOptedIn(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPTED_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logAcOptIn(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logAcOptedOut(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPTED_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1, p2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logAcOptIn(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logBirthdayBack(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->BIRTHDAY:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logBirthdayFocused(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_FOCUSED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->BIRTHDAY:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logBirthdayInteraction(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->BIRTHDAY:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logBirthdayNext(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->BIRTHDAY:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logBirthdayStart(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->BIRTHDAY:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logConfirmationFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 6

    .line 0
    move-object v3, p2

    .line 1
    move-object v4, p3

    .line 2
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    move-object v0, p0

    .line 15
    move-object v2, p1

    .line 16
    move-object p1, p4

    .line 17
    move-object p0, v5

    .line 18
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final logConfirmationNext(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 6

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    move-object v0, p0

    .line 15
    move-object v2, p1

    .line 16
    move-object p1, p3

    .line 17
    move-object v5, v4

    .line 18
    move-object p0, v4

    .line 19
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logConfirmationResendCodeClicked(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 6

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    move-object v0, p0

    .line 15
    move-object v2, p1

    .line 16
    move-object p1, p3

    .line 17
    move-object v5, v4

    .line 18
    move-object p0, v4

    .line 19
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logConfirmationStart(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 6

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    move-object v0, p0

    .line 15
    move-object v2, p1

    .line 16
    move-object p1, p3

    .line 17
    move-object v5, v4

    .line 18
    move-object p0, v4

    .line 19
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final logConfirmationSuccess(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    move-object v8, p5

    .line 3
    invoke-static {p2, v0, p5}, LX/003;->A0z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 7
    .line 8
    move-object v6, p3

    .line 9
    if-eqz p3, :cond_0

    .line 10
    .line 11
    invoke-static {p3}, LX/0wP;->A01(Ljava/lang/String;)Ljava/lang/Long;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    :goto_0
    const/4 v4, 0x0

    .line 16
    move-object v0, p0

    .line 17
    move-object v2, p1

    .line 18
    move-object v7, p4

    .line 19
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logConfirmation(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/Long;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    const/4 v5, 0x0

    .line 24
    goto :goto_0
.end method

.method public final logCreateAttempt(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 9

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    move-object v1, p0

    .line 5
    invoke-direct {p0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->extraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v6

    .line 9
    const/4 v7, 0x0

    .line 10
    sget-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 15
    .line 16
    .line 17
    move-result-object p3

    .line 18
    move-object v4, p1

    .line 19
    move-object v5, p2

    .line 20
    move-object p2, p4

    .line 21
    move-object p0, v7

    .line 22
    move-object p1, v7

    .line 23
    invoke-direct/range {v1 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logCreateFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 12

    .line 0
    const/4 v0, 0x4

    .line 1
    move-object/from16 v9, p5

    .line 2
    .line 3
    invoke-static {v9, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 7
    .line 8
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 9
    .line 10
    move-object v1, p0

    .line 11
    invoke-direct {p0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->extraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)Ljava/util/Map;

    .line 12
    .line 13
    .line 14
    move-result-object v6

    .line 15
    const/4 v7, 0x0

    .line 16
    sget-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    move-object v4, p1

    .line 25
    move-object v5, p2

    .line 26
    move-object/from16 v11, p4

    .line 27
    .line 28
    move-object v10, v7

    .line 29
    invoke-direct/range {v1 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final logCreateNewAccountClicked(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_NEW_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->LANDING:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_META:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 8
    .line 9
    .line 10
    move-result-object v5

    .line 11
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 16
    .line 17
    .line 18
    move-result-object v11

    .line 19
    move-object v0, p0

    .line 20
    move-object v3, p1

    .line 21
    move-object v8, v6

    .line 22
    move-object v9, v6

    .line 23
    move-object v10, v6

    .line 24
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final logCreateSuccess(Ljava/lang/String;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;)V
    .locals 12

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_CREATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    move-object v1, p0

    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->extraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)Ljava/util/Map;

    .line 8
    .line 9
    .line 10
    move-result-object v6

    .line 11
    const/4 v9, 0x0

    .line 12
    sget-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    move-object v4, p1

    .line 21
    move-object v7, p2

    .line 22
    move-object v5, p3

    .line 23
    move-object/from16 v11, p5

    .line 24
    .line 25
    move-object v10, v9

    .line 26
    invoke-direct/range {v1 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public final logLinkFailure(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;)V
    .locals 13

    .line 0
    const/4 v0, 0x2

    .line 1
    move-object/from16 v8, p3

    .line 2
    .line 3
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->LINK_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 7
    .line 8
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_LINK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 9
    .line 10
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 11
    .line 12
    const/16 v12, 0x570

    .line 13
    .line 14
    const/4 v5, 0x0

    .line 15
    move-object v0, p0

    .line 16
    move-object v3, p1

    .line 17
    move-object v10, p2

    .line 18
    move-object v6, v5

    .line 19
    move-object v7, v5

    .line 20
    move-object v9, v5

    .line 21
    move-object v11, v5

    .line 22
    move-object p0, v5

    .line 23
    invoke-static/range {v0 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;ILjava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logLinkSuccess(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)V
    .locals 9

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->LINK_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->ACCOUNT_LINK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;->NEW_TO_PLATFORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;

    .line 5
    .line 6
    move-object v1, p0

    .line 7
    invoke-direct {p0, p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->extraClientData(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;)Ljava/util/Map;

    .line 8
    .line 9
    .line 10
    move-result-object v6

    .line 11
    const/4 v7, 0x0

    .line 12
    sget-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 17
    .line 18
    .line 19
    move-result-object p3

    .line 20
    move-object v4, p1

    .line 21
    move-object p0, v7

    .line 22
    move-object p1, v7

    .line 23
    invoke-direct/range {v1 .. v12}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logNameBack(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logNameInteractionFirstName(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_INTERACTION_FIRST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logNameInteractionLastName(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_INTERACTION_LAST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logNameNext(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logNameStart(Ljava/lang/String;)V
    .locals 12

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    sget-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    move-object v0, p0

    .line 18
    move-object v3, p1

    .line 19
    move-object v6, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final logRegistrationStart(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtmSwitchReason;)V
    .locals 10

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v4, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->REGISTRATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    new-instance v2, LX/Imj;

    .line 8
    .line 9
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 10
    .line 11
    .line 12
    if-eqz p3, :cond_0

    .line 13
    .line 14
    const-string v1, "flow_source"

    .line 15
    .line 16
    invoke-virtual {p3}, Lcom/facebook/aura/auth/logging/caa/HatchCaaFlowSource;->getValue()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    :cond_0
    if-eqz p5, :cond_1

    .line 24
    .line 25
    const-string v1, "registration_source"

    .line 26
    .line 27
    invoke-virtual {p5}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationSource;->getValue()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    :cond_1
    if-eqz p7, :cond_2

    .line 35
    .line 36
    const-string v1, "ntm_switch_reason"

    .line 37
    .line 38
    invoke-virtual/range {p7 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaNtmSwitchReason;->getValue()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    :cond_2
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 46
    .line 47
    .line 48
    move-result-object v7

    .line 49
    const/4 v8, 0x0

    .line 50
    sget-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 51
    .line 52
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 53
    .line 54
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 55
    .line 56
    .line 57
    move-result-object p3

    .line 58
    move-object v2, p0

    .line 59
    move-object v5, p2

    .line 60
    move-object v6, p4

    .line 61
    move-object/from16 p2, p6

    .line 62
    .line 63
    move-object p0, v8

    .line 64
    move-object p1, v8

    .line 65
    invoke-direct/range {v2 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final logTosAccepted(Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegionalTos;Ljava/lang/String;)V
    .locals 14

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->TOS_ACCEPTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;->TERMS_OF_SERVICE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;

    .line 3
    .line 4
    new-instance v2, LX/Imj;

    .line 5
    .line 6
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 7
    .line 8
    .line 9
    if-eqz p4, :cond_0

    .line 10
    .line 11
    const-string v1, "regional_tos"

    .line 12
    .line 13
    invoke-virtual/range {p4 .. p4}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegionalTos;->getValue()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    :cond_0
    move-object/from16 v1, p5

    .line 21
    .line 22
    if-eqz p5, :cond_1

    .line 23
    .line 24
    const-string v0, "tos_content_version"

    .line 25
    .line 26
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    :cond_1
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 30
    .line 31
    .line 32
    move-result-object v7

    .line 33
    const/4 v8, 0x0

    .line 34
    sget-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;->REGISTRATION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 37
    .line 38
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 39
    .line 40
    .line 41
    move-result-object v13

    .line 42
    move-object v2, p0

    .line 43
    move-object v5, p1

    .line 44
    move-object/from16 v6, p2

    .line 45
    .line 46
    move-object/from16 v12, p3

    .line 47
    .line 48
    move-object v10, v8

    .line 49
    move-object v11, v8

    .line 50
    invoke-direct/range {v2 .. v13}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->log(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationEventStep;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaEventFlow;Ljava/util/Map;Ljava/lang/Long;Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationFunnel;Lcom/facebook/aura/auth/logging/caa/HatchCaaFailure;Ljava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaNtpSourcePlatform;LX/ES4;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final logUpsellBack(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logUpsell(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logUpsellLoginToExistingAccount(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_LOGIN_TO_EXISTING_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logUpsell(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logUpsellStart(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logUpsell(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logUpsellSwitchToNtm(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->SWITCH_TO_NTM:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationLogger;->logUpsell(Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
