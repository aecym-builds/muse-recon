.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum AC_OPTED_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum AC_OPTED_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum AC_OPT_IN_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum AC_OPT_IN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum BIRTHDAY_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum BIRTHDAY_FOCUSED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum BIRTHDAY_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum BIRTHDAY_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum BIRTHDAY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CONFIRMATION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CONFIRMATION_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CONFIRMATION_RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CONFIRMATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CONFIRMATION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CREATE_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CREATE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CREATE_NEW_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum CREATE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum LINK_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum LINK_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum NAME_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum NAME_INTERACTION_FIRST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum NAME_INTERACTION_LAST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum NAME_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum NAME_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum REGISTRATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum SWITCH_TO_NTM:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum TOS_ACCEPTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum UPSELL_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum UPSELL_LOGIN_TO_EXISTING_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

.field public static final enum UPSELL_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 61

    .line 0
    const/4 v3, 0x0

    .line 1
    const-string v2, "registration_start"

    .line 2
    .line 3
    const-string v1, "REGISTRATION_START"

    .line 4
    .line 5
    new-instance v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 6
    .line 7
    move-object/from16 v0, v34

    .line 8
    .line 9
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->REGISTRATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    const-string v2, "create_new_account_clicked"

    .line 16
    .line 17
    const-string v1, "CREATE_NEW_ACCOUNT_CLICKED"

    .line 18
    .line 19
    new-instance v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 20
    .line 21
    move-object/from16 v0, v33

    .line 22
    .line 23
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_NEW_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 27
    .line 28
    const/4 v3, 0x2

    .line 29
    const-string v2, "name_start"

    .line 30
    .line 31
    const-string v1, "NAME_START"

    .line 32
    .line 33
    new-instance v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 34
    .line 35
    move-object/from16 v0, v32

    .line 36
    .line 37
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sput-object v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 41
    .line 42
    const/4 v3, 0x3

    .line 43
    const-string v2, "name_interaction_first_name"

    .line 44
    .line 45
    const-string v1, "NAME_INTERACTION_FIRST_NAME"

    .line 46
    .line 47
    new-instance v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 48
    .line 49
    move-object/from16 v0, v31

    .line 50
    .line 51
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_INTERACTION_FIRST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 55
    .line 56
    const/4 v3, 0x4

    .line 57
    const-string v2, "name_interaction_last_name"

    .line 58
    .line 59
    const-string v1, "NAME_INTERACTION_LAST_NAME"

    .line 60
    .line 61
    new-instance v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 62
    .line 63
    move-object/from16 v0, v30

    .line 64
    .line 65
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    sput-object v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_INTERACTION_LAST_NAME:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 69
    .line 70
    const/4 v3, 0x5

    .line 71
    const-string v2, "name_next"

    .line 72
    .line 73
    const-string v1, "NAME_NEXT"

    .line 74
    .line 75
    new-instance v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 76
    .line 77
    move-object/from16 v0, v29

    .line 78
    .line 79
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 83
    .line 84
    const/4 v3, 0x6

    .line 85
    const-string v2, "name_back"

    .line 86
    .line 87
    const-string v1, "NAME_BACK"

    .line 88
    .line 89
    new-instance v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 90
    .line 91
    move-object/from16 v0, v28

    .line 92
    .line 93
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sput-object v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->NAME_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 97
    .line 98
    const/4 v3, 0x7

    .line 99
    const-string v2, "birthday_start"

    .line 100
    .line 101
    const-string v1, "BIRTHDAY_START"

    .line 102
    .line 103
    new-instance v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 104
    .line 105
    move-object/from16 v0, v27

    .line 106
    .line 107
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 108
    .line 109
    .line 110
    sput-object v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 111
    .line 112
    const/16 v3, 0x8

    .line 113
    .line 114
    const-string v2, "birthday_focused"

    .line 115
    .line 116
    const-string v1, "BIRTHDAY_FOCUSED"

    .line 117
    .line 118
    new-instance v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 119
    .line 120
    move-object/from16 v0, v26

    .line 121
    .line 122
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sput-object v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_FOCUSED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 126
    .line 127
    const/16 v3, 0x9

    .line 128
    .line 129
    const-string v2, "birthday_interaction"

    .line 130
    .line 131
    const-string v1, "BIRTHDAY_INTERACTION"

    .line 132
    .line 133
    new-instance v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 134
    .line 135
    move-object/from16 v0, v25

    .line 136
    .line 137
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sput-object v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_INTERACTION:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 141
    .line 142
    const/16 v3, 0xa

    .line 143
    .line 144
    const-string v2, "birthday_next"

    .line 145
    .line 146
    const-string v1, "BIRTHDAY_NEXT"

    .line 147
    .line 148
    new-instance v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 149
    .line 150
    move-object/from16 v0, v24

    .line 151
    .line 152
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 153
    .line 154
    .line 155
    sput-object v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 156
    .line 157
    const/16 v3, 0xb

    .line 158
    .line 159
    const-string v2, "birthday_back"

    .line 160
    .line 161
    const-string v1, "BIRTHDAY_BACK"

    .line 162
    .line 163
    new-instance v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 164
    .line 165
    move-object/from16 v0, v23

    .line 166
    .line 167
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 168
    .line 169
    .line 170
    sput-object v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->BIRTHDAY_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 171
    .line 172
    const/16 v3, 0xc

    .line 173
    .line 174
    const-string v2, "create_attempt"

    .line 175
    .line 176
    const-string v1, "CREATE_ATTEMPT"

    .line 177
    .line 178
    new-instance v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 179
    .line 180
    move-object/from16 v0, v22

    .line 181
    .line 182
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 183
    .line 184
    .line 185
    sput-object v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 186
    .line 187
    const/16 v3, 0xd

    .line 188
    .line 189
    const-string v2, "create_success"

    .line 190
    .line 191
    const-string v1, "CREATE_SUCCESS"

    .line 192
    .line 193
    new-instance v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 194
    .line 195
    move-object/from16 v0, v21

    .line 196
    .line 197
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 198
    .line 199
    .line 200
    sput-object v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 201
    .line 202
    const/16 v3, 0xe

    .line 203
    .line 204
    const-string v2, "create_failure"

    .line 205
    .line 206
    const-string v1, "CREATE_FAILURE"

    .line 207
    .line 208
    new-instance v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 209
    .line 210
    move-object/from16 v0, v20

    .line 211
    .line 212
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 213
    .line 214
    .line 215
    sput-object v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CREATE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 216
    .line 217
    const/16 v3, 0xf

    .line 218
    .line 219
    const-string v2, "link_success"

    .line 220
    .line 221
    const-string v1, "LINK_SUCCESS"

    .line 222
    .line 223
    new-instance v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 224
    .line 225
    move-object/from16 v0, v19

    .line 226
    .line 227
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 228
    .line 229
    .line 230
    sput-object v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->LINK_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 231
    .line 232
    const/16 v3, 0x10

    .line 233
    .line 234
    const-string v2, "link_failure"

    .line 235
    .line 236
    const-string v1, "LINK_FAILURE"

    .line 237
    .line 238
    new-instance v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 239
    .line 240
    move-object/from16 v0, v18

    .line 241
    .line 242
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 243
    .line 244
    .line 245
    sput-object v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->LINK_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 246
    .line 247
    const/16 v3, 0x11

    .line 248
    .line 249
    const-string v2, "upsell_start"

    .line 250
    .line 251
    const-string v1, "UPSELL_START"

    .line 252
    .line 253
    new-instance v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 254
    .line 255
    move-object/from16 v0, v17

    .line 256
    .line 257
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 258
    .line 259
    .line 260
    sput-object v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 261
    .line 262
    const/16 v3, 0x12

    .line 263
    .line 264
    const-string v2, "upsell_login_to_existing_account"

    .line 265
    .line 266
    const-string v1, "UPSELL_LOGIN_TO_EXISTING_ACCOUNT"

    .line 267
    .line 268
    new-instance v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 269
    .line 270
    move-object/from16 v0, v16

    .line 271
    .line 272
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 273
    .line 274
    .line 275
    sput-object v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_LOGIN_TO_EXISTING_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 276
    .line 277
    const/16 v2, 0x13

    .line 278
    .line 279
    const-string v1, "switch_to_ntm"

    .line 280
    .line 281
    const-string v0, "SWITCH_TO_NTM"

    .line 282
    .line 283
    new-instance v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 284
    .line 285
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 286
    .line 287
    .line 288
    sput-object v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->SWITCH_TO_NTM:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 289
    .line 290
    const/16 v2, 0x14

    .line 291
    .line 292
    const-string v1, "upsell_back"

    .line 293
    .line 294
    const-string v0, "UPSELL_BACK"

    .line 295
    .line 296
    new-instance v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 297
    .line 298
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 299
    .line 300
    .line 301
    sput-object v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->UPSELL_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 302
    .line 303
    const/16 v2, 0x15

    .line 304
    .line 305
    const-string v1, "confirmation_start"

    .line 306
    .line 307
    const-string v0, "CONFIRMATION_START"

    .line 308
    .line 309
    new-instance v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 310
    .line 311
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 312
    .line 313
    .line 314
    sput-object v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 315
    .line 316
    const/16 v2, 0x16

    .line 317
    .line 318
    const-string v1, "confirmation_next"

    .line 319
    .line 320
    const-string v0, "CONFIRMATION_NEXT"

    .line 321
    .line 322
    new-instance v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 323
    .line 324
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 325
    .line 326
    .line 327
    sput-object v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 328
    .line 329
    const/16 v2, 0x17

    .line 330
    .line 331
    const-string v1, "confirmation_resend_code_clicked"

    .line 332
    .line 333
    const-string v0, "CONFIRMATION_RESEND_CODE_CLICKED"

    .line 334
    .line 335
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 336
    .line 337
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 338
    .line 339
    .line 340
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 341
    .line 342
    const/16 v2, 0x18

    .line 343
    .line 344
    const-string v1, "confirmation_success"

    .line 345
    .line 346
    const-string v0, "CONFIRMATION_SUCCESS"

    .line 347
    .line 348
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 349
    .line 350
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 351
    .line 352
    .line 353
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 354
    .line 355
    const/16 v2, 0x19

    .line 356
    .line 357
    const-string v1, "confirmation_failure"

    .line 358
    .line 359
    const-string v0, "CONFIRMATION_FAILURE"

    .line 360
    .line 361
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 362
    .line 363
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 364
    .line 365
    .line 366
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->CONFIRMATION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 367
    .line 368
    const/16 v2, 0x1a

    .line 369
    .line 370
    const-string v1, "tos_accepted"

    .line 371
    .line 372
    const-string v0, "TOS_ACCEPTED"

    .line 373
    .line 374
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 375
    .line 376
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 377
    .line 378
    .line 379
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->TOS_ACCEPTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 380
    .line 381
    const/16 v6, 0x1b

    .line 382
    .line 383
    const-string v1, "ac_opt_in_start"

    .line 384
    .line 385
    const-string v0, "AC_OPT_IN_START"

    .line 386
    .line 387
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 388
    .line 389
    invoke-direct {v5, v0, v6, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 390
    .line 391
    .line 392
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPT_IN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 393
    .line 394
    const/16 v2, 0x1c

    .line 395
    .line 396
    const-string v1, "ac_opted_in"

    .line 397
    .line 398
    const-string v0, "AC_OPTED_IN"

    .line 399
    .line 400
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 401
    .line 402
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 403
    .line 404
    .line 405
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPTED_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 406
    .line 407
    const/16 v0, 0x1d

    .line 408
    .line 409
    const-string v2, "ac_opted_out"

    .line 410
    .line 411
    const-string v1, "AC_OPTED_OUT"

    .line 412
    .line 413
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 414
    .line 415
    invoke-direct {v3, v1, v0, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 416
    .line 417
    .line 418
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPTED_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 419
    .line 420
    const/16 v2, 0x1e

    .line 421
    .line 422
    const-string v1, "ac_opt_in_back"

    .line 423
    .line 424
    const-string v0, "AC_OPT_IN_BACK"

    .line 425
    .line 426
    new-instance v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 427
    .line 428
    invoke-direct {v15, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 429
    .line 430
    .line 431
    sput-object v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->AC_OPT_IN_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 432
    .line 433
    const/16 v0, 0x1f

    .line 434
    .line 435
    new-array v1, v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 436
    .line 437
    move-object/from16 v42, v26

    .line 438
    .line 439
    move-object/from16 v43, v25

    .line 440
    .line 441
    move-object/from16 v44, v24

    .line 442
    .line 443
    move-object/from16 v45, v23

    .line 444
    .line 445
    move-object/from16 v46, v22

    .line 446
    .line 447
    move-object/from16 v47, v21

    .line 448
    .line 449
    move-object/from16 v48, v20

    .line 450
    .line 451
    move-object/from16 v49, v19

    .line 452
    .line 453
    move-object/from16 v50, v18

    .line 454
    .line 455
    move-object/from16 v51, v17

    .line 456
    .line 457
    move-object/from16 v52, v16

    .line 458
    .line 459
    move-object/from16 v53, v14

    .line 460
    .line 461
    move-object/from16 v54, v13

    .line 462
    .line 463
    move-object/from16 v55, v12

    .line 464
    .line 465
    move-object/from16 v56, v11

    .line 466
    .line 467
    move-object/from16 v57, v10

    .line 468
    .line 469
    move-object/from16 v58, v9

    .line 470
    .line 471
    move-object/from16 v59, v8

    .line 472
    .line 473
    move-object/from16 v60, v7

    .line 474
    .line 475
    move-object/from16 v35, v33

    .line 476
    .line 477
    move-object/from16 v36, v32

    .line 478
    .line 479
    move-object/from16 v37, v31

    .line 480
    .line 481
    move-object/from16 v38, v30

    .line 482
    .line 483
    move-object/from16 v39, v29

    .line 484
    .line 485
    move-object/from16 v40, v28

    .line 486
    .line 487
    move-object/from16 v41, v27

    .line 488
    .line 489
    filled-new-array/range {v34 .. v60}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 490
    .line 491
    .line 492
    move-result-object v0

    .line 493
    const/4 v7, 0x0

    .line 494
    invoke-static {v0, v7, v1, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 495
    .line 496
    .line 497
    filled-new-array {v5, v4, v3, v15}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 498
    .line 499
    .line 500
    move-result-object v2

    .line 501
    const/4 v0, 0x4

    .line 502
    invoke-static {v2, v7, v1, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 503
    .line 504
    .line 505
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 506
    .line 507
    new-instance v0, LX/DvM;

    .line 508
    .line 509
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 510
    .line 511
    .line 512
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->$ENTRIES:LX/0vk;

    .line 513
    .line 514
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaRegistrationState;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
