.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum ACCOUNT_SELECTOR_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum ACCOUNT_SELECTOR_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_LOGIN_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_LOG_INTO_ANOTHER_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_PAGE_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_PROFILE_LOAD_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum AYMH_SCREEN_SKIPPED_NO_PROFILES:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum CONTACTPOINT_CONTINUE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum CONTACTPOINT_FOCUS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum CONTACTPOINT_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum ENTER_PASSWORD_INSTEAD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum FORGOT_PASSWORD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum GOOGLE_ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum GOOGLE_CREDENTIAL_MANAGER_LAUNCH_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_FAILED_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum LOGIN_SUCCESS_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum NTP_LANDING_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum NTP_LANDING_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum NTP_LANDING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum NTP_LANDING_SWITCH_TO_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum OTP_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_LOGIN_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_LOGIN_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_LOGIN_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_LOGIN_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_NUX_CANCELLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_NUX_CONTINUED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSKEY_NUX_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSWORD_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSWORD_SAVING_CHECKBOX_TOGGLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSWORD_SAVING_OPT_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSWORD_SAVING_OPT_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum PASSWORD_SAVING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum REMOVE_PROFILE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum REMOVE_PROFILE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum REMOVE_PROFILE_SUBMITTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum REMOVE_PROFILE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum SECURITY_KEY_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum SECURITY_KEY_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum SECURITY_KEY_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum SECURITY_KEY_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum SILENT_AUTH_ATTEMPT_STARTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum TWO_FAC_CONFIRM_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum TWO_FAC_CONFIRM_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum TWO_FAC_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

.field public static final enum TWO_FAC_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 83

    .line 0
    const/4 v3, 0x0

    .line 1
    const-string v2, "contactpoint_page_shown"

    .line 2
    .line 3
    const-string v1, "CONTACTPOINT_PAGE_SHOWN"

    .line 4
    .line 5
    new-instance v56, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 6
    .line 7
    move-object/from16 v0, v56

    .line 8
    .line 9
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v56, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    const-string v2, "contactpoint_focus"

    .line 16
    .line 17
    const-string v1, "CONTACTPOINT_FOCUS"

    .line 18
    .line 19
    new-instance v55, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 20
    .line 21
    move-object/from16 v0, v55

    .line 22
    .line 23
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v55, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_FOCUS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 27
    .line 28
    const/4 v3, 0x2

    .line 29
    const-string v2, "contactpoint_continue_clicked"

    .line 30
    .line 31
    const-string v1, "CONTACTPOINT_CONTINUE_CLICKED"

    .line 32
    .line 33
    new-instance v54, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 34
    .line 35
    move-object/from16 v0, v54

    .line 36
    .line 37
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sput-object v54, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->CONTACTPOINT_CONTINUE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 41
    .line 42
    const/4 v3, 0x3

    .line 43
    const-string v2, "login_start"

    .line 44
    .line 45
    const-string v1, "LOGIN_START"

    .line 46
    .line 47
    new-instance v53, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 48
    .line 49
    move-object/from16 v0, v53

    .line 50
    .line 51
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v53, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 55
    .line 56
    const/4 v3, 0x4

    .line 57
    const-string v2, "otp_page_shown"

    .line 58
    .line 59
    const-string v1, "OTP_PAGE_SHOWN"

    .line 60
    .line 61
    new-instance v52, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 62
    .line 63
    move-object/from16 v0, v52

    .line 64
    .line 65
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    sput-object v52, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->OTP_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 69
    .line 70
    const/4 v3, 0x5

    .line 71
    const-string v2, "resend_code_clicked"

    .line 72
    .line 73
    const-string v1, "RESEND_CODE_CLICKED"

    .line 74
    .line 75
    new-instance v51, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 76
    .line 77
    move-object/from16 v0, v51

    .line 78
    .line 79
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v51, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->RESEND_CODE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 83
    .line 84
    const/4 v3, 0x6

    .line 85
    const-string v2, "enter_password_instead_button_clicked"

    .line 86
    .line 87
    const-string v1, "ENTER_PASSWORD_INSTEAD_BUTTON_CLICKED"

    .line 88
    .line 89
    new-instance v50, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 90
    .line 91
    move-object/from16 v0, v50

    .line 92
    .line 93
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sput-object v50, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ENTER_PASSWORD_INSTEAD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 97
    .line 98
    const/4 v3, 0x7

    .line 99
    const-string v2, "password_page_shown"

    .line 100
    .line 101
    const-string v1, "PASSWORD_PAGE_SHOWN"

    .line 102
    .line 103
    new-instance v49, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 104
    .line 105
    move-object/from16 v0, v49

    .line 106
    .line 107
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 108
    .line 109
    .line 110
    sput-object v49, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 111
    .line 112
    const/16 v3, 0x8

    .line 113
    .line 114
    const-string v2, "forgot_password_button_clicked"

    .line 115
    .line 116
    const-string v1, "FORGOT_PASSWORD_BUTTON_CLICKED"

    .line 117
    .line 118
    new-instance v48, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 119
    .line 120
    move-object/from16 v0, v48

    .line 121
    .line 122
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sput-object v48, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->FORGOT_PASSWORD_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 126
    .line 127
    const/16 v3, 0x9

    .line 128
    .line 129
    const-string v2, "login_button_clicked"

    .line 130
    .line 131
    const-string v1, "LOGIN_BUTTON_CLICKED"

    .line 132
    .line 133
    new-instance v47, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 134
    .line 135
    move-object/from16 v0, v47

    .line 136
    .line 137
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sput-object v47, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_BUTTON_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 141
    .line 142
    const/16 v3, 0xa

    .line 143
    .line 144
    const-string v2, "login_attempt"

    .line 145
    .line 146
    const-string v1, "LOGIN_ATTEMPT"

    .line 147
    .line 148
    new-instance v46, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 149
    .line 150
    move-object/from16 v0, v46

    .line 151
    .line 152
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 153
    .line 154
    .line 155
    sput-object v46, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 156
    .line 157
    const/16 v3, 0xb

    .line 158
    .line 159
    const-string v2, "login_success"

    .line 160
    .line 161
    const-string v1, "LOGIN_SUCCESS"

    .line 162
    .line 163
    new-instance v45, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 164
    .line 165
    move-object/from16 v0, v45

    .line 166
    .line 167
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 168
    .line 169
    .line 170
    sput-object v45, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 171
    .line 172
    const/16 v3, 0xc

    .line 173
    .line 174
    const-string v2, "login_failed"

    .line 175
    .line 176
    const-string v1, "LOGIN_FAILED"

    .line 177
    .line 178
    new-instance v44, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 179
    .line 180
    move-object/from16 v0, v44

    .line 181
    .line 182
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 183
    .line 184
    .line 185
    sput-object v44, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 186
    .line 187
    const/16 v3, 0xd

    .line 188
    .line 189
    const-string v2, "2fa_login_success"

    .line 190
    .line 191
    const-string v1, "LOGIN_SUCCESS_2FA"

    .line 192
    .line 193
    new-instance v43, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 194
    .line 195
    move-object/from16 v0, v43

    .line 196
    .line 197
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 198
    .line 199
    .line 200
    sput-object v43, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_SUCCESS_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 201
    .line 202
    const/16 v3, 0xe

    .line 203
    .line 204
    const-string v2, "2fa_login_failed"

    .line 205
    .line 206
    const-string v1, "LOGIN_FAILED_2FA"

    .line 207
    .line 208
    new-instance v42, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 209
    .line 210
    move-object/from16 v0, v42

    .line 211
    .line 212
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 213
    .line 214
    .line 215
    sput-object v42, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->LOGIN_FAILED_2FA:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 216
    .line 217
    const/16 v3, 0xf

    .line 218
    .line 219
    const-string v2, "2fa_page_shown"

    .line 220
    .line 221
    const-string v1, "TWO_FAC_PAGE_SHOWN"

    .line 222
    .line 223
    new-instance v41, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 224
    .line 225
    move-object/from16 v0, v41

    .line 226
    .line 227
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 228
    .line 229
    .line 230
    sput-object v41, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 231
    .line 232
    const/16 v3, 0x10

    .line 233
    .line 234
    const-string v2, "2fa_next_clicked"

    .line 235
    .line 236
    const-string v1, "TWO_FAC_NEXT_CLICKED"

    .line 237
    .line 238
    new-instance v40, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 239
    .line 240
    move-object/from16 v0, v40

    .line 241
    .line 242
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 243
    .line 244
    .line 245
    sput-object v40, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 246
    .line 247
    const/16 v3, 0x11

    .line 248
    .line 249
    const-string v2, "2fa_confirm_page_shown"

    .line 250
    .line 251
    const-string v1, "TWO_FAC_CONFIRM_PAGE_SHOWN"

    .line 252
    .line 253
    new-instance v39, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 254
    .line 255
    move-object/from16 v0, v39

    .line 256
    .line 257
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 258
    .line 259
    .line 260
    sput-object v39, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_CONFIRM_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 261
    .line 262
    const/16 v3, 0x12

    .line 263
    .line 264
    const-string v2, "2fa_confirm_next_clicked"

    .line 265
    .line 266
    const-string v1, "TWO_FAC_CONFIRM_NEXT_CLICKED"

    .line 267
    .line 268
    new-instance v38, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 269
    .line 270
    move-object/from16 v0, v38

    .line 271
    .line 272
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 273
    .line 274
    .line 275
    sput-object v38, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->TWO_FAC_CONFIRM_NEXT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 276
    .line 277
    const/16 v3, 0x13

    .line 278
    .line 279
    const-string v2, "aymh_login_clicked"

    .line 280
    .line 281
    const-string v1, "AYMH_LOGIN_CLICKED"

    .line 282
    .line 283
    new-instance v37, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 284
    .line 285
    move-object/from16 v0, v37

    .line 286
    .line 287
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 288
    .line 289
    .line 290
    sput-object v37, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_LOGIN_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 291
    .line 292
    const/16 v3, 0x14

    .line 293
    .line 294
    const-string v2, "aymh_page_shown"

    .line 295
    .line 296
    const-string v1, "AYMH_PAGE_SHOWN"

    .line 297
    .line 298
    new-instance v36, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 299
    .line 300
    move-object/from16 v0, v36

    .line 301
    .line 302
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 303
    .line 304
    .line 305
    sput-object v36, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 306
    .line 307
    const/16 v3, 0x15

    .line 308
    .line 309
    const-string v2, "aymh_log_into_another_account_clicked"

    .line 310
    .line 311
    const-string v1, "AYMH_LOG_INTO_ANOTHER_ACCOUNT_CLICKED"

    .line 312
    .line 313
    new-instance v35, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 314
    .line 315
    move-object/from16 v0, v35

    .line 316
    .line 317
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 318
    .line 319
    .line 320
    sput-object v35, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_LOG_INTO_ANOTHER_ACCOUNT_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 321
    .line 322
    const/16 v3, 0x16

    .line 323
    .line 324
    const-string v2, "aymh_page_shown_per_account"

    .line 325
    .line 326
    const-string v1, "AYMH_PAGE_SHOWN_PER_ACCOUNT"

    .line 327
    .line 328
    new-instance v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 329
    .line 330
    move-object/from16 v0, v34

    .line 331
    .line 332
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 333
    .line 334
    .line 335
    sput-object v34, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PAGE_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 336
    .line 337
    const/16 v3, 0x17

    .line 338
    .line 339
    const-string v2, "ntp_landing_shown_per_account"

    .line 340
    .line 341
    const-string v1, "NTP_LANDING_SHOWN_PER_ACCOUNT"

    .line 342
    .line 343
    new-instance v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 344
    .line 345
    move-object/from16 v0, v33

    .line 346
    .line 347
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 348
    .line 349
    .line 350
    sput-object v33, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_SHOWN_PER_ACCOUNT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 351
    .line 352
    const/16 v3, 0x18

    .line 353
    .line 354
    const-string v2, "ntp_landing_start"

    .line 355
    .line 356
    const-string v1, "NTP_LANDING_START"

    .line 357
    .line 358
    new-instance v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 359
    .line 360
    move-object/from16 v0, v32

    .line 361
    .line 362
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 363
    .line 364
    .line 365
    sput-object v32, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 366
    .line 367
    const/16 v3, 0x19

    .line 368
    .line 369
    const-string v2, "ntp_landing_next"

    .line 370
    .line 371
    const-string v1, "NTP_LANDING_NEXT"

    .line 372
    .line 373
    new-instance v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 374
    .line 375
    move-object/from16 v0, v31

    .line 376
    .line 377
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 378
    .line 379
    .line 380
    sput-object v31, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_NEXT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 381
    .line 382
    const/16 v2, 0x1a

    .line 383
    .line 384
    const-string v1, "ntp_landing_switch_to_login"

    .line 385
    .line 386
    const-string v0, "NTP_LANDING_SWITCH_TO_LOGIN"

    .line 387
    .line 388
    new-instance v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 389
    .line 390
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 391
    .line 392
    .line 393
    sput-object v3, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->NTP_LANDING_SWITCH_TO_LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 394
    .line 395
    const/16 v4, 0x1b

    .line 396
    .line 397
    const-string v2, "aymh_profile_load_failed"

    .line 398
    .line 399
    const-string v1, "AYMH_PROFILE_LOAD_FAILED"

    .line 400
    .line 401
    new-instance v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 402
    .line 403
    move-object/from16 v0, v30

    .line 404
    .line 405
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 406
    .line 407
    .line 408
    sput-object v30, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_PROFILE_LOAD_FAILED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 409
    .line 410
    const/16 v4, 0x1c

    .line 411
    .line 412
    const-string v2, "aymh_screen_skipped_no_profiles"

    .line 413
    .line 414
    const-string v1, "AYMH_SCREEN_SKIPPED_NO_PROFILES"

    .line 415
    .line 416
    new-instance v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 417
    .line 418
    move-object/from16 v0, v29

    .line 419
    .line 420
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 421
    .line 422
    .line 423
    sput-object v29, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->AYMH_SCREEN_SKIPPED_NO_PROFILES:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 424
    .line 425
    const/16 v4, 0x1d

    .line 426
    .line 427
    const-string v2, "account_selector_page_shown"

    .line 428
    .line 429
    const-string v1, "ACCOUNT_SELECTOR_PAGE_SHOWN"

    .line 430
    .line 431
    new-instance v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 432
    .line 433
    move-object/from16 v0, v28

    .line 434
    .line 435
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 436
    .line 437
    .line 438
    sput-object v28, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTOR_PAGE_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 439
    .line 440
    const/16 v4, 0x1e

    .line 441
    .line 442
    const-string v2, "account_selected"

    .line 443
    .line 444
    const-string v1, "ACCOUNT_SELECTED"

    .line 445
    .line 446
    new-instance v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 447
    .line 448
    move-object/from16 v0, v27

    .line 449
    .line 450
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 451
    .line 452
    .line 453
    sput-object v27, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 454
    .line 455
    const/16 v4, 0x1f

    .line 456
    .line 457
    const-string v2, "account_selector_back"

    .line 458
    .line 459
    const-string v1, "ACCOUNT_SELECTOR_BACK"

    .line 460
    .line 461
    new-instance v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 462
    .line 463
    move-object/from16 v0, v26

    .line 464
    .line 465
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 466
    .line 467
    .line 468
    sput-object v26, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->ACCOUNT_SELECTOR_BACK:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 469
    .line 470
    const/16 v4, 0x20

    .line 471
    .line 472
    const-string v2, "login_google_credential_manager_launch_attempt"

    .line 473
    .line 474
    const-string v1, "GOOGLE_CREDENTIAL_MANAGER_LAUNCH_ATTEMPT"

    .line 475
    .line 476
    new-instance v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 477
    .line 478
    move-object/from16 v0, v25

    .line 479
    .line 480
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 481
    .line 482
    .line 483
    sput-object v25, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->GOOGLE_CREDENTIAL_MANAGER_LAUNCH_ATTEMPT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 484
    .line 485
    const/16 v4, 0x21

    .line 486
    .line 487
    const-string v2, "login_google_account_selected"

    .line 488
    .line 489
    const-string v1, "GOOGLE_ACCOUNT_SELECTED"

    .line 490
    .line 491
    new-instance v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 492
    .line 493
    move-object/from16 v0, v24

    .line 494
    .line 495
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 496
    .line 497
    .line 498
    sput-object v24, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->GOOGLE_ACCOUNT_SELECTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 499
    .line 500
    const/16 v4, 0x22

    .line 501
    .line 502
    const-string v2, "passkey_login_assertion_triggered"

    .line 503
    .line 504
    const-string v1, "PASSKEY_LOGIN_ASSERTION_TRIGGERED"

    .line 505
    .line 506
    new-instance v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 507
    .line 508
    move-object/from16 v0, v23

    .line 509
    .line 510
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 511
    .line 512
    .line 513
    sput-object v23, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 514
    .line 515
    const/16 v4, 0x23

    .line 516
    .line 517
    const-string v2, "passkey_login_assertion_success"

    .line 518
    .line 519
    const-string v1, "PASSKEY_LOGIN_ASSERTION_SUCCESS"

    .line 520
    .line 521
    new-instance v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 522
    .line 523
    move-object/from16 v0, v22

    .line 524
    .line 525
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 526
    .line 527
    .line 528
    sput-object v22, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 529
    .line 530
    const/16 v4, 0x24

    .line 531
    .line 532
    const-string v2, "passkey_login_assertion_failure"

    .line 533
    .line 534
    const-string v1, "PASSKEY_LOGIN_ASSERTION_FAILURE"

    .line 535
    .line 536
    new-instance v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 537
    .line 538
    move-object/from16 v0, v21

    .line 539
    .line 540
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 541
    .line 542
    .line 543
    sput-object v21, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 544
    .line 545
    const/16 v4, 0x25

    .line 546
    .line 547
    const-string v2, "passkey_login_assertion_cancel"

    .line 548
    .line 549
    const-string v1, "PASSKEY_LOGIN_ASSERTION_CANCEL"

    .line 550
    .line 551
    new-instance v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 552
    .line 553
    move-object/from16 v0, v20

    .line 554
    .line 555
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 556
    .line 557
    .line 558
    sput-object v20, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_LOGIN_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 559
    .line 560
    const/16 v4, 0x26

    .line 561
    .line 562
    const-string v2, "security_key_assertion_triggered"

    .line 563
    .line 564
    const-string v1, "SECURITY_KEY_ASSERTION_TRIGGERED"

    .line 565
    .line 566
    new-instance v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 567
    .line 568
    move-object/from16 v0, v19

    .line 569
    .line 570
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 571
    .line 572
    .line 573
    sput-object v19, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_TRIGGERED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 574
    .line 575
    const/16 v4, 0x27

    .line 576
    .line 577
    const-string v2, "security_key_assertion_success"

    .line 578
    .line 579
    const-string v1, "SECURITY_KEY_ASSERTION_SUCCESS"

    .line 580
    .line 581
    new-instance v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 582
    .line 583
    move-object/from16 v0, v18

    .line 584
    .line 585
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 586
    .line 587
    .line 588
    sput-object v18, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 589
    .line 590
    const/16 v4, 0x28

    .line 591
    .line 592
    const-string v2, "security_key_assertion_cancel"

    .line 593
    .line 594
    const-string v1, "SECURITY_KEY_ASSERTION_CANCEL"

    .line 595
    .line 596
    new-instance v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 597
    .line 598
    move-object/from16 v0, v17

    .line 599
    .line 600
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 601
    .line 602
    .line 603
    sput-object v17, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_CANCEL:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 604
    .line 605
    const/16 v4, 0x29

    .line 606
    .line 607
    const-string v2, "security_key_assertion_failure"

    .line 608
    .line 609
    const-string v1, "SECURITY_KEY_ASSERTION_FAILURE"

    .line 610
    .line 611
    new-instance v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 612
    .line 613
    move-object/from16 v0, v16

    .line 614
    .line 615
    invoke-direct {v0, v1, v4, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 616
    .line 617
    .line 618
    sput-object v16, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SECURITY_KEY_ASSERTION_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 619
    .line 620
    const/16 v2, 0x2a

    .line 621
    .line 622
    const-string v1, "passkey_nux_shown"

    .line 623
    .line 624
    const-string v0, "PASSKEY_NUX_SHOWN"

    .line 625
    .line 626
    new-instance v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 627
    .line 628
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 629
    .line 630
    .line 631
    sput-object v14, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_SHOWN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 632
    .line 633
    const/16 v2, 0x2b

    .line 634
    .line 635
    const-string v1, "passkey_nux_continued"

    .line 636
    .line 637
    const-string v0, "PASSKEY_NUX_CONTINUED"

    .line 638
    .line 639
    new-instance v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 640
    .line 641
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 642
    .line 643
    .line 644
    sput-object v13, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_CONTINUED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 645
    .line 646
    const/16 v2, 0x2c

    .line 647
    .line 648
    const-string v1, "passkey_nux_cancelled"

    .line 649
    .line 650
    const-string v0, "PASSKEY_NUX_CANCELLED"

    .line 651
    .line 652
    new-instance v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 653
    .line 654
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 655
    .line 656
    .line 657
    sput-object v12, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSKEY_NUX_CANCELLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 658
    .line 659
    const/16 v2, 0x2d

    .line 660
    .line 661
    const-string v1, "remove_profile_clicked"

    .line 662
    .line 663
    const-string v0, "REMOVE_PROFILE_CLICKED"

    .line 664
    .line 665
    new-instance v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 666
    .line 667
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 668
    .line 669
    .line 670
    sput-object v11, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_CLICKED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 671
    .line 672
    const/16 v2, 0x2e

    .line 673
    .line 674
    const-string v1, "remove_profile_submitted"

    .line 675
    .line 676
    const-string v0, "REMOVE_PROFILE_SUBMITTED"

    .line 677
    .line 678
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 679
    .line 680
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 681
    .line 682
    .line 683
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_SUBMITTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 684
    .line 685
    const/16 v2, 0x2f

    .line 686
    .line 687
    const-string v1, "remove_profile_success"

    .line 688
    .line 689
    const-string v0, "REMOVE_PROFILE_SUCCESS"

    .line 690
    .line 691
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 692
    .line 693
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 694
    .line 695
    .line 696
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_SUCCESS:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 697
    .line 698
    const/16 v2, 0x30

    .line 699
    .line 700
    const-string v1, "remove_profile_failure"

    .line 701
    .line 702
    const-string v0, "REMOVE_PROFILE_FAILURE"

    .line 703
    .line 704
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 705
    .line 706
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 707
    .line 708
    .line 709
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->REMOVE_PROFILE_FAILURE:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 710
    .line 711
    const/16 v2, 0x31

    .line 712
    .line 713
    const-string v1, "password_saving_start"

    .line 714
    .line 715
    const-string v0, "PASSWORD_SAVING_START"

    .line 716
    .line 717
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 718
    .line 719
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 720
    .line 721
    .line 722
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_START:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 723
    .line 724
    const/16 v2, 0x32

    .line 725
    .line 726
    const-string v1, "password_saving_checkbox_toggled"

    .line 727
    .line 728
    const-string v0, "PASSWORD_SAVING_CHECKBOX_TOGGLED"

    .line 729
    .line 730
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 731
    .line 732
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 733
    .line 734
    .line 735
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_CHECKBOX_TOGGLED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 736
    .line 737
    const/16 v2, 0x33

    .line 738
    .line 739
    const-string v1, "password_saving_opt_in"

    .line 740
    .line 741
    const-string v0, "PASSWORD_SAVING_OPT_IN"

    .line 742
    .line 743
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 744
    .line 745
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 746
    .line 747
    .line 748
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_OPT_IN:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 749
    .line 750
    const/16 v0, 0x34

    .line 751
    .line 752
    const-string v2, "password_saving_opt_out"

    .line 753
    .line 754
    const-string v1, "PASSWORD_SAVING_OPT_OUT"

    .line 755
    .line 756
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 757
    .line 758
    invoke-direct {v4, v1, v0, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 759
    .line 760
    .line 761
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->PASSWORD_SAVING_OPT_OUT:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 762
    .line 763
    const/16 v2, 0x35

    .line 764
    .line 765
    const-string v1, "silent_auth_attempt_started"

    .line 766
    .line 767
    const-string v0, "SILENT_AUTH_ATTEMPT_STARTED"

    .line 768
    .line 769
    new-instance v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 770
    .line 771
    invoke-direct {v15, v0, v2, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 772
    .line 773
    .line 774
    sput-object v15, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->SILENT_AUTH_ATTEMPT_STARTED:Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 775
    .line 776
    const/16 v0, 0x36

    .line 777
    .line 778
    new-array v1, v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 779
    .line 780
    move-object/from16 v69, v43

    .line 781
    .line 782
    move-object/from16 v70, v42

    .line 783
    .line 784
    move-object/from16 v71, v41

    .line 785
    .line 786
    move-object/from16 v72, v40

    .line 787
    .line 788
    move-object/from16 v73, v39

    .line 789
    .line 790
    move-object/from16 v74, v38

    .line 791
    .line 792
    move-object/from16 v75, v37

    .line 793
    .line 794
    move-object/from16 v76, v36

    .line 795
    .line 796
    move-object/from16 v77, v35

    .line 797
    .line 798
    move-object/from16 v78, v34

    .line 799
    .line 800
    move-object/from16 v79, v33

    .line 801
    .line 802
    move-object/from16 v80, v32

    .line 803
    .line 804
    move-object/from16 v81, v31

    .line 805
    .line 806
    move-object/from16 v82, v3

    .line 807
    .line 808
    move-object/from16 v57, v55

    .line 809
    .line 810
    move-object/from16 v58, v54

    .line 811
    .line 812
    move-object/from16 v59, v53

    .line 813
    .line 814
    move-object/from16 v60, v52

    .line 815
    .line 816
    move-object/from16 v61, v51

    .line 817
    .line 818
    move-object/from16 v62, v50

    .line 819
    .line 820
    move-object/from16 v63, v49

    .line 821
    .line 822
    move-object/from16 v64, v48

    .line 823
    .line 824
    move-object/from16 v65, v47

    .line 825
    .line 826
    move-object/from16 v66, v46

    .line 827
    .line 828
    move-object/from16 v67, v45

    .line 829
    .line 830
    move-object/from16 v68, v44

    .line 831
    .line 832
    filled-new-array/range {v56 .. v82}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 833
    .line 834
    .line 835
    move-result-object v0

    .line 836
    const/4 v3, 0x0

    .line 837
    const/16 v2, 0x1b

    .line 838
    .line 839
    invoke-static {v0, v3, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 840
    .line 841
    .line 842
    move-object/from16 v31, v29

    .line 843
    .line 844
    move-object/from16 v32, v28

    .line 845
    .line 846
    move-object/from16 v33, v27

    .line 847
    .line 848
    move-object/from16 v34, v26

    .line 849
    .line 850
    move-object/from16 v35, v25

    .line 851
    .line 852
    move-object/from16 v36, v24

    .line 853
    .line 854
    move-object/from16 v37, v23

    .line 855
    .line 856
    move-object/from16 v38, v22

    .line 857
    .line 858
    move-object/from16 v39, v21

    .line 859
    .line 860
    move-object/from16 v40, v20

    .line 861
    .line 862
    move-object/from16 v41, v19

    .line 863
    .line 864
    move-object/from16 v42, v18

    .line 865
    .line 866
    move-object/from16 v43, v17

    .line 867
    .line 868
    move-object/from16 v44, v16

    .line 869
    .line 870
    move-object/from16 v45, v14

    .line 871
    .line 872
    move-object/from16 v46, v13

    .line 873
    .line 874
    move-object/from16 v47, v12

    .line 875
    .line 876
    move-object/from16 v48, v11

    .line 877
    .line 878
    move-object/from16 v49, v10

    .line 879
    .line 880
    move-object/from16 v50, v9

    .line 881
    .line 882
    move-object/from16 v51, v8

    .line 883
    .line 884
    move-object/from16 v52, v7

    .line 885
    .line 886
    move-object/from16 v53, v6

    .line 887
    .line 888
    move-object/from16 v54, v5

    .line 889
    .line 890
    move-object/from16 v55, v4

    .line 891
    .line 892
    move-object/from16 v56, v15

    .line 893
    .line 894
    filled-new-array/range {v30 .. v56}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 895
    .line 896
    .line 897
    move-result-object v0

    .line 898
    invoke-static {v0, v3, v1, v2, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 899
    .line 900
    .line 901
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 902
    .line 903
    new-instance v0, LX/DvM;

    .line 904
    .line 905
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 906
    .line 907
    .line 908
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->$ENTRIES:LX/0vk;

    .line 909
    .line 910
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaLoginEvent;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
