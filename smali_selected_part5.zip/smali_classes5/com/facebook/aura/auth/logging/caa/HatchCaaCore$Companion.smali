.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic create$default(Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;
    .locals 1

    .line 0
    and-int/lit8 v0, p8, 0x10

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 5
    .line 6
    .line 7
    move-result-object p5

    .line 8
    :cond_0
    and-int/lit8 v0, p8, 0x20

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    const/4 p6, 0x0

    .line 13
    :cond_1
    and-int/lit8 v0, p8, 0x40

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-object p7, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 24
    .line 25
    :cond_2
    invoke-virtual/range {p0 .. p7}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore$Companion;->create(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0
.end method


# virtual methods
.method public final create(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const-string v1, "is_native"

    .line 4
    .line 5
    const-string v0, "1"

    .line 6
    .line 7
    invoke-static {v1, v0, p5}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    if-eqz p6, :cond_0

    .line 12
    .line 13
    const-string v1, "error_type"

    .line 14
    .line 15
    invoke-virtual {p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountErrorType;->getValue()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    new-instance v2, LX/IBK;

    .line 20
    .line 21
    invoke-direct {v2, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    const-string v1, "error_type_source"

    .line 25
    .line 26
    const-string v0, "client_classification"

    .line 27
    .line 28
    invoke-static {v1, v0, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    :goto_0
    invoke-static {p0, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 33
    .line 34
    .line 35
    move-result-object p6

    .line 36
    new-instance p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;

    .line 37
    .line 38
    move-object p5, p7

    .line 39
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/logging/caa/HatchCaaCore;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 40
    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    goto :goto_0
.end method
