.class public abstract Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryLoggerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FLAG_SET:Ljava/lang/String; = "1"

.field public static final TAG:Ljava/lang/String; = "HatchCaaLogging"
