.class public final Lcom/facebook/aura/auth/logging/caa/HatchCaaErrorType;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ALREADY_LOADING:Ljava/lang/String; = "already_loading"

.field public static final ASSERTION_FAILED:Ljava/lang/String; = "assertion_failed"

.field public static final CANCELLED:Ljava/lang/String; = "cancelled"

.field public static final CHECKPOINT_REQUIRED:Ljava/lang/String; = "checkpointRequired"

.field public static final CREDENTIALS_UNAVAILABLE:Ljava/lang/String; = "credentials_unavailable"

.field public static final INCOMPLETE_CREDENTIALS:Ljava/lang/String; = "incomplete_credentials"

.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaErrorType;

.field public static final INVALID_BIRTHDAY_INPUT:Ljava/lang/String; = "invalid_birthday_input"

.field public static final LINKING_DISCLOSURE_REQUIRED:Ljava/lang/String; = "linking_disclosure_required"

.field public static final LINKING_DISCLOSURE_UNAVAILABLE:Ljava/lang/String; = "linking_disclosure_unavailable"

.field public static final LINKING_FAILED:Ljava/lang/String; = "linking_failed"

.field public static final LOGIN_REQUIRED:Ljava/lang/String; = "login_required"

.field public static final MALFORMED_RESPONSE:Ljava/lang/String; = "malformed_response"

.field public static final MISSING_COMPLETION_HANDLE:Ljava/lang/String; = "missing_completion_handle"

.field public static final NAME_REQUIRED:Ljava/lang/String; = "name_required"

.field public static final NTP_UPSELL:Ljava/lang/String; = "ntp_upsell"

.field public static final ONE_TAP_UNAVAILABLE:Ljava/lang/String; = "one_tap_unavailable"

.field public static final REACTIVATION_REQUIRED:Ljava/lang/String; = "reactivation_required"

.field public static final SECURITY_KEY_OPTIONS_LIMIT:Ljava/lang/String; = "security_key_options_limit"

.field public static final SELECTOR_UNPRESENTABLE:Ljava/lang/String; = "selector_unpresentable"

.field public static final SESSION_EXPIRED:Ljava/lang/String; = "SessionExpired"

.field public static final SUPERSEDED_ATTEMPT:Ljava/lang/String; = "superseded_attempt"

.field public static final TEMP_TOKEN_UNAVAILABLE:Ljava/lang/String; = "temp_token_unavailable"

.field public static final TRANSPORT_FAILURE:Ljava/lang/String; = "transport_failure"

.field public static final UNTYPED_API_ERROR:Ljava/lang/String; = "untyped_api_error"

.field public static final WRITE_FAILED:Ljava/lang/String; = "write_failed"

.field public static final ZARI_NOT_MATCHED:Ljava/lang/String; = "zari_not_matched"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaErrorType;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaErrorType;->INSTANCE:Lcom/facebook/aura/auth/logging/caa/HatchCaaErrorType;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
