.class public final enum Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum CHANGE_PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum CODE_ENTRY:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum INITIATE_VIEW:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum PASSWORD_FORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum SEARCH:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

.field public static final enum XAPP_AR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;


# instance fields
.field public final category:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 0
    const-string v3, "PASWORD_FORM"

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->LOGIN:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 3
    .line 4
    const-string v1, "PASSWORD_FORM"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-instance v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 8
    .line 9
    invoke-direct {v4, v1, v0, v3, v2}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 10
    .line 11
    .line 12
    sput-object v4, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->PASSWORD_FORM:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->SEARCH:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 16
    .line 17
    const-string v0, "SEARCH"

    .line 18
    .line 19
    new-instance v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 20
    .line 21
    invoke-direct {v5, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 22
    .line 23
    .line 24
    sput-object v5, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->SEARCH:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 25
    .line 26
    const/4 v2, 0x2

    .line 27
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->INITIATE_VIEW:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 28
    .line 29
    const-string v0, "INITIATE_VIEW"

    .line 30
    .line 31
    new-instance v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 32
    .line 33
    invoke-direct {v6, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 34
    .line 35
    .line 36
    sput-object v6, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->INITIATE_VIEW:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 37
    .line 38
    const/4 v2, 0x3

    .line 39
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->CODE_ENTRY:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 40
    .line 41
    const-string v0, "CODE_ENTRY"

    .line 42
    .line 43
    new-instance v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 44
    .line 45
    invoke-direct {v7, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 46
    .line 47
    .line 48
    sput-object v7, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->CODE_ENTRY:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 49
    .line 50
    const/4 v2, 0x4

    .line 51
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 52
    .line 53
    const-string v0, "ACCOUNT_SELECTOR"

    .line 54
    .line 55
    new-instance v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 56
    .line 57
    invoke-direct {v8, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 58
    .line 59
    .line 60
    sput-object v8, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->ACCOUNT_SELECTOR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 61
    .line 62
    const/4 v2, 0x5

    .line 63
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->CHANGE_PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 64
    .line 65
    const-string v0, "CHANGE_PASSWORD"

    .line 66
    .line 67
    new-instance v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 68
    .line 69
    invoke-direct {v9, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 70
    .line 71
    .line 72
    sput-object v9, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->CHANGE_PASSWORD:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 73
    .line 74
    const/4 v2, 0x6

    .line 75
    sget-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;->XAPP_AR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 76
    .line 77
    const-string v0, "XAPP_AR"

    .line 78
    .line 79
    new-instance v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 80
    .line 81
    invoke-direct {v10, v0, v2, v0, v1}, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;-><init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V

    .line 82
    .line 83
    .line 84
    sput-object v10, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->XAPP_AR:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 85
    .line 86
    filled-new-array/range {v4 .. v10}, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    sput-object v1, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 91
    .line 92
    new-instance v0, LX/DvM;

    .line 93
    .line 94
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 95
    .line 96
    .line 97
    sput-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->$ENTRIES:LX/0vk;

    .line 98
    .line 99
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->value:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->category:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->$VALUES:[Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getCategory()Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->category:Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventCategory;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/caa/HatchCaaAccountRecoveryEventStep;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
