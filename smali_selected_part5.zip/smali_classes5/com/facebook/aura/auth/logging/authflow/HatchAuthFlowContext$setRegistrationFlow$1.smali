.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $wireValue:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;->$wireValue:Ljava/lang/String;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 9

    .line 0
    move-object v0, p1

    .line 1
    invoke-static {p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;->$wireValue:Ljava/lang/String;

    .line 5
    .line 6
    const/16 p0, 0xfb

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    move-object v2, v1

    .line 10
    move-object v4, v1

    .line 11
    move-object v5, v1

    .line 12
    move-object v6, v1

    .line 13
    move-object v7, v1

    .line 14
    move-object v8, v1

    .line 15
    move-object p1, v1

    .line 16
    invoke-static/range {v0 .. v10}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->copy$default(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
