.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 8

    .line 0
    move-object v1, p1

    .line 1
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const/4 v3, 0x0

    .line 14
    new-instance v1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 15
    .line 16
    move-object v4, v3

    .line 17
    move-object v5, v3

    .line 18
    move-object v6, v3

    .line 19
    move-object v7, v3

    .line 20
    move-object p0, v3

    .line 21
    move-object p1, v3

    .line 22
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-object v1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
