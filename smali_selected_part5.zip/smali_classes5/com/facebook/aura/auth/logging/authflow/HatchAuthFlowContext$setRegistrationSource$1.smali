.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $wireValue:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;->$wireValue:Ljava/lang/String;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 10

    .line 0
    move-object v1, p1

    .line 1
    invoke-static {p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object v5, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;->$wireValue:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v5, :cond_0

    .line 8
    .line 9
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    :cond_0
    move-object v5, v2

    .line 16
    :cond_1
    const/16 p0, 0xf7

    .line 17
    .line 18
    move-object v3, v2

    .line 19
    move-object v4, v2

    .line 20
    move-object v6, v2

    .line 21
    move-object v7, v2

    .line 22
    move-object v8, v2

    .line 23
    move-object v9, v2

    .line 24
    move-object p1, v2

    .line 25
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->copy$default(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
