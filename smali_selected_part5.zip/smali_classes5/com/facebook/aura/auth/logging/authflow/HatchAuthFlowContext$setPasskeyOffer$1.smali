.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $route:Ljava/lang/String;

.field public final synthetic $surface:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;->$route:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;->$surface:Ljava/lang/String;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 8

    .line 0
    invoke-static {p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v7, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;->$route:Ljava/lang/String;

    .line 4
    .line 5
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;->$surface:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v1, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v2, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v3, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v4, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v5, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 16
    .line 17
    iget-object v6, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 20
    .line 21
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
