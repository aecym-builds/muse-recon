.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 7

    .line 0
    invoke-static {p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    iget-object v1, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v2, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v3, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v4, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v5, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v6, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 17
    .line 18
    move-object p1, p0

    .line 19
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
