.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/function/UnaryOperator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/function/UnaryOperator;"
    }
.end annotation


# instance fields
.field public final synthetic $entryPoint:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;->$entryPoint:Ljava/lang/String;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 7

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    if-nez v1, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;->$entryPoint:Ljava/lang/String;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v2, :cond_1

    .line 16
    .line 17
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    :cond_1
    move-object v2, v3

    .line 24
    :cond_2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 25
    .line 26
    move-object v4, v3

    .line 27
    move-object v5, v3

    .line 28
    move-object v6, v3

    .line 29
    move-object p0, v3

    .line 30
    move-object p1, v3

    .line 31
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return-object v0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;->apply(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
