.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

.field public static final landingImpressionWaterfallId:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final state:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    new-instance v1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 9
    .line 10
    move-object v3, v2

    .line 11
    move-object v4, v2

    .line 12
    move-object v5, v2

    .line 13
    move-object v6, v2

    .line 14
    move-object v7, v2

    .line 15
    move-object v8, v2

    .line 16
    move-object v9, v2

    .line 17
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 26
    .line 27
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 30
    .line 31
    .line 32
    sput-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->landingImpressionWaterfallId:Ljava/util/concurrent/atomic/AtomicReference;

    .line 33
    .line 34
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic setLoginFlow$default(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->setLoginFlow(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final adoptOrBeginFlow(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$adoptOrBeginFlow$1;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final beginPrefetchFlow()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$beginPrefetchFlow$1;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final claimLandingImpression()Z
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 7
    .line 8
    iget-object p0, v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 9
    .line 10
    if-nez p0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return v0

    .line 14
    :cond_0
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->landingImpressionWaterfallId:Ljava/util/concurrent/atomic/AtomicReference;

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    xor-int/lit8 v0, v0, 0x1

    .line 25
    .line 26
    return v0
.end method

.method public final clearPasskeyOffer()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;->INSTANCE:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$clearPasskeyOffer$1;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final endFlow()V
    .locals 9

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    new-instance v1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 4
    .line 5
    move-object v3, v2

    .line 6
    move-object v4, v2

    .line 7
    move-object v5, v2

    .line 8
    move-object v6, v2

    .line 9
    move-object v7, v2

    .line 10
    move-object v8, v2

    .line 11
    move-object p0, v2

    .line 12
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final releaseLandingImpression()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->landingImpressionWaterfallId:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final setEntryPoint(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setEntryPoint$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setEntryPoint$1;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final setLoginFlow(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setLoginFlow$1;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setLoginFlow$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final setPasskeyOffer(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;

    .line 6
    .line 7
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setPasskeyOffer$1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final setRegistrationFlow(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationFlow$1;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final setRegistrationSource(Ljava/lang/String;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$setRegistrationSource$1;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final snapshot()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext;->state:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    check-cast p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 10
    .line 11
    return-object p0
.end method
