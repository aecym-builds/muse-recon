.class public final Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
.super LX/07H;
.source ""


# instance fields
.field public final entryPoint:Ljava/lang/String;

.field public final landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

.field public final loginFlow:Ljava/lang/String;

.field public final passkeyLoginRoute:Ljava/lang/String;

.field public final passkeyOfferSurface:Ljava/lang/String;

.field public final registrationFlow:Ljava/lang/String;

.field public final registrationSource:Ljava/lang/String;

.field public final waterfallId:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 8

    .line 536870912
    const/4 v1, 0x0

    .line 536870913
    move-object v0, p0

    .line 536870914
    move-object v2, v1

    .line 536870915
    move-object v3, v1

    .line 536870916
    move-object v4, v1

    .line 536870917
    move-object v5, v1

    .line 536870918
    move-object v6, v1

    .line 536870919
    move-object v7, v1

    .line 536870920
    move-object p0, v1

    .line 536870921
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 536870922
    .line 536870923
    .line 536870924
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p5, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p6, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 14
    .line 15
    iput-object p7, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 16
    .line 17
    iput-object p8, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 18
    .line 19
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p9, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 268435478
    .line 268435479
    if-eqz v0, :cond_4

    .line 268435480
    .line 268435481
    move-object p5, v1

    .line 268435482
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 268435483
    .line 268435484
    if-eqz v0, :cond_5

    .line 268435485
    .line 268435486
    move-object p6, v1

    .line 268435487
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 268435488
    .line 268435489
    if-eqz v0, :cond_6

    .line 268435490
    .line 268435491
    move-object p7, v1

    .line 268435492
    :cond_6
    and-int/lit16 v0, p9, 0x80

    .line 268435493
    .line 268435494
    if-eqz v0, :cond_7

    .line 268435495
    .line 268435496
    move-object p8, v1

    .line 268435497
    :cond_7
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435498
    .line 268435499
    .line 268435500
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 10

    .line 0
    move-object v2, p1

    .line 1
    move-object v3, p2

    .line 2
    move-object v4, p3

    .line 3
    move-object v5, p4

    .line 4
    move-object v6, p5

    .line 5
    move-object/from16 v7, p6

    .line 6
    .line 7
    move-object/from16 v8, p7

    .line 8
    .line 9
    move-object/from16 v9, p8

    .line 10
    .line 11
    move/from16 v1, p9

    .line 12
    .line 13
    and-int/lit8 v0, p9, 0x1

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 18
    .line 19
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 24
    .line 25
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 26
    .line 27
    if-eqz v0, :cond_2

    .line 28
    .line 29
    iget-object v4, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 30
    .line 31
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 32
    .line 33
    if-eqz v0, :cond_3

    .line 34
    .line 35
    iget-object v5, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 36
    .line 37
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 38
    .line 39
    if-eqz v0, :cond_4

    .line 40
    .line 41
    iget-object v6, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 42
    .line 43
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 44
    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    iget-object v7, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 48
    .line 49
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 50
    .line 51
    if-eqz v0, :cond_6

    .line 52
    .line 53
    iget-object v8, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 54
    .line 55
    :cond_6
    and-int/lit16 v0, v1, 0x80

    .line 56
    .line 57
    if-eqz v0, :cond_7

    .line 58
    .line 59
    iget-object v9, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 60
    .line 61
    :cond_7
    new-instance v1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 62
    .line 63
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    return-object v1
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_1

    .line 89
    .line 90
    :cond_0
    return v2

    .line 91
    :cond_1
    return v3
.end method

.method public final getEntryPoint()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLandingSsoSource()Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoginFlow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPasskeyLoginRoute()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPasskeyOfferSurface()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRegistrationFlow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRegistrationSource()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getWaterfallId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->waterfallId:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->entryPoint:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationFlow:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->registrationSource:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->loginFlow:Ljava/lang/String;

    .line 37
    .line 38
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v1, v0

    .line 43
    mul-int/lit8 v1, v1, 0x1f

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->landingSsoSource:Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$SsoSourceCounts;

    .line 46
    .line 47
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    add-int/2addr v1, v0

    .line 52
    mul-int/lit8 v1, v1, 0x1f

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyLoginRoute:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    add-int/2addr v1, v0

    .line 61
    mul-int/lit8 v1, v1, 0x1f

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/authflow/HatchAuthFlowContext$State;->passkeyOfferSurface:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_0

    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    :cond_0
    add-int/2addr v1, v2

    .line 72
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
