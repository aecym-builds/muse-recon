.class public Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry$Companion;

.field public static final SILENT_AUTH_REASON_CANCELLED:Ljava/lang/String; = "cancelled"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final SILENT_AUTH_REASON_CARRIER_ERROR:Ljava/lang/String; = "carrier_error"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final TAG:Ljava/lang/String; = "HatchSilentAuthAttemptTelemetry"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final joinId:Ljava/lang/String;

.field public trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

.field public final useCase:LX/DYK;

.field public final waterfallId:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->Companion:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;LX/DYK;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 10
    .line 11
    invoke-static {}, LX/Ffc;->A00()Ljava/util/UUID;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->joinId:Ljava/lang/String;

    .line 20
    .line 21
    return-void
.end method

.method private final guarded(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    :try_start_0
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    :catch_0
    invoke-static {p1}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public attemptCancelled()V
    .locals 5

    .line 0
    :try_start_0
    sget-object v4, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 1
    .line 2
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 5
    .line 6
    const-string v1, "cancelled"

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v4, v3, v2, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestFailure(Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->cancel()V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :catch_0
    const-string v0, "attempt_cancelled"

    .line 26
    .line 27
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public attemptErrored()V
    .locals 5

    .line 0
    :try_start_0
    sget-object v4, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 1
    .line 2
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 5
    .line 6
    const-string v1, "carrier_error"

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v4, v3, v2, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestFailure(Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestFailed(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 25
    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->failWithoutResultPost()V

    .line 29
    .line 30
    .line 31
    :cond_1
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    :catch_0
    const-string v0, "attempt_errored"

    .line 33
    .line 34
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public beforeResultRequest()V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->beforeResultRequestSent()V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 8
    :catch_0
    const-string p0, "before_result_request"

    .line 9
    .line 10
    invoke-static {p0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public carrierLegCaught()V
    .locals 4

    .line 0
    :try_start_0
    sget-object v3, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestCompleted(Ljava/lang/String;LX/DYK;LX/ES4;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestSucceeded()V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    :catch_0
    const-string v0, "carrier_leg_caught"

    .line 24
    .line 25
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public clientFailure(Ljava/lang/String;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    sget-object v3, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 5
    .line 6
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v3, v2, v1, p1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestFailure(Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestFailed(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    :catch_0
    const-string v0, "client_failure"

    .line 28
    .line 29
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final getJoinId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->joinId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public resultPostCancelled()V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->cancel()V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 8
    :catch_0
    const-string p0, "result_post_cancelled"

    .line 9
    .line 10
    invoke-static {p0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public resultPostSettled(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthResultPost;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->resultPostSettled(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthResultPost;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    :catch_0
    const-string v0, "result_post_settled"

    .line 13
    .line 14
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public started()V
    .locals 5

    .line 0
    :try_start_0
    sget-object v3, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestStart(Ljava/lang/String;LX/DYK;LX/ES4;)V

    .line 13
    .line 14
    .line 15
    sget-object v4, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQpl;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQpl;

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->useCase:LX/DYK;

    .line 18
    .line 19
    iget-object v3, v0, LX/DYK;->mValue:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v3}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->joinId:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->waterfallId:Ljava/lang/String;

    .line 27
    .line 28
    sget-object v0, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->INSTANCE:Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;

    .line 29
    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->getInstance()Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v4, v3, v2, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQpl;->startAttempt(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/quicklog/QuickPerformanceLogger;)Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestStarted()V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthAttemptTelemetry;->trace:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;

    .line 42
    .line 43
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    :catch_0
    const-string v0, "started"

    .line 45
    .line 46
    invoke-static {v0}, LX/Bi9;->A0G(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    return-void
.end method
