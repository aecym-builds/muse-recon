.class public final Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final EXTRA_REASON:Ljava/lang/String; = "reason"

.field public static final INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

.field public static final TAG:Ljava/lang/String; = "HatchSilentAuthLogger"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->INSTANCE:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final extraInfoFor(Ljava/lang/String;)Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0

    .line 7
    :cond_0
    const-string p0, "reason"

    .line 8
    .line 9
    invoke-static {p0, p1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method private final log(LX/DYN;Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DYN;",
            "Ljava/lang/String;",
            "LX/DYK;",
            "Ljava/lang/String;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    :try_start_0
    sget-object v1, LX/EXf;->A02:LX/EXf;

    .line 1
    .line 2
    const-string v0, "silent_auth_client_events"

    .line 3
    .line 4
    invoke-interface {p5, v0, v1}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-interface {v2}, LX/I2T;->isSampled()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    sget-object v1, LX/E3p;->A01:LX/E3p;

    .line 15
    .line 16
    const-string v0, "universe"

    .line 17
    .line 18
    invoke-interface {v2, v1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "event"

    .line 22
    .line 23
    invoke-interface {v2, p1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v0, "waterfall_id"

    .line 27
    .line 28
    invoke-interface {v2, v0, p2}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    sget-object v1, LX/END;->A01:LX/END;

    .line 32
    .line 33
    const-string v0, "phase"

    .line 34
    .line 35
    invoke-interface {v2, v1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-direct {p0, p4}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->extraInfoFor(Ljava/lang/String;)Ljava/util/Map;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const-string v0, "extra_info"

    .line 43
    .line 44
    invoke-interface {v2, v0, v1}, LX/I2T;->A3g(Ljava/lang/String;Ljava/util/Map;)V

    .line 45
    .line 46
    .line 47
    const-string v0, "usecase"

    .line 48
    .line 49
    invoke-interface {v2, p3, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    invoke-interface {v2}, LX/I2T;->AQ5()V

    .line 53
    .line 54
    .line 55
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    :catch_0
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    const-string v1, "HatchSilentAuthLogger"

    .line 65
    .line 66
    const-string v0, "failed to log %s"

    .line 67
    .line 68
    invoke-static {v1, v0, v2}, LX/FnY;->A0F(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public static synthetic logProviderRequestCompleted$default(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;Ljava/lang/String;LX/DYK;LX/ES4;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object p3

    .line 10
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestCompleted(Ljava/lang/String;LX/DYK;LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic logProviderRequestFailure$default(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object p4

    .line 10
    :cond_0
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestFailure(Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic logProviderRequestStart$default(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;Ljava/lang/String;LX/DYK;LX/ES4;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object p3

    .line 10
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->logProviderRequestStart(Ljava/lang/String;LX/DYK;LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final logProviderRequestCompleted(Ljava/lang/String;LX/DYK;LX/ES4;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/DYK;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object v3, p2

    .line 1
    move-object v5, p3

    .line 2
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v1, LX/DYN;->A01:LX/DYN;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->log(LX/DYN;Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final logProviderRequestFailure(Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/DYK;",
            "Ljava/lang/String;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object v3, p2

    .line 2
    move-object v4, p3

    .line 3
    move-object v5, p4

    .line 4
    invoke-static {p2, p3, p4, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    sget-object v1, LX/DYN;->A02:LX/DYN;

    .line 8
    .line 9
    move-object v0, p0

    .line 10
    move-object v2, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->log(LX/DYN;Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final logProviderRequestStart(Ljava/lang/String;LX/DYK;LX/ES4;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/DYK;",
            "LX/ES4<",
            "LX/EXf;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object v3, p2

    .line 1
    move-object v5, p3

    .line 2
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v1, LX/DYN;->A03:LX/DYN;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthLogger;->log(LX/DYN;Ljava/lang/String;LX/DYK;Ljava/lang/String;LX/ES4;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
