.class public final Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final ANNOTATION_ERROR:Ljava/lang/String; = "error"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final ANNOTATION_TOKEN_REQUEST_FAIL_REASON:Ljava/lang/String; = "client_token_request_fail_reason"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace$Companion;

.field public static final ERROR_RESULT_ERROR_RESPONSE:Ljava/lang/String; = "result_error_response"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final ERROR_RESULT_NO_RESPONSE:Ljava/lang/String; = "result_no_response"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final POINT_TOKEN_REQUEST_FAIL:Ljava/lang/String; = "client_token_request_fail"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final POINT_TOKEN_REQUEST_START:Ljava/lang/String; = "client_token_request_start"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final POINT_TOKEN_REQUEST_SUCCESS:Ljava/lang/String; = "client_token_request_success"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final instanceKey:I

.field public final markerId:I

.field public final qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

.field public final settled:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final tokenRequestFailed:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->Companion:Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Lcom/facebook/quicklog/QuickPerformanceLogger;II)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 10
    .line 11
    iput p3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 12
    .line 13
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->settled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 21
    .line 22
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestFailed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 26
    .line 27
    return-void
.end method

.method private final alignmentPoint(LX/DYB;)V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->settled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 9
    .line 10
    iget v3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 11
    .line 12
    iget v4, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 13
    .line 14
    const-string v1, "default_id"

    .line 15
    .line 16
    sget-object p0, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    .line 17
    .line 18
    const-wide/16 v6, -0x1

    .line 19
    .line 20
    invoke-static {v2, p1}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p1, LX/DYB;->alignmentPointNamePrefix:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    invoke-interface/range {v2 .. v8}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerPoint(IILjava/lang/String;JLjava/util/concurrent/TimeUnit;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void
.end method

.method private final end(SLX/IBK;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(S",
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->settled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-static {v0}, LX/8mk;->A1a(Ljava/util/concurrent/atomic/AtomicBoolean;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-eqz p2, :cond_0

    .line 9
    .line 10
    iget-object v4, p2, LX/IBK;->first:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v4, Ljava/lang/String;

    .line 13
    .line 14
    iget-object v3, p2, LX/IBK;->second:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v3, Ljava/lang/String;

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 19
    .line 20
    iget v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 21
    .line 22
    iget v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 23
    .line 24
    invoke-interface {v2, v1, v0, v4, v3}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerAnnotate(IILjava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 28
    .line 29
    iget v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 30
    .line 31
    iget v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 32
    .line 33
    invoke-interface {v2, v1, v0, p1}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerEnd(IIS)V

    .line 34
    .line 35
    .line 36
    :cond_1
    return-void
.end method

.method private final point(Ljava/lang/String;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->settled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 11
    .line 12
    iget v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 13
    .line 14
    invoke-interface {v2, v1, v0, p1}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerPoint(IILjava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method


# virtual methods
.method public final beforeResultRequestSent()V
    .locals 1

    .line 0
    sget-object v0, LX/DYB;->A03:LX/DYB;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->alignmentPoint(LX/DYB;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final cancel()V
    .locals 2

    .line 0
    const/4 v1, 0x4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->end(SLX/IBK;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final failWithoutResultPost()V
    .locals 2

    .line 0
    const/4 v1, 0x3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->end(SLX/IBK;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final resultPostSettled(Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthResultPost;)V
    .locals 5

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 5
    .line 6
    .line 7
    move-result v4

    .line 8
    const/4 v1, 0x2

    .line 9
    const/4 v0, 0x1

    .line 10
    const/4 v3, 0x3

    .line 11
    if-eq v4, v2, :cond_2

    .line 12
    .line 13
    const-string v2, "error"

    .line 14
    .line 15
    if-eq v4, v0, :cond_0

    .line 16
    .line 17
    if-ne v4, v1, :cond_1

    .line 18
    .line 19
    const-string v1, "result_no_response"

    .line 20
    .line 21
    :goto_0
    new-instance v0, LX/IBK;

    .line 22
    .line 23
    invoke-direct {v0, v2, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p0, v3, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->end(SLX/IBK;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    const-string v1, "result_error_response"

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 34
    .line 35
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 36
    .line 37
    .line 38
    throw v0

    .line 39
    :cond_2
    sget-object v0, LX/DYB;->A02:LX/DYB;

    .line 40
    .line 41
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->alignmentPoint(LX/DYB;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestFailed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    const/4 v1, 0x3

    .line 53
    :cond_3
    const/4 v0, 0x0

    .line 54
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->end(SLX/IBK;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final tokenRequestFailed(Ljava/lang/String;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->settled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->tokenRequestFailed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 16
    .line 17
    .line 18
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 19
    .line 20
    iget v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 21
    .line 22
    iget v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 23
    .line 24
    const-string v0, "client_token_request_fail"

    .line 25
    .line 26
    invoke-interface {v3, v2, v1, v0}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerPoint(IILjava/lang/String;)V

    .line 27
    .line 28
    .line 29
    iget-object v3, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->qpl:Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 30
    .line 31
    iget v2, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->markerId:I

    .line 32
    .line 33
    iget v1, p0, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->instanceKey:I

    .line 34
    .line 35
    const-string v0, "client_token_request_fail_reason"

    .line 36
    .line 37
    invoke-interface {v3, v2, v1, v0, p1}, Lcom/facebook/quicklog/QuickPerformanceLogger;->markerAnnotate(IILjava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    return-void
.end method

.method public final tokenRequestStarted()V
    .locals 1

    .line 0
    const-string v0, "client_token_request_start"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->point(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final tokenRequestSucceeded()V
    .locals 1

    .line 0
    const-string v0, "client_token_request_success"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/logging/silentauth/HatchSilentAuthQplTrace;->point(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
