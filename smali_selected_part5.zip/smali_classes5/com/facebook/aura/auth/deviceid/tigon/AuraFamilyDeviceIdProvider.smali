.class public final Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/IXu;


# static fields
.field public static final Companion:Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider$Companion;

.field public static final HEADER_NAME:Ljava/lang/String; = "X-FB-Family-Device-Id"


# instance fields
.field public final headerName:Ljava/lang/String;

.field public final isEnabled:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;->Companion:Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    iput-boolean v0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;->isEnabled:Z

    .line 5
    .line 6
    const-string v0, "X-FB-Family-Device-Id"

    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;->headerName:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public getHeaderName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;->headerName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getHeaderValue()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->get()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 9
    .line 10
    invoke-static {v0}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    return-object v0
.end method

.method public isEnabled()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraFamilyDeviceIdProvider;->isEnabled:Z

    .line 1
    .line 2
    return p0
.end method
