.class public final Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/HatchAttestationDeviceId;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/AuraDeviceId;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->get()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
