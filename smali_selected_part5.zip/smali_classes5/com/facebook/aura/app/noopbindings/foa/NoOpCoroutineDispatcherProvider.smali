.class public final Lcom/facebook/aura/app/noopbindings/foa/NoOpCoroutineDispatcherProvider;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpCoroutineDispatcherProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpCoroutineDispatcherProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpCoroutineDispatcherProvider;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpCoroutineDispatcherProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public background(LX/0QC;)LX/BqD;
    .locals 0

    .line 0
    sget-object p0, LX/DSW;->A00:LX/DSG;

    .line 1
    .line 2
    return-object p0
.end method

.method public io(LX/0QC;)LX/BqD;
    .locals 0

    .line 0
    sget-object p0, LX/DSW;->A00:LX/DSG;

    .line 1
    .line 2
    sget-object p0, LX/DSs;->A01:LX/DSs;

    .line 3
    .line 4
    return-object p0
.end method

.method public main()LX/BqD;
    .locals 0

    .line 0
    sget-object p0, LX/DSW;->A00:LX/DSG;

    .line 1
    .line 2
    sget-object p0, LX/3AA;->A00:LX/DSR;

    .line 3
    .line 4
    return-object p0
.end method
