.class public final Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideSessionScopedLogger$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/ES4;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/ES4<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public acquireEvent(Ljava/lang/String;)LX/I2T;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "LX/I2T<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    .line 268435456
    new-instance p0, LX/CP7;

    .line 268435457
    .line 268435458
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435459
    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public bridge synthetic acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;
    .locals 0

    .line 0
    new-instance p0, LX/CP7;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public acquireEvent(Ljava/lang/String;Ljava/lang/Void;)LX/I2T;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Void;",
            ")",
            "LX/I2T<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    .line 536870912
    new-instance p0, LX/CP7;

    .line 536870913
    .line 536870914
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870915
    .line 536870916
    .line 536870917
    return-object p0
.end method
