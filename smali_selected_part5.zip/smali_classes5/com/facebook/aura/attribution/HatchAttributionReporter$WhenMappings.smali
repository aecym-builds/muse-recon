.class public abstract synthetic Lcom/facebook/aura/attribution/HatchAttributionReporter$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    invoke-static {}, LX/ECD;->values()[LX/ECD;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v2, v0, [I

    .line 6
    .line 7
    :try_start_0
    const/4 v1, 0x0

    .line 8
    const/4 v0, 0x1

    .line 9
    aput v0, v2, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    :catch_0
    :try_start_1
    const/4 v1, 0x1

    .line 12
    const/4 v0, 0x2

    .line 13
    aput v0, v2, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 14
    .line 15
    :catch_1
    :try_start_2
    const/4 v0, 0x3

    .line 16
    aput v0, v2, v0
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 17
    .line 18
    :catch_2
    :try_start_3
    const/4 v1, 0x5

    .line 19
    const/4 v0, 0x4

    .line 20
    aput v0, v2, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 21
    .line 22
    :catch_3
    sput-object v2, Lcom/facebook/aura/attribution/HatchAttributionReporter$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 23
    .line 24
    return-void
.end method
