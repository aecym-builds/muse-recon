.class public interface abstract Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getStatus()Ljava/lang/String;
.end method
