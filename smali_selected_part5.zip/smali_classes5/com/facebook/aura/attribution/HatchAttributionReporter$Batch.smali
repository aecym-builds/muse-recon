.class public final Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final events:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/ECD;",
            ">;"
        }
    .end annotation
.end field

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "Ljava/util/List<",
            "+",
            "LX/ECD;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->events:Ljava/util/List;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getEvents()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LX/ECD;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->events:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUserSession()LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method
