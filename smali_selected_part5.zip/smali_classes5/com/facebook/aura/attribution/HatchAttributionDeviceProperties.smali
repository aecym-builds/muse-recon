.class public final Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final adid:Ljava/lang/String;

.field public final includeFamilyDeviceId:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->adid:Ljava/lang/String;

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->includeFamilyDeviceId:Z

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public getAdvertisingId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->adid:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getFamilyDeviceId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->includeFamilyDeviceId:Z

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->get()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public getSideLoadingId()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method
