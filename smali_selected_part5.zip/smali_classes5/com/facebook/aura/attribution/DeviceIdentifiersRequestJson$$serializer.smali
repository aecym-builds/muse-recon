.class public final synthetic Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->INSTANCE:Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.attribution.DeviceIdentifiersRequestJson"

    .line 10
    .line 11
    new-instance v2, LX/DZp;

    .line 12
    .line 13
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "client_time_ms"

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "log_reason"

    .line 23
    .line 24
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "suppressed_count"

    .line 28
    .line 29
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "auth_type"

    .line 33
    .line 34
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "app_install_id"

    .line 38
    .line 39
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "advertising_id"

    .line 43
    .line 44
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    const-string v0, "advertising_id_status"

    .line 48
    .line 49
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    const-string v0, "family_device_id"

    .line 53
    .line 54
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    sput-object v2, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->descriptor:LX/Da5;

    .line 58
    .line 59
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, LX/DZ1;->A00:LX/DZ1;

    .line 1
    .line 2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 3
    .line 4
    sget-object v2, LX/DYo;->A00:LX/DYo;

    .line 5
    .line 6
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    move-object v4, v1

    .line 19
    move-object v6, v1

    .line 20
    filled-new-array/range {v0 .. v7}, [LX/DZ7;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;
    .locals 19

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v4}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    const/4 v9, 0x7

    .line 13
    const/4 v8, 0x6

    .line 14
    const/4 v7, 0x5

    .line 15
    const/4 v6, 0x3

    .line 16
    const/4 v2, 0x4

    .line 17
    const/4 v1, 0x2

    .line 18
    const/4 v15, 0x0

    .line 19
    move-object/from16 p0, v15

    .line 20
    .line 21
    move-object/from16 v16, v15

    .line 22
    .line 23
    move-object/from16 v17, v15

    .line 24
    .line 25
    move-object/from16 v18, v15

    .line 26
    .line 27
    const-wide/16 v11, 0x0

    .line 28
    .line 29
    const/4 v14, 0x0

    .line 30
    move-object v13, v15

    .line 31
    const/4 v10, 0x0

    .line 32
    :goto_0
    invoke-interface {v3, v4}, LX/Da7;->A8S(LX/Da5;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    packed-switch v0, :pswitch_data_0

    .line 37
    .line 38
    .line 39
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 40
    .line 41
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 42
    .line 43
    .line 44
    throw v1

    .line 45
    :pswitch_0
    invoke-interface {v3, v4, v5}, LX/Da7;->A8c(LX/Da5;I)J

    .line 46
    .line 47
    .line 48
    move-result-wide v11

    .line 49
    or-int/lit8 v10, v10, 0x1

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :pswitch_1
    const/4 v0, 0x1

    .line 53
    invoke-interface {v3, v4, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v13

    .line 57
    or-int/lit8 v10, v10, 0x2

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :pswitch_2
    invoke-interface {v3, v4, v1}, LX/Da7;->A8Z(LX/Da5;I)I

    .line 61
    .line 62
    .line 63
    move-result v14

    .line 64
    or-int/lit8 v10, v10, 0x4

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :pswitch_3
    invoke-static {v4, v3, v6}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v15

    .line 71
    or-int/lit8 v10, v10, 0x8

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :pswitch_4
    invoke-interface {v3, v4, v2}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v16

    .line 78
    or-int/lit8 v10, v10, 0x10

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :pswitch_5
    invoke-static {v4, v3, v7}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v17

    .line 85
    or-int/lit8 v10, v10, 0x20

    .line 86
    .line 87
    goto :goto_0

    .line 88
    :pswitch_6
    invoke-interface {v3, v4, v8}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v18

    .line 92
    or-int/lit8 v10, v10, 0x40

    .line 93
    .line 94
    goto :goto_0

    .line 95
    :pswitch_7
    invoke-static {v4, v3, v9}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    or-int/lit16 v10, v10, 0x80

    .line 100
    .line 101
    goto :goto_0

    .line 102
    :pswitch_8
    invoke-interface {v3, v4}, LX/Da7;->AAi(LX/Da5;)V

    .line 103
    .line 104
    .line 105
    const/16 p1, 0x0

    .line 106
    .line 107
    new-instance v9, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 108
    .line 109
    invoke-direct/range {v9 .. v20}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;-><init>(IJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 110
    .line 111
    .line 112
    return-object v9

    .line 113
    nop

    .line 114
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_8
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_attribution_attribution(Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
