.class public final Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;->$batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, Ljava/lang/Boolean;

    .line 1
    .line 2
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, v0}, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;->invoke(Z)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 2

    .line 268435456
    sget-object v1, Lcom/facebook/aura/attribution/HatchAttributionReporter;->INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionReporter;

    .line 268435457
    .line 268435458
    iget-object v0, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;->$batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 268435459
    .line 268435460
    invoke-static {v1, v0, p1}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->access$onSettled(Lcom/facebook/aura/attribution/HatchAttributionReporter;Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method
