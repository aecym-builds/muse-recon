.class public abstract Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final attributionFailureMessage(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    instance-of v0, p0, Lcom/facebook/aura/json/NetworkException;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p0, Lcom/facebook/aura/json/NetworkException;

    .line 9
    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    iget p0, p0, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 13
    .line 14
    :goto_0
    const-string v0, "HTTP "

    .line 15
    .line 16
    invoke-static {v0, p0}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0

    .line 21
    :cond_0
    const/4 p0, -0x1

    .line 22
    goto :goto_0
.end method

.method public static final logAttributionFailure(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 3

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/json/NetworkException;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    move-object v0, p1

    .line 8
    check-cast v0, Lcom/facebook/aura/json/NetworkException;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget v1, v0, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 13
    .line 14
    :goto_0
    const/16 v0, 0x190

    .line 15
    .line 16
    const-string v2, "HatchAttribution"

    .line 17
    .line 18
    if-gt v0, v1, :cond_1

    .line 19
    .line 20
    const/16 v0, 0x1f4

    .line 21
    .line 22
    if-ge v1, v0, :cond_1

    .line 23
    .line 24
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    filled-new-array {p0, v0}, [Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const-string v0, "%s rejected the request (HTTP %d)"

    .line 33
    .line 34
    invoke-static {v2, v0, p1, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    const/4 v1, -0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    filled-new-array {p0, v0}, [Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    const-string v0, "%s failed (HTTP %d)"

    .line 49
    .line 50
    invoke-static {v2, v0, p1, v1}, LX/FnY;->A0D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method
