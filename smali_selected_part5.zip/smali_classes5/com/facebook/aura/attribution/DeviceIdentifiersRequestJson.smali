.class public final Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$Companion;


# instance fields
.field public final advertising_id:Ljava/lang/String;

.field public final advertising_id_status:Ljava/lang/String;

.field public final app_install_id:Ljava/lang/String;

.field public final auth_type:Ljava/lang/String;

.field public final client_time_ms:J

.field public final family_device_id:Ljava/lang/String;

.field public final log_reason:Ljava/lang/String;

.field public final suppressed_count:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->Companion:Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(IJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 268435456
    and-int/lit16 v0, p1, 0xff

    .line 268435457
    .line 268435458
    const/16 v1, 0xff

    .line 268435459
    .line 268435460
    if-eq v1, v0, :cond_0

    .line 268435461
    .line 268435462
    sget-object v0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson$$serializer;->descriptor:LX/Da5;

    .line 268435463
    .line 268435464
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 268435465
    .line 268435466
    .line 268435467
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    throw v0

    .line 268435472
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435473
    .line 268435474
    .line 268435475
    iput-wide p2, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 268435476
    .line 268435477
    iput-object p4, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 268435478
    .line 268435479
    iput p5, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 268435480
    .line 268435481
    iput-object p6, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 268435482
    .line 268435483
    iput-object p7, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 268435484
    .line 268435485
    iput-object p8, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 268435486
    .line 268435487
    iput-object p9, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 268435488
    .line 268435489
    iput-object p10, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 268435490
    .line 268435491
    return-void
.end method

.method public constructor <init>(JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    invoke-static {p6, v0, p8}, LX/003;->A11(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-wide p1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 12
    .line 13
    iput-object p3, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 14
    .line 15
    iput p4, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 16
    .line 17
    iput-object p5, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p6, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p7, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 22
    .line 23
    iput-object p8, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 24
    .line 25
    iput-object p9, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 26
    .line 27
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-wide p1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p3, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget p4, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p5, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p6, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p7, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p8, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p9, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 47
    .line 48
    :cond_7
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->copy(JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_attribution_attribution(Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;LX/Da8;LX/Da5;)V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    iget-wide v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 2
    .line 3
    invoke-interface {p1, p2, v2, v0, v1}, LX/Da8;->AAR(LX/Da5;IJ)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 14
    .line 15
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 16
    .line 17
    .line 18
    sget-object v2, LX/DYp;->A01:LX/DYp;

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 21
    .line 22
    const/4 v0, 0x3

    .line 23
    invoke-interface {p1, v1, v2, p2, v0}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x4

    .line 27
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 33
    .line 34
    const/4 v0, 0x5

    .line 35
    invoke-interface {p1, v1, v2, p2, v0}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x6

    .line 39
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 40
    .line 41
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 42
    .line 43
    .line 44
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 45
    .line 46
    const/4 v0, 0x7

    .line 47
    invoke-interface {p1, v1, v2, p2, v0}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 48
    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final component1()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x4

    .line 5
    invoke-static {p6, p0, p8}, LX/003;->A11(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    new-instance p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 9
    .line 10
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;-><init>(JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 9
    .line 10
    iget-wide v3, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 11
    .line 12
    iget-wide v1, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 13
    .line 14
    cmp-long v0, v3, v1

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    iget v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 29
    .line 30
    iget v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 31
    .line 32
    if-ne v1, v0, :cond_0

    .line 33
    .line 34
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 37
    .line 38
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_0

    .line 53
    .line 54
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 55
    .line 56
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 67
    .line 68
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    iget-object v1, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v0, p1, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_1

    .line 83
    .line 84
    :cond_0
    return v5

    .line 85
    :cond_1
    return v6
.end method

.method public final getAdvertising_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAdvertising_id_status()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getApp_install_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAuth_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getClient_time_ms()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getFamily_device_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLog_reason()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSuppressed_count()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 4

    .line 0
    iget-wide v2, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->client_time_ms:J

    .line 1
    .line 2
    const/16 v0, 0x20

    .line 3
    .line 4
    ushr-long v0, v2, v0

    .line 5
    .line 6
    xor-long/2addr v2, v0

    .line 7
    long-to-int v0, v2

    .line 8
    mul-int/lit8 v1, v0, 0x1f

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->log_reason:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    iget v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->suppressed_count:I

    .line 17
    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->auth_type:Ljava/lang/String;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    add-int/2addr v1, v0

    .line 29
    mul-int/lit8 v1, v1, 0x1f

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->app_install_id:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    add-int/2addr v1, v0

    .line 44
    mul-int/lit8 v1, v1, 0x1f

    .line 45
    .line 46
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->advertising_id_status:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    iget-object v0, p0, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;->family_device_id:Ljava/lang/String;

    .line 53
    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    :cond_0
    add-int/2addr v1, v2

    .line 61
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
