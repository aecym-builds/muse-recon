.class public final Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final INSTANCE:Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;

.field public static final KEY_LAST_FAILED_MS:Ljava/lang/String; = "device_ids_last_failed_ms"

.field public static final KEY_LAST_SENT_MS:Ljava/lang/String; = "device_ids_last_sent_ms"

.field public static final KEY_PENDING_AUTH:Ljava/lang/String; = "device_ids_pending_auth"

.field public static final KEY_PENDING_AUTH_MS:Ljava/lang/String; = "device_ids_pending_auth_ms"

.field public static final KEY_SUPPRESSED_COUNT:Ljava/lang/String; = "device_ids_suppressed_count"

.field public static final LOG_REASON_AUTH_COMPLETED:Ljava/lang/String; = "auth_completed"

.field public static final LOG_REASON_COLD_START:Ljava/lang/String; = "cold_start"

.field public static final PENDING_AUTH_MAX_AGE_MS:J = 0x5265c00L

.field public static final THROTTLE_MS:J = 0x36ee80L

.field public static final advertisingIdRetryUsed:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final isEnabled$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const-string v4, "isEnabled"

    .line 1
    .line 2
    const-string v3, "isEnabled()Z"

    .line 3
    .line 4
    const-class v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, LX/DVg;

    .line 8
    .line 9
    invoke-direct {v0, v2, v4, v3, v1}, LX/DVg;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 10
    .line 11
    .line 12
    filled-new-array {v0}, [LX/Dqa;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->$$delegatedProperties:[LX/Dqa;

    .line 17
    .line 18
    new-instance v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;

    .line 19
    .line 20
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    sput-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->INSTANCE:Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_device_identifiers_logging:LX/0d8;

    .line 26
    .line 27
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isEnabled$delegate:LX/1zE;

    .line 32
    .line 33
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 34
    .line 35
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 36
    .line 37
    .line 38
    sput-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 39
    .line 40
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 41
    .line 42
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 43
    .line 44
    .line 45
    sput-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->advertisingIdRetryUsed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 46
    .line 47
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$fetchAdvertisingId(Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;)Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->fetchAdvertisingId()Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final fetchAdvertisingId()Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getLowPriorityExecutor()Ljava/util/concurrent/ExecutorService;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    new-instance v1, LX/ECM;

    .line 19
    .line 20
    invoke-direct {v1, v0}, LX/ECM;-><init>(LX/ES4;)V

    .line 21
    .line 22
    .line 23
    new-instance v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;

    .line 24
    .line 25
    invoke-direct {v0, p0, v2, v1}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;-><init>(Landroid/content/Context;Ljava/util/concurrent/Executor;LX/ECM;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->fetchAdvertisingIdSnapshotSync()Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method

.method private final getPrefs()LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method private final isEnabled()Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    invoke-static {p0, v1, v0}, LX/8mk;->A1X(Ljava/lang/Object;LX/1zE;[LX/Dqa;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method private final isStandardVm(LX/AHE;)Z
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->Companion:Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-virtual {p0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->isStandardVm()Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method private final isWithinThrottle(JJ)Z
    .locals 3

    .line 0
    sub-long/2addr p1, p3

    .line 1
    const-wide/16 v1, 0x0

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    cmp-long v0, v1, p1

    .line 5
    .line 6
    if-gtz v0, :cond_0

    .line 7
    .line 8
    const-wide/32 v1, 0x36ee80

    .line 9
    .line 10
    .line 11
    cmp-long v0, p1, v1

    .line 12
    .line 13
    if-gez v0, :cond_0

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    :cond_0
    return p0
.end method

.method private final pendingAuthType(J)Ljava/lang/String;
    .locals 8

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v7, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v7}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const-string v6, "device_ids_pending_auth"

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    invoke-interface {v0, v6, v5}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    if-nez v4, :cond_0

    .line 16
    .line 17
    return-object v5

    .line 18
    :cond_0
    invoke-virtual {p0, v7}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    const-wide/16 v0, 0x0

    .line 23
    .line 24
    const-string v3, "device_ids_pending_auth_ms"

    .line 25
    .line 26
    invoke-interface {v2, v3, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    sub-long/2addr p1, v0

    .line 31
    const-wide/32 v1, 0x5265c00

    .line 32
    .line 33
    .line 34
    cmp-long v0, p1, v1

    .line 35
    .line 36
    if-gez v0, :cond_1

    .line 37
    .line 38
    return-object v4

    .line 39
    :cond_1
    invoke-static {v7, p0}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0, v6}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v3}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 50
    .line 51
    .line 52
    return-object v5
.end method


# virtual methods
.method public final recordPendingAuth(Lcom/facebook/aura/attribution/HatchAttributionReporter$AuthEvent;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-ne v1, v0, :cond_1

    .line 12
    .line 13
    const-string p0, "registration"

    .line 14
    .line 15
    :goto_0
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 18
    .line 19
    invoke-static {v0, v1}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    const-string v0, "device_ids_pending_auth"

    .line 24
    .line 25
    invoke-virtual {p1, v0, p0}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 29
    .line 30
    .line 31
    move-result-wide v1

    .line 32
    const-string v0, "device_ids_pending_auth_ms"

    .line 33
    .line 34
    invoke-virtual {p1, v0, v1, p0}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p1}, LX/Df3;->apply()V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_0
    const-string p0, "login"

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 47
    .line 48
    .line 49
    throw v0
.end method

.method public final reportOnStart(LX/AHE;LX/2M4;)Ljava/lang/Object;
    .locals 39
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    move-object/from16 v9, p1

    .line 3
    .line 4
    instance-of v0, v4, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;

    .line 5
    .line 6
    move-object/from16 v10, p0

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    move-object v2, v4

    .line 11
    check-cast v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;

    .line 12
    .line 13
    iget v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v3, v1

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    sub-int/2addr v3, v1

    .line 22
    iput v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v1, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v24, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->label:I

    .line 29
    .line 30
    const-string v23, "device_ids_last_sent_ms"

    .line 31
    .line 32
    const/16 v22, 0x2

    .line 33
    .line 34
    const-string v21, "device_ids_last_failed_ms"

    .line 35
    .line 36
    const-string v20, "device_ids_pending_auth_ms"

    .line 37
    .line 38
    const-string v19, "device_ids_suppressed_count"

    .line 39
    .line 40
    const/16 v18, 0x1

    .line 41
    .line 42
    if-eqz v3, :cond_2

    .line 43
    .line 44
    move/from16 v0, v18

    .line 45
    .line 46
    if-eq v3, v0, :cond_1

    .line 47
    .line 48
    move/from16 v0, v22

    .line 49
    .line 50
    if-ne v3, v0, :cond_15

    .line 51
    .line 52
    iget v13, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$1:I

    .line 53
    .line 54
    iget-wide v11, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$1:J

    .line 55
    .line 56
    iget v5, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$0:I

    .line 57
    .line 58
    iget-wide v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$0:J

    .line 59
    .line 60
    iget-object v9, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$2:Ljava/lang/Object;

    .line 61
    .line 62
    iget-object v0, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$1:Ljava/lang/Object;

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_0
    new-instance v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;

    .line 66
    .line 67
    invoke-direct {v2, v10, v4}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;-><init>(Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;LX/2M4;)V

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :goto_1
    :try_start_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    check-cast v1, LX/2PJ;

    .line 75
    .line 76
    iget-object v7, v1, LX/2PJ;->value:Ljava/lang/Object;

    .line 77
    .line 78
    const/4 v6, 0x0

    .line 79
    goto/16 :goto_c
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_2

    .line 80
    .line 81
    :cond_1
    iget v6, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$2:I

    .line 82
    .line 83
    iget v13, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$1:I

    .line 84
    .line 85
    iget-wide v11, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$1:J

    .line 86
    .line 87
    iget v5, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$0:I

    .line 88
    .line 89
    iget-wide v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$0:J

    .line 90
    .line 91
    iget-object v0, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$1:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v0, Ljava/lang/String;

    .line 94
    .line 95
    iget-object v9, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$0:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v9, LX/AHE;

    .line 98
    .line 99
    goto/16 :goto_5

    .line 100
    .line 101
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 105
    .line 106
    .line 107
    move-result-wide v3

    .line 108
    invoke-direct {v10, v3, v4}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->pendingAuthType(J)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    if-nez v0, :cond_5

    .line 113
    .line 114
    sget-object v1, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 115
    .line 116
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    if-eqz v1, :cond_5

    .line 121
    .line 122
    :cond_3
    :goto_2
    sget-object v24, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 123
    .line 124
    :cond_4
    return-object v24

    .line 125
    :cond_5
    invoke-direct {v10, v9}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isStandardVm(LX/AHE;)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    if-eqz v1, :cond_3

    .line 130
    .line 131
    invoke-direct {v10}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isEnabled()Z

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    if-eqz v1, :cond_3

    .line 136
    .line 137
    sget-object v5, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 138
    .line 139
    move/from16 v1, v18

    .line 140
    .line 141
    invoke-virtual {v5, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 142
    .line 143
    .line 144
    move-result v17

    .line 145
    xor-int/lit8 v5, v17, 0x1

    .line 146
    .line 147
    if-nez v0, :cond_6

    .line 148
    .line 149
    if-eqz v17, :cond_6

    .line 150
    .line 151
    goto :goto_2

    .line 152
    :cond_6
    sget-object v8, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 153
    .line 154
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 155
    .line 156
    invoke-virtual {v8, v1}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 157
    .line 158
    .line 159
    move-result-object v12

    .line 160
    const-wide/16 v6, 0x0

    .line 161
    .line 162
    move-object/from16 v11, v20

    .line 163
    .line 164
    invoke-interface {v12, v11, v6, v7}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 165
    .line 166
    .line 167
    move-result-wide v11

    .line 168
    invoke-virtual {v8, v1}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 169
    .line 170
    .line 171
    move-result-object v13

    .line 172
    const/16 v16, 0x0

    .line 173
    .line 174
    move-object/from16 v7, v19

    .line 175
    .line 176
    move/from16 v6, v16

    .line 177
    .line 178
    invoke-interface {v13, v7, v6}, LX/BVu;->getInt(Ljava/lang/String;I)I

    .line 179
    .line 180
    .line 181
    move-result v13

    .line 182
    if-nez v0, :cond_8

    .line 183
    .line 184
    invoke-virtual {v8, v1}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 185
    .line 186
    .line 187
    move-result-object v15

    .line 188
    const-wide/16 v6, 0x0

    .line 189
    .line 190
    move-object/from16 v14, v23

    .line 191
    .line 192
    invoke-interface {v15, v14, v6, v7}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 193
    .line 194
    .line 195
    move-result-wide v14

    .line 196
    invoke-direct {v10, v3, v4, v14, v15}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isWithinThrottle(JJ)Z

    .line 197
    .line 198
    .line 199
    move-result v15

    .line 200
    const/4 v14, 0x1

    .line 201
    if-nez v15, :cond_7

    .line 202
    .line 203
    :goto_3
    const/4 v14, 0x0

    .line 204
    :cond_7
    if-nez v14, :cond_13

    .line 205
    .line 206
    invoke-virtual {v8, v1}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 207
    .line 208
    .line 209
    move-result-object v15

    .line 210
    move-object/from16 v14, v21

    .line 211
    .line 212
    invoke-interface {v15, v14, v6, v7}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 213
    .line 214
    .line 215
    move-result-wide v6

    .line 216
    invoke-direct {v10, v3, v4, v6, v7}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isWithinThrottle(JJ)Z

    .line 217
    .line 218
    .line 219
    move-result v6

    .line 220
    if-nez v6, :cond_13

    .line 221
    .line 222
    goto :goto_4

    .line 223
    :cond_8
    const-wide/16 v6, 0x0

    .line 224
    .line 225
    goto :goto_3

    .line 226
    :goto_4
    :try_start_1
    sget-object v1, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 227
    .line 228
    invoke-virtual {v1}, Lcom/facebook/aura/executors/AuraDispatchers;->io()LX/BqD;

    .line 229
    .line 230
    .line 231
    move-result-object v8

    .line 232
    const/4 v1, 0x0

    .line 233
    new-instance v7, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;

    .line 234
    .line 235
    invoke-direct {v7, v1}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;-><init>(LX/2M4;)V

    .line 236
    .line 237
    .line 238
    iput-object v9, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$0:Ljava/lang/Object;

    .line 239
    .line 240
    iput-object v0, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$1:Ljava/lang/Object;

    .line 241
    .line 242
    iput-wide v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$0:J

    .line 243
    .line 244
    iput v5, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$0:I

    .line 245
    .line 246
    iput-wide v11, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$1:J

    .line 247
    .line 248
    iput v13, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$1:I

    .line 249
    .line 250
    const/4 v6, 0x0

    .line 251
    iput v6, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$2:I

    .line 252
    .line 253
    move/from16 v1, v18

    .line 254
    .line 255
    iput v1, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->label:I

    .line 256
    .line 257
    invoke-static {v2, v8, v7}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    move-object/from16 v7, v24

    .line 262
    .line 263
    if-ne v1, v7, :cond_9

    .line 264
    .line 265
    goto/16 :goto_e
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1

    .line 266
    .line 267
    :goto_5
    :try_start_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    :cond_9
    check-cast v1, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;

    .line 271
    .line 272
    invoke-direct {v10, v9}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->isStandardVm(LX/AHE;)Z

    .line 273
    .line 274
    .line 275
    move-result v7

    .line 276
    if-nez v7, :cond_a

    .line 277
    .line 278
    goto/16 :goto_f

    .line 279
    .line 280
    :cond_a
    if-eqz v0, :cond_b

    .line 281
    .line 282
    move-wide/from16 v31, v11

    .line 283
    .line 284
    :goto_6
    if-eqz v0, :cond_c

    .line 285
    .line 286
    goto :goto_7

    .line 287
    :cond_b
    move-wide/from16 v31, v3

    .line 288
    .line 289
    goto :goto_6

    .line 290
    :cond_c
    const-string v33, "cold_start"

    .line 291
    .line 292
    goto :goto_8

    .line 293
    :goto_7
    const-string v33, "auth_completed"

    .line 294
    .line 295
    :goto_8
    sget-object v7, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/AuraDeviceId;

    .line 296
    .line 297
    invoke-virtual {v7}, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->get()Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v36

    .line 301
    instance-of v7, v1, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 302
    .line 303
    if-eqz v7, :cond_d

    .line 304
    .line 305
    move-object v7, v1

    .line 306
    check-cast v7, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 307
    .line 308
    goto :goto_9

    .line 309
    :cond_d
    const/4 v7, 0x0

    .line 310
    :goto_9
    if-eqz v7, :cond_e

    .line 311
    .line 312
    goto :goto_a

    .line 313
    :cond_e
    const/4 v7, 0x0

    .line 314
    goto :goto_b

    .line 315
    :goto_a
    iget-object v7, v7, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 316
    .line 317
    :goto_b
    invoke-interface {v1}, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;->getStatus()Ljava/lang/String;

    .line 318
    .line 319
    .line 320
    move-result-object v38

    .line 321
    sget-object v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 322
    .line 323
    invoke-virtual {v8}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->get()Ljava/lang/String;

    .line 324
    .line 325
    .line 326
    move-result-object p0

    .line 327
    new-instance v30, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;

    .line 328
    .line 329
    move/from16 v34, v13

    .line 330
    .line 331
    move-object/from16 v35, v0

    .line 332
    .line 333
    move-object/from16 v37, v7

    .line 334
    .line 335
    invoke-direct/range {v30 .. v39}, Lcom/facebook/aura/attribution/DeviceIdentifiersRequestJson;-><init>(JLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 336
    .line 337
    .line 338
    sget-object v25, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 339
    .line 340
    sget-object v29, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionDeviceIdentifiers;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionDeviceIdentifiers;

    .line 341
    .line 342
    sget-object v31, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 343
    .line 344
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 345
    .line 346
    .line 347
    move-result-object v32

    .line 348
    sget-object p0, LX/0wX;->A00:LX/0wX;

    .line 349
    .line 350
    sget-object v26, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 351
    .line 352
    sget-object v27, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 353
    .line 354
    const/4 v7, 0x0

    .line 355
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$0:Ljava/lang/Object;

    .line 356
    .line 357
    iput-object v0, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$1:Ljava/lang/Object;

    .line 358
    .line 359
    iput-object v1, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$2:Ljava/lang/Object;

    .line 360
    .line 361
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$3:Ljava/lang/Object;

    .line 362
    .line 363
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$4:Ljava/lang/Object;

    .line 364
    .line 365
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$5:Ljava/lang/Object;

    .line 366
    .line 367
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$6:Ljava/lang/Object;

    .line 368
    .line 369
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$7:Ljava/lang/Object;

    .line 370
    .line 371
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$8:Ljava/lang/Object;

    .line 372
    .line 373
    iput-object v7, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->L$9:Ljava/lang/Object;

    .line 374
    .line 375
    iput-wide v3, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$0:J

    .line 376
    .line 377
    iput v5, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$0:I

    .line 378
    .line 379
    iput-wide v11, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->J$1:J

    .line 380
    .line 381
    iput v13, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$1:I

    .line 382
    .line 383
    iput v6, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$2:I

    .line 384
    .line 385
    move/from16 v6, v18

    .line 386
    .line 387
    iput v6, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$3:I

    .line 388
    .line 389
    const/4 v8, 0x0

    .line 390
    iput v8, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$4:I

    .line 391
    .line 392
    iput v8, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$5:I

    .line 393
    .line 394
    iput v8, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->I$6:I

    .line 395
    .line 396
    move/from16 v6, v22

    .line 397
    .line 398
    iput v6, v2, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$1;->label:I

    .line 399
    .line 400
    const/4 v6, 0x0
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_2

    .line 401
    :try_start_3
    move/from16 v28, v18

    .line 402
    .line 403
    move/from16 v33, v18

    .line 404
    .line 405
    move-object/from16 v34, v7

    .line 406
    .line 407
    move/from16 v35, v8

    .line 408
    .line 409
    move-object/from16 v36, v7

    .line 410
    .line 411
    move-object/from16 v37, v7

    .line 412
    .line 413
    move/from16 v38, v8

    .line 414
    .line 415
    move/from16 p1, v8

    .line 416
    .line 417
    move-object/from16 p2, v2

    .line 418
    .line 419
    invoke-virtual/range {v25 .. v41}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 420
    .line 421
    .line 422
    move-result-object v7

    .line 423
    move-object/from16 v2, v24

    .line 424
    .line 425
    if-eq v7, v2, :cond_4

    .line 426
    .line 427
    move-object v9, v1

    .line 428
    :goto_c
    instance-of v1, v7, LX/2PH;

    .line 429
    .line 430
    xor-int/lit8 v1, v1, 0x1

    .line 431
    .line 432
    if-eqz v1, :cond_11

    .line 433
    .line 434
    sget-object v10, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 435
    .line 436
    sget-object v2, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 437
    .line 438
    invoke-static {v2, v10}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 439
    .line 440
    .line 441
    move-result-object v8

    .line 442
    move-object/from16 v1, v19

    .line 443
    .line 444
    invoke-virtual {v8, v1, v6}, LX/Df3;->AZA(Ljava/lang/String;I)V

    .line 445
    .line 446
    .line 447
    move-object/from16 v1, v21

    .line 448
    .line 449
    invoke-virtual {v8, v1}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 450
    .line 451
    .line 452
    if-nez v0, :cond_f

    .line 453
    .line 454
    instance-of v1, v9, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Error;

    .line 455
    .line 456
    if-eqz v1, :cond_f

    .line 457
    .line 458
    sget-object v9, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->advertisingIdRetryUsed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 459
    .line 460
    move/from16 v1, v18

    .line 461
    .line 462
    invoke-virtual {v9, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 463
    .line 464
    .line 465
    move-result v1

    .line 466
    if-nez v1, :cond_f

    .line 467
    .line 468
    sget-object v1, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 469
    .line 470
    invoke-virtual {v1, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 471
    .line 472
    .line 473
    goto :goto_d

    .line 474
    :cond_f
    move-object/from16 v1, v23

    .line 475
    .line 476
    invoke-virtual {v8, v1, v3, v4}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 477
    .line 478
    .line 479
    :goto_d
    if-eqz v0, :cond_10

    .line 480
    .line 481
    invoke-virtual {v10, v2}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 482
    .line 483
    .line 484
    move-result-object v9

    .line 485
    const-wide/16 v0, 0x0

    .line 486
    .line 487
    move-object/from16 v2, v20

    .line 488
    .line 489
    invoke-interface {v9, v2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 490
    .line 491
    .line 492
    move-result-wide v1

    .line 493
    cmp-long v0, v1, v11

    .line 494
    .line 495
    if-nez v0, :cond_10

    .line 496
    .line 497
    const-string v0, "device_ids_pending_auth"

    .line 498
    .line 499
    invoke-virtual {v8, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 500
    .line 501
    .line 502
    move-object/from16 v0, v20

    .line 503
    .line 504
    invoke-virtual {v8, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 505
    .line 506
    .line 507
    :cond_10
    invoke-virtual {v8}, LX/Df3;->apply()V

    .line 508
    .line 509
    .line 510
    :cond_11
    invoke-static {v7}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 511
    .line 512
    .line 513
    move-result-object v7

    .line 514
    if-eqz v7, :cond_3

    .line 515
    .line 516
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 517
    .line 518
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 519
    .line 520
    invoke-static {v0, v1}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 521
    .line 522
    .line 523
    move-result-object v2

    .line 524
    move-object/from16 v0, v21

    .line 525
    .line 526
    invoke-virtual {v2, v0, v3, v4}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 527
    .line 528
    .line 529
    if-eqz v5, :cond_12

    .line 530
    .line 531
    add-int/lit8 v1, v13, 0x1

    .line 532
    .line 533
    move-object/from16 v0, v19

    .line 534
    .line 535
    invoke-virtual {v2, v0, v1}, LX/Df3;->AZA(Ljava/lang/String;I)V

    .line 536
    .line 537
    .line 538
    :cond_12
    invoke-virtual {v2}, LX/Df3;->apply()V

    .line 539
    .line 540
    .line 541
    sget-object v0, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionDeviceIdentifiers;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionDeviceIdentifiers;

    .line 542
    .line 543
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionDeviceIdentifiers;->getValue()Ljava/lang/String;

    .line 544
    .line 545
    .line 546
    move-result-object v0

    .line 547
    invoke-static {v0, v7}, Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;->logAttributionFailure(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 548
    .line 549
    .line 550
    goto/16 :goto_2

    .line 551
    .line 552
    :cond_13
    if-nez v17, :cond_3
    :try_end_3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3 .. :try_end_3} :catch_0

    .line 553
    .line 554
    invoke-static {v1, v8}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 555
    .line 556
    .line 557
    move-result-object v2

    .line 558
    add-int/lit8 v1, v13, 0x1

    .line 559
    .line 560
    move-object/from16 v0, v19

    .line 561
    .line 562
    invoke-virtual {v2, v0, v1}, LX/Df3;->AZA(Ljava/lang/String;I)V

    .line 563
    .line 564
    .line 565
    invoke-virtual {v2}, LX/Df3;->apply()V

    .line 566
    .line 567
    .line 568
    goto/16 :goto_2

    .line 569
    .line 570
    :goto_e
    return-object v24

    .line 571
    :goto_f
    if-eqz v5, :cond_14

    .line 572
    .line 573
    :try_start_4
    sget-object v1, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 574
    .line 575
    const/4 v0, 0x0

    .line 576
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 577
    .line 578
    .line 579
    :cond_14
    sget-object v24, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 580
    .line 581
    return-object v24
    :try_end_4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4 .. :try_end_4} :catch_2

    .line 582
    :catch_0
    move-exception v1

    .line 583
    goto :goto_10

    .line 584
    :catch_1
    move-exception v1

    .line 585
    const/4 v6, 0x0

    .line 586
    goto :goto_10

    .line 587
    :catch_2
    move-exception v1

    .line 588
    const/4 v6, 0x0

    .line 589
    :goto_10
    if-eqz v5, :cond_16

    .line 590
    .line 591
    sget-object v0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->coldStartHandled:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 592
    .line 593
    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 594
    .line 595
    .line 596
    throw v1

    .line 597
    :cond_15
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 598
    .line 599
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 600
    .line 601
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 602
    .line 603
    .line 604
    :cond_16
    throw v1
.end method
