.class public final Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Ljava/lang/Boolean;",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

.field public final synthetic $debugLogger:LX/ECM;

.field public final synthetic $events:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/ECD;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $includeFamilyDeviceId:Z

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(ZLX/AHE;LX/ECM;Ljava/util/List;Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/AHE;",
            "LX/ECM;",
            "Ljava/util/List<",
            "+",
            "LX/ECD;",
            ">;",
            "Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;",
            ")V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$includeFamilyDeviceId:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$userSession:LX/AHE;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$debugLogger:LX/ECM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$events:Ljava/util/List;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    check-cast p2, Ljava/lang/String;

    .line 268435463
    .line 268435464
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->invoke(ZLjava/lang/String;)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(ZLjava/lang/String;)V
    .locals 9

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$includeFamilyDeviceId:Z

    .line 1
    .line 2
    new-instance v5, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;

    .line 3
    .line 4
    invoke-direct {v5, p2, v0}, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;-><init>(Ljava/lang/String;Z)V

    .line 5
    .line 6
    .line 7
    iget-object v3, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$userSession:LX/AHE;

    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$debugLogger:LX/ECM;

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 12
    .line 13
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$1;

    .line 14
    .line 15
    invoke-direct {v0, v1}, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$1;-><init>(Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;)V

    .line 16
    .line 17
    .line 18
    new-instance v6, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 19
    .line 20
    invoke-direct {v6, v3, v2, v0}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;-><init>(LX/AHE;LX/ECM;LX/JDM;)V

    .line 21
    .line 22
    .line 23
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$userSession:LX/AHE;

    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$batch:Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2$2;-><init>(Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;)V

    .line 30
    .line 31
    .line 32
    new-instance v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;

    .line 33
    .line 34
    invoke-direct {v4, v2, v0}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;-><init>(LX/AHE;LX/JDM;)V

    .line 35
    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 38
    .line 39
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getLowPriorityExecutor()Ljava/util/concurrent/ExecutorService;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    iget-object v8, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$debugLogger:LX/ECM;

    .line 44
    .line 45
    new-instance v3, LX/ECN;

    .line 46
    .line 47
    invoke-direct/range {v3 .. v8}, LX/ECN;-><init>(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;Lcom/facebook/aura/attribution/HatchAttributionEventsClient;Ljava/util/concurrent/ExecutorService;LX/ECM;)V

    .line 48
    .line 49
    .line 50
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;->$events:Ljava/util/List;

    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    invoke-static {v2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 54
    .line 55
    .line 56
    iget-object v1, v3, LX/ECN;->A03:Ljava/util/concurrent/ExecutorService;

    .line 57
    .line 58
    new-instance v0, LX/ECQ;

    .line 59
    .line 60
    invoke-direct {v0, v2, v3}, LX/ECQ;-><init>(Ljava/util/List;LX/ECN;)V

    .line 61
    .line 62
    .line 63
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 64
    .line 65
    .line 66
    return-void
.end method
