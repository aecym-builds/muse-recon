.class public final Lcom/facebook/aura/attribution/MC$hatch_gtm;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x2131a

.field public static final INSTANCE:Lcom/facebook/aura/attribution/MC$hatch_gtm;

.field public static final __CONFIG__:I = 0x227

.field public static final app_install_silent_redeem_code:LX/0d8;

.field public static final card_token_auto_send_enabled:LX/0d8;

.field public static final chat_inline_media_share_enabled:LX/0d8;

.field public static final chat_share_prompt_max_length:LX/0d8;

.field public static final download_link_url:LX/0d8;

.field public static final enable_attribution_family_device_id:LX/0d8;

.field public static final enable_device_identifiers_logging:LX/0d8;

.field public static final enable_entry_context_token_send_ios:LX/0d8;

.field public static final enable_sharing_invite_to_ig_story:LX/0d8;

.field public static final facebook_avatar_story_uses_video:LX/0d8;

.field public static final facebook_feed_destination_enabled:LX/0d8;

.field public static final facebook_story_destination_enabled:LX/0d8;

.field public static final invite_button_tooltip_secs:LX/0d8;

.field public static final invite_enabled:LX/0d8;

.field public static final invite_story_share_enabled:LX/0d8;

.field public static final is_scratch_to_reveal_code_enabled:LX/0d8;

.field public static final media_viewer_share_as_primary_action_enabled:LX/0d8;

.field public static final redeem_code_screen_title_text:LX/0d8;

.field public static final redeem_invite_enabled:LX/0d8;

.field public static final screenshot_share_enabled:LX/0d8;

.field public static final share_avatar_enabled:LX/0d8;

.field public static final share_avatar_intro_enabled:LX/0d8;

.field public static final share_idea_enabled:LX/0d8;

.field public static final share_recipients_prewarm_enabled:LX/0d8;

.field public static final share_sheet_enabled:LX/0d8;

.field public static final x_media_share_extension_enabled_ios:LX/0d8;

.field public static final x_share_destination_enabled:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->INSTANCE:Lcom/facebook/aura/attribution/MC$hatch_gtm;

    .line 6
    .line 7
    const-wide v1, 0x81022700230136L

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->app_install_silent_redeem_code:LX/0d8;

    .line 18
    .line 19
    const-wide v1, 0x810227002c0138L

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    new-instance v0, LX/0d8;

    .line 25
    .line 26
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->card_token_auto_send_enabled:LX/0d8;

    .line 30
    .line 31
    const-wide v1, 0x8102270034013bL

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    new-instance v0, LX/0d8;

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->chat_inline_media_share_enabled:LX/0d8;

    .line 42
    .line 43
    const-wide v1, 0x82022700280affL

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    new-instance v0, LX/0d8;

    .line 49
    .line 50
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 51
    .line 52
    .line 53
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->chat_share_prompt_max_length:LX/0d8;

    .line 54
    .line 55
    const-wide v1, 0x8302270002004cL

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    new-instance v0, LX/0d8;

    .line 61
    .line 62
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 63
    .line 64
    .line 65
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->download_link_url:LX/0d8;

    .line 66
    .line 67
    const-wide v1, 0x8102270033013aL

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    new-instance v0, LX/0d8;

    .line 73
    .line 74
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_attribution_family_device_id:LX/0d8;

    .line 78
    .line 79
    const-wide v1, 0x810227002a0137L

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    new-instance v0, LX/0d8;

    .line 85
    .line 86
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 87
    .line 88
    .line 89
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_device_identifiers_logging:LX/0d8;

    .line 90
    .line 91
    const-wide v1, 0x810227001a0132L

    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    new-instance v0, LX/0d8;

    .line 97
    .line 98
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 99
    .line 100
    .line 101
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_entry_context_token_send_ios:LX/0d8;

    .line 102
    .line 103
    const-wide v1, 0x810227000e012bL

    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    new-instance v0, LX/0d8;

    .line 109
    .line 110
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 111
    .line 112
    .line 113
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_sharing_invite_to_ig_story:LX/0d8;

    .line 114
    .line 115
    const-wide v1, 0x810227001c0133L

    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    new-instance v0, LX/0d8;

    .line 121
    .line 122
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 123
    .line 124
    .line 125
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->facebook_avatar_story_uses_video:LX/0d8;

    .line 126
    .line 127
    const-wide v1, 0x810227001d0134L

    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    new-instance v0, LX/0d8;

    .line 133
    .line 134
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 135
    .line 136
    .line 137
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->facebook_feed_destination_enabled:LX/0d8;

    .line 138
    .line 139
    const-wide v1, 0x81022700190131L

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    new-instance v0, LX/0d8;

    .line 145
    .line 146
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 147
    .line 148
    .line 149
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->facebook_story_destination_enabled:LX/0d8;

    .line 150
    .line 151
    const-wide v1, 0x82022700250afeL

    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    new-instance v0, LX/0d8;

    .line 157
    .line 158
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 159
    .line 160
    .line 161
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->invite_button_tooltip_secs:LX/0d8;

    .line 162
    .line 163
    const-wide v1, 0x81022700040127L

    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    new-instance v0, LX/0d8;

    .line 169
    .line 170
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 171
    .line 172
    .line 173
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->invite_enabled:LX/0d8;

    .line 174
    .line 175
    const-wide v1, 0x810227000f012cL

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    new-instance v0, LX/0d8;

    .line 181
    .line 182
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 183
    .line 184
    .line 185
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->invite_story_share_enabled:LX/0d8;

    .line 186
    .line 187
    const-wide v1, 0x208102270009012aL    # 4.059343972405557E-152

    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    new-instance v0, LX/0d8;

    .line 193
    .line 194
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 195
    .line 196
    .line 197
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->is_scratch_to_reveal_code_enabled:LX/0d8;

    .line 198
    .line 199
    const-wide v1, 0x81022700300139L

    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    new-instance v0, LX/0d8;

    .line 205
    .line 206
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 207
    .line 208
    .line 209
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->media_viewer_share_as_primary_action_enabled:LX/0d8;

    .line 210
    .line 211
    const-wide v1, 0x8302270017004dL

    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    new-instance v0, LX/0d8;

    .line 217
    .line 218
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 219
    .line 220
    .line 221
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->redeem_code_screen_title_text:LX/0d8;

    .line 222
    .line 223
    const-wide v1, 0x8102270010012dL

    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    new-instance v0, LX/0d8;

    .line 229
    .line 230
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 231
    .line 232
    .line 233
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->redeem_invite_enabled:LX/0d8;

    .line 234
    .line 235
    const-wide v1, 0x81022700060129L

    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    new-instance v0, LX/0d8;

    .line 241
    .line 242
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 243
    .line 244
    .line 245
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->screenshot_share_enabled:LX/0d8;

    .line 246
    .line 247
    const-wide v1, 0x81022700010126L

    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    new-instance v0, LX/0d8;

    .line 253
    .line 254
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 255
    .line 256
    .line 257
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->share_avatar_enabled:LX/0d8;

    .line 258
    .line 259
    const-wide v1, 0x8102270012012eL

    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    new-instance v0, LX/0d8;

    .line 265
    .line 266
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 267
    .line 268
    .line 269
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->share_avatar_intro_enabled:LX/0d8;

    .line 270
    .line 271
    const-wide v1, 0x81022700200135L

    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    new-instance v0, LX/0d8;

    .line 277
    .line 278
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 279
    .line 280
    .line 281
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->share_idea_enabled:LX/0d8;

    .line 282
    .line 283
    const-wide v1, 0x81022700050128L

    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    new-instance v0, LX/0d8;

    .line 289
    .line 290
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 291
    .line 292
    .line 293
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->share_recipients_prewarm_enabled:LX/0d8;

    .line 294
    .line 295
    const-wide v1, 0x81022700000125L

    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    new-instance v0, LX/0d8;

    .line 301
    .line 302
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 303
    .line 304
    .line 305
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->share_sheet_enabled:LX/0d8;

    .line 306
    .line 307
    const-wide v1, 0x81022700180130L

    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    new-instance v0, LX/0d8;

    .line 313
    .line 314
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 315
    .line 316
    .line 317
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->x_media_share_extension_enabled_ios:LX/0d8;

    .line 318
    .line 319
    const-wide v1, 0x8102270014012fL

    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    new-instance v0, LX/0d8;

    .line 325
    .line 326
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 327
    .line 328
    .line 329
    sput-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->x_share_destination_enabled:LX/0d8;

    .line 330
    .line 331
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
