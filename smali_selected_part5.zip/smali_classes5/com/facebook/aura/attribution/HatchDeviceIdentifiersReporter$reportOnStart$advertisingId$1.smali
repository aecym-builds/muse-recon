.class public final Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.attribution.HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1"
    f = "HatchDeviceIdentifiersReporter.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    new-instance p1, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;

    .line 1
    .line 2
    invoke-direct {p1, p2}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    invoke-virtual {p1, p0}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter$reportOnStart$advertisingId$1;->label:I

    .line 1
    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->INSTANCE:Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;

    .line 8
    .line 9
    invoke-static {p0}, Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;->access$fetchAdvertisingId(Lcom/facebook/aura/attribution/HatchDeviceIdentifiersReporter;)Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :cond_0
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p0
.end method
