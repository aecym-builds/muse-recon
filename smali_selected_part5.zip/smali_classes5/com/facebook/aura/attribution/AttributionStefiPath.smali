.class public interface abstract Lcom/facebook/aura/attribution/AttributionStefiPath;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/api/StefiHatchPath$Extension;
