.class public final Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchAttributionCompliance"


# instance fields
.field public final onSettled:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final scope:LX/1EL;

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->Companion:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->onSettled:LX/JDM;

    .line 9
    .line 10
    invoke-static {}, LX/8mk;->A0z()LX/EQC;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->scope:LX/1EL;

    .line 15
    .line 16
    return-void
.end method

.method public static final synthetic access$getOnSettled$p(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->onSettled:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$toComplianceAction(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;Ljava/lang/String;)LX/ECS;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->toComplianceAction(Ljava/lang/String;)LX/ECS;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final toComplianceAction(Ljava/lang/String;)LX/ECS;
    .locals 1

    .line 0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 1
    .line 2
    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    const v0, -0x52246bc0

    .line 11
    .line 12
    .line 13
    if-eq p0, v0, :cond_1

    .line 14
    .line 15
    const v0, -0x46f4022e

    .line 16
    .line 17
    .line 18
    if-eq p0, v0, :cond_0

    .line 19
    .line 20
    const v0, -0x37b3aacc

    .line 21
    .line 22
    .line 23
    if-ne p0, v0, :cond_2

    .line 24
    .line 25
    const-string v0, "report"

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    sget-object v0, LX/ECS;->A04:LX/ECS;

    .line 34
    .line 35
    return-object v0

    .line 36
    :cond_0
    const-string v0, "ignore"

    .line 37
    .line 38
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    sget-object v0, LX/ECS;->A03:LX/ECS;

    .line 45
    .line 46
    return-object v0

    .line 47
    :cond_1
    const-string v0, "buffer"

    .line 48
    .line 49
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    sget-object v0, LX/ECS;->A02:LX/ECS;

    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_2
    const/4 v0, 0x0

    .line 59
    return-object v0
.end method


# virtual methods
.method public getEventComplianceAction(LX/ECg;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->scope:LX/1EL;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;-><init>(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;LX/ECg;LX/2M4;)V

    .line 10
    .line 11
    .line 12
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
