.class public final Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.attribution.HatchAttributionEventsClient$send$1"
    f = "HatchAttributionEventsClient.kt"
    l = {
        0x8d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $callback:LX/ECY;

.field public final synthetic $eventNames:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $request:Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;

.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;Lcom/facebook/aura/attribution/HatchAttributionEventsClient;LX/ECY;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;",
            "Lcom/facebook/aura/attribution/HatchAttributionEventsClient;",
            "LX/ECY;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$eventNames:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$request:Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$callback:LX/ECY;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$eventNames:Ljava/util/List;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$request:Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$callback:LX/ECY;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;-><init>(Ljava/util/List;Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;Lcom/facebook/aura/attribution/HatchAttributionEventsClient;LX/ECY;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v3, p0

    .line 5
    .line 6
    iget v0, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->label:I

    .line 7
    .line 8
    const-string v1, "HatchAttributionEventsClient"

    .line 9
    .line 10
    const/4 v7, 0x0

    .line 11
    const/4 v12, 0x1

    .line 12
    if-eqz v0, :cond_3

    .line 13
    .line 14
    if-ne v0, v12, :cond_4

    .line 15
    .line 16
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    check-cast v4, LX/2PJ;

    .line 20
    .line 21
    iget-object v0, v4, LX/2PJ;->value:Ljava/lang/Object;

    .line 22
    .line 23
    :cond_0
    iget-object v6, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$eventNames:Ljava/util/List;

    .line 24
    .line 25
    iget-object v5, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 26
    .line 27
    iget-object v3, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$callback:LX/ECY;

    .line 28
    .line 29
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    if-nez v2, :cond_2

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    const-string v2, ", "

    .line 37
    .line 38
    const-string v0, ""

    .line 39
    .line 40
    invoke-static {v2, v0, v0, v6, v4}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    const-string v0, "Sent %s"

    .line 45
    .line 46
    invoke-static {v2, v1, v0}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    iget-object v0, v5, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->onSettled:LX/JDM;

    .line 50
    .line 51
    invoke-static {v12, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 52
    .line 53
    .line 54
    check-cast v3, LX/ECR;

    .line 55
    .line 56
    iget-object v0, v3, LX/ECR;->A01:LX/ECN;

    .line 57
    .line 58
    iget-object v2, v0, LX/ECN;->A04:LX/ECM;

    .line 59
    .line 60
    if-eqz v2, :cond_1

    .line 61
    .line 62
    const-string v1, "report_events_success"

    .line 63
    .line 64
    iget-object v0, v3, LX/ECR;->A00:Ljava/util/List;

    .line 65
    .line 66
    invoke-static {v1, v4, v4, v0}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    const-string v0, "info"

    .line 71
    .line 72
    invoke-static {v1, v0, v2}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 73
    .line 74
    .line 75
    :cond_1
    :goto_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 76
    .line 77
    return-object v2

    .line 78
    :cond_2
    iget-object v0, v5, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->onSettled:LX/JDM;

    .line 79
    .line 80
    invoke-static {v7, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 81
    .line 82
    .line 83
    sget-object v0, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionReportEvents;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionReportEvents;

    .line 84
    .line 85
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionReportEvents;->getValue()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-static {v0, v2}, Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;->logAttributionFailure(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 90
    .line 91
    .line 92
    invoke-static {v2}, Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;->attributionFailureMessage(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-interface {v3, v0, v2}, LX/ECY;->ATU(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 97
    .line 98
    .line 99
    goto :goto_0

    .line 100
    :cond_3
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    iget-object v5, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$eventNames:Ljava/util/List;

    .line 104
    .line 105
    const/4 v13, 0x0

    .line 106
    const-string v4, ", "

    .line 107
    .line 108
    const-string v0, ""

    .line 109
    .line 110
    invoke-static {v4, v0, v0, v5, v13}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    const-string v0, "Sending %s"

    .line 115
    .line 116
    invoke-static {v4, v1, v0}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 120
    .line 121
    sget-object v8, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionReportEvents;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionReportEvents;

    .line 122
    .line 123
    iget-object v9, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->$request:Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;

    .line 124
    .line 125
    sget-object v10, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 126
    .line 127
    iget-object v0, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 128
    .line 129
    iget-object v0, v0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->userSession:LX/AHE;

    .line 130
    .line 131
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 132
    .line 133
    .line 134
    move-result-object v11

    .line 135
    sget-object v18, LX/0wX;->A00:LX/0wX;

    .line 136
    .line 137
    sget-object v5, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 138
    .line 139
    sget-object v6, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 140
    .line 141
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$0:Ljava/lang/Object;

    .line 142
    .line 143
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$1:Ljava/lang/Object;

    .line 144
    .line 145
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$2:Ljava/lang/Object;

    .line 146
    .line 147
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$3:Ljava/lang/Object;

    .line 148
    .line 149
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$4:Ljava/lang/Object;

    .line 150
    .line 151
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$5:Ljava/lang/Object;

    .line 152
    .line 153
    iput-object v13, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->L$6:Ljava/lang/Object;

    .line 154
    .line 155
    iput v12, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->I$0:I

    .line 156
    .line 157
    iput v7, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->I$1:I

    .line 158
    .line 159
    iput v7, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->I$2:I

    .line 160
    .line 161
    iput v7, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->I$3:I

    .line 162
    .line 163
    iput v12, v3, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;->label:I

    .line 164
    .line 165
    move v14, v7

    .line 166
    move-object v15, v13

    .line 167
    move-object/from16 v16, v0

    .line 168
    .line 169
    move/from16 v17, v7

    .line 170
    .line 171
    move/from16 p0, v7

    .line 172
    .line 173
    move-object/from16 p1, v3

    .line 174
    .line 175
    invoke-virtual/range {v4 .. v20}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    if-ne v0, v2, :cond_0

    .line 180
    .line 181
    return-object v2

    .line 182
    :cond_4
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 183
    .line 184
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 185
    .line 186
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    throw v0
.end method
