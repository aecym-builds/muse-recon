.class public final Lcom/facebook/aura/attribution/HatchAttributionReporter;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final ATTEMPT_BACKOFF_MS:J = 0x36ee80L

.field public static final DAY_MS:J = 0x5265c00L

.field public static final DEDUPE_SCHEMA_VERSION:I = 0x1

.field public static final INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionReporter;

.field public static final KEY_DEDUPE_SCHEMA_VERSION:Ljava/lang/String; = "dedupe_schema_version"

.field public static final KEY_FIRST_APP_LAUNCH_PROCESSED:Ljava/lang/String; = "first_app_launch_processed"

.field public static final KEY_LAST_ATTEMPT_MS:Ljava/lang/String; = "last_attempt_ms"

.field public static final KEY_LAST_EXISTING_SESSION_FIRE_MS:Ljava/lang/String; = "last_existing_session_fire_ms"

.field public static final KEY_PENDING_AUTH_EVENT:Ljava/lang/String; = "pending_auth_event"

.field public static final inFlight:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LX/ECD;",
            "Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;",
            ">;"
        }
    .end annotation
.end field

.field public static final isFamilyDeviceIdEnabled$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "isFamilyDeviceIdEnabled"

    .line 1
    .line 2
    const-string v1, "isFamilyDeviceIdEnabled()Z"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionReporter;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/attribution/MC$hatch_gtm;->enable_attribution_family_device_id:LX/0d8;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->isFamilyDeviceIdEnabled$delegate:LX/1zE;

    .line 26
    .line 27
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 30
    .line 31
    .line 32
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->inFlight:Ljava/util/Map;

    .line 33
    .line 34
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$onSettled(Lcom/facebook/aura/attribution/HatchAttributionReporter;Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->onSettled(Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;Z)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final buildSessionStartEvents(LX/AHE;)Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            ")",
            "Ljava/util/List<",
            "LX/ECD;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance v4, Ljava/util/ArrayList;

    .line 1
    .line 2
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 6
    .line 7
    .line 8
    move-result-wide v5

    .line 9
    invoke-direct {p0}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->peekPendingAuthEvent()LX/ECD;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    const-string v2, "last_existing_session_fire_ms"

    .line 24
    .line 25
    const-wide/16 v0, 0x0

    .line 26
    .line 27
    invoke-interface {v3, v2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 28
    .line 29
    .line 30
    move-result-wide v0

    .line 31
    sub-long/2addr v5, v0

    .line 32
    const-wide/32 v1, 0x5265c00

    .line 33
    .line 34
    .line 35
    cmp-long v0, v5, v1

    .line 36
    .line 37
    if-ltz v0, :cond_1

    .line 38
    .line 39
    sget-object v0, LX/ECD;->A02:LX/ECD;

    .line 40
    .line 41
    :cond_0
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    :cond_1
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 47
    .line 48
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    const-string v1, "first_app_launch_processed"

    .line 53
    .line 54
    const/4 v0, 0x0

    .line 55
    invoke-interface {v2, v1, v0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    sget-object v0, LX/ECD;->A03:LX/ECD;

    .line 62
    .line 63
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    :cond_2
    new-instance v3, Ljava/util/ArrayList;

    .line 67
    .line 68
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v4}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    :cond_3
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_5

    .line 80
    .line 81
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    sget-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->inFlight:Ljava/util/Map;

    .line 86
    .line 87
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 92
    .line 93
    if-eqz v0, :cond_4

    .line 94
    .line 95
    iget-object v0, v0, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->userSession:LX/AHE;

    .line 96
    .line 97
    :goto_1
    if-eq v0, p1, :cond_3

    .line 98
    .line 99
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_4
    const/4 v0, 0x0

    .line 104
    goto :goto_1

    .line 105
    :cond_5
    return-object v3
.end method

.method private final getPrefs()LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method private final isFamilyDeviceIdEnabled()Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/attribution/HatchAttributionReporter;->isFamilyDeviceIdEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    invoke-static {p0, v1, v0}, LX/8mk;->A1X(Ljava/lang/Object;LX/1zE;[LX/Dqa;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method private final declared-synchronized onSettled(Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;Z)V
    .locals 5

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p1, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->events:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v3

    .line 7
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, LX/ECD;

    .line 18
    .line 19
    sget-object v1, Lcom/facebook/aura/attribution/HatchAttributionReporter;->inFlight:Ljava/util/Map;

    .line 20
    .line 21
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    if-ne v0, p1, :cond_0

    .line 26
    .line 27
    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_1
    if-eqz p2, :cond_6

    .line 32
    .line 33
    sget-object v1, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 34
    .line 35
    iget-object v0, p1, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->userSession:LX/AHE;

    .line 36
    .line 37
    invoke-virtual {v1, v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_6

    .line 42
    .line 43
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 44
    .line 45
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 46
    .line 47
    invoke-static {v0, v1}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    iget-object v0, p1, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;->events:Ljava/util/List;

    .line 52
    .line 53
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    :cond_2
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_5

    .line 62
    .line 63
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, LX/ECD;

    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    const/4 v1, 0x1

    .line 74
    const/4 v0, 0x0

    .line 75
    if-eq v2, v0, :cond_4

    .line 76
    .line 77
    if-eq v2, v1, :cond_4

    .line 78
    .line 79
    const/4 v0, 0x3

    .line 80
    if-eq v2, v0, :cond_3

    .line 81
    .line 82
    const/4 v0, 0x5

    .line 83
    if-ne v2, v0, :cond_2

    .line 84
    .line 85
    const-string v0, "first_app_launch_processed"

    .line 86
    .line 87
    invoke-virtual {v4, v0, v1}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_3
    const-string v2, "last_existing_session_fire_ms"

    .line 92
    .line 93
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 94
    .line 95
    .line 96
    move-result-wide v0

    .line 97
    invoke-virtual {v4, v2, v0, v1}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_4
    const-string v0, "pending_auth_event"

    .line 102
    .line 103
    invoke-virtual {v4, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_5
    invoke-virtual {v4}, LX/Df3;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 108
    .line 109
    .line 110
    :cond_6
    monitor-exit p0

    .line 111
    return-void

    .line 112
    :catchall_0
    move-exception v0

    .line 113
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 114
    throw v0
.end method

.method private final peekPendingAuthEvent()LX/ECD;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-string v0, "pending_auth_event"

    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    invoke-interface {v1, v0, p0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const-string v0, "LOGIN"

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    sget-object p0, LX/ECD;->A04:LX/ECD;

    .line 24
    .line 25
    :cond_0
    return-object p0

    .line 26
    :cond_1
    const-string v0, "REGISTRATION"

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    sget-object p0, LX/ECD;->A05:LX/ECD;

    .line 35
    .line 36
    return-object p0
.end method

.method private final reArmIfDedupeSchemaStale()V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v3}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const/4 v0, 0x0

    .line 9
    const-string v2, "dedupe_schema_version"

    .line 10
    .line 11
    invoke-interface {v1, v2, v0}, LX/BVu;->getInt(Ljava/lang/String;I)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x1

    .line 16
    if-ge v0, v1, :cond_0

    .line 17
    .line 18
    invoke-static {v3, p0}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, LX/Df3;->A06()V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 26
    .line 27
    .line 28
    invoke-static {v3, p0}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0, v2, v1}, LX/Df3;->AZA(Ljava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
.end method


# virtual methods
.method public final declared-synchronized clearDedupeStateAndReport(LX/AHE;)V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, LX/Df3;->A06()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 25
    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->inFlight:Ljava/util/Map;

    .line 28
    .line 29
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, p1}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->reportSessionStart(LX/AHE;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    .line 34
    .line 35
    :cond_0
    monitor-exit p0

    .line 36
    return-void

    .line 37
    :catchall_0
    move-exception v0

    .line 38
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 39
    throw v0
.end method

.method public final declared-synchronized recordPendingAuthEvent(Lcom/facebook/aura/attribution/HatchAttributionReporter$AuthEvent;)V
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->reArmIfDedupeSchemaStale()V

    .line 6
    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 11
    .line 12
    invoke-static {v0, v1}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const-string v1, "pending_auth_event"

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v2, v1, v0}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const-string v0, "last_attempt_ms"

    .line 26
    .line 27
    invoke-virtual {v2, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, LX/Df3;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    .line 32
    .line 33
    monitor-exit p0

    .line 34
    return-void

    .line 35
    :catchall_0
    move-exception v0

    .line 36
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 37
    throw v0
.end method

.method public final declared-synchronized reportSessionStart(LX/AHE;)V
    .locals 14

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    move-object v10, p1

    .line 3
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_3

    .line 13
    .line 14
    invoke-direct {p0}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->reArmIfDedupeSchemaStale()V

    .line 15
    .line 16
    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    sget-object v7, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 22
    .line 23
    sget-object v6, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->ATTRIBUTION:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 24
    .line 25
    invoke-virtual {v7, v6}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    const-string v5, "last_attempt_ms"

    .line 30
    .line 31
    const-wide/16 v2, 0x0

    .line 32
    .line 33
    invoke-interface {v4, v5, v2, v3}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 34
    .line 35
    .line 36
    move-result-wide v2

    .line 37
    sub-long v8, v0, v2

    .line 38
    .line 39
    const-wide/32 v3, 0x36ee80

    .line 40
    .line 41
    .line 42
    cmp-long v2, v8, v3

    .line 43
    .line 44
    if-ltz v2, :cond_3

    .line 45
    .line 46
    invoke-direct {p0, p1}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->buildSessionStartEvents(LX/AHE;)Ljava/util/List;

    .line 47
    .line 48
    .line 49
    move-result-object v12

    .line 50
    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-nez v2, :cond_3

    .line 55
    .line 56
    new-instance v13, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;

    .line 57
    .line 58
    invoke-direct {v13, p1, v12}, Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;-><init>(LX/AHE;Ljava/util/List;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v6, v7}, LX/Df3;->A01(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;)LX/Df3;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-virtual {v2, v5, v0, v1}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v2}, LX/Df3;->apply()V

    .line 69
    .line 70
    .line 71
    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_0

    .line 80
    .line 81
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    check-cast v1, LX/ECD;

    .line 86
    .line 87
    sget-object v0, Lcom/facebook/aura/attribution/HatchAttributionReporter;->inFlight:Ljava/util/Map;

    .line 88
    .line 89
    invoke-interface {v0, v1, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_0
    sget-object v0, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->Companion:Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;

    .line 94
    .line 95
    invoke-virtual {v0, p1}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-virtual {v0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->isStandardVm()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_1

    .line 104
    .line 105
    invoke-direct {p0}, Lcom/facebook/aura/attribution/HatchAttributionReporter;->isFamilyDeviceIdEnabled()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    const/4 v9, 0x1

    .line 110
    if-nez v0, :cond_2

    .line 111
    .line 112
    :cond_1
    const/4 v9, 0x0

    .line 113
    :cond_2
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 114
    .line 115
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    new-instance v11, LX/ECM;

    .line 120
    .line 121
    invoke-direct {v11, v0}, LX/ECM;-><init>(LX/ES4;)V

    .line 122
    .line 123
    .line 124
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 125
    .line 126
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 131
    .line 132
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getLowPriorityExecutor()Ljava/util/concurrent/ExecutorService;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    new-instance v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;

    .line 137
    .line 138
    invoke-direct {v0, v2, v1, v11}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;-><init>(Landroid/content/Context;Ljava/util/concurrent/Executor;LX/ECM;)V

    .line 139
    .line 140
    .line 141
    new-instance v8, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;

    .line 142
    .line 143
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/attribution/HatchAttributionReporter$reportSessionStart$2;-><init>(ZLX/AHE;LX/ECM;Ljava/util/List;Lcom/facebook/aura/attribution/HatchAttributionReporter$Batch;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v0, v8}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->fetchAdvertisingIdInfo(LX/JDN;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 147
    .line 148
    .line 149
    :cond_3
    monitor-exit p0

    .line 150
    return-void

    .line 151
    :catchall_0
    move-exception v0

    .line 152
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 153
    throw v0
.end method
