.class public final Lcom/facebook/aura/attribution/HatchAttributionEventsClient;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/attribution/HatchAttributionEventsClient$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchAttributionEventsClient"


# instance fields
.field public final debugLogger:LX/ECM;

.field public final onSettled:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final scope:LX/1EL;

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->Companion:Lcom/facebook/aura/attribution/HatchAttributionEventsClient$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;LX/ECM;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "LX/ECM;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->debugLogger:LX/ECM;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->onSettled:LX/JDM;

    .line 11
    .line 12
    invoke-static {}, LX/8mk;->A0z()LX/EQC;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->scope:LX/1EL;

    .line 17
    .line 18
    return-void
.end method

.method public static final synthetic access$getOnSettled$p(Lcom/facebook/aura/attribution/HatchAttributionEventsClient;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->onSettled:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/attribution/HatchAttributionEventsClient;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method private final eventName(LX/ECD;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return-object p0

    .line 9
    :pswitch_0
    const-string p0, "LOGIN"

    .line 10
    .line 11
    return-object p0

    .line 12
    :pswitch_1
    const-string p0, "REGISTRATION"

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_2
    const-string p0, "CONFIRMATION"

    .line 16
    .line 17
    return-object p0

    .line 18
    :pswitch_3
    const-string p0, "EXISTING_SESSION_LOGIN"

    .line 19
    .line 20
    return-object p0

    .line 21
    :pswitch_4
    const-string p0, "RESURRECTION"

    .line 22
    .line 23
    return-object p0

    .line 24
    :pswitch_5
    const-string p0, "FIRST_APP_LAUNCH"

    .line 25
    .line 26
    return-object p0

    .line 27
    nop

    .line 28
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method


# virtual methods
.method public reportAdid(Ljava/lang/String;LX/ECY;)V
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string p1, "HatchAttributionEventsClient"

    .line 5
    .line 6
    const-string p0, "reportAdid is unsupported: no Stefi endpoint for report_advertiser_id"

    .line 7
    .line 8
    invoke-static {p1, p0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    const-string p0, "report_advertiser_id has no Stefi endpoint"

    .line 13
    .line 14
    invoke-interface {p2, p0, p1}, LX/ECY;->ATU(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public send(Ljava/util/List;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;LX/ECY;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "LX/ECD;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/ECY;",
            ")V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object/from16 v10, p6

    .line 2
    .line 3
    invoke-static {p1, v0, v10}, LX/003;->A10(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    new-instance v7, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    move-object v9, p0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    check-cast v0, LX/ECD;

    .line 27
    .line 28
    invoke-direct {p0, v0}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->eventName(LX/ECD;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    const/4 v5, 0x0

    .line 47
    const/4 v3, 0x1

    .line 48
    const/4 p0, 0x0

    .line 49
    if-eq v1, v0, :cond_4

    .line 50
    .line 51
    new-instance v4, Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 54
    .line 55
    .line 56
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    :cond_2
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_3

    .line 65
    .line 66
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    move-object v0, v1

    .line 71
    check-cast v0, LX/ECD;

    .line 72
    .line 73
    invoke-direct {v9, v0}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->eventName(LX/ECD;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-nez v0, :cond_2

    .line 78
    .line 79
    invoke-virtual {v4, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :cond_3
    iget-object v2, v9, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->debugLogger:LX/ECM;

    .line 84
    .line 85
    const-string v0, "unsupported_event_types"

    .line 86
    .line 87
    invoke-static {v0, p0, p0, v4}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    const-string v0, "error"

    .line 92
    .line 93
    invoke-static {v1, v0, v2}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 94
    .line 95
    .line 96
    const-string v1, ", "

    .line 97
    .line 98
    const-string v0, ""

    .line 99
    .line 100
    invoke-static {v1, v0, v0, v4, p0}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    const-string v1, "HatchAttributionEventsClient"

    .line 109
    .line 110
    const-string v0, "Dropping event types with no wire name: %s"

    .line 111
    .line 112
    invoke-static {v1, v0, v2}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :cond_4
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_5

    .line 120
    .line 121
    iget-object v0, v9, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->onSettled:LX/JDM;

    .line 122
    .line 123
    invoke-static {v3, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 124
    .line 125
    .line 126
    const-string v0, "No attribution events to report"

    .line 127
    .line 128
    invoke-interface {v10, v0, p0}, LX/ECY;->ATU(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :cond_5
    if-nez p3, :cond_6

    .line 133
    .line 134
    if-eqz p2, :cond_6

    .line 135
    .line 136
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-nez v0, :cond_7

    .line 141
    .line 142
    :cond_6
    const/4 v5, 0x1

    .line 143
    :cond_7
    invoke-static {v7}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 148
    .line 149
    .line 150
    move-result-object v3

    .line 151
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    if-eqz v0, :cond_9

    .line 156
    .line 157
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    check-cast v2, Ljava/lang/String;

    .line 162
    .line 163
    move-object v1, p2

    .line 164
    if-eqz v5, :cond_8

    .line 165
    .line 166
    move-object v1, p0

    .line 167
    :cond_8
    new-instance v0, Lcom/facebook/aura/attribution/AttributionEventJson;

    .line 168
    .line 169
    move-object/from16 v6, p5

    .line 170
    .line 171
    invoke-direct {v0, v2, v1, v5, v6}, Lcom/facebook/aura/attribution/AttributionEventJson;-><init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    goto :goto_2

    .line 178
    :cond_9
    invoke-static {}, LX/Ffc;->A00()Ljava/util/UUID;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    new-instance v8, Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;

    .line 187
    .line 188
    invoke-direct {v8, v4, v0}, Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    iget-object v0, v9, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->scope:LX/1EL;

    .line 192
    .line 193
    new-instance v6, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;

    .line 194
    .line 195
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient$send$1;-><init>(Ljava/util/List;Lcom/facebook/aura/attribution/ReportAttributionEventsRequestJson;Lcom/facebook/aura/attribution/HatchAttributionEventsClient;LX/ECY;LX/2M4;)V

    .line 196
    .line 197
    .line 198
    invoke-static {v6, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 199
    .line 200
    .line 201
    return-void
.end method
