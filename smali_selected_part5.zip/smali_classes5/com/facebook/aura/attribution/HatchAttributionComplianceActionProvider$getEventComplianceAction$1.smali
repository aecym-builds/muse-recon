.class public final Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.attribution.HatchAttributionComplianceActionProvider$getEventComplianceAction$1"
    f = "HatchAttributionComplianceActionProvider.kt"
    l = {
        0x4d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $callback:LX/ECg;

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;LX/ECg;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;",
            "LX/ECg;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->$callback:LX/ECg;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->$callback:LX/ECg;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;-><init>(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;LX/ECg;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 0
    move-object/from16 v2, p1

    .line 1
    .line 2
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v4, p0

    .line 5
    .line 6
    iget v0, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->label:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    const/4 v9, 0x0

    .line 10
    if-eqz v0, :cond_8

    .line 11
    .line 12
    if-ne v0, v1, :cond_9

    .line 13
    .line 14
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    check-cast v2, LX/2PJ;

    .line 18
    .line 19
    iget-object v2, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_0
    iget-object v6, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;

    .line 22
    .line 23
    iget-object v4, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->$callback:LX/ECg;

    .line 24
    .line 25
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    if-nez v5, :cond_7

    .line 30
    .line 31
    check-cast v2, Lcom/facebook/aura/attribution/AttributionComplianceActionResponseJson;

    .line 32
    .line 33
    iget-object v0, v2, Lcom/facebook/aura/attribution/AttributionComplianceActionResponseJson;->action:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v6, v0}, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->access$toComplianceAction(Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;Ljava/lang/String;)LX/ECS;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    const-string v3, "HatchAttributionCompliance"

    .line 40
    .line 41
    if-nez v8, :cond_2

    .line 42
    .line 43
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    const-string v0, "Unsupported compliance action: %s"

    .line 48
    .line 49
    invoke-static {v3, v0, v1}, LX/FnY;->A0F(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v0, v6, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->onSettled:LX/JDM;

    .line 53
    .line 54
    invoke-static {v9, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 55
    .line 56
    .line 57
    iget-object v1, v2, Lcom/facebook/aura/attribution/AttributionComplianceActionResponseJson;->action:Ljava/lang/String;

    .line 58
    .line 59
    const-string v0, "Unsupported compliance action: "

    .line 60
    .line 61
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    const/4 v3, 0x0

    .line 66
    check-cast v4, LX/ECT;

    .line 67
    .line 68
    iget-object v0, v4, LX/ECT;->A01:LX/ECN;

    .line 69
    .line 70
    iget-object v2, v0, LX/ECN;->A04:LX/ECM;

    .line 71
    .line 72
    if-eqz v2, :cond_1

    .line 73
    .line 74
    const-string v1, "get_compliance_action_failure"

    .line 75
    .line 76
    iget-object v0, v4, LX/ECT;->A00:Ljava/util/List;

    .line 77
    .line 78
    invoke-static {v1, v5, v3, v0}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    :goto_0
    const-string v0, "error"

    .line 83
    .line 84
    invoke-static {v1, v0, v2}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 85
    .line 86
    .line 87
    :cond_1
    :goto_1
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 88
    .line 89
    return-object v3

    .line 90
    :cond_2
    const-string v2, "Compliance action: %s"

    .line 91
    .line 92
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-static {v0, v3, v2}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    sget-object v0, LX/ECS;->A03:LX/ECS;

    .line 100
    .line 101
    if-ne v8, v0, :cond_3

    .line 102
    .line 103
    iget-object v0, v6, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->onSettled:LX/JDM;

    .line 104
    .line 105
    invoke-static {v9, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 106
    .line 107
    .line 108
    :cond_3
    check-cast v4, LX/ECT;

    .line 109
    .line 110
    iget-object v2, v4, LX/ECT;->A01:LX/ECN;

    .line 111
    .line 112
    iget-object v5, v2, LX/ECN;->A04:LX/ECM;

    .line 113
    .line 114
    if-eqz v5, :cond_4

    .line 115
    .line 116
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v7

    .line 120
    iget-object v6, v4, LX/ECT;->A00:Ljava/util/List;

    .line 121
    .line 122
    const-string v3, "get_compliance_action_success"

    .line 123
    .line 124
    invoke-static {v7, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 125
    .line 126
    .line 127
    const/4 v0, 0x0

    .line 128
    invoke-static {v3, v7, v0, v6}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    const-string v0, "info"

    .line 133
    .line 134
    invoke-static {v3, v0, v5}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 135
    .line 136
    .line 137
    :cond_4
    sget-object v0, LX/ECS;->A04:LX/ECS;

    .line 138
    .line 139
    if-ne v8, v0, :cond_5

    .line 140
    .line 141
    iget-object v7, v4, LX/ECT;->A00:Ljava/util/List;

    .line 142
    .line 143
    iget-object v0, v2, LX/ECN;->A01:Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;

    .line 144
    .line 145
    iget-object v8, v0, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->adid:Ljava/lang/String;

    .line 146
    .line 147
    iget-object v6, v2, LX/ECN;->A02:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 148
    .line 149
    const/4 v10, 0x0

    .line 150
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->getFamilyDeviceId()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v11

    .line 154
    new-instance v12, LX/ECR;

    .line 155
    .line 156
    invoke-direct {v12, v7, v2}, LX/ECR;-><init>(Ljava/util/List;LX/ECN;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual/range {v6 .. v12}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->send(Ljava/util/List;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;LX/ECY;)V

    .line 160
    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_5
    sget-object v0, LX/ECS;->A02:LX/ECS;

    .line 164
    .line 165
    if-ne v8, v0, :cond_1

    .line 166
    .line 167
    iget-object v6, v4, LX/ECT;->A00:Ljava/util/List;

    .line 168
    .line 169
    if-eqz v5, :cond_6

    .line 170
    .line 171
    const-string v4, "buffer_events"

    .line 172
    .line 173
    const-string v3, "server_side"

    .line 174
    .line 175
    const/4 v0, 0x0

    .line 176
    invoke-static {v4, v3, v0, v6}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    const-string v0, "info"

    .line 181
    .line 182
    invoke-static {v3, v0, v5}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 183
    .line 184
    .line 185
    :cond_6
    const/4 v7, 0x0

    .line 186
    iget-object v5, v2, LX/ECN;->A02:Lcom/facebook/aura/attribution/HatchAttributionEventsClient;

    .line 187
    .line 188
    iget-object v0, v2, LX/ECN;->A01:Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;

    .line 189
    .line 190
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/HatchAttributionDeviceProperties;->getFamilyDeviceId()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v10

    .line 194
    new-instance v0, LX/ECR;

    .line 195
    .line 196
    invoke-direct {v0, v6, v2}, LX/ECR;-><init>(Ljava/util/List;LX/ECN;)V

    .line 197
    .line 198
    .line 199
    move-object v9, v7

    .line 200
    move v8, v1

    .line 201
    move-object v11, v0

    .line 202
    invoke-virtual/range {v5 .. v11}, Lcom/facebook/aura/attribution/HatchAttributionEventsClient;->send(Ljava/util/List;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;LX/ECY;)V

    .line 203
    .line 204
    .line 205
    goto :goto_1

    .line 206
    :cond_7
    iget-object v0, v6, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->onSettled:LX/JDM;

    .line 207
    .line 208
    invoke-static {v9, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 209
    .line 210
    .line 211
    sget-object v0, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionComplianceAction;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionComplianceAction;

    .line 212
    .line 213
    invoke-virtual {v0}, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionComplianceAction;->getValue()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    invoke-static {v0, v5}, Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;->logAttributionFailure(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 218
    .line 219
    .line 220
    invoke-static {v5}, Lcom/facebook/aura/attribution/HatchAttributionEventsClientKt;->attributionFailureMessage(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v3

    .line 224
    check-cast v4, LX/ECT;

    .line 225
    .line 226
    invoke-static {v3, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 227
    .line 228
    .line 229
    iget-object v0, v4, LX/ECT;->A01:LX/ECN;

    .line 230
    .line 231
    iget-object v2, v0, LX/ECN;->A04:LX/ECM;

    .line 232
    .line 233
    if-eqz v2, :cond_1

    .line 234
    .line 235
    const-string v1, "get_compliance_action_failure"

    .line 236
    .line 237
    iget-object v0, v4, LX/ECT;->A00:Ljava/util/List;

    .line 238
    .line 239
    invoke-static {v1, v3, v5, v0}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v1

    .line 243
    goto/16 :goto_0

    .line 244
    .line 245
    :cond_8
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    sget-object v7, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 249
    .line 250
    sget-object v10, Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionComplianceAction;->INSTANCE:Lcom/facebook/aura/attribution/AttributionStefiPath$AttributionComplianceAction;

    .line 251
    .line 252
    sget-object v11, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 253
    .line 254
    iget-object v0, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->this$0:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;

    .line 255
    .line 256
    iget-object v0, v0, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider;->userSession:LX/AHE;

    .line 257
    .line 258
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 259
    .line 260
    .line 261
    move-result-object v14

    .line 262
    sget-object v8, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1$invokeSuspend$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1$invokeSuspend$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 263
    .line 264
    const/4 v12, 0x0

    .line 265
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$0:Ljava/lang/Object;

    .line 266
    .line 267
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$1:Ljava/lang/Object;

    .line 268
    .line 269
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$2:Ljava/lang/Object;

    .line 270
    .line 271
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$3:Ljava/lang/Object;

    .line 272
    .line 273
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$4:Ljava/lang/Object;

    .line 274
    .line 275
    iput-object v12, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->L$5:Ljava/lang/Object;

    .line 276
    .line 277
    iput v1, v4, Lcom/facebook/aura/attribution/HatchAttributionComplianceActionProvider$getEventComplianceAction$1;->label:I

    .line 278
    .line 279
    move-object v13, v12

    .line 280
    move-object v15, v14

    .line 281
    move-object/from16 p1, v4

    .line 282
    .line 283
    move-object/from16 p0, v0

    .line 284
    .line 285
    invoke-virtual/range {v7 .. v17}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    move-result-object v2

    .line 289
    if-ne v2, v3, :cond_0

    .line 290
    .line 291
    return-object v3

    .line 292
    :cond_9
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 293
    .line 294
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 295
    .line 296
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    throw v0
.end method
