.class public final Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ENTRYPOINT_QUERY_PARAM:Ljava/lang/String; = "entrypoint"

.field public static final INSTANCE:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;

.field public static final MAX_TRACKED_NOTIFICATION_IMPRESSIONS:I = 0x100

.field public static final TAG:Ljava/lang/String; = "HatchNMEAttribution"

.field public static final entrypointsByValue$delegate:Lkotlin/Lazy;

.field public static final loggedNotificationImpressions:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$loggedNotificationImpressions$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->INSTANCE:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$entrypointsByValue$2;->INSTANCE:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$entrypointsByValue$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->entrypointsByValue$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$loggedNotificationImpressions$1;

    .line 16
    .line 17
    invoke-direct {v0}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$loggedNotificationImpressions$1;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->loggedNotificationImpressions:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$loggedNotificationImpressions$1;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getEntrypointsByValue()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LX/8OS;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->entrypointsByValue$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Ljava/util/Map;

    .line 7
    .line 8
    return-object p0
.end method


# virtual methods
.method public final entrypointFromUri$fbandroid_express_aura_java_com_facebook_aura_analytics_waterfall_waterfall(Landroid/net/Uri;)LX/8OS;
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/net/Uri;->isHierarchical()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const-string v0, "entrypoint"

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0, v0}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->fromRawValue(Ljava/lang/String;)LX/8OS;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0

    .line 22
    :cond_0
    return-object v1
.end method

.method public final fromRawValue(Ljava/lang/String;)LX/8OS;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    sget-object p0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->entrypointsByValue$delegate:Lkotlin/Lazy;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Ljava/util/Map;

    .line 9
    .line 10
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, LX/8OS;

    .line 15
    .line 16
    return-object p0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    return-object p0
.end method

.method public final logClick(Landroid/net/Uri;)V
    .locals 2

    .line 0
    :try_start_0
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->entrypointFromUri$fbandroid_express_aura_java_com_facebook_aura_analytics_waterfall_waterfall(Landroid/net/Uri;)LX/8OS;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    const/4 p0, 0x1

    .line 7
    const/4 v1, 0x0

    .line 8
    new-instance v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;

    .line 9
    .line 10
    invoke-direct {v0, v1, p0, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;-><init>(LX/ES4;ILX/04f;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, p1, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logClick(LX/8OS;Ljava/util/Map;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception p0

    .line 18
    const-string v1, "notification click attribution logger threw"

    .line 19
    .line 20
    const-string v0, "HatchNMEAttribution"

    .line 21
    .line 22
    invoke-static {v0, p0, v1}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final logImpression(Landroid/net/Uri;Ljava/lang/String;)V
    .locals 5

    .line 0
    const/4 v4, 0x1

    .line 1
    invoke-static {p2, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->entrypointFromUri$fbandroid_express_aura_java_com_facebook_aura_analytics_waterfall_waterfall(Landroid/net/Uri;)LX/8OS;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    if-eqz v3, :cond_1

    .line 9
    .line 10
    sget-object v2, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution;->loggedNotificationImpressions:Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointAttribution$loggedNotificationImpressions$1;

    .line 11
    .line 12
    monitor-enter v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    :try_start_1
    invoke-virtual {v2, p2}, Ljava/util/AbstractMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    new-instance v0, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;

    .line 21
    .line 22
    invoke-direct {v0, v1, v4, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;-><init>(LX/ES4;ILX/04f;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v3, v1}, Lcom/facebook/aura/analytics/waterfall/HatchNMEEntrypointLogger;->logImpression(LX/8OS;Ljava/util/Map;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 32
    .line 33
    invoke-virtual {v2, p2, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 34
    .line 35
    .line 36
    :cond_0
    :try_start_2
    monitor-exit v2

    .line 37
    return-void

    .line 38
    :catchall_0
    move-exception v0

    .line 39
    monitor-exit v2

    .line 40
    throw v0

    .line 41
    :cond_1
    return-void
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 42
    :catch_0
    move-exception v2

    .line 43
    const-string v1, "HatchNMEAttribution"

    .line 44
    .line 45
    const-string v0, "notification impression attribution logger threw"

    .line 46
    .line 47
    invoke-static {v1, v2, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-void
.end method
