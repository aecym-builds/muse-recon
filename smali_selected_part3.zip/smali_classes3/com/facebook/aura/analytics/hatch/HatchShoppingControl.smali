.class public final enum Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CART_OPEN:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CART_PROVIDER_LINK:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CART_QUANTITY_STEP:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CART_REQUEST_CHECKOUT:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CART_UPDATE:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

.field public static final enum CHECKOUT_OFFER_LINK:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;


# instance fields
.field public final action:Ljava/lang/String;

.field public final controlRole:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 0
    const-string v2, "CART_OPEN"

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    const-string v0, "open_cart"

    .line 4
    .line 5
    const-string v3, "primary"

    .line 6
    .line 7
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 8
    .line 9
    invoke-direct {v5, v2, v1, v0, v3}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CART_OPEN:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    const-string v1, "request_checkout_assistance"

    .line 16
    .line 17
    const-string v0, "CART_REQUEST_CHECKOUT"

    .line 18
    .line 19
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 20
    .line 21
    invoke-direct {v6, v0, v2, v1, v3}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CART_REQUEST_CHECKOUT:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 25
    .line 26
    const-string v2, "secondary"

    .line 27
    .line 28
    const-string v1, "CART_PROVIDER_LINK"

    .line 29
    .line 30
    const/4 v0, 0x2

    .line 31
    const-string v4, "open_provider_cart"

    .line 32
    .line 33
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 34
    .line 35
    invoke-direct {v7, v1, v0, v4, v2}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CART_PROVIDER_LINK:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 39
    .line 40
    const/4 v2, 0x3

    .line 41
    const-string v1, "shopping_cart_update"

    .line 42
    .line 43
    const-string v0, "CART_UPDATE"

    .line 44
    .line 45
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 46
    .line 47
    invoke-direct {v8, v0, v2, v1, v3}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CART_UPDATE:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 51
    .line 52
    const-string v3, "shopping_cart_quantity_step"

    .line 53
    .line 54
    const-string v2, "stepper"

    .line 55
    .line 56
    const-string v1, "CART_QUANTITY_STEP"

    .line 57
    .line 58
    const/4 v0, 0x4

    .line 59
    new-instance v9, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 60
    .line 61
    invoke-direct {v9, v1, v0, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CART_QUANTITY_STEP:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 65
    .line 66
    const/4 v2, 0x5

    .line 67
    const-string v1, "inline_link"

    .line 68
    .line 69
    const-string v0, "CHECKOUT_OFFER_LINK"

    .line 70
    .line 71
    new-instance v10, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 72
    .line 73
    invoke-direct {v10, v0, v2, v4, v1}, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->CHECKOUT_OFFER_LINK:Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 77
    .line 78
    filled-new-array/range {v5 .. v10}, [Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 83
    .line 84
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->$ENTRIES:LX/0vk;

    .line 89
    .line 90
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->action:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->controlRole:Ljava/lang/String;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getAction()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->action:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getControlRole()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingControl;->controlRole:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
