.class public final Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getDevice()Lcom/facebook/aura/analytics/hatch/HatchFormFactor;
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->access$getDevice$delegate$cp()Lkotlin/Lazy;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 9
    .line 10
    return-object p0
.end method
