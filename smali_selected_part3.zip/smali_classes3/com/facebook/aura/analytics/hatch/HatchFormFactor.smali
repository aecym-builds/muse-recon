.class public final enum Lcom/facebook/aura/analytics/hatch/HatchFormFactor;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchFormFactor;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final enum CAR:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final Companion:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;

.field public static final enum FOLDABLE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final enum PHONE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final enum TABLET:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final enum WATCH:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

.field public static final device$delegate:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Lcom/facebook/aura/analytics/hatch/HatchFormFactor;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "phone"

    .line 2
    .line 3
    const-string v0, "PHONE"

    .line 4
    .line 5
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 6
    .line 7
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->PHONE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "foldable"

    .line 14
    .line 15
    const-string v0, "FOLDABLE"

    .line 16
    .line 17
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 18
    .line 19
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->FOLDABLE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "tablet"

    .line 26
    .line 27
    const-string v0, "TABLET"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->TABLET:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "watch"

    .line 38
    .line 39
    const-string v0, "WATCH"

    .line 40
    .line 41
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 42
    .line 43
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->WATCH:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 47
    .line 48
    const/4 v3, 0x4

    .line 49
    const-string v2, "car"

    .line 50
    .line 51
    const-string v1, "CAR"

    .line 52
    .line 53
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 54
    .line 55
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->CAR:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 59
    .line 60
    filled-new-array {v7, v6, v5, v4, v0}, [Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 65
    .line 66
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->$ENTRIES:LX/0vk;

    .line 71
    .line 72
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;

    .line 73
    .line 74
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->Companion:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;

    .line 78
    .line 79
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;

    .line 80
    .line 81
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->device$delegate:Lkotlin/Lazy;

    .line 86
    .line 87
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static final synthetic access$getDevice$delegate$cp()Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->device$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchFormFactor;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchFormFactor;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchFormFactor;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
