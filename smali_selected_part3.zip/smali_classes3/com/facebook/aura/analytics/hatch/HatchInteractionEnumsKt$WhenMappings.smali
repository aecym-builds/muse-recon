.class public abstract synthetic Lcom/facebook/aura/analytics/hatch/HatchInteractionEnumsKt$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->values()[Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->FEED_CARD:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 8
    .line 9
    invoke-static {v0, v1}, LX/007;->A1G(Ljava/lang/Enum;[I)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    .line 12
    :catch_0
    :try_start_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->NEW_GOAL:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A1H(Ljava/lang/Enum;[I)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 15
    .line 16
    .line 17
    :catch_1
    :try_start_2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->GOAL_SUBGOAL:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 18
    .line 19
    invoke-static {v0, v1}, LX/007;->A1I(Ljava/lang/Enum;[I)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 20
    .line 21
    .line 22
    :catch_2
    :try_start_3
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->GOAL_DISCUSS:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 23
    .line 24
    invoke-static {v0, v1}, LX/007;->A1J(Ljava/lang/Enum;[I)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 25
    .line 26
    .line 27
    :catch_3
    :try_start_4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->NONE:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 28
    .line 29
    invoke-static {v0, v1}, LX/007;->A1K(Ljava/lang/Enum;[I)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 30
    .line 31
    .line 32
    :catch_4
    :try_start_5
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->CREATE_SPACE:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/007;->A1L(Ljava/lang/Enum;[I)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 35
    .line 36
    .line 37
    :catch_5
    :try_start_6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->CONNECTED_APPS:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 38
    .line 39
    invoke-static {v0, v1}, LX/3Rr;->A17(Ljava/lang/Enum;[I)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 40
    .line 41
    .line 42
    :catch_6
    :try_start_7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->SHARE_INTENT:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 43
    .line 44
    invoke-static {v0, v1}, LX/3Rr;->A18(Ljava/lang/Enum;[I)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 45
    .line 46
    .line 47
    :catch_7
    :try_start_8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->PROCESS_TEXT:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 48
    .line 49
    invoke-static {v0, v1}, LX/603;->A1E(Ljava/lang/Enum;[I)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 50
    .line 51
    .line 52
    :catch_8
    :try_start_9
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->ASSIST:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 53
    .line 54
    invoke-static {v0, v1}, LX/603;->A1F(Ljava/lang/Enum;[I)V
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 55
    .line 56
    .line 57
    :catch_9
    :try_start_a
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->FLOCK_FEED_CARD:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 58
    .line 59
    invoke-static {v0, v1}, LX/603;->A1G(Ljava/lang/Enum;[I)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    .line 60
    .line 61
    .line 62
    :catch_a
    :try_start_b
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->DEEP_LINK:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 63
    .line 64
    invoke-static {v0, v1}, LX/603;->A1H(Ljava/lang/Enum;[I)V
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    .line 65
    .line 66
    .line 67
    :catch_b
    :try_start_c
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->CARD_AUTO_SEND:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 68
    .line 69
    invoke-static {v0, v1}, LX/603;->A1I(Ljava/lang/Enum;[I)V
    :try_end_c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_c} :catch_c

    .line 70
    .line 71
    .line 72
    :catch_c
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionEnumsKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 73
    .line 74
    return-void
.end method
