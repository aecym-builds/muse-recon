.class public final enum Lcom/facebook/aura/analytics/hatch/HatchScreen;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ACCOUNTS_CENTER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ADD_HOME_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum AGENT_PERMISSION_MULTI_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ANNOUNCEMENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ARTIFACT_CANVAS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ARTIFACT_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ARTIFACT_DOCUMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ARTIFACT_PREVIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BIOMETRICS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BLUETOOTH_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BOT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BROWSER_OVERLAY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum BUY_MORE_CREDITS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CALENDAR_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CALL_LOG_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CANCEL_SUBSCRIPTION_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CARD_VAULT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CAR_CALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CAR_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CCV_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CHANNELS_MESSENGER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CHANNELS_TELEGRAM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CHANNELS_WHATSAPP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CHAT_THREAD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_ADD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_INVITE_AGREEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_RECEIVED_ITEM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_SHARE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTIONS_SHARE_STATUS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_ACCEPT_INVITE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_ACCEPT_LEVEL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_ADD_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_PAIRING_STATUS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTION_RULE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_API_KEY_INPUT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_AUTH_WEB_VIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_CONSENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_OAUTH_CREDENTIAL_INPUT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONNECTOR_PERMISSIONS_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONTACTS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONTACT_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONTACT_SUPPORT_SUCCESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CONVERSATION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CREDITS_MAIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_DATA_CHOICE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_DELETE_DATA_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_JOIN_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_MIGRATION_DONE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_OFF_WAITLIST_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_ON_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_CREATE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_ENTER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_HELP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_LOCKED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_PIN_LOOKUP_FAILED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_REPLACEMENT_MAINTENANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_REVIEW_ARTIFACTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_SUBSCRIBE_INTRO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_SUBSCRIPTION_ENDED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_SWITCH_INTRO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_SWITCH_PROGRESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_SWITCH_UNAVAILABLE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_TRANSFER_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum CVM_TRANSFER_PROGRESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DATA_EXPORT_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DEFAULT_ASSISTANT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DEVICES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DEVICE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DEVICE_PAIRING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum DOWNLOAD_AGENT_DATA_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum EMAIL_SETUP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FEEDBACK_FORM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FEED_EDIT_PROMPT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FEED_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FEED_STATUS_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FILE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FLIGHT_FARES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FLIGHT_ITINERARY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FLIGHT_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum FULL_SCREEN_MAP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum GOALS_COMPLETED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum GOALS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum GOAL_CREATION_BOTTOM_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum GOAL_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HELP_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HOME_LINK_ORDER_BLOCKED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HOME_LINK_ORDER_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HOME_LINK_ORDER_INFO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HOTEL_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum HOTEL_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum IDEAS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum IDEA_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum IDEA_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum IMPORT_MEMORY_TO_HATCH:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum INLINE_MAP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LEGAL_INFO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LIBRARY_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOCATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_ACCOUNT_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_CHECKPOINT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_CONTACT_POINT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_ITEMIZED_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_LANDING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_LINKING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_NTP_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_OTP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_PASSWORD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGIN_REACTIVATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum LOGOUT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MANAGE_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MAP_PLACE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MEDIA_FULLSCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MESSAGES_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MESSENGER_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MICROPHONE_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum MODEL_PICKER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum NAV_BAR_EXPANDED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum NEW_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum NOTIFICATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum OFF_WAITLIST_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_ACCOUNT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_AGE_ID:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_AGE_METHODS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_CVM_OFFER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_GATE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_IDENTITY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_INVITE_FRIENDS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_NAME_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_NDA:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_RETOS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_TASKS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_TOUR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_VM_PROVISIONING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum ONBOARDING_WELCOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PASSKEY_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PAYMENT_METHOD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PEER_SPACE_MEMBERS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PEER_SPACE_MENU:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PHONE_CALL_VIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PHONE_NOTIFICATIONS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PLAN_CHANGE_BLOCKED_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PRELOADS_TOS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PRODUCT_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PRODUCT_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PROFESSIONAL_CONSENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PROFILE_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PUBLISH_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PUBLISH_FAILED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum PUBLISH_SUCCESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum REDEEM_COMPLIMENTARY_SUBSCRIPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RENTAL_CAR_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RENTAL_CAR_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RESET_CONFIRMATION_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RESET_HATCH_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RESET_HATCH_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum RESUME_SUBSCRIPTION_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SEARCH_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SECURE_STORAGE_ADD_LOGIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SECURE_STORAGE_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SECURE_STORAGE_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SECURE_STORAGE_VERIFICATION_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CHANNELS_MESSENGER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CHANNELS_TELEGRAM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CHANNELS_WHATSAPP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CONNECTED_APPS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_CONNECTED_DEVICES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_DEVICE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_MAIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SETTINGS_NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SHARED_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SHARED_GOAL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SHOPPING_CART:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SPACES_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SPACE_AUDIENCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SPACE_COLLABORATORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SPACE_INVITE_PICKER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SUBSCRIPTION_CONFIRM_NAME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SUBSCRIPTION_MANAGEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SUBSCRIPTION_PAYWALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SUBTHREAD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum SURVEY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum TASK_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum TELEGRAM_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum VOICE_ANNOUNCEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum VOICE_NUX:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum VOICE_OVERLAY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum VOICE_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum VOICE_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WALLET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WALLET_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_APPROVAL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_AVATAR_MENU:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_CALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_KEYBOARD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_LAUNCH_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_SETUP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WATCH_VOICE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WEARABLES_CELLULAR_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WEARABLES_LINKING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WEARABLE_DEVICE_HELP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final enum WHATSAPP_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 244

    .line 625701
    const/4 v2, 0x0

    const-string v1, "main_chat"

    const-string v0, "MAIN_CHAT"

    .line 625702
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v5

    .line 625703
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625704
    const/4 v2, 0x1

    const-string v1, "new_chat"

    const-string v0, "NEW_CHAT"

    .line 625705
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v6

    .line 625706
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchScreen;->NEW_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625707
    const/4 v2, 0x2

    const-string v1, "conversation_history"

    const-string v0, "CONVERSATION_HISTORY"

    .line 625708
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v7

    .line 625709
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONVERSATION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625710
    const/4 v2, 0x3

    const-string v1, "library_home"

    const-string v0, "LIBRARY_HOME"

    .line 625711
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v8

    .line 625712
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LIBRARY_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625713
    const/4 v2, 0x4

    const-string v1, "feed_home"

    const-string v0, "FEED_HOME"

    .line 625714
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v9

    .line 625715
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FEED_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625716
    const/4 v2, 0x5

    const-string v1, "ideas_home"

    const-string v0, "IDEAS_HOME"

    .line 625717
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v10

    .line 625718
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchScreen;->IDEAS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625719
    const/4 v2, 0x6

    const-string v1, "feed_edit_prompt_sheet"

    const-string v0, "FEED_EDIT_PROMPT_SHEET"

    .line 625720
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v11

    .line 625721
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FEED_EDIT_PROMPT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625722
    const/4 v2, 0x7

    const-string v1, "feed_status_sheet"

    const-string v0, "FEED_STATUS_SHEET"

    .line 625723
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v12

    .line 625724
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FEED_STATUS_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625725
    const/16 v2, 0x8

    const-string v1, "media_fullscreen"

    const-string v0, "MEDIA_FULLSCREEN"

    .line 625726
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v13

    .line 625727
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MEDIA_FULLSCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625728
    const/16 v2, 0x9

    const-string v1, "artifact_code"

    const-string v0, "ARTIFACT_CODE"

    .line 625729
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v14

    .line 625730
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ARTIFACT_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625731
    const/16 v2, 0xa

    const-string v1, "artifact_canvas"

    const-string v0, "ARTIFACT_CANVAS"

    .line 625732
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v15

    .line 625733
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ARTIFACT_CANVAS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625734
    const/16 v2, 0xb

    const-string v1, "artifact_document"

    const-string v0, "ARTIFACT_DOCUMENT"

    .line 625735
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v16

    .line 625736
    sput-object v16, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ARTIFACT_DOCUMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625737
    const/16 v2, 0xc

    const-string v1, "model_picker"

    const-string v0, "MODEL_PICKER"

    .line 625738
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v17

    .line 625739
    sput-object v17, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MODEL_PICKER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625740
    const/16 v2, 0xd

    const-string v1, "feedback_form"

    const-string v0, "FEEDBACK_FORM"

    .line 625741
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v18

    .line 625742
    sput-object v18, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FEEDBACK_FORM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625743
    const/16 v2, 0xe

    const-string v1, "settings_main"

    const-string v0, "SETTINGS_MAIN"

    .line 625744
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v19

    .line 625745
    sput-object v19, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_MAIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625746
    const/16 v2, 0xf

    const-string v1, "settings_notifications"

    const-string v0, "SETTINGS_NOTIFICATIONS"

    .line 625747
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v20

    .line 625748
    sput-object v20, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625749
    const/16 v2, 0x10

    const-string v1, "settings_data_controls"

    const-string v0, "SETTINGS_DATA_CONTROLS"

    .line 625750
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v21

    .line 625751
    sput-object v21, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625752
    const/16 v2, 0x11

    const-string v1, "settings_appearance"

    const-string v0, "SETTINGS_APPEARANCE"

    .line 625753
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v22

    .line 625754
    sput-object v22, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625755
    const/16 v2, 0x12

    const-string v1, "channels"

    const-string v0, "CHANNELS"

    .line 625756
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v23

    .line 625757
    sput-object v23, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625758
    const/16 v2, 0x13

    const-string v1, "channels_whatsapp"

    const-string v0, "CHANNELS_WHATSAPP"

    .line 625759
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v24

    .line 625760
    sput-object v24, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CHANNELS_WHATSAPP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625761
    const/16 v2, 0x14

    const-string v1, "channels_telegram"

    const-string v0, "CHANNELS_TELEGRAM"

    .line 625762
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v25

    .line 625763
    sput-object v25, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CHANNELS_TELEGRAM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625764
    const/16 v2, 0x15

    const-string v1, "channels_messenger"

    const-string v0, "CHANNELS_MESSENGER"

    .line 625765
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v26

    .line 625766
    sput-object v26, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CHANNELS_MESSENGER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625767
    const/16 v2, 0x16

    const-string v1, "whatsapp_disconnect_dialog"

    const-string v0, "WHATSAPP_DISCONNECT_DIALOG"

    .line 625768
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v27

    .line 625769
    sput-object v27, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WHATSAPP_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625770
    const/16 v2, 0x17

    const-string v1, "telegram_disconnect_dialog"

    const-string v0, "TELEGRAM_DISCONNECT_DIALOG"

    .line 625771
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v28

    .line 625772
    sput-object v28, Lcom/facebook/aura/analytics/hatch/HatchScreen;->TELEGRAM_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625773
    const/16 v2, 0x18

    const-string v1, "messenger_disconnect_dialog"

    const-string v0, "MESSENGER_DISCONNECT_DIALOG"

    .line 625774
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v29

    .line 625775
    sput-object v29, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MESSENGER_DISCONNECT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625776
    const/16 v2, 0x19

    const-string v1, "devices"

    const-string v0, "DEVICES"

    .line 625777
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v30

    .line 625778
    sput-object v30, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DEVICES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625779
    const/16 v2, 0x1a

    const-string v1, "device_details"

    const-string v0, "DEVICE_DETAILS"

    .line 625780
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v31

    .line 625781
    sput-object v31, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DEVICE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625782
    const/16 v2, 0x1b

    const-string v1, "home_link_order_info"

    const-string v0, "HOME_LINK_ORDER_INFO"

    .line 625783
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v32

    .line 625784
    sput-object v32, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HOME_LINK_ORDER_INFO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625785
    const/16 v2, 0x1c

    const-string v1, "home_link_order_details"

    const-string v0, "HOME_LINK_ORDER_DETAILS"

    .line 625786
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v33

    .line 625787
    sput-object v33, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HOME_LINK_ORDER_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625788
    const/16 v2, 0x1d

    const-string v1, "home_link_order_blocked"

    const-string v0, "HOME_LINK_ORDER_BLOCKED"

    .line 625789
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v34

    .line 625790
    sput-object v34, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HOME_LINK_ORDER_BLOCKED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625791
    const/16 v2, 0x1e

    const-string v1, "connectors"

    const-string v0, "CONNECTORS"

    .line 625792
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v35

    .line 625793
    sput-object v35, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625794
    const/16 v2, 0x1f

    const-string v1, "professional_consent_sheet"

    const-string v0, "PROFESSIONAL_CONSENT_SHEET"

    .line 625795
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v36

    .line 625796
    sput-object v36, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PROFESSIONAL_CONSENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625797
    const/16 v2, 0x20

    const-string v1, "wallet"

    const-string v0, "WALLET"

    .line 625798
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v37

    .line 625799
    sput-object v37, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WALLET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625800
    const/16 v2, 0x21

    const-string v1, "redeem_invite_code"

    const-string v0, "REDEEM_INVITE_CODE"

    .line 625801
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v38

    .line 625802
    sput-object v38, Lcom/facebook/aura/analytics/hatch/HatchScreen;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625803
    const/16 v2, 0x22

    const-string v1, "permissions"

    const-string v0, "PERMISSIONS"

    .line 625804
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v39

    .line 625805
    sput-object v39, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625806
    const/16 v2, 0x23

    const-string v1, "connector_permissions_list"

    const-string v0, "CONNECTOR_PERMISSIONS_LIST"

    .line 625807
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v40

    .line 625808
    sput-object v40, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_PERMISSIONS_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625809
    const/16 v2, 0x24

    const-string v1, "connector_permissions"

    const-string v0, "CONNECTOR_PERMISSIONS"

    .line 625810
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v41

    .line 625811
    sput-object v41, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625812
    const/16 v2, 0x25

    const-string v1, "manage_approvals"

    const-string v0, "MANAGE_APPROVALS"

    .line 625813
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v42

    .line 625814
    sput-object v42, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MANAGE_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625815
    const/16 v2, 0x26

    const-string v1, "passkey_upsell"

    const-string v0, "PASSKEY_UPSELL"

    .line 625816
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v43

    .line 625817
    sput-object v43, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PASSKEY_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625818
    const/16 v2, 0x27

    const-string v1, "data_controls"

    const-string v0, "DATA_CONTROLS"

    .line 625819
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v44

    .line 625820
    sput-object v44, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625821
    const/16 v2, 0x28

    const-string v1, "encryption"

    const-string v0, "ENCRYPTION"

    .line 625822
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v45

    .line 625823
    sput-object v45, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625824
    const/16 v2, 0x29

    const-string v1, "import_memory_to_hatch"

    const-string v0, "IMPORT_MEMORY_TO_HATCH"

    .line 625825
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v46

    .line 625826
    sput-object v46, Lcom/facebook/aura/analytics/hatch/HatchScreen;->IMPORT_MEMORY_TO_HATCH:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625827
    const/16 v2, 0x2a

    const-string v1, "reset_hatch_dialog"

    const-string v0, "RESET_HATCH_DIALOG"

    .line 625828
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v47

    .line 625829
    sput-object v47, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RESET_HATCH_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625830
    const/16 v2, 0x2b

    const-string v1, "reset_confirmation_sheet"

    const-string v0, "RESET_CONFIRMATION_SHEET"

    .line 625831
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v48

    .line 625832
    sput-object v48, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RESET_CONFIRMATION_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625833
    const/16 v2, 0x2c

    const-string v1, "cvm_pin_help"

    const-string v0, "CVM_PIN_HELP"

    .line 625834
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v49

    .line 625835
    sput-object v49, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_HELP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625836
    const/16 v2, 0x2d

    const-string v1, "cvm_pin_create"

    const-string v0, "CVM_PIN_CREATE"

    .line 625837
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v50

    .line 625838
    sput-object v50, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_CREATE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625839
    const/16 v2, 0x2e

    const-string v1, "cvm_pin_confirm"

    const-string v0, "CVM_PIN_CONFIRM"

    .line 625840
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v51

    .line 625841
    sput-object v51, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625842
    const/16 v2, 0x2f

    const-string v1, "cvm_pin_enter"

    const-string v0, "CVM_PIN_ENTER"

    .line 625843
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v52

    .line 625844
    sput-object v52, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_ENTER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625845
    const/16 v2, 0x30

    const-string v1, "cvm_pin_locked"

    const-string v0, "CVM_PIN_LOCKED"

    .line 625846
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v53

    .line 625847
    sput-object v53, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_LOCKED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625848
    const/16 v2, 0x31

    const-string v1, "cvm_pin_lookup_failed"

    const-string v0, "CVM_PIN_LOOKUP_FAILED"

    .line 625849
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v54

    .line 625850
    sput-object v54, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_PIN_LOOKUP_FAILED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625851
    const/16 v2, 0x32

    const-string v1, "cvm_switch_intro"

    const-string v0, "CVM_SWITCH_INTRO"

    .line 625852
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v55

    .line 625853
    sput-object v55, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_SWITCH_INTRO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625854
    const/16 v2, 0x33

    const-string v1, "cvm_subscribe_intro"

    const-string v0, "CVM_SUBSCRIBE_INTRO"

    .line 625855
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v56

    .line 625856
    sput-object v56, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_SUBSCRIBE_INTRO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625857
    const/16 v2, 0x34

    const-string v1, "cvm_join_waitlist"

    const-string v0, "CVM_JOIN_WAITLIST"

    .line 625858
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v57

    .line 625859
    sput-object v57, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_JOIN_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625860
    const/16 v2, 0x35

    const-string v1, "cvm_on_waitlist"

    const-string v0, "CVM_ON_WAITLIST"

    .line 625861
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v58

    .line 625862
    sput-object v58, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_ON_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625863
    const/16 v2, 0x36

    const-string v1, "cvm_off_waitlist_sheet"

    const-string v0, "CVM_OFF_WAITLIST_SHEET"

    .line 625864
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v59

    .line 625865
    sput-object v59, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_OFF_WAITLIST_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625866
    const/16 v2, 0x37

    const-string v1, "cvm_switch_unavailable"

    const-string v0, "CVM_SWITCH_UNAVAILABLE"

    .line 625867
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v60

    .line 625868
    sput-object v60, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_SWITCH_UNAVAILABLE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625869
    const/16 v2, 0x38

    const-string v1, "cvm_subscription_ended"

    const-string v0, "CVM_SUBSCRIPTION_ENDED"

    .line 625870
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v61

    .line 625871
    sput-object v61, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_SUBSCRIPTION_ENDED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625872
    const/16 v2, 0x39

    const-string v1, "cvm_data_choice"

    const-string v0, "CVM_DATA_CHOICE"

    .line 625873
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v62

    .line 625874
    sput-object v62, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_DATA_CHOICE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625875
    const/16 v2, 0x3a

    const-string v1, "cvm_review_artifacts"

    const-string v0, "CVM_REVIEW_ARTIFACTS"

    .line 625876
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v63

    .line 625877
    sput-object v63, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_REVIEW_ARTIFACTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625878
    const/16 v2, 0x3b

    const-string v1, "cvm_delete_data_sheet"

    const-string v0, "CVM_DELETE_DATA_SHEET"

    .line 625879
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v64

    .line 625880
    sput-object v64, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_DELETE_DATA_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625881
    const/16 v2, 0x3c

    const-string v1, "cvm_transfer_confirm"

    const-string v0, "CVM_TRANSFER_CONFIRM"

    .line 625882
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v65

    .line 625883
    sput-object v65, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_TRANSFER_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625884
    const/16 v2, 0x3d

    const-string v1, "cvm_switch_progress"

    const-string v0, "CVM_SWITCH_PROGRESS"

    .line 625885
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v66

    .line 625886
    sput-object v66, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_SWITCH_PROGRESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625887
    const/16 v2, 0x3e

    const-string v1, "cvm_transfer_progress"

    const-string v0, "CVM_TRANSFER_PROGRESS"

    .line 625888
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v67

    .line 625889
    sput-object v67, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_TRANSFER_PROGRESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625890
    const/16 v2, 0x3f

    const-string v1, "cvm_migration_done"

    const-string v0, "CVM_MIGRATION_DONE"

    .line 625891
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v68

    .line 625892
    sput-object v68, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_MIGRATION_DONE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625893
    const/16 v2, 0x40

    const-string v1, "reset_hatch_error_dialog"

    const-string v0, "RESET_HATCH_ERROR_DIALOG"

    .line 625894
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v69

    .line 625895
    sput-object v69, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RESET_HATCH_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625896
    const/16 v2, 0x41

    const-string v1, "download_agent_data_dialog"

    const-string v0, "DOWNLOAD_AGENT_DATA_DIALOG"

    .line 625897
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v70

    .line 625898
    sput-object v70, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DOWNLOAD_AGENT_DATA_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625899
    const/16 v2, 0x42

    const-string v1, "data_export_error_dialog"

    const-string v0, "DATA_EXPORT_ERROR_DIALOG"

    .line 625900
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v71

    .line 625901
    sput-object v71, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DATA_EXPORT_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625902
    const/16 v2, 0x43

    const-string v1, "notifications"

    const-string v0, "NOTIFICATIONS"

    .line 625903
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v72

    .line 625904
    sput-object v72, Lcom/facebook/aura/analytics/hatch/HatchScreen;->NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625905
    const/16 v2, 0x44

    const-string v1, "appearance"

    const-string v0, "APPEARANCE"

    .line 625906
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v73

    .line 625907
    sput-object v73, Lcom/facebook/aura/analytics/hatch/HatchScreen;->APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625908
    const/16 v2, 0x45

    const-string v1, "biometrics"

    const-string v0, "BIOMETRICS"

    .line 625909
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v74

    .line 625910
    sput-object v74, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BIOMETRICS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625911
    const/16 v2, 0x46

    const-string v1, "default_assistant"

    const-string v0, "DEFAULT_ASSISTANT"

    .line 625912
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v75

    .line 625913
    sput-object v75, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DEFAULT_ASSISTANT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625914
    const/16 v2, 0x47

    const-string v1, "add_home_screen"

    const-string v0, "ADD_HOME_SCREEN"

    .line 625915
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v76

    .line 625916
    sput-object v76, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ADD_HOME_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625917
    const/16 v2, 0x48

    const-string v1, "help_support"

    const-string v0, "HELP_SUPPORT"

    .line 625918
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v77

    .line 625919
    sput-object v77, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HELP_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625920
    const/16 v2, 0x49

    const-string v1, "contact_support"

    const-string v0, "CONTACT_SUPPORT"

    .line 625921
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v78

    .line 625922
    sput-object v78, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONTACT_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625923
    const/16 v2, 0x4a

    const-string v1, "contact_support_success"

    const-string v0, "CONTACT_SUPPORT_SUCCESS"

    .line 625924
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v79

    .line 625925
    sput-object v79, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONTACT_SUPPORT_SUCCESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625926
    const/16 v2, 0x4b

    const-string v1, "legal_info"

    const-string v0, "LEGAL_INFO"

    .line 625927
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v80

    .line 625928
    sput-object v80, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LEGAL_INFO:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625929
    const/16 v2, 0x4c

    const-string v1, "accounts_center"

    const-string v0, "ACCOUNTS_CENTER"

    .line 625930
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v81

    .line 625931
    sput-object v81, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ACCOUNTS_CENTER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625932
    const/16 v2, 0x4d

    const-string v1, "internal_settings"

    const-string v0, "INTERNAL_SETTINGS"

    .line 625933
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v82

    .line 625934
    sput-object v82, Lcom/facebook/aura/analytics/hatch/HatchScreen;->INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625935
    const/16 v2, 0x4e

    const-string v1, "card_vault"

    const-string v0, "CARD_VAULT"

    .line 625936
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v83

    .line 625937
    sput-object v83, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CARD_VAULT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625938
    const/16 v2, 0x4f

    const-string v1, "logout_dialog"

    const-string v0, "LOGOUT_DIALOG"

    .line 625939
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v84

    .line 625940
    sput-object v84, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGOUT_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625941
    const/16 v2, 0x50

    const-string v1, "location_permission"

    const-string v0, "LOCATION_PERMISSION"

    .line 625942
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v85

    .line 625943
    sput-object v85, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOCATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625944
    const/16 v2, 0x51

    const-string v1, "contacts_permission"

    const-string v0, "CONTACTS_PERMISSION"

    .line 625945
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v86

    .line 625946
    sput-object v86, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONTACTS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625947
    const/16 v2, 0x52

    const-string v1, "calendar_permission"

    const-string v0, "CALENDAR_PERMISSION"

    .line 625948
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v87

    .line 625949
    sput-object v87, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CALENDAR_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625950
    const/16 v2, 0x53

    const-string v1, "messages_permission"

    const-string v0, "MESSAGES_PERMISSION"

    .line 625951
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v88

    .line 625952
    sput-object v88, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MESSAGES_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625953
    const/16 v2, 0x54

    const-string v1, "call_log_permission"

    const-string v0, "CALL_LOG_PERMISSION"

    .line 625954
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v89

    .line 625955
    sput-object v89, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CALL_LOG_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625956
    const/16 v2, 0x55

    const-string v1, "phone_notifications_permission"

    const-string v0, "PHONE_NOTIFICATIONS_PERMISSION"

    .line 625957
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v90

    .line 625958
    sput-object v90, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PHONE_NOTIFICATIONS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625959
    const/16 v2, 0x56

    const-string v1, "microphone_permission"

    const-string v0, "MICROPHONE_PERMISSION"

    .line 625960
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v91

    .line 625961
    sput-object v91, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MICROPHONE_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625962
    const/16 v2, 0x57

    const-string v1, "bluetooth_permission"

    const-string v0, "BLUETOOTH_PERMISSION"

    .line 625963
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v92

    .line 625964
    sput-object v92, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BLUETOOTH_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625965
    const/16 v2, 0x58

    const-string v1, "profile_detail"

    const-string v0, "PROFILE_DETAIL"

    .line 625966
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v93

    .line 625967
    sput-object v93, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PROFILE_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625968
    const/16 v2, 0x59

    const-string v1, "voice_overlay"

    const-string v0, "VOICE_OVERLAY"

    .line 625969
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v94

    .line 625970
    sput-object v94, Lcom/facebook/aura/analytics/hatch/HatchScreen;->VOICE_OVERLAY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625971
    const/16 v2, 0x5a

    const-string v1, "voice_nux"

    const-string v0, "VOICE_NUX"

    .line 625972
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v95

    .line 625973
    sput-object v95, Lcom/facebook/aura/analytics/hatch/HatchScreen;->VOICE_NUX:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625974
    const/16 v2, 0x5b

    const-string v1, "voice_announcement"

    const-string v0, "VOICE_ANNOUNCEMENT"

    .line 625975
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v96

    .line 625976
    sput-object v96, Lcom/facebook/aura/analytics/hatch/HatchScreen;->VOICE_ANNOUNCEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625977
    const/16 v2, 0x5c

    const-string v1, "announcement_sheet"

    const-string v0, "ANNOUNCEMENT_SHEET"

    .line 625978
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v97

    .line 625979
    sput-object v97, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ANNOUNCEMENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625980
    const/16 v2, 0x5d

    const-string v1, "voice_settings"

    const-string v0, "VOICE_SETTINGS"

    .line 625981
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v98

    .line 625982
    sput-object v98, Lcom/facebook/aura/analytics/hatch/HatchScreen;->VOICE_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625983
    const/16 v2, 0x5e

    const-string v1, "voice_selection"

    const-string v0, "VOICE_SELECTION"

    .line 625984
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v99

    .line 625985
    sput-object v99, Lcom/facebook/aura/analytics/hatch/HatchScreen;->VOICE_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625986
    const/16 v2, 0x5f

    const-string v1, "car_home"

    const-string v0, "CAR_HOME"

    .line 625987
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v100

    .line 625988
    sput-object v100, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CAR_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625989
    const/16 v2, 0x60

    const-string v1, "car_call"

    const-string v0, "CAR_CALL"

    .line 625990
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v101

    .line 625991
    sput-object v101, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CAR_CALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625992
    const/16 v2, 0x61

    const-string v1, "watch_home"

    const-string v0, "WATCH_HOME"

    .line 625993
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v102

    .line 625994
    sput-object v102, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625995
    const/16 v2, 0x62

    const-string v1, "watch_chat"

    const-string v0, "WATCH_CHAT"

    .line 625996
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v103

    .line 625997
    sput-object v103, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 625998
    const/16 v2, 0x63

    const-string v1, "watch_keyboard"

    const-string v0, "WATCH_KEYBOARD"

    .line 625999
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v104

    .line 626000
    sput-object v104, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_KEYBOARD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626001
    const/16 v2, 0x64

    const-string v1, "watch_voice"

    const-string v0, "WATCH_VOICE"

    .line 626002
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v105

    .line 626003
    sput-object v105, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_VOICE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626004
    const/16 v2, 0x65

    const-string v1, "watch_call"

    const-string v0, "WATCH_CALL"

    .line 626005
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v106

    .line 626006
    sput-object v106, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_CALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626007
    const/16 v2, 0x66

    const-string v1, "watch_bug_report"

    const-string v0, "WATCH_BUG_REPORT"

    .line 626008
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v107

    .line 626009
    sput-object v107, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626010
    const/16 v2, 0x67

    const-string v1, "watch_avatar_menu"

    const-string v0, "WATCH_AVATAR_MENU"

    .line 626011
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v108

    .line 626012
    sput-object v108, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_AVATAR_MENU:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626013
    const/16 v2, 0x68

    const-string v1, "watch_settings"

    const-string v0, "WATCH_SETTINGS"

    .line 626014
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v109

    .line 626015
    sput-object v109, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626016
    const/16 v2, 0x69

    const-string v1, "watch_setup"

    const-string v0, "WATCH_SETUP"

    .line 626017
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v110

    .line 626018
    sput-object v110, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_SETUP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626019
    const/16 v2, 0x6a

    const-string v1, "watch_approval"

    const-string v0, "WATCH_APPROVAL"

    .line 626020
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v111

    .line 626021
    sput-object v111, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_APPROVAL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626022
    const/16 v2, 0x6b

    const-string v1, "watch_launch_confirmation"

    const-string v0, "WATCH_LAUNCH_CONFIRMATION"

    .line 626023
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v112

    .line 626024
    sput-object v112, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WATCH_LAUNCH_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626025
    const/16 v2, 0x6c

    const-string v1, "search_results"

    const-string v0, "SEARCH_RESULTS"

    .line 626026
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v113

    .line 626027
    sput-object v113, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SEARCH_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626028
    const/16 v2, 0x6d

    const-string v1, "onboarding_gate"

    const-string v0, "ONBOARDING_GATE"

    .line 626029
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v114

    .line 626030
    sput-object v114, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_GATE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626031
    const/16 v2, 0x6e

    const-string v1, "onboarding_welcome"

    const-string v0, "ONBOARDING_WELCOME"

    .line 626032
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v115

    .line 626033
    sput-object v115, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WELCOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626034
    const/16 v2, 0x6f

    const-string v1, "onboarding_permissions"

    const-string v0, "ONBOARDING_PERMISSIONS"

    .line 626035
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v116

    .line 626036
    sput-object v116, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626037
    const/16 v2, 0x70

    const-string v1, "onboarding_account"

    const-string v0, "ONBOARDING_ACCOUNT"

    .line 626038
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v117

    .line 626039
    sput-object v117, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_ACCOUNT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626040
    const/16 v2, 0x71

    const-string v1, "onboarding_waitlist"

    const-string v0, "ONBOARDING_WAITLIST"

    .line 626041
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v118

    .line 626042
    sput-object v118, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626043
    const/16 v2, 0x72

    const-string v1, "onboarding_invite_code"

    const-string v0, "ONBOARDING_INVITE_CODE"

    .line 626044
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v119

    .line 626045
    sput-object v119, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626046
    const/16 v2, 0x73

    const-string v1, "ccv_screen"

    const-string v0, "CCV_SCREEN"

    .line 626047
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v120

    .line 626048
    sput-object v120, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CCV_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626049
    const/16 v2, 0x74

    const-string v1, "onboarding_age_confirmation"

    const-string v0, "ONBOARDING_AGE_CONFIRMATION"

    .line 626050
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v121

    .line 626051
    sput-object v121, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626052
    const/16 v2, 0x75

    const-string v1, "onboarding_age_id"

    const-string v0, "ONBOARDING_AGE_ID"

    .line 626053
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v122

    .line 626054
    sput-object v122, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_ID:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626055
    const/16 v2, 0x76

    const-string v1, "onboarding_age_methods"

    const-string v0, "ONBOARDING_AGE_METHODS"

    .line 626056
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v123

    .line 626057
    sput-object v123, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_METHODS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626058
    const/16 v2, 0x77

    const-string v1, "onboarding_disclosure"

    const-string v0, "ONBOARDING_DISCLOSURE"

    .line 626059
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v124

    .line 626060
    sput-object v124, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626061
    const/16 v2, 0x78

    const-string v1, "onboarding_retos"

    const-string v0, "ONBOARDING_RETOS"

    .line 626062
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v125

    .line 626063
    sput-object v125, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_RETOS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626064
    const/16 v2, 0x79

    const-string v1, "onboarding_nda"

    const-string v0, "ONBOARDING_NDA"

    .line 626065
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v126

    .line 626066
    sput-object v126, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_NDA:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626067
    const/16 v2, 0x7a

    const-string v1, "onboarding_name_confirmation"

    const-string v0, "ONBOARDING_NAME_CONFIRMATION"

    .line 626068
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v127

    .line 626069
    sput-object v127, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_NAME_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626070
    const/16 v2, 0x7b

    const-string v1, "onboarding_encryption"

    const-string v0, "ONBOARDING_ENCRYPTION"

    .line 626071
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v128

    .line 626072
    sput-object v128, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626073
    const/16 v2, 0x7c

    const-string v1, "onboarding_cvm_offer"

    const-string v0, "ONBOARDING_CVM_OFFER"

    .line 626074
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v129

    .line 626075
    sput-object v129, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_CVM_OFFER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626076
    const/16 v2, 0x7d

    const-string v1, "onboarding_vm_provisioning"

    const-string v0, "ONBOARDING_VM_PROVISIONING"

    .line 626077
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v130

    .line 626078
    sput-object v130, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_VM_PROVISIONING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626079
    const/16 v2, 0x7e

    const-string v1, "wearables_linking"

    const-string v0, "WEARABLES_LINKING"

    .line 626080
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v131

    .line 626081
    sput-object v131, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WEARABLES_LINKING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626082
    const/16 v2, 0x7f

    const-string v1, "login_landing"

    const-string v0, "LOGIN_LANDING"

    .line 626083
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v132

    .line 626084
    sput-object v132, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_LANDING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626085
    const/16 v2, 0x80

    const-string v1, "login_contact_point"

    const-string v0, "LOGIN_CONTACT_POINT"

    .line 626086
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v133

    .line 626087
    sput-object v133, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_CONTACT_POINT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626088
    const/16 v2, 0x81

    const-string v1, "login_otp"

    const-string v0, "LOGIN_OTP"

    .line 626089
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v134

    .line 626090
    sput-object v134, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_OTP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626091
    const/16 v2, 0x82

    const-string v1, "login_password"

    const-string v0, "LOGIN_PASSWORD"

    .line 626092
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v135

    .line 626093
    sput-object v135, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_PASSWORD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626094
    const/16 v2, 0x83

    const-string v1, "login_account_selection"

    const-string v0, "LOGIN_ACCOUNT_SELECTION"

    .line 626095
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v136

    .line 626096
    sput-object v136, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_ACCOUNT_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626097
    const/16 v2, 0x84

    const-string v1, "login_ntp_upsell"

    const-string v0, "LOGIN_NTP_UPSELL"

    .line 626098
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v137

    .line 626099
    sput-object v137, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_NTP_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626100
    const/16 v2, 0x85

    const-string v1, "login_linking_disclosure"

    const-string v0, "LOGIN_LINKING_DISCLOSURE"

    .line 626101
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v138

    .line 626102
    sput-object v138, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_LINKING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626103
    const/16 v2, 0x86

    const-string v1, "login_itemized_consent"

    const-string v0, "LOGIN_ITEMIZED_CONSENT"

    .line 626104
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v139

    .line 626105
    sput-object v139, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_ITEMIZED_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626106
    const/16 v2, 0x87

    const-string v1, "login_checkpoint"

    const-string v0, "LOGIN_CHECKPOINT"

    .line 626107
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v140

    .line 626108
    sput-object v140, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_CHECKPOINT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626109
    const/16 v2, 0x88

    const-string v1, "preloads_tos"

    const-string v0, "PRELOADS_TOS"

    .line 626110
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v141

    .line 626111
    sput-object v141, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PRELOADS_TOS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626112
    const/16 v2, 0x89

    const-string v1, "login_reactivation"

    const-string v0, "LOGIN_REACTIVATION"

    .line 626113
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v142

    .line 626114
    sput-object v142, Lcom/facebook/aura/analytics/hatch/HatchScreen;->LOGIN_REACTIVATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626115
    const/16 v2, 0x8a

    const-string v1, "task_detail"

    const-string v0, "TASK_DETAIL"

    .line 626116
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v143

    .line 626117
    sput-object v143, Lcom/facebook/aura/analytics/hatch/HatchScreen;->TASK_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626118
    const/16 v2, 0x8b

    const-string v1, "device_pairing"

    const-string v0, "DEVICE_PAIRING"

    .line 626119
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v144

    .line 626120
    sput-object v144, Lcom/facebook/aura/analytics/hatch/HatchScreen;->DEVICE_PAIRING:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626121
    const/16 v2, 0x8c

    const-string v1, "wearable_device_help"

    const-string v0, "WEARABLE_DEVICE_HELP"

    .line 626122
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v145

    .line 626123
    sput-object v145, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WEARABLE_DEVICE_HELP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626124
    const/16 v2, 0x8d

    const-string v1, "wearables_cellular_consent"

    const-string v0, "WEARABLES_CELLULAR_CONSENT"

    .line 626125
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v146

    .line 626126
    sput-object v146, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WEARABLES_CELLULAR_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626127
    const/16 v2, 0x8e

    const-string v1, "settings_connected_devices"

    const-string v0, "SETTINGS_CONNECTED_DEVICES"

    .line 626128
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v147

    .line 626129
    sput-object v147, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CONNECTED_DEVICES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626130
    const/16 v2, 0x8f

    const-string v1, "settings_device_details"

    const-string v0, "SETTINGS_DEVICE_DETAILS"

    .line 626131
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v148

    .line 626132
    sput-object v148, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_DEVICE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626133
    const/16 v2, 0x90

    const-string v1, "bot_sheet"

    const-string v0, "BOT_SHEET"

    .line 626134
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v149

    .line 626135
    sput-object v149, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BOT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626136
    const/16 v2, 0x91

    const-string v1, "connector_consent_sheet"

    const-string v0, "CONNECTOR_CONSENT_SHEET"

    .line 626137
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v150

    .line 626138
    sput-object v150, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_CONSENT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626139
    const/16 v2, 0x92

    const-string v1, "wallet_consent"

    const-string v0, "WALLET_CONSENT"

    .line 626140
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v151

    .line 626141
    sput-object v151, Lcom/facebook/aura/analytics/hatch/HatchScreen;->WALLET_CONSENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626142
    const/16 v2, 0x93

    const-string v1, "email_setup"

    const-string v0, "EMAIL_SETUP"

    .line 626143
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v152

    .line 626144
    sput-object v152, Lcom/facebook/aura/analytics/hatch/HatchScreen;->EMAIL_SETUP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626145
    const/16 v2, 0x94

    const-string v1, "connector_api_key_input"

    const-string v0, "CONNECTOR_API_KEY_INPUT"

    .line 626146
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v153

    .line 626147
    sput-object v153, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_API_KEY_INPUT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626148
    const/16 v2, 0x95

    const-string v1, "connector_oauth_credential_input"

    const-string v0, "CONNECTOR_OAUTH_CREDENTIAL_INPUT"

    .line 626149
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v154

    .line 626150
    sput-object v154, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_OAUTH_CREDENTIAL_INPUT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626151
    const/16 v2, 0x96

    const-string v1, "connector_auth_web_view"

    const-string v0, "CONNECTOR_AUTH_WEB_VIEW"

    .line 626152
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v155

    .line 626153
    sput-object v155, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTOR_AUTH_WEB_VIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626154
    const/16 v2, 0x97

    const-string v1, "browser_overlay"

    const-string v0, "BROWSER_OVERLAY"

    .line 626155
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v156

    .line 626156
    sput-object v156, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BROWSER_OVERLAY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626157
    const/16 v2, 0x98

    const-string v1, "phone_call_view"

    const-string v0, "PHONE_CALL_VIEW"

    .line 626158
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v157

    .line 626159
    sput-object v157, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PHONE_CALL_VIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626160
    const/16 v2, 0x99

    const-string v1, "file_editor"

    const-string v0, "FILE_EDITOR"

    .line 626161
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v158

    .line 626162
    sput-object v158, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FILE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626163
    const/16 v2, 0x9a

    const-string v1, "settings_channels"

    const-string v0, "SETTINGS_CHANNELS"

    .line 626164
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v159

    .line 626165
    sput-object v159, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626166
    const/16 v2, 0x9b

    const-string v1, "settings_channels_whatsapp"

    const-string v0, "SETTINGS_CHANNELS_WHATSAPP"

    .line 626167
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v160

    .line 626168
    sput-object v160, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CHANNELS_WHATSAPP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626169
    const/16 v2, 0x9c

    const-string v1, "settings_channels_telegram"

    const-string v0, "SETTINGS_CHANNELS_TELEGRAM"

    .line 626170
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v161

    .line 626171
    sput-object v161, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CHANNELS_TELEGRAM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626172
    const/16 v2, 0x9d

    const-string v1, "settings_channels_messenger"

    const-string v0, "SETTINGS_CHANNELS_MESSENGER"

    .line 626173
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v162

    .line 626174
    sput-object v162, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CHANNELS_MESSENGER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626175
    const/16 v2, 0x9e

    const-string v1, "settings_connected_apps"

    const-string v0, "SETTINGS_CONNECTED_APPS"

    .line 626176
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v163

    .line 626177
    sput-object v163, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CONNECTED_APPS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626178
    const/16 v2, 0x9f

    const-string v1, "buy_more_credits"

    const-string v0, "BUY_MORE_CREDITS"

    .line 626179
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v164

    .line 626180
    sput-object v164, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BUY_MORE_CREDITS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626181
    const/16 v2, 0xa0

    const-string v1, "redeem_complimentary_subscription"

    const-string v0, "REDEEM_COMPLIMENTARY_SUBSCRIPTION"

    .line 626182
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v165

    .line 626183
    sput-object v165, Lcom/facebook/aura/analytics/hatch/HatchScreen;->REDEEM_COMPLIMENTARY_SUBSCRIPTION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626184
    const/16 v2, 0xa1

    const-string v1, "spaces_home"

    const-string v0, "SPACES_HOME"

    .line 626185
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v166

    .line 626186
    sput-object v166, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SPACES_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626187
    const/16 v2, 0xa2

    const-string v1, "shared_content"

    const-string v0, "SHARED_CONTENT"

    .line 626188
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v167

    .line 626189
    sput-object v167, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SHARED_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626190
    const/16 v2, 0xa3

    const-string v1, "space_audience"

    const-string v0, "SPACE_AUDIENCE"

    .line 626191
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v168

    .line 626192
    sput-object v168, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SPACE_AUDIENCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626193
    const/16 v2, 0xa4

    const-string v1, "connections_invite_agreement"

    const-string v0, "CONNECTIONS_INVITE_AGREEMENT"

    .line 626194
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v169

    .line 626195
    sput-object v169, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_INVITE_AGREEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626196
    const/16 v2, 0xa5

    const-string v1, "share_sheet"

    const-string v0, "SHARE_SHEET"

    .line 626197
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v170

    .line 626198
    sput-object v170, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626199
    const/16 v2, 0xa6

    const-string v1, "idea_detail"

    const-string v0, "IDEA_DETAIL"

    .line 626200
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v171

    .line 626201
    sput-object v171, Lcom/facebook/aura/analytics/hatch/HatchScreen;->IDEA_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626202
    const/16 v2, 0xa7

    const-string v1, "idea_report"

    const-string v0, "IDEA_REPORT"

    .line 626203
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v172

    .line 626204
    sput-object v172, Lcom/facebook/aura/analytics/hatch/HatchScreen;->IDEA_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626205
    const/16 v2, 0xa8

    const-string v1, "goals_home"

    const-string v0, "GOALS_HOME"

    .line 626206
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v173

    .line 626207
    sput-object v173, Lcom/facebook/aura/analytics/hatch/HatchScreen;->GOALS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626208
    const/16 v2, 0xa9

    const-string v1, "connections_home"

    const-string v0, "CONNECTIONS_HOME"

    .line 626209
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v174

    .line 626210
    sput-object v174, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_HOME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626211
    const/16 v2, 0xaa

    const-string v1, "goal_detail"

    const-string v0, "GOAL_DETAIL"

    .line 626212
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v175

    .line 626213
    sput-object v175, Lcom/facebook/aura/analytics/hatch/HatchScreen;->GOAL_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626214
    const/16 v2, 0xab

    const-string v1, "goals_completed"

    const-string v0, "GOALS_COMPLETED"

    .line 626215
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v176

    .line 626216
    sput-object v176, Lcom/facebook/aura/analytics/hatch/HatchScreen;->GOALS_COMPLETED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626217
    const/16 v2, 0xac

    const-string v1, "goal_creation_bottom_sheet"

    const-string v0, "GOAL_CREATION_BOTTOM_SHEET"

    .line 626218
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v177

    .line 626219
    sput-object v177, Lcom/facebook/aura/analytics/hatch/HatchScreen;->GOAL_CREATION_BOTTOM_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626220
    const/16 v2, 0xad

    const-string v1, "publish_confirm"

    const-string v0, "PUBLISH_CONFIRM"

    .line 626221
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v178

    .line 626222
    sput-object v178, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PUBLISH_CONFIRM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626223
    const/16 v2, 0xae

    const-string v1, "publish_success"

    const-string v0, "PUBLISH_SUCCESS"

    .line 626224
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v179

    .line 626225
    sput-object v179, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PUBLISH_SUCCESS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626226
    const/16 v2, 0xaf

    const-string v1, "publish_failed"

    const-string v0, "PUBLISH_FAILED"

    .line 626227
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v180

    .line 626228
    sput-object v180, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PUBLISH_FAILED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626229
    const/16 v2, 0xb0

    const-string v1, "onboarding_invite_friends"

    const-string v0, "ONBOARDING_INVITE_FRIENDS"

    .line 626230
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v181

    .line 626231
    sput-object v181, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_FRIENDS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626232
    const/16 v2, 0xb1

    const-string v1, "onboarding_tour"

    const-string v0, "ONBOARDING_TOUR"

    .line 626233
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v182

    .line 626234
    sput-object v182, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_TOUR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626235
    const/16 v2, 0xb2

    const-string v1, "inlinemap"

    const-string v0, "INLINE_MAP"

    .line 626236
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v183

    .line 626237
    sput-object v183, Lcom/facebook/aura/analytics/hatch/HatchScreen;->INLINE_MAP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626238
    const/16 v2, 0xb3

    const-string v1, "fullscreenmap"

    const-string v0, "FULL_SCREEN_MAP"

    .line 626239
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v184

    .line 626240
    sput-object v184, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FULL_SCREEN_MAP:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626241
    const/16 v2, 0xb4

    const-string v1, "mapplacedetails"

    const-string v0, "MAP_PLACE_DETAILS"

    .line 626242
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v185

    .line 626243
    sput-object v185, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAP_PLACE_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626244
    const/16 v2, 0xb5

    const-string v1, "onboarding_connectors"

    const-string v0, "ONBOARDING_CONNECTORS"

    .line 626245
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v186

    .line 626246
    sput-object v186, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626247
    const/16 v2, 0xb6

    const-string v1, "onboarding_tasks"

    const-string v0, "ONBOARDING_TASKS"

    .line 626248
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v187

    .line 626249
    sput-object v187, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_TASKS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626250
    const/16 v2, 0xb7

    const-string v1, "onboarding_identity"

    const-string v0, "ONBOARDING_IDENTITY"

    .line 626251
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v188

    .line 626252
    sput-object v188, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_IDENTITY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626253
    const/16 v2, 0xb8

    const-string v1, "artifact_preview"

    const-string v0, "ARTIFACT_PREVIEW"

    .line 626254
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v189

    .line 626255
    sput-object v189, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ARTIFACT_PREVIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626256
    const/16 v2, 0xb9

    const-string v1, "bug_report"

    const-string v0, "BUG_REPORT"

    .line 626257
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v190

    .line 626258
    sput-object v190, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626259
    const/16 v2, 0xba

    const-string v1, "notification_permission"

    const-string v0, "NOTIFICATION_PERMISSION"

    .line 626260
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v191

    .line 626261
    sput-object v191, Lcom/facebook/aura/analytics/hatch/HatchScreen;->NOTIFICATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626262
    const/16 v2, 0xbb

    const-string v1, "chat_thread"

    const-string v0, "CHAT_THREAD"

    .line 626263
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v192

    .line 626264
    sput-object v192, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CHAT_THREAD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626265
    const/16 v2, 0xbc

    const-string v1, "subthread"

    const-string v0, "SUBTHREAD"

    .line 626266
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v193

    .line 626267
    sput-object v193, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SUBTHREAD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626268
    const/16 v2, 0xbd

    const-string v1, "flight_itinerary"

    const-string v0, "FLIGHT_ITINERARY"

    .line 626269
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v194

    .line 626270
    sput-object v194, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FLIGHT_ITINERARY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626271
    const/16 v2, 0xbe

    const-string v1, "flight_fares"

    const-string v0, "FLIGHT_FARES"

    .line 626272
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v195

    .line 626273
    sput-object v195, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FLIGHT_FARES:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626274
    const/16 v2, 0xbf

    const-string v1, "flight_results"

    const-string v0, "FLIGHT_RESULTS"

    .line 626275
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v196

    .line 626276
    sput-object v196, Lcom/facebook/aura/analytics/hatch/HatchScreen;->FLIGHT_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626277
    const/16 v2, 0xc0

    const-string v1, "hotel_results"

    const-string v0, "HOTEL_RESULTS"

    .line 626278
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v197

    .line 626279
    sput-object v197, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HOTEL_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626280
    const/16 v2, 0xc1

    const-string v1, "hotel_details"

    const-string v0, "HOTEL_DETAILS"

    .line 626281
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v198

    .line 626282
    sput-object v198, Lcom/facebook/aura/analytics/hatch/HatchScreen;->HOTEL_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626283
    const/16 v2, 0xc2

    const-string v1, "rental_car_results"

    const-string v0, "RENTAL_CAR_RESULTS"

    .line 626284
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v199

    .line 626285
    sput-object v199, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RENTAL_CAR_RESULTS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626286
    const/16 v2, 0xc3

    const-string v1, "rental_car_details"

    const-string v0, "RENTAL_CAR_DETAILS"

    .line 626287
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v200

    .line 626288
    sput-object v200, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RENTAL_CAR_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626289
    const/16 v2, 0xc4

    const-string v1, "agent_permission_single_approval_pill"

    const-string v0, "AGENT_PERMISSION_SINGLE_APPROVAL_PILL"

    .line 626290
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v201

    .line 626291
    sput-object v201, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626292
    const/16 v2, 0xc5

    const-string v1, "agent_permission_single_approval_sheet"

    const-string v0, "AGENT_PERMISSION_SINGLE_APPROVAL_SHEET"

    .line 626293
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v202

    .line 626294
    sput-object v202, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626295
    const/16 v2, 0xc6

    const-string v1, "agent_permission_multi_approval_pill"

    const-string v0, "AGENT_PERMISSION_MULTI_APPROVAL_PILL"

    .line 626296
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v203

    .line 626297
    sput-object v203, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626298
    const/16 v2, 0xc7

    const-string v1, "agent_permission_multi_approval_sheet"

    const-string v0, "AGENT_PERMISSION_MULTI_APPROVAL_SHEET"

    .line 626299
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v204

    .line 626300
    sput-object v204, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626301
    const/16 v2, 0xc8

    const-string v1, "agent_permission_banner"

    const-string v0, "AGENT_PERMISSION_BANNER"

    .line 626302
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v205

    .line 626303
    sput-object v205, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626304
    const/16 v2, 0xc9

    const-string v1, "payment_method"

    const-string v0, "PAYMENT_METHOD"

    .line 626305
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v206

    .line 626306
    sput-object v206, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PAYMENT_METHOD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626307
    const/16 v2, 0xca

    const-string v1, "credits_main"

    const-string v0, "CREDITS_MAIN"

    .line 626308
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v207

    .line 626309
    sput-object v207, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CREDITS_MAIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626310
    const/16 v2, 0xcb

    const-string v1, "subscription_management"

    const-string v0, "SUBSCRIPTION_MANAGEMENT"

    .line 626311
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v208

    .line 626312
    sput-object v208, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SUBSCRIPTION_MANAGEMENT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626313
    const/16 v2, 0xcc

    const-string v1, "cancel_subscription_dialog"

    const-string v0, "CANCEL_SUBSCRIPTION_DIALOG"

    .line 626314
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v209

    .line 626315
    sput-object v209, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CANCEL_SUBSCRIPTION_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626316
    const/16 v2, 0xcd

    const-string v1, "resume_subscription_dialog"

    const-string v0, "RESUME_SUBSCRIPTION_DIALOG"

    .line 626317
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v210

    .line 626318
    sput-object v210, Lcom/facebook/aura/analytics/hatch/HatchScreen;->RESUME_SUBSCRIPTION_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626319
    const/16 v2, 0xce

    const-string v1, "plan_change_blocked_dialog"

    const-string v0, "PLAN_CHANGE_BLOCKED_DIALOG"

    .line 626320
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v211

    .line 626321
    sput-object v211, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PLAN_CHANGE_BLOCKED_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626322
    const/16 v2, 0xcf

    const-string v1, "subscription_paywall"

    const-string v0, "SUBSCRIPTION_PAYWALL"

    .line 626323
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v212

    .line 626324
    sput-object v212, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SUBSCRIPTION_PAYWALL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626325
    const/16 v2, 0xd0

    const-string v1, "subscription_confirm_name"

    const-string v0, "SUBSCRIPTION_CONFIRM_NAME"

    .line 626326
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v213

    .line 626327
    sput-object v213, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SUBSCRIPTION_CONFIRM_NAME:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626328
    const/16 v2, 0xd1

    const-string v1, "survey"

    const-string v0, "SURVEY"

    .line 626329
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v214

    .line 626330
    sput-object v214, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SURVEY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626331
    const/16 v2, 0xd2

    const-string v1, "off_waitlist_upsell"

    const-string v0, "OFF_WAITLIST_UPSELL"

    .line 626332
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v215

    .line 626333
    sput-object v215, Lcom/facebook/aura/analytics/hatch/HatchScreen;->OFF_WAITLIST_UPSELL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626334
    const/16 v2, 0xd3

    const-string v1, "nav_bar"

    const-string v0, "NAV_BAR"

    .line 626335
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v216

    .line 626336
    sput-object v216, Lcom/facebook/aura/analytics/hatch/HatchScreen;->NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626337
    const/16 v2, 0xd4

    const-string v1, "nav_bar_expanded"

    const-string v0, "NAV_BAR_EXPANDED"

    .line 626338
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v217

    .line 626339
    sput-object v217, Lcom/facebook/aura/analytics/hatch/HatchScreen;->NAV_BAR_EXPANDED:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626340
    const/16 v2, 0xd5

    const-string v1, "product_detail"

    const-string v0, "PRODUCT_DETAIL"

    .line 626341
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v218

    .line 626342
    sput-object v218, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PRODUCT_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626343
    const/16 v2, 0xd6

    const-string v1, "product_list"

    const-string v0, "PRODUCT_LIST"

    .line 626344
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v219

    .line 626345
    sput-object v219, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PRODUCT_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626346
    const/16 v2, 0xd7

    const-string v1, "shopping_cart"

    const-string v0, "SHOPPING_CART"

    .line 626347
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v220

    .line 626348
    sput-object v220, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SHOPPING_CART:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626349
    const/16 v2, 0xd8

    const-string v1, "cvm_replacement_maintenance"

    const-string v0, "CVM_REPLACEMENT_MAINTENANCE"

    .line 626350
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v221

    .line 626351
    sput-object v221, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CVM_REPLACEMENT_MAINTENANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626352
    const/16 v2, 0xd9

    const-string v1, "secure_storage_list"

    const-string v0, "SECURE_STORAGE_LIST"

    .line 626353
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v222

    .line 626354
    sput-object v222, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SECURE_STORAGE_LIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626355
    const/16 v2, 0xda

    const-string v1, "secure_storage_detail"

    const-string v0, "SECURE_STORAGE_DETAIL"

    .line 626356
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v223

    .line 626357
    sput-object v223, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SECURE_STORAGE_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626358
    const/16 v2, 0xdb

    const-string v1, "secure_storage_add_login"

    const-string v0, "SECURE_STORAGE_ADD_LOGIN"

    .line 626359
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v224

    .line 626360
    sput-object v224, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SECURE_STORAGE_ADD_LOGIN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626361
    const/16 v2, 0xdc

    const-string v1, "secure_storage_verification_code"

    const-string v0, "SECURE_STORAGE_VERIFICATION_CODE"

    .line 626362
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v225

    .line 626363
    sput-object v225, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SECURE_STORAGE_VERIFICATION_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626364
    const/16 v2, 0xdd

    const-string v1, "connections_add"

    const-string v0, "CONNECTIONS_ADD"

    .line 626365
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v226

    .line 626366
    sput-object v226, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_ADD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626367
    const/16 v2, 0xde

    const-string v1, "connection_detail"

    const-string v0, "CONNECTION_DETAIL"

    .line 626368
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v227

    .line 626369
    sput-object v227, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626370
    const/16 v2, 0xdf

    const-string v1, "connection_rule_editor"

    const-string v0, "CONNECTION_RULE_EDITOR"

    .line 626371
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v228

    .line 626372
    sput-object v228, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_RULE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626373
    const/16 v2, 0xe0

    const-string v1, "connection_add_permission"

    const-string v0, "CONNECTION_ADD_PERMISSION"

    .line 626374
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v229

    .line 626375
    sput-object v229, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_ADD_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626376
    const/16 v2, 0xe1

    const-string v1, "connections_share"

    const-string v0, "CONNECTIONS_SHARE"

    .line 626377
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v230

    .line 626378
    sput-object v230, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_SHARE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626379
    const/16 v2, 0xe2

    const-string v1, "connection_history"

    const-string v0, "CONNECTION_HISTORY"

    .line 626380
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v231

    .line 626381
    sput-object v231, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626382
    const/16 v2, 0xe3

    const-string v1, "peer_space"

    const-string v0, "PEER_SPACE"

    .line 626383
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v232

    .line 626384
    sput-object v232, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626385
    const/16 v2, 0xe4

    const-string v1, "connection_pairing_status"

    const-string v0, "CONNECTION_PAIRING_STATUS"

    .line 626386
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v233

    .line 626387
    sput-object v233, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_PAIRING_STATUS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626388
    const/16 v2, 0xe5

    const-string v1, "connection_accept_invite"

    const-string v0, "CONNECTION_ACCEPT_INVITE"

    .line 626389
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v234

    .line 626390
    sput-object v234, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_ACCEPT_INVITE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626391
    const/16 v2, 0xe6

    const-string v1, "connection_accept_level"

    const-string v0, "CONNECTION_ACCEPT_LEVEL"

    .line 626392
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v235

    .line 626393
    sput-object v235, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTION_ACCEPT_LEVEL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626394
    const/16 v2, 0xe7

    const-string v1, "connections_share_status"

    const-string v0, "CONNECTIONS_SHARE_STATUS"

    .line 626395
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v236

    .line 626396
    sput-object v236, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_SHARE_STATUS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626397
    const/16 v2, 0xe8

    const-string v1, "connections_received_item"

    const-string v0, "CONNECTIONS_RECEIVED_ITEM"

    .line 626398
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v237

    .line 626399
    sput-object v237, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CONNECTIONS_RECEIVED_ITEM:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626400
    const/16 v2, 0xe9

    const-string v1, "shared_goal"

    const-string v0, "SHARED_GOAL"

    .line 626401
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v238

    .line 626402
    sput-object v238, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SHARED_GOAL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626403
    const/16 v2, 0xea

    const-string v1, "peer_space_menu"

    const-string v0, "PEER_SPACE_MENU"

    .line 626404
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v239

    .line 626405
    sput-object v239, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PEER_SPACE_MENU:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626406
    const/16 v2, 0xeb

    const-string v1, "peer_space_members"

    const-string v0, "PEER_SPACE_MEMBERS"

    .line 626407
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v240

    .line 626408
    sput-object v240, Lcom/facebook/aura/analytics/hatch/HatchScreen;->PEER_SPACE_MEMBERS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626409
    const/16 v2, 0xec

    const-string v1, "space_collaborators"

    const-string v0, "SPACE_COLLABORATORS"

    .line 626410
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v241

    .line 626411
    sput-object v241, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SPACE_COLLABORATORS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626412
    const/16 v2, 0xed

    const-string v1, "space_invite_picker"

    const-string v0, "SPACE_INVITE_PICKER"

    .line 626413
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v242

    .line 626414
    sput-object v242, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SPACE_INVITE_PICKER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626415
    const/16 v2, 0xee

    const-string v1, "storage_recovery"

    const-string v0, "STORAGE_RECOVERY"

    .line 626416
    invoke-static {v0, v1, v2}, LX/602;->A0F(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v243

    .line 626417
    sput-object v243, Lcom/facebook/aura/analytics/hatch/HatchScreen;->STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626418
    const/16 v0, 0xef

    new-array v4, v0, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    filled-new-array/range {v5 .. v31}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v0

    const/4 v2, 0x0

    const/16 v3, 0x1b

    invoke-static {v0, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v32 .. v58}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v0

    invoke-static {v0, v2, v4, v3, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v59 .. v85}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0x36

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v86 .. v112}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0x51

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v113 .. v139}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0x6c

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v140 .. v166}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0x87

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v167 .. v193}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0xa2

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v194 .. v220}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v1

    const/16 v0, 0xbd

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v221 .. v243}, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    move-result-object v3

    const/16 v1, 0xd8

    const/16 v0, 0x17

    invoke-static {v3, v2, v4, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 626419
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 626420
    invoke-static {v4}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    move-result-object v0

    .line 626421
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->$ENTRIES:LX/0vk;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchScreen;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchScreen;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
