.class public final enum Lcom/facebook/aura/analytics/hatch/HatchClickPoint;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchClickPoint;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum ASSIST:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum BACK_GESTURE:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum BUTTON_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum COMPLICATION:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum CONVERSATION_STARTER:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum DEEP_LINK:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum FEED_CARD:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum HISTORY_ITEM_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum KEYBOARD_SHORTCUT:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum PUSH_NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum SEARCH_RESULT:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum SYSTEM:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum TAB_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

.field public static final enum WATCH_FACE:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 30

    .line 0
    const/4 v3, 0x0

    .line 1
    const-string v2, "tab_tap"

    .line 2
    .line 3
    const-string v1, "TAB_TAP"

    .line 4
    .line 5
    new-instance v16, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 6
    .line 7
    move-object/from16 v0, v16

    .line 8
    .line 9
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v16, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->TAB_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    const-string v1, "button_tap"

    .line 16
    .line 17
    const-string v0, "BUTTON_TAP"

    .line 18
    .line 19
    new-instance v15, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 20
    .line 21
    invoke-direct {v15, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->BUTTON_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 25
    .line 26
    const/4 v2, 0x2

    .line 27
    const-string v1, "history_item_tap"

    .line 28
    .line 29
    const-string v0, "HISTORY_ITEM_TAP"

    .line 30
    .line 31
    new-instance v14, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 32
    .line 33
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->HISTORY_ITEM_TAP:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 37
    .line 38
    const/4 v2, 0x3

    .line 39
    const-string v1, "deep_link"

    .line 40
    .line 41
    const-string v0, "DEEP_LINK"

    .line 42
    .line 43
    new-instance v13, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 44
    .line 45
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 46
    .line 47
    .line 48
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->DEEP_LINK:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 49
    .line 50
    const/4 v2, 0x4

    .line 51
    const-string v1, "push_notification"

    .line 52
    .line 53
    const-string v0, "PUSH_NOTIFICATION"

    .line 54
    .line 55
    new-instance v12, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 56
    .line 57
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 58
    .line 59
    .line 60
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->PUSH_NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 61
    .line 62
    const/4 v2, 0x5

    .line 63
    const-string v1, "conversation_starter"

    .line 64
    .line 65
    const-string v0, "CONVERSATION_STARTER"

    .line 66
    .line 67
    new-instance v11, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 68
    .line 69
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 70
    .line 71
    .line 72
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->CONVERSATION_STARTER:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 73
    .line 74
    const/4 v2, 0x6

    .line 75
    const-string v1, "search_result"

    .line 76
    .line 77
    const-string v0, "SEARCH_RESULT"

    .line 78
    .line 79
    new-instance v10, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 80
    .line 81
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 82
    .line 83
    .line 84
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->SEARCH_RESULT:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 85
    .line 86
    const/4 v2, 0x7

    .line 87
    const-string v1, "feed_card"

    .line 88
    .line 89
    const-string v0, "FEED_CARD"

    .line 90
    .line 91
    new-instance v9, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 92
    .line 93
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->FEED_CARD:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 97
    .line 98
    const/16 v2, 0x8

    .line 99
    .line 100
    const-string v1, "system"

    .line 101
    .line 102
    const-string v0, "SYSTEM"

    .line 103
    .line 104
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 105
    .line 106
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 107
    .line 108
    .line 109
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->SYSTEM:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 110
    .line 111
    const/16 v2, 0x9

    .line 112
    .line 113
    const-string v1, "back_gesture"

    .line 114
    .line 115
    const-string v0, "BACK_GESTURE"

    .line 116
    .line 117
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 118
    .line 119
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 120
    .line 121
    .line 122
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->BACK_GESTURE:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 123
    .line 124
    const/16 v2, 0xa

    .line 125
    .line 126
    const-string v1, "keyboard_shortcut"

    .line 127
    .line 128
    const-string v0, "KEYBOARD_SHORTCUT"

    .line 129
    .line 130
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 131
    .line 132
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 133
    .line 134
    .line 135
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->KEYBOARD_SHORTCUT:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 136
    .line 137
    const/16 v2, 0xb

    .line 138
    .line 139
    const-string v1, "complication"

    .line 140
    .line 141
    const-string v0, "COMPLICATION"

    .line 142
    .line 143
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 144
    .line 145
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 146
    .line 147
    .line 148
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->COMPLICATION:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 149
    .line 150
    const/16 v2, 0xc

    .line 151
    .line 152
    const-string v1, "watch_face"

    .line 153
    .line 154
    const-string v0, "WATCH_FACE"

    .line 155
    .line 156
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 157
    .line 158
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 159
    .line 160
    .line 161
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->WATCH_FACE:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 162
    .line 163
    const/16 v2, 0xd

    .line 164
    .line 165
    const-string v1, "assist"

    .line 166
    .line 167
    const-string v0, "ASSIST"

    .line 168
    .line 169
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 170
    .line 171
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 172
    .line 173
    .line 174
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->ASSIST:Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 175
    .line 176
    move-object/from16 v29, v3

    .line 177
    .line 178
    move-object/from16 v28, v4

    .line 179
    .line 180
    move-object/from16 v27, v5

    .line 181
    .line 182
    move-object/from16 v26, v6

    .line 183
    .line 184
    move-object/from16 v25, v7

    .line 185
    .line 186
    move-object/from16 v24, v8

    .line 187
    .line 188
    move-object/from16 v23, v9

    .line 189
    .line 190
    move-object/from16 v22, v10

    .line 191
    .line 192
    move-object/from16 v21, v11

    .line 193
    .line 194
    move-object/from16 v20, v12

    .line 195
    .line 196
    move-object/from16 v19, v13

    .line 197
    .line 198
    move-object/from16 v18, v14

    .line 199
    .line 200
    move-object/from16 v17, v15

    .line 201
    .line 202
    filled-new-array/range {v16 .. v29}, [Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 207
    .line 208
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->$ENTRIES:LX/0vk;

    .line 213
    .line 214
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchClickPoint;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchClickPoint;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchClickPoint;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchClickPoint;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
