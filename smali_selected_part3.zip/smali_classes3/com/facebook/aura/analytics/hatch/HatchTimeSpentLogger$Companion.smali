.class public final Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getDebugEvents()LX/2QV;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2QV<",
            "Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->debugEvents:LX/2QV;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getInstance(LX/AHE;)Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion$getInstance$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion$getInstance$1;

    .line 5
    .line 6
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;

    .line 7
    .line 8
    invoke-virtual {p1, v0, p0}, LX/0HF;->A03(Ljava/lang/Class;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;

    .line 13
    .line 14
    return-object v0
.end method
