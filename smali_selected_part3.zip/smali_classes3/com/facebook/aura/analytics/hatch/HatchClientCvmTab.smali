.class public final enum Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum CHAT:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum FEED:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum GOALS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum IDEAS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

.field public static final enum LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 0
    const-string v1, "CHAT"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v2, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 4
    .line 5
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v2, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 9
    .line 10
    const-string v1, "CONNECTIONS"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 19
    .line 20
    const-string v1, "CONNECTORS"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 24
    .line 25
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 29
    .line 30
    const-string v1, "FEED"

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 34
    .line 35
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->FEED:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 39
    .line 40
    const-string v1, "GOALS"

    .line 41
    .line 42
    const/4 v0, 0x4

    .line 43
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 44
    .line 45
    invoke-direct {v6, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->GOALS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 49
    .line 50
    const-string v1, "IDEAS"

    .line 51
    .line 52
    const/4 v0, 0x5

    .line 53
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 54
    .line 55
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->IDEAS:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 59
    .line 60
    const-string v1, "LIBRARY"

    .line 61
    .line 62
    const/4 v0, 0x6

    .line 63
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 64
    .line 65
    invoke-direct {v8, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;-><init>(Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 69
    .line 70
    filled-new-array/range {v2 .. v8}, [Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 75
    .line 76
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->$ENTRIES:LX/0vk;

    .line 81
    .line 82
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchClientCvmTab;

    .line 7
    .line 8
    return-object v0
.end method
