.class public final enum Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum CHAT:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum OTHER:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum SIDEBAR:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

.field public static final enum TAB:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "sidebar"

    .line 2
    .line 3
    const-string v0, "SIDEBAR"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->SIDEBAR:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "tab"

    .line 14
    .line 15
    const-string v0, "TAB"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->TAB:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "library"

    .line 26
    .line 27
    const-string v0, "LIBRARY"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "chat"

    .line 38
    .line 39
    const-string v0, "CHAT"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "peer_space"

    .line 50
    .line 51
    const-string v0, "PEER_SPACE"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "other"

    .line 62
    .line 63
    const-string v0, "OTHER"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->OTHER:Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 71
    .line 72
    filled-new-array/range {v3 .. v8}, [Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 77
    .line 78
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->$ENTRIES:LX/0vk;

    .line 83
    .line 84
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchSpaceEntryPoint;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
