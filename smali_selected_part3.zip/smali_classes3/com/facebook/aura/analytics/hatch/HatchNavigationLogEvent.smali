.class public final Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final clickPoint:Ljava/lang/String;

.field public final destModule:Ljava/lang/String;

.field public final eventSubtype:Ljava/lang/String;

.field public final sourceModule:Ljava/lang/String;

.field public final timestamp:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 14
    .line 15
    iput-wide p5, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 16
    .line 17
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JILjava/lang/Object;)Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-wide p5, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-wide v3, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 51
    .line 52
    iget-wide v1, p1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 53
    .line 54
    cmp-long v0, v3, v1

    .line 55
    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    :cond_0
    return v5

    .line 59
    :cond_1
    return v6
.end method

.method public final getClickPoint()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDestModule()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEventSubtype()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSourceModule()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTimestamp()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->sourceModule:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->destModule:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->clickPoint:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    add-int/2addr v1, v0

    .line 21
    mul-int/lit8 v1, v1, 0x1f

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->eventSubtype:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    add-int/2addr v1, v0

    .line 30
    mul-int/lit8 v2, v1, 0x1f

    .line 31
    .line 32
    iget-wide v0, p0, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;->timestamp:J

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/002;->A0H(J)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    add-int/2addr v2, v0

    .line 39
    return v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
