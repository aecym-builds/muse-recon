.class public final Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion;

.field public static final _debugEvents:LX/5Lx;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/5Lx<",
            "Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;",
            ">;"
        }
    .end annotation
.end field

.field public static final debugEvents:LX/2QV;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2QV<",
            "Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->Companion:Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger$Companion;

    .line 6
    .line 7
    const/16 v2, 0x20

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, LX/5NB;->A00(Ljava/lang/Integer;II)LX/Ddz;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->_debugEvents:LX/5Lx;

    .line 17
    .line 18
    invoke-static {v0}, LX/602;->A16(LX/2QV;)LX/ETm;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->debugEvents:LX/2QV;

    .line 23
    .line 24
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getDebugEvents$cp()LX/2QV;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->debugEvents:LX/2QV;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic reportNavigation$default(Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchClickPoint;Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p3, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p4, v1

    .line 11
    :cond_1
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->reportNavigation(Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchClickPoint;Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public clearUserData()V
    .locals 0

    .line 0
    return-void
.end method

.method public final reportNavigation(Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchModule;Lcom/facebook/aura/analytics/hatch/HatchClickPoint;Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;)V
    .locals 6

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchTimeSpentLogger;->_debugEvents:LX/5Lx;

    .line 5
    .line 6
    const/4 v5, 0x0

    .line 7
    if-eqz p1, :cond_5

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/facebook/aura/analytics/hatch/HatchModule;->getModuleName()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    :goto_0
    invoke-virtual {p2}, Lcom/facebook/aura/analytics/hatch/HatchModule;->getModuleName()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    if-eqz p3, :cond_4

    .line 18
    .line 19
    invoke-virtual {p3}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->getValue()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    :goto_1
    if-eqz p4, :cond_0

    .line 24
    .line 25
    invoke-virtual {p4}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->getValue()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 30
    .line 31
    .line 32
    move-result-wide p0

    .line 33
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;

    .line 34
    .line 35
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchNavigationLogEvent;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    .line 36
    .line 37
    .line 38
    invoke-interface {v0, v1}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    invoke-static {}, LX/602;->A10()LX/Imj;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->Companion:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;

    .line 46
    .line 47
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion;->getDevice()Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->getValue()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-string v0, "device_type"

    .line 56
    .line 57
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLocale;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceLocale;

    .line 61
    .line 62
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceLocale;->getIdentifier()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    if-eqz v1, :cond_1

    .line 67
    .line 68
    const-string v0, "device_locale"

    .line 69
    .line 70
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    :cond_1
    if-eqz p3, :cond_2

    .line 74
    .line 75
    const-string v1, "click_point"

    .line 76
    .line 77
    invoke-virtual {p3}, Lcom/facebook/aura/analytics/hatch/HatchClickPoint;->getValue()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    :cond_2
    if-eqz p4, :cond_3

    .line 85
    .line 86
    const-string v1, "event_subtype"

    .line 87
    .line 88
    invoke-virtual {p4}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->getValue()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    :cond_3
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    sget-object v3, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 100
    .line 101
    invoke-virtual {p2}, Lcom/facebook/aura/analytics/hatch/HatchModule;->getModuleName()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    invoke-virtual {p2}, Lcom/facebook/aura/analytics/hatch/HatchModule;->getModuleClassName()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {p2}, Ljava/lang/Object;->hashCode()I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    invoke-interface {v3, v2, v1, v0, v4}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->reportNavigationEventForComposable(Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;)V

    .line 114
    .line 115
    .line 116
    return-void

    .line 117
    :cond_4
    move-object v4, v5

    .line 118
    goto :goto_1

    .line 119
    :cond_5
    move-object v2, v5

    .line 120
    goto :goto_0
.end method
