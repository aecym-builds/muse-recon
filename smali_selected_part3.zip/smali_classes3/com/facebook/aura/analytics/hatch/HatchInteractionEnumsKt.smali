.class public abstract Lcom/facebook/aura/analytics/hatch/HatchInteractionEnumsKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final chatScreen(Z)Lcom/facebook/aura/analytics/hatch/HatchScreen;
    .locals 0

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    return-object p0

    .line 5
    :cond_0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SUBTHREAD:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 6
    .line 7
    return-object p0
.end method

.method public static final chatThreadLogMetadata(ZLjava/lang/String;Ljava/lang/Boolean;Ljava/util/Map;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {}, LX/602;->A10()LX/Imj;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->IS_PRIMARY_THREAD:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 9
    .line 10
    invoke-static {v0, v2, p0}, LX/602;->A1B(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;LX/Imj;Z)V

    .line 11
    .line 12
    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->THREAD_ID:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 16
    .line 17
    invoke-static {v0, p1, v2}, LX/3Rr;->A16(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;Ljava/lang/Object;LX/Imj;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    if-eqz p2, :cond_1

    .line 21
    .line 22
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->IS_ARCHIVED:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 27
    .line 28
    invoke-static {v0, v2, v1}, LX/602;->A1B(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;LX/Imj;Z)V

    .line 29
    .line 30
    .line 31
    :cond_1
    invoke-virtual {v2, p3}, LX/Imj;->putAll(Ljava/util/Map;)V

    .line 32
    .line 33
    .line 34
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0
.end method

.method public static synthetic chatThreadLogMetadata$default(ZLjava/lang/String;Ljava/lang/Boolean;Ljava/util/Map;ILjava/lang/Object;)Ljava/util/Map;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    and-int/lit8 v0, p4, 0x8

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 10
    .line 11
    .line 12
    move-result-object p3

    .line 13
    :cond_1
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchInteractionEnumsKt;->chatThreadLogMetadata(ZLjava/lang/String;Ljava/lang/Boolean;Ljava/util/Map;)Ljava/util/Map;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public static final getOriginIdMetadataKey(Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;)Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;
    .locals 0

    .line 0
    invoke-static {p0}, LX/008;->A0S(Ljava/lang/Enum;)I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    throw p0

    .line 12
    :pswitch_0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->FEED_CARD_ID:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_1
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->GOAL_ID:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 16
    .line 17
    return-object p0

    .line 18
    :pswitch_2
    const/4 p0, 0x0

    .line 19
    return-object p0

    .line 20
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_2
    .end packed-switch
.end method
