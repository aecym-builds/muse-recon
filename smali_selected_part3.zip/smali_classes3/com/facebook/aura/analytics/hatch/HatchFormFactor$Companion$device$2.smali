.class public final Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/analytics/hatch/HatchFormFactor;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/analytics/hatch/HatchFormFactor;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/ui/adaptive/AuraDevice;->INSTANCE:Lcom/facebook/aura/ui/adaptive/AuraDevice;

    .line 1
    .line 2
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {p0, v0}, Lcom/facebook/aura/ui/adaptive/AuraDevice;->type(Landroid/content/Context;)Lcom/facebook/aura/ui/adaptive/AuraDeviceType;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    const/4 v0, 0x0

    .line 15
    if-eq p0, v0, :cond_4

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    if-eq p0, v0, :cond_3

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    if-eq p0, v0, :cond_2

    .line 22
    .line 23
    const/4 v0, 0x3

    .line 24
    if-eq p0, v0, :cond_1

    .line 25
    .line 26
    const/4 v0, 0x4

    .line 27
    if-ne p0, v0, :cond_0

    .line 28
    .line 29
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->CAR:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    throw v0

    .line 37
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->WATCH:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->TABLET:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 41
    .line 42
    return-object v0

    .line 43
    :cond_3
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->FOLDABLE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 44
    .line 45
    return-object v0

    .line 46
    :cond_4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFormFactor;->PHONE:Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 47
    .line 48
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchFormFactor$Companion$device$2;->invoke()Lcom/facebook/aura/analytics/hatch/HatchFormFactor;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
