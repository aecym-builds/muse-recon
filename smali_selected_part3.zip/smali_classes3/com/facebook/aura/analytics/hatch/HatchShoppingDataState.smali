.class public final enum Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

.field public static final enum FRESH:Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

.field public static final enum SAVED:Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "fresh"

    .line 2
    .line 3
    const-string v0, "FRESH"

    .line 4
    .line 5
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 6
    .line 7
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->FRESH:Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    const-string v2, "saved"

    .line 14
    .line 15
    const-string v1, "SAVED"

    .line 16
    .line 17
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 18
    .line 19
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->SAVED:Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 23
    .line 24
    filled-new-array {v4, v0}, [Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 29
    .line 30
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->$ENTRIES:LX/0vk;

    .line 35
    .line 36
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchShoppingDataState;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
