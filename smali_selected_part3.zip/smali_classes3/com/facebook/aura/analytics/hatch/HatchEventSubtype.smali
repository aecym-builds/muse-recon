.class public final enum Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum BACKGROUND:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum BACK_NAVIGATION:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum CONVERSATION_OPEN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum DEEP_LINK:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum FOREGROUND:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum HIDE_MODULE:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum PUSH_NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum RESIGN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum STATUS_CLOSE:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum STATUS_OPEN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

.field public static final enum TAB_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 14

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "foreground"

    .line 2
    .line 3
    const-string v0, "FOREGROUND"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->FOREGROUND:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "background"

    .line 14
    .line 15
    const-string v0, "BACKGROUND"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->BACKGROUND:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "resign"

    .line 26
    .line 27
    const-string v0, "RESIGN"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->RESIGN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "conversation_open"

    .line 38
    .line 39
    const-string v0, "CONVERSATION_OPEN"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->CONVERSATION_OPEN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "hide_module"

    .line 50
    .line 51
    const-string v0, "HIDE_MODULE"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->HIDE_MODULE:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "tab_switch"

    .line 62
    .line 63
    const-string v0, "TAB_SWITCH"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->TAB_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "deep_link"

    .line 74
    .line 75
    const-string v0, "DEEP_LINK"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->DEEP_LINK:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 83
    .line 84
    const/4 v2, 0x7

    .line 85
    const-string v1, "push_notification"

    .line 86
    .line 87
    const-string v0, "PUSH_NOTIFICATION"

    .line 88
    .line 89
    new-instance v10, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 90
    .line 91
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->PUSH_NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 95
    .line 96
    const/16 v2, 0x8

    .line 97
    .line 98
    const-string v1, "back_navigation"

    .line 99
    .line 100
    const-string v0, "BACK_NAVIGATION"

    .line 101
    .line 102
    new-instance v11, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 103
    .line 104
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->BACK_NAVIGATION:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 108
    .line 109
    const/16 v2, 0x9

    .line 110
    .line 111
    const-string v1, "status_open"

    .line 112
    .line 113
    const-string v0, "STATUS_OPEN"

    .line 114
    .line 115
    new-instance v12, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 116
    .line 117
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 118
    .line 119
    .line 120
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->STATUS_OPEN:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 121
    .line 122
    const/16 v2, 0xa

    .line 123
    .line 124
    const-string v1, "status_close"

    .line 125
    .line 126
    const-string v0, "STATUS_CLOSE"

    .line 127
    .line 128
    new-instance v13, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 129
    .line 130
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 131
    .line 132
    .line 133
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->STATUS_CLOSE:Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 134
    .line 135
    filled-new-array/range {v3 .. v13}, [Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 140
    .line 141
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->$ENTRIES:LX/0vk;

    .line 146
    .line 147
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
