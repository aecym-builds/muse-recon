.class public final enum Lcom/facebook/aura/analytics/hatch/HatchSubsurface;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchSubsurface;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ACCOUNTS_CENTER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ADD_HOME_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ARTIFACT_SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ARTIFACT_TOOLBAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum BIOMETRICS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum BLUETOOTH_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum BOT_SHEET_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CALENDAR_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CALL_LOG_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CITATION_SECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum COMPOSER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTIONS_ACTIVITY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTIONS_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTIONS_ROW:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTIONS_SUGGESTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTION_COLLABORATING:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTION_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTION_STATUS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONNECTOR_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONTACTS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CONVERSATION_STARTER_AREA:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CREDITS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum CREDITS_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DEFAULT_ASSISTANT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DESTINATION_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DEVICES:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DOCUMENT_OPTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum DOT_MENU:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum FEATURE_INVITE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum FEED_EMPTY_STATE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum FEED_PROMPT_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum FEED_WIDGET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum GOALS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum GOAL_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum GOAL_RENAME_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum HEADER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum HELP_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum IMPORT_MEMORY_TO_HATCH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum KEYBOARD_ACCESSORY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum LEGAL_INFO:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum LOCATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum MEDIA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum MESSAGES_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum MESSAGE_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum MICROPHONE_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ONBOARDING_CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ONBOARDING_IDENTITY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ONBOARDING_PRE_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum ONBOARDING_TASKS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum PHONE_NOTIFICATIONS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum PUBLISH_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum RECIPIENT_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum RESPONSE_TOOLBAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SECURE_STORAGE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SECURE_STORAGE_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SETTINGS_ACCOUNT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SETTINGS_GENERAL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SETTINGS_MODEL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SETTINGS_PRIVACY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SPACES_CAROUSEL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SPACES_EMPTY_STATE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SPACES_REORDER_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SPACE_ACCESS_REQUESTS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SPACE_INVITE_CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum STORAGE_RECOVERY_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum STORAGE_RECOVERY_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SUBSCRIPTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SURVEY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum SWIPE_ACTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_CHAT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_FEED:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_IDEAS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TAB_SPACE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TASK_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum THINKING_SECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum TOUR_WELCOME:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum VOICE_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum VOICE_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum VOICE_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum WALLET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public static final enum WEARABLES_LINKING:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 102

    .line 626422
    const/4 v2, 0x0

    const-string v1, "composer"

    const-string v0, "COMPOSER"

    .line 626423
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v5

    .line 626424
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->COMPOSER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626425
    const/4 v2, 0x1

    const-string v1, "message_list"

    const-string v0, "MESSAGE_LIST"

    .line 626426
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v6

    .line 626427
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->MESSAGE_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626428
    const/4 v2, 0x2

    const-string v1, "citation_section"

    const-string v0, "CITATION_SECTION"

    .line 626429
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v7

    .line 626430
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CITATION_SECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626431
    const/4 v2, 0x3

    const-string v1, "thinking_section"

    const-string v0, "THINKING_SECTION"

    .line 626432
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v8

    .line 626433
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->THINKING_SECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626434
    const/4 v2, 0x4

    const-string v1, "response_toolbar"

    const-string v0, "RESPONSE_TOOLBAR"

    .line 626435
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v9

    .line 626436
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->RESPONSE_TOOLBAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626437
    const/4 v2, 0x5

    const-string v1, "conversation_starter_area"

    const-string v0, "CONVERSATION_STARTER_AREA"

    .line 626438
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v10

    .line 626439
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONVERSATION_STARTER_AREA:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626440
    const/4 v2, 0x6

    const-string v1, "tab_bar"

    const-string v0, "TAB_BAR"

    .line 626441
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v11

    .line 626442
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626443
    const/4 v2, 0x7

    const-string v1, "nav_bar"

    const-string v0, "NAV_BAR"

    .line 626444
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v12

    .line 626445
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626446
    const/16 v2, 0x8

    const-string v1, "tab_chat"

    const-string v0, "TAB_CHAT"

    .line 626447
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v13

    .line 626448
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_CHAT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626449
    const/16 v2, 0x9

    const-string v1, "tab_feed"

    const-string v0, "TAB_FEED"

    .line 626450
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v14

    .line 626451
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_FEED:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626452
    const/16 v2, 0xa

    const-string v1, "tab_ideas"

    const-string v0, "TAB_IDEAS"

    .line 626453
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v15

    .line 626454
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_IDEAS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626455
    const/16 v2, 0xb

    const-string v1, "tab_library"

    const-string v0, "TAB_LIBRARY"

    .line 626456
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v16

    .line 626457
    sput-object v16, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626458
    const/16 v2, 0xc

    const-string v1, "goals"

    const-string v0, "GOALS"

    .line 626459
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v17

    .line 626460
    sput-object v17, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->GOALS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626461
    const/16 v2, 0xd

    const-string v1, "goal_rename_dialog"

    const-string v0, "GOAL_RENAME_DIALOG"

    .line 626462
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v18

    .line 626463
    sput-object v18, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->GOAL_RENAME_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626464
    const/16 v2, 0xe

    const-string v1, "goal_delete_dialog"

    const-string v0, "GOAL_DELETE_DIALOG"

    .line 626465
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v19

    .line 626466
    sput-object v19, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->GOAL_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626467
    const/16 v2, 0xf

    const-string v1, "tab_settings"

    const-string v0, "TAB_SETTINGS"

    .line 626468
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v20

    .line 626469
    sput-object v20, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626470
    const/16 v2, 0x10

    const-string v1, "tab_space"

    const-string v0, "TAB_SPACE"

    .line 626471
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v21

    .line 626472
    sput-object v21, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TAB_SPACE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626473
    const/16 v2, 0x11

    const-string v1, "header"

    const-string v0, "HEADER"

    .line 626474
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v22

    .line 626475
    sput-object v22, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->HEADER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626476
    const/16 v2, 0x12

    const-string v1, "feed_widget"

    const-string v0, "FEED_WIDGET"

    .line 626477
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v23

    .line 626478
    sput-object v23, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->FEED_WIDGET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626479
    const/16 v2, 0x13

    const-string v1, "feed_empty_state"

    const-string v0, "FEED_EMPTY_STATE"

    .line 626480
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v24

    .line 626481
    sput-object v24, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->FEED_EMPTY_STATE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626482
    const/16 v2, 0x14

    const-string v1, "feed_prompt_editor"

    const-string v0, "FEED_PROMPT_EDITOR"

    .line 626483
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v25

    .line 626484
    sput-object v25, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->FEED_PROMPT_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626485
    const/16 v2, 0x15

    const-string v1, "settings_general"

    const-string v0, "SETTINGS_GENERAL"

    .line 626486
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v26

    .line 626487
    sput-object v26, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SETTINGS_GENERAL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626488
    const/16 v2, 0x16

    const-string v1, "settings_account"

    const-string v0, "SETTINGS_ACCOUNT"

    .line 626489
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v27

    .line 626490
    sput-object v27, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SETTINGS_ACCOUNT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626491
    const/16 v2, 0x17

    const-string v1, "settings_privacy"

    const-string v0, "SETTINGS_PRIVACY"

    .line 626492
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v28

    .line 626493
    sput-object v28, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SETTINGS_PRIVACY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626494
    const/16 v2, 0x18

    const-string v1, "settings_model"

    const-string v0, "SETTINGS_MODEL"

    .line 626495
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v29

    .line 626496
    sput-object v29, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SETTINGS_MODEL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626497
    const/16 v2, 0x19

    const-string v1, "voice_controls"

    const-string v0, "VOICE_CONTROLS"

    .line 626498
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v30

    .line 626499
    sput-object v30, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->VOICE_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626500
    const/16 v2, 0x1a

    const-string v1, "voice_selection"

    const-string v0, "VOICE_SELECTION"

    .line 626501
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v31

    .line 626502
    sput-object v31, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->VOICE_SELECTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626503
    const/16 v2, 0x1b

    const-string v1, "voice_settings"

    const-string v0, "VOICE_SETTINGS"

    .line 626504
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v32

    .line 626505
    sput-object v32, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->VOICE_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626506
    const/16 v2, 0x1c

    const-string v1, "channels"

    const-string v0, "CHANNELS"

    .line 626507
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v33

    .line 626508
    sput-object v33, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CHANNELS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626509
    const/16 v2, 0x1d

    const-string v1, "devices"

    const-string v0, "DEVICES"

    .line 626510
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v34

    .line 626511
    sput-object v34, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DEVICES:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626512
    const/16 v2, 0x1e

    const-string v1, "connectors"

    const-string v0, "CONNECTORS"

    .line 626513
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v35

    .line 626514
    sput-object v35, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626515
    const/16 v2, 0x1f

    const-string v1, "wallet"

    const-string v0, "WALLET"

    .line 626516
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v36

    .line 626517
    sput-object v36, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->WALLET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626518
    const/16 v2, 0x20

    const-string v1, "redeem_invite_code"

    const-string v0, "REDEEM_INVITE_CODE"

    .line 626519
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v37

    .line 626520
    sput-object v37, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626521
    const/16 v2, 0x21

    const-string v1, "permissions"

    const-string v0, "PERMISSIONS"

    .line 626522
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v38

    .line 626523
    sput-object v38, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626524
    const/16 v2, 0x22

    const-string v1, "data_controls"

    const-string v0, "DATA_CONTROLS"

    .line 626525
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v39

    .line 626526
    sput-object v39, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DATA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626527
    const/16 v2, 0x23

    const-string v1, "encryption"

    const-string v0, "ENCRYPTION"

    .line 626528
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v40

    .line 626529
    sput-object v40, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ENCRYPTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626530
    const/16 v2, 0x24

    const-string v1, "import_memory_to_hatch"

    const-string v0, "IMPORT_MEMORY_TO_HATCH"

    .line 626531
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v41

    .line 626532
    sput-object v41, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->IMPORT_MEMORY_TO_HATCH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626533
    const/16 v2, 0x25

    const-string v1, "notifications"

    const-string v0, "NOTIFICATIONS"

    .line 626534
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v42

    .line 626535
    sput-object v42, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->NOTIFICATIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626536
    const/16 v2, 0x26

    const-string v1, "appearance"

    const-string v0, "APPEARANCE"

    .line 626537
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v43

    .line 626538
    sput-object v43, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626539
    const/16 v2, 0x27

    const-string v1, "biometrics"

    const-string v0, "BIOMETRICS"

    .line 626540
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v44

    .line 626541
    sput-object v44, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BIOMETRICS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626542
    const/16 v2, 0x28

    const-string v1, "default_assistant"

    const-string v0, "DEFAULT_ASSISTANT"

    .line 626543
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v45

    .line 626544
    sput-object v45, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DEFAULT_ASSISTANT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626545
    const/16 v2, 0x29

    const-string v1, "add_home_screen"

    const-string v0, "ADD_HOME_SCREEN"

    .line 626546
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v46

    .line 626547
    sput-object v46, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ADD_HOME_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626548
    const/16 v2, 0x2a

    const-string v1, "help_support"

    const-string v0, "HELP_SUPPORT"

    .line 626549
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v47

    .line 626550
    sput-object v47, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->HELP_SUPPORT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626551
    const/16 v2, 0x2b

    const-string v1, "legal_info"

    const-string v0, "LEGAL_INFO"

    .line 626552
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v48

    .line 626553
    sput-object v48, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->LEGAL_INFO:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626554
    const/16 v2, 0x2c

    const-string v1, "accounts_center"

    const-string v0, "ACCOUNTS_CENTER"

    .line 626555
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v49

    .line 626556
    sput-object v49, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ACCOUNTS_CENTER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626557
    const/16 v2, 0x2d

    const-string v1, "internal_settings"

    const-string v0, "INTERNAL_SETTINGS"

    .line 626558
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v50

    .line 626559
    sput-object v50, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626560
    const/16 v2, 0x2e

    const-string v1, "bug_report"

    const-string v0, "BUG_REPORT"

    .line 626561
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v51

    .line 626562
    sput-object v51, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626563
    const/16 v2, 0x2f

    const-string v1, "location_permission"

    const-string v0, "LOCATION_PERMISSION"

    .line 626564
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v52

    .line 626565
    sput-object v52, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->LOCATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626566
    const/16 v2, 0x30

    const-string v1, "contacts_permission"

    const-string v0, "CONTACTS_PERMISSION"

    .line 626567
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v53

    .line 626568
    sput-object v53, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONTACTS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626569
    const/16 v2, 0x31

    const-string v1, "calendar_permission"

    const-string v0, "CALENDAR_PERMISSION"

    .line 626570
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v54

    .line 626571
    sput-object v54, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CALENDAR_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626572
    const/16 v2, 0x32

    const-string v1, "messages_permission"

    const-string v0, "MESSAGES_PERMISSION"

    .line 626573
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v55

    .line 626574
    sput-object v55, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->MESSAGES_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626575
    const/16 v2, 0x33

    const-string v1, "call_log_permission"

    const-string v0, "CALL_LOG_PERMISSION"

    .line 626576
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v56

    .line 626577
    sput-object v56, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CALL_LOG_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626578
    const/16 v2, 0x34

    const-string v1, "phone_notifications_permission"

    const-string v0, "PHONE_NOTIFICATIONS_PERMISSION"

    .line 626579
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v57

    .line 626580
    sput-object v57, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->PHONE_NOTIFICATIONS_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626581
    const/16 v2, 0x35

    const-string v1, "microphone_permission"

    const-string v0, "MICROPHONE_PERMISSION"

    .line 626582
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v58

    .line 626583
    sput-object v58, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->MICROPHONE_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626584
    const/16 v2, 0x36

    const-string v1, "bluetooth_permission"

    const-string v0, "BLUETOOTH_PERMISSION"

    .line 626585
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v59

    .line 626586
    sput-object v59, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BLUETOOTH_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626587
    const/16 v2, 0x37

    const-string v1, "dot_menu"

    const-string v0, "DOT_MENU"

    .line 626588
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v60

    .line 626589
    sput-object v60, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DOT_MENU:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626590
    const/16 v2, 0x38

    const-string v1, "agent_permission"

    const-string v0, "AGENT_PERMISSION"

    .line 626591
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v61

    .line 626592
    sput-object v61, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626593
    const/16 v2, 0x39

    const-string v1, "keyboard_accessory"

    const-string v0, "KEYBOARD_ACCESSORY"

    .line 626594
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v62

    .line 626595
    sput-object v62, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->KEYBOARD_ACCESSORY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626596
    const/16 v2, 0x3a

    const-string v1, "media_controls"

    const-string v0, "MEDIA_CONTROLS"

    .line 626597
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v63

    .line 626598
    sput-object v63, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->MEDIA_CONTROLS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626599
    const/16 v2, 0x3b

    const-string v1, "artifact_toolbar"

    const-string v0, "ARTIFACT_TOOLBAR"

    .line 626600
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v64

    .line 626601
    sput-object v64, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ARTIFACT_TOOLBAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626602
    const/16 v2, 0x3c

    const-string v1, "task_list"

    const-string v0, "TASK_LIST"

    .line 626603
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v65

    .line 626604
    sput-object v65, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TASK_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626605
    const/16 v2, 0x3d

    const-string v1, "bot_sheet_content"

    const-string v0, "BOT_SHEET_CONTENT"

    .line 626606
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v66

    .line 626607
    sput-object v66, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BOT_SHEET_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626608
    const/16 v2, 0x3e

    const-string v1, "credits_sheet"

    const-string v0, "CREDITS_SHEET"

    .line 626609
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v67

    .line 626610
    sput-object v67, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CREDITS_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626611
    const/16 v2, 0x3f

    const-string v1, "onboarding_pre_auth"

    const-string v0, "ONBOARDING_PRE_AUTH"

    .line 626612
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v68

    .line 626613
    sput-object v68, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_PRE_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626614
    const/16 v2, 0x40

    const-string v1, "onboarding_post_auth"

    const-string v0, "ONBOARDING_POST_AUTH"

    .line 626615
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v69

    .line 626616
    sput-object v69, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626617
    const/16 v2, 0x41

    const-string v1, "welcome"

    const-string v0, "TOUR_WELCOME"

    .line 626618
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v70

    .line 626619
    sput-object v70, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->TOUR_WELCOME:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626620
    const/16 v2, 0x42

    const-string v1, "onboarding_connectors"

    const-string v0, "ONBOARDING_CONNECTORS"

    .line 626621
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v71

    .line 626622
    sput-object v71, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_CONNECTORS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626623
    const/16 v2, 0x43

    const-string v1, "onboarding_tasks"

    const-string v0, "ONBOARDING_TASKS"

    .line 626624
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v72

    .line 626625
    sput-object v72, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_TASKS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626626
    const/16 v2, 0x44

    const-string v1, "onboarding_identity"

    const-string v0, "ONBOARDING_IDENTITY"

    .line 626627
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v73

    .line 626628
    sput-object v73, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_IDENTITY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626629
    const/16 v2, 0x45

    const-string v1, "connector_auth"

    const-string v0, "CONNECTOR_AUTH"

    .line 626630
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v74

    .line 626631
    sput-object v74, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTOR_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626632
    const/16 v2, 0x46

    const-string v1, "spaces_carousel"

    const-string v0, "SPACES_CAROUSEL"

    .line 626633
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v75

    .line 626634
    sput-object v75, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SPACES_CAROUSEL:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626635
    const/16 v2, 0x47

    const-string v1, "spaces_reorder_sheet"

    const-string v0, "SPACES_REORDER_SHEET"

    .line 626636
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v76

    .line 626637
    sput-object v76, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SPACES_REORDER_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626638
    const/16 v2, 0x48

    const-string v1, "spaces_empty_state"

    const-string v0, "SPACES_EMPTY_STATE"

    .line 626639
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v77

    .line 626640
    sput-object v77, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SPACES_EMPTY_STATE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626641
    const/16 v2, 0x49

    const-string v1, "document_options"

    const-string v0, "DOCUMENT_OPTIONS"

    .line 626642
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v78

    .line 626643
    sput-object v78, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DOCUMENT_OPTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626644
    const/16 v2, 0x4a

    const-string v1, "publish_sheet"

    const-string v0, "PUBLISH_SHEET"

    .line 626645
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v79

    .line 626646
    sput-object v79, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->PUBLISH_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626647
    const/16 v2, 0x4b

    const-string v1, "artifact_share_sheet"

    const-string v0, "ARTIFACT_SHARE_SHEET"

    .line 626648
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v80

    .line 626649
    sput-object v80, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ARTIFACT_SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626650
    const/16 v2, 0x4c

    const-string v1, "destination_bar"

    const-string v0, "DESTINATION_BAR"

    .line 626651
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v81

    .line 626652
    sput-object v81, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DESTINATION_BAR:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626653
    const/16 v2, 0x4d

    const-string v1, "recipient_list"

    const-string v0, "RECIPIENT_LIST"

    .line 626654
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v82

    .line 626655
    sput-object v82, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->RECIPIENT_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626656
    const/16 v2, 0x4e

    const-string v1, "credits"

    const-string v0, "CREDITS"

    .line 626657
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v83

    .line 626658
    sput-object v83, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CREDITS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626659
    const/16 v2, 0x4f

    const-string v1, "subscription"

    const-string v0, "SUBSCRIPTION"

    .line 626660
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v84

    .line 626661
    sput-object v84, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SUBSCRIPTION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626662
    const/16 v2, 0x50

    const-string v1, "secure_storage_delete_dialog"

    const-string v0, "SECURE_STORAGE_DELETE_DIALOG"

    .line 626663
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v85

    .line 626664
    sput-object v85, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SECURE_STORAGE_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626665
    const/16 v2, 0x51

    const-string v1, "survey"

    const-string v0, "SURVEY"

    .line 626666
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v86

    .line 626667
    sput-object v86, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SURVEY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626668
    const/16 v2, 0x52

    const-string v1, "swipe_actions"

    const-string v0, "SWIPE_ACTIONS"

    .line 626669
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v87

    .line 626670
    sput-object v87, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SWIPE_ACTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626671
    const/16 v2, 0x53

    const-string v1, "wearables_linking"

    const-string v0, "WEARABLES_LINKING"

    .line 626672
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v88

    .line 626673
    sput-object v88, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->WEARABLES_LINKING:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626674
    const/16 v2, 0x54

    const-string v1, "secure_storage"

    const-string v0, "SECURE_STORAGE"

    .line 626675
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v89

    .line 626676
    sput-object v89, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SECURE_STORAGE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626677
    const/16 v2, 0x55

    const-string v1, "connections_suggestions"

    const-string v0, "CONNECTIONS_SUGGESTIONS"

    .line 626678
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v90

    .line 626679
    sput-object v90, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTIONS_SUGGESTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626680
    const/16 v2, 0x56

    const-string v1, "connections_row"

    const-string v0, "CONNECTIONS_ROW"

    .line 626681
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v91

    .line 626682
    sput-object v91, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTIONS_ROW:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626683
    const/16 v2, 0x57

    const-string v1, "connections_activity"

    const-string v0, "CONNECTIONS_ACTIVITY"

    .line 626684
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v92

    .line 626685
    sput-object v92, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTIONS_ACTIVITY:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626686
    const/16 v2, 0x58

    const-string v1, "connection_status"

    const-string v0, "CONNECTION_STATUS"

    .line 626687
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v93

    .line 626688
    sput-object v93, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTION_STATUS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626689
    const/16 v2, 0x59

    const-string v1, "connection_permissions"

    const-string v0, "CONNECTION_PERMISSIONS"

    .line 626690
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v94

    .line 626691
    sput-object v94, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTION_PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626692
    const/16 v2, 0x5a

    const-string v1, "connection_collaborating"

    const-string v0, "CONNECTION_COLLABORATING"

    .line 626693
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v95

    .line 626694
    sput-object v95, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTION_COLLABORATING:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626695
    const/16 v2, 0x5b

    const-string v1, "connections_dialog"

    const-string v0, "CONNECTIONS_DIALOG"

    .line 626696
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v96

    .line 626697
    sput-object v96, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->CONNECTIONS_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626698
    const/16 v2, 0x5c

    const-string v1, "feature_invite"

    const-string v0, "FEATURE_INVITE"

    .line 626699
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v97

    .line 626700
    sput-object v97, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->FEATURE_INVITE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626701
    const/16 v2, 0x5d

    const-string v1, "space_access_requests"

    const-string v0, "SPACE_ACCESS_REQUESTS"

    .line 626702
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v98

    .line 626703
    sput-object v98, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SPACE_ACCESS_REQUESTS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626704
    const/16 v2, 0x5e

    const-string v1, "space_invite_connections"

    const-string v0, "SPACE_INVITE_CONNECTIONS"

    .line 626705
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v99

    .line 626706
    sput-object v99, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->SPACE_INVITE_CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626707
    const/16 v2, 0x5f

    const-string v1, "storage_recovery_delete_dialog"

    const-string v0, "STORAGE_RECOVERY_DELETE_DIALOG"

    .line 626708
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v100

    .line 626709
    sput-object v100, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->STORAGE_RECOVERY_DELETE_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626710
    const/16 v2, 0x60

    const-string v1, "storage_recovery_error_dialog"

    const-string v0, "STORAGE_RECOVERY_ERROR_DIALOG"

    .line 626711
    invoke-static {v0, v1, v2}, LX/602;->A0G(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v101

    .line 626712
    sput-object v101, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->STORAGE_RECOVERY_ERROR_DIALOG:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626713
    const/16 v0, 0x61

    new-array v4, v0, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    filled-new-array/range {v5 .. v31}, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v0

    const/4 v2, 0x0

    const/16 v3, 0x1b

    invoke-static {v0, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v32 .. v58}, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v0

    invoke-static {v0, v2, v4, v3, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v59 .. v85}, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v1

    const/16 v0, 0x36

    invoke-static {v1, v2, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    filled-new-array/range {v86 .. v101}, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    move-result-object v3

    const/16 v1, 0x51

    const/16 v0, 0x10

    invoke-static {v3, v2, v4, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 626714
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 626715
    invoke-static {v4}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    move-result-object v0

    .line 626716
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->$ENTRIES:LX/0vk;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchSubsurface;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchSubsurface;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchSubsurface;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
