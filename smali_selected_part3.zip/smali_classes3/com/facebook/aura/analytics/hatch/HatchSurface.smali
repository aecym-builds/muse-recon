.class public final enum Lcom/facebook/aura/analytics/hatch/HatchSurface;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchSurface;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CVM_DOWNGRADE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CVM_PIN_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CVM_REPLACEMENT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum FEED:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum GOALS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum IDEAS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum MODEL_SELECTOR:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum MONETIZATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum NODES:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum PROFILE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SEARCH:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SHOPPING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SPACES:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum STATUS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum SURVEY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum UPSELL:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum VM_DISCONNECTED:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum VOICE_MODE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

.field public static final enum WEARABLES:Lcom/facebook/aura/analytics/hatch/HatchSurface;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 37

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "chat"

    .line 2
    .line 3
    const-string v0, "CHAT"

    .line 4
    .line 5
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    const-string v1, "feed"

    .line 13
    .line 14
    const-string v0, "FEED"

    .line 15
    .line 16
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchSurface;->FEED:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 21
    .line 22
    const/4 v2, 0x2

    .line 23
    const-string v1, "ideas"

    .line 24
    .line 25
    const-string v0, "IDEAS"

    .line 26
    .line 27
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchSurface;->IDEAS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 32
    .line 33
    const/4 v2, 0x3

    .line 34
    const-string v1, "library"

    .line 35
    .line 36
    const-string v0, "LIBRARY"

    .line 37
    .line 38
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 39
    .line 40
    .line 41
    move-result-object v6

    .line 42
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchSurface;->LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 43
    .line 44
    const/4 v2, 0x4

    .line 45
    const-string v1, "goals"

    .line 46
    .line 47
    const-string v0, "GOALS"

    .line 48
    .line 49
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 50
    .line 51
    .line 52
    move-result-object v7

    .line 53
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchSurface;->GOALS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 54
    .line 55
    const/4 v2, 0x5

    .line 56
    const-string v1, "connections"

    .line 57
    .line 58
    const-string v0, "CONNECTIONS"

    .line 59
    .line 60
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 61
    .line 62
    .line 63
    move-result-object v8

    .line 64
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 65
    .line 66
    const/4 v2, 0x6

    .line 67
    const-string v1, "settings"

    .line 68
    .line 69
    const-string v0, "SETTINGS"

    .line 70
    .line 71
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 76
    .line 77
    const/4 v2, 0x7

    .line 78
    const-string v1, "internal_settings"

    .line 79
    .line 80
    const-string v0, "INTERNAL_SETTINGS"

    .line 81
    .line 82
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 83
    .line 84
    .line 85
    move-result-object v10

    .line 86
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchSurface;->INTERNAL_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 87
    .line 88
    const/16 v2, 0x8

    .line 89
    .line 90
    const-string v1, "profile"

    .line 91
    .line 92
    const-string v0, "PROFILE"

    .line 93
    .line 94
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 95
    .line 96
    .line 97
    move-result-object v11

    .line 98
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchSurface;->PROFILE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 99
    .line 100
    const/16 v2, 0x9

    .line 101
    .line 102
    const-string v1, "search"

    .line 103
    .line 104
    const-string v0, "SEARCH"

    .line 105
    .line 106
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 107
    .line 108
    .line 109
    move-result-object v12

    .line 110
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SEARCH:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 111
    .line 112
    const/16 v2, 0xa

    .line 113
    .line 114
    const-string v1, "onboarding"

    .line 115
    .line 116
    const-string v0, "ONBOARDING"

    .line 117
    .line 118
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 119
    .line 120
    .line 121
    move-result-object v13

    .line 122
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 123
    .line 124
    const/16 v2, 0xb

    .line 125
    .line 126
    const-string v1, "age_confirmation"

    .line 127
    .line 128
    const-string v0, "AGE_CONFIRMATION"

    .line 129
    .line 130
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 131
    .line 132
    .line 133
    move-result-object v14

    .line 134
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchSurface;->AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 135
    .line 136
    const/16 v2, 0xc

    .line 137
    .line 138
    const-string v1, "voice_mode"

    .line 139
    .line 140
    const-string v0, "VOICE_MODE"

    .line 141
    .line 142
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 143
    .line 144
    .line 145
    move-result-object v15

    .line 146
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchSurface;->VOICE_MODE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 147
    .line 148
    const/16 v2, 0xd

    .line 149
    .line 150
    const-string v1, "notification"

    .line 151
    .line 152
    const-string v0, "NOTIFICATION"

    .line 153
    .line 154
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 155
    .line 156
    .line 157
    move-result-object v16

    .line 158
    sput-object v16, Lcom/facebook/aura/analytics/hatch/HatchSurface;->NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 159
    .line 160
    const/16 v2, 0xe

    .line 161
    .line 162
    const-string v1, "media_viewer"

    .line 163
    .line 164
    const-string v0, "MEDIA_VIEWER"

    .line 165
    .line 166
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 167
    .line 168
    .line 169
    move-result-object v17

    .line 170
    sput-object v17, Lcom/facebook/aura/analytics/hatch/HatchSurface;->MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 171
    .line 172
    const/16 v2, 0xf

    .line 173
    .line 174
    const-string v1, "artifact_viewer"

    .line 175
    .line 176
    const-string v0, "ARTIFACT_VIEWER"

    .line 177
    .line 178
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 179
    .line 180
    .line 181
    move-result-object v18

    .line 182
    sput-object v18, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 183
    .line 184
    const/16 v2, 0x10

    .line 185
    .line 186
    const-string v1, "model_selector"

    .line 187
    .line 188
    const-string v0, "MODEL_SELECTOR"

    .line 189
    .line 190
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 191
    .line 192
    .line 193
    move-result-object v19

    .line 194
    sput-object v19, Lcom/facebook/aura/analytics/hatch/HatchSurface;->MODEL_SELECTOR:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 195
    .line 196
    const/16 v2, 0x11

    .line 197
    .line 198
    const-string v1, "status"

    .line 199
    .line 200
    const-string v0, "STATUS"

    .line 201
    .line 202
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 203
    .line 204
    .line 205
    move-result-object v20

    .line 206
    sput-object v20, Lcom/facebook/aura/analytics/hatch/HatchSurface;->STATUS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 207
    .line 208
    const/16 v2, 0x12

    .line 209
    .line 210
    const-string v1, "monetization"

    .line 211
    .line 212
    const-string v0, "MONETIZATION"

    .line 213
    .line 214
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 215
    .line 216
    .line 217
    move-result-object v21

    .line 218
    sput-object v21, Lcom/facebook/aura/analytics/hatch/HatchSurface;->MONETIZATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 219
    .line 220
    const/16 v2, 0x13

    .line 221
    .line 222
    const-string v1, "survey"

    .line 223
    .line 224
    const-string v0, "SURVEY"

    .line 225
    .line 226
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 227
    .line 228
    .line 229
    move-result-object v22

    .line 230
    sput-object v22, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SURVEY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 231
    .line 232
    const/16 v2, 0x14

    .line 233
    .line 234
    const-string v1, "spaces"

    .line 235
    .line 236
    const-string v0, "SPACES"

    .line 237
    .line 238
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 239
    .line 240
    .line 241
    move-result-object v23

    .line 242
    sput-object v23, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SPACES:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 243
    .line 244
    const/16 v2, 0x15

    .line 245
    .line 246
    const-string v1, "nodes"

    .line 247
    .line 248
    const-string v0, "NODES"

    .line 249
    .line 250
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 251
    .line 252
    .line 253
    move-result-object v24

    .line 254
    sput-object v24, Lcom/facebook/aura/analytics/hatch/HatchSurface;->NODES:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 255
    .line 256
    const/16 v2, 0x16

    .line 257
    .line 258
    const-string v1, "permissions"

    .line 259
    .line 260
    const-string v0, "PERMISSIONS"

    .line 261
    .line 262
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 263
    .line 264
    .line 265
    move-result-object v25

    .line 266
    sput-object v25, Lcom/facebook/aura/analytics/hatch/HatchSurface;->PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 267
    .line 268
    const/16 v2, 0x17

    .line 269
    .line 270
    const-string v1, "upsell"

    .line 271
    .line 272
    const-string v0, "UPSELL"

    .line 273
    .line 274
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 275
    .line 276
    .line 277
    move-result-object v26

    .line 278
    sput-object v26, Lcom/facebook/aura/analytics/hatch/HatchSurface;->UPSELL:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 279
    .line 280
    const/16 v2, 0x18

    .line 281
    .line 282
    const-string v1, "nav_bar"

    .line 283
    .line 284
    const-string v0, "NAV_BAR"

    .line 285
    .line 286
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 287
    .line 288
    .line 289
    move-result-object v27

    .line 290
    sput-object v27, Lcom/facebook/aura/analytics/hatch/HatchSurface;->NAV_BAR:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 291
    .line 292
    const/16 v2, 0x19

    .line 293
    .line 294
    const-string v1, "shopping"

    .line 295
    .line 296
    const-string v0, "SHOPPING"

    .line 297
    .line 298
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 299
    .line 300
    .line 301
    move-result-object v28

    .line 302
    sput-object v28, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SHOPPING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 303
    .line 304
    const/16 v2, 0x1a

    .line 305
    .line 306
    const-string v1, "wearables"

    .line 307
    .line 308
    const-string v0, "WEARABLES"

    .line 309
    .line 310
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 311
    .line 312
    .line 313
    move-result-object v29

    .line 314
    sput-object v29, Lcom/facebook/aura/analytics/hatch/HatchSurface;->WEARABLES:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 315
    .line 316
    const/16 v2, 0x1b

    .line 317
    .line 318
    const-string v1, "share_sheet"

    .line 319
    .line 320
    const-string v0, "SHARE_SHEET"

    .line 321
    .line 322
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 323
    .line 324
    .line 325
    move-result-object v30

    .line 326
    sput-object v30, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 327
    .line 328
    const/16 v2, 0x1c

    .line 329
    .line 330
    const-string v1, "cvm_replacement"

    .line 331
    .line 332
    const-string v0, "CVM_REPLACEMENT"

    .line 333
    .line 334
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 335
    .line 336
    .line 337
    move-result-object v31

    .line 338
    sput-object v31, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CVM_REPLACEMENT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 339
    .line 340
    const/16 v2, 0x1d

    .line 341
    .line 342
    const-string v1, "cvm_pin_recovery"

    .line 343
    .line 344
    const-string v0, "CVM_PIN_RECOVERY"

    .line 345
    .line 346
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 347
    .line 348
    .line 349
    move-result-object v32

    .line 350
    sput-object v32, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CVM_PIN_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 351
    .line 352
    const/16 v2, 0x1e

    .line 353
    .line 354
    const-string v1, "cvm_switch"

    .line 355
    .line 356
    const-string v0, "CVM_SWITCH"

    .line 357
    .line 358
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 359
    .line 360
    .line 361
    move-result-object v33

    .line 362
    sput-object v33, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 363
    .line 364
    const/16 v2, 0x1f

    .line 365
    .line 366
    const-string v1, "cvm_downgrade"

    .line 367
    .line 368
    const-string v0, "CVM_DOWNGRADE"

    .line 369
    .line 370
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 371
    .line 372
    .line 373
    move-result-object v34

    .line 374
    sput-object v34, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CVM_DOWNGRADE:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 375
    .line 376
    const/16 v2, 0x20

    .line 377
    .line 378
    const-string v1, "vm_disconnected"

    .line 379
    .line 380
    const-string v0, "VM_DISCONNECTED"

    .line 381
    .line 382
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 383
    .line 384
    .line 385
    move-result-object v35

    .line 386
    sput-object v35, Lcom/facebook/aura/analytics/hatch/HatchSurface;->VM_DISCONNECTED:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 387
    .line 388
    const/16 v2, 0x21

    .line 389
    .line 390
    const-string v1, "storage_recovery"

    .line 391
    .line 392
    const-string v0, "STORAGE_RECOVERY"

    .line 393
    .line 394
    invoke-static {v0, v1, v2}, LX/602;->A0H(Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 395
    .line 396
    .line 397
    move-result-object v36

    .line 398
    sput-object v36, Lcom/facebook/aura/analytics/hatch/HatchSurface;->STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 399
    .line 400
    const/16 v0, 0x22

    .line 401
    .line 402
    new-array v0, v0, [Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 403
    .line 404
    filled-new-array/range {v3 .. v29}, [Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    invoke-static {v1, v0}, LX/602;->A1X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 409
    .line 410
    .line 411
    move-result v4

    .line 412
    filled-new-array/range {v30 .. v36}, [Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 413
    .line 414
    .line 415
    move-result-object v3

    .line 416
    const/16 v2, 0x1b

    .line 417
    .line 418
    const/4 v1, 0x7

    .line 419
    invoke-static {v3, v4, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 420
    .line 421
    .line 422
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 423
    .line 424
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->$ENTRIES:LX/0vk;

    .line 429
    .line 430
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchSurface;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchSurface;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchSurface;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
