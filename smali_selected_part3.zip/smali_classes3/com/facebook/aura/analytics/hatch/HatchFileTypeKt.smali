.class public abstract Lcom/facebook/aura/analytics/hatch/HatchFileTypeKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FILE_TYPE_EXTENSIONS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 30

    .line 0
    const/16 v0, 0x73

    .line 1
    .line 2
    new-array v2, v0, [Ljava/lang/String;

    .line 3
    .line 4
    const-string v3, "7z"

    .line 5
    .line 6
    const-string v4, "aac"

    .line 7
    .line 8
    const-string v5, "ai"

    .line 9
    .line 10
    const-string v6, "aiff"

    .line 11
    .line 12
    const-string v7, "avi"

    .line 13
    .line 14
    const-string v8, "bash"

    .line 15
    .line 16
    const-string v9, "bmp"

    .line 17
    .line 18
    const-string v10, "bz2"

    .line 19
    .line 20
    const-string v11, "c"

    .line 21
    .line 22
    const-string v12, "caf"

    .line 23
    .line 24
    const-string v13, "cc"

    .line 25
    .line 26
    const-string v14, "cpp"

    .line 27
    .line 28
    const-string v15, "cs"

    .line 29
    .line 30
    const-string v16, "css"

    .line 31
    .line 32
    const-string v17, "csv"

    .line 33
    .line 34
    const-string v18, "dart"

    .line 35
    .line 36
    const-string v19, "diff"

    .line 37
    .line 38
    const-string v20, "doc"

    .line 39
    .line 40
    const-string v21, "docx"

    .line 41
    .line 42
    const-string v22, "eml"

    .line 43
    .line 44
    const-string v23, "epub"

    .line 45
    .line 46
    const-string v24, "fig"

    .line 47
    .line 48
    const-string v25, "flac"

    .line 49
    .line 50
    const-string v26, "gif"

    .line 51
    .line 52
    const-string v27, "glb"

    .line 53
    .line 54
    const-string v28, "gltf"

    .line 55
    .line 56
    const-string v29, "go"

    .line 57
    .line 58
    filled-new-array/range {v3 .. v29}, [Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    const/4 v0, 0x0

    .line 63
    const/16 v1, 0x1b

    .line 64
    .line 65
    invoke-static {v3, v0, v2, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 66
    .line 67
    .line 68
    const-string v3, "gz"

    .line 69
    .line 70
    const-string v4, "h"

    .line 71
    .line 72
    const-string v5, "heic"

    .line 73
    .line 74
    const-string v6, "heif"

    .line 75
    .line 76
    const-string v7, "hpp"

    .line 77
    .line 78
    const-string v8, "htm"

    .line 79
    .line 80
    const-string v9, "html"

    .line 81
    .line 82
    const-string v10, "ico"

    .line 83
    .line 84
    const-string v11, "ics"

    .line 85
    .line 86
    const-string v12, "ini"

    .line 87
    .line 88
    const-string v13, "ipynb"

    .line 89
    .line 90
    const-string v14, "java"

    .line 91
    .line 92
    const-string v15, "jpeg"

    .line 93
    .line 94
    const-string v16, "jpg"

    .line 95
    .line 96
    const-string v17, "js"

    .line 97
    .line 98
    const-string v18, "json"

    .line 99
    .line 100
    const-string v19, "jsonl"

    .line 101
    .line 102
    const-string v20, "jsx"

    .line 103
    .line 104
    const-string v21, "key"

    .line 105
    .line 106
    const-string v22, "kt"

    .line 107
    .line 108
    const-string v23, "kts"

    .line 109
    .line 110
    const-string v24, "log"

    .line 111
    .line 112
    const-string v25, "lua"

    .line 113
    .line 114
    const-string v26, "m"

    .line 115
    .line 116
    const-string v27, "m4a"

    .line 117
    .line 118
    const-string v28, "m4v"

    .line 119
    .line 120
    const-string v29, "md"

    .line 121
    .line 122
    filled-new-array/range {v3 .. v29}, [Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    invoke-static {v3, v0, v2, v1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 127
    .line 128
    .line 129
    const-string v3, "markdown"

    .line 130
    .line 131
    const-string v4, "mjs"

    .line 132
    .line 133
    const-string v5, "mkv"

    .line 134
    .line 135
    const-string v6, "mm"

    .line 136
    .line 137
    const-string v7, "mov"

    .line 138
    .line 139
    const-string v8, "mp3"

    .line 140
    .line 141
    const-string v9, "mp4"

    .line 142
    .line 143
    const-string v10, "numbers"

    .line 144
    .line 145
    const-string v11, "odp"

    .line 146
    .line 147
    const-string v12, "ods"

    .line 148
    .line 149
    const-string v13, "odt"

    .line 150
    .line 151
    const-string v14, "ogg"

    .line 152
    .line 153
    const-string v15, "opus"

    .line 154
    .line 155
    const-string v16, "pages"

    .line 156
    .line 157
    const-string v17, "patch"

    .line 158
    .line 159
    const-string v18, "pdf"

    .line 160
    .line 161
    const-string v19, "php"

    .line 162
    .line 163
    const-string v20, "pl"

    .line 164
    .line 165
    const-string v21, "png"

    .line 166
    .line 167
    const-string v22, "ppt"

    .line 168
    .line 169
    const-string v23, "pptx"

    .line 170
    .line 171
    const-string v24, "psd"

    .line 172
    .line 173
    const-string v25, "py"

    .line 174
    .line 175
    const-string v26, "r"

    .line 176
    .line 177
    const-string v27, "rar"

    .line 178
    .line 179
    const-string v28, "rb"

    .line 180
    .line 181
    const-string v29, "rs"

    .line 182
    .line 183
    filled-new-array/range {v3 .. v29}, [Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v4

    .line 187
    const/16 v3, 0x36

    .line 188
    .line 189
    invoke-static {v4, v0, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 190
    .line 191
    .line 192
    const-string v3, "rtf"

    .line 193
    .line 194
    const-string v4, "scala"

    .line 195
    .line 196
    const-string v5, "sh"

    .line 197
    .line 198
    const-string v6, "sql"

    .line 199
    .line 200
    const-string v7, "srt"

    .line 201
    .line 202
    const-string v8, "stl"

    .line 203
    .line 204
    const-string v9, "svg"

    .line 205
    .line 206
    const-string v10, "swift"

    .line 207
    .line 208
    const-string v11, "tar"

    .line 209
    .line 210
    const-string v12, "tex"

    .line 211
    .line 212
    const-string v13, "text"

    .line 213
    .line 214
    const-string v14, "tgz"

    .line 215
    .line 216
    const-string v15, "tif"

    .line 217
    .line 218
    const-string v16, "tiff"

    .line 219
    .line 220
    const-string v17, "toml"

    .line 221
    .line 222
    const-string v18, "ts"

    .line 223
    .line 224
    const-string v19, "tsv"

    .line 225
    .line 226
    const-string v20, "tsx"

    .line 227
    .line 228
    const-string v21, "txt"

    .line 229
    .line 230
    const-string v22, "usdz"

    .line 231
    .line 232
    const-string v23, "vcf"

    .line 233
    .line 234
    const-string v24, "vtt"

    .line 235
    .line 236
    const-string v25, "wasm"

    .line 237
    .line 238
    const-string v26, "wav"

    .line 239
    .line 240
    const-string v27, "webm"

    .line 241
    .line 242
    const-string v28, "webp"

    .line 243
    .line 244
    const-string v29, "xls"

    .line 245
    .line 246
    filled-new-array/range {v3 .. v29}, [Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v4

    .line 250
    const/16 v3, 0x51

    .line 251
    .line 252
    invoke-static {v4, v0, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 253
    .line 254
    .line 255
    const-string v3, "xlsx"

    .line 256
    .line 257
    const-string v4, "xml"

    .line 258
    .line 259
    const-string v5, "xz"

    .line 260
    .line 261
    const-string v6, "yaml"

    .line 262
    .line 263
    const-string v7, "yml"

    .line 264
    .line 265
    const-string v8, "zip"

    .line 266
    .line 267
    const-string v9, "zsh"

    .line 268
    .line 269
    filled-new-array/range {v3 .. v9}, [Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object v4

    .line 273
    const/16 v3, 0x6c

    .line 274
    .line 275
    const/4 v1, 0x7

    .line 276
    invoke-static {v4, v0, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 277
    .line 278
    .line 279
    invoke-static {v2}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchFileTypeKt;->FILE_TYPE_EXTENSIONS:Ljava/util/Set;

    .line 284
    .line 285
    return-void
.end method

.method public static final hatchFileTypeMetadata(Ljava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v2, 0x0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    invoke-static {p0}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchFileTypeKt;->FILE_TYPE_EXTENSIONS:Ljava/util/Set;

    .line 8
    .line 9
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->FILE_TYPE:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/3Rs;->A0m(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;Ljava/lang/Object;)Ljava/util/Map;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0

    .line 22
    :cond_0
    return-object v2
.end method
