.class public final enum Lcom/facebook/aura/analytics/hatch/HatchModule;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchModule;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTIONS_ADD:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTIONS_RECEIVED_ITEM:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTIONS_SHARE:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTIONS_SHARE_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_ACCEPT_INVITE:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_ACCEPT_LEVEL:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_ADD_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_PAIRING_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CONNECTION_RULE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_DEVICE_PAIRING:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_FEED:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_FEEDBACK:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_GOALS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_GOALS_COMPLETED:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_GOAL_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_IDEAS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_LIBRARY_ARTIFACTS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_LIBRARY_MEDIA:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_MODEL_PICKER:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_NEW_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_PEER_SPACE_MEMBERS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_PROFILE:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SEARCH:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SHARED_GOAL:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SPACES:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SPACE_COLLABORATORS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_SPACE_INVITE_PICKER:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum HATCH_VOICE_MODE:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_APPROVAL:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_AVATAR_MENU:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_CALL:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_HOME:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_KEYBOARD:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_SETUP:Lcom/facebook/aura/analytics/hatch/HatchModule;

.field public static final enum WATCH_VOICE:Lcom/facebook/aura/analytics/hatch/HatchModule;


# instance fields
.field public final moduleClassName:Ljava/lang/String;

.field public final moduleName:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 55

    .line 0
    const-string v2, "HATCH_CHAT"

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    const-string v0, "hatch_chat"

    .line 4
    .line 5
    const-string v3, "HatchConversationScreen"

    .line 6
    .line 7
    invoke-static {v2, v0, v3, v1}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 8
    .line 9
    .line 10
    move-result-object v4

    .line 11
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    const-string v1, "hatch_new_chat"

    .line 15
    .line 16
    const-string v0, "HATCH_NEW_CHAT"

    .line 17
    .line 18
    invoke-static {v0, v1, v3, v2}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_NEW_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 23
    .line 24
    const-string v3, "hatch_library"

    .line 25
    .line 26
    const-string v2, "HatchLibraryTabScreen"

    .line 27
    .line 28
    const-string v1, "HATCH_LIBRARY"

    .line 29
    .line 30
    const/4 v0, 0x2

    .line 31
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 32
    .line 33
    .line 34
    move-result-object v6

    .line 35
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 36
    .line 37
    const-string v3, "hatch_library_media"

    .line 38
    .line 39
    const-string v2, "MediaGalleryScreen"

    .line 40
    .line 41
    const-string v1, "HATCH_LIBRARY_MEDIA"

    .line 42
    .line 43
    const/4 v0, 0x3

    .line 44
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 45
    .line 46
    .line 47
    move-result-object v7

    .line 48
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_LIBRARY_MEDIA:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 49
    .line 50
    const-string v3, "hatch_library_artifacts"

    .line 51
    .line 52
    const-string v2, "ArtifactsDetailScreen"

    .line 53
    .line 54
    const-string v1, "HATCH_LIBRARY_ARTIFACTS"

    .line 55
    .line 56
    const/4 v0, 0x4

    .line 57
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 58
    .line 59
    .line 60
    move-result-object v8

    .line 61
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_LIBRARY_ARTIFACTS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 62
    .line 63
    const-string v3, "hatch_goals"

    .line 64
    .line 65
    const-string v2, "HatchGoalsTabScreen"

    .line 66
    .line 67
    const-string v1, "HATCH_GOALS"

    .line 68
    .line 69
    const/4 v0, 0x5

    .line 70
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 71
    .line 72
    .line 73
    move-result-object v9

    .line 74
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_GOALS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 75
    .line 76
    const-string v3, "hatch_goal_details"

    .line 77
    .line 78
    const-string v2, "GoalDetailScreen"

    .line 79
    .line 80
    const-string v1, "HATCH_GOAL_DETAILS"

    .line 81
    .line 82
    const/4 v0, 0x6

    .line 83
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 84
    .line 85
    .line 86
    move-result-object v10

    .line 87
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_GOAL_DETAILS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 88
    .line 89
    const-string v3, "hatch_goals_completed"

    .line 90
    .line 91
    const-string v2, "GoalsCompletedScreen"

    .line 92
    .line 93
    const-string v1, "HATCH_GOALS_COMPLETED"

    .line 94
    .line 95
    const/4 v0, 0x7

    .line 96
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_GOALS_COMPLETED:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 101
    .line 102
    const-string v3, "hatch_settings"

    .line 103
    .line 104
    const-string v2, "HatchSettingsScreen"

    .line 105
    .line 106
    const-string v1, "HATCH_SETTINGS"

    .line 107
    .line 108
    const/16 v0, 0x8

    .line 109
    .line 110
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 111
    .line 112
    .line 113
    move-result-object v12

    .line 114
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 115
    .line 116
    const-string v3, "hatch_profile"

    .line 117
    .line 118
    const-string v2, "HatchProfileScreen"

    .line 119
    .line 120
    const-string v1, "HATCH_PROFILE"

    .line 121
    .line 122
    const/16 v0, 0x9

    .line 123
    .line 124
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 125
    .line 126
    .line 127
    move-result-object v13

    .line 128
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_PROFILE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 129
    .line 130
    const-string v3, "hatch_search"

    .line 131
    .line 132
    const-string v2, "ConversationSearchScreen"

    .line 133
    .line 134
    const-string v1, "HATCH_SEARCH"

    .line 135
    .line 136
    const/16 v0, 0xa

    .line 137
    .line 138
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 139
    .line 140
    .line 141
    move-result-object v14

    .line 142
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SEARCH:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 143
    .line 144
    const-string v3, "hatch_voice_mode"

    .line 145
    .line 146
    const-string v2, "HatchVoiceModeScreen"

    .line 147
    .line 148
    const-string v1, "HATCH_VOICE_MODE"

    .line 149
    .line 150
    const/16 v0, 0xb

    .line 151
    .line 152
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 153
    .line 154
    .line 155
    move-result-object v15

    .line 156
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_VOICE_MODE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 157
    .line 158
    const-string v3, "HATCH_MEDIA_VIEWER"

    .line 159
    .line 160
    const/16 v1, 0xc

    .line 161
    .line 162
    const-string v0, "hatch_media_viewer"

    .line 163
    .line 164
    const-string v2, "ContentViewerScreen"

    .line 165
    .line 166
    invoke-static {v3, v0, v2, v1}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 167
    .line 168
    .line 169
    move-result-object v16

    .line 170
    sput-object v16, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 171
    .line 172
    const/16 v3, 0xd

    .line 173
    .line 174
    const-string v1, "hatch_artifact_viewer"

    .line 175
    .line 176
    const-string v0, "HATCH_ARTIFACT_VIEWER"

    .line 177
    .line 178
    invoke-static {v0, v1, v2, v3}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 179
    .line 180
    .line 181
    move-result-object v17

    .line 182
    sput-object v17, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 183
    .line 184
    const-string v3, "hatch_onboarding"

    .line 185
    .line 186
    const-string v2, "AuraActivationScreen"

    .line 187
    .line 188
    const-string v1, "HATCH_ONBOARDING"

    .line 189
    .line 190
    const/16 v0, 0xe

    .line 191
    .line 192
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 193
    .line 194
    .line 195
    move-result-object v18

    .line 196
    sput-object v18, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 197
    .line 198
    const-string v3, "hatch_status"

    .line 199
    .line 200
    const-string v2, "HatchStatusScreen"

    .line 201
    .line 202
    const-string v1, "HATCH_STATUS"

    .line 203
    .line 204
    const/16 v0, 0xf

    .line 205
    .line 206
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 207
    .line 208
    .line 209
    move-result-object v19

    .line 210
    sput-object v19, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 211
    .line 212
    const-string v3, "hatch_model_picker"

    .line 213
    .line 214
    const-string v2, "HatchModelPickerSheet"

    .line 215
    .line 216
    const-string v1, "HATCH_MODEL_PICKER"

    .line 217
    .line 218
    const/16 v0, 0x10

    .line 219
    .line 220
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 221
    .line 222
    .line 223
    move-result-object v20

    .line 224
    sput-object v20, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_MODEL_PICKER:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 225
    .line 226
    const-string v3, "hatch_device_pairing"

    .line 227
    .line 228
    const-string v2, "HatchDevicePairingScreen"

    .line 229
    .line 230
    const-string v1, "HATCH_DEVICE_PAIRING"

    .line 231
    .line 232
    const/16 v0, 0x11

    .line 233
    .line 234
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 235
    .line 236
    .line 237
    move-result-object v21

    .line 238
    sput-object v21, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_DEVICE_PAIRING:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 239
    .line 240
    const-string v3, "hatch_feedback"

    .line 241
    .line 242
    const-string v2, "HatchFeedbackSheet"

    .line 243
    .line 244
    const-string v1, "HATCH_FEEDBACK"

    .line 245
    .line 246
    const/16 v0, 0x12

    .line 247
    .line 248
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 249
    .line 250
    .line 251
    move-result-object v22

    .line 252
    sput-object v22, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_FEEDBACK:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 253
    .line 254
    const-string v3, "hatch_spaces"

    .line 255
    .line 256
    const-string v2, "HatchSpacesModalScreen"

    .line 257
    .line 258
    const-string v1, "HATCH_SPACES"

    .line 259
    .line 260
    const/16 v0, 0x13

    .line 261
    .line 262
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 263
    .line 264
    .line 265
    move-result-object v23

    .line 266
    sput-object v23, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SPACES:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 267
    .line 268
    const-string v3, "hatch_feed"

    .line 269
    .line 270
    const-string v2, "FeedTabScreen"

    .line 271
    .line 272
    const-string v1, "HATCH_FEED"

    .line 273
    .line 274
    const/16 v0, 0x14

    .line 275
    .line 276
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 277
    .line 278
    .line 279
    move-result-object v24

    .line 280
    sput-object v24, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_FEED:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 281
    .line 282
    const-string v3, "hatch_ideas"

    .line 283
    .line 284
    const-string v2, "HatchIdeasTabScreen"

    .line 285
    .line 286
    const-string v1, "HATCH_IDEAS"

    .line 287
    .line 288
    const/16 v0, 0x15

    .line 289
    .line 290
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 291
    .line 292
    .line 293
    move-result-object v25

    .line 294
    sput-object v25, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_IDEAS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 295
    .line 296
    const-string v3, "hatch_cvm_switch"

    .line 297
    .line 298
    const-string v2, "ConfidentialVmSwitchIntroScreen"

    .line 299
    .line 300
    const-string v1, "HATCH_CVM_SWITCH"

    .line 301
    .line 302
    const/16 v0, 0x16

    .line 303
    .line 304
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 305
    .line 306
    .line 307
    move-result-object v26

    .line 308
    sput-object v26, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 309
    .line 310
    const-string v3, "hatch_connections"

    .line 311
    .line 312
    const-string v2, "ConnectionsTabScreen"

    .line 313
    .line 314
    const-string v1, "HATCH_CONNECTIONS"

    .line 315
    .line 316
    const/16 v0, 0x17

    .line 317
    .line 318
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 319
    .line 320
    .line 321
    move-result-object v27

    .line 322
    sput-object v27, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 323
    .line 324
    const-string v3, "hatch_connections_add"

    .line 325
    .line 326
    const-string v2, "ConnectionsAddScreen"

    .line 327
    .line 328
    const-string v1, "HATCH_CONNECTIONS_ADD"

    .line 329
    .line 330
    const/16 v0, 0x18

    .line 331
    .line 332
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 333
    .line 334
    .line 335
    move-result-object v28

    .line 336
    sput-object v28, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTIONS_ADD:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 337
    .line 338
    const-string v3, "hatch_connection_detail"

    .line 339
    .line 340
    const-string v2, "ConnectionsSheetScreen"

    .line 341
    .line 342
    const-string v1, "HATCH_CONNECTION_DETAIL"

    .line 343
    .line 344
    const/16 v0, 0x19

    .line 345
    .line 346
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 347
    .line 348
    .line 349
    move-result-object v29

    .line 350
    sput-object v29, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_DETAIL:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 351
    .line 352
    const-string v3, "hatch_connection_rule_editor"

    .line 353
    .line 354
    const-string v2, "ConnectionsRuleEditorScreen"

    .line 355
    .line 356
    const-string v1, "HATCH_CONNECTION_RULE_EDITOR"

    .line 357
    .line 358
    const/16 v0, 0x1a

    .line 359
    .line 360
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 361
    .line 362
    .line 363
    move-result-object v30

    .line 364
    sput-object v30, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_RULE_EDITOR:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 365
    .line 366
    const-string v3, "hatch_connection_add_permission"

    .line 367
    .line 368
    const-string v2, "ConnectionsAddPermissionScreen"

    .line 369
    .line 370
    const-string v1, "HATCH_CONNECTION_ADD_PERMISSION"

    .line 371
    .line 372
    const/16 v0, 0x1b

    .line 373
    .line 374
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 375
    .line 376
    .line 377
    move-result-object v31

    .line 378
    sput-object v31, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_ADD_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 379
    .line 380
    const-string v3, "hatch_connections_share"

    .line 381
    .line 382
    const-string v2, "ConnectionsShareScreen"

    .line 383
    .line 384
    const-string v1, "HATCH_CONNECTIONS_SHARE"

    .line 385
    .line 386
    const/16 v0, 0x1c

    .line 387
    .line 388
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 389
    .line 390
    .line 391
    move-result-object v32

    .line 392
    sput-object v32, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTIONS_SHARE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 393
    .line 394
    const-string v3, "hatch_connection_history"

    .line 395
    .line 396
    const-string v2, "PairsHistoryScreen"

    .line 397
    .line 398
    const-string v1, "HATCH_CONNECTION_HISTORY"

    .line 399
    .line 400
    const/16 v0, 0x1d

    .line 401
    .line 402
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 403
    .line 404
    .line 405
    move-result-object v33

    .line 406
    sput-object v33, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_HISTORY:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 407
    .line 408
    const-string v3, "hatch_peer_space"

    .line 409
    .line 410
    const-string v2, "PeerSpaceScreen"

    .line 411
    .line 412
    const-string v1, "HATCH_PEER_SPACE"

    .line 413
    .line 414
    const/16 v0, 0x1e

    .line 415
    .line 416
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 417
    .line 418
    .line 419
    move-result-object v34

    .line 420
    sput-object v34, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_PEER_SPACE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 421
    .line 422
    const-string v3, "hatch_connection_pairing_status"

    .line 423
    .line 424
    const-string v2, "PairsStatusScreen"

    .line 425
    .line 426
    const-string v1, "HATCH_CONNECTION_PAIRING_STATUS"

    .line 427
    .line 428
    const/16 v0, 0x1f

    .line 429
    .line 430
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 431
    .line 432
    .line 433
    move-result-object v35

    .line 434
    sput-object v35, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_PAIRING_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 435
    .line 436
    const-string v3, "hatch_connection_accept_invite"

    .line 437
    .line 438
    const-string v2, "PairsAcceptLinkScreen"

    .line 439
    .line 440
    const-string v1, "HATCH_CONNECTION_ACCEPT_INVITE"

    .line 441
    .line 442
    const/16 v0, 0x20

    .line 443
    .line 444
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 445
    .line 446
    .line 447
    move-result-object v36

    .line 448
    sput-object v36, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_ACCEPT_INVITE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 449
    .line 450
    const-string v3, "hatch_connection_accept_level"

    .line 451
    .line 452
    const-string v2, "PairsAcceptPreferencesScreen"

    .line 453
    .line 454
    const-string v1, "HATCH_CONNECTION_ACCEPT_LEVEL"

    .line 455
    .line 456
    const/16 v0, 0x21

    .line 457
    .line 458
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 459
    .line 460
    .line 461
    move-result-object v37

    .line 462
    sput-object v37, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTION_ACCEPT_LEVEL:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 463
    .line 464
    const-string v3, "hatch_connections_share_status"

    .line 465
    .line 466
    const-string v2, "ConnectionsShareStatusScreen"

    .line 467
    .line 468
    const-string v1, "HATCH_CONNECTIONS_SHARE_STATUS"

    .line 469
    .line 470
    const/16 v0, 0x22

    .line 471
    .line 472
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 473
    .line 474
    .line 475
    move-result-object v38

    .line 476
    sput-object v38, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTIONS_SHARE_STATUS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 477
    .line 478
    const-string v3, "hatch_connections_received_item"

    .line 479
    .line 480
    const-string v2, "ConnectionsReceivedItemScreen"

    .line 481
    .line 482
    const-string v1, "HATCH_CONNECTIONS_RECEIVED_ITEM"

    .line 483
    .line 484
    const/16 v0, 0x23

    .line 485
    .line 486
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 487
    .line 488
    .line 489
    move-result-object v39

    .line 490
    sput-object v39, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_CONNECTIONS_RECEIVED_ITEM:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 491
    .line 492
    const-string v3, "hatch_shared_goal"

    .line 493
    .line 494
    const-string v2, "SharedGoalScreen"

    .line 495
    .line 496
    const-string v1, "HATCH_SHARED_GOAL"

    .line 497
    .line 498
    const/16 v0, 0x24

    .line 499
    .line 500
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 501
    .line 502
    .line 503
    move-result-object v40

    .line 504
    sput-object v40, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SHARED_GOAL:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 505
    .line 506
    const-string v3, "hatch_peer_space_members"

    .line 507
    .line 508
    const-string v2, "PeerSpaceCollaboratorsSheet"

    .line 509
    .line 510
    const-string v1, "HATCH_PEER_SPACE_MEMBERS"

    .line 511
    .line 512
    const/16 v0, 0x25

    .line 513
    .line 514
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 515
    .line 516
    .line 517
    move-result-object v41

    .line 518
    sput-object v41, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_PEER_SPACE_MEMBERS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 519
    .line 520
    const-string v3, "hatch_space_collaborators"

    .line 521
    .line 522
    const-string v2, "SpaceCollaboratorsSheet"

    .line 523
    .line 524
    const-string v1, "HATCH_SPACE_COLLABORATORS"

    .line 525
    .line 526
    const/16 v0, 0x26

    .line 527
    .line 528
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 529
    .line 530
    .line 531
    move-result-object v42

    .line 532
    sput-object v42, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SPACE_COLLABORATORS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 533
    .line 534
    const-string v3, "hatch_space_invite_picker"

    .line 535
    .line 536
    const-string v2, "SpaceCollaboratorPickerScreen"

    .line 537
    .line 538
    const-string v1, "HATCH_SPACE_INVITE_PICKER"

    .line 539
    .line 540
    const/16 v0, 0x27

    .line 541
    .line 542
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 543
    .line 544
    .line 545
    move-result-object v43

    .line 546
    sput-object v43, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_SPACE_INVITE_PICKER:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 547
    .line 548
    const-string v3, "hatch_storage_recovery"

    .line 549
    .line 550
    const-string v2, "StorageRecoveryOverlayContent"

    .line 551
    .line 552
    const-string v1, "HATCH_STORAGE_RECOVERY"

    .line 553
    .line 554
    const/16 v0, 0x28

    .line 555
    .line 556
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 557
    .line 558
    .line 559
    move-result-object v44

    .line 560
    sput-object v44, Lcom/facebook/aura/analytics/hatch/HatchModule;->HATCH_STORAGE_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 561
    .line 562
    const-string v3, "watch_setup"

    .line 563
    .line 564
    const-string v2, "WatchSessionGate"

    .line 565
    .line 566
    const-string v1, "WATCH_SETUP"

    .line 567
    .line 568
    const/16 v0, 0x29

    .line 569
    .line 570
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 571
    .line 572
    .line 573
    move-result-object v45

    .line 574
    sput-object v45, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_SETUP:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 575
    .line 576
    const-string v3, "watch_home"

    .line 577
    .line 578
    const-string v2, "WatchHomeScreen"

    .line 579
    .line 580
    const-string v1, "WATCH_HOME"

    .line 581
    .line 582
    const/16 v0, 0x2a

    .line 583
    .line 584
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 585
    .line 586
    .line 587
    move-result-object v46

    .line 588
    sput-object v46, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_HOME:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 589
    .line 590
    const-string v3, "watch_chat"

    .line 591
    .line 592
    const-string v2, "WatchConversationScreen"

    .line 593
    .line 594
    const-string v1, "WATCH_CHAT"

    .line 595
    .line 596
    const/16 v0, 0x2b

    .line 597
    .line 598
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 599
    .line 600
    .line 601
    move-result-object v47

    .line 602
    sput-object v47, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_CHAT:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 603
    .line 604
    const-string v3, "watch_keyboard"

    .line 605
    .line 606
    const-string v2, "WatchKeyboardScreen"

    .line 607
    .line 608
    const-string v1, "WATCH_KEYBOARD"

    .line 609
    .line 610
    const/16 v0, 0x2c

    .line 611
    .line 612
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 613
    .line 614
    .line 615
    move-result-object v48

    .line 616
    sput-object v48, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_KEYBOARD:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 617
    .line 618
    const-string v3, "watch_voice"

    .line 619
    .line 620
    const-string v2, "WatchDictationScreen"

    .line 621
    .line 622
    const-string v1, "WATCH_VOICE"

    .line 623
    .line 624
    const/16 v0, 0x2d

    .line 625
    .line 626
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 627
    .line 628
    .line 629
    move-result-object v49

    .line 630
    sput-object v49, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_VOICE:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 631
    .line 632
    const-string v3, "watch_call"

    .line 633
    .line 634
    const-string v2, "WatchCallScreen"

    .line 635
    .line 636
    const-string v1, "WATCH_CALL"

    .line 637
    .line 638
    const/16 v0, 0x2e

    .line 639
    .line 640
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 641
    .line 642
    .line 643
    move-result-object v50

    .line 644
    sput-object v50, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_CALL:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 645
    .line 646
    const-string v3, "watch_avatar_menu"

    .line 647
    .line 648
    const-string v2, "WatchAvatarMenuScreen"

    .line 649
    .line 650
    const-string v1, "WATCH_AVATAR_MENU"

    .line 651
    .line 652
    const/16 v0, 0x2f

    .line 653
    .line 654
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 655
    .line 656
    .line 657
    move-result-object v51

    .line 658
    sput-object v51, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_AVATAR_MENU:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 659
    .line 660
    const-string v3, "watch_settings"

    .line 661
    .line 662
    const-string v2, "WatchSettingsScreen"

    .line 663
    .line 664
    const-string v1, "WATCH_SETTINGS"

    .line 665
    .line 666
    const/16 v0, 0x30

    .line 667
    .line 668
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 669
    .line 670
    .line 671
    move-result-object v52

    .line 672
    sput-object v52, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 673
    .line 674
    const-string v3, "watch_bug_report"

    .line 675
    .line 676
    const-string v2, "WatchBugReportScreen"

    .line 677
    .line 678
    const-string v1, "WATCH_BUG_REPORT"

    .line 679
    .line 680
    const/16 v0, 0x31

    .line 681
    .line 682
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 683
    .line 684
    .line 685
    move-result-object v53

    .line 686
    sput-object v53, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_BUG_REPORT:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 687
    .line 688
    const-string v3, "watch_approval"

    .line 689
    .line 690
    const-string v2, "WatchApprovalDialog"

    .line 691
    .line 692
    const-string v1, "WATCH_APPROVAL"

    .line 693
    .line 694
    const/16 v0, 0x32

    .line 695
    .line 696
    invoke-static {v1, v3, v2, v0}, LX/602;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 697
    .line 698
    .line 699
    move-result-object v54

    .line 700
    sput-object v54, Lcom/facebook/aura/analytics/hatch/HatchModule;->WATCH_APPROVAL:Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 701
    .line 702
    const/16 v0, 0x33

    .line 703
    .line 704
    new-array v1, v0, [Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 705
    .line 706
    filled-new-array/range {v4 .. v30}, [Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    invoke-static {v0, v1}, LX/602;->A1X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 711
    .line 712
    .line 713
    move-result v0

    .line 714
    filled-new-array/range {v31 .. v54}, [Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 715
    .line 716
    .line 717
    move-result-object v4

    .line 718
    const/16 v3, 0x1b

    .line 719
    .line 720
    const/16 v2, 0x18

    .line 721
    .line 722
    invoke-static {v4, v0, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 723
    .line 724
    .line 725
    sput-object v1, Lcom/facebook/aura/analytics/hatch/HatchModule;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 726
    .line 727
    invoke-static {v1}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 728
    .line 729
    .line 730
    move-result-object v0

    .line 731
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchModule;->$ENTRIES:LX/0vk;

    .line 732
    .line 733
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchModule;->moduleName:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchModule;->moduleClassName:Ljava/lang/String;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchModule;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchModule;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchModule;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchModule;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchModule;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchModule;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getModuleClassName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchModule;->moduleClassName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getModuleName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchModule;->moduleName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
