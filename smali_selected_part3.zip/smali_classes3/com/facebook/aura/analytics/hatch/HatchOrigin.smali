.class public final enum Lcom/facebook/aura/analytics/hatch/HatchOrigin;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/analytics/hatch/HatchOrigin;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum CHAT:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum CVM_DOWNGRADE:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum CVM_PIN_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum FEED:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum GOALS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum HATCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum IDEAS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum MONETIZATION:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SEARCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SHOPPING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SPACES:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum STATUS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum SURVEY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum UPSELL:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

.field public static final enum WEARABLES:Lcom/facebook/aura/analytics/hatch/HatchOrigin;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 51

    .line 0
    const/4 v3, 0x0

    .line 1
    const-string v2, "hatch"

    .line 2
    .line 3
    const-string v1, "HATCH"

    .line 4
    .line 5
    new-instance v27, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 6
    .line 7
    move-object/from16 v0, v27

    .line 8
    .line 9
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v27, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->HATCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    const-string v2, "chat"

    .line 16
    .line 17
    const-string v1, "CHAT"

    .line 18
    .line 19
    new-instance v26, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 20
    .line 21
    move-object/from16 v0, v26

    .line 22
    .line 23
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v26, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 27
    .line 28
    const/4 v3, 0x2

    .line 29
    const-string v2, "feed"

    .line 30
    .line 31
    const-string v1, "FEED"

    .line 32
    .line 33
    new-instance v25, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 34
    .line 35
    move-object/from16 v0, v25

    .line 36
    .line 37
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sput-object v25, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->FEED:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 41
    .line 42
    const/4 v3, 0x3

    .line 43
    const-string v2, "ideas"

    .line 44
    .line 45
    const-string v1, "IDEAS"

    .line 46
    .line 47
    new-instance v24, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 48
    .line 49
    move-object/from16 v0, v24

    .line 50
    .line 51
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v24, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->IDEAS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 55
    .line 56
    const/4 v3, 0x4

    .line 57
    const-string v2, "library"

    .line 58
    .line 59
    const-string v1, "LIBRARY"

    .line 60
    .line 61
    new-instance v23, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 62
    .line 63
    move-object/from16 v0, v23

    .line 64
    .line 65
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    sput-object v23, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->LIBRARY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 69
    .line 70
    const/4 v3, 0x5

    .line 71
    const-string v2, "goals"

    .line 72
    .line 73
    const-string v1, "GOALS"

    .line 74
    .line 75
    new-instance v22, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 76
    .line 77
    move-object/from16 v0, v22

    .line 78
    .line 79
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v22, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->GOALS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 83
    .line 84
    const/4 v3, 0x6

    .line 85
    const-string v2, "search"

    .line 86
    .line 87
    const-string v1, "SEARCH"

    .line 88
    .line 89
    new-instance v21, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 90
    .line 91
    move-object/from16 v0, v21

    .line 92
    .line 93
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sput-object v21, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SEARCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 97
    .line 98
    const/4 v3, 0x7

    .line 99
    const-string v2, "media_viewer"

    .line 100
    .line 101
    const-string v1, "MEDIA_VIEWER"

    .line 102
    .line 103
    new-instance v20, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 104
    .line 105
    move-object/from16 v0, v20

    .line 106
    .line 107
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 108
    .line 109
    .line 110
    sput-object v20, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->MEDIA_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 111
    .line 112
    const/16 v3, 0x8

    .line 113
    .line 114
    const-string v2, "artifact_viewer"

    .line 115
    .line 116
    const-string v1, "ARTIFACT_VIEWER"

    .line 117
    .line 118
    new-instance v19, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 119
    .line 120
    move-object/from16 v0, v19

    .line 121
    .line 122
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sput-object v19, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ARTIFACT_VIEWER:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 126
    .line 127
    const/16 v3, 0x9

    .line 128
    .line 129
    const-string v2, "onboarding"

    .line 130
    .line 131
    const-string v1, "ONBOARDING"

    .line 132
    .line 133
    new-instance v18, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 134
    .line 135
    move-object/from16 v0, v18

    .line 136
    .line 137
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sput-object v18, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 141
    .line 142
    const/16 v3, 0xa

    .line 143
    .line 144
    const-string v2, "status"

    .line 145
    .line 146
    const-string v1, "STATUS"

    .line 147
    .line 148
    new-instance v17, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 149
    .line 150
    move-object/from16 v0, v17

    .line 151
    .line 152
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 153
    .line 154
    .line 155
    sput-object v17, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->STATUS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 156
    .line 157
    const/16 v2, 0xb

    .line 158
    .line 159
    const-string v1, "notification"

    .line 160
    .line 161
    const-string v0, "NOTIFICATION"

    .line 162
    .line 163
    new-instance v14, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 164
    .line 165
    invoke-direct {v14, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 166
    .line 167
    .line 168
    sput-object v14, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->NOTIFICATION:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 169
    .line 170
    const/16 v2, 0xc

    .line 171
    .line 172
    const-string v1, "spaces"

    .line 173
    .line 174
    const-string v0, "SPACES"

    .line 175
    .line 176
    new-instance v13, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 177
    .line 178
    invoke-direct {v13, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 179
    .line 180
    .line 181
    sput-object v13, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SPACES:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 182
    .line 183
    const/16 v2, 0xd

    .line 184
    .line 185
    const-string v1, "settings"

    .line 186
    .line 187
    const-string v0, "SETTINGS"

    .line 188
    .line 189
    new-instance v12, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 190
    .line 191
    invoke-direct {v12, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 192
    .line 193
    .line 194
    sput-object v12, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 195
    .line 196
    const/16 v2, 0xe

    .line 197
    .line 198
    const-string v1, "upsell"

    .line 199
    .line 200
    const-string v0, "UPSELL"

    .line 201
    .line 202
    new-instance v11, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 203
    .line 204
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 205
    .line 206
    .line 207
    sput-object v11, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->UPSELL:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 208
    .line 209
    const/16 v2, 0xf

    .line 210
    .line 211
    const-string v1, "survey"

    .line 212
    .line 213
    const-string v0, "SURVEY"

    .line 214
    .line 215
    new-instance v10, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 216
    .line 217
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 218
    .line 219
    .line 220
    sput-object v10, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SURVEY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 221
    .line 222
    const/16 v2, 0x10

    .line 223
    .line 224
    const-string v1, "wearables"

    .line 225
    .line 226
    const-string v0, "WEARABLES"

    .line 227
    .line 228
    new-instance v9, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 229
    .line 230
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 231
    .line 232
    .line 233
    sput-object v9, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->WEARABLES:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 234
    .line 235
    const/16 v2, 0x11

    .line 236
    .line 237
    const-string v1, "monetization"

    .line 238
    .line 239
    const-string v0, "MONETIZATION"

    .line 240
    .line 241
    new-instance v8, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 242
    .line 243
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 244
    .line 245
    .line 246
    sput-object v8, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->MONETIZATION:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 247
    .line 248
    const/16 v2, 0x12

    .line 249
    .line 250
    const-string v1, "share_sheet"

    .line 251
    .line 252
    const-string v0, "SHARE_SHEET"

    .line 253
    .line 254
    new-instance v7, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 255
    .line 256
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 257
    .line 258
    .line 259
    sput-object v7, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SHARE_SHEET:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 260
    .line 261
    const/16 v2, 0x13

    .line 262
    .line 263
    const-string v1, "shopping"

    .line 264
    .line 265
    const-string v0, "SHOPPING"

    .line 266
    .line 267
    new-instance v6, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 268
    .line 269
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 270
    .line 271
    .line 272
    sput-object v6, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->SHOPPING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 273
    .line 274
    const/16 v2, 0x14

    .line 275
    .line 276
    const-string v1, "cvm_switch"

    .line 277
    .line 278
    const-string v0, "CVM_SWITCH"

    .line 279
    .line 280
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 281
    .line 282
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 283
    .line 284
    .line 285
    sput-object v5, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CVM_SWITCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 286
    .line 287
    const/16 v2, 0x15

    .line 288
    .line 289
    const-string v1, "cvm_pin_recovery"

    .line 290
    .line 291
    const-string v0, "CVM_PIN_RECOVERY"

    .line 292
    .line 293
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 294
    .line 295
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 296
    .line 297
    .line 298
    sput-object v4, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CVM_PIN_RECOVERY:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 299
    .line 300
    const/16 v0, 0x16

    .line 301
    .line 302
    const-string v2, "cvm_downgrade"

    .line 303
    .line 304
    const-string v1, "CVM_DOWNGRADE"

    .line 305
    .line 306
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 307
    .line 308
    invoke-direct {v3, v1, v0, v2}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 309
    .line 310
    .line 311
    sput-object v3, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CVM_DOWNGRADE:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 312
    .line 313
    const/16 v1, 0x17

    .line 314
    .line 315
    const-string v16, "connections"

    .line 316
    .line 317
    const-string v0, "CONNECTIONS"

    .line 318
    .line 319
    new-instance v15, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 320
    .line 321
    move v2, v1

    .line 322
    move-object v1, v0

    .line 323
    move-object/from16 v0, v16

    .line 324
    .line 325
    invoke-direct {v15, v1, v2, v0}, Lcom/facebook/aura/analytics/hatch/HatchOrigin;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 326
    .line 327
    .line 328
    sput-object v15, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CONNECTIONS:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 329
    .line 330
    move-object/from16 v40, v12

    .line 331
    .line 332
    move-object/from16 v41, v11

    .line 333
    .line 334
    move-object/from16 v42, v10

    .line 335
    .line 336
    move-object/from16 v43, v9

    .line 337
    .line 338
    move-object/from16 v44, v8

    .line 339
    .line 340
    move-object/from16 v45, v7

    .line 341
    .line 342
    move-object/from16 v46, v6

    .line 343
    .line 344
    move-object/from16 v47, v5

    .line 345
    .line 346
    move-object/from16 v48, v4

    .line 347
    .line 348
    move-object/from16 v49, v3

    .line 349
    .line 350
    move-object/from16 v50, v15

    .line 351
    .line 352
    move-object/from16 v29, v25

    .line 353
    .line 354
    move-object/from16 v30, v24

    .line 355
    .line 356
    move-object/from16 v31, v23

    .line 357
    .line 358
    move-object/from16 v32, v22

    .line 359
    .line 360
    move-object/from16 v33, v21

    .line 361
    .line 362
    move-object/from16 v34, v20

    .line 363
    .line 364
    move-object/from16 v35, v19

    .line 365
    .line 366
    move-object/from16 v36, v18

    .line 367
    .line 368
    move-object/from16 v37, v17

    .line 369
    .line 370
    move-object/from16 v38, v14

    .line 371
    .line 372
    move-object/from16 v39, v13

    .line 373
    .line 374
    move-object/from16 v28, v26

    .line 375
    .line 376
    filled-new-array/range {v27 .. v50}, [Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 377
    .line 378
    .line 379
    move-result-object v0

    .line 380
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 381
    .line 382
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 383
    .line 384
    .line 385
    move-result-object v0

    .line 386
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->$ENTRIES:LX/0vk;

    .line 387
    .line 388
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/analytics/hatch/HatchOrigin;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchOrigin;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/analytics/hatch/HatchOrigin;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->$VALUES:[Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
