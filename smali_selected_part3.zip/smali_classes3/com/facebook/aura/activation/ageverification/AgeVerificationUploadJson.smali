.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson$Companion;


# instance fields
.field public final kind:Ljava/lang/String;

.field public final max_bytes:Ljava/lang/Long;

.field public final required:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 805306368
    const/4 v2, 0x0

    .line 805306369
    const-string v1, ""

    .line 805306370
    .line 805306371
    const/4 v0, 0x1

    .line 805306372
    invoke-direct {p0, v1, v0, v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;-><init>(Ljava/lang/String;ZLjava/lang/Long;)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;ZLjava/lang/Long;LX/5Xm;)V
    .locals 1

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-static {p1, p2}, LX/3Rr;->A0i(ILjava/lang/String;)Ljava/lang/String;

    .line 536870916
    .line 536870917
    .line 536870918
    move-result-object v0

    .line 536870919
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 536870920
    .line 536870921
    and-int/lit8 v0, p1, 0x2

    .line 536870922
    .line 536870923
    if-nez v0, :cond_0

    .line 536870924
    .line 536870925
    const/4 v0, 0x1

    .line 536870926
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 536870927
    .line 536870928
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_1

    .line 536870931
    .line 536870932
    const/4 v0, 0x0

    .line 536870933
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 536870934
    .line 536870935
    return-void

    .line 536870936
    :cond_0
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 536870937
    .line 536870938
    goto :goto_0

    .line 536870939
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 536870940
    .line 536870941
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ZLjava/lang/Long;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ZLjava/lang/Long;ILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p4, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object v1

    .line 268435460
    and-int/lit8 v0, p4, 0x2

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    const/4 p2, 0x1

    .line 268435465
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 268435466
    .line 268435467
    if-eqz v0, :cond_1

    .line 268435468
    .line 268435469
    const/4 p3, 0x0

    .line 268435470
    :cond_1
    invoke-direct {p0, v1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;-><init>(Ljava/lang/String;ZLjava/lang/Long;)V

    .line 268435471
    .line 268435472
    .line 268435473
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;Ljava/lang/String;ZLjava/lang/Long;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->copy(Ljava/lang/String;ZLjava/lang/Long;)Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v1, 0x1

    .line 21
    if-nez v3, :cond_2

    .line 22
    .line 23
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 24
    .line 25
    if-eq v0, v1, :cond_3

    .line 26
    .line 27
    :cond_2
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 28
    .line 29
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DZ1;->A00:LX/DZ1;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;ZLjava/lang/Long;)Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;-><init>(Ljava/lang/String;ZLjava/lang/Long;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    :cond_0
    return v2

    .line 37
    :cond_1
    return v3
.end method

.method public final getKind()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMax_bytes()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRequired()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
