.class public final synthetic Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x2

    .line 8
    const-string v0, "com.facebook.aura.activation.ageverification.AgeVerificationStartResponseJson"

    .line 9
    .line 10
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v0, "attempt_id"

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    const-string v0, "uploads"

    .line 21
    .line 22
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 23
    .line 24
    .line 25
    sput-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->descriptor:LX/Da5;

    .line 26
    .line 27
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/3Rt;->A0J([Lkotlin/Lazy;)[LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;
    .locals 10

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v9, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->descriptor:LX/Da5;

    .line 5
    .line 6
    invoke-interface {p1, v9}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 7
    .line 8
    .line 9
    move-result-object v8

    .line 10
    sget-object v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 11
    .line 12
    const/4 v6, 0x1

    .line 13
    const/4 v5, 0x0

    .line 14
    move-object v4, v5

    .line 15
    move-object v3, v5

    .line 16
    const/4 v2, 0x0

    .line 17
    :goto_0
    invoke-interface {v8, v9}, LX/Da7;->A8S(LX/Da5;)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    const/4 v0, -0x1

    .line 22
    if-eq v1, v0, :cond_2

    .line 23
    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    if-ne v1, v6, :cond_1

    .line 27
    .line 28
    invoke-static {v9, v8, v7, v6}, LX/3Rs;->A0k(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    or-int/lit8 v2, v2, 0x2

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_0
    invoke-interface {v8, v9, p0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    or-int/lit8 v2, v2, 0x1

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    invoke-static {v1}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    throw v0

    .line 47
    :cond_2
    invoke-interface {v8, v9}, LX/Da7;->AAi(LX/Da5;)V

    .line 48
    .line 49
    .line 50
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 51
    .line 52
    invoke-direct {v0, v2, v3, v4, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;-><init>(ILjava/lang/String;Ljava/util/List;LX/5Xm;)V

    .line 53
    .line 54
    .line 55
    return-object v0
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->descriptor:LX/Da5;

    .line 268435460
    .line 268435461
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 268435462
    .line 268435463
    .line 268435464
    move-result-object v0

    .line 268435465
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;LX/Da8;LX/Da5;)V

    .line 268435466
    .line 268435467
    .line 268435468
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
