.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$Companion;


# instance fields
.field public final attempt_id:Ljava/lang/String;

.field public final uploads:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v2, v0}, LX/3Rr;->A1X(Ljava/lang/Integer;Lkotlin/Lazy;Lkotlin/jvm/functions/Function0;)[Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const-string v1, ""

    .line 805306369
    .line 805306370
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306371
    .line 805306372
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;LX/5Xm;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-static {p1, p2}, LX/3Rr;->A0i(ILjava/lang/String;)Ljava/lang/String;

    .line 268435460
    .line 268435461
    .line 268435462
    move-result-object v0

    .line 268435463
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 268435464
    .line 268435465
    and-int/lit8 v0, p1, 0x2

    .line 268435466
    .line 268435467
    if-nez v0, :cond_0

    .line 268435468
    .line 268435469
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 268435470
    .line 268435471
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 268435472
    .line 268435473
    return-void

    .line 268435474
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 268435475
    .line 268435476
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/util/List;ILX/04f;)V
    .locals 2

    .line 536870912
    invoke-static {p3, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object v1

    .line 536870916
    invoke-static {p2, p3}, LX/3Rr;->A0t(Ljava/util/List;I)Ljava/util/List;

    .line 536870917
    .line 536870918
    .line 536870919
    move-result-object v0

    .line 536870920
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 536870921
    .line 536870922
    .line 536870923
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;Ljava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 16
    .line 17
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v2}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v2, 0x1

    .line 23
    if-nez v1, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 26
    .line 27
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 38
    .line 39
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 40
    .line 41
    .line 42
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getAttempt_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUploads()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
