.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $dismissLabel:Ljava/lang/String;

.field public final synthetic $onDismissClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$dismissLabel:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$onDismissClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    if-eqz v0, :cond_2

    .line 268435465
    .line 268435466
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$dismissLabel:Ljava/lang/String;

    .line 268435467
    .line 268435468
    invoke-interface {p1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435469
    .line 268435470
    .line 268435471
    move-result v1

    .line 268435472
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$onDismissClick:Lkotlin/jvm/functions/Function0;

    .line 268435473
    .line 268435474
    invoke-static {p1, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435475
    .line 268435476
    .line 268435477
    move-result v1

    .line 268435478
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$dismissLabel:Ljava/lang/String;

    .line 268435479
    .line 268435480
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;->$onDismissClick:Lkotlin/jvm/functions/Function0;

    .line 268435481
    .line 268435482
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435483
    .line 268435484
    .line 268435485
    move-result-object v0

    .line 268435486
    if-nez v1, :cond_0

    .line 268435487
    .line 268435488
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435489
    .line 268435490
    if-ne v0, v1, :cond_1

    .line 268435491
    .line 268435492
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1$1$1;

    .line 268435493
    .line 268435494
    invoke-direct {v0, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1$1$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 268435495
    .line 268435496
    .line 268435497
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435498
    .line 268435499
    .line 268435500
    :cond_1
    invoke-static {p1, v0}, LX/009;->A0z(LX/2d4;Ljava/lang/Object;)V

    .line 268435501
    .line 268435502
    .line 268435503
    return-void

    .line 268435504
    :cond_2
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435505
    .line 268435506
    .line 268435507
    return-void
.end method
