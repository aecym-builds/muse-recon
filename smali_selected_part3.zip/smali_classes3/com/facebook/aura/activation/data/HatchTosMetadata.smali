.class public final Lcom/facebook/aura/activation/data/HatchTosMetadata;
.super LX/07H;
.source ""


# instance fields
.field public final cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

.field public final disclosureButtonText:Ljava/lang/String;

.field public final disclosureEntities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureEntity;",
            ">;"
        }
    .end annotation
.end field

.field public final disclosureSections:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;"
        }
    .end annotation
.end field

.field public final disclosureText:Ljava/lang/String;

.field public final disclosureTitle:Ljava/lang/String;

.field public final disclosureVersion:Ljava/lang/String;

.field public final hasAcceptedTos:Z

.field public final infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

.field public final subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

.field public final subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;


# direct methods
.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureEntity;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "Lcom/facebook/aura/activation/data/HatchDisclosureText;",
            "Lcom/facebook/aura/activation/data/HatchInfoBanner;",
            ")V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, p3, p4, p5, v0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-boolean p1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 11
    .line 12
    iput-object p2, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p3, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p4, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 17
    .line 18
    iput-object p5, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p6, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p7, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 23
    .line 24
    iput-object p8, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 25
    .line 26
    iput-object p9, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 27
    .line 28
    iput-object p10, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 29
    .line 30
    iput-object p11, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 31
    .line 32
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;ILjava/lang/Object;)Lcom/facebook/aura/activation/data/HatchTosMetadata;
    .locals 1

    .line 0
    and-int/lit8 v0, p12, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p12, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p12, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p12, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p12, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p12, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p12, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p12, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p12, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 53
    .line 54
    :cond_8
    and-int/lit16 v0, p12, 0x200

    .line 55
    .line 56
    if-eqz v0, :cond_9

    .line 57
    .line 58
    iget-object p10, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 59
    .line 60
    :cond_9
    and-int/lit16 v0, p12, 0x400

    .line 61
    .line 62
    if-eqz v0, :cond_a

    .line 63
    .line 64
    iget-object p11, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 65
    .line 66
    :cond_a
    invoke-virtual/range {p0 .. p11}, Lcom/facebook/aura/activation/data/HatchTosMetadata;->copy(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    return-object v0
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component10()Lcom/facebook/aura/activation/data/HatchDisclosureText;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Lcom/facebook/aura/activation/data/HatchInfoBanner;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/data/HatchTosMetadata;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureEntity;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "Lcom/facebook/aura/activation/data/HatchDisclosureText;",
            "Lcom/facebook/aura/activation/data/HatchInfoBanner;",
            ")",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p3, p4, p5, p0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    new-instance p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 8
    .line 9
    invoke-direct/range {p0 .. p11}, Lcom/facebook/aura/activation/data/HatchTosMetadata;-><init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchUpsellCell;Lcom/facebook/aura/activation/data/HatchDisclosureText;Lcom/facebook/aura/activation/data/HatchInfoBanner;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_0

    .line 75
    .line 76
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 77
    .line 78
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 79
    .line 80
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_0

    .line 85
    .line 86
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 87
    .line 88
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 89
    .line 90
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_0

    .line 95
    .line 96
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 97
    .line 98
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 99
    .line 100
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_0

    .line 105
    .line 106
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 107
    .line 108
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 109
    .line 110
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    if-nez v0, :cond_1

    .line 115
    .line 116
    :cond_0
    return v2

    .line 117
    :cond_1
    return v3
.end method

.method public final getCvmUpsellCell()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureButtonText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureEntities()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureSections()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosureVersion()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHasAcceptedTos()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getInfoBanner()Lcom/facebook/aura/activation/data/HatchInfoBanner;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscriptionDisclosure()Lcom/facebook/aura/activation/data/HatchDisclosureText;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscriptionUpsellCell()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 1
    .line 2
    invoke-static {v0}, LX/07F;->A02(Z)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureVersion:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 43
    .line 44
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    mul-int/lit8 v1, v1, 0x1f

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 52
    .line 53
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    add-int/2addr v1, v0

    .line 58
    mul-int/lit8 v1, v1, 0x1f

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 61
    .line 62
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    add-int/2addr v1, v0

    .line 67
    mul-int/lit8 v1, v1, 0x1f

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 70
    .line 71
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    add-int/2addr v1, v0

    .line 76
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
