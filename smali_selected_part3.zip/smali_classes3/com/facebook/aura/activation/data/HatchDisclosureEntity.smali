.class public final Lcom/facebook/aura/activation/data/HatchDisclosureEntity;
.super LX/07H;
.source ""


# instance fields
.field public final length:I

.field public final offset:I

.field public final url:Ljava/lang/String;


# direct methods
.method public constructor <init>(IILjava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/data/HatchDisclosureEntity;IILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/data/HatchDisclosureEntity;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget p2, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->copy(IILjava/lang/String;)Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 1
    .line 2
    return p0
.end method

.method public final component2()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(IILjava/lang/String;)Lcom/facebook/aura/activation/data/HatchDisclosureEntity;
    .locals 0

    .line 0
    const/4 p0, 0x2

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;-><init>(IILjava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 17
    .line 18
    iget v0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    :cond_0
    return v2

    .line 33
    :cond_1
    return v3
.end method

.method public final getLength()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 1
    .line 2
    return p0
.end method

.method public final getOffset()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 1
    .line 2
    return p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 1
    .line 2
    mul-int/lit8 v1, v0, 0x1f

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 5
    .line 6
    add-int/2addr v1, v0

    .line 7
    mul-int/lit8 v1, v1, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0, v1}, LX/006;->A0L(Ljava/lang/String;I)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
