.class public final Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
.super LX/07H;
.source ""


# instance fields
.field public final error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

.field public final firstName:Ljava/lang/String;

.field public final isContinueEnabled:Z

.field public final isSaving:Z

.field public final lastName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 536870912
    const/4 v5, 0x0

    .line 536870913
    const-string v1, ""

    .line 536870914
    .line 536870915
    const/4 v3, 0x0

    .line 536870916
    move-object v0, p0

    .line 536870917
    move-object v2, v1

    .line 536870918
    move v4, v3

    .line 536870919
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)V

    .line 536870920
    .line 536870921
    .line 536870922
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 9
    .line 10
    iput-boolean p3, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 11
    .line 12
    iput-boolean p4, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 13
    .line 14
    iput-object p5, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p6, 0x1

    .line 268435457
    .line 268435458
    const-string v1, ""

    .line 268435459
    .line 268435460
    if-eqz v0, :cond_0

    .line 268435461
    .line 268435462
    move-object p1, v1

    .line 268435463
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 268435464
    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    invoke-static {p6, p3}, LX/006;->A1X(IZ)Z

    .line 268435469
    .line 268435470
    .line 268435471
    move-result p3

    .line 268435472
    invoke-static {p6, p4}, LX/3Rr;->A1P(IZ)Z

    .line 268435473
    .line 268435474
    .line 268435475
    move-result p4

    .line 268435476
    and-int/lit8 v0, p6, 0x10

    .line 268435477
    .line 268435478
    if-eqz v0, :cond_2

    .line 268435479
    .line 268435480
    const/4 p5, 0x0

    .line 268435481
    :cond_2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)V

    .line 268435482
    .line 268435483
    .line 268435484
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 31
    .line 32
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 37
    .line 38
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 43
    .line 44
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 45
    .line 46
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_1

    .line 51
    .line 52
    :cond_0
    return v2

    .line 53
    :cond_1
    return v3
.end method

.method public final getError()Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFirstName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLastName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 25
    .line 26
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v1, v0

    .line 31
    return v1
.end method

.method public final isContinueEnabled()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isSaving()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
