.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraDisclosureViewModel$fetchTosMetadata$1"
    f = "AuraDisclosureViewModel.kt"
    l = {
        0x55
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 0
    move-object v8, p1

    .line 1
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 2
    .line 3
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->label:I

    .line 4
    .line 5
    const/4 v6, 0x1

    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    if-ne v0, v6, :cond_6

    .line 9
    .line 10
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    check-cast v8, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 14
    .line 15
    iget-object v4, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 16
    .line 17
    iget-object v3, v4, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 18
    .line 19
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    move-object v1, v2

    .line 24
    check-cast v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 25
    .line 26
    const/4 v10, 0x0

    .line 27
    if-eqz v8, :cond_3

    .line 28
    .line 29
    iget-object v0, v8, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionDisclosure:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 30
    .line 31
    if-eqz v0, :cond_3

    .line 32
    .line 33
    invoke-static {v4, v0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->access$toLegalText(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/data/HatchDisclosureText;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 34
    .line 35
    .line 36
    move-result-object v9

    .line 37
    :goto_0
    iget-object v0, v8, Lcom/facebook/aura/activation/data/HatchTosMetadata;->infoBanner:Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 38
    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    invoke-static {v4, v0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->access$toUiModel(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 42
    .line 43
    .line 44
    move-result-object v10

    .line 45
    :cond_2
    const/4 v7, 0x0

    .line 46
    iget-boolean v6, v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 47
    .line 48
    iget-object p0, v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 49
    .line 50
    new-instance v5, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 51
    .line 52
    invoke-direct/range {v5 .. v11}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 53
    .line 54
    .line 55
    invoke-static {v4, v5}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->access$withUpsellCell(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_1

    .line 64
    .line 65
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 66
    .line 67
    return-object v3

    .line 68
    :cond_3
    move-object v9, v10

    .line 69
    if-eqz v8, :cond_2

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 76
    .line 77
    iget-object v2, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 78
    .line 79
    :cond_5
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    move-object v0, v1

    .line 84
    check-cast v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 85
    .line 86
    iget-boolean v5, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 87
    .line 88
    iget-object v7, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 89
    .line 90
    iget-object v8, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 91
    .line 92
    iget-object v9, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 93
    .line 94
    iget-object v10, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 95
    .line 96
    new-instance v4, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 97
    .line 98
    invoke-direct/range {v4 .. v10}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 99
    .line 100
    .line 101
    invoke-interface {v2, v1, v4}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-eqz v0, :cond_5

    .line 106
    .line 107
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 108
    .line 109
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 110
    .line 111
    iput v6, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;->label:I

    .line 112
    .line 113
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->fetchTosMetadata(LX/2M4;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    if-ne v8, v3, :cond_0

    .line 118
    .line 119
    return-object v3

    .line 120
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    throw v0
.end method
