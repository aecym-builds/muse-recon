.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;
.super LX/1EJ;
.source ""


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

.field public final loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/AHE;Ljava/lang/String;)V
    .locals 5

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, p2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;->INSTANCE:Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rp;->A04(Lcom/facebook/aura/common/coroutines/OnDuplicateCall;)Lcom/facebook/aura/common/coroutines/LazyStartSingleFlightImpl;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 16
    .line 17
    if-eqz p3, :cond_0

    .line 18
    .line 19
    invoke-static {p3}, LX/603;->A0n(Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    :goto_0
    const/4 v2, 0x0

    .line 24
    sget-object v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;

    .line 25
    .line 26
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 27
    .line 28
    invoke-direct {v0, v3, v4, v2, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 29
    .line 30
    .line 31
    invoke-static {v0}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iput-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 36
    .line 37
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iput-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->uiState:LX/2J3;

    .line 42
    .line 43
    invoke-direct {p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->loadInvitePage()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_0
    const-string v3, ""

    .line 48
    .line 49
    goto :goto_0
.end method

.method public static final synthetic access$getActivationRepository$p(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getLoadSingleFlight$p(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;)Lcom/facebook/aura/common/coroutines/SingleFlight;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$logRedemptionResult(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->logRedemptionResult(Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final loadInvitePage()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1;

    .line 10
    .line 11
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final logRedemptionResult(Ljava/lang/String;)V
    .locals 7

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_CODE_FORM:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 11
    .line 12
    invoke-static {v0, p1}, LX/3Rs;->A0m(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;Ljava/lang/Object;)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    const/4 v6, 0x0

    .line 17
    move-object p1, v6

    .line 18
    invoke-virtual/range {v1 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method private final logSubmit()V
    .locals 7

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->REDEEM_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_CODE_FORM:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    move-object v6, v5

    .line 12
    move-object p0, v5

    .line 13
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onConfirmClick()V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    check-cast v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 7
    .line 8
    iget-object v7, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 9
    .line 10
    iget-boolean v0, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    iget-object v0, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 15
    .line 16
    instance-of v0, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/4 v0, 0x6

    .line 25
    if-lt v1, v0, :cond_1

    .line 26
    .line 27
    iget-object v6, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 28
    .line 29
    :cond_0
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    move-object v0, v5

    .line 34
    check-cast v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    iget-object v3, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 38
    .line 39
    iget-object v2, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 40
    .line 41
    const/4 v1, 0x1

    .line 42
    invoke-static {v3, v2}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 46
    .line 47
    invoke-direct {v0, v3, v1, v4, v2}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {v6, v5, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    invoke-direct {p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->logSubmit()V

    .line 57
    .line 58
    .line 59
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;

    .line 68
    .line 69
    invoke-direct {v0, p0, v7, v4}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;Ljava/lang/String;LX/2M4;)V

    .line 70
    .line 71
    .line 72
    invoke-static {v1, v0, v2}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 73
    .line 74
    .line 75
    :cond_1
    return-void
.end method

.method public final onInviteCodeChange(Ljava/lang/String;)V
    .locals 8

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 11
    .line 12
    iget-boolean v0, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-static {p1}, Lcom/facebook/aura/activation/model/InviteCodeKt;->normalizeInviteCodeInput(Ljava/lang/String;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v7

    .line 20
    if-eqz v7, :cond_1

    .line 21
    .line 22
    iget-object v6, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 23
    .line 24
    :cond_0
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    move-object v4, v5

    .line 29
    check-cast v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 30
    .line 31
    iget-object v0, v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    move-object v0, v4

    .line 40
    :goto_0
    invoke-interface {v6, v5, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v2, v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    const/4 v1, 0x6

    .line 53
    if-ne v0, v1, :cond_1

    .line 54
    .line 55
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-ge v0, v1, :cond_1

    .line 60
    .line 61
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->onConfirmClick()V

    .line 62
    .line 63
    .line 64
    :cond_1
    return-void

    .line 65
    :cond_2
    const/4 v3, 0x0

    .line 66
    iget-boolean v2, v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 67
    .line 68
    iget-object v1, v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 69
    .line 70
    const/4 v0, 0x3

    .line 71
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 72
    .line 73
    .line 74
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 75
    .line 76
    invoke-direct {v0, v7, v2, v3, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 77
    .line 78
    .line 79
    goto :goto_0
.end method

.method public final onRetryClick()V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->loadInvitePage()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
