.class public final Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDQ<",
        "Lcom/facebook/aura/user/provider/AuraUserData;",
        "Ljava/lang/Boolean;",
        "LX/2M4<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.HatchActivationGateViewModel$isGateRequired$1"
    f = "HatchActivationGateViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic Z$0:Z

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/user/provider/AuraUserData;ZLX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/user/provider/AuraUserData;",
            "Z",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;

    .line 268435457
    .line 268435458
    invoke-direct {p0, p3}, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->L$0:Ljava/lang/Object;

    .line 268435462
    .line 268435463
    iput-boolean p2, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->Z$0:Z

    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, Lcom/facebook/aura/user/provider/AuraUserData;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    check-cast p3, LX/2M4;

    .line 7
    .line 8
    invoke-virtual {p0, p1, v0, p3}, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->invoke(Lcom/facebook/aura/user/provider/AuraUserData;ZLX/2M4;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v3, Lcom/facebook/aura/user/provider/AuraUserData;

    .line 3
    .line 4
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->Z$0:Z

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;->label:I

    .line 7
    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    invoke-virtual {v3, v2, v1, v2}, Lcom/facebook/aura/user/provider/AuraUserData;->getCurrentActivationState(ZZZ)Lcom/facebook/aura/activation/data/ActivationState;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/activation/data/ActivationState;->FULLY_ACTIVATED:Lcom/facebook/aura/activation/data/ActivationState;

    .line 23
    .line 24
    if-eq v1, v0, :cond_0

    .line 25
    .line 26
    sget-object v0, Lcom/facebook/aura/activation/data/ActivationState;->LOADING:Lcom/facebook/aura/activation/data/ActivationState;

    .line 27
    .line 28
    if-eq v1, v0, :cond_0

    .line 29
    .line 30
    const/4 v2, 0x1

    .line 31
    :cond_0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    return-object v0

    .line 36
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    throw v0
.end method
