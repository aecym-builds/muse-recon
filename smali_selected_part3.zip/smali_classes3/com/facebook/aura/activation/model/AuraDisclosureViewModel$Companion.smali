.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getCONFIDENTIAL_VM_ROUTES()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->CONFIDENTIAL_VM_ROUTES:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method
