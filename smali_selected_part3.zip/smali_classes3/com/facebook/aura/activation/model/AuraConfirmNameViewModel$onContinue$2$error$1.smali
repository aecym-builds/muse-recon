.class public final Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/user/provider/AuraUserData;",
        "Lcom/facebook/aura/user/provider/AuraUserData;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;->INSTANCE:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/user/provider/AuraUserData;)Lcom/facebook/aura/user/provider/AuraUserData;
    .locals 25

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const p0, 0xffbfff

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    move-object v2, v1

    .line 11
    move-object v3, v1

    .line 12
    move-object v4, v1

    .line 13
    move-object v5, v1

    .line 14
    move-object v6, v1

    .line 15
    move v8, v7

    .line 16
    move-object v9, v1

    .line 17
    move-object v10, v1

    .line 18
    move v11, v7

    .line 19
    move v12, v7

    .line 20
    move v13, v7

    .line 21
    move-object v14, v1

    .line 22
    move v15, v7

    .line 23
    move-object/from16 v16, v1

    .line 24
    .line 25
    move-object/from16 v17, v1

    .line 26
    .line 27
    move-object/from16 v18, v1

    .line 28
    .line 29
    move-object/from16 v19, v1

    .line 30
    .line 31
    move-object/from16 v20, v1

    .line 32
    .line 33
    move-object/from16 v21, v1

    .line 34
    .line 35
    move-object/from16 v22, v1

    .line 36
    .line 37
    move-object/from16 v23, v1

    .line 38
    .line 39
    move-object/from16 v24, v1

    .line 40
    .line 41
    move-object/from16 p1, v1

    .line 42
    .line 43
    invoke-static/range {v0 .. v26}, Lcom/facebook/aura/user/provider/AuraUserData;->copy$default(Lcom/facebook/aura/user/provider/AuraUserData;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;LX/7Kq;ZZLX/BDp;Ljava/lang/Boolean;ZZZLjava/lang/Boolean;ZLjava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckLayout;ILjava/lang/Object;)Lcom/facebook/aura/user/provider/AuraUserData;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/user/provider/AuraUserData;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;->invoke(Lcom/facebook/aura/user/provider/AuraUserData;)Lcom/facebook/aura/user/provider/AuraUserData;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
