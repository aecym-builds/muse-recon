.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final CONFIDENTIAL_VM_ROUTES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Companion;


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final _viewEffect:LX/5Lx;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/5Lx<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect;",
            ">;"
        }
    .end annotation
.end field

.field public final activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

.field public final deferredDeeplinks:Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;

.field public final setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final viewEffect:LX/2QV;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2QV<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->Companion:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Companion;

    .line 6
    .line 7
    const-string v1, "cvm_switch"

    .line 8
    .line 9
    const-string v0, "cvm_off_waitlist"

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/0wJ;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->CONFIDENTIAL_VM_ROUTES:Ljava/util/Set;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;)V
    .locals 11

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, p2, p3}, LX/3Rs;->A1R(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v6

    .line 5
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 9
    .line 10
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 11
    .line 12
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->deferredDeeplinks:Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;

    .line 13
    .line 14
    const/4 v7, 0x0

    .line 15
    sget-object v3, LX/FkO;->A00:Ljava/lang/Integer;

    .line 16
    .line 17
    invoke-static {v3, v5, v5}, LX/5NB;->A00(Ljava/lang/Integer;II)LX/Ddz;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_viewEffect:LX/5Lx;

    .line 22
    .line 23
    invoke-static {v0}, LX/602;->A16(LX/2QV;)LX/ETm;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->viewEffect:LX/2QV;

    .line 28
    .line 29
    new-instance v4, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 30
    .line 31
    move-object v8, v7

    .line 32
    move-object v9, v7

    .line 33
    move-object v10, v7

    .line 34
    invoke-direct/range {v4 .. v10}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 35
    .line 36
    .line 37
    invoke-static {v4}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 42
    .line 43
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->uiState:LX/2J3;

    .line 48
    .line 49
    invoke-direct {p0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->fetchTosMetadata()V

    .line 50
    .line 51
    .line 52
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    new-instance v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1;

    .line 57
    .line 58
    invoke-direct {v1, p0, v7}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;LX/2M4;)V

    .line 59
    .line 60
    .line 61
    sget-object v0, LX/39s;->A00:LX/39s;

    .line 62
    .line 63
    invoke-static {v3, v0, v1, v2}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public static final synthetic access$getActivationRepository$p(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getCONFIDENTIAL_VM_ROUTES$cp()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->CONFIDENTIAL_VM_ROUTES:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getDeferredDeeplinks$p(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->deferredDeeplinks:Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSetupGate$p(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_viewEffect$p(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)LX/5Lx;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_viewEffect:LX/5Lx;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$toLegalText(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/data/HatchDisclosureText;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->toLegalText(Lcom/facebook/aura/activation/data/HatchDisclosureText;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$toUiModel(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->toUiModel(Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$withUpsellCell(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->withUpsellCell(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final fetchTosMetadata()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;

    .line 10
    .line 11
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$fetchTosMetadata$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final toLegalText(Lcom/facebook/aura/activation/data/HatchDisclosureText;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;
    .locals 6

    .line 0
    iget-object p0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureText;->text:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchDisclosureText;->entities:Ljava/util/List;

    .line 3
    .line 4
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 23
    .line 24
    iget v3, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 25
    .line 26
    iget v2, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 27
    .line 28
    iget-object v1, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 29
    .line 30
    new-instance v0, Lcom/facebook/aura/linktext/HatchTextLink;

    .line 31
    .line 32
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/linktext/HatchTextLink;-><init>(IILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    invoke-static {v5}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 44
    .line 45
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;-><init>(Ljava/lang/String;LX/Ddn;)V

    .line 46
    .line 47
    .line 48
    return-object v0
.end method

.method private final toUiModel(Lcom/facebook/aura/activation/data/HatchInfoBanner;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;
    .locals 6

    .line 0
    iget-object v5, p1, Lcom/facebook/aura/activation/data/HatchInfoBanner;->text:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInfoBanner;->sections:Ljava/util/List;

    .line 3
    .line 4
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lcom/facebook/aura/activation/data/HatchInfoSheetSection;

    .line 23
    .line 24
    iget-object v2, v0, Lcom/facebook/aura/activation/data/HatchInfoSheetSection;->title:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v0, v0, Lcom/facebook/aura/activation/data/HatchInfoSheetSection;->body:Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 27
    .line 28
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->toLegalText(Lcom/facebook/aura/activation/data/HatchDisclosureText;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;

    .line 33
    .line 34
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-static {v4}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    iget-object v1, p1, Lcom/facebook/aura/activation/data/HatchInfoBanner;->closeText:Ljava/lang/String;

    .line 46
    .line 47
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 48
    .line 49
    invoke-direct {v0, v5, v2, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;-><init>(Ljava/lang/String;LX/Ddn;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    return-object v0
.end method

.method private final withUpsellCell(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 6

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->CONFIDENTIAL_VM_ROUTES:Ljava/util/Set;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->deferredDeeplinks:Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;

    .line 3
    .line 4
    iget-object v0, v0, Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks;->awaitingActivation:LX/2J3;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;

    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    iget-object v0, v0, Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;->routeName:Ljava/lang/String;

    .line 16
    .line 17
    :goto_0
    invoke-static {v1, v0}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    iget-object v3, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    iget-object p0, v3, Lcom/facebook/aura/activation/data/HatchTosMetadata;->cvmUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 28
    .line 29
    :cond_0
    :goto_1
    iget-boolean v1, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 30
    .line 31
    iget-boolean v2, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 32
    .line 33
    iget-object v4, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 34
    .line 35
    iget-object v5, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 38
    .line 39
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 40
    .line 41
    .line 42
    return-object v0

    .line 43
    :cond_1
    if-eqz v3, :cond_0

    .line 44
    .line 45
    iget-object p0, v3, Lcom/facebook/aura/activation/data/HatchTosMetadata;->subscriptionUpsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_2
    move-object v0, p0

    .line 49
    goto :goto_0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getViewEffect()LX/2QV;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2QV<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->viewEffect:LX/2QV;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onClose(Ljava/lang/String;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 11
    .line 12
    iget-boolean v0, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/4 v1, 0x0

    .line 25
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;

    .line 26
    .line 27
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Ljava/lang/String;LX/2M4;)V

    .line 28
    .line 29
    .line 30
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method

.method public final onInfoBannerClick()V
    .locals 7

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->PRIVACY_INFO_BANNER:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    move-object v5, v2

    .line 10
    move-object v6, v2

    .line 11
    move-object p0, v2

    .line 12
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
