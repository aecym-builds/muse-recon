.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.HatchRedeemInviteCodeViewModel$loadInvitePage$1$1"
    f = "HatchRedeemInviteCodeViewModel.kt"
    l = {
        0x5c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;

    .line 3
    .line 4
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->label:I

    .line 3
    .line 4
    const/4 v7, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    if-ne v0, v7, :cond_6

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    check-cast p1, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 13
    .line 14
    if-eqz p1, :cond_3

    .line 15
    .line 16
    iget-object v2, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 17
    .line 18
    iget-object v1, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 19
    .line 20
    if-eqz v2, :cond_3

    .line 21
    .line 22
    if-eqz v1, :cond_3

    .line 23
    .line 24
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    new-instance v6, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;

    .line 29
    .line 30
    invoke-direct {v6, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;-><init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 31
    .line 32
    .line 33
    :goto_0
    check-cast v6, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 36
    .line 37
    iget-object v5, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 38
    .line 39
    :cond_1
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    move-object v0, v4

    .line 44
    check-cast v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 45
    .line 46
    iget-object v3, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 47
    .line 48
    iget-boolean v2, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 49
    .line 50
    iget-object v1, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 51
    .line 52
    invoke-static {v3, v6}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 56
    .line 57
    invoke-direct {v0, v3, v2, v1, v6}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 58
    .line 59
    .line 60
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_1

    .line 65
    .line 66
    sget-object v8, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 67
    .line 68
    return-object v8

    .line 69
    :cond_2
    new-instance v6, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 70
    .line 71
    invoke-direct {v6, v2, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;-><init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 72
    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    const-string v1, "HatchRedeemInviteCodeViewModel"

    .line 76
    .line 77
    const-string v0, "Invite page copy unavailable, showing the retry state"

    .line 78
    .line 79
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sget-object v6, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$LoadFailed;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$LoadFailed;

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 89
    .line 90
    iget-object v6, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 91
    .line 92
    :cond_5
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    move-object v0, v5

    .line 97
    check-cast v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 98
    .line 99
    sget-object v4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;

    .line 100
    .line 101
    iget-object v3, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 102
    .line 103
    iget-boolean v2, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 104
    .line 105
    iget-object v1, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 106
    .line 107
    invoke-static {v3, v4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 111
    .line 112
    invoke-direct {v0, v3, v2, v1, v4}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 113
    .line 114
    .line 115
    invoke-interface {v6, v5, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_5

    .line 120
    .line 121
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 122
    .line 123
    iget-object v0, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 124
    .line 125
    iput v7, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$loadInvitePage$1$1;->label:I

    .line 126
    .line 127
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->fetchInvitePage(LX/2M4;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    if-ne p1, v8, :cond_0

    .line 132
    .line 133
    return-object v8

    .line 134
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    throw v0
.end method
