.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraDisclosureViewModel$onClose$1"
    f = "AuraDisclosureViewModel.kt"
    l = {
        0x79,
        0x7e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $fallbackDisclosureText:Ljava/lang/String;

.field public Z$0:Z

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Ljava/lang/String;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 0
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x2

    .line 5
    const/4 v6, 0x1

    .line 6
    if-eqz v2, :cond_1

    .line 7
    .line 8
    if-eq v2, v6, :cond_3

    .line 9
    .line 10
    if-ne v2, v1, :cond_8

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 22
    .line 23
    iget-object v4, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 24
    .line 25
    :cond_2
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    move-object v2, v3

    .line 30
    check-cast v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 31
    .line 32
    iget-boolean v7, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 33
    .line 34
    iget-object v8, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 35
    .line 36
    iget-object v9, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 37
    .line 38
    iget-object v10, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 39
    .line 40
    iget-object v11, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 41
    .line 42
    new-instance v5, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 43
    .line 44
    invoke-direct/range {v5 .. v11}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 45
    .line 46
    .line 47
    invoke-interface {v4, v3, v5}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_2

    .line 52
    .line 53
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 54
    .line 55
    iget-object v3, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 56
    .line 57
    sget-object v2, Lcom/facebook/aura/gateway/HatchlingVmType;->HATCH_VM:Lcom/facebook/aura/gateway/HatchlingVmType;

    .line 58
    .line 59
    invoke-virtual {v3, v2}, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;->markSelected(Lcom/facebook/aura/gateway/HatchlingVmType;)Z

    .line 60
    .line 61
    .line 62
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 63
    .line 64
    iget-object v4, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 65
    .line 66
    iget-object v2, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 67
    .line 68
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    check-cast v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 73
    .line 74
    iget-object v3, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 75
    .line 76
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 77
    .line 78
    iput v6, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->label:I

    .line 79
    .line 80
    invoke-static {v4, v3, v2, p0}, Lcom/facebook/aura/activation/model/TosConsentKt;->submitTosConsent(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    if-ne p1, v0, :cond_4

    .line 85
    .line 86
    return-object v0

    .line 87
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    :cond_4
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    if-nez v4, :cond_5

    .line 95
    .line 96
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 97
    .line 98
    iget-object v2, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 99
    .line 100
    invoke-virtual {v2}, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;->resetSelection()Z

    .line 101
    .line 102
    .line 103
    :cond_5
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 104
    .line 105
    iget-object v5, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 106
    .line 107
    :cond_6
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    move-object v2, v3

    .line 112
    check-cast v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 113
    .line 114
    const/4 v7, 0x0

    .line 115
    iget-boolean v8, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 116
    .line 117
    iget-object v9, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 118
    .line 119
    iget-object v10, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 120
    .line 121
    iget-object v11, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 122
    .line 123
    iget-object v12, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 124
    .line 125
    new-instance v6, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 126
    .line 127
    invoke-direct/range {v6 .. v12}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 128
    .line 129
    .line 130
    invoke-interface {v5, v3, v6}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v2

    .line 134
    if-eqz v2, :cond_6

    .line 135
    .line 136
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 137
    .line 138
    iget-object v3, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_viewEffect:LX/5Lx;

    .line 139
    .line 140
    if-eqz v4, :cond_7

    .line 141
    .line 142
    sget-object v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect$DisclosureAccepted;->INSTANCE:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect$DisclosureAccepted;

    .line 143
    .line 144
    :goto_0
    iput-boolean v4, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->Z$0:Z

    .line 145
    .line 146
    iput v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$onClose$1;->label:I

    .line 147
    .line 148
    invoke-interface {v3, v2, p0}, LX/5Lx;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    if-ne v1, v0, :cond_0

    .line 153
    .line 154
    return-object v0

    .line 155
    :cond_7
    sget-object v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect$AcceptFailed;->INSTANCE:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect$AcceptFailed;

    .line 156
    .line 157
    goto :goto_0

    .line 158
    :cond_8
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    throw v0
.end method
