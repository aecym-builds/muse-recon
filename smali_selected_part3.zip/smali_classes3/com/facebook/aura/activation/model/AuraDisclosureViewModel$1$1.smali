.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 268435457
    .line 268435458
    iget-object p1, p2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->_uiState:LX/2J2;

    .line 268435459
    .line 268435460
    :cond_0
    invoke-interface {p1}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    move-object v0, p0

    .line 268435465
    check-cast v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 268435466
    .line 268435467
    invoke-static {p2, v0}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->access$withUpsellCell(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    invoke-interface {p1, p0, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435472
    .line 268435473
    .line 268435474
    move-result v0

    .line 268435475
    if-eqz v0, :cond_0

    .line 268435476
    .line 268435477
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435478
    .line 268435479
    return-object v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$1$1;->emit(Lcom/facebook/aura/deeplink/HatchDeferredDeeplinks$Link;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
