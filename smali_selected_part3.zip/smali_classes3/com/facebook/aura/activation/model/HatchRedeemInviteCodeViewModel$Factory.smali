.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;",
        ">;"
    }
.end annotation


# instance fields
.field public final initialCode:Ljava/lang/String;

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->initialCode:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->create()Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;
    .locals 4

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    iget-object v2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->userSession:LX/AHE;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$Factory;->initialCode:Ljava/lang/String;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 13
    .line 14
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/AHE;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method
