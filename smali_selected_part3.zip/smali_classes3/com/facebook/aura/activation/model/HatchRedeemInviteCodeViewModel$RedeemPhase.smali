.class public interface abstract Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;
.super Ljava/lang/Object;
.source ""
