.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;
.super LX/07H;
.source ""


# instance fields
.field public final error:Lcom/facebook/aura/activation/model/InviteCodeError;

.field public final inviteCode:Ljava/lang/String;

.field public final isLoading:Z

.field public final phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 536870912
    const/4 v3, 0x0

    .line 536870913
    const-string v2, ""

    .line 536870914
    .line 536870915
    const/4 v1, 0x0

    .line 536870916
    sget-object v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;

    .line 536870917
    .line 536870918
    invoke-direct {p0, v2, v1, v3, v0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 536870919
    .line 536870920
    .line 536870921
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V
    .locals 0

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 7
    .line 8
    iput-boolean p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 11
    .line 12
    iput-object p4, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;ILX/04f;)V
    .locals 3

    .line 268435456
    invoke-static {p5, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object v2

    .line 268435460
    invoke-static {p5, p2}, LX/3Rr;->A1O(IZ)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v1

    .line 268435464
    and-int/lit8 v0, p5, 0x4

    .line 268435465
    .line 268435466
    if-eqz v0, :cond_0

    .line 268435467
    .line 268435468
    const/4 p3, 0x0

    .line 268435469
    :cond_0
    and-int/lit8 v0, p5, 0x8

    .line 268435470
    .line 268435471
    if-eqz v0, :cond_1

    .line 268435472
    .line 268435473
    sget-object p4, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;

    .line 268435474
    .line 268435475
    :cond_1
    invoke-direct {p0, v2, v1, p3, p4}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 268435476
    .line 268435477
    .line 268435478
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 23
    .line 24
    :cond_3
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 28
    .line 29
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 30
    .line 31
    .line 32
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Lcom/facebook/aura/activation/model/InviteCodeError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;
    .locals 0

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    :cond_0
    return v2

    .line 47
    :cond_1
    return v3
.end method

.method public final getError()Lcom/facebook/aura/activation/model/InviteCodeError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getInviteCode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPhase()Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 22
    .line 23
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    return v0
.end method

.method public final isLoading()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
