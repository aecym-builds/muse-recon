.class public final Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
.super LX/07H;
.source ""


# instance fields
.field public final infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

.field public final isFetchingMetadata:Z

.field public final isLoading:Z

.field public final subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

.field public final tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

.field public final upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 536870912
    const/4 v3, 0x0

    .line 536870913
    const/4 v1, 0x0

    .line 536870914
    const/4 v2, 0x1

    .line 536870915
    move-object v0, p0

    .line 536870916
    move-object v4, v3

    .line 536870917
    move-object v5, v3

    .line 536870918
    move-object p0, v3

    .line 536870919
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 536870920
    .line 536870921
    .line 536870922
    return-void
.end method

.method public constructor <init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 10
    .line 11
    iput-object p5, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 12
    .line 13
    iput-object p6, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;ILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p7, p1}, LX/002;->A1U(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p1

    .line 268435460
    and-int/lit8 v0, p7, 0x2

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    const/4 p2, 0x1

    .line 268435465
    :cond_0
    and-int/lit8 v0, p7, 0x4

    .line 268435466
    .line 268435467
    const/4 v1, 0x0

    .line 268435468
    if-eqz v0, :cond_1

    .line 268435469
    .line 268435470
    move-object p3, v1

    .line 268435471
    :cond_1
    and-int/lit8 v0, p7, 0x8

    .line 268435472
    .line 268435473
    if-eqz v0, :cond_2

    .line 268435474
    .line 268435475
    move-object p4, v1

    .line 268435476
    :cond_2
    and-int/lit8 v0, p7, 0x10

    .line 268435477
    .line 268435478
    if-eqz v0, :cond_3

    .line 268435479
    .line 268435480
    move-object p5, v1

    .line 268435481
    :cond_3
    and-int/lit8 v0, p7, 0x20

    .line 268435482
    .line 268435483
    if-eqz v0, :cond_4

    .line 268435484
    .line 268435485
    move-object p6, v1

    .line 268435486
    :cond_4
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 268435487
    .line 268435488
    .line 268435489
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 7

    .line 0
    move v1, p1

    .line 1
    move v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-object v4, p4

    .line 4
    move-object v5, p5

    .line 5
    move-object v6, p6

    .line 6
    and-int/lit8 v0, p7, 0x1

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 11
    .line 12
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-boolean v2, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 17
    .line 18
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 19
    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    iget-object v3, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 23
    .line 24
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 25
    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    iget-object v4, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 29
    .line 30
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 31
    .line 32
    if-eqz v0, :cond_4

    .line 33
    .line 34
    iget-object v5, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 35
    .line 36
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 37
    .line 38
    if-eqz v0, :cond_5

    .line 39
    .line 40
    iget-object v6, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 41
    .line 42
    :cond_5
    new-instance v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 43
    .line 44
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 45
    .line 46
    .line 47
    return-object v0
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Lcom/facebook/aura/activation/data/HatchTosMetadata;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;-><init>(ZZLcom/facebook/aura/activation/data/HatchTosMetadata;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 17
    .line 18
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 23
    .line 24
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 33
    .line 34
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 43
    .line 44
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 45
    .line 46
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 53
    .line 54
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 55
    .line 56
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-nez v0, :cond_1

    .line 61
    .line 62
    :cond_0
    return v2

    .line 63
    :cond_1
    return v3
.end method

.method public final getInfoBanner()Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscriptionLegalText()Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTosMetadata()Lcom/facebook/aura/activation/data/HatchTosMetadata;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUpsellCell()Lcom/facebook/aura/activation/data/HatchUpsellCell;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 1
    .line 2
    invoke-static {v0}, LX/07F;->A02(Z)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 22
    .line 23
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v1, v0

    .line 28
    mul-int/lit8 v1, v1, 0x1f

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 31
    .line 32
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 40
    .line 41
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    add-int/2addr v1, v0

    .line 46
    return v1
.end method

.method public final isFetchingMetadata()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isFetchingMetadata:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isLoading()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
