.class public final Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;
.super LX/1EJ;
.source ""


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;Lcom/facebook/aura/user/provider/AuraViewerDataProvider;)V
    .locals 6

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    const-string v1, ""

    .line 13
    .line 14
    new-instance v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 15
    .line 16
    move-object v2, v1

    .line 17
    move v4, v3

    .line 18
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)V

    .line 19
    .line 20
    .line 21
    invoke-static {v0}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->uiState:LX/2J3;

    .line 32
    .line 33
    return-void
.end method

.method public static final synthetic access$confirmNameError(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Ljava/lang/String;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->confirmNameError(Ljava/lang/String;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getSubscriptionRepository$p(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;)Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getViewerDataProvider$p(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final confirmNameError(Ljava/lang/String;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-static {p1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-nez p0, :cond_0

    .line 7
    .line 8
    new-instance p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Server;

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Server;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-object p0

    .line 14
    :cond_0
    sget-object p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Generic;->INSTANCE:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Generic;

    .line 15
    .line 16
    return-object p0
.end method

.method private final withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 5

    .line 0
    move-object v1, p1

    .line 1
    iget-boolean v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 6
    .line 7
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 p0, 0x1

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :cond_0
    const/4 p0, 0x0

    .line 23
    :cond_1
    iget-object v2, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v3, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 26
    .line 27
    iget-boolean v4, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 28
    .line 29
    iget-object p1, p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 30
    .line 31
    invoke-virtual/range {v1 .. v6}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    return-object v0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onContinue()V
    .locals 10

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    check-cast v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 7
    .line 8
    iget-boolean v0, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 13
    .line 14
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    move-object v4, v1

    .line 19
    check-cast v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 20
    .line 21
    const/4 v9, 0x0

    .line 22
    const/4 v7, 0x1

    .line 23
    iget-object v5, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v6, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 26
    .line 27
    const/4 v8, 0x0

    .line 28
    invoke-virtual/range {v4 .. v9}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    new-instance v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;

    .line 47
    .line 48
    invoke-direct {v0, p0, v3, v9}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;-><init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/2M4;)V

    .line 49
    .line 50
    .line 51
    invoke-static {v1, v0, v2}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    return-void
.end method

.method public final onFirstNameChange(Ljava/lang/String;)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v4, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 6
    .line 7
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    move-object v3, v1

    .line 12
    check-cast v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 13
    .line 14
    const/4 v8, 0x0

    .line 15
    iget-object v5, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 16
    .line 17
    iget-boolean v6, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 18
    .line 19
    iget-boolean v7, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 20
    .line 21
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    return-void
.end method

.method public final onLastNameChange(Ljava/lang/String;)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v5, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 6
    .line 7
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    move-object v3, v1

    .line 12
    check-cast v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 13
    .line 14
    const/4 v8, 0x0

    .line 15
    iget-object v4, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 16
    .line 17
    iget-boolean v6, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 18
    .line 19
    iget-boolean v7, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 20
    .line 21
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    return-void
.end method
