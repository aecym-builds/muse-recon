.class public interface abstract Lcom/facebook/aura/activation/model/InviteCodeError;
.super Ljava/lang/Object;
.source ""
