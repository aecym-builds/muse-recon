.class public final Lcom/facebook/aura/activation/model/HatchActivationGateViewModel;
.super LX/1EJ;
.source ""


# instance fields
.field public final isGateRequired:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/user/provider/AuraViewerDataProvider;Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;)V
    .locals 5

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v4

    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iget-object v3, p1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->userData:LX/2J3;

    .line 8
    .line 9
    iget-object v2, p2, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;->isSetupRequired:LX/2J3;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    new-instance v0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;

    .line 13
    .line 14
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel$isGateRequired$1;-><init>(LX/2M4;)V

    .line 15
    .line 16
    .line 17
    invoke-static {v0, v3, v2}, LX/EXj;->A03(LX/JDQ;LX/2Lw;LX/2Lw;)LX/EUU;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, LX/IJu;->A02(LX/2Lw;)LX/2Lw;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    sget-object v1, LX/5Lz;->A00:LX/5Ly;

    .line 30
    .line 31
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-static {v0, v2, v3, v1}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iput-object v0, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel;->isGateRequired:LX/2J3;

    .line 40
    .line 41
    return-void
.end method


# virtual methods
.method public final isGateRequired()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchActivationGateViewModel;->isGateRequired:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onGateNavigated()V
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->onInAppRegate()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
