.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.HatchRedeemInviteCodeViewModel$onConfirmClick$2"
    f = "HatchRedeemInviteCodeViewModel.kt"
    l = {
        0x94
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $code:Ljava/lang/String;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->$code:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->$code:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;Ljava/lang/String;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->label:I

    .line 3
    .line 4
    const/4 v5, 0x0

    .line 5
    const-string v4, "HatchRedeemInviteCodeViewModel"

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    if-ne v0, v3, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    throw v0

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 22
    .line 23
    iget-object v2, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->$code:Ljava/lang/String;

    .line 26
    .line 27
    iput v3, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->label:I

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-virtual {v2, v1, v3, v0, p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->redeemInviteCode(Ljava/lang/String;ZZLX/2M4;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    if-ne p1, v6, :cond_2

    .line 35
    .line 36
    return-object v6

    .line 37
    :goto_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_2
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;

    .line 41
    .line 42
    goto :goto_1
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    :catch_0
    move-exception v1

    .line 44
    const-string v0, "Invite code redemption threw"

    .line 45
    .line 46
    invoke-static {v4, v0, v1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 47
    .line 48
    .line 49
    move-object p1, v5

    .line 50
    :goto_1
    if-nez p1, :cond_8

    .line 51
    .line 52
    sget-object v5, Lcom/facebook/aura/activation/model/InviteCodeError$Generic;->INSTANCE:Lcom/facebook/aura/activation/model/InviteCodeError$Generic;

    .line 53
    .line 54
    :goto_2
    check-cast v5, Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 55
    .line 56
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 57
    .line 58
    iget-object v7, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->_uiState:LX/2J2;

    .line 59
    .line 60
    :cond_4
    invoke-interface {v7}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    move-object v1, v6

    .line 65
    check-cast v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 66
    .line 67
    iget-object v3, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 68
    .line 69
    if-nez v5, :cond_5

    .line 70
    .line 71
    instance-of v0, v3, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 72
    .line 73
    if-eqz v0, :cond_5

    .line 74
    .line 75
    check-cast v3, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 76
    .line 77
    iget-object v0, v3, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 78
    .line 79
    new-instance v3, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;

    .line 80
    .line 81
    invoke-direct {v3, v0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;-><init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 82
    .line 83
    .line 84
    :cond_5
    iget-object v2, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 85
    .line 86
    const/4 v1, 0x0

    .line 87
    invoke-static {v2, v3}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 91
    .line 92
    invoke-direct {v0, v2, v1, v5, v3}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;-><init>(Ljava/lang/String;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;)V

    .line 93
    .line 94
    .line 95
    invoke-interface {v7, v6, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_4

    .line 100
    .line 101
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$onConfirmClick$2;->this$0:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;

    .line 102
    .line 103
    if-nez v5, :cond_7

    .line 104
    .line 105
    const-string v0, "success"

    .line 106
    .line 107
    :goto_3
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;->access$logRedemptionResult(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    if-nez v5, :cond_6

    .line 111
    .line 112
    const-string v0, "Invite code redeemed from settings"

    .line 113
    .line 114
    invoke-static {v4, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    :cond_6
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 118
    .line 119
    return-object v6

    .line 120
    :cond_7
    const-string v0, "error"

    .line 121
    .line 122
    goto :goto_3

    .line 123
    :cond_8
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;->success:Z

    .line 124
    .line 125
    if-nez v0, :cond_3

    .line 126
    .line 127
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$RedeemInviteCodeResult;->error:Ljava/lang/String;

    .line 128
    .line 129
    invoke-static {v0}, Lcom/facebook/aura/activation/repo/InviteCodeServerErrorKt;->parseInviteCodeServerErrorMessage(Ljava/lang/String;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    new-instance v5, Lcom/facebook/aura/activation/model/InviteCodeError$Invalid;

    .line 134
    .line 135
    invoke-direct {v5, v0}, Lcom/facebook/aura/activation/model/InviteCodeError$Invalid;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    goto :goto_2

    .line 139
    :catch_1
    move-exception v0

    .line 140
    throw v0
.end method
