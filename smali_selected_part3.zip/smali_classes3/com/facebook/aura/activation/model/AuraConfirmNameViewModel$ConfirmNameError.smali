.class public interface abstract Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;
.super Ljava/lang/Object;
.source ""
