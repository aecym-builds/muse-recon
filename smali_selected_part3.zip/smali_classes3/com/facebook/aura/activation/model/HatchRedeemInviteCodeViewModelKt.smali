.class public abstract Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchRedeemInviteCodeViewModel"
