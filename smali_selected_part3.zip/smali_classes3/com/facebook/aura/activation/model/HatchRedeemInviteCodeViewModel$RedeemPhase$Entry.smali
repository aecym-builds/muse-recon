.class public final Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;


# instance fields
.field public final copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

.field public final successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 9
    .line 10
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 11
    .line 12
    :cond_1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 16
    .line 17
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;-><init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;-><init>(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getCopy()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSuccessCopy()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
