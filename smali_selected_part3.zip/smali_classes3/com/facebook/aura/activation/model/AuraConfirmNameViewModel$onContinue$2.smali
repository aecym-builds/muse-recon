.class public final Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraConfirmNameViewModel$onContinue$2"
    f = "AuraConfirmNameViewModel.kt"
    l = {
        0x3d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->$state:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->$state:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;-><init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    if-ne v0, v3, :cond_6

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    check-cast p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$Success;->INSTANCE:Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$Success;

    .line 15
    .line 16
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 23
    .line 24
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;->markNameSatisfied()V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 30
    .line 31
    iget-object v1, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;->INSTANCE:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2$error$1;

    .line 34
    .line 35
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->atomicUpdate(LX/JDM;)V

    .line 36
    .line 37
    .line 38
    const/4 p1, 0x0

    .line 39
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 40
    .line 41
    iget-object v2, v3, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->_uiState:LX/2J2;

    .line 42
    .line 43
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    move-object v4, v1

    .line 48
    check-cast v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 49
    .line 50
    const/4 v7, 0x0

    .line 51
    iget-object v5, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 52
    .line 53
    iget-object v6, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 54
    .line 55
    iget-boolean p0, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 56
    .line 57
    invoke-virtual/range {v4 .. v9}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->copy(Ljava/lang/String;Ljava/lang/String;ZZLcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-static {v3, v0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->access$withContinueEnabled(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 72
    .line 73
    return-object v4

    .line 74
    :cond_2
    instance-of v0, p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$InvalidName;

    .line 75
    .line 76
    if-eqz v0, :cond_3

    .line 77
    .line 78
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 79
    .line 80
    check-cast p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$InvalidName;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$InvalidName;->detail:Ljava/lang/String;

    .line 83
    .line 84
    :goto_1
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->access$confirmNameError(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Ljava/lang/String;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    goto :goto_0

    .line 89
    :cond_3
    instance-of v0, p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$Failed;

    .line 90
    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 94
    .line 95
    check-cast p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$Failed;

    .line 96
    .line 97
    iget-object v0, p1, Lcom/facebook/aura/subscription/repo/SaveViewerNameResult$Failed;->detail:Ljava/lang/String;

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->this$0:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 104
    .line 105
    iget-object v2, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 106
    .line 107
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->$state:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 108
    .line 109
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 110
    .line 111
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->$state:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 116
    .line 117
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 118
    .line 119
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    iput v3, p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$onContinue$2;->label:I

    .line 124
    .line 125
    invoke-virtual {v2, v1, v0, p0}, Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;->saveViewerName(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    if-ne p1, v4, :cond_0

    .line 130
    .line 131
    return-object v4

    .line 132
    :cond_5
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    throw v0

    .line 137
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    throw v0
.end method
