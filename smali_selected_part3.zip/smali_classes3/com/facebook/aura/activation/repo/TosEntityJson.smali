.class public final Lcom/facebook/aura/activation/repo/TosEntityJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/TosEntityJson$Companion;


# instance fields
.field public final length:I

.field public final offset:I

.field public final url:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/TosEntityJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/TosEntityJson;->Companion:Lcom/facebook/aura/activation/repo/TosEntityJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    const-string v0, ""

    .line 805306370
    .line 805306371
    invoke-direct {p0, v1, v1, v0}, Lcom/facebook/aura/activation/repo/TosEntityJson;-><init>(IILjava/lang/String;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(IIILjava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const/4 v1, 0x0

    .line 536870918
    if-nez v0, :cond_1

    .line 536870919
    .line 536870920
    iput v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 536870921
    .line 536870922
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    if-nez v0, :cond_0

    .line 536870925
    .line 536870926
    iput v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 536870927
    .line 536870928
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_2

    .line 536870931
    .line 536870932
    const-string v0, ""

    .line 536870933
    .line 536870934
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 536870935
    .line 536870936
    return-void

    .line 536870937
    :cond_0
    iput p3, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 536870938
    .line 536870939
    goto :goto_1

    .line 536870940
    :cond_1
    iput p2, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 536870941
    .line 536870942
    goto :goto_0

    .line 536870943
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 536870944
    .line 536870945
    return-void
.end method

.method public constructor <init>(IILjava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(IILjava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p4, 0x1

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    const/4 p1, 0x0

    .line 268435461
    :cond_0
    invoke-static {p4, p2}, LX/603;->A02(II)I

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v1

    .line 268435465
    and-int/lit8 v0, p4, 0x4

    .line 268435466
    .line 268435467
    if-eqz v0, :cond_1

    .line 268435468
    .line 268435469
    const-string p3, ""

    .line 268435470
    .line 268435471
    :cond_1
    invoke-direct {p0, p1, v1, p3}, Lcom/facebook/aura/activation/repo/TosEntityJson;-><init>(IILjava/lang/String;)V

    .line 268435472
    .line 268435473
    .line 268435474
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/TosEntityJson;IILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/TosEntityJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget p2, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosEntityJson;->copy(IILjava/lang/String;)Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/TosEntityJson;LX/Da8;LX/Da5;)V
    .locals 3

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    if-nez v2, :cond_0

    .line 6
    .line 7
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 12
    .line 13
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 14
    .line 15
    .line 16
    :cond_1
    const/4 v1, 0x1

    .line 17
    if-nez v2, :cond_2

    .line 18
    .line 19
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 20
    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    :cond_2
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 24
    .line 25
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAO(LX/Da5;II)V

    .line 26
    .line 27
    .line 28
    :cond_3
    const/4 v1, 0x2

    .line 29
    if-nez v2, :cond_4

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_5

    .line 38
    .line 39
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 40
    .line 41
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 42
    .line 43
    .line 44
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 1
    .line 2
    return p0
.end method

.method public final component2()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(IILjava/lang/String;)Lcom/facebook/aura/activation/repo/TosEntityJson;
    .locals 0

    .line 0
    const/4 p0, 0x2

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosEntityJson;-><init>(IILjava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 17
    .line 18
    iget v0, p1, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    :cond_0
    return v2

    .line 33
    :cond_1
    return v3
.end method

.method public final getLength()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 1
    .line 2
    return p0
.end method

.method public final getOffset()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 1
    .line 2
    return p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 1
    .line 2
    mul-int/lit8 v1, v0, 0x1f

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 5
    .line 6
    add-int/2addr v1, v0

    .line 7
    mul-int/lit8 v1, v1, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0, v1}, LX/006;->A0L(Ljava/lang/String;I)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final toDomain()Lcom/facebook/aura/activation/data/HatchDisclosureEntity;
    .locals 4

    .line 0
    iget v3, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->offset:I

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->length:I

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosEntityJson;->url:Ljava/lang/String;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;-><init>(IILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
