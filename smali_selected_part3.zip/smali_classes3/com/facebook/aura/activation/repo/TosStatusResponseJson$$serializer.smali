.class public final synthetic Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/repo/TosStatusResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0xc

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.activation.repo.TosStatusResponseJson"

    .line 10
    .line 11
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v0, "has_accepted_tos"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "disclosure_text"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "disclosure_version"

    .line 27
    .line 28
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    const-string v0, "disclosure_entities"

    .line 32
    .line 33
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 34
    .line 35
    .line 36
    const-string v0, "disclosure_title"

    .line 37
    .line 38
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 39
    .line 40
    .line 41
    const-string v0, "disclosure_button_text"

    .line 42
    .line 43
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 44
    .line 45
    .line 46
    const-string v0, "disclosure_sections"

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 49
    .line 50
    .line 51
    const-string v0, "cvm_upsell_cell"

    .line 52
    .line 53
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 54
    .line 55
    .line 56
    const-string v0, "subscription_upsell_cell"

    .line 57
    .line 58
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 59
    .line 60
    .line 61
    const-string v0, "info_banner"

    .line 62
    .line 63
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 64
    .line 65
    .line 66
    const-string v0, "subscription_disclosure_text"

    .line 67
    .line 68
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 69
    .line 70
    .line 71
    const-string v0, "subscription_disclosure_entities"

    .line 72
    .line 73
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 74
    .line 75
    .line 76
    sput-object v2, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 77
    .line 78
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    sget-object v2, LX/DYz;->A00:LX/DYz;

    .line 3
    .line 4
    sget-object v3, LX/DYp;->A01:LX/DYp;

    .line 5
    .line 6
    invoke-static {v1}, LX/3Rq;->A1N([Lkotlin/Lazy;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v5

    .line 10
    const/4 v0, 0x6

    .line 11
    invoke-static {v1, v0}, LX/3Rp;->A1A([Lkotlin/Lazy;I)LX/DZ7;

    .line 12
    .line 13
    .line 14
    move-result-object v8

    .line 15
    sget-object v0, Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;

    .line 16
    .line 17
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 18
    .line 19
    .line 20
    move-result-object v9

    .line 21
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 22
    .line 23
    .line 24
    move-result-object v10

    .line 25
    sget-object v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;

    .line 26
    .line 27
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 28
    .line 29
    .line 30
    move-result-object v11

    .line 31
    const/16 v0, 0xb

    .line 32
    .line 33
    invoke-static {v1, v0}, LX/3Rp;->A1A([Lkotlin/Lazy;I)LX/DZ7;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    move-object v4, v3

    .line 38
    move-object v6, v3

    .line 39
    move-object v7, v3

    .line 40
    move-object v12, v3

    .line 41
    filled-new-array/range {v2 .. v13}, [LX/DZ7;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/TosStatusResponseJson;
    .locals 24

    .line 0
    const/4 v3, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v2}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    sget-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 13
    .line 14
    const/16 v11, 0xa

    .line 15
    .line 16
    const/16 v10, 0x9

    .line 17
    .line 18
    const/16 v9, 0x8

    .line 19
    .line 20
    const/4 v12, 0x0

    .line 21
    const/16 v8, 0xb

    .line 22
    .line 23
    const/16 v23, 0x0

    .line 24
    .line 25
    move-object/from16 v22, v23

    .line 26
    .line 27
    move-object/from16 v21, v23

    .line 28
    .line 29
    move-object/from16 v19, v23

    .line 30
    .line 31
    move-object/from16 p0, v23

    .line 32
    .line 33
    move-object/from16 v20, v23

    .line 34
    .line 35
    move-object/from16 v16, v23

    .line 36
    .line 37
    move-object/from16 v14, v23

    .line 38
    .line 39
    move-object v15, v14

    .line 40
    move-object/from16 v17, v14

    .line 41
    .line 42
    move-object/from16 v18, v14

    .line 43
    .line 44
    const/4 v13, 0x0

    .line 45
    const/4 v7, 0x3

    .line 46
    const/4 v6, 0x6

    .line 47
    :goto_0
    invoke-interface {v1, v2}, LX/Da7;->A8S(LX/Da5;)I

    .line 48
    .line 49
    .line 50
    move-result v4

    .line 51
    packed-switch v4, :pswitch_data_0

    .line 52
    .line 53
    .line 54
    invoke-static {v4}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    throw v0

    .line 59
    :pswitch_0
    invoke-static {v2, v1, v0, v8}, LX/3Rs;->A0j(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    or-int/lit16 v12, v12, 0x800

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :pswitch_1
    invoke-interface {v1, v2, v11}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v23

    .line 70
    or-int/lit16 v12, v12, 0x400

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :pswitch_2
    sget-object v4, Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;

    .line 74
    .line 75
    invoke-interface {v1, v4, v2, v10}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v22

    .line 79
    check-cast v22, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 80
    .line 81
    or-int/lit16 v12, v12, 0x200

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :pswitch_3
    sget-object v4, Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;

    .line 85
    .line 86
    invoke-interface {v1, v4, v2, v9}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v21

    .line 90
    check-cast v21, Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 91
    .line 92
    or-int/lit16 v12, v12, 0x100

    .line 93
    .line 94
    goto :goto_0

    .line 95
    :pswitch_4
    sget-object v5, Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;

    .line 96
    .line 97
    const/4 v4, 0x7

    .line 98
    invoke-interface {v1, v5, v2, v4}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v20

    .line 102
    check-cast v20, Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 103
    .line 104
    or-int/lit16 v12, v12, 0x80

    .line 105
    .line 106
    goto :goto_0

    .line 107
    :pswitch_5
    invoke-static {v2, v1, v0, v6}, LX/3Rs;->A0j(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 108
    .line 109
    .line 110
    move-result-object v19

    .line 111
    or-int/lit8 v12, v12, 0x40

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :pswitch_6
    const/4 v4, 0x5

    .line 115
    invoke-interface {v1, v2, v4}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v18

    .line 119
    or-int/lit8 v12, v12, 0x20

    .line 120
    .line 121
    goto :goto_0

    .line 122
    :pswitch_7
    const/4 v4, 0x4

    .line 123
    invoke-interface {v1, v2, v4}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v17

    .line 127
    or-int/lit8 v12, v12, 0x10

    .line 128
    .line 129
    goto :goto_0

    .line 130
    :pswitch_8
    invoke-static {v2, v1, v0, v7}, LX/3Rs;->A0G(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v16

    .line 134
    check-cast v16, Ljava/util/List;

    .line 135
    .line 136
    or-int/lit8 v12, v12, 0x8

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :pswitch_9
    invoke-static {v2, v1}, LX/603;->A0r(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v15

    .line 143
    or-int/lit8 v12, v12, 0x4

    .line 144
    .line 145
    goto :goto_0

    .line 146
    :pswitch_a
    invoke-static {v2, v1}, LX/3Rr;->A0o(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v14

    .line 150
    or-int/lit8 v12, v12, 0x2

    .line 151
    .line 152
    goto :goto_0

    .line 153
    :pswitch_b
    invoke-interface {v1, v2, v3}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 154
    .line 155
    .line 156
    move-result v13

    .line 157
    or-int/lit8 v12, v12, 0x1

    .line 158
    .line 159
    goto :goto_0

    .line 160
    :pswitch_c
    invoke-interface {v1, v2}, LX/Da7;->AAi(LX/Da5;)V

    .line 161
    .line 162
    .line 163
    const/16 p1, 0x0

    .line 164
    .line 165
    new-instance v11, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 166
    .line 167
    invoke-direct/range {v11 .. v25}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;-><init>(IZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;LX/5Xm;)V

    .line 168
    .line 169
    .line 170
    return-object v11

    .line 171
    nop

    .line 172
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/TosStatusResponseJson;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 268435460
    .line 268435461
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 268435462
    .line 268435463
    .line 268435464
    move-result-object v0

    .line 268435465
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/TosStatusResponseJson;LX/Da8;LX/Da5;)V

    .line 268435466
    .line 268435467
    .line 268435468
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/TosStatusResponseJson;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
