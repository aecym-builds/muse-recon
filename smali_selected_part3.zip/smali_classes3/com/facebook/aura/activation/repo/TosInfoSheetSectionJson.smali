.class public final Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson$Companion;


# instance fields
.field public final body:Ljava/lang/String;

.field public final body_entities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation
.end field

.field public final title:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->Companion:Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v2, v2, v0}, LX/3Rp;->A1X(Ljava/lang/Integer;Lkotlin/Lazy;Lkotlin/Lazy;Lkotlin/jvm/functions/Function0;)[Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const-string v1, ""

    .line 805306369
    .line 805306370
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306371
    .line 805306372
    invoke-direct {p0, v1, v1, v0}, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/util/List;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const-string v1, ""

    .line 536870918
    .line 536870919
    if-nez v0, :cond_1

    .line 536870920
    .line 536870921
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 536870922
    .line 536870923
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870924
    .line 536870925
    if-nez v0, :cond_0

    .line 536870926
    .line 536870927
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 536870928
    .line 536870929
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870930
    .line 536870931
    if-nez v0, :cond_2

    .line 536870932
    .line 536870933
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870934
    .line 536870935
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 536870936
    .line 536870937
    return-void

    .line 536870938
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 536870939
    .line 536870940
    goto :goto_1

    .line 536870941
    :cond_1
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 536870942
    .line 536870943
    goto :goto_0

    .line 536870944
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 536870945
    .line 536870946
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p4, 0x1

    .line 268435457
    .line 268435458
    const-string v1, ""

    .line 268435459
    .line 268435460
    if-eqz v0, :cond_0

    .line 268435461
    .line 268435462
    move-object p1, v1

    .line 268435463
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 268435464
    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    invoke-static {p3, p4}, LX/3Rr;->A0u(Ljava/util/List;I)Ljava/util/List;

    .line 268435469
    .line 268435470
    .line 268435471
    move-result-object v0

    .line 268435472
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 268435473
    .line 268435474
    .line 268435475
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    const-string v2, ""

    .line 8
    .line 9
    if-nez v3, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    const/4 v1, 0x1

    .line 25
    if-nez v3, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_3

    .line 34
    .line 35
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 36
    .line 37
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_3
    const/4 v2, 0x2

    .line 41
    if-nez v3, :cond_4

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 44
    .line 45
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-nez v0, :cond_5

    .line 50
    .line 51
    :cond_4
    invoke-static {v4, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;)",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getBody()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBody_entities()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
