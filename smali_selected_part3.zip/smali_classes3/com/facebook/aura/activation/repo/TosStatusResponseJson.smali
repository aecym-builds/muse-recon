.class public final Lcom/facebook/aura/activation/repo/TosStatusResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion;


# instance fields
.field public final cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

.field public final disclosure_button_text:Ljava/lang/String;

.field public final disclosure_entities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation
.end field

.field public final disclosure_sections:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosSectionJson;",
            ">;"
        }
    .end annotation
.end field

.field public final disclosure_text:Ljava/lang/String;

.field public final disclosure_title:Ljava/lang/String;

.field public final disclosure_version:Ljava/lang/String;

.field public final has_accepted_tos:Z

.field public final info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

.field public final subscription_disclosure_entities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation
.end field

.field public final subscription_disclosure_text:Ljava/lang/String;

.field public final subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;


# direct methods
.method public static constructor <clinit>()V
    .locals 14

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->Companion:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v5

    .line 16
    sget-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$2;->INSTANCE:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$2;

    .line 17
    .line 18
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 19
    .line 20
    .line 21
    move-result-object v8

    .line 22
    sget-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$3;->INSTANCE:Lcom/facebook/aura/activation/repo/TosStatusResponseJson$Companion$$childSerializers$3;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 25
    .line 26
    .line 27
    move-result-object v13

    .line 28
    move-object v3, v2

    .line 29
    move-object v4, v2

    .line 30
    move-object v6, v2

    .line 31
    move-object v7, v2

    .line 32
    move-object v9, v2

    .line 33
    move-object v10, v2

    .line 34
    move-object v11, v2

    .line 35
    move-object v12, v2

    .line 36
    filled-new-array/range {v2 .. v13}, [Lkotlin/Lazy;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sput-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>()V
    .locals 12

    .line 805306368
    const/4 v8, 0x0

    .line 805306369
    const/4 v1, 0x0

    .line 805306370
    const-string v2, ""

    .line 805306371
    .line 805306372
    sget-object v4, LX/0wV;->A00:LX/0wV;

    .line 805306373
    .line 805306374
    move-object v0, p0

    .line 805306375
    move-object v3, v2

    .line 805306376
    move-object v5, v2

    .line 805306377
    move-object v6, v2

    .line 805306378
    move-object v7, v4

    .line 805306379
    move-object v9, v8

    .line 805306380
    move-object v10, v8

    .line 805306381
    move-object v11, v2

    .line 805306382
    move-object p0, v4

    .line 805306383
    invoke-direct/range {v0 .. v12}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)V

    .line 805306384
    .line 805306385
    .line 805306386
    return-void
.end method

.method public synthetic constructor <init>(IZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;LX/5Xm;)V
    .locals 3

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    if-nez v0, :cond_0

    .line 536870918
    .line 536870919
    const/4 p2, 0x0

    .line 536870920
    :cond_0
    iput-boolean p2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 536870921
    .line 536870922
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    const-string v1, ""

    .line 536870925
    .line 536870926
    if-nez v0, :cond_b

    .line 536870927
    .line 536870928
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 536870929
    .line 536870930
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 536870931
    .line 536870932
    if-nez v0, :cond_a

    .line 536870933
    .line 536870934
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 536870935
    .line 536870936
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 536870937
    .line 536870938
    if-nez v0, :cond_9

    .line 536870939
    .line 536870940
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870941
    .line 536870942
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 536870943
    .line 536870944
    :goto_2
    and-int/lit8 v0, p1, 0x10

    .line 536870945
    .line 536870946
    if-nez v0, :cond_8

    .line 536870947
    .line 536870948
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 536870949
    .line 536870950
    :goto_3
    and-int/lit8 v0, p1, 0x20

    .line 536870951
    .line 536870952
    if-nez v0, :cond_7

    .line 536870953
    .line 536870954
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 536870955
    .line 536870956
    :goto_4
    and-int/lit8 v0, p1, 0x40

    .line 536870957
    .line 536870958
    if-nez v0, :cond_6

    .line 536870959
    .line 536870960
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870961
    .line 536870962
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 536870963
    .line 536870964
    :goto_5
    and-int/lit16 v0, p1, 0x80

    .line 536870965
    .line 536870966
    const/4 v2, 0x0

    .line 536870967
    if-nez v0, :cond_5

    .line 536870968
    .line 536870969
    iput-object v2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 536870970
    .line 536870971
    :goto_6
    and-int/lit16 v0, p1, 0x100

    .line 536870972
    .line 536870973
    if-nez v0, :cond_4

    .line 536870974
    .line 536870975
    iput-object v2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 536870976
    .line 536870977
    :goto_7
    and-int/lit16 v0, p1, 0x200

    .line 536870978
    .line 536870979
    if-nez v0, :cond_3

    .line 536870980
    .line 536870981
    iput-object v2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 536870982
    .line 536870983
    :goto_8
    and-int/lit16 v0, p1, 0x400

    .line 536870984
    .line 536870985
    if-nez v0, :cond_2

    .line 536870986
    .line 536870987
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 536870988
    .line 536870989
    :goto_9
    and-int/lit16 v0, p1, 0x800

    .line 536870990
    .line 536870991
    if-nez v0, :cond_1

    .line 536870992
    .line 536870993
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870994
    .line 536870995
    :goto_a
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 536870996
    .line 536870997
    return-void

    .line 536870998
    :cond_1
    move-object/from16 v0, p13

    .line 536870999
    .line 536871000
    goto :goto_a

    .line 536871001
    :cond_2
    iput-object p12, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 536871002
    .line 536871003
    goto :goto_9

    .line 536871004
    :cond_3
    iput-object p11, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 536871005
    .line 536871006
    goto :goto_8

    .line 536871007
    :cond_4
    iput-object p10, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 536871008
    .line 536871009
    goto :goto_7

    .line 536871010
    :cond_5
    iput-object p9, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 536871011
    .line 536871012
    goto :goto_6

    .line 536871013
    :cond_6
    iput-object p8, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 536871014
    .line 536871015
    goto :goto_5

    .line 536871016
    :cond_7
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 536871017
    .line 536871018
    goto :goto_4

    .line 536871019
    :cond_8
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 536871020
    .line 536871021
    goto :goto_3

    .line 536871022
    :cond_9
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 536871023
    .line 536871024
    goto :goto_2

    .line 536871025
    :cond_a
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 536871026
    .line 536871027
    goto :goto_1

    .line 536871028
    :cond_b
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 536871029
    .line 536871030
    goto :goto_0
.end method

.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosSectionJson;",
            ">;",
            "Lcom/facebook/aura/activation/repo/TosUpsellCellJson;",
            "Lcom/facebook/aura/activation/repo/TosUpsellCellJson;",
            "Lcom/facebook/aura/activation/repo/TosInfoBannerJson;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, p3, p4, p5, v0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    const/16 v0, 0xa

    .line 8
    .line 9
    invoke-static {p11, v0, p12}, LX/003;->A15(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-boolean p1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 16
    .line 17
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 22
    .line 23
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 24
    .line 25
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 26
    .line 27
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 28
    .line 29
    iput-object p8, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 30
    .line 31
    iput-object p9, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 32
    .line 33
    iput-object p10, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 34
    .line 35
    iput-object p11, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 36
    .line 37
    iput-object p12, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 38
    .line 39
    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;ILX/04f;)V
    .locals 14

    .line 268435456
    move-object/from16 v3, p2

    .line 268435457
    .line 268435458
    move-object/from16 v4, p3

    .line 268435459
    .line 268435460
    move-object/from16 v6, p5

    .line 268435461
    .line 268435462
    move-object/from16 v7, p6

    .line 268435463
    .line 268435464
    move-object/from16 v9, p8

    .line 268435465
    .line 268435466
    move-object/from16 v10, p9

    .line 268435467
    .line 268435468
    move/from16 v1, p13

    .line 268435469
    .line 268435470
    move-object/from16 v5, p4

    .line 268435471
    .line 268435472
    move-object/from16 v8, p7

    .line 268435473
    .line 268435474
    move-object/from16 v13, p12

    .line 268435475
    .line 268435476
    invoke-static {v1, p1}, LX/002;->A1U(IZ)Z

    .line 268435477
    .line 268435478
    .line 268435479
    move-result v2

    .line 268435480
    and-int/lit8 v0, p13, 0x2

    .line 268435481
    .line 268435482
    const-string v12, ""

    .line 268435483
    .line 268435484
    if-eqz v0, :cond_0

    .line 268435485
    .line 268435486
    move-object v3, v12

    .line 268435487
    :cond_0
    and-int/lit8 v0, p13, 0x4

    .line 268435488
    .line 268435489
    if-eqz v0, :cond_1

    .line 268435490
    .line 268435491
    move-object v4, v12

    .line 268435492
    :cond_1
    and-int/lit8 v0, p13, 0x8

    .line 268435493
    .line 268435494
    if-eqz v0, :cond_2

    .line 268435495
    .line 268435496
    sget-object v5, LX/0wV;->A00:LX/0wV;

    .line 268435497
    .line 268435498
    :cond_2
    and-int/lit8 v0, p13, 0x10

    .line 268435499
    .line 268435500
    if-eqz v0, :cond_3

    .line 268435501
    .line 268435502
    move-object v6, v12

    .line 268435503
    :cond_3
    and-int/lit8 v0, p13, 0x20

    .line 268435504
    .line 268435505
    if-eqz v0, :cond_4

    .line 268435506
    .line 268435507
    move-object v7, v12

    .line 268435508
    :cond_4
    and-int/lit8 v0, p13, 0x40

    .line 268435509
    .line 268435510
    if-eqz v0, :cond_5

    .line 268435511
    .line 268435512
    sget-object v8, LX/0wV;->A00:LX/0wV;

    .line 268435513
    .line 268435514
    :cond_5
    and-int/lit16 v0, v1, 0x80

    .line 268435515
    .line 268435516
    const/4 v11, 0x0

    .line 268435517
    if-eqz v0, :cond_6

    .line 268435518
    .line 268435519
    move-object v9, v11

    .line 268435520
    :cond_6
    and-int/lit16 v0, v1, 0x100

    .line 268435521
    .line 268435522
    if-eqz v0, :cond_7

    .line 268435523
    .line 268435524
    move-object v10, v11

    .line 268435525
    :cond_7
    and-int/lit16 v0, v1, 0x200

    .line 268435526
    .line 268435527
    if-nez v0, :cond_8

    .line 268435528
    .line 268435529
    move-object/from16 v11, p10

    .line 268435530
    .line 268435531
    :cond_8
    and-int/lit16 v0, v1, 0x400

    .line 268435532
    .line 268435533
    if-nez v0, :cond_9

    .line 268435534
    .line 268435535
    move-object/from16 v12, p11

    .line 268435536
    .line 268435537
    :cond_9
    and-int/lit16 v0, v1, 0x800

    .line 268435538
    .line 268435539
    if-eqz v0, :cond_a

    .line 268435540
    .line 268435541
    sget-object v13, LX/0wV;->A00:LX/0wV;

    .line 268435542
    .line 268435543
    :cond_a
    move-object v1, p0

    .line 268435544
    invoke-direct/range {v1 .. v13}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)V

    .line 268435545
    .line 268435546
    .line 268435547
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/TosStatusResponseJson;ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/TosStatusResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p13, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p13, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p13, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p13, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p13, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p13, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p13, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p13, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p13, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 53
    .line 54
    :cond_8
    and-int/lit16 v0, p13, 0x200

    .line 55
    .line 56
    if-eqz v0, :cond_9

    .line 57
    .line 58
    iget-object p10, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 59
    .line 60
    :cond_9
    and-int/lit16 v0, p13, 0x400

    .line 61
    .line 62
    if-eqz v0, :cond_a

    .line 63
    .line 64
    iget-object p11, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 65
    .line 66
    :cond_a
    and-int/lit16 v0, p13, 0x800

    .line 67
    .line 68
    if-eqz v0, :cond_b

    .line 69
    .line 70
    iget-object p12, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 71
    .line 72
    :cond_b
    invoke-virtual/range {p0 .. p12}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->copy(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/TosStatusResponseJson;LX/Da8;LX/Da5;)V
    .locals 6

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v5

    .line 7
    if-nez v5, :cond_0

    .line 8
    .line 9
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 14
    .line 15
    invoke-interface {p1, p2, v2, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v3, 0x1

    .line 19
    const-string v2, ""

    .line 20
    .line 21
    if-nez v5, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, p2, v3}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    :cond_3
    const/4 v3, 0x2

    .line 37
    if-nez v5, :cond_4

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_5

    .line 46
    .line 47
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 48
    .line 49
    invoke-interface {p1, v0, p2, v3}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 50
    .line 51
    .line 52
    :cond_5
    const/4 v4, 0x3

    .line 53
    if-nez v5, :cond_6

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 56
    .line 57
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-nez v0, :cond_7

    .line 62
    .line 63
    :cond_6
    invoke-static {v1, v4}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {p1, v0, v3, p2, v4}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 70
    .line 71
    .line 72
    :cond_7
    const/4 v3, 0x4

    .line 73
    if-nez v5, :cond_8

    .line 74
    .line 75
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 76
    .line 77
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_9

    .line 82
    .line 83
    :cond_8
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 84
    .line 85
    invoke-interface {p1, v0, p2, v3}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 86
    .line 87
    .line 88
    :cond_9
    const/4 v3, 0x5

    .line 89
    if-nez v5, :cond_a

    .line 90
    .line 91
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 92
    .line 93
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-nez v0, :cond_b

    .line 98
    .line 99
    :cond_a
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 100
    .line 101
    invoke-interface {p1, v0, p2, v3}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 102
    .line 103
    .line 104
    :cond_b
    const/4 v4, 0x6

    .line 105
    if-nez v5, :cond_c

    .line 106
    .line 107
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 108
    .line 109
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-nez v0, :cond_d

    .line 114
    .line 115
    :cond_c
    invoke-static {v1, v4}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 120
    .line 121
    invoke-interface {p1, v0, v3, p2, v4}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 122
    .line 123
    .line 124
    :cond_d
    const/4 v4, 0x7

    .line 125
    if-nez v5, :cond_e

    .line 126
    .line 127
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 128
    .line 129
    if-eqz v0, :cond_f

    .line 130
    .line 131
    :cond_e
    sget-object v3, Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;

    .line 132
    .line 133
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 134
    .line 135
    invoke-interface {p1, v0, v3, p2, v4}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 136
    .line 137
    .line 138
    :cond_f
    const/16 v4, 0x8

    .line 139
    .line 140
    if-nez v5, :cond_10

    .line 141
    .line 142
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 143
    .line 144
    if-eqz v0, :cond_11

    .line 145
    .line 146
    :cond_10
    sget-object v3, Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosUpsellCellJson$$serializer;

    .line 147
    .line 148
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 149
    .line 150
    invoke-interface {p1, v0, v3, p2, v4}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 151
    .line 152
    .line 153
    :cond_11
    const/16 v4, 0x9

    .line 154
    .line 155
    if-nez v5, :cond_12

    .line 156
    .line 157
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 158
    .line 159
    if-eqz v0, :cond_13

    .line 160
    .line 161
    :cond_12
    sget-object v3, Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$$serializer;

    .line 162
    .line 163
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 164
    .line 165
    invoke-interface {p1, v0, v3, p2, v4}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 166
    .line 167
    .line 168
    :cond_13
    const/16 v3, 0xa

    .line 169
    .line 170
    if-nez v5, :cond_14

    .line 171
    .line 172
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 173
    .line 174
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    if-nez v0, :cond_15

    .line 179
    .line 180
    :cond_14
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 181
    .line 182
    invoke-interface {p1, v0, p2, v3}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 183
    .line 184
    .line 185
    :cond_15
    const/16 v2, 0xb

    .line 186
    .line 187
    if-nez v5, :cond_16

    .line 188
    .line 189
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 190
    .line 191
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-nez v0, :cond_17

    .line 196
    .line 197
    :cond_16
    invoke-static {v1, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 202
    .line 203
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 204
    .line 205
    .line 206
    :cond_17
    return-void
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component10()Lcom/facebook/aura/activation/repo/TosInfoBannerJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component12()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosSectionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Lcom/facebook/aura/activation/repo/TosUpsellCellJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Lcom/facebook/aura/activation/repo/TosUpsellCellJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/repo/TosStatusResponseJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosSectionJson;",
            ">;",
            "Lcom/facebook/aura/activation/repo/TosUpsellCellJson;",
            "Lcom/facebook/aura/activation/repo/TosUpsellCellJson;",
            "Lcom/facebook/aura/activation/repo/TosInfoBannerJson;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;)",
            "Lcom/facebook/aura/activation/repo/TosStatusResponseJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p3, p4, p5, p0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    const/16 p0, 0xa

    .line 8
    .line 9
    invoke-static {p11, p0, p12}, LX/003;->A15(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    new-instance p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 13
    .line 14
    invoke-direct/range {p0 .. p12}, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;-><init>(ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosUpsellCellJson;Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_0

    .line 75
    .line 76
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 77
    .line 78
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 79
    .line 80
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_0

    .line 85
    .line 86
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 87
    .line 88
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 89
    .line 90
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_0

    .line 95
    .line 96
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 97
    .line 98
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 99
    .line 100
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_0

    .line 105
    .line 106
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 107
    .line 108
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 109
    .line 110
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    if-eqz v0, :cond_0

    .line 115
    .line 116
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 117
    .line 118
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 119
    .line 120
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    if-nez v0, :cond_1

    .line 125
    .line 126
    :cond_0
    return v2

    .line 127
    :cond_1
    return v3
.end method

.method public final getCvm_upsell_cell()Lcom/facebook/aura/activation/repo/TosUpsellCellJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_button_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_entities()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_sections()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosSectionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_title()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisclosure_version()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHas_accepted_tos()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getInfo_banner()Lcom/facebook/aura/activation/repo/TosInfoBannerJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscription_disclosure_entities()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosEntityJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscription_disclosure_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubscription_upsell_cell()Lcom/facebook/aura/activation/repo/TosUpsellCellJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->has_accepted_tos:Z

    .line 1
    .line 2
    invoke-static {v0}, LX/07F;->A02(Z)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_text:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_version:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_entities:Ljava/util/List;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_title:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_button_text:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->disclosure_sections:Ljava/util/List;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->cvm_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 43
    .line 44
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    mul-int/lit8 v1, v1, 0x1f

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_upsell_cell:Lcom/facebook/aura/activation/repo/TosUpsellCellJson;

    .line 52
    .line 53
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    add-int/2addr v1, v0

    .line 58
    mul-int/lit8 v1, v1, 0x1f

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->info_banner:Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 61
    .line 62
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    add-int/2addr v1, v0

    .line 67
    mul-int/lit8 v1, v1, 0x1f

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_text:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosStatusResponseJson;->subscription_disclosure_entities:Ljava/util/List;

    .line 76
    .line 77
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
