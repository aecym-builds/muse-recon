.class public final Lcom/facebook/aura/activation/repo/TosInfoBannerJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$Companion;


# instance fields
.field public final sheet_button_text:Ljava/lang/String;

.field public final sheet_sections:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;",
            ">;"
        }
    .end annotation
.end field

.field public final text:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->Companion:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$Companion;

    .line 6
    .line 7
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/repo/TosInfoBannerJson$Companion$$childSerializers$1;

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/3Rs;->A1X(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)[Lkotlin/Lazy;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->$childSerializers:[Lkotlin/Lazy;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const-string v1, ""

    .line 805306369
    .line 805306370
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306371
    .line 805306372
    invoke-direct {p0, v1, v0, v1}, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const-string v1, ""

    .line 536870918
    .line 536870919
    if-nez v0, :cond_1

    .line 536870920
    .line 536870921
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 536870922
    .line 536870923
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870924
    .line 536870925
    if-nez v0, :cond_0

    .line 536870926
    .line 536870927
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870928
    .line 536870929
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 536870930
    .line 536870931
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870932
    .line 536870933
    if-nez v0, :cond_2

    .line 536870934
    .line 536870935
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 536870936
    .line 536870937
    return-void

    .line 536870938
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 536870939
    .line 536870940
    goto :goto_1

    .line 536870941
    :cond_1
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 536870942
    .line 536870943
    goto :goto_0

    .line 536870944
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 536870945
    .line 536870946
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;ILX/04f;)V
    .locals 3

    .line 268435456
    and-int/lit8 v0, p4, 0x1

    .line 268435457
    .line 268435458
    const-string v2, ""

    .line 268435459
    .line 268435460
    if-eqz v0, :cond_0

    .line 268435461
    .line 268435462
    move-object p1, v2

    .line 268435463
    :cond_0
    invoke-static {p2, p4}, LX/3Rr;->A0t(Ljava/util/List;I)Ljava/util/List;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object v1

    .line 268435467
    and-int/lit8 v0, p4, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_1

    .line 268435470
    .line 268435471
    move-object p3, v2

    .line 268435472
    :cond_1
    invoke-direct {p0, p1, v1, p3}, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 268435473
    .line 268435474
    .line 268435475
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/TosInfoBannerJson;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/TosInfoBannerJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->copy(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/TosInfoBannerJson;LX/Da8;LX/Da5;)V
    .locals 6

    .line 0
    sget-object v5, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    const-string v3, ""

    .line 8
    .line 9
    if-nez v4, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    const/4 v2, 0x1

    .line 25
    if-nez v4, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 28
    .line 29
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_3

    .line 34
    .line 35
    :cond_2
    invoke-static {v5, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 40
    .line 41
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 42
    .line 43
    .line 44
    :cond_3
    const/4 v1, 0x2

    .line 45
    if-nez v4, :cond_4

    .line 46
    .line 47
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 48
    .line 49
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_5

    .line 54
    .line 55
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/TosInfoBannerJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/activation/repo/TosInfoBannerJson;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getSheet_button_text()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSheet_sections()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/006;->A0L(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final toDomain()Lcom/facebook/aura/activation/data/HatchInfoBanner;
    .locals 7

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_sections:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    move-object v1, v2

    .line 21
    check-cast v1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 22
    .line 23
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    iget-object v0, v1, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v0, v2, v4}, LX/3Rs;->A15(Ljava/lang/CharSequence;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    invoke-static {v4}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_3

    .line 50
    .line 51
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;

    .line 56
    .line 57
    iget-object v5, v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->title:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v4, v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v0, v0, Lcom/facebook/aura/activation/repo/TosInfoSheetSectionJson;->body_entities:Ljava/util/List;

    .line 62
    .line 63
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_2

    .line 76
    .line 77
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, Lcom/facebook/aura/activation/repo/TosEntityJson;

    .line 82
    .line 83
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/TosEntityJson;->toDomain()Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    goto :goto_2

    .line 91
    :cond_2
    new-instance v1, Lcom/facebook/aura/activation/data/HatchDisclosureText;

    .line 92
    .line 93
    invoke-direct {v1, v4, v2}, Lcom/facebook/aura/activation/data/HatchDisclosureText;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 94
    .line 95
    .line 96
    new-instance v0, Lcom/facebook/aura/activation/data/HatchInfoSheetSection;

    .line 97
    .line 98
    invoke-direct {v0, v5, v1}, Lcom/facebook/aura/activation/data/HatchInfoSheetSection;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/data/HatchDisclosureText;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 106
    .line 107
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-nez v0, :cond_4

    .line 112
    .line 113
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 114
    .line 115
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-nez v0, :cond_4

    .line 120
    .line 121
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-nez v0, :cond_4

    .line 126
    .line 127
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->text:Ljava/lang/String;

    .line 128
    .line 129
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/TosInfoBannerJson;->sheet_button_text:Ljava/lang/String;

    .line 130
    .line 131
    new-instance v2, Lcom/facebook/aura/activation/data/HatchInfoBanner;

    .line 132
    .line 133
    invoke-direct {v2, v1, v3, v0}, Lcom/facebook/aura/activation/data/HatchInfoBanner;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    return-object v2

    .line 137
    :cond_4
    const/4 v2, 0x0

    .line 138
    return-object v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
