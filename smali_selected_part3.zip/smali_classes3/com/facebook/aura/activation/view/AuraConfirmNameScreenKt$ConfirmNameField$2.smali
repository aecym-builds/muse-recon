.class public final Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $contentType:LX/0PV;

.field public final synthetic $enabled:Z

.field public final synthetic $imeAction:I

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $placeholderText:Ljava/lang/String;

.field public final synthetic $value:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "LX/0PV;",
            "IZ",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$value:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$onChange:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$placeholderText:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$contentType:LX/0PV;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$imeAction:I

    .line 9
    .line 10
    iput-boolean p6, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$enabled:Z

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$modifier:LX/3C1;

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$$changed:I

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$$default:I

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$value:Ljava/lang/String;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$onChange:LX/JDM;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$placeholderText:Ljava/lang/String;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$contentType:LX/0PV;

    .line 268435463
    .line 268435464
    iget v5, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$imeAction:I

    .line 268435465
    .line 268435466
    iget-boolean v6, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$enabled:Z

    .line 268435467
    .line 268435468
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$modifier:LX/3C1;

    .line 268435469
    .line 268435470
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$$changed:I

    .line 268435471
    .line 268435472
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v9

    .line 268435476
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;->$$default:I

    .line 268435477
    .line 268435478
    move-object v8, p1

    .line 268435479
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V

    .line 268435480
    .line 268435481
    .line 268435482
    return-void
.end method
