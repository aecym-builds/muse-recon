.class public final Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/header/api/ConversationHeaderEndActionContributor;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;

.field public static final priority:Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;->INSTANCE:Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;->INVITE_FRIENDS:Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;

    .line 8
    .line 9
    sput-object v0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;->priority:Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberAction$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method


# virtual methods
.method public getPriority()Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction;->priority:Lcom/facebook/aura/header/api/ConversationHeaderEndActionPriority;

    .line 1
    .line 2
    return-object p0
.end method

.method public rememberAction(Lcom/facebook/aura/header/api/ConversationHeaderContext;LX/2d4;I)Lcom/facebook/aura/header/api/HeaderAction;
    .locals 15

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v1, p1

    .line 2
    .line 3
    invoke-static {v1, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const v0, 0x75b144da

    .line 7
    .line 8
    .line 9
    move-object/from16 v2, p2

    .line 10
    .line 11
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2}, LX/602;->A0S(LX/2d4;)LX/AHE;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    iget-object v0, v1, Lcom/facebook/aura/header/api/ConversationHeaderContext;->threadId:Ljava/lang/String;

    .line 19
    .line 20
    if-nez v0, :cond_4

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/utils/HatchUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchUtils;

    .line 23
    .line 24
    invoke-virtual {v0, v5}, Lcom/facebook/aura/utils/HatchUtils;->isInviteFriendsAvailable(LX/AHE;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_4

    .line 29
    .line 30
    invoke-static {v2}, LX/3Rp;->A06(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-interface {v2, v5}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    if-nez v0, :cond_0

    .line 43
    .line 44
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 45
    .line 46
    if-ne v1, v0, :cond_1

    .line 47
    .line 48
    :cond_0
    sget-object v0, Lcom/facebook/aura/invite/api/InviteBadges;->INSTANCE:Lcom/facebook/aura/invite/api/InviteBadges;

    .line 49
    .line 50
    invoke-virtual {v0, v5}, Lcom/facebook/aura/invite/api/InviteBadges;->hasUnseenInviteRedemptions(LX/AHE;)LX/2J3;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-interface {v2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_1
    check-cast v1, LX/2J3;

    .line 58
    .line 59
    const/4 v14, 0x0

    .line 60
    invoke-static {v2, v1, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    invoke-static {v3}, LX/16A;->A0C(LX/16A;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v2, v5, v4}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    invoke-interface {v2, v0}, LX/2d4;->A6A(Z)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    or-int/2addr v0, v1

    .line 77
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    if-nez v0, :cond_2

    .line 82
    .line 83
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 84
    .line 85
    if-ne v7, v0, :cond_3

    .line 86
    .line 87
    :cond_2
    sget-object v8, Lcom/facebook/aura/activation/view/InviteFriendsSlot;->INSTANCE:Lcom/facebook/aura/activation/view/InviteFriendsSlot;

    .line 88
    .line 89
    const v1, 0x7f1204bc

    .line 90
    .line 91
    .line 92
    const v0, 0x7f080198

    .line 93
    .line 94
    .line 95
    const/4 v13, 0x1

    .line 96
    new-instance v9, Lcom/facebook/aura/header/api/HeaderActionIcon;

    .line 97
    .line 98
    invoke-direct {v9, v0, v1, v6, v13}, Lcom/facebook/aura/header/api/HeaderActionIcon;-><init>(IIZZ)V

    .line 99
    .line 100
    .line 101
    new-instance v11, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;

    .line 102
    .line 103
    invoke-direct {v11, v5, v4}, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;-><init>(LX/AHE;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object p2

    .line 110
    invoke-static {v3}, LX/16A;->A0C(LX/16A;)Z

    .line 111
    .line 112
    .line 113
    move-result p3

    .line 114
    const-string v10, "hatch-invite-friends-button"

    .line 115
    .line 116
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 117
    .line 118
    new-instance v7, Lcom/facebook/aura/header/api/HeaderAction;

    .line 119
    .line 120
    move-object p0, v14

    .line 121
    move-object/from16 p1, v14

    .line 122
    .line 123
    invoke-direct/range {v7 .. v18}, Lcom/facebook/aura/header/api/HeaderAction;-><init>(Ljava/lang/Object;Lcom/facebook/aura/header/api/HeaderActionIcon;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/JDQ;LX/JDO;LX/JDM;Ljava/lang/Integer;Z)V

    .line 124
    .line 125
    .line 126
    invoke-interface {v2, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    :cond_3
    check-cast v7, Lcom/facebook/aura/header/api/HeaderAction;

    .line 130
    .line 131
    invoke-static {v2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    return-object v7

    .line 135
    :cond_4
    invoke-static {v2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    const/4 v7, 0x0

    .line 139
    return-object v7
.end method
