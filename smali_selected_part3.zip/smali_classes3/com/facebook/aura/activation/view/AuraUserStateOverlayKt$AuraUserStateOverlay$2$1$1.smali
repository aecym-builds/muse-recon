.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/3CH;",
        "LX/2qg;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offsetX$delegate:LX/2ss;

.field public final synthetic $offsetY$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;LX/2ss;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;->$offsetX$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;->$offsetY$delegate:LX/2ss;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/3CH;

    .line 1
    .line 2
    check-cast p2, LX/2qg;

    .line 3
    .line 4
    iget-wide v0, p2, LX/2qg;->A00:J

    .line 5
    .line 6
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;->invoke-Uv8p0NA(LX/3CH;J)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke-Uv8p0NA(LX/3CH;J)V
    .locals 3

    .line 0
    invoke-static {p1}, LX/603;->A19(LX/3CH;)V

    .line 1
    .line 2
    .line 3
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;->$offsetX$delegate:LX/2ss;

    .line 4
    .line 5
    invoke-interface {v2}, LX/2ss;->AFu()F

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-static {p2, p3}, LX/004;->A03(J)F

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    add-float/2addr v1, v0

    .line 14
    invoke-interface {v2, v1}, LX/2ss;->Adw(F)V

    .line 15
    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;->$offsetY$delegate:LX/2ss;

    .line 18
    .line 19
    invoke-interface {v2}, LX/2ss;->AFu()F

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-static {p2, p3}, LX/004;->A02(J)F

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-float/2addr v1, v0

    .line 28
    invoke-interface {v2, v1}, LX/2ss;->Adw(F)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
