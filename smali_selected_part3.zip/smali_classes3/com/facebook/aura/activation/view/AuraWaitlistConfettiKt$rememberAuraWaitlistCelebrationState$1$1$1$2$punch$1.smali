.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1"
    f = "AuraWaitlistConfetti.kt"
    l = {
        0xc1
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v5, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v6

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 19
    .line 20
    iget-object v4, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->ctaScale:LX/Dvf;

    .line 21
    .line 22
    const v0, 0x3f85c28f    # 1.045f

    .line 23
    .line 24
    .line 25
    invoke-static {v0}, LX/001;->A0o(F)Ljava/lang/Float;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    const/4 v2, 0x0

    .line 30
    const v1, 0x3f147ae1    # 0.58f

    .line 31
    .line 32
    .line 33
    const/high16 v0, 0x43c80000    # 400.0f

    .line 34
    .line 35
    invoke-static {v2, v1, v0}, LX/001;->A0R(Ljava/lang/Object;FF)LX/ELU;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iput v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;->label:I

    .line 40
    .line 41
    invoke-static {v4, v0, v3, p0, v2}, LX/002;->A0s(LX/Dvf;LX/DwJ;Ljava/lang/Object;LX/2M4;LX/JDM;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-ne v0, v6, :cond_0

    .line 46
    .line 47
    return-object v6

    .line 48
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0
.end method
