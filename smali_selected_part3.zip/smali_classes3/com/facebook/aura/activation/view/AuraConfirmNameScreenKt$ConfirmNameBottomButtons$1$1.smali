.class public final Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onContinue:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onLogOut:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$uiState:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$onContinue:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 11

    .line 0
    const/4 v2, 0x0

    .line 1
    move-object v3, p1

    .line 2
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    move-object v1, p0

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$uiState:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 7
    .line 8
    iget-boolean v7, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isContinueEnabled:Z

    .line 9
    .line 10
    iget-boolean v8, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$onContinue:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    new-instance v10, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1$1;

    .line 15
    .line 16
    invoke-direct {v10, v0}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 17
    .line 18
    .line 19
    const/4 v5, 0x0

    .line 20
    const v4, 0x7f1202b8

    .line 21
    .line 22
    .line 23
    const-string v9, "primary_button"

    .line 24
    .line 25
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 26
    .line 27
    move-object v6, v5

    .line 28
    move-object p0, v5

    .line 29
    invoke-interface/range {v3 .. v12}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(I[Ljava/lang/Object;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$uiState:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 33
    .line 34
    iget-boolean v0, v0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 35
    .line 36
    xor-int/lit8 v7, v0, 0x1

    .line 37
    .line 38
    iget-object v1, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 39
    .line 40
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1$2;

    .line 41
    .line 42
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1$2;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 43
    .line 44
    .line 45
    const v4, 0x7f12081b

    .line 46
    .line 47
    .line 48
    const-string v9, "secondary_button"

    .line 49
    .line 50
    move v8, v2

    .line 51
    move-object v10, v0

    .line 52
    invoke-interface/range {v3 .. v12}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->secondaryButton(I[Ljava/lang/Object;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;)V

    .line 53
    .line 54
    .line 55
    return-void
.end method
