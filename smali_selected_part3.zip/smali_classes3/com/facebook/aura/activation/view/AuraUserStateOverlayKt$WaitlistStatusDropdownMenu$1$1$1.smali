.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $status:LX/7Kq;


# direct methods
.method public constructor <init>(LX/7Kq;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;->$status:LX/7Kq;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 24

    .line 268435456
    move/from16 v1, p2

    .line 268435457
    .line 268435458
    invoke-static {v1}, LX/005;->A1D(I)Z

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    move-object/from16 v2, p1

    .line 268435463
    .line 268435464
    invoke-static {v0, v2, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    if-eqz v0, :cond_0

    .line 268435469
    .line 268435470
    move-object/from16 v0, p0

    .line 268435471
    .line 268435472
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;->$status:LX/7Kq;

    .line 268435473
    .line 268435474
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 268435475
    .line 268435476
    .line 268435477
    move-result-object v10

    .line 268435478
    const/4 v12, 0x0

    .line 268435479
    const v17, 0x1fffe

    .line 268435480
    .line 268435481
    .line 268435482
    const/4 v3, 0x0

    .line 268435483
    const-wide/16 v18, 0x0

    .line 268435484
    .line 268435485
    move-object v4, v3

    .line 268435486
    move-object v5, v3

    .line 268435487
    move-object v6, v3

    .line 268435488
    move-object v7, v3

    .line 268435489
    move-object v8, v3

    .line 268435490
    move-object v9, v3

    .line 268435491
    move-object v11, v3

    .line 268435492
    move v13, v12

    .line 268435493
    move v14, v12

    .line 268435494
    move v15, v12

    .line 268435495
    move/from16 v16, v12

    .line 268435496
    .line 268435497
    move-wide/from16 v20, v18

    .line 268435498
    .line 268435499
    move-wide/from16 v22, v18

    .line 268435500
    .line 268435501
    move-wide/from16 p0, v18

    .line 268435502
    .line 268435503
    move/from16 p2, v12

    .line 268435504
    .line 268435505
    invoke-static/range {v2 .. v26}, LX/2rV;->A00(LX/2d4;LX/3C1;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2wS;LX/2RW;Ljava/lang/String;LX/JDM;IIIIIIJJJJZ)V

    .line 268435506
    .line 268435507
    .line 268435508
    return-void

    .line 268435509
    :cond_0
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 268435510
    .line 268435511
    .line 268435512
    return-void
.end method
