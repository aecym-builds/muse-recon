.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $isResetting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onLogOut:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resetFailedTitle:Ljava/lang/String;

.field public final synthetic $userSession:LX/AHE;

.field public final synthetic $view:Landroid/view/View;


# direct methods
.method public constructor <init>(LX/1EL;Landroidx/compose/runtime/MutableState;LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/AHE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$coroutineScope:LX/1EL;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$userSession:LX/AHE;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$view:Landroid/view/View;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$resetFailedTitle:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 7

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$coroutineScope:LX/1EL;

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$userSession:LX/AHE;

    .line 17
    .line 18
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$view:Landroid/view/View;

    .line 21
    .line 22
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$resetFailedTitle:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 25
    .line 26
    const/4 p0, 0x0

    .line 27
    new-instance v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;

    .line 28
    .line 29
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;-><init>(LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 30
    .line 31
    .line 32
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void
.end method
