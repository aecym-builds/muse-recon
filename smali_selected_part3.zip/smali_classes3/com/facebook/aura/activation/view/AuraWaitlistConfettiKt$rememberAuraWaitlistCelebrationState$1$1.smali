.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1"
    f = "AuraWaitlistConfetti.kt"
    l = {
        0xb1,
        0xb2,
        0xb7
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $animationsEnabled:Z

.field public final synthetic $celebrationId:I

.field public final synthetic $haptics:LX/1sR;

.field public final synthetic $isAlreadyJoined:Z

.field public final synthetic $lastCelebrationId$delegate:LX/CR1;

.field public final synthetic $state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public label:I


# direct methods
.method public constructor <init>(ZILX/1sR;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;ZLX/CR1;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZI",
            "LX/1sR;",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Z",
            "LX/CR1;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$isAlreadyJoined:Z

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$celebrationId:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$haptics:LX/1sR;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$animationsEnabled:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$lastCelebrationId$delegate:LX/CR1;

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0, p7}, LX/DRu;-><init>(ILX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$isAlreadyJoined:Z

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$celebrationId:I

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$haptics:LX/1sR;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 7
    .line 8
    iget-boolean v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$animationsEnabled:Z

    .line 9
    .line 10
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$lastCelebrationId$delegate:LX/CR1;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;

    .line 13
    .line 14
    move-object p1, p2

    .line 15
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;-><init>(ZILX/1sR;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;ZLX/CR1;LX/2M4;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x3

    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v6, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    if-eq v0, v6, :cond_2

    .line 10
    .line 11
    if-eq v0, v2, :cond_4

    .line 12
    .line 13
    if-ne v0, v4, :cond_6

    .line 14
    .line 15
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    return-object v3

    .line 21
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$isAlreadyJoined:Z

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    iget v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$celebrationId:I

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$lastCelebrationId$delegate:LX/CR1;

    .line 31
    .line 32
    sget v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->CtaPunchScale:F

    .line 33
    .line 34
    invoke-interface {v1}, LX/CR1;->AGk()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-le v5, v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$lastCelebrationId$delegate:LX/CR1;

    .line 41
    .line 42
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$celebrationId:I

    .line 43
    .line 44
    invoke-interface {v1, v0}, LX/CR1;->Ae1(I)V

    .line 45
    .line 46
    .line 47
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$haptics:LX/1sR;

    .line 48
    .line 49
    sget v0, Lcom/facebook/aura/vds/compose/accessibility/AuraHaptics;->SUCCESS:I

    .line 50
    .line 51
    invoke-interface {v1, v0}, LX/1sR;->AYC(I)V

    .line 52
    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 55
    .line 56
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->ctaScale:LX/Dvf;

    .line 57
    .line 58
    invoke-static {}, LX/002;->A0l()Ljava/lang/Float;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput v6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->label:I

    .line 63
    .line 64
    invoke-virtual {v1, v0, p0}, LX/Dvf;->A04(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-ne v0, v3, :cond_3

    .line 69
    .line 70
    return-object v3

    .line 71
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 75
    .line 76
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 77
    .line 78
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 79
    .line 80
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iget v0, v0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 85
    .line 86
    int-to-float v0, v0

    .line 87
    invoke-static {v0}, LX/001;->A0o(F)Ljava/lang/Float;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iput v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->label:I

    .line 92
    .line 93
    invoke-virtual {v1, v0, p0}, LX/Dvf;->A04(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    if-ne v0, v3, :cond_5

    .line 98
    .line 99
    return-object v3

    .line 100
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :cond_5
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$animationsEnabled:Z

    .line 104
    .line 105
    if-eqz v0, :cond_0

    .line 106
    .line 107
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 108
    .line 109
    const/4 v1, 0x0

    .line 110
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;

    .line 111
    .line 112
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 113
    .line 114
    .line 115
    iput v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;->label:I

    .line 116
    .line 117
    invoke-static {v0, p0}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    if-ne v0, v3, :cond_0

    .line 122
    .line 123
    return-object v3

    .line 124
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0
.end method
