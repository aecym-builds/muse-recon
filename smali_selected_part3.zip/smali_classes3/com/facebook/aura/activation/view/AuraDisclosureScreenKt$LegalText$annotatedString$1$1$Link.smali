.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final label:Ljava/lang/String;

.field public final start:I

.field public final url:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->start:I

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->label:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->url:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStart()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->start:I

    .line 1
    .line 2
    return p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
