.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $celebrationId:I

.field public final synthetic $isJoiningWaitlist:Z

.field public final synthetic $mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRefresh:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/WaitlistScreenMode;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZILcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/WaitlistScreenMode;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;ZI",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onRefresh:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$isJoiningWaitlist:Z

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$celebrationId:I

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$modifier:LX/3C1;

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$$changed:I

    .line 17
    .line 18
    iput p10, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$$default:I

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 11

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$onRefresh:Lkotlin/jvm/functions/Function0;

    .line 268435463
    .line 268435464
    iget-boolean v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$isJoiningWaitlist:Z

    .line 268435465
    .line 268435466
    iget v6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$celebrationId:I

    .line 268435467
    .line 268435468
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 268435469
    .line 268435470
    iget-object v8, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$modifier:LX/3C1;

    .line 268435471
    .line 268435472
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$$changed:I

    .line 268435473
    .line 268435474
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435475
    .line 268435476
    .line 268435477
    move-result v10

    .line 268435478
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;->$$default:I

    .line 268435479
    .line 268435480
    move-object v9, p1

    .line 268435481
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->AuraWaitlistScreen(Lcom/facebook/aura/activation/view/WaitlistScreenMode;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZILcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;LX/2d4;II)V

    .line 268435482
    .line 268435483
    .line 268435484
    return-void
.end method
