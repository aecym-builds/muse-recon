.class public final Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemLoadingContent$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/367;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $loadingDescription:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemLoadingContent$1$1;->$loadingDescription:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/367;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemLoadingContent$1$1;->invoke(LX/367;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/367;)V
    .locals 0

    .line 0
    invoke-static {p1}, LX/35e;->A02(LX/367;)V

    .line 1
    .line 2
    .line 3
    iget-object p0, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemLoadingContent$1$1;->$loadingDescription:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p1, p0}, LX/35e;->A09(LX/367;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
