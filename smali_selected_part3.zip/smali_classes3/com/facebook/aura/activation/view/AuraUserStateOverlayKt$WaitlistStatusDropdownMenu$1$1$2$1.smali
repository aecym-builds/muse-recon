.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $failedToastTitle:Ljava/lang/String;

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeStarted:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $parentView:Landroid/view/View;

.field public final synthetic $status:LX/7Kq;

.field public final synthetic $successToastTitle:Ljava/lang/String;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/1EL;LX/AHE;LX/7Kq;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/1EL;",
            "LX/AHE;",
            "LX/7Kq;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$coroutineScope:LX/1EL;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$status:LX/7Kq;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$parentView:Landroid/view/View;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$successToastTitle:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$failedToastTitle:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 6
    .line 7
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$coroutineScope:LX/1EL;

    .line 11
    .line 12
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$userSession:LX/AHE;

    .line 13
    .line 14
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$status:LX/7Kq;

    .line 15
    .line 16
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$parentView:Landroid/view/View;

    .line 19
    .line 20
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$successToastTitle:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;->$failedToastTitle:Ljava/lang/String;

    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    new-instance v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;

    .line 26
    .line 27
    invoke-direct/range {v1 .. v8}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;-><init>(LX/AHE;LX/7Kq;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Ljava/lang/String;LX/2M4;)V

    .line 28
    .line 29
    .line 30
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method
