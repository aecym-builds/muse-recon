.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Ljava/lang/Float;",
        "Ljava/lang/Float;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offsetY$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-static {p1}, LX/001;->A04(Ljava/lang/Object;)F

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p1

    .line 268435460
    check-cast p2, Ljava/lang/Number;

    .line 268435461
    .line 268435462
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 268435463
    .line 268435464
    .line 268435465
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435466
    .line 268435467
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader$lambda$5(Landroidx/compose/runtime/MutableState;F)V

    .line 268435468
    .line 268435469
    .line 268435470
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435471
    .line 268435472
    return-object p0
.end method

.method public final invoke(FF)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader$lambda$5(Landroidx/compose/runtime/MutableState;F)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
