.class public final Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onLogOut:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$viewModel:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$uiState$delegate:LX/16A;

    .line 7
    .line 8
    const/4 v0, 0x4

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 17

    .line 0
    move/from16 v2, p4

    .line 1
    .line 2
    and-int/lit8 v0, p4, 0x6

    .line 3
    .line 4
    move/from16 p2, p1

    .line 5
    .line 6
    move-object/from16 v9, p3

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    move/from16 v0, p2

    .line 11
    .line 12
    invoke-static {v9, v0}, LX/004;->A09(LX/2d4;F)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    or-int v2, p4, v0

    .line 17
    .line 18
    :cond_0
    and-int/lit16 v1, v2, 0x83

    .line 19
    .line 20
    const/16 v0, 0x82

    .line 21
    .line 22
    const/4 v8, 0x1

    .line 23
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {v0, v9, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_8

    .line 32
    .line 33
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 34
    .line 35
    const/16 v16, 0x0

    .line 36
    .line 37
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 38
    .line 39
    invoke-static {v0}, LX/6jg;->A01(LX/3C1;)LX/3C1;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v0}, LX/6jg;->A00(LX/3C1;)LX/3C1;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 48
    .line 49
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    sget-object v13, LX/2Id;->A00:LX/2sS;

    .line 54
    .line 55
    move-object/from16 v1, p0

    .line 56
    .line 57
    iget-object v10, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$viewModel:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 58
    .line 59
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 60
    .line 61
    move-object/from16 p4, v0

    .line 62
    .line 63
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 64
    .line 65
    move-object/from16 p0, v0

    .line 66
    .line 67
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;->$uiState$delegate:LX/16A;

    .line 68
    .line 69
    move-object/from16 p3, v0

    .line 70
    .line 71
    sget-object v12, LX/Dn6;->A06:LX/Dps;

    .line 72
    .line 73
    const/16 v11, 0x30

    .line 74
    .line 75
    invoke-static {v12, v9, v13, v11}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    move-object v6, v9

    .line 80
    check-cast v6, LX/J7I;

    .line 81
    .line 82
    iget-wide v0, v6, LX/J7I;->A06:J

    .line 83
    .line 84
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 85
    .line 86
    .line 87
    move-result v14

    .line 88
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-static {v9, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    sget-object v5, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 97
    .line 98
    iget-object v3, v6, LX/J7I;->A0V:LX/3DJ;

    .line 99
    .line 100
    if-nez v3, :cond_1

    .line 101
    .line 102
    invoke-static {}, LX/1VY;->A00()V

    .line 103
    .line 104
    .line 105
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    throw v0

    .line 110
    :cond_1
    invoke-static {v9, v6, v5}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 111
    .line 112
    .line 113
    sget-object v4, LX/3Cl;->A04:LX/JDN;

    .line 114
    .line 115
    invoke-static {v9, v2, v4}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    invoke-static {v9, v1, v3, v14}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 120
    .line 121
    .line 122
    move-result-object v15

    .line 123
    sget-object v2, LX/3Cl;->A02:LX/JDM;

    .line 124
    .line 125
    invoke-static {v9, v0, v2}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 126
    .line 127
    .line 128
    move-result-object v14

    .line 129
    sget-object v0, LX/CgJ;->A00:LX/CgJ;

    .line 130
    .line 131
    const/16 p1, 0x0

    .line 132
    .line 133
    invoke-static {v0, v7, v8}, LX/002;->A0X(LX/CgJ;LX/3C1;Z)LX/3C1;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    sget-object v0, LX/2sI;->A02:LX/2wD;

    .line 138
    .line 139
    invoke-static {v9, v1, v0}, LX/3J3;->A05(LX/2d4;LX/3C1;LX/3C1;)LX/3C1;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    invoke-static {v12, v9, v13, v11}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 144
    .line 145
    .line 146
    move-result-object v12

    .line 147
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 148
    .line 149
    .line 150
    move-result v11

    .line 151
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    invoke-static {v9, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    invoke-static {v9, v6, v5}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 160
    .line 161
    .line 162
    invoke-static {v9, v12, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 163
    .line 164
    .line 165
    invoke-static {v9, v1, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 166
    .line 167
    .line 168
    invoke-static {v2, v15, v9, v11}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 169
    .line 170
    .line 171
    invoke-static {v9, v0, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 172
    .line 173
    .line 174
    move/from16 v0, p2

    .line 175
    .line 176
    invoke-static {v9, v7, v0}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 177
    .line 178
    .line 179
    invoke-interface/range {p3 .. p3}, LX/16A;->getValue()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v13

    .line 183
    check-cast v13, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 184
    .line 185
    invoke-interface {v9, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    if-nez v0, :cond_2

    .line 194
    .line 195
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 196
    .line 197
    if-ne v2, v0, :cond_3

    .line 198
    .line 199
    :cond_2
    new-instance v2, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$1$1$1;

    .line 200
    .line 201
    invoke-direct {v2, v10}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$1$1$1;-><init>(Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    invoke-interface {v9, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_3
    check-cast v2, LX/DqV;

    .line 208
    .line 209
    check-cast v2, LX/JDM;

    .line 210
    .line 211
    invoke-interface {v9, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    move-result v1

    .line 215
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    if-nez v1, :cond_4

    .line 220
    .line 221
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 222
    .line 223
    if-ne v0, v1, :cond_5

    .line 224
    .line 225
    :cond_4
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$1$2$1;

    .line 226
    .line 227
    invoke-direct {v0, v10}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$1$2$1;-><init>(Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    :cond_5
    check-cast v0, LX/DqV;

    .line 234
    .line 235
    check-cast v0, LX/JDM;

    .line 236
    .line 237
    const/16 p2, 0x10

    .line 238
    .line 239
    move-object/from16 v12, p0

    .line 240
    .line 241
    move-object v14, v2

    .line 242
    move-object v15, v0

    .line 243
    move-object/from16 p0, v9

    .line 244
    .line 245
    invoke-static/range {v12 .. v19}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameForm(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 246
    .line 247
    .line 248
    invoke-static {v6, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 249
    .line 250
    .line 251
    sget v2, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 252
    .line 253
    invoke-static {v9, v7, v2}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 254
    .line 255
    .line 256
    invoke-interface/range {p3 .. p3}, LX/16A;->getValue()Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v13

    .line 260
    check-cast v13, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 261
    .line 262
    invoke-interface {v9, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result v1

    .line 266
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    if-nez v1, :cond_6

    .line 271
    .line 272
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 273
    .line 274
    if-ne v0, v1, :cond_7

    .line 275
    .line 276
    :cond_6
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$2$1;

    .line 277
    .line 278
    invoke-direct {v0, v10}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1$1$2$1;-><init>(Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 282
    .line 283
    .line 284
    :cond_7
    check-cast v0, LX/DqV;

    .line 285
    .line 286
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 287
    .line 288
    const/16 p2, 0x8

    .line 289
    .line 290
    move-object v14, v0

    .line 291
    move-object/from16 v15, p4

    .line 292
    .line 293
    invoke-static/range {v13 .. v19}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameBottomButtons(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 294
    .line 295
    .line 296
    invoke-static {v9, v6, v7, v2, v8}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 297
    .line 298
    .line 299
    return-void

    .line 300
    :cond_8
    invoke-interface {v9}, LX/2d4;->AgJ()V

    .line 301
    .line 302
    .line 303
    return-void
.end method
