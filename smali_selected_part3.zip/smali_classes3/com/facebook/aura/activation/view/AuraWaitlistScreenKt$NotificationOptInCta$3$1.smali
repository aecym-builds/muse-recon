.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;

.field public final synthetic $notificationPermissionLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $showDeniedDialog$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/app/Activity;LX/166;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$activity:Landroid/app/Activity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$notificationPermissionLauncher:LX/166;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$showDeniedDialog$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 8

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->NOTIFICATION_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    move-object v5, v2

    .line 10
    move-object v6, v2

    .line 11
    move-object v7, v2

    .line 12
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$activity:Landroid/app/Activity;

    .line 16
    .line 17
    invoke-static {v0}, Lcom/facebook/aura/utils/HatchNotificationPermissionLauncherKt;->canRequestNotificationPermission(Landroid/app/Activity;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$notificationPermissionLauncher:LX/166;

    .line 24
    .line 25
    const-string v0, "android.permission.POST_NOTIFICATIONS"

    .line 26
    .line 27
    invoke-virtual {v1, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;->$showDeniedDialog$delegate:Landroidx/compose/runtime/MutableState;

    .line 32
    .line 33
    const/4 v0, 0x1

    .line 34
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method
