.class public final Lcom/facebook/aura/activation/view/ConfettiParticle;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final color:J

.field public final delay:F

.field public final depth:Lcom/facebook/aura/activation/view/ConfettiDepth;

.field public final drag:F

.field public final end:F

.field public final gravity:F

.field public final height:F

.field public final kind:Lcom/facebook/aura/activation/view/ConfettiKind;

.field public final lifetime:F

.field public final normalizedX:F

.field public final rotation:F

.field public final spin:F

.field public final startY:F

.field public final swayAmplitude:F

.field public final swayFrequency:F

.field public final swayPhase:F

.field public final targetOffset:F

.field public final targetSide:F

.field public final targetStrength:F

.field public final targetsSuccess:Z

.field public final tumblePhase:F

.field public final tumbleRate:F

.field public final velocityX:F

.field public final velocityY:F

.field public final width:F


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/ConfettiDepth;Lcom/facebook/aura/activation/view/ConfettiKind;JFFFFFFFFFFFFFFFFFZFFF)V
    .locals 2

    .line 269288789
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 269288790
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 269288791
    iput-object p1, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->depth:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 269288792
    iput-object p2, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->kind:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 269288793
    iput-wide p3, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->color:J

    .line 269288794
    iput p5, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->normalizedX:F

    .line 269288795
    iput p6, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->startY:F

    .line 269288796
    iput p7, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->delay:F

    .line 269288797
    iput p8, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityX:F

    .line 269288798
    iput p9, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityY:F

    .line 269288799
    iput p10, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->gravity:F

    .line 269288800
    iput p11, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->drag:F

    .line 269288801
    iput p12, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->width:F

    .line 269288802
    iput p13, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->height:F

    .line 269288803
    move/from16 v0, p14

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->rotation:F

    .line 269288804
    move/from16 v0, p15

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->spin:F

    .line 269288805
    move/from16 v0, p16

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumblePhase:F

    .line 269288806
    move/from16 v0, p17

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumbleRate:F

    .line 269288807
    move/from16 v0, p18

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayAmplitude:F

    .line 269288808
    move/from16 v0, p19

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayFrequency:F

    .line 269288809
    move/from16 v0, p20

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayPhase:F

    .line 269288810
    move/from16 v1, p21

    iput v1, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->lifetime:F

    .line 269288811
    move/from16 v0, p22

    iput-boolean v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetsSuccess:Z

    .line 269288812
    move/from16 v0, p23

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetSide:F

    .line 269288813
    move/from16 v0, p24

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetOffset:F

    .line 269288814
    move/from16 v0, p25

    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetStrength:F

    add-float p7, p7, p21

    .line 269288815
    iput p7, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->end:F

    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/activation/view/ConfettiDepth;Lcom/facebook/aura/activation/view/ConfettiKind;JFFFFFFFFFFFFFFFFFZFFFLX/04f;)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p25}, Lcom/facebook/aura/activation/view/ConfettiParticle;-><init>(Lcom/facebook/aura/activation/view/ConfettiDepth;Lcom/facebook/aura/activation/view/ConfettiKind;JFFFFFFFFFFFFFFFFFZFFF)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getColor-0d7_KjU()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->color:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getDelay()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->delay:F

    .line 1
    .line 2
    return p0
.end method

.method public final getDepth()Lcom/facebook/aura/activation/view/ConfettiDepth;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->depth:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDrag()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->drag:F

    .line 1
    .line 2
    return p0
.end method

.method public final getEnd()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->end:F

    .line 1
    .line 2
    return p0
.end method

.method public final getGravity()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->gravity:F

    .line 1
    .line 2
    return p0
.end method

.method public final getHeight()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->height:F

    .line 1
    .line 2
    return p0
.end method

.method public final getKind()Lcom/facebook/aura/activation/view/ConfettiKind;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->kind:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLifetime()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->lifetime:F

    .line 1
    .line 2
    return p0
.end method

.method public final getNormalizedX()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->normalizedX:F

    .line 1
    .line 2
    return p0
.end method

.method public final getRotation()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->rotation:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSpin()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->spin:F

    .line 1
    .line 2
    return p0
.end method

.method public final getStartY()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->startY:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSwayAmplitude()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayAmplitude:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSwayFrequency()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayFrequency:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSwayPhase()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayPhase:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTargetOffset()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetOffset:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTargetSide()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetSide:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTargetStrength()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetStrength:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTargetsSuccess()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetsSuccess:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getTumblePhase()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumblePhase:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTumbleRate()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumbleRate:F

    .line 1
    .line 2
    return p0
.end method

.method public final getVelocityX()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityX:F

    .line 1
    .line 2
    return p0
.end method

.method public final getVelocityY()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityY:F

    .line 1
    .line 2
    return p0
.end method

.method public final getWidth()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiParticle;->width:F

    .line 1
    .line 2
    return p0
.end method
