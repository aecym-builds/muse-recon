.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $isFetchingMetadata:Z

.field public final synthetic $isLoading:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onClose:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $showsActivationSubscriptionUpgradeCard:Z

.field public final synthetic $tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

.field public final synthetic $upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;ZII)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "LX/3C1;",
            "ZZ",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "ZII)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$onClose:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$modifier:LX/3C1;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$isLoading:Z

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$isFetchingMetadata:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$showsActivationSubscriptionUpgradeCard:Z

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$$changed:I

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$$default:I

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$onClose:Lkotlin/jvm/functions/Function0;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$upsellCell:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$modifier:LX/3C1;

    .line 268435461
    .line 268435462
    iget-boolean v4, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$isLoading:Z

    .line 268435463
    .line 268435464
    iget-boolean v5, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$isFetchingMetadata:Z

    .line 268435465
    .line 268435466
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 268435467
    .line 268435468
    iget-boolean v7, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$showsActivationSubscriptionUpgradeCard:Z

    .line 268435469
    .line 268435470
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$$changed:I

    .line 268435471
    .line 268435472
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v9

    .line 268435476
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;->$$default:I

    .line 268435477
    .line 268435478
    move-object v8, p1

    .line 268435479
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->AuraDisclosureScreen(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;ZLX/2d4;II)V

    .line 268435480
    .line 268435481
    .line 268435482
    return-void
.end method
