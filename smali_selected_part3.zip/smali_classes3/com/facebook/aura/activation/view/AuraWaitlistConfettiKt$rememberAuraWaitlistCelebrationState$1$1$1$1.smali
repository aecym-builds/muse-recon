.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1"
    f = "AuraWaitlistConfetti.kt"
    l = {
        0xb9,
        0xba
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v6, 0x2

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-eq v0, v2, :cond_2

    .line 9
    .line 10
    if-ne v0, v6, :cond_4

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v5

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 22
    .line 23
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 24
    .line 25
    invoke-static {}, LX/007;->A0q()Ljava/lang/Float;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->label:I

    .line 30
    .line 31
    invoke-virtual {v1, v0, p0}, LX/Dvf;->A04(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-ne v0, v5, :cond_3

    .line 36
    .line 37
    return-object v5

    .line 38
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 42
    .line 43
    iget-object v4, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 44
    .line 45
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 46
    .line 47
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    iget v0, v0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 52
    .line 53
    int-to-float v0, v0

    .line 54
    invoke-static {v0}, LX/001;->A0o(F)Ljava/lang/Float;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 59
    .line 60
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 61
    .line 62
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    iget v2, v0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 67
    .line 68
    sget-object v0, LX/33X;->A02:LX/1V8;

    .line 69
    .line 70
    const/4 v1, 0x0

    .line 71
    invoke-static {v0, v2}, LX/002;->A0U(LX/1V8;I)LX/E1b;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    iput v6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;->label:I

    .line 76
    .line 77
    invoke-static {v4, v0, v3, p0, v1}, LX/002;->A0s(LX/Dvf;LX/DwJ;Ljava/lang/Object;LX/2M4;LX/JDM;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-ne v0, v5, :cond_0

    .line 82
    .line 83
    return-object v5

    .line 84
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    throw v0
.end method
