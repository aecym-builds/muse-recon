.class public final Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 8

    .line 0
    sget-object v1, Lcom/facebook/aura/invite/api/InviteBadges;->INSTANCE:Lcom/facebook/aura/invite/api/InviteBadges;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;->$userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/invite/api/InviteBadges;->markSeen(LX/AHE;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 8
    .line 9
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 10
    .line 11
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->HEADER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 12
    .line 13
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 14
    .line 15
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_FRIENDS_PILL:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 16
    .line 17
    const/4 v5, 0x0

    .line 18
    move-object v6, v5

    .line 19
    move-object v7, v5

    .line 20
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteConversationHeaderAction$rememberAction$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 24
    .line 25
    sget-object v1, Lcom/facebook/aura/navigation/key/InviteFriendScreenKey;->INSTANCE:Lcom/facebook/aura/navigation/key/InviteFriendScreenKey;

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-interface {v2, v1, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
