.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;

.field public final synthetic $notificationPermissionLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/app/Activity;LX/166;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;->$activity:Landroid/app/Activity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;->$notificationPermissionLauncher:LX/166;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;->$activity:Landroid/app/Activity;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/utils/HatchNotificationPermissionLauncherKt;->canRequestNotificationPermission(Landroid/app/Activity;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;->$notificationPermissionLauncher:LX/166;

    .line 9
    .line 10
    const-string v0, "android.permission.POST_NOTIFICATIONS"

    .line 11
    .line 12
    invoke-virtual {p0, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1$invoke$$inlined$onDispose$1;

    .line 16
    .line 17
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
