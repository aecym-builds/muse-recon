.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2f1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;->$surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2f1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;->invoke(LX/2f1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2f1;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;->$surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-virtual {p1}, LX/2f1;->A02()LX/2sT;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    sget v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->CtaPunchScale:F

    .line 11
    .line 12
    invoke-interface {p0, v1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
