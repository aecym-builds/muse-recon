.class public abstract Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AuraDisclosureScreen(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;ZLX/2d4;II)V
    .locals 42
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/data/HatchUpsellCell;",
            "LX/3C1;",
            "ZZ",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "Z",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move/from16 v8, p4

    .line 1
    .line 2
    move-object/from16 v24, p5

    .line 3
    .line 4
    move-object/from16 v23, p2

    .line 5
    .line 6
    move/from16 v22, p3

    .line 7
    .line 8
    move/from16 v21, p6

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    move-object/from16 p6, p0

    .line 12
    .line 13
    move-object/from16 v0, p6

    .line 14
    .line 15
    invoke-static {v0, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    const v0, 0x7d58cf20

    .line 19
    .line 20
    .line 21
    move-object/from16 v1, p7

    .line 22
    .line 23
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 24
    .line 25
    .line 26
    move/from16 v6, p8

    .line 27
    .line 28
    and-int/lit8 v0, p8, 0x6

    .line 29
    .line 30
    if-nez v0, :cond_15

    .line 31
    .line 32
    move-object/from16 v0, p6

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int v0, v0, p8

    .line 39
    .line 40
    :goto_0
    and-int/lit8 v2, p8, 0x30

    .line 41
    .line 42
    move-object/from16 p5, p1

    .line 43
    .line 44
    if-nez v2, :cond_0

    .line 45
    .line 46
    move-object/from16 v2, p5

    .line 47
    .line 48
    invoke-static {v1, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    or-int/2addr v0, v2

    .line 53
    :cond_0
    move/from16 v40, p9

    .line 54
    .line 55
    and-int/lit8 v10, p9, 0x4

    .line 56
    .line 57
    if-eqz v10, :cond_14

    .line 58
    .line 59
    or-int/lit16 v0, v0, 0x180

    .line 60
    .line 61
    :cond_1
    :goto_1
    and-int/lit8 v3, p9, 0x8

    .line 62
    .line 63
    if-eqz v3, :cond_13

    .line 64
    .line 65
    or-int/lit16 v0, v0, 0xc00

    .line 66
    .line 67
    :cond_2
    :goto_2
    and-int/lit8 v4, p9, 0x10

    .line 68
    .line 69
    if-eqz v4, :cond_12

    .line 70
    .line 71
    or-int/lit16 v0, v0, 0x6000

    .line 72
    .line 73
    :cond_3
    :goto_3
    and-int/lit8 v9, p9, 0x20

    .line 74
    .line 75
    const/high16 v2, 0x30000

    .line 76
    .line 77
    if-nez v9, :cond_4

    .line 78
    .line 79
    and-int v2, p8, v2

    .line 80
    .line 81
    if-nez v2, :cond_5

    .line 82
    .line 83
    move-object/from16 v2, v24

    .line 84
    .line 85
    invoke-static {v1, v2}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 86
    .line 87
    .line 88
    move-result v2

    .line 89
    :cond_4
    or-int/2addr v0, v2

    .line 90
    :cond_5
    and-int/lit8 v7, p9, 0x40

    .line 91
    .line 92
    const/high16 v2, 0x180000

    .line 93
    .line 94
    if-nez v7, :cond_6

    .line 95
    .line 96
    and-int v2, p8, v2

    .line 97
    .line 98
    if-nez v2, :cond_7

    .line 99
    .line 100
    move/from16 v2, v21

    .line 101
    .line 102
    invoke-static {v1, v2}, LX/004;->A0o(LX/2d4;Z)I

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    :cond_6
    or-int/2addr v0, v2

    .line 107
    :cond_7
    const v2, 0x92493

    .line 108
    .line 109
    .line 110
    invoke-static {v0, v2}, LX/005;->A1O(II)Z

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    invoke-static {v2, v1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 115
    .line 116
    .line 117
    move-result v2

    .line 118
    if-eqz v2, :cond_b

    .line 119
    .line 120
    if-eqz v10, :cond_8

    .line 121
    .line 122
    sget-object v23, LX/3C1;->A00:LX/3Cb;

    .line 123
    .line 124
    :cond_8
    move/from16 v2, v22

    .line 125
    .line 126
    invoke-static {v3, v2}, LX/001;->A1P(IZ)Z

    .line 127
    .line 128
    .line 129
    move-result v22

    .line 130
    invoke-static {v4, v8}, LX/001;->A1P(IZ)Z

    .line 131
    .line 132
    .line 133
    move-result v36

    .line 134
    const/16 v31, 0x0

    .line 135
    .line 136
    if-eqz v9, :cond_9

    .line 137
    .line 138
    move-object/from16 v24, v31

    .line 139
    .line 140
    :cond_9
    move/from16 v2, v21

    .line 141
    .line 142
    invoke-static {v7, v2}, LX/001;->A1P(IZ)Z

    .line 143
    .line 144
    .line 145
    move-result v21

    .line 146
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 147
    .line 148
    const/4 v7, 0x6

    .line 149
    invoke-virtual {v2, v1, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    if-eqz v36, :cond_c

    .line 154
    .line 155
    const v0, -0x3e2a4d4f

    .line 156
    .line 157
    .line 158
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 159
    .line 160
    .line 161
    invoke-static/range {v23 .. v23}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    iget-wide v2, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 166
    .line 167
    invoke-static {v0, v2, v3}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 172
    .line 173
    .line 174
    move-result-object v9

    .line 175
    move-object v3, v1

    .line 176
    check-cast v3, LX/J7I;

    .line 177
    .line 178
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 179
    .line 180
    .line 181
    move-result v8

    .line 182
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 183
    .line 184
    .line 185
    move-result-object v5

    .line 186
    invoke-static {v1, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 187
    .line 188
    .line 189
    move-result-object v4

    .line 190
    sget-object v2, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 191
    .line 192
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 193
    .line 194
    if-eqz v0, :cond_16

    .line 195
    .line 196
    invoke-static {v1, v3, v2}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 197
    .line 198
    .line 199
    invoke-static {v1, v9, v5, v4, v8}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 200
    .line 201
    .line 202
    sget-object v0, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;->Companion:Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle$Companion;

    .line 203
    .line 204
    invoke-virtual {v0, v1, v7}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle$Companion;->small(LX/2d4;I)Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;

    .line 205
    .line 206
    .line 207
    move-result-object v8

    .line 208
    sget v0, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;->$stable:I

    .line 209
    .line 210
    shl-int/lit8 v12, v0, 0x3

    .line 211
    .line 212
    const/4 v13, 0x5

    .line 213
    const-wide/16 v9, 0x0

    .line 214
    .line 215
    move-object/from16 v7, v31

    .line 216
    .line 217
    move-object v11, v1

    .line 218
    invoke-static/range {v7 .. v13}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerKt;->AuraSpinner-FNF3uiM(LX/3C1;Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;JLX/2d4;II)V

    .line 219
    .line 220
    .line 221
    const/4 v0, 0x1

    .line 222
    invoke-static {v3, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 223
    .line 224
    .line 225
    invoke-static {v1, v3}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    if-eqz v1, :cond_a

    .line 230
    .line 231
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$2;

    .line 232
    .line 233
    move-object/from16 v31, v0

    .line 234
    .line 235
    move-object/from16 v32, p6

    .line 236
    .line 237
    move-object/from16 v33, p5

    .line 238
    .line 239
    move-object/from16 v34, v23

    .line 240
    .line 241
    move/from16 v35, v22

    .line 242
    .line 243
    move-object/from16 v37, v24

    .line 244
    .line 245
    move/from16 v38, v21

    .line 246
    .line 247
    move/from16 v39, v6

    .line 248
    .line 249
    invoke-direct/range {v31 .. v40}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$2;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;ZII)V

    .line 250
    .line 251
    .line 252
    :goto_4
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    :cond_a
    return-void

    .line 256
    :cond_b
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 257
    .line 258
    .line 259
    goto/16 :goto_6

    .line 260
    .line 261
    :cond_c
    const v2, -0x3e273cbe

    .line 262
    .line 263
    .line 264
    invoke-static {v1, v2}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    if-eqz v24, :cond_11

    .line 269
    .line 270
    move-object/from16 v2, v24

    .line 271
    .line 272
    iget-object v13, v2, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureButtonText:Ljava/lang/String;

    .line 273
    .line 274
    if-eqz v13, :cond_11

    .line 275
    .line 276
    invoke-static {v13}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 277
    .line 278
    .line 279
    move-result v2

    .line 280
    if-nez v2, :cond_11

    .line 281
    .line 282
    const v2, -0x759e2659

    .line 283
    .line 284
    .line 285
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 286
    .line 287
    .line 288
    :goto_5
    invoke-static {v4, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 289
    .line 290
    .line 291
    invoke-static/range {v23 .. v23}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 292
    .line 293
    .line 294
    move-result-object v7

    .line 295
    iget-wide v2, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 296
    .line 297
    invoke-static {v7, v2, v3}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 298
    .line 299
    .line 300
    move-result-object v2

    .line 301
    invoke-static {v1, v2}, LX/1ho;->A00(LX/2d4;LX/3C1;)LX/3C1;

    .line 302
    .line 303
    .line 304
    move-result-object v2

    .line 305
    invoke-static {v2}, LX/6jg;->A01(LX/3C1;)LX/3C1;

    .line 306
    .line 307
    .line 308
    move-result-object v3

    .line 309
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 310
    .line 311
    const/16 p4, 0x7

    .line 312
    .line 313
    const/4 v2, 0x0

    .line 314
    invoke-static {v3, v2, v2, v2, v7}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 315
    .line 316
    .line 317
    move-result-object v25

    .line 318
    sget-object v26, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 319
    .line 320
    sget-object v27, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 321
    .line 322
    sget-object v28, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 323
    .line 324
    sget-object v29, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 325
    .line 326
    sget-object v30, Lcom/facebook/aura/analytics/hatch/HatchComponent;->RISK_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 327
    .line 328
    const-wide/16 v34, 0x1f4

    .line 329
    .line 330
    move-object/from16 v32, v31

    .line 331
    .line 332
    move-object/from16 v33, v31

    .line 333
    .line 334
    move/from16 v36, v2

    .line 335
    .line 336
    move-object/from16 v37, v31

    .line 337
    .line 338
    move-object/from16 v38, v31

    .line 339
    .line 340
    move-object/from16 v39, v31

    .line 341
    .line 342
    invoke-static/range {v25 .. v39}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 343
    .line 344
    .line 345
    move-result-object v9

    .line 346
    sget-object v8, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Standard:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 347
    .line 348
    const/16 v3, 0x30

    .line 349
    .line 350
    invoke-static {v9, v8, v1, v3}, Lcom/facebook/aura/ui/adaptive/AuraContentFrameKt;->auraContentWidth(LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;LX/2d4;I)LX/3C1;

    .line 351
    .line 352
    .line 353
    move-result-object v8

    .line 354
    invoke-static {v1}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 355
    .line 356
    .line 357
    move-result-object v10

    .line 358
    iget-wide v11, v4, LX/J7I;->A06:J

    .line 359
    .line 360
    invoke-static {v11, v12}, LX/001;->A0A(J)I

    .line 361
    .line 362
    .line 363
    move-result v9

    .line 364
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 365
    .line 366
    .line 367
    move-result-object v3

    .line 368
    invoke-static {v1, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 369
    .line 370
    .line 371
    move-result-object v14

    .line 372
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 373
    .line 374
    iget-object v11, v4, LX/J7I;->A0V:LX/3DJ;

    .line 375
    .line 376
    if-eqz v11, :cond_16

    .line 377
    .line 378
    invoke-static {v1, v4, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 379
    .line 380
    .line 381
    sget-object v12, LX/3Cl;->A04:LX/JDN;

    .line 382
    .line 383
    invoke-static {v1, v10, v12}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 384
    .line 385
    .line 386
    move-result-object v11

    .line 387
    invoke-static {v1, v3, v11, v9}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 388
    .line 389
    .line 390
    move-result-object v20

    .line 391
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 392
    .line 393
    invoke-static {v1, v14, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 394
    .line 395
    .line 396
    move-result-object v19

    .line 397
    sget-object v14, LX/CgJ;->A00:LX/CgJ;

    .line 398
    .line 399
    const/4 v3, 0x1

    .line 400
    invoke-static {v5, v1, v5, v3}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 401
    .line 402
    .line 403
    move-result-object v15

    .line 404
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 405
    .line 406
    invoke-static {v14, v9, v3}, LX/002;->A0X(LX/CgJ;LX/3C1;Z)LX/3C1;

    .line 407
    .line 408
    .line 409
    move-result-object v14

    .line 410
    invoke-static {v14, v7, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 411
    .line 412
    .line 413
    move-result-object v14

    .line 414
    invoke-static {v5}, LX/001;->A0g(Z)LX/3BI;

    .line 415
    .line 416
    .line 417
    move-result-object v18

    .line 418
    invoke-static {v4}, LX/002;->A0J(LX/J7I;)I

    .line 419
    .line 420
    .line 421
    move-result v17

    .line 422
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 423
    .line 424
    .line 425
    move-result-object v16

    .line 426
    invoke-static {v1, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 427
    .line 428
    .line 429
    move-result-object v14

    .line 430
    invoke-static {v1, v4, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 431
    .line 432
    .line 433
    move-object/from16 v8, v18

    .line 434
    .line 435
    invoke-static {v1, v8, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 436
    .line 437
    .line 438
    move-object/from16 v8, v16

    .line 439
    .line 440
    invoke-static {v1, v8, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 441
    .line 442
    .line 443
    move-object/from16 v11, v20

    .line 444
    .line 445
    move/from16 v8, v17

    .line 446
    .line 447
    invoke-static {v10, v11, v1, v8}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 448
    .line 449
    .line 450
    move-object/from16 v8, v19

    .line 451
    .line 452
    invoke-static {v1, v14, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 453
    .line 454
    .line 455
    sget-object v10, LX/3Jn;->A00:LX/3Jn;

    .line 456
    .line 457
    invoke-static {v15, v9, v3}, LX/3J3;->A02(LX/3Lr;LX/3C1;Z)LX/3C1;

    .line 458
    .line 459
    .line 460
    move-result-object v27

    .line 461
    shr-int/lit8 v8, v0, 0xf

    .line 462
    .line 463
    and-int/lit8 v11, v8, 0xe

    .line 464
    .line 465
    and-int/lit8 v29, v8, 0x7e

    .line 466
    .line 467
    shl-int/lit8 v8, v0, 0x3

    .line 468
    .line 469
    and-int/lit16 v8, v8, 0x380

    .line 470
    .line 471
    or-int v29, v29, v8

    .line 472
    .line 473
    const/4 v12, 0x0

    .line 474
    move/from16 v25, v21

    .line 475
    .line 476
    move-object/from16 v26, p5

    .line 477
    .line 478
    move-object/from16 v28, v1

    .line 479
    .line 480
    move/from16 v30, v5

    .line 481
    .line 482
    invoke-static/range {v24 .. v30}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureContent(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V

    .line 483
    .line 484
    .line 485
    sget-object v8, LX/2Id;->A06:Landroidx/compose/ui/Alignment;

    .line 486
    .line 487
    invoke-virtual {v10, v8, v9}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 488
    .line 489
    .line 490
    move-result-object v8

    .line 491
    invoke-static {v15, v8, v1, v5, v5}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureScrollFade(LX/3Lr;LX/3C1;LX/2d4;II)V

    .line 492
    .line 493
    .line 494
    invoke-static {v4, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 495
    .line 496
    .line 497
    const/4 v8, 0x0

    .line 498
    move-object/from16 v41, v31

    .line 499
    .line 500
    move-object/from16 p0, v31

    .line 501
    .line 502
    move/from16 p1, v5

    .line 503
    .line 504
    move-object/from16 p2, v1

    .line 505
    .line 506
    move/from16 p3, v5

    .line 507
    .line 508
    invoke-static/range {v41 .. v46}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraDivider(LX/3C1;Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle;ZLX/2d4;II)V

    .line 509
    .line 510
    .line 511
    const/4 v15, 0x3

    .line 512
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 513
    .line 514
    invoke-static {v9, v7, v10}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 515
    .line 516
    .line 517
    move-result-object v17

    .line 518
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 519
    .line 520
    .line 521
    move-result-object v10

    .line 522
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 523
    .line 524
    if-ne v10, v9, :cond_d

    .line 525
    .line 526
    sget-object v10, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;

    .line 527
    .line 528
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 529
    .line 530
    .line 531
    :cond_d
    check-cast v10, LX/DqV;

    .line 532
    .line 533
    check-cast v10, LX/JDM;

    .line 534
    .line 535
    or-int/lit16 v11, v11, 0x180

    .line 536
    .line 537
    move-object/from16 v14, v24

    .line 538
    .line 539
    move-object/from16 v16, v10

    .line 540
    .line 541
    move-object/from16 v18, v1

    .line 542
    .line 543
    move/from16 v19, v11

    .line 544
    .line 545
    move/from16 v20, v5

    .line 546
    .line 547
    invoke-static/range {v14 .. v20}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureLegalText-5TldRvM(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 548
    .line 549
    .line 550
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 551
    .line 552
    invoke-static {v5, v7, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 553
    .line 554
    .line 555
    move-result-object v25

    .line 556
    invoke-interface {v1, v13}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 557
    .line 558
    .line 559
    move-result v7

    .line 560
    and-int/lit16 v5, v0, 0x1c00

    .line 561
    .line 562
    const/16 v2, 0x800

    .line 563
    .line 564
    if-ne v5, v2, :cond_e

    .line 565
    .line 566
    const/4 v12, 0x1

    .line 567
    :cond_e
    or-int/2addr v7, v12

    .line 568
    invoke-static {v0}, LX/005;->A1E(I)Z

    .line 569
    .line 570
    .line 571
    move-result v0

    .line 572
    or-int/2addr v7, v0

    .line 573
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 574
    .line 575
    .line 576
    move-result-object v5

    .line 577
    if-nez v7, :cond_f

    .line 578
    .line 579
    if-ne v5, v9, :cond_10

    .line 580
    .line 581
    :cond_f
    new-instance v5, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;

    .line 582
    .line 583
    move/from16 v2, v22

    .line 584
    .line 585
    move-object/from16 v0, p6

    .line 586
    .line 587
    invoke-direct {v5, v13, v2, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;-><init>(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)V

    .line 588
    .line 589
    .line 590
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 591
    .line 592
    .line 593
    :cond_10
    check-cast v5, LX/JDM;

    .line 594
    .line 595
    const/high16 v35, 0xc00000

    .line 596
    .line 597
    const/16 v36, 0x7e

    .line 598
    .line 599
    move-object/from16 v26, v31

    .line 600
    .line 601
    move-object/from16 v27, v31

    .line 602
    .line 603
    move-object/from16 v28, v31

    .line 604
    .line 605
    move-object/from16 v29, v31

    .line 606
    .line 607
    move-object/from16 v30, v31

    .line 608
    .line 609
    move/from16 v32, v3

    .line 610
    .line 611
    move-object/from16 v33, v5

    .line 612
    .line 613
    move-object/from16 v34, v1

    .line 614
    .line 615
    invoke-static/range {v25 .. v36}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupsKt;->AuraButtonGroupStyleExplicit-FLdL6rA(LX/3C1;LX/2iK;LX/2wS;LX/JDM;LX/2iK;LX/2wS;Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupSize;ZLX/JDM;LX/2d4;II)V

    .line 616
    .line 617
    .line 618
    invoke-static {v4, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 619
    .line 620
    .line 621
    :goto_6
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 622
    .line 623
    .line 624
    move-result-object v1

    .line 625
    if-eqz v1, :cond_a

    .line 626
    .line 627
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;

    .line 628
    .line 629
    move-object/from16 v31, v0

    .line 630
    .line 631
    move-object/from16 v32, p6

    .line 632
    .line 633
    move-object/from16 v33, p5

    .line 634
    .line 635
    move-object/from16 v34, v23

    .line 636
    .line 637
    move/from16 v35, v22

    .line 638
    .line 639
    move/from16 v36, v8

    .line 640
    .line 641
    move-object/from16 v37, v24

    .line 642
    .line 643
    move/from16 v38, v21

    .line 644
    .line 645
    move/from16 v39, v6

    .line 646
    .line 647
    invoke-direct/range {v31 .. v40}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$4;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;ZZLcom/facebook/aura/activation/data/HatchTosMetadata;ZII)V

    .line 648
    .line 649
    .line 650
    goto/16 :goto_4

    .line 651
    .line 652
    :cond_11
    const v2, -0x759e1d44    # -1.0876E-32f

    .line 653
    .line 654
    .line 655
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 656
    .line 657
    .line 658
    const v2, 0x7f1202ce

    .line 659
    .line 660
    .line 661
    invoke-static {v1, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 662
    .line 663
    .line 664
    move-result-object v13

    .line 665
    goto/16 :goto_5

    .line 666
    .line 667
    :cond_12
    and-int/lit16 v2, v6, 0x6000

    .line 668
    .line 669
    if-nez v2, :cond_3

    .line 670
    .line 671
    invoke-static {v1, v8}, LX/004;->A0m(LX/2d4;Z)I

    .line 672
    .line 673
    .line 674
    move-result v2

    .line 675
    or-int/2addr v0, v2

    .line 676
    goto/16 :goto_3

    .line 677
    .line 678
    :cond_13
    and-int/lit16 v2, v6, 0xc00

    .line 679
    .line 680
    if-nez v2, :cond_2

    .line 681
    .line 682
    move/from16 v2, v22

    .line 683
    .line 684
    invoke-static {v1, v2}, LX/004;->A0l(LX/2d4;Z)I

    .line 685
    .line 686
    .line 687
    move-result v2

    .line 688
    or-int/2addr v0, v2

    .line 689
    goto/16 :goto_2

    .line 690
    .line 691
    :cond_14
    and-int/lit16 v2, v6, 0x180

    .line 692
    .line 693
    if-nez v2, :cond_1

    .line 694
    .line 695
    move-object/from16 v2, v23

    .line 696
    .line 697
    invoke-static {v1, v2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 698
    .line 699
    .line 700
    move-result v2

    .line 701
    or-int/2addr v0, v2

    .line 702
    goto/16 :goto_1

    .line 703
    .line 704
    :cond_15
    move v0, v6

    .line 705
    goto/16 :goto_0

    .line 706
    .line 707
    :cond_16
    invoke-static {}, LX/1VY;->A00()V

    .line 708
    .line 709
    .line 710
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 711
    .line 712
    .line 713
    move-result-object v0

    .line 714
    throw v0
.end method

.method public static final DisclosureCard(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;II)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v10, p0

    .line 1
    move-object v11, p1

    .line 2
    const v0, -0x4a774b51

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 p1, p5

    .line 11
    .line 12
    and-int/lit8 v5, p5, 0x1

    .line 13
    .line 14
    move/from16 p0, p4

    .line 15
    .line 16
    if-eqz v5, :cond_7

    .line 17
    .line 18
    or-int/lit8 v3, p4, 0x6

    .line 19
    .line 20
    :goto_0
    and-int/lit8 v4, p5, 0x2

    .line 21
    .line 22
    if-eqz v4, :cond_6

    .line 23
    .line 24
    or-int/lit8 v3, v3, 0x30

    .line 25
    .line 26
    :cond_0
    :goto_1
    and-int/lit16 v0, p0, 0x180

    .line 27
    .line 28
    move-object v12, p2

    .line 29
    if-nez v0, :cond_1

    .line 30
    .line 31
    invoke-static {v2, p2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    or-int/2addr v3, v0

    .line 36
    :cond_1
    and-int/lit16 v1, v3, 0x93

    .line 37
    .line 38
    const/16 v0, 0x92

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {v0, v2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_a

    .line 49
    .line 50
    if-eqz v5, :cond_2

    .line 51
    .line 52
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 53
    .line 54
    :cond_2
    const/4 v6, 0x0

    .line 55
    if-eqz v4, :cond_3

    .line 56
    .line 57
    move-object v11, v6

    .line 58
    :cond_3
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 59
    .line 60
    const/4 v7, 0x6

    .line 61
    invoke-virtual {v1, v2, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getShapes(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-object v8, v0, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->large:LX/2bW;

    .line 66
    .line 67
    invoke-static {v10}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-static {v0, v8}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    const/high16 v4, 0x3f800000    # 1.0f

    .line 76
    .line 77
    invoke-virtual {v1, v2, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->border:J

    .line 82
    .line 83
    invoke-static {v5, v8, v4, v0, v1}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    if-eqz v11, :cond_4

    .line 88
    .line 89
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 90
    .line 91
    invoke-static {v0, v6, v11}, LX/3Rs;->A08(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    if-nez v0, :cond_5

    .line 96
    .line 97
    :cond_4
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 98
    .line 99
    :cond_5
    invoke-interface {v1, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 104
    .line 105
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    shl-int/lit8 v0, v3, 0x3

    .line 110
    .line 111
    and-int/lit16 v9, v0, 0x1c00

    .line 112
    .line 113
    invoke-static {v2}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    move-object v6, v2

    .line 118
    check-cast v6, LX/J7I;

    .line 119
    .line 120
    invoke-static {v6}, LX/003;->A0F(LX/J7I;)I

    .line 121
    .line 122
    .line 123
    move-result v5

    .line 124
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    invoke-static {v2, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 133
    .line 134
    iget-object v0, v6, LX/J7I;->A0V:LX/3DJ;

    .line 135
    .line 136
    if-nez v0, :cond_9

    .line 137
    .line 138
    invoke-static {}, LX/1VY;->A00()V

    .line 139
    .line 140
    .line 141
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    throw v0

    .line 146
    :cond_6
    and-int/lit8 v0, p4, 0x30

    .line 147
    .line 148
    if-nez v0, :cond_0

    .line 149
    .line 150
    invoke-static {v2, v11}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    or-int/2addr v3, v0

    .line 155
    goto/16 :goto_1

    .line 156
    .line 157
    :cond_7
    and-int/lit8 v0, p4, 0x6

    .line 158
    .line 159
    if-nez v0, :cond_8

    .line 160
    .line 161
    invoke-static {v2, v10}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 162
    .line 163
    .line 164
    move-result v3

    .line 165
    or-int v3, v3, p4

    .line 166
    .line 167
    goto/16 :goto_0

    .line 168
    .line 169
    :cond_8
    move v3, p0

    .line 170
    goto/16 :goto_0

    .line 171
    .line 172
    :cond_9
    invoke-static {v2, v6, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v2, v8, v4, v3, v5}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 176
    .line 177
    .line 178
    sget-object v1, LX/CgJ;->A00:LX/CgJ;

    .line 179
    .line 180
    shr-int/2addr v9, v7

    .line 181
    and-int/lit8 v0, v9, 0x70

    .line 182
    .line 183
    or-int/lit8 v0, v0, 0x6

    .line 184
    .line 185
    invoke-static {v1, v2, p2, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 186
    .line 187
    .line 188
    const/4 v0, 0x1

    .line 189
    invoke-static {v6, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 190
    .line 191
    .line 192
    goto :goto_2

    .line 193
    :cond_a
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 194
    .line 195
    .line 196
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    if-eqz v0, :cond_b

    .line 201
    .line 202
    new-instance v9, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureCard$2;

    .line 203
    .line 204
    invoke-direct/range {v9 .. v14}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureCard$2;-><init>(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;II)V

    .line 205
    .line 206
    .line 207
    iput-object v9, v0, LX/J7V;->A06:LX/JDN;

    .line 208
    .line 209
    :cond_b
    return-void
.end method

.method public static final DisclosureContent(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V
    .locals 37

    .line 0
    move-object/from16 v15, p3

    .line 1
    .line 2
    const v0, -0x6ca6c93e

    .line 3
    .line 4
    .line 5
    move-object/from16 v7, p4

    .line 6
    .line 7
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v6, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v9, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v7, v9}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    or-int v5, v5, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move/from16 v19, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move/from16 v0, v19

    .line 31
    .line 32
    invoke-static {v7, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v5, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v6, 0x180

    .line 38
    .line 39
    move-object/from16 p5, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    move-object/from16 v0, p5

    .line 44
    .line 45
    invoke-static {v7, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v5, v0

    .line 50
    :cond_1
    move/from16 p2, p6

    .line 51
    .line 52
    and-int/lit8 v2, p6, 0x8

    .line 53
    .line 54
    if-eqz v2, :cond_5

    .line 55
    .line 56
    or-int/lit16 v5, v5, 0xc00

    .line 57
    .line 58
    :cond_2
    :goto_1
    and-int/lit16 v1, v5, 0x493

    .line 59
    .line 60
    const/16 v0, 0x492

    .line 61
    .line 62
    const/16 v18, 0x1

    .line 63
    .line 64
    const/4 v4, 0x0

    .line 65
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    invoke-static {v0, v7, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-eqz v0, :cond_a

    .line 74
    .line 75
    if-eqz v2, :cond_3

    .line 76
    .line 77
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 78
    .line 79
    :cond_3
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 80
    .line 81
    const/4 v0, 0x6

    .line 82
    invoke-virtual {v1, v7, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 83
    .line 84
    .line 85
    move-result-object v16

    .line 86
    if-eqz p0, :cond_4

    .line 87
    .line 88
    iget-object v13, v9, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureTitle:Ljava/lang/String;

    .line 89
    .line 90
    if-eqz v13, :cond_4

    .line 91
    .line 92
    invoke-static {v13}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    if-nez v2, :cond_4

    .line 97
    .line 98
    const v2, 0x21e6ac7a

    .line 99
    .line 100
    .line 101
    invoke-interface {v7, v2}, LX/2d4;->Agj(I)V

    .line 102
    .line 103
    .line 104
    :goto_2
    invoke-static {v7}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    and-int/lit8 v2, v5, 0xe

    .line 109
    .line 110
    invoke-static {v9, v7, v2}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->rememberDisclosureSections(Lcom/facebook/aura/activation/data/HatchTosMetadata;LX/2d4;I)Ljava/util/List;

    .line 111
    .line 112
    .line 113
    move-result-object v17

    .line 114
    sget-object v2, LX/2Id;->A00:LX/2sS;

    .line 115
    .line 116
    invoke-static {v7, v2}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 117
    .line 118
    .line 119
    move-result-object v14

    .line 120
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 121
    .line 122
    .line 123
    move-result v12

    .line 124
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 125
    .line 126
    .line 127
    move-result-object v11

    .line 128
    invoke-static {v7, v15}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 129
    .line 130
    .line 131
    move-result-object v10

    .line 132
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 133
    .line 134
    iget-object v2, v3, LX/J7I;->A0V:LX/3DJ;

    .line 135
    .line 136
    if-nez v2, :cond_7

    .line 137
    .line 138
    invoke-static {}, LX/1VY;->A00()V

    .line 139
    .line 140
    .line 141
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    throw v0

    .line 146
    :cond_4
    const v2, 0x21e6b4f4

    .line 147
    .line 148
    .line 149
    invoke-interface {v7, v2}, LX/2d4;->Agj(I)V

    .line 150
    .line 151
    .line 152
    const v2, 0x7f1202cf

    .line 153
    .line 154
    .line 155
    invoke-static {v7, v2}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v13

    .line 159
    goto :goto_2

    .line 160
    :cond_5
    and-int/lit16 v0, v6, 0xc00

    .line 161
    .line 162
    if-nez v0, :cond_2

    .line 163
    .line 164
    invoke-static {v7, v15}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    or-int/2addr v5, v0

    .line 169
    goto :goto_1

    .line 170
    :cond_6
    move v5, v6

    .line 171
    goto/16 :goto_0

    .line 172
    .line 173
    :cond_7
    invoke-static {v7, v3, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 174
    .line 175
    .line 176
    invoke-static {v7, v14, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 177
    .line 178
    .line 179
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 180
    .line 181
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXHugePlus:F

    .line 182
    .line 183
    invoke-static {v7, v2, v8}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 184
    .line 185
    .line 186
    const v8, 0x7f0801e0

    .line 187
    .line 188
    .line 189
    const/4 v12, 0x2

    .line 190
    invoke-static {v7, v8, v4}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 191
    .line 192
    .line 193
    move-result-object v24

    .line 194
    invoke-virtual {v1, v7, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 195
    .line 196
    .line 197
    move-result-object v8

    .line 198
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->icon:Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;

    .line 199
    .line 200
    iget v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;->xLarge:F

    .line 201
    .line 202
    invoke-static {v2, v8}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 203
    .line 204
    .line 205
    move-result-object v22

    .line 206
    sget v8, LX/2l9;->$stable:I

    .line 207
    .line 208
    or-int/lit8 v28, v8, 0x30

    .line 209
    .line 210
    const/16 v29, 0x78

    .line 211
    .line 212
    const/4 v11, 0x0

    .line 213
    const/4 v8, 0x0

    .line 214
    move-object/from16 v20, v7

    .line 215
    .line 216
    move-object/from16 v21, v11

    .line 217
    .line 218
    move-object/from16 v23, v11

    .line 219
    .line 220
    move-object/from16 v25, v11

    .line 221
    .line 222
    move-object/from16 v26, v11

    .line 223
    .line 224
    move/from16 v27, v8

    .line 225
    .line 226
    invoke-static/range {v20 .. v29}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 227
    .line 228
    .line 229
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 230
    .line 231
    invoke-static {v7, v2, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v1, v7, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Medium:LX/2hg;

    .line 239
    .line 240
    move-object/from16 v20, v0

    .line 241
    .line 242
    move-object/from16 v0, v16

    .line 243
    .line 244
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 245
    .line 246
    move-wide/from16 p3, v0

    .line 247
    .line 248
    const/16 v16, 0x3

    .line 249
    .line 250
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 251
    .line 252
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 257
    .line 258
    if-ne v1, v0, :cond_8

    .line 259
    .line 260
    sget-object v1, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureContent$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureContent$1$1$1;

    .line 261
    .line 262
    invoke-interface {v7, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    :cond_8
    invoke-static {v14, v1, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 266
    .line 267
    .line 268
    move-result-object v21

    .line 269
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 270
    .line 271
    .line 272
    move-result-object v27

    .line 273
    const/16 p1, 0x3fb0

    .line 274
    .line 275
    move-object/from16 v24, v20

    .line 276
    .line 277
    move/from16 v28, v4

    .line 278
    .line 279
    move/from16 v29, v4

    .line 280
    .line 281
    move/from16 v30, v4

    .line 282
    .line 283
    move/from16 v31, v4

    .line 284
    .line 285
    move-object/from16 v32, v11

    .line 286
    .line 287
    move-object/from16 v33, v11

    .line 288
    .line 289
    move-object/from16 v34, v11

    .line 290
    .line 291
    move-object/from16 v35, v7

    .line 292
    .line 293
    move/from16 v36, v4

    .line 294
    .line 295
    move/from16 p0, v4

    .line 296
    .line 297
    move-object/from16 v20, v13

    .line 298
    .line 299
    move-wide/from16 v22, p3

    .line 300
    .line 301
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 302
    .line 303
    .line 304
    invoke-static {v7, v2, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 305
    .line 306
    .line 307
    move-object/from16 v0, v17

    .line 308
    .line 309
    invoke-static {v0, v11, v7, v4, v12}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureValuePropCard(Ljava/util/List;LX/3C1;LX/2d4;II)V

    .line 310
    .line 311
    .line 312
    if-eqz v19, :cond_9

    .line 313
    .line 314
    const v0, -0x2caee95e

    .line 315
    .line 316
    .line 317
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 318
    .line 319
    .line 320
    invoke-static {v7, v2, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 321
    .line 322
    .line 323
    shr-int/lit8 v0, v5, 0x6

    .line 324
    .line 325
    and-int/lit8 v1, v0, 0xe

    .line 326
    .line 327
    move-object/from16 v0, p5

    .line 328
    .line 329
    invoke-static {v0, v11, v7, v1, v12}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureSubscriptionUpgradeCard(Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V

    .line 330
    .line 331
    .line 332
    :goto_3
    invoke-static {v3, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 333
    .line 334
    .line 335
    invoke-static {v2, v8, v10, v8, v8}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    invoke-static {v0, v7, v4, v4}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt;->AuraDisclosureInfoBanner(LX/3C1;LX/2d4;II)V

    .line 340
    .line 341
    .line 342
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 343
    .line 344
    move/from16 v0, v18

    .line 345
    .line 346
    invoke-static {v7, v3, v2, v1, v0}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 347
    .line 348
    .line 349
    goto :goto_4

    .line 350
    :cond_9
    const v0, -0x2cacead6

    .line 351
    .line 352
    .line 353
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 354
    .line 355
    .line 356
    goto :goto_3

    .line 357
    :cond_a
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 358
    .line 359
    .line 360
    :goto_4
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    if-eqz v1, :cond_b

    .line 365
    .line 366
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureContent$2;

    .line 367
    .line 368
    move-object/from16 v33, v0

    .line 369
    .line 370
    move-object/from16 v34, v9

    .line 371
    .line 372
    move/from16 v35, v19

    .line 373
    .line 374
    move-object/from16 v36, p5

    .line 375
    .line 376
    move-object/from16 p0, v15

    .line 377
    .line 378
    move/from16 p1, v6

    .line 379
    .line 380
    invoke-direct/range {v33 .. v39}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureContent$2;-><init>(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;II)V

    .line 381
    .line 382
    .line 383
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 384
    .line 385
    :cond_b
    return-void
.end method

.method public static final DisclosureLegalText-5TldRvM(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v10, p3

    .line 1
    .line 2
    const v0, 0x17c4ef55

    .line 3
    .line 4
    .line 5
    move-object/from16 v11, p4

    .line 6
    .line 7
    invoke-interface {v11, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    if-nez v0, :cond_6

    .line 15
    .line 16
    invoke-static {v11, p0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v4

    .line 20
    or-int v4, v4, p5

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 23
    .line 24
    move v8, p1

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    invoke-static {v11, p1}, LX/004;->A0F(LX/2d4;I)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    or-int/2addr v4, v0

    .line 32
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 33
    .line 34
    move-object/from16 v9, p2

    .line 35
    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    invoke-static {v11, v9}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v4, v0

    .line 43
    :cond_1
    move/from16 p5, p6

    .line 44
    .line 45
    and-int/lit8 v2, p6, 0x8

    .line 46
    .line 47
    if-eqz v2, :cond_5

    .line 48
    .line 49
    or-int/lit16 v4, v4, 0xc00

    .line 50
    .line 51
    :cond_2
    :goto_1
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v11, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_8

    .line 60
    .line 61
    if-eqz v2, :cond_3

    .line 62
    .line 63
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_3
    if-eqz p0, :cond_7

    .line 66
    .line 67
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-lez v0, :cond_7

    .line 74
    .line 75
    const v0, 0xe8b1321

    .line 76
    .line 77
    .line 78
    invoke-interface {v11, v0}, LX/2d4;->Agj(I)V

    .line 79
    .line 80
    .line 81
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 82
    .line 83
    invoke-interface {v11, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    if-nez v0, :cond_4

    .line 92
    .line 93
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 94
    .line 95
    if-ne v7, v0, :cond_a

    .line 96
    .line 97
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureEntities:Ljava/util/List;

    .line 98
    .line 99
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 100
    .line 101
    .line 102
    move-result-object v7

    .line 103
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 104
    .line 105
    .line 106
    move-result-object v6

    .line 107
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_9

    .line 112
    .line 113
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    check-cast v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;

    .line 118
    .line 119
    iget v5, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->offset:I

    .line 120
    .line 121
    iget v3, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->length:I

    .line 122
    .line 123
    iget-object v2, v0, Lcom/facebook/aura/activation/data/HatchDisclosureEntity;->url:Ljava/lang/String;

    .line 124
    .line 125
    new-instance v0, Lcom/facebook/aura/linktext/HatchTextLink;

    .line 126
    .line 127
    invoke-direct {v0, v5, v3, v2}, Lcom/facebook/aura/linktext/HatchTextLink;-><init>(IILjava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_5
    and-int/lit16 v0, v1, 0xc00

    .line 135
    .line 136
    if-nez v0, :cond_2

    .line 137
    .line 138
    invoke-static {v11, v10}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    or-int/2addr v4, v0

    .line 143
    goto :goto_1

    .line 144
    :cond_6
    move v4, v1

    .line 145
    goto :goto_0

    .line 146
    :cond_7
    const v0, 0xe908bb3

    .line 147
    .line 148
    .line 149
    invoke-interface {v11, v0}, LX/2d4;->Agj(I)V

    .line 150
    .line 151
    .line 152
    shr-int/lit8 v0, v4, 0x3

    .line 153
    .line 154
    and-int/lit16 v12, v0, 0x3fe

    .line 155
    .line 156
    const/4 v13, 0x0

    .line 157
    invoke-static/range {v8 .. v13}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->LegalText-KE6awZw(ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 158
    .line 159
    .line 160
    goto :goto_3

    .line 161
    :cond_8
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 162
    .line 163
    .line 164
    goto :goto_4

    .line 165
    :cond_9
    invoke-interface {v11, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    :cond_a
    check-cast v7, Ljava/util/List;

    .line 169
    .line 170
    iget-object v6, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureText:Ljava/lang/String;

    .line 171
    .line 172
    shl-int/lit8 v12, v4, 0x3

    .line 173
    .line 174
    const v0, 0xff80

    .line 175
    .line 176
    .line 177
    and-int/2addr v12, v0

    .line 178
    const/4 v13, 0x0

    .line 179
    invoke-static/range {v6 .. v13}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DynamicLegalText-D30ufTU(Ljava/lang/String;Ljava/util/List;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 180
    .line 181
    .line 182
    :goto_3
    invoke-static {v11}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    :goto_4
    invoke-interface {v11}, LX/2d4;->AAg()LX/J7V;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    if-eqz v0, :cond_b

    .line 190
    .line 191
    new-instance v13, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureLegalText$1;

    .line 192
    .line 193
    move-object/from16 p3, v10

    .line 194
    .line 195
    move/from16 p4, v1

    .line 196
    .line 197
    invoke-direct/range {v13 .. v19}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureLegalText$1;-><init>(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;II)V

    .line 198
    .line 199
    .line 200
    iput-object v13, v0, LX/J7V;->A06:LX/JDN;

    .line 201
    .line 202
    :cond_b
    return-void
.end method

.method public static final DisclosureScrollFade(LX/3Lr;LX/3C1;LX/2d4;II)V
    .locals 6

    .line 0
    const v0, -0x440fe54e

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v0, p3, 0x6

    .line 7
    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    or-int/2addr v4, p3

    .line 15
    :goto_0
    and-int/lit8 v2, p4, 0x2

    .line 16
    .line 17
    if-eqz v2, :cond_9

    .line 18
    .line 19
    or-int/lit8 v4, v4, 0x30

    .line 20
    .line 21
    :cond_0
    :goto_1
    and-int/lit8 v1, v4, 0x13

    .line 22
    .line 23
    const/16 v0, 0x12

    .line 24
    .line 25
    const/4 v3, 0x0

    .line 26
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, p2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_8

    .line 35
    .line 36
    if-eqz v2, :cond_1

    .line 37
    .line 38
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 39
    .line 40
    :cond_1
    invoke-static {v4}, LX/008;->A1X(I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    if-nez v0, :cond_2

    .line 49
    .line 50
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 51
    .line 52
    if-ne v1, v0, :cond_3

    .line 53
    .line 54
    :cond_2
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$hasMoreBelow$2$1;

    .line 55
    .line 56
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$hasMoreBelow$2$1;-><init>(LX/3Lr;)V

    .line 57
    .line 58
    .line 59
    invoke-static {p2, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    :cond_3
    check-cast v1, LX/16A;

    .line 64
    .line 65
    invoke-static {v1}, LX/16A;->A0C(LX/16A;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_5

    .line 70
    .line 71
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    if-eqz v1, :cond_4

    .line 76
    .line 77
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$1;

    .line 78
    .line 79
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$1;-><init>(LX/3Lr;LX/3C1;II)V

    .line 80
    .line 81
    .line 82
    :goto_2
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :cond_4
    return-void

    .line 86
    :cond_5
    invoke-static {p2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 91
    .line 92
    invoke-interface {p2, v0, v1}, LX/2d4;->A68(J)Z

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    if-nez v4, :cond_6

    .line 101
    .line 102
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 103
    .line 104
    if-ne v2, v4, :cond_7

    .line 105
    .line 106
    :cond_6
    sget-wide v4, LX/JOw;->A06:J

    .line 107
    .line 108
    invoke-static {v4, v5}, LX/001;->A0d(J)LX/JOw;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-static {v2, v0, v1}, LX/005;->A0p(LX/JOw;J)Ljava/util/List;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    const/4 v1, 0x0

    .line 117
    const/high16 v0, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 118
    .line 119
    invoke-static {v2, v1, v0}, LX/2hZ;->A02(Ljava/util/List;FF)LX/2hU;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    invoke-interface {p2, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_7
    check-cast v2, LX/2hZ;

    .line 127
    .line 128
    invoke-static {p1}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 133
    .line 134
    invoke-static {v1, v0}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    sget-object v0, LX/2oZ;->A00:LX/2bW;

    .line 139
    .line 140
    invoke-static {v1, v2, v0}, LX/2pC;->A02(LX/3C1;LX/2hZ;LX/2bW;)LX/3C1;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    invoke-static {v0, p2, v3}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 145
    .line 146
    .line 147
    goto :goto_3

    .line 148
    :cond_8
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 149
    .line 150
    .line 151
    :goto_3
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    if-eqz v1, :cond_4

    .line 156
    .line 157
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$2;

    .line 158
    .line 159
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureScrollFade$2;-><init>(LX/3Lr;LX/3C1;II)V

    .line 160
    .line 161
    .line 162
    goto :goto_2

    .line 163
    :cond_9
    and-int/lit8 v0, p3, 0x30

    .line 164
    .line 165
    if-nez v0, :cond_0

    .line 166
    .line 167
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    or-int/2addr v4, v0

    .line 172
    goto/16 :goto_1

    .line 173
    .line 174
    :cond_a
    move v4, p3

    .line 175
    goto/16 :goto_0
.end method

.method public static final DisclosureScrollFade$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final DisclosureSubscriptionUpgradeCard(Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V
    .locals 17

    .line 0
    move-object/from16 v7, p1

    .line 1
    .line 2
    const v1, 0x6812fc17

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p2

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p3

    .line 11
    .line 12
    and-int/lit8 v3, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    if-nez v3, :cond_7

    .line 17
    .line 18
    invoke-static {v0, v2}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    or-int v6, v6, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v4, p4

    .line 25
    .line 26
    and-int/lit8 v5, p4, 0x2

    .line 27
    .line 28
    if-eqz v5, :cond_6

    .line 29
    .line 30
    or-int/lit8 v6, v6, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    invoke-static {v6}, LX/005;->A1G(I)Z

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    invoke-static {v3, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    if-eqz v3, :cond_5

    .line 41
    .line 42
    if-eqz v5, :cond_1

    .line 43
    .line 44
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 45
    .line 46
    :cond_1
    invoke-static {v0}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    sget-object v8, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 51
    .line 52
    sget-object v9, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 53
    .line 54
    sget-object v10, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 55
    .line 56
    sget-object v11, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 57
    .line 58
    sget-object v12, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CVM_OFFER_CARD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 59
    .line 60
    invoke-virtual {v12}, Lcom/facebook/aura/analytics/hatch/HatchComponent;->getValue()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p3

    .line 64
    const/4 v13, 0x0

    .line 65
    const-wide/16 v16, 0x1f4

    .line 66
    .line 67
    const/16 p1, 0x0

    .line 68
    .line 69
    move-object v14, v13

    .line 70
    move-object v15, v13

    .line 71
    move-object/from16 p2, v13

    .line 72
    .line 73
    move-object/from16 p4, v13

    .line 74
    .line 75
    invoke-static/range {v7 .. v21}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 76
    .line 77
    .line 78
    move-result-object v8

    .line 79
    invoke-interface {v0, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    if-nez v5, :cond_2

    .line 88
    .line 89
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 90
    .line 91
    if-ne v6, v5, :cond_3

    .line 92
    .line 93
    :cond_2
    new-instance v6, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$1$1;

    .line 94
    .line 95
    invoke-direct {v6, v3}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 96
    .line 97
    .line 98
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :cond_3
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 102
    .line 103
    new-instance v5, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;

    .line 104
    .line 105
    invoke-direct {v5, v2}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;-><init>(Lcom/facebook/aura/activation/data/HatchUpsellCell;)V

    .line 106
    .line 107
    .line 108
    const v3, -0x36498325

    .line 109
    .line 110
    .line 111
    invoke-static {v0, v5, v3}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 112
    .line 113
    .line 114
    move-result-object v10

    .line 115
    const/16 v12, 0x180

    .line 116
    .line 117
    const/4 v13, 0x0

    .line 118
    move-object v9, v6

    .line 119
    move-object v11, v0

    .line 120
    invoke-static/range {v8 .. v13}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureCard(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;II)V

    .line 121
    .line 122
    .line 123
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 124
    .line 125
    .line 126
    move-result-object v3

    .line 127
    if-eqz v3, :cond_4

    .line 128
    .line 129
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$3;

    .line 130
    .line 131
    invoke-direct {v0, v2, v7, v1, v4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$3;-><init>(Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;II)V

    .line 132
    .line 133
    .line 134
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 135
    .line 136
    :cond_4
    return-void

    .line 137
    :cond_5
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 138
    .line 139
    .line 140
    goto :goto_2

    .line 141
    :cond_6
    and-int/lit8 v3, p3, 0x30

    .line 142
    .line 143
    if-nez v3, :cond_0

    .line 144
    .line 145
    invoke-static {v0, v7}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 146
    .line 147
    .line 148
    move-result v3

    .line 149
    or-int/2addr v6, v3

    .line 150
    goto :goto_1

    .line 151
    :cond_7
    move v6, v1

    .line 152
    goto :goto_0
.end method

.method public static final DisclosureValuePropCard(Ljava/util/List;LX/3C1;LX/2d4;II)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v3, p1

    .line 1
    const v0, 0x5e3b8af5

    .line 2
    .line 3
    .line 4
    move-object v6, p2

    .line 5
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    and-int/lit8 v0, p3, 0x6

    .line 9
    .line 10
    if-nez v0, :cond_5

    .line 11
    .line 12
    invoke-static {p0, p2, p3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {v0}, LX/003;->A06(I)I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    or-int/2addr v2, p3

    .line 21
    :goto_0
    and-int/lit8 v1, p4, 0x2

    .line 22
    .line 23
    if-eqz v1, :cond_4

    .line 24
    .line 25
    or-int/lit8 v2, v2, 0x30

    .line 26
    .line 27
    :cond_0
    :goto_1
    invoke-static {v2}, LX/005;->A1G(I)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    invoke-static {v0, p2, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_3

    .line 36
    .line 37
    if-eqz v1, :cond_1

    .line 38
    .line 39
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 40
    .line 41
    :cond_1
    new-instance v1, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;

    .line 42
    .line 43
    invoke-direct {v1, p0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;-><init>(Ljava/util/List;)V

    .line 44
    .line 45
    .line 46
    const v0, -0x23d3684f

    .line 47
    .line 48
    .line 49
    invoke-static {p2, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    shr-int/lit8 v0, v2, 0x3

    .line 54
    .line 55
    and-int/lit8 v0, v0, 0xe

    .line 56
    .line 57
    or-int/lit16 v7, v0, 0x180

    .line 58
    .line 59
    const/4 v8, 0x2

    .line 60
    const/4 v4, 0x0

    .line 61
    invoke-static/range {v3 .. v8}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureCard(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;II)V

    .line 62
    .line 63
    .line 64
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    if-eqz v1, :cond_2

    .line 69
    .line 70
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$2;

    .line 71
    .line 72
    invoke-direct {v0, p0, v3, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$2;-><init>(Ljava/util/List;LX/3C1;II)V

    .line 73
    .line 74
    .line 75
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 76
    .line 77
    :cond_2
    return-void

    .line 78
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 79
    .line 80
    .line 81
    goto :goto_2

    .line 82
    :cond_4
    and-int/lit8 v0, p3, 0x30

    .line 83
    .line 84
    if-nez v0, :cond_0

    .line 85
    .line 86
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    or-int/2addr v2, v0

    .line 91
    goto :goto_1

    .line 92
    :cond_5
    move v2, p3

    .line 93
    goto :goto_0
.end method

.method public static final DisclosureValuePropRow(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V
    .locals 39

    .line 0
    move-object/from16 v22, p3

    .line 1
    .line 2
    move/from16 v20, p4

    .line 3
    .line 4
    const v1, -0xcbd7b1a

    .line 5
    .line 6
    .line 7
    move-object/from16 v0, p5

    .line 8
    .line 9
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v6, p6

    .line 13
    .line 14
    and-int/lit8 v1, p6, 0x6

    .line 15
    .line 16
    move-object/from16 v23, p0

    .line 17
    .line 18
    if-nez v1, :cond_7

    .line 19
    .line 20
    move-object/from16 v1, v23

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    or-int v2, v2, p6

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v1, p6, 0x30

    .line 29
    .line 30
    move-object/from16 p6, p1

    .line 31
    .line 32
    if-nez v1, :cond_0

    .line 33
    .line 34
    move-object/from16 v1, p6

    .line 35
    .line 36
    invoke-static {v0, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    or-int/2addr v2, v1

    .line 41
    :cond_0
    and-int/lit16 v1, v6, 0x180

    .line 42
    .line 43
    move-object/from16 p5, p2

    .line 44
    .line 45
    if-nez v1, :cond_1

    .line 46
    .line 47
    move-object/from16 v1, p5

    .line 48
    .line 49
    invoke-static {v0, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    or-int/2addr v2, v1

    .line 54
    :cond_1
    move/from16 p4, p7

    .line 55
    .line 56
    and-int/lit8 v5, p7, 0x8

    .line 57
    .line 58
    if-eqz v5, :cond_6

    .line 59
    .line 60
    or-int/lit16 v2, v2, 0xc00

    .line 61
    .line 62
    :cond_2
    :goto_1
    and-int/lit8 v4, p7, 0x10

    .line 63
    .line 64
    if-eqz v4, :cond_5

    .line 65
    .line 66
    or-int/lit16 v2, v2, 0x6000

    .line 67
    .line 68
    :cond_3
    :goto_2
    and-int/lit16 v3, v2, 0x2493

    .line 69
    .line 70
    const/16 v1, 0x2492

    .line 71
    .line 72
    const/16 v21, 0x0

    .line 73
    .line 74
    invoke-static {v3, v1}, LX/003;->A1H(II)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    invoke-static {v1, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-eqz v1, :cond_8

    .line 83
    .line 84
    if-eqz v5, :cond_4

    .line 85
    .line 86
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 87
    .line 88
    :cond_4
    move/from16 v1, v20

    .line 89
    .line 90
    invoke-static {v4, v1}, LX/001;->A1P(IZ)Z

    .line 91
    .line 92
    .line 93
    move-result v20

    .line 94
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 95
    .line 96
    const/4 v5, 0x6

    .line 97
    invoke-virtual {v4, v0, v5}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 98
    .line 99
    .line 100
    move-result-object v7

    .line 101
    sget-object v3, LX/2Id;->A04:LX/2rU;

    .line 102
    .line 103
    invoke-static/range {v22 .. v22}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-static {v0, v3}, LX/003;->A0Z(LX/2d4;LX/2rU;)LX/3BI;

    .line 108
    .line 109
    .line 110
    move-result-object v10

    .line 111
    move-object v3, v0

    .line 112
    check-cast v3, LX/J7I;

    .line 113
    .line 114
    iget-wide v8, v3, LX/J7I;->A06:J

    .line 115
    .line 116
    invoke-static {v8, v9}, LX/001;->A0A(J)I

    .line 117
    .line 118
    .line 119
    move-result v13

    .line 120
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 121
    .line 122
    .line 123
    move-result-object v9

    .line 124
    invoke-static {v0, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 125
    .line 126
    .line 127
    move-result-object v8

    .line 128
    sget-object v12, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 129
    .line 130
    iget-object v1, v3, LX/J7I;->A0V:LX/3DJ;

    .line 131
    .line 132
    if-nez v1, :cond_9

    .line 133
    .line 134
    invoke-static {}, LX/1VY;->A00()V

    .line 135
    .line 136
    .line 137
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    throw v0

    .line 142
    :cond_5
    and-int/lit16 v1, v6, 0x6000

    .line 143
    .line 144
    if-nez v1, :cond_3

    .line 145
    .line 146
    move/from16 v1, v20

    .line 147
    .line 148
    invoke-static {v0, v1}, LX/004;->A0m(LX/2d4;Z)I

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    or-int/2addr v2, v1

    .line 153
    goto :goto_2

    .line 154
    :cond_6
    and-int/lit16 v1, v6, 0xc00

    .line 155
    .line 156
    if-nez v1, :cond_2

    .line 157
    .line 158
    move-object/from16 v1, v22

    .line 159
    .line 160
    invoke-static {v0, v1}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    or-int/2addr v2, v1

    .line 165
    goto :goto_1

    .line 166
    :cond_7
    move v2, v6

    .line 167
    goto/16 :goto_0

    .line 168
    .line 169
    :cond_8
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 170
    .line 171
    .line 172
    goto/16 :goto_5

    .line 173
    .line 174
    :cond_9
    invoke-static {v0, v3, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 175
    .line 176
    .line 177
    sget-object v14, LX/3Cl;->A04:LX/JDN;

    .line 178
    .line 179
    invoke-static {v0, v10, v14}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 180
    .line 181
    .line 182
    move-result-object v11

    .line 183
    invoke-static {v0, v9, v11, v13}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 184
    .line 185
    .line 186
    move-result-object v19

    .line 187
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 188
    .line 189
    invoke-static {v0, v8, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 190
    .line 191
    .line 192
    move-result-object v18

    .line 193
    sget-object v15, LX/CgK;->A00:LX/CgK;

    .line 194
    .line 195
    if-eqz p0, :cond_c

    .line 196
    .line 197
    const v8, -0x247ba8a7

    .line 198
    .line 199
    .line 200
    move-object/from16 v1, v23

    .line 201
    .line 202
    invoke-static {v0, v1, v8}, LX/3Rr;->A04(LX/2d4;Ljava/lang/Number;I)I

    .line 203
    .line 204
    .line 205
    move-result v1

    .line 206
    invoke-static {v0, v2, v1}, LX/603;->A0H(LX/2d4;II)LX/2l9;

    .line 207
    .line 208
    .line 209
    move-result-object v28

    .line 210
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 211
    .line 212
    invoke-virtual {v4, v0, v5}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 213
    .line 214
    .line 215
    move-result-object v8

    .line 216
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->icon:Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;

    .line 217
    .line 218
    iget v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;->xSmall:F

    .line 219
    .line 220
    invoke-static {v1, v8}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 221
    .line 222
    .line 223
    move-result-object v26

    .line 224
    const/16 v25, 0x0

    .line 225
    .line 226
    iget-object v8, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 227
    .line 228
    iget-wide v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 229
    .line 230
    invoke-static {v8, v9}, LX/2hb;->A00(J)LX/2hb;

    .line 231
    .line 232
    .line 233
    move-result-object v27

    .line 234
    sget v8, LX/2l9;->$stable:I

    .line 235
    .line 236
    or-int/lit8 v32, v8, 0x30

    .line 237
    .line 238
    const/16 v33, 0x38

    .line 239
    .line 240
    const/16 v31, 0x0

    .line 241
    .line 242
    move-object/from16 v24, v0

    .line 243
    .line 244
    move-object/from16 v29, v25

    .line 245
    .line 246
    move-object/from16 v30, v25

    .line 247
    .line 248
    invoke-static/range {v24 .. v33}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 249
    .line 250
    .line 251
    :goto_3
    move/from16 v8, v21

    .line 252
    .line 253
    invoke-static {v3, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 254
    .line 255
    .line 256
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 257
    .line 258
    invoke-static {v0, v1, v8}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 259
    .line 260
    .line 261
    const/16 v25, 0x0

    .line 262
    .line 263
    const/high16 v13, 0x3f800000    # 1.0f

    .line 264
    .line 265
    const/4 v9, 0x1

    .line 266
    invoke-virtual {v15, v1, v13, v9}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 267
    .line 268
    .line 269
    move-result-object v13

    .line 270
    invoke-static {v0}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 271
    .line 272
    .line 273
    move-result-object v17

    .line 274
    invoke-static {v3}, LX/002;->A0J(LX/J7I;)I

    .line 275
    .line 276
    .line 277
    move-result v16

    .line 278
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 279
    .line 280
    .line 281
    move-result-object v15

    .line 282
    invoke-static {v0, v13}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 283
    .line 284
    .line 285
    move-result-object v13

    .line 286
    invoke-static {v0, v3, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 287
    .line 288
    .line 289
    move-object/from16 v12, v17

    .line 290
    .line 291
    invoke-static {v0, v12, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 292
    .line 293
    .line 294
    invoke-static {v0, v15, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 295
    .line 296
    .line 297
    move-object/from16 v12, v19

    .line 298
    .line 299
    move/from16 v11, v16

    .line 300
    .line 301
    invoke-static {v10, v12, v0, v11}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 302
    .line 303
    .line 304
    move-object/from16 v10, v18

    .line 305
    .line 306
    invoke-static {v0, v13, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 307
    .line 308
    .line 309
    invoke-static {v0, v4}, LX/07H;->A0M(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 310
    .line 311
    .line 312
    move-result-object v28

    .line 313
    iget-wide v10, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 314
    .line 315
    shr-int/lit8 v12, v2, 0x3

    .line 316
    .line 317
    and-int/lit8 p1, v12, 0xe

    .line 318
    .line 319
    const/16 p3, 0x3ff2

    .line 320
    .line 321
    move-object/from16 v24, p6

    .line 322
    .line 323
    move-wide/from16 v26, v10

    .line 324
    .line 325
    move-object/from16 v29, v25

    .line 326
    .line 327
    move-object/from16 v30, v25

    .line 328
    .line 329
    move-object/from16 v31, v25

    .line 330
    .line 331
    move/from16 v32, v21

    .line 332
    .line 333
    move/from16 v33, v21

    .line 334
    .line 335
    move/from16 v34, v21

    .line 336
    .line 337
    move/from16 v35, v21

    .line 338
    .line 339
    move-object/from16 v36, v25

    .line 340
    .line 341
    move-object/from16 v37, v25

    .line 342
    .line 343
    move-object/from16 v38, v25

    .line 344
    .line 345
    move-object/from16 p0, v0

    .line 346
    .line 347
    move/from16 p2, v21

    .line 348
    .line 349
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 350
    .line 351
    .line 352
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 353
    .line 354
    invoke-static {v0, v1, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 355
    .line 356
    .line 357
    invoke-static {v0, v4}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 358
    .line 359
    .line 360
    move-result-object v28

    .line 361
    iget-wide v10, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 362
    .line 363
    shr-int/lit8 v2, v2, 0x6

    .line 364
    .line 365
    and-int/lit8 p1, v2, 0xe

    .line 366
    .line 367
    move-object/from16 v24, p5

    .line 368
    .line 369
    move-wide/from16 v26, v10

    .line 370
    .line 371
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 372
    .line 373
    .line 374
    invoke-static {v3, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 375
    .line 376
    .line 377
    if-eqz v20, :cond_b

    .line 378
    .line 379
    const v2, -0x246d0261

    .line 380
    .line 381
    .line 382
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 383
    .line 384
    .line 385
    invoke-static {v0, v1, v8}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 386
    .line 387
    .line 388
    const v8, 0x7f0800ea

    .line 389
    .line 390
    .line 391
    move/from16 v2, v21

    .line 392
    .line 393
    invoke-static {v0, v8, v2}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 394
    .line 395
    .line 396
    move-result-object v28

    .line 397
    invoke-virtual {v4, v0, v5}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 398
    .line 399
    .line 400
    move-result-object v2

    .line 401
    iget-object v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->icon:Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;

    .line 402
    .line 403
    iget v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;->tiny:F

    .line 404
    .line 405
    invoke-static {v1, v2}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 406
    .line 407
    .line 408
    move-result-object v26

    .line 409
    iget-object v1, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 410
    .line 411
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 412
    .line 413
    invoke-static {v1, v2}, LX/2hb;->A00(J)LX/2hb;

    .line 414
    .line 415
    .line 416
    move-result-object v27

    .line 417
    sget v1, LX/2l9;->$stable:I

    .line 418
    .line 419
    or-int/lit8 v32, v1, 0x30

    .line 420
    .line 421
    const/16 v33, 0x38

    .line 422
    .line 423
    const/16 v31, 0x0

    .line 424
    .line 425
    move-object/from16 v24, v0

    .line 426
    .line 427
    invoke-static/range {v24 .. v33}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 428
    .line 429
    .line 430
    :goto_4
    move/from16 v1, v21

    .line 431
    .line 432
    invoke-static {v3, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 433
    .line 434
    .line 435
    invoke-static {v3, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 436
    .line 437
    .line 438
    :goto_5
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 439
    .line 440
    .line 441
    move-result-object v1

    .line 442
    if-eqz v1, :cond_a

    .line 443
    .line 444
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropRow$2;

    .line 445
    .line 446
    move-object/from16 v36, v0

    .line 447
    .line 448
    move-object/from16 v37, v23

    .line 449
    .line 450
    move-object/from16 v38, p6

    .line 451
    .line 452
    move-object/from16 p0, p5

    .line 453
    .line 454
    move-object/from16 p1, v22

    .line 455
    .line 456
    move/from16 p2, v20

    .line 457
    .line 458
    move/from16 p3, v6

    .line 459
    .line 460
    invoke-direct/range {v36 .. v43}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropRow$2;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZII)V

    .line 461
    .line 462
    .line 463
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 464
    .line 465
    :cond_a
    return-void

    .line 466
    :cond_b
    const v1, -0x2467f348

    .line 467
    .line 468
    .line 469
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 470
    .line 471
    .line 472
    goto :goto_4

    .line 473
    :cond_c
    const v1, -0x247571d8    # -7.79997E16f

    .line 474
    .line 475
    .line 476
    invoke-static {v0, v1}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 477
    .line 478
    .line 479
    move-result-object v1

    .line 480
    invoke-virtual {v4, v0, v5}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 481
    .line 482
    .line 483
    move-result-object v8

    .line 484
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->icon:Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;

    .line 485
    .line 486
    iget v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;->xSmall:F

    .line 487
    .line 488
    invoke-static {v1, v8}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 489
    .line 490
    .line 491
    move-result-object v8

    .line 492
    invoke-static {v0, v8}, LX/1Vt;->A04(LX/2d4;LX/3C1;)V

    .line 493
    .line 494
    .line 495
    goto/16 :goto_3
.end method

.method public static final DynamicLegalText-D30ufTU(Ljava/lang/String;Ljava/util/List;ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/linktext/HatchTextLink;",
            ">;I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v11, p0

    .line 1
    .line 2
    move-object/from16 v10, p1

    .line 3
    .line 4
    move-object/from16 v9, p4

    .line 5
    .line 6
    invoke-static {v11, v10}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result p4

    .line 10
    const/4 v0, 0x3

    .line 11
    move-object/from16 v14, p3

    .line 12
    .line 13
    invoke-static {v14, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    const v0, 0x2b6a7873

    .line 17
    .line 18
    .line 19
    move-object/from16 v8, p5

    .line 20
    .line 21
    invoke-interface {v8, v0}, LX/2d4;->Agl(I)V

    .line 22
    .line 23
    .line 24
    move/from16 v7, p6

    .line 25
    .line 26
    and-int/lit8 v0, p6, 0x6

    .line 27
    .line 28
    const/4 v6, 0x4

    .line 29
    if-nez v0, :cond_10

    .line 30
    .line 31
    invoke-static {v8, v11}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    or-int v5, v5, p6

    .line 36
    .line 37
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 38
    .line 39
    const/16 v4, 0x20

    .line 40
    .line 41
    if-nez v0, :cond_0

    .line 42
    .line 43
    invoke-static {v10, v8, v7}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0}, LX/003;->A07(I)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v5, v0

    .line 52
    :cond_0
    and-int/lit16 v0, v7, 0x180

    .line 53
    .line 54
    move/from16 v15, p2

    .line 55
    .line 56
    if-nez v0, :cond_1

    .line 57
    .line 58
    invoke-static {v8, v15}, LX/004;->A0G(LX/2d4;I)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    or-int/2addr v5, v0

    .line 63
    :cond_1
    and-int/lit16 v0, v7, 0xc00

    .line 64
    .line 65
    if-nez v0, :cond_2

    .line 66
    .line 67
    invoke-static {v8, v14}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    or-int/2addr v5, v0

    .line 72
    :cond_2
    move/from16 p5, p7

    .line 73
    .line 74
    and-int/lit8 v1, p7, 0x10

    .line 75
    .line 76
    if-eqz v1, :cond_f

    .line 77
    .line 78
    or-int/lit16 v5, v5, 0x6000

    .line 79
    .line 80
    :cond_3
    :goto_1
    invoke-static {v5}, LX/009;->A1I(I)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    invoke-static {v0, v8, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_e

    .line 89
    .line 90
    if-eqz v1, :cond_4

    .line 91
    .line 92
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 93
    .line 94
    :cond_4
    invoke-static {v8}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 95
    .line 96
    .line 97
    move-result-object v13

    .line 98
    iget-wide v0, v13, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 99
    .line 100
    and-int/lit8 v3, v5, 0xe

    .line 101
    .line 102
    invoke-static {v3, v6}, LX/003;->A1I(II)Z

    .line 103
    .line 104
    .line 105
    move-result v12

    .line 106
    and-int/lit8 v2, v5, 0x70

    .line 107
    .line 108
    if-eq v2, v4, :cond_5

    .line 109
    .line 110
    and-int/lit8 v16, v5, 0x40

    .line 111
    .line 112
    if-eqz v16, :cond_d

    .line 113
    .line 114
    invoke-interface {v8, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v16

    .line 118
    if-eqz v16, :cond_d

    .line 119
    .line 120
    :cond_5
    const/16 v16, 0x1

    .line 121
    .line 122
    :goto_2
    or-int v12, v12, v16

    .line 123
    .line 124
    invoke-static {v8, v0, v1, v12}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    invoke-interface {v8}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    if-nez v1, :cond_6

    .line 133
    .line 134
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 135
    .line 136
    if-ne v0, v1, :cond_7

    .line 137
    .line 138
    :cond_6
    iget-wide v0, v13, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 139
    .line 140
    const/4 v12, 0x0

    .line 141
    invoke-static {v11, v10, v0, v1, v12}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->buildHatchLinkAnnotatedString-9LQNqLg(Ljava/lang/String;Ljava/util/List;JLX/2W8;)LX/2iK;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-interface {v8, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_7
    check-cast v0, LX/2iK;

    .line 149
    .line 150
    invoke-static {v3, v6}, LX/003;->A1I(II)Z

    .line 151
    .line 152
    .line 153
    move-result v3

    .line 154
    if-eq v2, v4, :cond_8

    .line 155
    .line 156
    and-int/lit8 v1, v5, 0x40

    .line 157
    .line 158
    if-eqz v1, :cond_c

    .line 159
    .line 160
    invoke-interface {v8, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    if-eqz v1, :cond_c

    .line 165
    .line 166
    :cond_8
    const/4 v1, 0x1

    .line 167
    :goto_3
    or-int/2addr v3, v1

    .line 168
    invoke-interface {v8}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    if-nez v3, :cond_9

    .line 173
    .line 174
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 175
    .line 176
    if-ne v2, v1, :cond_a

    .line 177
    .line 178
    :cond_9
    invoke-static {v11, v10}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->hatchLinkTitlesByUrl(Ljava/lang/String;Ljava/util/List;)Ljava/util/Map;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    invoke-interface {v8, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    :cond_a
    check-cast v2, Ljava/util/Map;

    .line 186
    .line 187
    const v1, 0xff80

    .line 188
    .line 189
    .line 190
    and-int/2addr v5, v1

    .line 191
    move/from16 p3, v5

    .line 192
    .line 193
    move-object/from16 p2, v8

    .line 194
    .line 195
    move-object/from16 p1, v9

    .line 196
    .line 197
    move/from16 v18, v15

    .line 198
    .line 199
    move-object/from16 p0, v14

    .line 200
    .line 201
    move-object/from16 v16, v0

    .line 202
    .line 203
    move-object/from16 v17, v2

    .line 204
    .line 205
    invoke-static/range {v16 .. v23}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 206
    .line 207
    .line 208
    :goto_4
    invoke-interface {v8}, LX/2d4;->AAg()LX/J7V;

    .line 209
    .line 210
    .line 211
    move-result-object v1

    .line 212
    if-eqz v1, :cond_b

    .line 213
    .line 214
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DynamicLegalText$1;

    .line 215
    .line 216
    move-object/from16 p0, v10

    .line 217
    .line 218
    move/from16 p1, v15

    .line 219
    .line 220
    move-object/from16 p2, v14

    .line 221
    .line 222
    move-object/from16 p3, v9

    .line 223
    .line 224
    move/from16 p4, v7

    .line 225
    .line 226
    move-object/from16 v17, v0

    .line 227
    .line 228
    move-object/from16 v18, v11

    .line 229
    .line 230
    invoke-direct/range {v17 .. v24}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DynamicLegalText$1;-><init>(Ljava/lang/String;Ljava/util/List;ILX/JDM;LX/3C1;II)V

    .line 231
    .line 232
    .line 233
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 234
    .line 235
    :cond_b
    return-void

    .line 236
    :cond_c
    const/4 v1, 0x0

    .line 237
    goto :goto_3

    .line 238
    :cond_d
    const/16 v16, 0x0

    .line 239
    .line 240
    goto :goto_2

    .line 241
    :cond_e
    invoke-interface {v8}, LX/2d4;->AgJ()V

    .line 242
    .line 243
    .line 244
    goto :goto_4

    .line 245
    :cond_f
    and-int/lit16 v0, v7, 0x6000

    .line 246
    .line 247
    if-nez v0, :cond_3

    .line 248
    .line 249
    invoke-static {v8, v9}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 250
    .line 251
    .line 252
    move-result v0

    .line 253
    or-int/2addr v5, v0

    .line 254
    goto/16 :goto_1

    .line 255
    .line 256
    :cond_10
    move v5, v7

    .line 257
    goto/16 :goto_0
.end method

.method public static final LegalText-KE6awZw(ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v20, p2

    .line 1
    .line 2
    const v0, 0x16cbe7d

    .line 3
    .line 4
    .line 5
    move-object/from16 v13, p3

    .line 6
    .line 7
    invoke-interface {v13, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v21, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move/from16 p2, p0

    .line 15
    .line 16
    if-nez v0, :cond_8

    .line 17
    .line 18
    move/from16 v0, p2

    .line 19
    .line 20
    invoke-static {v13, v0}, LX/004;->A0E(LX/2d4;I)I

    .line 21
    .line 22
    .line 23
    move-result v14

    .line 24
    or-int v14, v14, p4

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move-object/from16 v0, p1

    .line 31
    .line 32
    invoke-static {v13, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v14, v0

    .line 37
    :cond_0
    move/from16 p0, p5

    .line 38
    .line 39
    and-int/lit8 v2, p5, 0x4

    .line 40
    .line 41
    if-eqz v2, :cond_7

    .line 42
    .line 43
    or-int/lit16 v14, v14, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    and-int/lit16 v1, v14, 0x93

    .line 46
    .line 47
    const/16 v0, 0x92

    .line 48
    .line 49
    const/4 v12, 0x0

    .line 50
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0, v13, v14}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_a

    .line 59
    .line 60
    if-eqz v2, :cond_2

    .line 61
    .line 62
    sget-object v20, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    invoke-static {v13}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    const v0, 0x7f1202d3

    .line 69
    .line 70
    .line 71
    const-string v1, "Muse"

    .line 72
    .line 73
    invoke-static {v13, v1, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v11

    .line 77
    const v0, 0x7f1202d0

    .line 78
    .line 79
    .line 80
    invoke-static {v13, v1, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v19

    .line 84
    const v0, 0x7f1202d4

    .line 85
    .line 86
    .line 87
    invoke-static {v13, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v15

    .line 91
    const v0, 0x7f1202d5

    .line 92
    .line 93
    .line 94
    invoke-static {v13, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v10

    .line 98
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 103
    .line 104
    if-ne v9, v8, :cond_3

    .line 105
    .line 106
    sget-object v0, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->INSTANCE:Lcom/facebook/aura/settings/AuraExternalUriRegistry;

    .line 107
    .line 108
    invoke-virtual {v0}, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->getSupplementalTermsOfServiceUri()Lcom/facebook/aura/utils/navigation/SecureUri;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    iget-object v0, v0, Lcom/facebook/aura/utils/navigation/SecureUri;->uri:Landroid/net/Uri;

    .line 113
    .line 114
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v9

    .line 118
    invoke-interface {v13, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :cond_3
    check-cast v9, Ljava/lang/String;

    .line 122
    .line 123
    invoke-static {v9}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v7

    .line 130
    if-ne v7, v8, :cond_4

    .line 131
    .line 132
    sget-object v0, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->INSTANCE:Lcom/facebook/aura/settings/AuraExternalUriRegistry;

    .line 133
    .line 134
    invoke-virtual {v0}, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->getMetaAiTermsOfServiceUri()Lcom/facebook/aura/utils/navigation/SecureUri;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    iget-object v0, v0, Lcom/facebook/aura/utils/navigation/SecureUri;->uri:Landroid/net/Uri;

    .line 139
    .line 140
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v7

    .line 144
    invoke-interface {v13, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :cond_4
    check-cast v7, Ljava/lang/String;

    .line 148
    .line 149
    invoke-static {v7}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v6

    .line 156
    if-ne v6, v8, :cond_5

    .line 157
    .line 158
    sget-object v0, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->INSTANCE:Lcom/facebook/aura/settings/AuraExternalUriRegistry;

    .line 159
    .line 160
    invoke-virtual {v0}, Lcom/facebook/aura/settings/AuraExternalUriRegistry;->getPrivacyPolicyUri()Lcom/facebook/aura/utils/navigation/SecureUri;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    iget-object v0, v0, Lcom/facebook/aura/utils/navigation/SecureUri;->uri:Landroid/net/Uri;

    .line 165
    .line 166
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v6

    .line 170
    invoke-interface {v13, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_5
    check-cast v6, Ljava/lang/String;

    .line 174
    .line 175
    invoke-static {v6}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    iget-wide v0, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 179
    .line 180
    invoke-interface {v13, v11}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    move-result v4

    .line 184
    move-object/from16 v2, v19

    .line 185
    .line 186
    invoke-static {v13, v2, v15, v10, v4}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 187
    .line 188
    .line 189
    move-result v2

    .line 190
    invoke-interface {v13, v0, v1}, LX/2d4;->A68(J)Z

    .line 191
    .line 192
    .line 193
    move-result v0

    .line 194
    or-int/2addr v0, v2

    .line 195
    invoke-static {v13, v9, v7, v6, v0}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    if-nez v0, :cond_6

    .line 204
    .line 205
    if-ne v1, v8, :cond_c

    .line 206
    .line 207
    :cond_6
    iget-wide v0, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 208
    .line 209
    const/16 v18, 0x0

    .line 210
    .line 211
    move-object/from16 v3, v18

    .line 212
    .line 213
    invoke-static {v0, v1, v3, v3}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->hatchLinkStyles-ek8zF_U(JLX/2W8;LX/IzA;)LX/2iS;

    .line 214
    .line 215
    .line 216
    move-result-object v17

    .line 217
    invoke-static {}, LX/2b4;->A00()LX/2b4;

    .line 218
    .line 219
    .line 220
    move-result-object v5

    .line 221
    move-object/from16 v0, v19

    .line 222
    .line 223
    invoke-static {v11, v0, v12, v12}, LX/AdT;->A0G(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    .line 224
    .line 225
    .line 226
    move-result v2

    .line 227
    invoke-static {v11, v15, v12, v12}, LX/AdT;->A0G(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    .line 228
    .line 229
    .line 230
    move-result v3

    .line 231
    invoke-static {v11, v10, v12, v12}, LX/AdT;->A0G(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    .line 232
    .line 233
    .line 234
    move-result v16

    .line 235
    if-ltz v2, :cond_b

    .line 236
    .line 237
    if-ltz v3, :cond_b

    .line 238
    .line 239
    if-ltz v16, :cond_b

    .line 240
    .line 241
    new-instance v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;

    .line 242
    .line 243
    invoke-direct {v4, v2, v0, v9}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    new-instance v2, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;

    .line 247
    .line 248
    invoke-direct {v2, v3, v15, v7}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 249
    .line 250
    .line 251
    new-instance v1, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;

    .line 252
    .line 253
    move/from16 v0, v16

    .line 254
    .line 255
    invoke-direct {v1, v0, v10, v6}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    filled-new-array {v4, v2, v1}, [Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText_KE6awZw$lambda$3$0$$inlined$sortedBy$1;

    .line 267
    .line 268
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText_KE6awZw$lambda$3$0$$inlined$sortedBy$1;-><init>()V

    .line 269
    .line 270
    .line 271
    invoke-static {v1, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 276
    .line 277
    .line 278
    move-result-object v16

    .line 279
    const/4 v1, 0x0

    .line 280
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    if-eqz v0, :cond_9

    .line 285
    .line 286
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v4

    .line 290
    check-cast v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;

    .line 291
    .line 292
    iget v0, v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->start:I

    .line 293
    .line 294
    invoke-virtual {v11, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v0

    .line 298
    invoke-virtual {v5, v0}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 299
    .line 300
    .line 301
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->url:Ljava/lang/String;

    .line 302
    .line 303
    new-instance v1, LX/2iL;

    .line 304
    .line 305
    move-object/from16 v3, v17

    .line 306
    .line 307
    move-object v2, v0

    .line 308
    move-object/from16 v0, v18

    .line 309
    .line 310
    invoke-direct {v1, v0, v3, v2}, LX/2iL;-><init>(LX/2D4;LX/2iS;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {v5, v1}, LX/2b4;->A02(LX/2D7;)I

    .line 314
    .line 315
    .line 316
    move-result v1

    .line 317
    :try_start_0
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->label:Ljava/lang/String;

    .line 318
    .line 319
    invoke-virtual {v5, v0}, LX/2b4;->A0E(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 320
    .line 321
    .line 322
    invoke-virtual {v5, v1}, LX/2b4;->A06(I)V

    .line 323
    .line 324
    .line 325
    iget v1, v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->start:I

    .line 326
    .line 327
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$annotatedString$1$1$Link;->label:Ljava/lang/String;

    .line 328
    .line 329
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 330
    .line 331
    .line 332
    move-result v0

    .line 333
    add-int/2addr v1, v0

    .line 334
    goto :goto_2

    .line 335
    :cond_7
    move/from16 v0, v21

    .line 336
    .line 337
    and-int/lit16 v0, v0, 0x180

    .line 338
    .line 339
    if-nez v0, :cond_1

    .line 340
    .line 341
    move-object/from16 v0, v20

    .line 342
    .line 343
    invoke-static {v13, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 344
    .line 345
    .line 346
    move-result v0

    .line 347
    or-int/2addr v14, v0

    .line 348
    goto/16 :goto_1

    .line 349
    .line 350
    :cond_8
    move/from16 v14, v21

    .line 351
    .line 352
    goto/16 :goto_0

    .line 353
    .line 354
    :catchall_0
    move-exception v0

    .line 355
    invoke-virtual {v5, v1}, LX/2b4;->A06(I)V

    .line 356
    .line 357
    .line 358
    throw v0

    .line 359
    :cond_9
    invoke-virtual {v11, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    invoke-virtual {v5, v0}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 364
    .line 365
    .line 366
    goto :goto_3

    .line 367
    :cond_a
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 368
    .line 369
    .line 370
    goto :goto_4

    .line 371
    :cond_b
    invoke-virtual {v5, v11}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 372
    .line 373
    .line 374
    :goto_3
    invoke-virtual {v5}, LX/2b4;->A04()LX/2iK;

    .line 375
    .line 376
    .line 377
    move-result-object v1

    .line 378
    invoke-interface {v13, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 379
    .line 380
    .line 381
    :cond_c
    check-cast v1, LX/2iK;

    .line 382
    .line 383
    move-object/from16 v0, v19

    .line 384
    .line 385
    invoke-interface {v13, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 386
    .line 387
    .line 388
    move-result v0

    .line 389
    invoke-static {v13, v15, v10, v9, v0}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 390
    .line 391
    .line 392
    move-result v0

    .line 393
    invoke-static {v13, v7, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 394
    .line 395
    .line 396
    move-result v0

    .line 397
    invoke-static {v13, v6, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 398
    .line 399
    .line 400
    move-result v0

    .line 401
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 402
    .line 403
    .line 404
    move-result-object v2

    .line 405
    if-nez v0, :cond_d

    .line 406
    .line 407
    if-ne v2, v8, :cond_e

    .line 408
    .line 409
    :cond_d
    move-object/from16 v0, v19

    .line 410
    .line 411
    invoke-static {v9, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 412
    .line 413
    .line 414
    move-result-object v2

    .line 415
    invoke-static {v7, v15}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    invoke-static {v6, v10, v2, v0}, LX/1H9;->A05(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;LX/IBK;)Ljava/util/Map;

    .line 420
    .line 421
    .line 422
    move-result-object v2

    .line 423
    invoke-interface {v13, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    :cond_e
    check-cast v2, Ljava/util/Map;

    .line 427
    .line 428
    shl-int/lit8 v7, v14, 0x6

    .line 429
    .line 430
    const v0, 0xff80

    .line 431
    .line 432
    .line 433
    and-int/2addr v7, v0

    .line 434
    move/from16 v3, p2

    .line 435
    .line 436
    move-object/from16 v4, p1

    .line 437
    .line 438
    move-object/from16 v5, v20

    .line 439
    .line 440
    move-object v6, v13

    .line 441
    move v8, v12

    .line 442
    invoke-static/range {v1 .. v8}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 443
    .line 444
    .line 445
    :goto_4
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 446
    .line 447
    .line 448
    move-result-object v1

    .line 449
    if-eqz v1, :cond_f

    .line 450
    .line 451
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$1;

    .line 452
    .line 453
    move-object/from16 v17, v0

    .line 454
    .line 455
    move/from16 v18, p2

    .line 456
    .line 457
    move-object/from16 v19, p1

    .line 458
    .line 459
    invoke-direct/range {v17 .. v22}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$LegalText$1;-><init>(ILX/JDM;LX/3C1;II)V

    .line 460
    .line 461
    .line 462
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 463
    .line 464
    :cond_f
    return-void
.end method

.method public static final MuseAppDisclosureLegalText(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v7, p2

    .line 1
    const/4 v0, 0x1

    .line 2
    move-object p2, p1

    .line 3
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const v0, 0x61770ba6

    .line 7
    .line 8
    .line 9
    move-object v8, p3

    .line 10
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 11
    .line 12
    .line 13
    and-int/lit8 v0, p4, 0x6

    .line 14
    .line 15
    move p1, p0

    .line 16
    if-nez v0, :cond_b

    .line 17
    .line 18
    invoke-static {p3, p0}, LX/004;->A0i(LX/2d4;Z)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    or-int/2addr v0, p4

    .line 23
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 24
    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    invoke-static {p3, p2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    or-int/2addr v0, v1

    .line 32
    :cond_0
    and-int/lit8 v3, p5, 0x4

    .line 33
    .line 34
    if-eqz v3, :cond_a

    .line 35
    .line 36
    or-int/lit16 v0, v0, 0x180

    .line 37
    .line 38
    :cond_1
    :goto_1
    and-int/lit16 v2, v0, 0x93

    .line 39
    .line 40
    const/16 v1, 0x92

    .line 41
    .line 42
    const/4 p0, 0x0

    .line 43
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    invoke-static {v1, p3, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_9

    .line 52
    .line 53
    if-eqz v3, :cond_2

    .line 54
    .line 55
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 56
    .line 57
    :cond_2
    invoke-static {p3}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    new-instance v5, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;

    .line 62
    .line 63
    invoke-direct {v5, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;-><init>(LX/AHE;)V

    .line 64
    .line 65
    .line 66
    invoke-static {p3}, LX/3Rq;->A02(LX/2d4;)Landroidx/activity/ComponentActivity;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    invoke-static {v4}, LX/004;->A14(LX/15O;)LX/13i;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    const-class v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 75
    .line 76
    invoke-static {v1}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    const/4 v1, 0x0

    .line 81
    invoke-static {v5, v4, v3, v1, v2}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    check-cast v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 86
    .line 87
    iget-object v1, v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->uiState:LX/2J3;

    .line 88
    .line 89
    invoke-static {p3, v1, p0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    invoke-interface {v3}, LX/16A;->getValue()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    check-cast v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 98
    .line 99
    iget-object v2, v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->subscriptionLegalText:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 100
    .line 101
    if-eqz v2, :cond_6

    .line 102
    .line 103
    if-eqz p1, :cond_6

    .line 104
    .line 105
    const v1, 0x1c7c678d

    .line 106
    .line 107
    .line 108
    invoke-interface {p3, v1}, LX/2d4;->Agj(I)V

    .line 109
    .line 110
    .line 111
    iget-object v3, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;->text:Ljava/lang/String;

    .line 112
    .line 113
    iget-object v4, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;->links:LX/Ddn;

    .line 114
    .line 115
    const/4 v5, 0x5

    .line 116
    invoke-static {v0}, LX/006;->A1W(I)Z

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    if-nez v1, :cond_3

    .line 125
    .line 126
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 127
    .line 128
    if-ne v6, v1, :cond_4

    .line 129
    .line 130
    :cond_3
    new-instance v6, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$1$1;

    .line 131
    .line 132
    invoke-direct {v6, p2}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 133
    .line 134
    .line 135
    invoke-interface {p3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    :cond_4
    check-cast v6, LX/JDM;

    .line 139
    .line 140
    sget v1, Lcom/facebook/aura/linktext/HatchTextLink;->$stable:I

    .line 141
    .line 142
    shl-int/lit8 v9, v1, 0x3

    .line 143
    .line 144
    const v1, 0xe000

    .line 145
    .line 146
    .line 147
    shl-int/lit8 v0, v0, 0x6

    .line 148
    .line 149
    and-int/2addr v0, v1

    .line 150
    or-int/2addr v9, v0

    .line 151
    invoke-static/range {v3 .. v10}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DynamicLegalText-D30ufTU(Ljava/lang/String;Ljava/util/List;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 152
    .line 153
    .line 154
    invoke-static {p3, p3}, LX/003;->A0W(LX/2d4;Ljava/lang/Object;)LX/J7V;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    if-eqz v0, :cond_5

    .line 159
    .line 160
    new-instance p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$2;

    .line 161
    .line 162
    move-object p3, v7

    .line 163
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$2;-><init>(ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 164
    .line 165
    .line 166
    :goto_2
    invoke-static {v0, p0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    :cond_5
    return-void

    .line 170
    :cond_6
    const v1, 0x1c7fe8bc

    .line 171
    .line 172
    .line 173
    invoke-static {p3, v1}, LX/003;->A0q(LX/2d4;I)V

    .line 174
    .line 175
    .line 176
    invoke-interface {v3}, LX/16A;->getValue()Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    check-cast v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 181
    .line 182
    iget-object v4, v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->tosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 183
    .line 184
    const/4 v5, 0x5

    .line 185
    invoke-static {v0}, LX/006;->A1W(I)Z

    .line 186
    .line 187
    .line 188
    move-result v1

    .line 189
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    if-nez v1, :cond_7

    .line 194
    .line 195
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 196
    .line 197
    if-ne v6, v1, :cond_8

    .line 198
    .line 199
    :cond_7
    new-instance v6, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$3$1;

    .line 200
    .line 201
    invoke-direct {v6, p2}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$3$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 202
    .line 203
    .line 204
    invoke-interface {p3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_8
    check-cast v6, LX/JDM;

    .line 208
    .line 209
    shl-int/lit8 v0, v0, 0x3

    .line 210
    .line 211
    and-int/lit16 v9, v0, 0x1c00

    .line 212
    .line 213
    invoke-static/range {v4 .. v10}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureLegalText-5TldRvM(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 214
    .line 215
    .line 216
    goto :goto_3

    .line 217
    :cond_9
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 218
    .line 219
    .line 220
    :goto_3
    invoke-interface {p3}, LX/2d4;->AAg()LX/J7V;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    if-eqz v0, :cond_5

    .line 225
    .line 226
    new-instance p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$4;

    .line 227
    .line 228
    move-object p3, v7

    .line 229
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$MuseAppDisclosureLegalText$4;-><init>(ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 230
    .line 231
    .line 232
    goto :goto_2

    .line 233
    :cond_a
    and-int/lit16 v1, p4, 0x180

    .line 234
    .line 235
    if-nez v1, :cond_1

    .line 236
    .line 237
    invoke-static {p3, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 238
    .line 239
    .line 240
    move-result v1

    .line 241
    or-int/2addr v0, v1

    .line 242
    goto/16 :goto_1

    .line 243
    .line 244
    :cond_b
    move v0, p4

    .line 245
    goto/16 :goto_0
.end method

.method public static final MuseAppDisclosureLegalText$lambda$0(LX/16A;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2iK;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p4

    .line 1
    .line 2
    const v0, 0x5618a36c

    .line 3
    .line 4
    .line 5
    move-object/from16 v5, p5

    .line 6
    .line 7
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p6

    .line 11
    .line 12
    and-int/lit8 v0, p6, 0x6

    .line 13
    .line 14
    const/4 v3, 0x2

    .line 15
    move-object/from16 v8, p0

    .line 16
    .line 17
    if-nez v0, :cond_a

    .line 18
    .line 19
    invoke-static {v5, v8}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    or-int v2, v2, p6

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 26
    .line 27
    move-object/from16 v7, p1

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    invoke-static {v7, v5, v4}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0}, LX/003;->A07(I)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    or-int/2addr v2, v0

    .line 40
    :cond_0
    and-int/lit16 v0, v4, 0x180

    .line 41
    .line 42
    move/from16 v11, p2

    .line 43
    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    invoke-static {v5, v11}, LX/004;->A0G(LX/2d4;I)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    or-int/2addr v2, v0

    .line 51
    :cond_1
    and-int/lit16 v0, v4, 0xc00

    .line 52
    .line 53
    move-object/from16 v6, p3

    .line 54
    .line 55
    if-nez v0, :cond_2

    .line 56
    .line 57
    invoke-static {v5, v6}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    or-int/2addr v2, v0

    .line 62
    :cond_2
    and-int/lit8 v9, p7, 0x10

    .line 63
    .line 64
    if-eqz v9, :cond_9

    .line 65
    .line 66
    or-int/lit16 v2, v2, 0x6000

    .line 67
    .line 68
    :cond_3
    :goto_1
    invoke-static {v2}, LX/009;->A1I(I)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    invoke-static {v0, v5, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_8

    .line 77
    .line 78
    if-eqz v9, :cond_4

    .line 79
    .line 80
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    :cond_4
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 83
    .line 84
    const/4 v0, 0x6

    .line 85
    invoke-virtual {v9, v5, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-static {v5, v9}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 90
    .line 91
    .line 92
    move-result-object v13

    .line 93
    iget-wide v9, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 94
    .line 95
    const v25, 0xff7ffe

    .line 96
    .line 97
    .line 98
    const/4 v12, 0x0

    .line 99
    const-wide/16 p1, 0x0

    .line 100
    .line 101
    const/4 v0, 0x0

    .line 102
    move-object v14, v12

    .line 103
    move-object v15, v12

    .line 104
    move-object/from16 v16, v12

    .line 105
    .line 106
    move-object/from16 v17, v12

    .line 107
    .line 108
    move-object/from16 v18, v12

    .line 109
    .line 110
    move-object/from16 v19, v12

    .line 111
    .line 112
    move-object/from16 v20, v12

    .line 113
    .line 114
    move-object/from16 v21, v12

    .line 115
    .line 116
    move/from16 v23, v0

    .line 117
    .line 118
    move/from16 v24, v0

    .line 119
    .line 120
    move-wide/from16 v26, v9

    .line 121
    .line 122
    move-wide/from16 p3, p1

    .line 123
    .line 124
    move-wide/from16 p5, p1

    .line 125
    .line 126
    move/from16 v22, v11

    .line 127
    .line 128
    invoke-static/range {v12 .. v33}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 129
    .line 130
    .line 131
    move-result-object v9

    .line 132
    invoke-static {v9, v5, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->rememberSixLineHeight(LX/2hg;LX/2d4;I)F

    .line 133
    .line 134
    .line 135
    move-result v10

    .line 136
    shr-int/lit8 v0, v2, 0x3

    .line 137
    .line 138
    and-int/lit8 v0, v0, 0xe

    .line 139
    .line 140
    invoke-static {v7, v12, v5, v0, v3}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->rememberHatchLinkUriHandler(Ljava/util/Map;LX/JDM;LX/2d4;II)LX/18m;

    .line 141
    .line 142
    .line 143
    move-result-object v12

    .line 144
    invoke-static {v5, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    invoke-interface {v5, v12}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    if-nez v0, :cond_5

    .line 157
    .line 158
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 159
    .line 160
    if-ne v2, v0, :cond_6

    .line 161
    .line 162
    :cond_5
    new-instance v2, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;

    .line 163
    .line 164
    invoke-direct {v2, v12, v3}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;-><init>(LX/18m;LX/16A;)V

    .line 165
    .line 166
    .line 167
    invoke-interface {v5, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    :cond_6
    sget-object v0, LX/3Fe;->A0G:LX/Ip3;

    .line 171
    .line 172
    invoke-virtual {v0, v2}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    new-instance v2, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;

    .line 177
    .line 178
    invoke-direct {v2, v8, v1, v10, v9}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;-><init>(LX/2iK;LX/3C1;FLX/2hg;)V

    .line 179
    .line 180
    .line 181
    const v0, 0x5a8d882c

    .line 182
    .line 183
    .line 184
    invoke-static {v5, v2, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 185
    .line 186
    .line 187
    move-result-object v2

    .line 188
    const/16 v0, 0x30

    .line 189
    .line 190
    invoke-static {v5, v3, v2, v0}, LX/Izg;->A01(LX/2d4;LX/Ip4;LX/JDN;I)V

    .line 191
    .line 192
    .line 193
    :goto_2
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 194
    .line 195
    .line 196
    move-result-object v2

    .line 197
    if-eqz v2, :cond_7

    .line 198
    .line 199
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;

    .line 200
    .line 201
    move/from16 p3, v11

    .line 202
    .line 203
    move-object/from16 p0, v0

    .line 204
    .line 205
    move-object/from16 p1, v8

    .line 206
    .line 207
    move-object/from16 p2, v7

    .line 208
    .line 209
    move-object/from16 p4, v6

    .line 210
    .line 211
    move-object/from16 p5, v1

    .line 212
    .line 213
    move/from16 p6, v4

    .line 214
    .line 215
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;-><init>(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;II)V

    .line 216
    .line 217
    .line 218
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 219
    .line 220
    :cond_7
    return-void

    .line 221
    :cond_8
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 222
    .line 223
    .line 224
    goto :goto_2

    .line 225
    :cond_9
    and-int/lit16 v0, v4, 0x6000

    .line 226
    .line 227
    if-nez v0, :cond_3

    .line 228
    .line 229
    invoke-static {v5, v1}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    or-int/2addr v2, v0

    .line 234
    goto/16 :goto_1

    .line 235
    .line 236
    :cond_a
    move v2, v4

    .line 237
    goto/16 :goto_0
.end method

.method public static final ScrollableLinkText_D30ufTU$lambda$0(LX/16A;)LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A07(LX/16A;)LX/JDM;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$DisclosureCard(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureCard(LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureContent(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureContent(Lcom/facebook/aura/activation/data/HatchTosMetadata;ZLcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureLegalText-5TldRvM(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureLegalText-5TldRvM(Lcom/facebook/aura/activation/data/HatchTosMetadata;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureScrollFade(LX/3Lr;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureScrollFade(LX/3Lr;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureSubscriptionUpgradeCard(Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureSubscriptionUpgradeCard(Lcom/facebook/aura/activation/data/HatchUpsellCell;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureValuePropCard(Ljava/util/List;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureValuePropCard(Ljava/util/List;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$DisclosureValuePropRow(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureValuePropRow(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$LegalText-KE6awZw(ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->LegalText-KE6awZw(ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ScrollableLinkText_D30ufTU$lambda$0(LX/16A;)LX/JDM;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A07(LX/16A;)LX/JDM;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$disclosureSectionIconRes(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->disclosureSectionIconRes(Ljava/lang/String;)Ljava/lang/Integer;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$logDisclosureLegalLinkClick(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->logDisclosureLegalLinkClick(Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final disclosureSectionIconRes(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    sparse-switch v0, :sswitch_data_0

    .line 14
    .line 15
    .line 16
    :cond_0
    return-object v1

    .line 17
    :sswitch_0
    const-string v0, "settingsGearAndroid"

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    const v0, 0x7f080297

    .line 26
    .line 27
    .line 28
    goto/16 :goto_0

    .line 29
    .line 30
    :sswitch_1
    const-string v0, "shieldLock"

    .line 31
    .line 32
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    const v0, 0x7f08029f

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :sswitch_2
    const-string v0, "shieldInfo"

    .line 43
    .line 44
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    const v0, 0x7f08029d

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :sswitch_3
    const-string v0, "clock"

    .line 55
    .line 56
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_0

    .line 61
    .line 62
    const v0, 0x7f080103

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :sswitch_4
    const-string v0, "wand"

    .line 67
    .line 68
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    const v0, 0x7f0802e2

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :sswitch_5
    const-string v0, "lock"

    .line 79
    .line 80
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_0

    .line 85
    .line 86
    const v0, 0x7f080229

    .line 87
    .line 88
    .line 89
    goto :goto_0

    .line 90
    :sswitch_6
    const-string v0, "eye"

    .line 91
    .line 92
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_0

    .line 97
    .line 98
    const v0, 0x7f08012d

    .line 99
    .line 100
    .line 101
    goto :goto_0

    .line 102
    :sswitch_7
    const-string v0, "shieldCheck"

    .line 103
    .line 104
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_0

    .line 109
    .line 110
    const v0, 0x7f08029c

    .line 111
    .line 112
    .line 113
    goto :goto_0

    .line 114
    :sswitch_8
    const-string v0, "settingsGearIOS"

    .line 115
    .line 116
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    if-eqz v0, :cond_0

    .line 121
    .line 122
    const v0, 0x7f080298

    .line 123
    .line 124
    .line 125
    goto :goto_0

    .line 126
    :sswitch_9
    const-string v0, "agentic"

    .line 127
    .line 128
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-eqz v0, :cond_0

    .line 133
    .line 134
    const v0, 0x7f08007a

    .line 135
    .line 136
    .line 137
    goto :goto_0

    .line 138
    :sswitch_a
    const-string v0, "lockKeyhole"

    .line 139
    .line 140
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    if-eqz v0, :cond_0

    .line 145
    .line 146
    const v0, 0x7f08022b

    .line 147
    .line 148
    .line 149
    goto :goto_0

    .line 150
    :sswitch_b
    const-string v0, "sliders2Horizontal"

    .line 151
    .line 152
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-eqz v0, :cond_0

    .line 157
    .line 158
    const v0, 0x7f0802a4

    .line 159
    .line 160
    .line 161
    :goto_0
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    return-object v1

    .line 166
    :sswitch_data_0
    .sparse-switch
        -0x666b34fc -> :sswitch_b
        -0x4f70f80c -> :sswitch_a
        -0x3f3d5d21 -> :sswitch_9
        -0x3d455da5 -> :sswitch_8
        -0x13def0e1 -> :sswitch_7
        0x18a31 -> :sswitch_6
        0x32c52b -> :sswitch_5
        0x379200 -> :sswitch_4
        0x5a5dc0e -> :sswitch_3
        0x30eb1bb7 -> :sswitch_2
        0x30ec7c34 -> :sswitch_1
        0x54756dbd -> :sswitch_0
    .end sparse-switch
.end method

.method public static final logDisclosureLegalLinkClick(Ljava/lang/String;)V
    .locals 7

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_DISCLOSURE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->LEGAL_LINK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 7
    .line 8
    invoke-static {p0}, Lcom/facebook/aura/settings/AuraLegalLinkTypesKt;->legalLinkMetadataForUrl(Ljava/lang/String;)Ljava/util/Map;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v2, 0x0

    .line 13
    move-object v5, v2

    .line 14
    move-object p0, v2

    .line 15
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public static final rememberDisclosureSections(Lcom/facebook/aura/activation/data/HatchTosMetadata;LX/2d4;I)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "LX/2d4;",
            "I)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, -0x511e7b52

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchTosMetadata;->disclosureSections:Ljava/util/List;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :cond_0
    const v0, 0x7f1202d7

    .line 23
    .line 24
    .line 25
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    const v0, 0x7f1202d6

    .line 30
    .line 31
    .line 32
    invoke-static {p1, v0}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    const v0, 0x7f1202d2

    .line 37
    .line 38
    .line 39
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    const v0, 0x7f1202d1

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {p1, v5, v4, v3, v0}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-nez v1, :cond_1

    .line 63
    .line 64
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 65
    .line 66
    if-ne v0, v1, :cond_2

    .line 67
    .line 68
    :cond_1
    const-string v0, "wand"

    .line 69
    .line 70
    new-instance v2, Lcom/facebook/aura/activation/data/HatchDisclosureSection;

    .line 71
    .line 72
    invoke-direct {v2, p0, v5, v0}, Lcom/facebook/aura/activation/data/HatchDisclosureSection;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    const-string v1, "lock"

    .line 76
    .line 77
    new-instance v0, Lcom/facebook/aura/activation/data/HatchDisclosureSection;

    .line 78
    .line 79
    invoke-direct {v0, v4, v3, v1}, Lcom/facebook/aura/activation/data/HatchDisclosureSection;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    filled-new-array {v2, v0}, [Lcom/facebook/aura/activation/data/HatchDisclosureSection;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    :cond_2
    check-cast v0, Ljava/util/List;

    .line 94
    .line 95
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    return-object v0
.end method

.method public static final rememberSixLineHeight(LX/2hg;LX/2d4;I)F
    .locals 10

    .line 0
    const/4 v3, 0x0

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v3, v0}, LX/2oA;->A00(LX/2d4;II)LX/2o8;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    invoke-static {p1}, LX/3Rp;->A02(LX/2d4;)LX/34Y;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    and-int/lit8 v0, p2, 0xe

    .line 11
    .line 12
    xor-int/lit8 v0, v0, 0x6

    .line 13
    .line 14
    const/4 v1, 0x4

    .line 15
    move-object v5, p0

    .line 16
    if-le v0, v1, :cond_0

    .line 17
    .line 18
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    :cond_0
    and-int/lit8 v0, p2, 0x6

    .line 25
    .line 26
    if-ne v0, v1, :cond_2

    .line 27
    .line 28
    :cond_1
    const/4 v3, 0x1

    .line 29
    :cond_2
    invoke-static {p1, v2, v3}, LX/001;->A1U(LX/2d4;Ljava/lang/Object;Z)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-nez v1, :cond_3

    .line 38
    .line 39
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 40
    .line 41
    if-ne v0, v1, :cond_4

    .line 42
    .line 43
    :cond_3
    const/16 v8, 0x3fc

    .line 44
    .line 45
    const-string v6, "l\nl\nl\nl\nl\nl"

    .line 46
    .line 47
    const/4 v7, 0x0

    .line 48
    const-wide/16 v9, 0x0

    .line 49
    .line 50
    invoke-static/range {v4 .. v10}, LX/2o8;->A01(LX/2o8;LX/2hg;Ljava/lang/String;IIJ)LX/2ab;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iget-wide v0, v0, LX/2ab;->A02:J

    .line 55
    .line 56
    invoke-static {v0, v1}, LX/002;->A0G(J)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    invoke-interface {v2, v0}, LX/34Y;->AhT(I)F

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_4
    check-cast v0, LX/1Ot;

    .line 72
    .line 73
    iget v0, v0, LX/1Ot;->A00:F

    .line 74
    .line 75
    return v0
.end method
