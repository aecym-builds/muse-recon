.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/2vi;",
        "LX/2sf;",
        "Landroidx/compose/ui/unit/Constraints;",
        "LX/3CP;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $fraction:F


# direct methods
.method public constructor <init>(F)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;->$fraction:F

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2vi;

    .line 1
    .line 2
    check-cast p2, LX/2sf;

    .line 3
    .line 4
    check-cast p3, Landroidx/compose/ui/unit/Constraints;

    .line 5
    .line 6
    iget-wide v0, p3, Landroidx/compose/ui/unit/Constraints;->A00:J

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;->invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;
    .locals 5

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, p3, p4}, LX/2sf;->AQh(J)LX/3B5;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    iget v3, v4, LX/3B5;->A01:I

    .line 8
    .line 9
    iget v0, v4, LX/3B5;->A00:I

    .line 10
    .line 11
    int-to-float v2, v0

    .line 12
    const/high16 v1, 0x3f800000    # 1.0f

    .line 13
    .line 14
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1;->$fraction:F

    .line 15
    .line 16
    sub-float/2addr v1, v0

    .line 17
    invoke-static {v2, v1}, LX/0sc;->A02(FF)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1$1;

    .line 22
    .line 23
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$overlappedBy$1$1;-><init>(LX/3B5;)V

    .line 24
    .line 25
    .line 26
    invoke-static {p1, v0, v3, v1}, LX/602;->A0B(LX/2vi;LX/JDM;II)LX/3CP;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0
.end method
