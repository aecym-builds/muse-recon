.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2"
    f = "AuraWaitlistConfetti.kt"
    l = {
        0xca,
        0xcc
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v2, LX/1EL;

    .line 3
    .line 4
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->label:I

    .line 7
    .line 8
    const/4 v6, 0x2

    .line 9
    const/4 v3, 0x1

    .line 10
    const/4 v4, 0x0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    if-eq v0, v3, :cond_2

    .line 14
    .line 15
    if-ne v0, v6, :cond_4

    .line 16
    .line 17
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 21
    .line 22
    return-object v5

    .line 23
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;

    .line 29
    .line 30
    invoke-direct {v0, v1, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2$punch$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v0, v2}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    iput-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$0:Ljava/lang/Object;

    .line 38
    .line 39
    iput-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$1:Ljava/lang/Object;

    .line 40
    .line 41
    iput v3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->label:I

    .line 42
    .line 43
    const-wide/16 v0, 0xb4

    .line 44
    .line 45
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-ne v0, v5, :cond_3

    .line 50
    .line 51
    return-object v5

    .line 52
    :cond_2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$1:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, LX/Cbu;

    .line 55
    .line 56
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_3
    invoke-interface {v2, v4}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 60
    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 63
    .line 64
    iget-object v3, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->ctaScale:LX/Dvf;

    .line 65
    .line 66
    invoke-static {}, LX/002;->A0l()Ljava/lang/Float;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    const v1, 0x3f3851ec    # 0.72f

    .line 71
    .line 72
    .line 73
    const v0, 0x44bb8000    # 1500.0f

    .line 74
    .line 75
    .line 76
    invoke-static {v4, v1, v0}, LX/001;->A0R(Ljava/lang/Object;FF)LX/ELU;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    iput-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$0:Ljava/lang/Object;

    .line 81
    .line 82
    iput-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->L$1:Ljava/lang/Object;

    .line 83
    .line 84
    iput v6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;->label:I

    .line 85
    .line 86
    invoke-static {v3, v0, v2, p0, v4}, LX/002;->A0s(LX/Dvf;LX/DwJ;Ljava/lang/Object;LX/2M4;LX/JDM;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    if-ne v0, v5, :cond_0

    .line 91
    .line 92
    return-object v5

    .line 93
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    throw v0
.end method
