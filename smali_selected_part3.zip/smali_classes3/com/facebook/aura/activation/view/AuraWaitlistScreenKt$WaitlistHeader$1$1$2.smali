.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistScreenKt$WaitlistHeader$1$1$2"
    f = "AuraWaitlistScreen.kt"
    l = {
        0x15b
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $offsetY$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;-><init>(Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;-><init>(Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->label:I

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-ne v0, v1, :cond_2

    .line 9
    .line 10
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v2

    .line 16
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    sget-object v3, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->animationSpec:LX/ELU;

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 22
    .line 23
    new-instance v5, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;

    .line 24
    .line 25
    invoke-direct {v5, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 26
    .line 27
    .line 28
    iput v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1$2;->label:I

    .line 29
    .line 30
    const/high16 v6, 0x42100000    # 36.0f

    .line 31
    .line 32
    const/4 p0, 0x0

    .line 33
    move p1, p0

    .line 34
    invoke-static/range {v3 .. v8}, Landroidx/compose/animation/core/SuspendAnimationKt;->A03(LX/DwJ;LX/2M4;LX/JDN;FFF)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-ne v0, v2, :cond_0

    .line 39
    .line 40
    return-object v2

    .line 41
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0
.end method
