.class public final Lcom/facebook/aura/activation/view/ConfettiBurst;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final durationMs:I

.field public final particles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/view/ConfettiParticle;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/view/ConfettiParticle;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/view/ConfettiBurst;->particles:Ljava/util/List;

    .line 8
    .line 9
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lcom/facebook/aura/activation/view/ConfettiParticle;

    .line 24
    .line 25
    iget v1, v0, Lcom/facebook/aura/activation/view/ConfettiParticle;->end:F

    .line 26
    .line 27
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/facebook/aura/activation/view/ConfettiParticle;

    .line 38
    .line 39
    iget v0, v0, Lcom/facebook/aura/activation/view/ConfettiParticle;->end:F

    .line 40
    .line 41
    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    const/high16 v0, 0x447a0000    # 1000.0f

    .line 47
    .line 48
    mul-float/2addr v1, v0

    .line 49
    const/high16 v0, 0x42a00000    # 80.0f

    .line 50
    .line 51
    add-float/2addr v0, v1

    .line 52
    invoke-static {v0}, LX/0sc;->A01(F)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    iput v0, p0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 57
    .line 58
    return-void

    .line 59
    :cond_1
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 60
    .line 61
    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .line 62
    .line 63
    .line 64
    throw v0
.end method


# virtual methods
.method public final getDurationMs()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 1
    .line 2
    return p0
.end method

.method public final getParticles()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/view/ConfettiParticle;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/ConfettiBurst;->particles:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method
