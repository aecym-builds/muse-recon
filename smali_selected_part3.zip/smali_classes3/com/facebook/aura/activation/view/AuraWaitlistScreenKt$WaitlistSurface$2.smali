.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public final synthetic $component:Lcom/facebook/aura/analytics/hatch/HatchComponent;

.field public final synthetic $content:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "LX/3dS;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $verticalArrangement:LX/Dps;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
            "LX/Dps;",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$component:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$verticalArrangement:LX/Dps;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$modifier:LX/3C1;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$content:LX/JDQ;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$$changed:I

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$$default:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$component:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$verticalArrangement:LX/Dps;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;

    .line 268435463
    .line 268435464
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$modifier:LX/3C1;

    .line 268435465
    .line 268435466
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$content:LX/JDQ;

    .line 268435467
    .line 268435468
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$$changed:I

    .line 268435469
    .line 268435470
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v8

    .line 268435474
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;->$$default:I

    .line 268435475
    .line 268435476
    move-object v7, p1

    .line 268435477
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistSurface(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 268435478
    .line 268435479
    .line 268435480
    return-void
.end method
