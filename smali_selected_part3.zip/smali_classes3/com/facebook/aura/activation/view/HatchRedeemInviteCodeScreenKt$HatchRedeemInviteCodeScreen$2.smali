.class public final Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onCodeChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onConfirmClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRetryClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onRetryClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onCodeChange:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onConfirmClick:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    const/4 v0, 0x4

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 10

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move v7, p1

    .line 3
    move-object v9, p3

    .line 4
    if-nez v0, :cond_4

    .line 5
    .line 6
    invoke-static {p3, p1}, LX/004;->A09(LX/2d4;F)I

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    or-int/2addr v2, p4

    .line 11
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 12
    .line 13
    move v8, p2

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {p3, p2}, LX/004;->A0A(LX/2d4;F)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int/2addr v2, v0

    .line 21
    :cond_0
    invoke-static {v2}, LX/005;->A1I(I)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-static {v0, p3, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_6

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 32
    .line 33
    iget-object v1, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->phase:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase;

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Loading;

    .line 36
    .line 37
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    const v0, 0x52d10b69

    .line 44
    .line 45
    .line 46
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 47
    .line 48
    .line 49
    const/4 v2, 0x0

    .line 50
    const/4 v1, 0x0

    .line 51
    const/4 v0, 0x1

    .line 52
    invoke-static {v2, p3, v1, v0}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt;->RedeemLoadingContent(LX/3C1;LX/2d4;II)V

    .line 53
    .line 54
    .line 55
    :goto_1
    invoke-static {p3}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$LoadFailed;->INSTANCE:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$LoadFailed;

    .line 60
    .line 61
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_2

    .line 66
    .line 67
    const v0, 0x52d113c0

    .line 68
    .line 69
    .line 70
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 71
    .line 72
    .line 73
    iget-object v6, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onRetryClick:Lkotlin/jvm/functions/Function0;

    .line 74
    .line 75
    shl-int/lit8 v0, v2, 0x3

    .line 76
    .line 77
    and-int/lit8 p0, v0, 0x70

    .line 78
    .line 79
    const/4 v8, 0x0

    .line 80
    const/4 p1, 0x4

    .line 81
    invoke-static/range {v6 .. v11}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt;->RedeemLoadFailedContent-uFdPcIQ(Lkotlin/jvm/functions/Function0;FLX/3C1;LX/2d4;II)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_2
    instance-of v0, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;

    .line 86
    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    const v0, 0x52d1232b

    .line 90
    .line 91
    .line 92
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 93
    .line 94
    .line 95
    check-cast v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;

    .line 96
    .line 97
    iget-object v1, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Redeemed;->successCopy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 98
    .line 99
    shl-int/lit8 v0, v2, 0x3

    .line 100
    .line 101
    and-int/lit16 v0, v0, 0x3f0

    .line 102
    .line 103
    invoke-static {v1, p1, p2, p3, v0}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt;->RedeemedContent-73KfpEQ(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;FFLX/2d4;I)V

    .line 104
    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_3
    instance-of v0, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 108
    .line 109
    if-eqz v0, :cond_5

    .line 110
    .line 111
    const v0, 0x52d13bc7

    .line 112
    .line 113
    .line 114
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 115
    .line 116
    .line 117
    check-cast v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;

    .line 118
    .line 119
    iget-object v3, v1, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$RedeemPhase$Entry;->copy:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 120
    .line 121
    iget-object v4, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 122
    .line 123
    iget-object v5, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onCodeChange:LX/JDM;

    .line 124
    .line 125
    iget-object v6, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$HatchRedeemInviteCodeScreen$2;->$onConfirmClick:Lkotlin/jvm/functions/Function0;

    .line 126
    .line 127
    shl-int/lit8 p0, v2, 0xc

    .line 128
    .line 129
    const v0, 0x7e000

    .line 130
    .line 131
    .line 132
    and-int/2addr p0, v0

    .line 133
    invoke-static/range {v3 .. v10}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt;->RedeemInviteCodeContent-NuRrP5Q(Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;LX/JDM;Lkotlin/jvm/functions/Function0;FFLX/2d4;I)V

    .line 134
    .line 135
    .line 136
    goto :goto_1

    .line 137
    :cond_4
    move v2, p4

    .line 138
    goto :goto_0

    .line 139
    :cond_5
    const v0, 0x52d10628

    .line 140
    .line 141
    .line 142
    invoke-static {p3, v0}, LX/3Rs;->A0y(LX/2d4;I)V

    .line 143
    .line 144
    .line 145
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    throw v0

    .line 150
    :cond_6
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 151
    .line 152
    .line 153
    return-void
.end method
