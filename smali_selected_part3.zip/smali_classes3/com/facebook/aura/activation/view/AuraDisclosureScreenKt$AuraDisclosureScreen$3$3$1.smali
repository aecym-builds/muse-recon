.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $continueButtonText:Ljava/lang/String;

.field public final synthetic $isLoading:Z

.field public final synthetic $onClose:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$continueButtonText:Ljava/lang/String;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$isLoading:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$onClose:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 9

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$continueButtonText:Ljava/lang/String;

    .line 6
    .line 7
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$isLoading:Z

    .line 8
    .line 9
    xor-int/lit8 v4, v0, 0x1

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1;->$onClose:Lkotlin/jvm/functions/Function0;

    .line 12
    .line 13
    new-instance v7, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1$1;

    .line 14
    .line 15
    invoke-direct {v7, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$3$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 16
    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    const-string v6, "primary_button"

    .line 20
    .line 21
    const p0, 0x7fffffff

    .line 22
    .line 23
    .line 24
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 25
    .line 26
    move-object v8, v3

    .line 27
    invoke-interface/range {v1 .. v10}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(Ljava/lang/String;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ILX/3C1;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method
