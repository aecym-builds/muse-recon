.class public final Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1"
    f = "HatchRedeemInviteCodeScreen.kt"
    l = {
        0xf8
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $scrollState:LX/3Lr;

.field public final synthetic $uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;LX/3Lr;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            "LX/3Lr;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$scrollState:LX/3Lr;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$scrollState:LX/3Lr;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;-><init>(Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;LX/3Lr;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v3

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 19
    .line 20
    iget-object v0, v0, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    iget-object v1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->$scrollState:LX/3Lr;

    .line 25
    .line 26
    iget-object v0, v1, LX/3Lr;->A01:LX/CR1;

    .line 27
    .line 28
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    iput v2, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$1$1;->label:I

    .line 33
    .line 34
    invoke-static {v1, p0, v0}, LX/3Lr;->A00(LX/3Lr;LX/2M4;I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-ne v0, v3, :cond_0

    .line 39
    .line 40
    return-object v3

    .line 41
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0
.end method
