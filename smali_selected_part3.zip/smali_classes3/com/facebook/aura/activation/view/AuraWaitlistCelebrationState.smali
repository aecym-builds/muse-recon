.class public final Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final confettiElapsedMs:LX/Dvf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;"
        }
    .end annotation
.end field

.field public final ctaScale:LX/Dvf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;"
        }
    .end annotation
.end field

.field public final density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 8
    .line 9
    const/high16 v0, 0x3f800000    # 1.0f

    .line 10
    .line 11
    invoke-static {v0}, LX/Dvi;->A00(F)LX/Dvf;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->ctaScale:LX/Dvf;

    .line 16
    .line 17
    invoke-static {p1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget v0, v0, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 22
    .line 23
    int-to-float v0, v0

    .line 24
    invoke-static {v0}, LX/Dvi;->A00(F)LX/Dvf;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final getConfettiElapsedMs()LX/Dvf;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCtaScale()LX/Dvf;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->ctaScale:LX/Dvf;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDensity$fbandroid_express_aura_java_com_facebook_aura_activation_view_view()Lcom/facebook/aura/activation/view/AuraConfettiDensity;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 1
    .line 2
    return-object p0
.end method
