.class public final synthetic Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;
.super LX/DVE;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 0
    const-class v2, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;

    .line 1
    .line 2
    const-string v4, "logDisclosureLegalLinkClick(Ljava/lang/String;)V"

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    const-string v3, "logDisclosureLegalLinkClick"

    .line 6
    .line 7
    move-object v0, p0

    .line 8
    move p0, v1

    .line 9
    invoke-direct/range {v0 .. v5}, LX/DVE;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$AuraDisclosureScreen$3$2$1;->invoke(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 0

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-static {p1}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->logDisclosureLegalLinkClick(Ljava/lang/String;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method
