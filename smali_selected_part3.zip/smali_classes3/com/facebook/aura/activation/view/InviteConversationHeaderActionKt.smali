.class public abstract Lcom/facebook/aura/activation/view/InviteConversationHeaderActionKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INVITE_FRIENDS_BUTTON_TEST_TAG:Ljava/lang/String; = "hatch-invite-friends-button"
