.class public final Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onConfirmClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $redeemText:Ljava/lang/String;

.field public final synthetic $uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$redeemText:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$onConfirmClick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 11

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v3, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v4, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$redeemText:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$uiState:Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;

    .line 8
    .line 9
    iget-object v0, v2, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->inviteCode:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v0, 0x6

    .line 16
    if-lt v1, v0, :cond_0

    .line 17
    .line 18
    iget-boolean v0, v2, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 19
    .line 20
    const/4 v6, 0x1

    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 v6, 0x0

    .line 24
    :cond_1
    iget-boolean v7, v2, Lcom/facebook/aura/activation/model/HatchRedeemInviteCodeViewModel$UiState;->isLoading:Z

    .line 25
    .line 26
    iget-object v9, p0, Lcom/facebook/aura/activation/view/HatchRedeemInviteCodeScreenKt$RedeemInviteCodeContent$1$3$1;->$onConfirmClick:Lkotlin/jvm/functions/Function0;

    .line 27
    .line 28
    const/4 v5, 0x0

    .line 29
    const-string v8, "primary_button"

    .line 30
    .line 31
    const p0, 0x7fffffff

    .line 32
    .line 33
    .line 34
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 35
    .line 36
    move-object v10, v5

    .line 37
    invoke-interface/range {v3 .. v12}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(Ljava/lang/String;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ILX/3C1;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
