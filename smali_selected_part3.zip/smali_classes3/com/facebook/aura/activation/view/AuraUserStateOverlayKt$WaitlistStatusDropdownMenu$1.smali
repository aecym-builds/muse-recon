.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeStarted:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $parentView:Landroid/view/View;

.field public final synthetic $statusOptions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/7Kq;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Ljava/util/List;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/1EL;LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "LX/7Kq;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/1EL;",
            "LX/AHE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$statusOptions:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$coroutineScope:LX/1EL;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$userSession:LX/AHE;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$parentView:Landroid/view/View;

    .line 13
    .line 14
    const/4 v0, 0x3

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 25

    .line 268435456
    const/4 v8, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    move/from16 v1, p3

    .line 268435460
    .line 268435461
    invoke-static {v0, v8, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object/from16 v15, p2

    .line 268435466
    .line 268435467
    invoke-static {v0, v15, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    if-eqz v0, :cond_2

    .line 268435472
    .line 268435473
    move-object/from16 v1, p0

    .line 268435474
    .line 268435475
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$statusOptions:Ljava/util/List;

    .line 268435476
    .line 268435477
    iget-object v7, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435478
    .line 268435479
    iget-object v6, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 268435480
    .line 268435481
    iget-object v5, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$coroutineScope:LX/1EL;

    .line 268435482
    .line 268435483
    iget-object v4, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$userSession:LX/AHE;

    .line 268435484
    .line 268435485
    iget-object v3, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 268435486
    .line 268435487
    iget-object v2, v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;->$parentView:Landroid/view/View;

    .line 268435488
    .line 268435489
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 268435490
    .line 268435491
    .line 268435492
    move-result-object v11

    .line 268435493
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 268435494
    .line 268435495
    .line 268435496
    move-result v0

    .line 268435497
    if-eqz v0, :cond_3

    .line 268435498
    .line 268435499
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268435500
    .line 268435501
    .line 268435502
    move-result-object v10

    .line 268435503
    check-cast v10, LX/7Kq;

    .line 268435504
    .line 268435505
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 268435506
    .line 268435507
    .line 268435508
    move-result-object v1

    .line 268435509
    const-string v0, "Waitlist status set to "

    .line 268435510
    .line 268435511
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 268435512
    .line 268435513
    .line 268435514
    move-result-object v9

    .line 268435515
    new-instance v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;

    .line 268435516
    .line 268435517
    invoke-direct {v1, v10}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$1;-><init>(LX/7Kq;)V

    .line 268435518
    .line 268435519
    .line 268435520
    const v0, -0x326be91c

    .line 268435521
    .line 268435522
    .line 268435523
    invoke-static {v15, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435524
    .line 268435525
    .line 268435526
    move-result-object v18

    .line 268435527
    invoke-static {v15, v7, v6}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435528
    .line 268435529
    .line 268435530
    move-result v0

    .line 268435531
    invoke-static {v15, v5, v4, v0}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 268435532
    .line 268435533
    .line 268435534
    move-result v1

    .line 268435535
    invoke-static {v15, v10}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 268435536
    .line 268435537
    .line 268435538
    move-result v0

    .line 268435539
    invoke-static {v15, v3, v2, v1, v0}, LX/603;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;ZZ)Z

    .line 268435540
    .line 268435541
    .line 268435542
    move-result v0

    .line 268435543
    invoke-static {v15, v9, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435544
    .line 268435545
    .line 268435546
    move-result v1

    .line 268435547
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435548
    .line 268435549
    .line 268435550
    move-result-object v0

    .line 268435551
    if-nez v1, :cond_0

    .line 268435552
    .line 268435553
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435554
    .line 268435555
    if-ne v0, v1, :cond_1

    .line 268435556
    .line 268435557
    :cond_0
    const-string p3, "Failed to set waitlist status"

    .line 268435558
    .line 268435559
    new-instance v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;

    .line 268435560
    .line 268435561
    move-object/from16 v19, v0

    .line 268435562
    .line 268435563
    move-object/from16 v20, v7

    .line 268435564
    .line 268435565
    move-object/from16 v21, v6

    .line 268435566
    .line 268435567
    move-object/from16 v22, v5

    .line 268435568
    .line 268435569
    move-object/from16 v23, v4

    .line 268435570
    .line 268435571
    move-object/from16 v24, v10

    .line 268435572
    .line 268435573
    move-object/from16 p0, v3

    .line 268435574
    .line 268435575
    move-object/from16 p1, v2

    .line 268435576
    .line 268435577
    move-object/from16 p2, v9

    .line 268435578
    .line 268435579
    invoke-direct/range {v19 .. v28}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/1EL;LX/AHE;LX/7Kq;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435580
    .line 268435581
    .line 268435582
    invoke-interface {v15, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435583
    .line 268435584
    .line 268435585
    :cond_1
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435586
    .line 268435587
    const/16 v21, 0x6

    .line 268435588
    .line 268435589
    const/16 v22, 0x1fc

    .line 268435590
    .line 268435591
    const/4 v12, 0x0

    .line 268435592
    move-object v13, v12

    .line 268435593
    move-object v14, v12

    .line 268435594
    move-object/from16 v16, v12

    .line 268435595
    .line 268435596
    move-object/from16 v19, v12

    .line 268435597
    .line 268435598
    move-object/from16 v20, v12

    .line 268435599
    .line 268435600
    move-object/from16 v17, v0

    .line 268435601
    .line 268435602
    move/from16 v23, v8

    .line 268435603
    .line 268435604
    invoke-static/range {v12 .. v23}, LX/2qx;->A01(LX/3Gw;LX/2or;LX/1X0;LX/2d4;LX/3C1;Lkotlin/jvm/functions/Function0;LX/JDN;LX/JDN;LX/JDN;IIZ)V

    .line 268435605
    .line 268435606
    .line 268435607
    goto :goto_0

    .line 268435608
    :cond_2
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 268435609
    .line 268435610
    .line 268435611
    :cond_3
    return-void
.end method
