.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $isEnabled$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;->$isEnabled$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;->invoke(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;->$isEnabled$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->areNotificationsEnabled(Landroid/content/Context;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    invoke-static {p0, p1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
