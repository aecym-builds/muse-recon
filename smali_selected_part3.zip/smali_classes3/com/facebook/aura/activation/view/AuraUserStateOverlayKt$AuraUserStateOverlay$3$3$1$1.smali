.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1"
    f = "AuraUserStateOverlay.kt"
    l = {
        0xb0
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $isResetting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onLogOut:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resetFailedTitle:Ljava/lang/String;

.field public final synthetic $userSession:LX/AHE;

.field public final synthetic $view:Landroid/view/View;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Landroidx/compose/runtime/MutableState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$view:Landroid/view/View;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$resetFailedTitle:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$view:Landroid/view/View;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$resetFailedTitle:Ljava/lang/String;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;-><init>(LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    throw v0

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    sget-object v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$userSession:LX/AHE;

    .line 21
    .line 22
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const/4 v0, 0x0

    .line 27
    iput-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->L$0:Ljava/lang/Object;

    .line 28
    .line 29
    iput v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->label:I

    .line 30
    .line 31
    invoke-virtual {v1, p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->debugResetActivation(LX/2M4;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    if-ne p1, v3, :cond_2

    .line 36
    .line 37
    return-object v3

    .line 38
    :goto_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :cond_2
    check-cast p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugResetActivationResult;

    .line 42
    .line 43
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 44
    .line 45
    const/4 v0, 0x0

    .line 46
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 47
    .line 48
    .line 49
    if-eqz p1, :cond_3

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$onLogOut:Lkotlin/jvm/functions/Function0;

    .line 52
    .line 53
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_3
    sget-object v3, Lcom/facebook/aura/vds/toast/AuraToast;->Companion:Lcom/facebook/aura/vds/toast/AuraToast$Companion;

    .line 58
    .line 59
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$view:Landroid/view/View;

    .line 60
    .line 61
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$resetFailedTitle:Ljava/lang/String;

    .line 62
    .line 63
    sget-object v0, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->LONG:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 64
    .line 65
    invoke-static {v2, v3, v0, v1}, LX/604;->A0c(Landroid/view/View;Lcom/facebook/aura/vds/toast/AuraToast$Companion;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 69
    :catch_0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$isResetting$delegate:Landroidx/compose/runtime/MutableState;

    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 73
    .line 74
    .line 75
    sget-object v3, Lcom/facebook/aura/vds/toast/AuraToast;->Companion:Lcom/facebook/aura/vds/toast/AuraToast$Companion;

    .line 76
    .line 77
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$view:Landroid/view/View;

    .line 78
    .line 79
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1$1;->$resetFailedTitle:Ljava/lang/String;

    .line 80
    .line 81
    sget-object v0, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->LONG:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 82
    .line 83
    invoke-static {v2, v3, v0, v1}, LX/604;->A0c(Landroid/view/View;Lcom/facebook/aura/vds/toast/AuraToast$Companion;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :goto_1
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 87
    .line 88
    return-object v3
.end method
