.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $annotatedString:LX/2iK;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onLinkClick:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $textAlign:I

.field public final synthetic $titlesByUrl:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2iK;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;I",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$annotatedString:LX/2iK;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$titlesByUrl:Ljava/util/Map;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$textAlign:I

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$onLinkClick:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$modifier:LX/3C1;

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$$changed:I

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$$default:I

    .line 13
    .line 14
    const/4 v0, 0x2

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 8

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$annotatedString:LX/2iK;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$titlesByUrl:Ljava/util/Map;

    .line 268435459
    .line 268435460
    iget v3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$textAlign:I

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$onLinkClick:LX/JDM;

    .line 268435463
    .line 268435464
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$modifier:LX/3C1;

    .line 268435465
    .line 268435466
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$$changed:I

    .line 268435467
    .line 268435468
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435469
    .line 268435470
    .line 268435471
    move-result v7

    .line 268435472
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$2;->$$default:I

    .line 268435473
    .line 268435474
    move-object v6, p1

    .line 268435475
    invoke-static/range {v1 .. v8}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->ScrollableLinkText-D30ufTU(LX/2iK;Ljava/util/Map;ILX/JDM;LX/3C1;LX/2d4;II)V

    .line 268435476
    .line 268435477
    .line 268435478
    return-void
.end method
