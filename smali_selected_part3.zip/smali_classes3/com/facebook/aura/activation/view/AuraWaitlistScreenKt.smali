.class public abstract Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CtaCrossfadeDurationMs:I = 0x12c

.field public static final OffsetY:F = 36.0f

.field public static final animationSpec:LX/ELU;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/ELU<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    const/high16 v3, 0x40000000    # 2.0f

    .line 1
    .line 2
    const-wide/high16 v0, 0x4059000000000000L    # 100.0

    .line 3
    .line 4
    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    .line 5
    .line 6
    .line 7
    move-result-wide v1

    .line 8
    double-to-float v0, v1

    .line 9
    mul-float/2addr v3, v0

    .line 10
    const/high16 v2, 0x41700000    # 15.0f

    .line 11
    .line 12
    div-float/2addr v2, v3

    .line 13
    const/4 v1, 0x0

    .line 14
    const/high16 v0, 0x42c80000    # 100.0f

    .line 15
    .line 16
    invoke-static {v1, v2, v0}, LX/001;->A0R(Ljava/lang/Object;FF)LX/ELU;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->animationSpec:LX/ELU;

    .line 21
    .line 22
    return-void
.end method

.method public static final AuraWaitlistScreen(Lcom/facebook/aura/activation/view/WaitlistScreenMode;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZILcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;LX/2d4;II)V
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/WaitlistScreenMode;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;ZI",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v13, p7

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v5, p0

    .line 4
    .line 5
    move-object/from16 v15, p1

    .line 6
    .line 7
    invoke-static {v5, v15}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v11

    .line 11
    const/4 v0, 0x3

    .line 12
    const/4 v10, 0x2

    .line 13
    move-object/from16 v4, p3

    .line 14
    .line 15
    invoke-static {v4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    const/4 v9, 0x6

    .line 19
    move-object/from16 v14, p6

    .line 20
    .line 21
    invoke-static {v14, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 22
    .line 23
    .line 24
    const v0, -0x7059950f

    .line 25
    .line 26
    .line 27
    move-object/from16 v6, p8

    .line 28
    .line 29
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 30
    .line 31
    .line 32
    move/from16 v3, p9

    .line 33
    .line 34
    and-int/lit8 v0, p9, 0x6

    .line 35
    .line 36
    if-nez v0, :cond_12

    .line 37
    .line 38
    invoke-static {v6, v5}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    or-int v7, v7, p9

    .line 43
    .line 44
    :goto_0
    and-int/lit8 v0, p9, 0x30

    .line 45
    .line 46
    if-nez v0, :cond_0

    .line 47
    .line 48
    invoke-static {v6, v15}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    or-int/2addr v7, v0

    .line 53
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 54
    .line 55
    move-object/from16 p9, p2

    .line 56
    .line 57
    if-nez v0, :cond_1

    .line 58
    .line 59
    move-object/from16 v0, p9

    .line 60
    .line 61
    invoke-static {v6, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    or-int/2addr v7, v0

    .line 66
    :cond_1
    and-int/lit16 v0, v3, 0xc00

    .line 67
    .line 68
    if-nez v0, :cond_2

    .line 69
    .line 70
    invoke-static {v6, v4}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    or-int/2addr v7, v0

    .line 75
    :cond_2
    and-int/lit16 v0, v3, 0x6000

    .line 76
    .line 77
    move/from16 p8, p4

    .line 78
    .line 79
    if-nez v0, :cond_3

    .line 80
    .line 81
    move/from16 v0, p8

    .line 82
    .line 83
    invoke-static {v6, v0}, LX/004;->A0m(LX/2d4;Z)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    or-int/2addr v7, v0

    .line 88
    :cond_3
    const/high16 v0, 0x30000

    .line 89
    .line 90
    and-int/2addr v0, v3

    .line 91
    move/from16 p7, p5

    .line 92
    .line 93
    if-nez v0, :cond_4

    .line 94
    .line 95
    move/from16 v0, p7

    .line 96
    .line 97
    invoke-static {v6, v0}, LX/008;->A0M(LX/2d4;I)I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    or-int/2addr v7, v0

    .line 102
    :cond_4
    const/high16 v0, 0x180000

    .line 103
    .line 104
    and-int/2addr v0, v3

    .line 105
    if-nez v0, :cond_5

    .line 106
    .line 107
    invoke-static {v6, v14}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    or-int/2addr v7, v0

    .line 112
    :cond_5
    move/from16 p6, p10

    .line 113
    .line 114
    move/from16 v0, p6

    .line 115
    .line 116
    and-int/lit16 v1, v0, 0x80

    .line 117
    .line 118
    const/high16 v0, 0xc00000

    .line 119
    .line 120
    if-nez v1, :cond_6

    .line 121
    .line 122
    and-int/2addr v0, v3

    .line 123
    if-nez v0, :cond_7

    .line 124
    .line 125
    invoke-static {v6, v13}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    :cond_6
    or-int/2addr v7, v0

    .line 130
    :cond_7
    invoke-static {v7}, LX/009;->A1J(I)Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    invoke-static {v0, v6, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_11

    .line 139
    .line 140
    if-eqz v1, :cond_8

    .line 141
    .line 142
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 143
    .line 144
    :cond_8
    sget-object v0, Lcom/facebook/aura/activation/view/WaitlistScreenMode;->JOINED:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

    .line 145
    .line 146
    invoke-static {v5, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    move-result v20

    .line 150
    shr-int/lit8 v0, v7, 0xf

    .line 151
    .line 152
    and-int/lit8 v23, v0, 0xe

    .line 153
    .line 154
    const/16 v24, 0x4

    .line 155
    .line 156
    const/4 v8, 0x0

    .line 157
    move/from16 v19, p7

    .line 158
    .line 159
    move-object/from16 v21, v8

    .line 160
    .line 161
    move-object/from16 v22, v6

    .line 162
    .line 163
    invoke-static/range {v19 .. v24}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->rememberAuraWaitlistCelebrationState(IZLcom/facebook/aura/activation/view/AuraConfettiDensity;LX/2d4;II)Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 164
    .line 165
    .line 166
    move-result-object v18

    .line 167
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 172
    .line 173
    if-ne v1, v0, :cond_9

    .line 174
    .line 175
    invoke-static {v6, v8}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    :cond_9
    check-cast v1, Landroidx/compose/runtime/MutableState;

    .line 180
    .line 181
    sget-object v22, LX/DqI;->ON_RESUME:LX/DqI;

    .line 182
    .line 183
    invoke-static {v7}, LX/005;->A1L(I)Z

    .line 184
    .line 185
    .line 186
    move-result v16

    .line 187
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v12

    .line 191
    if-nez v16, :cond_a

    .line 192
    .line 193
    if-ne v12, v0, :cond_b

    .line 194
    .line 195
    :cond_a
    new-instance v12, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$1$1;

    .line 196
    .line 197
    invoke-direct {v12, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 198
    .line 199
    .line 200
    invoke-interface {v6, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    :cond_b
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 204
    .line 205
    move-object/from16 v21, v6

    .line 206
    .line 207
    move-object/from16 v23, v8

    .line 208
    .line 209
    move-object/from16 v24, v12

    .line 210
    .line 211
    move/from16 v25, v9

    .line 212
    .line 213
    move/from16 v26, v10

    .line 214
    .line 215
    invoke-static/range {v21 .. v26}, LX/CcX;->A00(LX/2d4;LX/DqI;LX/07p;Lkotlin/jvm/functions/Function0;II)V

    .line 216
    .line 217
    .line 218
    if-eqz v20, :cond_10

    .line 219
    .line 220
    const v8, -0x48bf2c80

    .line 221
    .line 222
    .line 223
    invoke-interface {v6, v8}, LX/2d4;->Agj(I)V

    .line 224
    .line 225
    .line 226
    invoke-static {v6, v2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->RequestWaitlistNotificationPermission(LX/2d4;I)V

    .line 227
    .line 228
    .line 229
    :goto_1
    invoke-static {v6}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 233
    .line 234
    .line 235
    move-result v8

    .line 236
    if-eq v8, v2, :cond_f

    .line 237
    .line 238
    if-eq v8, v11, :cond_e

    .line 239
    .line 240
    if-ne v8, v10, :cond_13

    .line 241
    .line 242
    sget-object v25, Lcom/facebook/aura/analytics/hatch/HatchComponent;->WAITLIST_LIMITED:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 243
    .line 244
    :goto_2
    sget-object v26, LX/Dn6;->A02:LX/1Yw;

    .line 245
    .line 246
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v8

    .line 250
    if-ne v8, v0, :cond_c

    .line 251
    .line 252
    new-instance v8, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$2$1;

    .line 253
    .line 254
    invoke-direct {v8, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 255
    .line 256
    .line 257
    invoke-interface {v6, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    :cond_c
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 261
    .line 262
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;

    .line 263
    .line 264
    move-object/from16 v17, v14

    .line 265
    .line 266
    move-object/from16 v19, v5

    .line 267
    .line 268
    move/from16 v21, p8

    .line 269
    .line 270
    move-object/from16 v22, v15

    .line 271
    .line 272
    move-object/from16 v23, p9

    .line 273
    .line 274
    move-object/from16 v24, v1

    .line 275
    .line 276
    move-object/from16 v16, v0

    .line 277
    .line 278
    invoke-direct/range {v16 .. v24}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;-><init>(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lcom/facebook/aura/activation/view/WaitlistScreenMode;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 279
    .line 280
    .line 281
    const v1, 0x22ea746b

    .line 282
    .line 283
    .line 284
    invoke-static {v6, v0, v1}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 285
    .line 286
    .line 287
    move-result-object p2

    .line 288
    shr-int/lit8 p4, v7, 0x9

    .line 289
    .line 290
    const v0, 0xe000

    .line 291
    .line 292
    .line 293
    and-int p4, p4, v0

    .line 294
    .line 295
    const v0, 0x30c30

    .line 296
    .line 297
    .line 298
    or-int p4, p4, v0

    .line 299
    .line 300
    move-object/from16 v27, v18

    .line 301
    .line 302
    move-object/from16 p0, v8

    .line 303
    .line 304
    move-object/from16 p1, v13

    .line 305
    .line 306
    move-object/from16 p3, v6

    .line 307
    .line 308
    move/from16 p5, v2

    .line 309
    .line 310
    invoke-static/range {v25 .. v33}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistSurface(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 311
    .line 312
    .line 313
    :goto_3
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    if-eqz v0, :cond_d

    .line 318
    .line 319
    new-instance v10, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;

    .line 320
    .line 321
    move/from16 v16, p7

    .line 322
    .line 323
    move-object/from16 v17, v14

    .line 324
    .line 325
    move-object/from16 v18, v13

    .line 326
    .line 327
    move/from16 v19, v3

    .line 328
    .line 329
    move/from16 v20, p6

    .line 330
    .line 331
    move-object v11, v5

    .line 332
    move-object v12, v15

    .line 333
    move-object/from16 v13, p9

    .line 334
    .line 335
    move-object v14, v4

    .line 336
    move/from16 v15, p8

    .line 337
    .line 338
    invoke-direct/range {v10 .. v20}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$4;-><init>(Lcom/facebook/aura/activation/view/WaitlistScreenMode;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZILcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;II)V

    .line 339
    .line 340
    .line 341
    iput-object v10, v0, LX/J7V;->A06:LX/JDN;

    .line 342
    .line 343
    :cond_d
    return-void

    .line 344
    :cond_e
    sget-object v25, Lcom/facebook/aura/analytics/hatch/HatchComponent;->JOINED_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 345
    .line 346
    goto :goto_2

    .line 347
    :cond_f
    sget-object v25, Lcom/facebook/aura/analytics/hatch/HatchComponent;->WAITLIST_STATUS:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 348
    .line 349
    goto :goto_2

    .line 350
    :cond_10
    const v8, -0x48be748f

    .line 351
    .line 352
    .line 353
    invoke-interface {v6, v8}, LX/2d4;->Agj(I)V

    .line 354
    .line 355
    .line 356
    goto :goto_1

    .line 357
    :cond_11
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 358
    .line 359
    .line 360
    goto :goto_3

    .line 361
    :cond_12
    move v7, v3

    .line 362
    goto/16 :goto_0

    .line 363
    .line 364
    :cond_13
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 365
    .line 366
    .line 367
    move-result-object v0

    .line 368
    throw v0
.end method

.method public static final AuraWaitlistScreen$lambda$1(Landroidx/compose/runtime/MutableState;)LX/2sT;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;)",
            "LX/2sT;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/2sT;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final AuraWaitlistScreen$lambda$2(Landroidx/compose/runtime/MutableState;LX/2sT;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;",
            "LX/2sT;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HaveInviteCodeLink(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 26
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v2, p1

    .line 1
    .line 2
    const v0, -0x6db7040a

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_7

    .line 17
    .line 18
    invoke-static {v6, v5}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    or-int v1, v1, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v3, p4

    .line 25
    .line 26
    and-int/lit8 v9, p4, 0x2

    .line 27
    .line 28
    if-eqz v9, :cond_6

    .line 29
    .line 30
    or-int/lit8 v1, v1, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v7, v1, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v8, 0x0

    .line 37
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v6, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    if-eqz v9, :cond_1

    .line 48
    .line 49
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 50
    .line 51
    :cond_1
    const v0, 0x7f1207bf

    .line 52
    .line 53
    .line 54
    invoke-static {v6, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v12

    .line 58
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 59
    .line 60
    const/4 v0, 0x6

    .line 61
    invoke-static {v6, v7}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 62
    .line 63
    .line 64
    move-result-object v16

    .line 65
    invoke-virtual {v7, v6, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iget-wide v14, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 70
    .line 71
    const/4 v11, 0x3

    .line 72
    const/4 v7, 0x0

    .line 73
    invoke-static {v2}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    invoke-static {v8}, LX/1Y9;->A01(I)LX/1Y9;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    invoke-static {v1}, LX/008;->A1X(I)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    if-nez v0, :cond_2

    .line 90
    .line 91
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 92
    .line 93
    if-ne v1, v0, :cond_3

    .line 94
    .line 95
    :cond_2
    new-instance v1, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$HaveInviteCodeLink$1$1;

    .line 96
    .line 97
    invoke-direct {v1, v5}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$HaveInviteCodeLink$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 98
    .line 99
    .line 100
    invoke-interface {v6, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :cond_3
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 104
    .line 105
    const/4 v0, 0x1

    .line 106
    invoke-static {v10, v9, v7, v1, v0}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 107
    .line 108
    .line 109
    move-result-object v9

    .line 110
    const/high16 v1, 0x42400000    # 48.0f

    .line 111
    .line 112
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 113
    .line 114
    invoke-static {v9, v0, v1}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    sget-object v0, LX/2Id;->A04:LX/2rU;

    .line 119
    .line 120
    invoke-static {v0, v1, v8}, LX/2sI;->A01(LX/2rU;LX/3C1;Z)LX/3C1;

    .line 121
    .line 122
    .line 123
    move-result-object v13

    .line 124
    invoke-static {v11}, LX/2wS;->A01(I)LX/2wS;

    .line 125
    .line 126
    .line 127
    move-result-object v19

    .line 128
    const/16 p4, 0x3fb0

    .line 129
    .line 130
    move-object/from16 v18, v7

    .line 131
    .line 132
    move/from16 v21, v8

    .line 133
    .line 134
    move/from16 v22, v8

    .line 135
    .line 136
    move/from16 v23, v8

    .line 137
    .line 138
    move-object/from16 v24, v7

    .line 139
    .line 140
    move-object/from16 v25, v7

    .line 141
    .line 142
    move-object/from16 p0, v7

    .line 143
    .line 144
    move-object/from16 p1, v6

    .line 145
    .line 146
    move/from16 p2, v8

    .line 147
    .line 148
    move/from16 p3, v8

    .line 149
    .line 150
    move/from16 v20, v8

    .line 151
    .line 152
    move-object/from16 v17, v7

    .line 153
    .line 154
    invoke-static/range {v12 .. v30}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 155
    .line 156
    .line 157
    :goto_2
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    if-eqz v1, :cond_4

    .line 162
    .line 163
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$HaveInviteCodeLink$2;

    .line 164
    .line 165
    invoke-direct {v0, v5, v2, v4, v3}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$HaveInviteCodeLink$2;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 166
    .line 167
    .line 168
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 169
    .line 170
    :cond_4
    return-void

    .line 171
    :cond_5
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 172
    .line 173
    .line 174
    goto :goto_2

    .line 175
    :cond_6
    and-int/lit8 v0, p3, 0x30

    .line 176
    .line 177
    if-nez v0, :cond_0

    .line 178
    .line 179
    invoke-static {v6, v2}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    or-int/2addr v1, v0

    .line 184
    goto/16 :goto_1

    .line 185
    .line 186
    :cond_7
    move v1, v4

    .line 187
    goto/16 :goto_0
.end method

.method public static final JoinWaitlistCta(ZZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p3

    .line 1
    .line 2
    const v0, -0x6eedd801

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p4

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v0, p5

    .line 11
    .line 12
    and-int/lit8 v1, p5, 0x6

    .line 13
    .line 14
    move/from16 v13, p0

    .line 15
    .line 16
    if-nez v1, :cond_7

    .line 17
    .line 18
    invoke-static {v6, v13}, LX/004;->A0i(LX/2d4;Z)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    or-int v2, v2, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v1, p5, 0x30

    .line 25
    .line 26
    move/from16 v14, p1

    .line 27
    .line 28
    if-nez v1, :cond_0

    .line 29
    .line 30
    invoke-static {v6, v14}, LX/004;->A0j(LX/2d4;Z)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    or-int/2addr v2, v1

    .line 35
    :cond_0
    and-int/lit16 v1, v0, 0x180

    .line 36
    .line 37
    move-object/from16 v15, p2

    .line 38
    .line 39
    if-nez v1, :cond_1

    .line 40
    .line 41
    invoke-static {v6, v15}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    or-int/2addr v2, v1

    .line 46
    :cond_1
    move/from16 p0, p6

    .line 47
    .line 48
    and-int/lit8 v4, p6, 0x8

    .line 49
    .line 50
    if-eqz v4, :cond_6

    .line 51
    .line 52
    or-int/lit16 v2, v2, 0xc00

    .line 53
    .line 54
    :cond_2
    :goto_1
    and-int/lit16 v3, v2, 0x493

    .line 55
    .line 56
    const/16 v1, 0x492

    .line 57
    .line 58
    const/4 v12, 0x0

    .line 59
    invoke-static {v3, v1}, LX/003;->A1H(II)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    invoke-static {v1, v6, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_5

    .line 68
    .line 69
    if-eqz v4, :cond_3

    .line 70
    .line 71
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 72
    .line 73
    :cond_3
    const v1, 0x7f120339

    .line 74
    .line 75
    .line 76
    invoke-static {v6, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p3

    .line 80
    const v1, 0x7f1207c0

    .line 81
    .line 82
    .line 83
    invoke-static {v6, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p2

    .line 87
    const/16 v1, 0x12c

    .line 88
    .line 89
    invoke-static {v1, v12}, LX/002;->A0T(II)LX/E1b;

    .line 90
    .line 91
    .line 92
    move-result-object v5

    .line 93
    const/4 v4, 0x6

    .line 94
    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 95
    .line 96
    .line 97
    move-result-object v8

    .line 98
    new-instance v3, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;

    .line 99
    .line 100
    move-object/from16 p1, v3

    .line 101
    .line 102
    move/from16 p4, v13

    .line 103
    .line 104
    move/from16 p5, v14

    .line 105
    .line 106
    move-object/from16 p6, v15

    .line 107
    .line 108
    invoke-direct/range {p1 .. p6}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;-><init>(Ljava/lang/String;Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;)V

    .line 109
    .line 110
    .line 111
    const v1, 0x6ca3f260

    .line 112
    .line 113
    .line 114
    invoke-static {v6, v3, v1}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    and-int/lit8 v1, v2, 0xe

    .line 119
    .line 120
    or-int/lit16 v11, v1, 0x6d80

    .line 121
    .line 122
    shr-int/2addr v2, v4

    .line 123
    and-int/lit8 v1, v2, 0x70

    .line 124
    .line 125
    or-int/2addr v11, v1

    .line 126
    const-string v9, "waitlistCtaState"

    .line 127
    .line 128
    invoke-static/range {v5 .. v12}, LX/2ra;->A01(LX/DwR;LX/2d4;LX/3C1;Ljava/lang/Object;Ljava/lang/String;LX/JDQ;II)V

    .line 129
    .line 130
    .line 131
    :goto_2
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    if-eqz v1, :cond_4

    .line 136
    .line 137
    new-instance v12, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$2;

    .line 138
    .line 139
    move-object/from16 v16, v7

    .line 140
    .line 141
    move/from16 v17, v0

    .line 142
    .line 143
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$2;-><init>(ZZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 144
    .line 145
    .line 146
    iput-object v12, v1, LX/J7V;->A06:LX/JDN;

    .line 147
    .line 148
    :cond_4
    return-void

    .line 149
    :cond_5
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 150
    .line 151
    .line 152
    goto :goto_2

    .line 153
    :cond_6
    and-int/lit16 v1, v0, 0xc00

    .line 154
    .line 155
    if-nez v1, :cond_2

    .line 156
    .line 157
    invoke-static {v6, v7}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    or-int/2addr v2, v1

    .line 162
    goto :goto_1

    .line 163
    :cond_7
    move v2, v0

    .line 164
    goto/16 :goto_0
.end method

.method public static final NotificationOptInCta(LX/3C1;LX/2d4;II)V
    .locals 40

    .line 0
    move-object/from16 v15, p0

    .line 1
    .line 2
    const v0, -0x70d98ee9

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p1

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v11, p3

    .line 11
    .line 12
    and-int/lit8 v4, p3, 0x1

    .line 13
    .line 14
    const/4 v9, 0x2

    .line 15
    move/from16 v1, p2

    .line 16
    .line 17
    if-eqz v4, :cond_e

    .line 18
    .line 19
    or-int/lit8 v7, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v3, v7, 0x3

    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    invoke-static {v3, v9}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    invoke-static {v3, v2, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-eqz v3, :cond_d

    .line 33
    .line 34
    if-eqz v4, :cond_0

    .line 35
    .line 36
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 37
    .line 38
    :cond_0
    invoke-static {v2}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 39
    .line 40
    .line 41
    move-result-object v13

    .line 42
    sget-object v3, LX/3J2;->A00:LX/Ip3;

    .line 43
    .line 44
    invoke-interface {v2, v3}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v6

    .line 48
    check-cast v6, Landroid/app/Activity;

    .line 49
    .line 50
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 55
    .line 56
    if-ne v8, v4, :cond_1

    .line 57
    .line 58
    invoke-static {v13}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->areNotificationsEnabled(Landroid/content/Context;)Z

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    invoke-static {v2, v3}, LX/005;->A0Y(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 63
    .line 64
    .line 65
    move-result-object v8

    .line 66
    :cond_1
    check-cast v8, Landroidx/compose/runtime/MutableState;

    .line 67
    .line 68
    invoke-static {v2, v4, v0}, LX/005;->A0k(LX/2d4;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 73
    .line 74
    invoke-interface {v2, v13}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v10

    .line 78
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    if-nez v10, :cond_2

    .line 83
    .line 84
    if-ne v5, v4, :cond_3

    .line 85
    .line 86
    :cond_2
    new-instance v5, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;

    .line 87
    .line 88
    invoke-direct {v5, v13, v8}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$notificationPermissionLauncher$1$1;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V

    .line 89
    .line 90
    .line 91
    invoke-interface {v2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    :cond_3
    check-cast v5, LX/JDM;

    .line 95
    .line 96
    invoke-static {v5, v2, v0, v0}, Lcom/facebook/aura/utils/HatchNotificationPermissionLauncherKt;->rememberNotificationPermissionLauncher(LX/JDM;LX/2d4;II)LX/166;

    .line 97
    .line 98
    .line 99
    move-result-object v5

    .line 100
    sget-object v17, LX/DqI;->ON_RESUME:LX/DqI;

    .line 101
    .line 102
    invoke-interface {v2, v13}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v12

    .line 106
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v10

    .line 110
    if-nez v12, :cond_4

    .line 111
    .line 112
    if-ne v10, v4, :cond_5

    .line 113
    .line 114
    :cond_4
    new-instance v10, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$1$1;

    .line 115
    .line 116
    invoke-direct {v10, v13, v8}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$1$1;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {v2, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :cond_5
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 123
    .line 124
    const/16 v20, 0x6

    .line 125
    .line 126
    const/4 v12, 0x0

    .line 127
    move-object/from16 v16, v2

    .line 128
    .line 129
    move-object/from16 v18, v12

    .line 130
    .line 131
    move-object/from16 v19, v10

    .line 132
    .line 133
    move/from16 v21, v9

    .line 134
    .line 135
    invoke-static/range {v16 .. v21}, LX/CcX;->A00(LX/2d4;LX/DqI;LX/07p;Lkotlin/jvm/functions/Function0;II)V

    .line 136
    .line 137
    .line 138
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 139
    .line 140
    .line 141
    move-result v10

    .line 142
    const v9, 0x7f0800c9

    .line 143
    .line 144
    .line 145
    if-eqz v10, :cond_6

    .line 146
    .line 147
    const v9, 0x7f0800e6

    .line 148
    .line 149
    .line 150
    :cond_6
    invoke-static {v2, v9, v0}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 151
    .line 152
    .line 153
    move-result-object v10

    .line 154
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 155
    .line 156
    .line 157
    move-result v9

    .line 158
    if-eqz v9, :cond_c

    .line 159
    .line 160
    const v9, -0x756f9892

    .line 161
    .line 162
    .line 163
    invoke-interface {v2, v9}, LX/2d4;->Agj(I)V

    .line 164
    .line 165
    .line 166
    const v9, 0x7f1207c1

    .line 167
    .line 168
    .line 169
    :goto_1
    invoke-static {v2, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v13

    .line 173
    invoke-static {v2}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 174
    .line 175
    .line 176
    move-result-object v9

    .line 177
    sget-object v17, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->MEDIUM:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 178
    .line 179
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 180
    .line 181
    .line 182
    move-result v8

    .line 183
    xor-int/lit8 v21, v8, 0x1

    .line 184
    .line 185
    new-instance v8, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;

    .line 186
    .line 187
    invoke-direct {v8, v10}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;-><init>(LX/2l9;)V

    .line 188
    .line 189
    .line 190
    const v10, -0x36a88aa1

    .line 191
    .line 192
    .line 193
    invoke-static {v2, v8, v10}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 194
    .line 195
    .line 196
    move-result-object v18

    .line 197
    invoke-static {v2, v6, v5}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result v10

    .line 201
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v8

    .line 205
    if-nez v10, :cond_7

    .line 206
    .line 207
    if-ne v8, v4, :cond_8

    .line 208
    .line 209
    :cond_7
    new-instance v8, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;

    .line 210
    .line 211
    invoke-direct {v8, v6, v5, v3}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$3$1;-><init>(Landroid/app/Activity;LX/166;Landroidx/compose/runtime/MutableState;)V

    .line 212
    .line 213
    .line 214
    invoke-interface {v2, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    :cond_8
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 218
    .line 219
    shl-int/lit8 v5, v7, 0x9

    .line 220
    .line 221
    and-int/lit16 v5, v5, 0x1c00

    .line 222
    .line 223
    const/high16 v6, 0x1b0000

    .line 224
    .line 225
    or-int/2addr v5, v6

    .line 226
    const p3, 0x7ffbd95

    .line 227
    .line 228
    .line 229
    move-object v14, v12

    .line 230
    move-object/from16 v16, v12

    .line 231
    .line 232
    move/from16 v20, v0

    .line 233
    .line 234
    move/from16 v22, v0

    .line 235
    .line 236
    move/from16 v23, v0

    .line 237
    .line 238
    move-object/from16 v24, v12

    .line 239
    .line 240
    move-object/from16 v25, v12

    .line 241
    .line 242
    move-object/from16 v26, v8

    .line 243
    .line 244
    move-object/from16 v27, v12

    .line 245
    .line 246
    move-object/from16 v28, v12

    .line 247
    .line 248
    move-object/from16 v29, v12

    .line 249
    .line 250
    move-object/from16 v30, v12

    .line 251
    .line 252
    move-object/from16 v31, v12

    .line 253
    .line 254
    move-object/from16 v32, v12

    .line 255
    .line 256
    move-object/from16 v33, v12

    .line 257
    .line 258
    move-object/from16 v34, v12

    .line 259
    .line 260
    move/from16 v35, v0

    .line 261
    .line 262
    move/from16 v36, v0

    .line 263
    .line 264
    move/from16 v37, v0

    .line 265
    .line 266
    move/from16 v38, v0

    .line 267
    .line 268
    move-object/from16 v39, v2

    .line 269
    .line 270
    move/from16 p0, v5

    .line 271
    .line 272
    move/from16 p1, v0

    .line 273
    .line 274
    move/from16 p2, v0

    .line 275
    .line 276
    move/from16 v19, v0

    .line 277
    .line 278
    invoke-static/range {v12 .. v43}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 279
    .line 280
    .line 281
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 282
    .line 283
    .line 284
    move-result v5

    .line 285
    if-eqz v5, :cond_b

    .line 286
    .line 287
    const v5, -0x75622906

    .line 288
    .line 289
    .line 290
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 291
    .line 292
    .line 293
    const v5, 0x7f1210b8

    .line 294
    .line 295
    .line 296
    invoke-static {v2, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object v16

    .line 300
    const v5, 0x7f1210b7

    .line 301
    .line 302
    .line 303
    invoke-static {v2, v5}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v17

    .line 307
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object v5

    .line 311
    if-ne v5, v4, :cond_9

    .line 312
    .line 313
    new-instance v5, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$4$1;

    .line 314
    .line 315
    invoke-direct {v5, v3}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$4$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 316
    .line 317
    .line 318
    invoke-interface {v2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 319
    .line 320
    .line 321
    :cond_9
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 322
    .line 323
    const/16 v26, 0x180

    .line 324
    .line 325
    const/16 v27, 0x1f8

    .line 326
    .line 327
    move-object/from16 v18, v5

    .line 328
    .line 329
    move-object/from16 v19, v12

    .line 330
    .line 331
    move-object/from16 v20, v12

    .line 332
    .line 333
    move-object/from16 v21, v12

    .line 334
    .line 335
    move-object/from16 v22, v12

    .line 336
    .line 337
    move-object/from16 v23, v12

    .line 338
    .line 339
    move-object/from16 v25, v2

    .line 340
    .line 341
    invoke-static/range {v16 .. v27}, Lcom/facebook/aura/utils/HatchPermissionDeniedDialogKt;->HatchPermissionDeniedDialog(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 342
    .line 343
    .line 344
    :goto_2
    invoke-static {v9, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 345
    .line 346
    .line 347
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 348
    .line 349
    .line 350
    move-result-object v2

    .line 351
    if-eqz v2, :cond_a

    .line 352
    .line 353
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$5;

    .line 354
    .line 355
    invoke-direct {v0, v15, v1, v11}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$5;-><init>(LX/3C1;II)V

    .line 356
    .line 357
    .line 358
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 359
    .line 360
    :cond_a
    return-void

    .line 361
    :cond_b
    const v3, -0x755db015

    .line 362
    .line 363
    .line 364
    invoke-interface {v2, v3}, LX/2d4;->Agj(I)V

    .line 365
    .line 366
    .line 367
    goto :goto_2

    .line 368
    :cond_c
    const v9, -0x756e196e

    .line 369
    .line 370
    .line 371
    invoke-interface {v2, v9}, LX/2d4;->Agj(I)V

    .line 372
    .line 373
    .line 374
    const v9, 0x7f1207be

    .line 375
    .line 376
    .line 377
    goto/16 :goto_1

    .line 378
    .line 379
    :cond_d
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 380
    .line 381
    .line 382
    goto :goto_3

    .line 383
    :cond_e
    and-int/lit8 v0, p2, 0x6

    .line 384
    .line 385
    if-nez v0, :cond_f

    .line 386
    .line 387
    invoke-static {v2, v15}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 388
    .line 389
    .line 390
    move-result v0

    .line 391
    or-int v7, p2, v0

    .line 392
    .line 393
    goto/16 :goto_0

    .line 394
    .line 395
    :cond_f
    move v7, v1

    .line 396
    goto/16 :goto_0
.end method

.method public static final NotificationOptInCta$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final NotificationOptInCta$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final NotificationOptInCta$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final NotificationOptInCta$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final RequestWaitlistNotificationPermission(LX/2d4;I)V
    .locals 4

    .line 0
    const v0, 0x5ca63423

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_3

    .line 17
    .line 18
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 19
    .line 20
    invoke-interface {p0, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    check-cast v3, Landroid/app/Activity;

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    invoke-static {v0, p0, v1, v2}, Lcom/facebook/aura/utils/HatchNotificationPermissionLauncherKt;->rememberNotificationPermissionLauncher(LX/JDM;LX/2d4;II)LX/166;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-static {p0, v3, v2}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v1, :cond_0

    .line 40
    .line 41
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 42
    .line 43
    if-ne v0, v1, :cond_1

    .line 44
    .line 45
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;

    .line 46
    .line 47
    invoke-direct {v0, v3, v2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$1$1;-><init>(Landroid/app/Activity;LX/166;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    invoke-static {p0, v0, v3}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :goto_0
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$2;

    .line 63
    .line 64
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$RequestWaitlistNotificationPermission$2;-><init>(I)V

    .line 65
    .line 66
    .line 67
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 68
    .line 69
    :cond_2
    return-void

    .line 70
    :cond_3
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 71
    .line 72
    .line 73
    goto :goto_0
.end method

.method public static final WaitlistHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 34

    .line 0
    move-object/from16 v15, p2

    .line 1
    .line 2
    const v0, -0x63e57726

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 p4, p0

    .line 15
    .line 16
    if-nez v0, :cond_9

    .line 17
    .line 18
    move-object/from16 v0, p4

    .line 19
    .line 20
    invoke-static {v2, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    or-int/2addr v4, v1

    .line 25
    :goto_0
    and-int/lit8 v0, v1, 0x30

    .line 26
    .line 27
    move-object/from16 p3, p1

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    move-object/from16 v0, p3

    .line 32
    .line 33
    invoke-static {v2, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    or-int/2addr v4, v0

    .line 38
    :cond_0
    move/from16 p2, p5

    .line 39
    .line 40
    and-int/lit8 v5, p5, 0x4

    .line 41
    .line 42
    if-eqz v5, :cond_8

    .line 43
    .line 44
    or-int/lit16 v4, v4, 0x180

    .line 45
    .line 46
    :cond_1
    :goto_1
    and-int/lit16 v3, v4, 0x93

    .line 47
    .line 48
    const/16 v0, 0x92

    .line 49
    .line 50
    const/4 v14, 0x0

    .line 51
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_c

    .line 60
    .line 61
    if-eqz v5, :cond_2

    .line 62
    .line 63
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 70
    .line 71
    const/16 v24, 0x0

    .line 72
    .line 73
    const/16 v16, 0x0

    .line 74
    .line 75
    if-ne v10, v9, :cond_3

    .line 76
    .line 77
    invoke-static/range {v24 .. v24}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-static {v2, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 82
    .line 83
    .line 84
    move-result-object v10

    .line 85
    :cond_3
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 86
    .line 87
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    if-ne v7, v9, :cond_4

    .line 92
    .line 93
    invoke-static/range {v24 .. v24}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-static {v2, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 98
    .line 99
    .line 100
    move-result-object v7

    .line 101
    :cond_4
    check-cast v7, Landroidx/compose/runtime/MutableState;

    .line 102
    .line 103
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 104
    .line 105
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    if-ne v3, v9, :cond_5

    .line 110
    .line 111
    new-instance v3, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1;

    .line 112
    .line 113
    move-object/from16 v0, v16

    .line 114
    .line 115
    invoke-direct {v3, v10, v7, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$1$1;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 116
    .line 117
    .line 118
    invoke-interface {v2, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :cond_5
    check-cast v3, LX/JDN;

    .line 122
    .line 123
    const/4 v8, 0x6

    .line 124
    invoke-static {v2, v5, v3}, LX/CdB;->A06(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 125
    .line 126
    .line 127
    invoke-static {v2}, LX/3Rp;->A02(LX/2d4;)LX/34Y;

    .line 128
    .line 129
    .line 130
    move-result-object v11

    .line 131
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 132
    .line 133
    invoke-virtual {v6, v2, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    invoke-interface {v2, v11}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    if-nez v3, :cond_6

    .line 146
    .line 147
    if-ne v0, v9, :cond_7

    .line 148
    .line 149
    :cond_6
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;

    .line 150
    .line 151
    invoke-direct {v0, v11, v7, v10}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;-><init>(LX/34Y;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 152
    .line 153
    .line 154
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_7
    invoke-static {v15, v0}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    sget-object v0, LX/2Id;->A00:LX/2sS;

    .line 162
    .line 163
    invoke-static {v2, v0}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 164
    .line 165
    .line 166
    move-result-object v13

    .line 167
    move-object v0, v2

    .line 168
    check-cast v0, LX/J7I;

    .line 169
    .line 170
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 171
    .line 172
    .line 173
    move-result v12

    .line 174
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 175
    .line 176
    .line 177
    move-result-object v11

    .line 178
    invoke-static {v2, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 179
    .line 180
    .line 181
    move-result-object v10

    .line 182
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 183
    .line 184
    iget-object v3, v0, LX/J7I;->A0V:LX/3DJ;

    .line 185
    .line 186
    if-nez v3, :cond_a

    .line 187
    .line 188
    invoke-static {}, LX/1VY;->A00()V

    .line 189
    .line 190
    .line 191
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    throw v0

    .line 196
    :cond_8
    and-int/lit16 v0, v1, 0x180

    .line 197
    .line 198
    if-nez v0, :cond_1

    .line 199
    .line 200
    invoke-static {v2, v15}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 201
    .line 202
    .line 203
    move-result v0

    .line 204
    or-int/2addr v4, v0

    .line 205
    goto/16 :goto_1

    .line 206
    .line 207
    :cond_9
    move v4, v1

    .line 208
    goto/16 :goto_0

    .line 209
    .line 210
    :cond_a
    invoke-static {v2, v0, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 211
    .line 212
    .line 213
    invoke-static {v2, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 214
    .line 215
    .line 216
    const v3, 0x7f0801e0

    .line 217
    .line 218
    .line 219
    invoke-static {v2, v3, v14}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 220
    .line 221
    .line 222
    move-result-object v21

    .line 223
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 224
    .line 225
    const/high16 v7, 0x42500000    # 52.0f

    .line 226
    .line 227
    invoke-static {v3, v7}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 228
    .line 229
    .line 230
    move-result-object v19

    .line 231
    sget v7, LX/2l9;->$stable:I

    .line 232
    .line 233
    or-int/lit16 v7, v7, 0x1b0

    .line 234
    .line 235
    const/16 v26, 0x78

    .line 236
    .line 237
    move-object/from16 v17, v2

    .line 238
    .line 239
    move-object/from16 v18, v16

    .line 240
    .line 241
    move-object/from16 v20, v16

    .line 242
    .line 243
    move-object/from16 v22, v16

    .line 244
    .line 245
    move-object/from16 v23, v16

    .line 246
    .line 247
    move/from16 v25, v7

    .line 248
    .line 249
    invoke-static/range {v17 .. v26}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 250
    .line 251
    .line 252
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 253
    .line 254
    invoke-static {v2, v3, v7}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v6, v2, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 258
    .line 259
    .line 260
    move-result-object v7

    .line 261
    iget-object v10, v7, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Emphasized:LX/2hg;

    .line 262
    .line 263
    iget-wide v7, v5, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 264
    .line 265
    const/4 v12, 0x3

    .line 266
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v11

    .line 270
    if-ne v11, v9, :cond_b

    .line 271
    .line 272
    sget-object v11, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$3$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$3$1$1;

    .line 273
    .line 274
    invoke-interface {v2, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    :cond_b
    invoke-static {v3, v11, v14}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 278
    .line 279
    .line 280
    move-result-object v18

    .line 281
    invoke-static {v12}, LX/2wS;->A01(I)LX/2wS;

    .line 282
    .line 283
    .line 284
    move-result-object v24

    .line 285
    and-int/lit8 v33, v4, 0xe

    .line 286
    .line 287
    const/16 p1, 0x3fb0

    .line 288
    .line 289
    move-object/from16 v21, v10

    .line 290
    .line 291
    move/from16 v25, v14

    .line 292
    .line 293
    move/from16 v26, v14

    .line 294
    .line 295
    move/from16 v27, v14

    .line 296
    .line 297
    move/from16 v28, v14

    .line 298
    .line 299
    move-object/from16 v29, v16

    .line 300
    .line 301
    move-object/from16 v30, v16

    .line 302
    .line 303
    move-object/from16 v31, v16

    .line 304
    .line 305
    move-object/from16 v32, v2

    .line 306
    .line 307
    move/from16 p0, v14

    .line 308
    .line 309
    move-object/from16 v17, p4

    .line 310
    .line 311
    move-wide/from16 v19, v7

    .line 312
    .line 313
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 314
    .line 315
    .line 316
    invoke-static {v2, v3}, LX/1Vt;->A02(LX/2d4;LX/3C1;)V

    .line 317
    .line 318
    .line 319
    invoke-static {v2, v6}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 320
    .line 321
    .line 322
    move-result-object v21

    .line 323
    iget-wide v5, v5, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 324
    .line 325
    invoke-static {v12}, LX/2wS;->A01(I)LX/2wS;

    .line 326
    .line 327
    .line 328
    move-result-object v24

    .line 329
    shr-int/lit8 v3, v4, 0x3

    .line 330
    .line 331
    and-int/lit8 v33, v3, 0xe

    .line 332
    .line 333
    const/16 p1, 0x3fb2

    .line 334
    .line 335
    move-object/from16 v17, p3

    .line 336
    .line 337
    move-object/from16 v18, v16

    .line 338
    .line 339
    move-wide/from16 v19, v5

    .line 340
    .line 341
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 342
    .line 343
    .line 344
    const/4 v3, 0x1

    .line 345
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 346
    .line 347
    .line 348
    goto :goto_2

    .line 349
    :cond_c
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 350
    .line 351
    .line 352
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 353
    .line 354
    .line 355
    move-result-object v2

    .line 356
    if-eqz v2, :cond_d

    .line 357
    .line 358
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$4;

    .line 359
    .line 360
    move-object/from16 v31, v0

    .line 361
    .line 362
    move-object/from16 v32, p4

    .line 363
    .line 364
    move-object/from16 v33, p3

    .line 365
    .line 366
    move-object/from16 p0, v15

    .line 367
    .line 368
    move/from16 p1, v1

    .line 369
    .line 370
    invoke-direct/range {v31 .. v36}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$4;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 371
    .line 372
    .line 373
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 374
    .line 375
    :cond_d
    return-void
.end method

.method public static final WaitlistHeader$lambda$1(Landroidx/compose/runtime/MutableState;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final WaitlistHeader$lambda$2(Landroidx/compose/runtime/MutableState;F)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;F)V"
        }
    .end annotation

    .line 0
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {p0, v0}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final WaitlistHeader$lambda$4(Landroidx/compose/runtime/MutableState;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final WaitlistHeader$lambda$5(Landroidx/compose/runtime/MutableState;F)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;F)V"
        }
    .end annotation

    .line 0
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {p0, v0}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final WaitlistSurface(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
            "LX/Dps;",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p4

    .line 1
    .line 2
    const v1, 0x411d5fe0

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p6

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p7

    .line 11
    .line 12
    and-int/lit8 v2, p7, 0x6

    .line 13
    .line 14
    move-object/from16 v14, p0

    .line 15
    .line 16
    if-nez v2, :cond_9

    .line 17
    .line 18
    invoke-static {v0, v14}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 19
    .line 20
    .line 21
    move-result v9

    .line 22
    or-int v9, v9, p7

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v2, p7, 0x30

    .line 25
    .line 26
    move-object/from16 v8, p1

    .line 27
    .line 28
    if-nez v2, :cond_0

    .line 29
    .line 30
    invoke-static {v0, v8}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    or-int/2addr v9, v2

    .line 35
    :cond_0
    and-int/lit16 v2, v1, 0x180

    .line 36
    .line 37
    move-object/from16 v7, p2

    .line 38
    .line 39
    if-nez v2, :cond_1

    .line 40
    .line 41
    invoke-static {v0, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    or-int/2addr v9, v2

    .line 46
    :cond_1
    and-int/lit16 v2, v1, 0xc00

    .line 47
    .line 48
    move-object/from16 v6, p3

    .line 49
    .line 50
    if-nez v2, :cond_2

    .line 51
    .line 52
    invoke-static {v0, v6}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    or-int/2addr v9, v2

    .line 57
    :cond_2
    move/from16 p1, p8

    .line 58
    .line 59
    and-int/lit8 v3, p8, 0x10

    .line 60
    .line 61
    if-eqz v3, :cond_8

    .line 62
    .line 63
    or-int/lit16 v9, v9, 0x6000

    .line 64
    .line 65
    :cond_3
    :goto_1
    const/high16 v2, 0x30000

    .line 66
    .line 67
    and-int v2, v2, p7

    .line 68
    .line 69
    move-object/from16 v4, p5

    .line 70
    .line 71
    if-nez v2, :cond_4

    .line 72
    .line 73
    invoke-static {v0, v4}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    or-int/2addr v9, v2

    .line 78
    :cond_4
    invoke-static {v9}, LX/005;->A1C(I)Z

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    invoke-static {v2, v0, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    if-eqz v2, :cond_7

    .line 87
    .line 88
    if-eqz v3, :cond_5

    .line 89
    .line 90
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 91
    .line 92
    :cond_5
    invoke-static {v5}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 93
    .line 94
    .line 95
    move-result-object v10

    .line 96
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 97
    .line 98
    const/16 p7, 0x6

    .line 99
    .line 100
    invoke-static {v0, v2}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 101
    .line 102
    .line 103
    move-result-wide v2

    .line 104
    const/4 v15, 0x0

    .line 105
    invoke-static {v10, v2, v3}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    shr-int/lit8 v2, v9, 0x3

    .line 110
    .line 111
    and-int/lit16 v2, v2, 0x3f0

    .line 112
    .line 113
    invoke-static {v3, v7, v6, v0, v2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->auraWaitlistConfetti(LX/3C1;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v9

    .line 117
    sget-object v10, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 118
    .line 119
    sget-object v11, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 120
    .line 121
    sget-object v12, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 122
    .line 123
    sget-object v13, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 124
    .line 125
    const-wide/16 v18, 0x1f4

    .line 126
    .line 127
    const/16 v20, 0x0

    .line 128
    .line 129
    move-object/from16 v16, v15

    .line 130
    .line 131
    move-object/from16 v17, v15

    .line 132
    .line 133
    move-object/from16 v21, v15

    .line 134
    .line 135
    move-object/from16 v22, v15

    .line 136
    .line 137
    move-object/from16 p0, v15

    .line 138
    .line 139
    invoke-static/range {v9 .. v23}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-static {v2}, LX/6jg;->A02(LX/3C1;)LX/3C1;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    invoke-static {v2}, LX/6jg;->A01(LX/3C1;)LX/3C1;

    .line 148
    .line 149
    .line 150
    move-result-object p4

    .line 151
    new-instance v3, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;

    .line 152
    .line 153
    invoke-direct {v3, v8, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;-><init>(LX/Dps;LX/JDQ;)V

    .line 154
    .line 155
    .line 156
    const v2, -0x436bbdca

    .line 157
    .line 158
    .line 159
    invoke-static {v0, v3, v2}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 160
    .line 161
    .line 162
    move-result-object p5

    .line 163
    const/16 p6, 0xc00

    .line 164
    .line 165
    const/16 p8, 0x0

    .line 166
    .line 167
    move-object/from16 p2, v0

    .line 168
    .line 169
    move-object/from16 p3, v15

    .line 170
    .line 171
    invoke-static/range {p2 .. p8}, LX/2vl;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/JDQ;IIZ)V

    .line 172
    .line 173
    .line 174
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 175
    .line 176
    .line 177
    move-result-object v2

    .line 178
    if-eqz v2, :cond_6

    .line 179
    .line 180
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;

    .line 181
    .line 182
    move-object/from16 v17, v14

    .line 183
    .line 184
    move-object/from16 v21, v5

    .line 185
    .line 186
    move-object/from16 v22, v4

    .line 187
    .line 188
    move/from16 p0, v1

    .line 189
    .line 190
    move-object/from16 v16, v0

    .line 191
    .line 192
    move-object/from16 v18, v8

    .line 193
    .line 194
    move-object/from16 v19, v7

    .line 195
    .line 196
    move-object/from16 v20, v6

    .line 197
    .line 198
    invoke-direct/range {v16 .. v24}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$2;-><init>(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;II)V

    .line 199
    .line 200
    .line 201
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 202
    .line 203
    :cond_6
    return-void

    .line 204
    :cond_7
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 205
    .line 206
    .line 207
    goto :goto_2

    .line 208
    :cond_8
    and-int/lit16 v2, v1, 0x6000

    .line 209
    .line 210
    if-nez v2, :cond_3

    .line 211
    .line 212
    invoke-static {v0, v5}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 213
    .line 214
    .line 215
    move-result v2

    .line 216
    or-int/2addr v9, v2

    .line 217
    goto/16 :goto_1

    .line 218
    .line 219
    :cond_9
    move v9, v1

    .line 220
    goto/16 :goto_0
.end method

.method public static final synthetic access$AuraWaitlistScreen$lambda$1(Landroidx/compose/runtime/MutableState;)LX/2sT;
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/2sT;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$AuraWaitlistScreen$lambda$2(Landroidx/compose/runtime/MutableState;LX/2sT;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HaveInviteCodeLink(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->HaveInviteCodeLink(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$JoinWaitlistCta(ZZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->JoinWaitlistCta(ZZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NotificationOptInCta(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->NotificationOptInCta(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NotificationOptInCta$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NotificationOptInCta$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$RequestWaitlistNotificationPermission(LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->RequestWaitlistNotificationPermission(LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$WaitlistHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$WaitlistHeader$lambda$1(Landroidx/compose/runtime/MutableState;)F
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final synthetic access$WaitlistHeader$lambda$2(Landroidx/compose/runtime/MutableState;F)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader$lambda$2(Landroidx/compose/runtime/MutableState;F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$WaitlistHeader$lambda$4(Landroidx/compose/runtime/MutableState;)F
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final synthetic access$WaitlistHeader$lambda$5(Landroidx/compose/runtime/MutableState;F)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader$lambda$5(Landroidx/compose/runtime/MutableState;F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$WaitlistSurface(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistSurface(Lcom/facebook/aura/analytics/hatch/HatchComponent;LX/Dps;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$areNotificationsEnabled(Landroid/content/Context;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->areNotificationsEnabled(Landroid/content/Context;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$getAnimationSpec$p()LX/ELU;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->animationSpec:LX/ELU;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final areNotificationsEnabled(Landroid/content/Context;)Z
    .locals 1

    .line 0
    new-instance v0, LX/IAc;

    .line 1
    .line 2
    invoke-direct {v0, p0}, LX/IAc;-><init>(Landroid/content/Context;)V

    .line 3
    .line 4
    .line 5
    iget-object v0, v0, LX/IAc;->A00:Landroid/app/NotificationManager;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method
