.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1"
    f = "AuraUserStateOverlay.kt"
    l = {
        0xfc
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $failedToastTitle:Ljava/lang/String;

.field public final synthetic $onStatusChangeFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $parentView:Landroid/view/View;

.field public final synthetic $status:LX/7Kq;

.field public final synthetic $successToastTitle:Ljava/lang/String;

.field public final synthetic $userSession:LX/AHE;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/AHE;LX/7Kq;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "LX/7Kq;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$status:LX/7Kq;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$parentView:Landroid/view/View;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$successToastTitle:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$failedToastTitle:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0, p7}, LX/DRu;-><init>(ILX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$status:LX/7Kq;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$parentView:Landroid/view/View;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$successToastTitle:Ljava/lang/String;

    .line 9
    .line 10
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$failedToastTitle:Ljava/lang/String;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;

    .line 13
    .line 14
    move-object p1, p2

    .line 15
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;-><init>(LX/AHE;LX/7Kq;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;Ljava/lang/String;LX/2M4;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 0
    move-object/from16 v2, p1

    .line 1
    .line 2
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v0, p0

    .line 5
    .line 6
    iget v1, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->label:I

    .line 7
    .line 8
    const/4 v4, 0x1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    if-ne v1, v4, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    throw v0

    .line 19
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :try_start_0
    sget-object v2, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 23
    .line 24
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$userSession:LX/AHE;

    .line 25
    .line 26
    invoke-virtual {v2, v1}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    iget-object v2, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$status:LX/7Kq;

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    iput-object v1, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->L$0:Ljava/lang/Object;

    .line 34
    .line 35
    iput v4, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->label:I

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->debugSetWaitlistStatus(LX/7Kq;ZLX/2M4;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    if-ne v2, v5, :cond_2

    .line 43
    .line 44
    return-object v5

    .line 45
    :goto_0
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2
    check-cast v2, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;

    .line 49
    .line 50
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 51
    .line 52
    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    if-eqz v2, :cond_3

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_3
    sget-object v1, Lcom/facebook/aura/vds/toast/AuraToast;->Companion:Lcom/facebook/aura/vds/toast/AuraToast$Companion;

    .line 59
    .line 60
    iget-object v2, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$parentView:Landroid/view/View;

    .line 61
    .line 62
    iget-object v3, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$failedToastTitle:Ljava/lang/String;

    .line 63
    .line 64
    sget-object v5, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->LONG:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 65
    .line 66
    const/4 v4, 0x0

    .line 67
    sget-object v7, Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;->INSTANCE:Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;

    .line 68
    .line 69
    const/4 v9, 0x0

    .line 70
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;->DEFAULT:Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 71
    .line 72
    sget-object p0, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->MEDIUM:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 73
    .line 74
    move-object v6, v4

    .line 75
    move-object v8, v4

    .line 76
    move-object v10, v4

    .line 77
    move-object v12, v4

    .line 78
    move-object v13, v4

    .line 79
    move v14, v9

    .line 80
    move v15, v9

    .line 81
    move-object/from16 v16, v4

    .line 82
    .line 83
    move-object/from16 v17, v4

    .line 84
    .line 85
    move-object/from16 v18, v4

    .line 86
    .line 87
    move-object/from16 p1, v4

    .line 88
    .line 89
    invoke-virtual/range {v1 .. v20}, Lcom/facebook/aura/vds/toast/AuraToast$Companion;->make-KDArT4I(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/toast/AuraToastOption;Landroid/view/View$OnClickListener;ZLjava/lang/Boolean;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Ljava/lang/Integer;Landroid/view/View;ZZLkotlin/jvm/functions/Function0;Ljava/lang/Float;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;)Lcom/facebook/aura/vds/toast/AuraToast;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    if-eqz v1, :cond_4

    .line 94
    .line 95
    goto :goto_2

    .line 96
    :goto_1
    iget-boolean v1, v2, Lcom/facebook/aura/activation/repo/AuraActivationRepository$DebugSetWaitlistStatusResult;->success:Z

    .line 97
    .line 98
    if-eqz v1, :cond_3

    .line 99
    .line 100
    sget-object v1, Lcom/facebook/aura/vds/toast/AuraToast;->Companion:Lcom/facebook/aura/vds/toast/AuraToast$Companion;

    .line 101
    .line 102
    iget-object v2, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$parentView:Landroid/view/View;

    .line 103
    .line 104
    iget-object v3, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$successToastTitle:Ljava/lang/String;

    .line 105
    .line 106
    sget-object v5, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->SHORT:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 107
    .line 108
    const/4 v4, 0x0

    .line 109
    sget-object v7, Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;->INSTANCE:Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;

    .line 110
    .line 111
    const/4 v9, 0x0

    .line 112
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;->DEFAULT:Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 113
    .line 114
    sget-object p0, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->MEDIUM:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 115
    .line 116
    move-object v6, v4

    .line 117
    move-object v8, v4

    .line 118
    move-object v10, v4

    .line 119
    move-object v12, v4

    .line 120
    move-object v13, v4

    .line 121
    move v14, v9

    .line 122
    move v15, v9

    .line 123
    move-object/from16 v16, v4

    .line 124
    .line 125
    move-object/from16 v17, v4

    .line 126
    .line 127
    move-object/from16 v18, v4

    .line 128
    .line 129
    move-object/from16 p1, v4

    .line 130
    .line 131
    invoke-virtual/range {v1 .. v20}, Lcom/facebook/aura/vds/toast/AuraToast$Companion;->make-KDArT4I(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/toast/AuraToastOption;Landroid/view/View$OnClickListener;ZLjava/lang/Boolean;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Ljava/lang/Integer;Landroid/view/View;ZZLkotlin/jvm/functions/Function0;Ljava/lang/Float;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;)Lcom/facebook/aura/vds/toast/AuraToast;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    if-eqz v1, :cond_4

    .line 136
    .line 137
    :goto_2
    invoke-virtual {v1}, Lcom/facebook/aura/vds/toast/AuraToast;->show()V

    .line 138
    .line 139
    .line 140
    goto :goto_3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 141
    :catch_0
    iget-object v1, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 142
    .line 143
    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    sget-object v1, Lcom/facebook/aura/vds/toast/AuraToast;->Companion:Lcom/facebook/aura/vds/toast/AuraToast$Companion;

    .line 147
    .line 148
    iget-object v2, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$parentView:Landroid/view/View;

    .line 149
    .line 150
    iget-object v3, v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1$1$2$1$1;->$failedToastTitle:Ljava/lang/String;

    .line 151
    .line 152
    sget-object v5, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->LONG:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 153
    .line 154
    const/4 v4, 0x0

    .line 155
    sget-object v7, Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;->INSTANCE:Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;

    .line 156
    .line 157
    const/4 v9, 0x0

    .line 158
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;->DEFAULT:Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 159
    .line 160
    sget-object p0, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->MEDIUM:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 161
    .line 162
    move-object v6, v4

    .line 163
    move-object v8, v4

    .line 164
    move-object v10, v4

    .line 165
    move-object v12, v4

    .line 166
    move-object v13, v4

    .line 167
    move v14, v9

    .line 168
    move v15, v9

    .line 169
    move-object/from16 v16, v4

    .line 170
    .line 171
    move-object/from16 v17, v4

    .line 172
    .line 173
    move-object/from16 v18, v4

    .line 174
    .line 175
    move-object/from16 p1, v4

    .line 176
    .line 177
    invoke-virtual/range {v1 .. v20}, Lcom/facebook/aura/vds/toast/AuraToast$Companion;->make-KDArT4I(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/toast/AuraToastOption;Landroid/view/View$OnClickListener;ZLjava/lang/Boolean;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Ljava/lang/Integer;Landroid/view/View;ZZLkotlin/jvm/functions/Function0;Ljava/lang/Float;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;)Lcom/facebook/aura/vds/toast/AuraToast;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    if-eqz v0, :cond_4

    .line 182
    .line 183
    invoke-virtual {v0}, Lcom/facebook/aura/vds/toast/AuraToast;->show()V

    .line 184
    .line 185
    .line 186
    :cond_4
    :goto_3
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 187
    .line 188
    return-object v5
.end method
