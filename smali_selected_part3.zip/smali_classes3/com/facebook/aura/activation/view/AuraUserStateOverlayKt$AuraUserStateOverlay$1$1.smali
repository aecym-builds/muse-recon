.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/34Y;",
        "LX/2RF;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offsetX$delegate:LX/2ss;

.field public final synthetic $offsetY$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;LX/2ss;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;->$offsetX$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;->$offsetY$delegate:LX/2ss;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/34Y;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;->invoke-Bjo55l4(LX/34Y;)J

    .line 3
    .line 4
    .line 5
    move-result-wide p0

    .line 6
    new-instance v0, LX/2RF;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, LX/2RF;-><init>(J)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke-Bjo55l4(LX/34Y;)J
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;->$offsetX$delegate:LX/2ss;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-static {v0}, LX/0sc;->A01(F)I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;->$offsetY$delegate:LX/2ss;

    .line 11
    .line 12
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {v0}, LX/0sc;->A01(F)I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    int-to-long v0, v1

    .line 21
    invoke-static {v0, v1, p0}, LX/005;->A0N(JI)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    return-wide v0
.end method
