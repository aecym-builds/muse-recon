.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic $offsetX$delegate:LX/2ss;

.field public final synthetic $offsetY$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;LX/2ss;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;->$offsetX$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;->$offsetY$delegate:LX/2ss;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final invoke(LX/32h;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/32h;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;->$offsetX$delegate:LX/2ss;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;->$offsetY$delegate:LX/2ss;

    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;

    .line 5
    .line 6
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1$1;-><init>(LX/2ss;LX/2ss;)V

    .line 7
    .line 8
    .line 9
    const/16 v0, 0x10

    .line 10
    .line 11
    new-instance v4, LX/8m4;

    .line 12
    .line 13
    invoke-direct {v4, v0}, LX/8m4;-><init>(I)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    new-instance v2, LX/8m5;

    .line 18
    .line 19
    invoke-direct {v2, v0}, LX/8m5;-><init>(I)V

    .line 20
    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    new-instance v3, LX/8m5;

    .line 24
    .line 25
    invoke-direct {v3, v0}, LX/8m5;-><init>(I)V

    .line 26
    .line 27
    .line 28
    move-object v0, p1

    .line 29
    move-object v1, p2

    .line 30
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/gestures/DragGestureDetectorKt;->A0C(LX/32h;LX/2M4;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDN;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 35
    .line 36
    if-eq v1, v0, :cond_0

    .line 37
    .line 38
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 39
    .line 40
    :cond_0
    return-object v1
.end method
