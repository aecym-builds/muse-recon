.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2gu;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $alpha$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $density:LX/34Y;

.field public final synthetic $offsetY$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/34Y;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/34Y;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$density:LX/34Y;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$alpha$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2gu;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->invoke(LX/2gu;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2gu;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$density:LX/34Y;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$offsetY$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-interface {v1, v0}, LX/34Y;->AhZ(F)F

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-interface {p1, v0}, LX/2gu;->Afa(F)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistHeader$2$1;->$alpha$delegate:Landroidx/compose/runtime/MutableState;

    .line 24
    .line 25
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-interface {p1, v0}, LX/2gu;->AdD(F)V

    .line 34
    .line 35
    .line 36
    return-void
.end method
