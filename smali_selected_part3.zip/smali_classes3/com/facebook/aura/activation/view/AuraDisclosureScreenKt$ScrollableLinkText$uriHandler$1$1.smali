.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/18m;


# instance fields
.field public final synthetic $currentOnLinkClick$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $linkUriHandler:LX/18m;


# direct methods
.method public constructor <init>(LX/18m;LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/18m;",
            "LX/16A<",
            "+",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;->$linkUriHandler:LX/18m;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;->$currentOnLinkClick$delegate:LX/16A;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public openUri(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;->$currentOnLinkClick$delegate:LX/16A;

    .line 5
    .line 6
    invoke-static {v0}, LX/16A;->A07(LX/16A;)LX/JDM;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {v0, p1}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$uriHandler$1$1;->$linkUriHandler:LX/18m;

    .line 14
    .line 15
    invoke-interface {v0, p1}, LX/18m;->openUri(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
