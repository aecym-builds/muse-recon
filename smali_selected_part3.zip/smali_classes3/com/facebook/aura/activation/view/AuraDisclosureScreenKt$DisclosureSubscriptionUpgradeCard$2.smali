.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $serverCopy:Lcom/facebook/aura/activation/data/HatchUpsellCell;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/data/HatchUpsellCell;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;->$serverCopy:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 7

    .line 268435456
    and-int/lit8 v1, p3, 0x11

    .line 268435457
    .line 268435458
    const/16 v0, 0x10

    .line 268435459
    .line 268435460
    const/4 v2, 0x0

    .line 268435461
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object p1, p2

    .line 268435466
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435467
    .line 268435468
    .line 268435469
    move-result v0

    .line 268435470
    if-eqz v0, :cond_2

    .line 268435471
    .line 268435472
    const v0, 0x7f0800d8

    .line 268435473
    .line 268435474
    .line 268435475
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 268435476
    .line 268435477
    .line 268435478
    move-result-object v3

    .line 268435479
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;->$serverCopy:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 268435480
    .line 268435481
    if-eqz v0, :cond_1

    .line 268435482
    .line 268435483
    iget-object v4, v0, Lcom/facebook/aura/activation/data/HatchUpsellCell;->title:Ljava/lang/String;

    .line 268435484
    .line 268435485
    if-eqz v4, :cond_1

    .line 268435486
    .line 268435487
    const v0, 0x360ac247

    .line 268435488
    .line 268435489
    .line 268435490
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435491
    .line 268435492
    .line 268435493
    :goto_0
    invoke-static {p2}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 268435494
    .line 268435495
    .line 268435496
    move-result-object v1

    .line 268435497
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureSubscriptionUpgradeCard$2;->$serverCopy:Lcom/facebook/aura/activation/data/HatchUpsellCell;

    .line 268435498
    .line 268435499
    if-eqz v0, :cond_0

    .line 268435500
    .line 268435501
    iget-object v5, v0, Lcom/facebook/aura/activation/data/HatchUpsellCell;->subtitle:Ljava/lang/String;

    .line 268435502
    .line 268435503
    if-eqz v5, :cond_0

    .line 268435504
    .line 268435505
    const v0, 0x360ad450

    .line 268435506
    .line 268435507
    .line 268435508
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435509
    .line 268435510
    .line 268435511
    :goto_1
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435512
    .line 268435513
    .line 268435514
    const/4 v6, 0x0

    .line 268435515
    const/4 p0, 0x1

    .line 268435516
    const/16 p2, 0x6000

    .line 268435517
    .line 268435518
    const/16 p3, 0x8

    .line 268435519
    .line 268435520
    invoke-static/range {v3 .. v10}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureValuePropRow(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 268435521
    .line 268435522
    .line 268435523
    return-void

    .line 268435524
    :cond_0
    const v0, 0x360ad928    # 2.0690004E-6f

    .line 268435525
    .line 268435526
    .line 268435527
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435528
    .line 268435529
    .line 268435530
    const v0, 0x7f1202d8

    .line 268435531
    .line 268435532
    .line 268435533
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435534
    .line 268435535
    .line 268435536
    move-result-object v5

    .line 268435537
    goto :goto_1

    .line 268435538
    :cond_1
    const v0, 0x360ac6c2

    .line 268435539
    .line 268435540
    .line 268435541
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435542
    .line 268435543
    .line 268435544
    const v0, 0x7f1202d9

    .line 268435545
    .line 268435546
    .line 268435547
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435548
    .line 268435549
    .line 268435550
    move-result-object v4

    .line 268435551
    goto :goto_0

    .line 268435552
    :cond_2
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435553
    .line 268435554
    .line 268435555
    return-void
.end method
