.class public abstract Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CtaPunchScale:F = 1.045f

.field public static final CtaSettleDelayMs:J = 0xb4L

.field public static final DenseBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

.field public static final DenseParticleCount:I = 0xdc

.field public static final EarlyShare:F = 0.78f

.field public static final FadeStart:F = 0.78f

.field public static final ForegroundScale:F = 1.16f

.field public static final ForegroundShare:F = 0.22f

.field public static final ForegroundVelocityBoost:F = 1.1f

.field public static final LaunchColumns:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public static final LeadInMs:F = 80.0f

.field public static final MillisPerSecond:F = 1000.0f

.field public static final OffscreenPaddingDp:F = 48.0f

.field public static final Palette:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/JOw;",
            ">;"
        }
    .end annotation
.end field

.field public static final RadiansToDegrees:F = 57.29578f

.field public static final Seed:J = 0x4d555345L

.field public static final SquashFloor:F = 0.12f

.field public static final StandardBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

.field public static final StandardParticleCount:I = 0x5c

.field public static final SuccessFadeHorizontalInsetDp:F = 8.0f

.field public static final SuccessFadeOpacity:F = 0.34f

.field public static final SuccessFadeVerticalInsetDp:F = 120.0f

.field public static final TargetRampSeconds:F = 0.82f

.field public static final TargetReach:F = 0.46f


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const-wide v0, 0xffe0349bL

    .line 1
    .line 2
    .line 3
    .line 4
    .line 5
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    const-wide v0, 0xff2fd3e0L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    const-wide v0, 0xffffd23fL    # 2.121990004E-314

    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    const-wide v0, 0xffff8a2bL

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    const-wide v0, 0xff9b5de5L

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    const-wide v0, 0xffe0342fL

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    const-wide v0, 0xff39c95cL

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 60
    .line 61
    .line 62
    move-result-object v8

    .line 63
    const-wide v0, 0xff246bfdL

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 69
    .line 70
    .line 71
    move-result-object v9

    .line 72
    filled-new-array/range {v2 .. v9}, [LX/JOw;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    sput-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->Palette:Ljava/util/List;

    .line 81
    .line 82
    const v0, 0x3d8f5c29    # 0.07f

    .line 83
    .line 84
    .line 85
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    const v0, 0x3e3851ec    # 0.18f

    .line 90
    .line 91
    .line 92
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    const v0, 0x3eb851ec    # 0.36f

    .line 97
    .line 98
    .line 99
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    const v0, 0x3f07ae14    # 0.53f

    .line 104
    .line 105
    .line 106
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    const v0, 0x3f3851ec    # 0.72f

    .line 111
    .line 112
    .line 113
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 114
    .line 115
    .line 116
    move-result-object v5

    .line 117
    const v0, 0x3f6147ae    # 0.88f

    .line 118
    .line 119
    .line 120
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    filled-new-array/range {v1 .. v6}, [Ljava/lang/Float;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    sput-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->LaunchColumns:Ljava/util/List;

    .line 133
    .line 134
    const/16 v0, 0x5c

    .line 135
    .line 136
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->createConfettiField(I)Ljava/util/List;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    new-instance v0, Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 141
    .line 142
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/ConfettiBurst;-><init>(Ljava/util/List;)V

    .line 143
    .line 144
    .line 145
    sput-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->StandardBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 146
    .line 147
    const/16 v0, 0xdc

    .line 148
    .line 149
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->createConfettiField(I)Ljava/util/List;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    new-instance v0, Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 154
    .line 155
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/ConfettiBurst;-><init>(Ljava/util/List;)V

    .line 156
    .line 157
    .line 158
    sput-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->DenseBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 159
    .line 160
    return-void
.end method

.method public static final synthetic access$auraWaitlistConfetti$lambda$1(Landroidx/compose/runtime/MutableState;)LX/2sT;
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/2sT;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$auraWaitlistConfetti$lambda$2(Landroidx/compose/runtime/MutableState;LX/2sT;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$drawConfettiLayer(LX/2la;Lcom/facebook/aura/activation/view/ConfettiBurst;Lcom/facebook/aura/activation/view/ConfettiDepth;FLX/36Z;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->drawConfettiLayer(LX/2la;Lcom/facebook/aura/activation/view/ConfettiBurst;Lcom/facebook/aura/activation/view/ConfettiDepth;FLX/36Z;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$localSuccessFrame(LX/2sT;LX/2sT;)LX/36Z;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->localSuccessFrame(LX/2sT;LX/2sT;)LX/36Z;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rememberAuraWaitlistCelebrationState$lambda$3(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$rememberAuraWaitlistCelebrationState$lambda$4(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final auraWaitlistConfetti(LX/3C1;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/3C1;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;",
            "LX/2d4;",
            "I)",
            "LX/3C1;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1, p2}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 8
    .line 9
    if-ne v4, v3, :cond_0

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {p3, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    :cond_0
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 17
    .line 18
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-ne v0, v3, :cond_1

    .line 23
    .line 24
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;

    .line 25
    .line 26
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_1
    check-cast v0, LX/JDM;

    .line 33
    .line 34
    invoke-static {p0, v0}, LX/604;->A07(LX/3C1;LX/JDM;)LX/3C1;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    and-int/lit8 v0, p4, 0x70

    .line 39
    .line 40
    xor-int/lit8 v0, v0, 0x30

    .line 41
    .line 42
    const/4 p0, 0x0

    .line 43
    const/16 v1, 0x20

    .line 44
    .line 45
    if-le v0, v1, :cond_2

    .line 46
    .line 47
    invoke-interface {p3, p1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_3

    .line 52
    .line 53
    :cond_2
    and-int/lit8 v0, p4, 0x30

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    if-ne v0, v1, :cond_4

    .line 57
    .line 58
    :cond_3
    const/4 v2, 0x1

    .line 59
    :cond_4
    and-int/lit16 v0, p4, 0x380

    .line 60
    .line 61
    xor-int/lit16 v0, v0, 0x180

    .line 62
    .line 63
    const/16 v1, 0x100

    .line 64
    .line 65
    if-le v0, v1, :cond_5

    .line 66
    .line 67
    invoke-interface {p3, p2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-nez v0, :cond_6

    .line 72
    .line 73
    :cond_5
    and-int/lit16 v0, p4, 0x180

    .line 74
    .line 75
    if-ne v0, v1, :cond_7

    .line 76
    .line 77
    :cond_6
    const/4 p0, 0x1

    .line 78
    :cond_7
    or-int/2addr v2, p0

    .line 79
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-nez v2, :cond_8

    .line 84
    .line 85
    if-ne v0, v3, :cond_9

    .line 86
    .line 87
    :cond_8
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;

    .line 88
    .line 89
    invoke-direct {v0, p1, p2, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 90
    .line 91
    .line 92
    invoke-interface {p3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :cond_9
    check-cast v0, LX/JDM;

    .line 96
    .line 97
    invoke-static {v5, v0}, LX/2pJ;->A03(LX/3C1;LX/JDM;)LX/3C1;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    return-object v0
.end method

.method public static final auraWaitlistConfetti$lambda$1(Landroidx/compose/runtime/MutableState;)LX/2sT;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;)",
            "LX/2sT;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/2sT;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final auraWaitlistConfetti$lambda$2(Landroidx/compose/runtime/MutableState;LX/2sT;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;",
            "LX/2sT;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final confettiKind(I)Lcom/facebook/aura/activation/view/ConfettiKind;
    .locals 1

    .line 0
    rem-int/lit8 p0, p0, 0x14

    .line 1
    .line 2
    const/16 v0, 0xc

    .line 3
    .line 4
    if-ltz p0, :cond_2

    .line 5
    .line 6
    if-ge p0, v0, :cond_0

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiKind;->RECTANGLE:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_0
    const/16 v0, 0x10

    .line 12
    .line 13
    if-ge p0, v0, :cond_1

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiKind;->SQUARE:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_1
    const/16 v0, 0x12

    .line 19
    .line 20
    if-ge p0, v0, :cond_2

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiKind;->CIRCLE:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 23
    .line 24
    return-object v0

    .line 25
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiKind;->RIBBON:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 26
    .line 27
    return-object v0
.end method

.method public static final createConfettiField(I)Ljava/util/List;
    .locals 36
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/view/ConfettiParticle;",
            ">;"
        }
    .end annotation

    .line 0
    const-wide/32 v1, 0x4d555345

    .line 1
    .line 2
    .line 3
    new-instance v0, Lcom/facebook/aura/activation/view/SeededRandom;

    .line 4
    .line 5
    invoke-direct {v0, v1, v2}, Lcom/facebook/aura/activation/view/SeededRandom;-><init>(J)V

    .line 6
    .line 7
    .line 8
    move/from16 v8, p0

    .line 9
    .line 10
    int-to-float v2, v8

    .line 11
    const v1, 0x3f47ae14    # 0.78f

    .line 12
    .line 13
    .line 14
    mul-float/2addr v2, v1

    .line 15
    float-to-int v7, v2

    .line 16
    invoke-static {v8}, LX/001;->A12(I)Ljava/util/ArrayList;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    const/4 v1, 0x0

    .line 21
    :goto_0
    if-ge v1, v8, :cond_e

    .line 22
    .line 23
    invoke-static {v1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->confettiKind(I)Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 24
    .line 25
    .line 26
    move-result-object v13

    .line 27
    rem-int/lit8 v2, v1, 0x5

    .line 28
    .line 29
    const/4 v12, 0x1

    .line 30
    const/4 v5, 0x0

    .line 31
    invoke-static {v2}, LX/003;->A1C(I)Z

    .line 32
    .line 33
    .line 34
    move-result v9

    .line 35
    rem-int/lit8 v2, v1, 0x6

    .line 36
    .line 37
    invoke-static {v2, v12}, LX/003;->A1I(II)Z

    .line 38
    .line 39
    .line 40
    move-result v11

    .line 41
    invoke-virtual {v0}, Lcom/facebook/aura/activation/view/SeededRandom;->unit()F

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    const v4, 0x3e6147ae    # 0.22f

    .line 46
    .line 47
    .line 48
    cmpg-float v2, v2, v4

    .line 49
    .line 50
    const/4 v10, 0x0

    .line 51
    if-gez v2, :cond_0

    .line 52
    .line 53
    const/4 v10, 0x1

    .line 54
    :cond_0
    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-eq v3, v5, :cond_c

    .line 59
    .line 60
    if-eq v3, v12, :cond_b

    .line 61
    .line 62
    const/4 v2, 0x2

    .line 63
    if-eq v3, v2, :cond_b

    .line 64
    .line 65
    const/4 v2, 0x3

    .line 66
    if-ne v3, v2, :cond_d

    .line 67
    .line 68
    const/high16 v3, 0x40800000    # 4.0f

    .line 69
    .line 70
    const/high16 v2, 0x40c00000    # 6.0f

    .line 71
    .line 72
    invoke-static {v0, v2, v3}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 73
    .line 74
    .line 75
    move-result v23

    .line 76
    const/high16 v3, 0x41600000    # 14.0f

    .line 77
    .line 78
    const/high16 v2, 0x41a00000    # 20.0f

    .line 79
    .line 80
    :goto_1
    invoke-static {v0, v2, v3}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 81
    .line 82
    .line 83
    move-result v24

    .line 84
    :goto_2
    const/4 v2, 0x0

    .line 85
    if-lt v1, v7, :cond_1

    .line 86
    .line 87
    const v2, 0x3e75c28f    # 0.24f

    .line 88
    .line 89
    .line 90
    const v4, 0x3edc28f6    # 0.43f

    .line 91
    .line 92
    .line 93
    :cond_1
    invoke-static {v0, v4, v2}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 94
    .line 95
    .line 96
    move-result v18

    .line 97
    sget-object v4, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->LaunchColumns:Ljava/util/List;

    .line 98
    .line 99
    mul-int/lit8 v2, v1, 0x5

    .line 100
    .line 101
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    rem-int v3, v2, v3

    .line 106
    .line 107
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    invoke-static {v3}, LX/001;->A04(Ljava/lang/Object;)F

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    const v4, -0x4247ae14    # -0.09f

    .line 116
    .line 117
    .line 118
    const v3, 0x3db851ec    # 0.09f

    .line 119
    .line 120
    .line 121
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 122
    .line 123
    .line 124
    move-result v3

    .line 125
    add-float/2addr v5, v3

    .line 126
    const v4, 0x3cf5c28f    # 0.03f

    .line 127
    .line 128
    .line 129
    const v3, 0x3f7851ec    # 0.97f

    .line 130
    .line 131
    .line 132
    invoke-static {v5, v4, v3}, LX/34j;->A04(FFF)F

    .line 133
    .line 134
    .line 135
    move-result v16

    .line 136
    const/high16 v4, -0x3d880000    # -62.0f

    .line 137
    .line 138
    const/high16 v3, -0x3ea00000    # -14.0f

    .line 139
    .line 140
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 141
    .line 142
    .line 143
    move-result v17

    .line 144
    const/high16 v4, -0x3d2e0000    # -105.0f

    .line 145
    .line 146
    const/high16 v3, 0x42d20000    # 105.0f

    .line 147
    .line 148
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 149
    .line 150
    .line 151
    move-result v19

    .line 152
    const/high16 v3, 0x3f800000    # 1.0f

    .line 153
    .line 154
    if-eqz v10, :cond_2

    .line 155
    .line 156
    const v3, 0x3f8ccccd    # 1.1f

    .line 157
    .line 158
    .line 159
    :cond_2
    mul-float v19, v19, v3

    .line 160
    .line 161
    if-eqz v9, :cond_8

    .line 162
    .line 163
    const v4, 0x442c8000    # 690.0f

    .line 164
    .line 165
    .line 166
    const v3, 0x44548000    # 850.0f

    .line 167
    .line 168
    .line 169
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 170
    .line 171
    .line 172
    move-result v20

    .line 173
    if-eqz v11, :cond_a

    .line 174
    .line 175
    :goto_3
    const/high16 v4, 0x42340000    # 45.0f

    .line 176
    .line 177
    const/high16 v3, 0x42aa0000    # 85.0f

    .line 178
    .line 179
    :goto_4
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 180
    .line 181
    .line 182
    move-result v21

    .line 183
    const v4, 0x3e75c28f    # 0.24f

    .line 184
    .line 185
    .line 186
    const v3, 0x3f1eb852    # 0.62f

    .line 187
    .line 188
    .line 189
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 190
    .line 191
    .line 192
    move-result v22

    .line 193
    const v4, -0x3fb6f025

    .line 194
    .line 195
    .line 196
    const v3, 0x40490fdb    # (float)Math.PI

    .line 197
    .line 198
    .line 199
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 200
    .line 201
    .line 202
    move-result v25

    .line 203
    const v4, 0x404ccccd    # 3.2f

    .line 204
    .line 205
    .line 206
    const v3, 0x411ccccd    # 9.8f

    .line 207
    .line 208
    .line 209
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 210
    .line 211
    .line 212
    move-result v26

    .line 213
    rem-int/lit8 v5, v1, 0x2

    .line 214
    .line 215
    const/high16 v3, 0x3f800000    # 1.0f

    .line 216
    .line 217
    if-nez v5, :cond_3

    .line 218
    .line 219
    const/high16 v3, -0x40800000    # -1.0f

    .line 220
    .line 221
    :cond_3
    mul-float v26, v26, v3

    .line 222
    .line 223
    const/16 v31, 0x0

    .line 224
    .line 225
    const v9, 0x40c90fdb

    .line 226
    .line 227
    .line 228
    invoke-virtual {v0}, Lcom/facebook/aura/activation/view/SeededRandom;->unit()F

    .line 229
    .line 230
    .line 231
    move-result v3

    .line 232
    sub-float v9, v9, v31

    .line 233
    .line 234
    mul-float/2addr v3, v9

    .line 235
    add-float v27, v31, v3

    .line 236
    .line 237
    const/high16 v4, 0x40900000    # 4.5f

    .line 238
    .line 239
    const/high16 v3, 0x41280000    # 10.5f

    .line 240
    .line 241
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 242
    .line 243
    .line 244
    move-result v28

    .line 245
    rem-int/lit8 v3, v1, 0x3

    .line 246
    .line 247
    if-nez v3, :cond_7

    .line 248
    .line 249
    const/high16 v4, 0x40e00000    # 7.0f

    .line 250
    .line 251
    const/high16 v3, 0x41900000    # 18.0f

    .line 252
    .line 253
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 254
    .line 255
    .line 256
    move-result v29

    .line 257
    :goto_5
    const v4, 0x4019999a    # 2.4f

    .line 258
    .line 259
    .line 260
    const v3, 0x40a66666    # 5.2f

    .line 261
    .line 262
    .line 263
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 264
    .line 265
    .line 266
    move-result v30

    .line 267
    invoke-virtual {v0}, Lcom/facebook/aura/activation/view/SeededRandom;->unit()F

    .line 268
    .line 269
    .line 270
    move-result v3

    .line 271
    mul-float/2addr v3, v9

    .line 272
    add-float v31, v31, v3

    .line 273
    .line 274
    const v4, 0x4029999a    # 2.65f

    .line 275
    .line 276
    .line 277
    const v3, 0x4069999a    # 3.65f

    .line 278
    .line 279
    .line 280
    if-eqz v11, :cond_4

    .line 281
    .line 282
    const v4, 0x4069999a    # 3.65f

    .line 283
    .line 284
    .line 285
    const v3, 0x40866666    # 4.2f

    .line 286
    .line 287
    .line 288
    :cond_4
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 289
    .line 290
    .line 291
    move-result v32

    .line 292
    const/high16 v4, -0x3e400000    # -24.0f

    .line 293
    .line 294
    const/high16 v3, 0x41e00000    # 28.0f

    .line 295
    .line 296
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 297
    .line 298
    .line 299
    move-result v35

    .line 300
    const v4, 0x3dcccccd    # 0.1f

    .line 301
    .line 302
    .line 303
    const v3, 0x3e75c28f    # 0.24f

    .line 304
    .line 305
    .line 306
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 307
    .line 308
    .line 309
    move-result p0

    .line 310
    if-eqz v10, :cond_6

    .line 311
    .line 312
    sget-object v12, Lcom/facebook/aura/activation/view/ConfettiDepth;->FOREGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 313
    .line 314
    :goto_6
    sget-object v4, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->Palette:Ljava/util/List;

    .line 315
    .line 316
    div-int/lit8 v3, v1, 0x9

    .line 317
    .line 318
    add-int/2addr v2, v3

    .line 319
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 320
    .line 321
    .line 322
    move-result v3

    .line 323
    rem-int/2addr v2, v3

    .line 324
    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    check-cast v2, LX/JOw;

    .line 329
    .line 330
    iget-wide v14, v2, LX/JOw;->A00:J

    .line 331
    .line 332
    rem-int/lit8 v2, v1, 0x4

    .line 333
    .line 334
    invoke-static {v2}, LX/003;->A1C(I)Z

    .line 335
    .line 336
    .line 337
    move-result v33

    .line 338
    const/high16 v34, 0x3f800000    # 1.0f

    .line 339
    .line 340
    if-nez v5, :cond_5

    .line 341
    .line 342
    const/high16 v34, -0x40800000    # -1.0f

    .line 343
    .line 344
    :cond_5
    new-instance v11, Lcom/facebook/aura/activation/view/ConfettiParticle;

    .line 345
    .line 346
    invoke-direct/range {v11 .. v36}, Lcom/facebook/aura/activation/view/ConfettiParticle;-><init>(Lcom/facebook/aura/activation/view/ConfettiDepth;Lcom/facebook/aura/activation/view/ConfettiKind;JFFFFFFFFFFFFFFFFFZFFF)V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v6, v11}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 350
    .line 351
    .line 352
    add-int/lit8 v1, v1, 0x1

    .line 353
    .line 354
    goto/16 :goto_0

    .line 355
    .line 356
    :cond_6
    sget-object v12, Lcom/facebook/aura/activation/view/ConfettiDepth;->BACKGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 357
    .line 358
    goto :goto_6

    .line 359
    :cond_7
    const/16 v29, 0x0

    .line 360
    .line 361
    goto :goto_5

    .line 362
    :cond_8
    if-eqz v11, :cond_9

    .line 363
    .line 364
    const/high16 v4, 0x431b0000    # 155.0f

    .line 365
    .line 366
    const/high16 v3, 0x437a0000    # 250.0f

    .line 367
    .line 368
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 369
    .line 370
    .line 371
    move-result v20

    .line 372
    goto/16 :goto_3

    .line 373
    .line 374
    :cond_9
    const/high16 v4, 0x43960000    # 300.0f

    .line 375
    .line 376
    const/high16 v3, 0x43ff0000    # 510.0f

    .line 377
    .line 378
    invoke-static {v0, v3, v4}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 379
    .line 380
    .line 381
    move-result v20

    .line 382
    :cond_a
    const/high16 v4, 0x42be0000    # 95.0f

    .line 383
    .line 384
    const/high16 v3, 0x432f0000    # 175.0f

    .line 385
    .line 386
    goto/16 :goto_4

    .line 387
    .line 388
    :cond_b
    const/high16 v3, 0x40a00000    # 5.0f

    .line 389
    .line 390
    const/high16 v2, 0x41100000    # 9.0f

    .line 391
    .line 392
    invoke-static {v0, v2, v3}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 393
    .line 394
    .line 395
    move-result v24

    .line 396
    move/from16 v23, v24

    .line 397
    .line 398
    goto/16 :goto_2

    .line 399
    .line 400
    :cond_c
    const/high16 v3, 0x40800000    # 4.0f

    .line 401
    .line 402
    const/high16 v2, 0x40e00000    # 7.0f

    .line 403
    .line 404
    invoke-static {v0, v2, v3}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 405
    .line 406
    .line 407
    move-result v23

    .line 408
    const/high16 v3, 0x41100000    # 9.0f

    .line 409
    .line 410
    const/high16 v2, 0x41700000    # 15.0f

    .line 411
    .line 412
    goto/16 :goto_1

    .line 413
    .line 414
    :cond_d
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    throw v0

    .line 419
    :cond_e
    return-object v6
.end method

.method public static final drawConfettiLayer(LX/2la;Lcom/facebook/aura/activation/view/ConfettiBurst;Lcom/facebook/aura/activation/view/ConfettiDepth;FLX/36Z;)V
    .locals 22

    .line 0
    const/high16 v0, 0x42a00000    # 80.0f

    .line 1
    .line 2
    sub-float p3, p3, v0

    .line 3
    .line 4
    const/high16 v0, 0x447a0000    # 1000.0f

    .line 5
    .line 6
    div-float p3, p3, v0

    .line 7
    .line 8
    const/4 v6, 0x0

    .line 9
    cmpg-float v0, p3, v6

    .line 10
    .line 11
    if-ltz v0, :cond_5

    .line 12
    .line 13
    move-object/from16 v17, p0

    .line 14
    .line 15
    invoke-interface/range {v17 .. v17}, LX/34Y;->AEu()F

    .line 16
    .line 17
    .line 18
    move-result v16

    .line 19
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiDepth;->FOREGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 20
    .line 21
    const/high16 v5, 0x3f800000    # 1.0f

    .line 22
    .line 23
    const/high16 p0, 0x3f800000    # 1.0f

    .line 24
    .line 25
    move-object/from16 v12, p2

    .line 26
    .line 27
    if-ne v12, v0, :cond_0

    .line 28
    .line 29
    const p0, 0x3f947ae1    # 1.16f

    .line 30
    .line 31
    .line 32
    :cond_0
    move-object/from16 v7, p4

    .line 33
    .line 34
    iget v10, v7, LX/36Z;->A01:F

    .line 35
    .line 36
    const/high16 v0, 0x41000000    # 8.0f

    .line 37
    .line 38
    mul-float v0, v0, v16

    .line 39
    .line 40
    sub-float v4, v10, v0

    .line 41
    .line 42
    iget v3, v7, LX/36Z;->A03:F

    .line 43
    .line 44
    const/high16 v2, 0x42f00000    # 120.0f

    .line 45
    .line 46
    mul-float v2, v2, v16

    .line 47
    .line 48
    sub-float/2addr v3, v2

    .line 49
    iget v9, v7, LX/36Z;->A02:F

    .line 50
    .line 51
    add-float v1, v9, v0

    .line 52
    .line 53
    iget v0, v7, LX/36Z;->A00:F

    .line 54
    .line 55
    add-float/2addr v0, v2

    .line 56
    new-instance v8, LX/36Z;

    .line 57
    .line 58
    invoke-direct {v8, v4, v3, v1, v0}, LX/36Z;-><init>(FFFF)V

    .line 59
    .line 60
    .line 61
    move-object/from16 v0, p1

    .line 62
    .line 63
    iget-object v0, v0, Lcom/facebook/aura/activation/view/ConfettiBurst;->particles:Ljava/util/List;

    .line 64
    .line 65
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object v15

    .line 69
    :cond_1
    :goto_0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-eqz v0, :cond_5

    .line 74
    .line 75
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    check-cast v4, Lcom/facebook/aura/activation/view/ConfettiParticle;

    .line 80
    .line 81
    iget-object v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->depth:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 82
    .line 83
    if-ne v0, v12, :cond_1

    .line 84
    .line 85
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->delay:F

    .line 86
    .line 87
    sub-float v14, p3, v0

    .line 88
    .line 89
    cmpg-float v0, v14, v6

    .line 90
    .line 91
    if-ltz v0, :cond_1

    .line 92
    .line 93
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->lifetime:F

    .line 94
    .line 95
    cmpl-float v0, v14, v0

    .line 96
    .line 97
    if-gtz v0, :cond_1

    .line 98
    .line 99
    iget v2, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->drag:F

    .line 100
    .line 101
    neg-float v0, v2

    .line 102
    mul-float/2addr v0, v14

    .line 103
    float-to-double v0, v0

    .line 104
    invoke-static {v0, v1}, Ljava/lang/Math;->exp(D)D

    .line 105
    .line 106
    .line 107
    move-result-wide v0

    .line 108
    double-to-float v3, v0

    .line 109
    sub-float v3, v5, v3

    .line 110
    .line 111
    div-float/2addr v3, v2

    .line 112
    iget v2, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->normalizedX:F

    .line 113
    .line 114
    invoke-interface/range {v17 .. v17}, LX/2la;->AKf()J

    .line 115
    .line 116
    .line 117
    move-result-wide v0

    .line 118
    invoke-static {v0, v1}, LX/004;->A03(J)F

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    mul-float/2addr v2, v0

    .line 123
    iget v11, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityX:F

    .line 124
    .line 125
    mul-float v11, v11, v16

    .line 126
    .line 127
    mul-float/2addr v11, v3

    .line 128
    add-float/2addr v11, v2

    .line 129
    iget v1, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayFrequency:F

    .line 130
    .line 131
    mul-float/2addr v1, v14

    .line 132
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayPhase:F

    .line 133
    .line 134
    add-float/2addr v1, v0

    .line 135
    float-to-double v0, v1

    .line 136
    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    .line 137
    .line 138
    .line 139
    move-result-wide v0

    .line 140
    double-to-float v3, v0

    .line 141
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->swayAmplitude:F

    .line 142
    .line 143
    mul-float/2addr v3, v0

    .line 144
    mul-float v3, v3, v16

    .line 145
    .line 146
    add-float/2addr v11, v3

    .line 147
    iget-boolean v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetsSuccess:Z

    .line 148
    .line 149
    if-eqz v0, :cond_2

    .line 150
    .line 151
    invoke-virtual {v7}, LX/36Z;->A06()Z

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    if-nez v0, :cond_2

    .line 156
    .line 157
    invoke-virtual {v7}, LX/36Z;->A01()J

    .line 158
    .line 159
    .line 160
    move-result-wide v0

    .line 161
    invoke-static {v0, v1}, LX/002;->A01(J)F

    .line 162
    .line 163
    .line 164
    move-result v13

    .line 165
    iget v3, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetSide:F

    .line 166
    .line 167
    sub-float v1, v9, v10

    .line 168
    .line 169
    const v0, 0x3eeb851f    # 0.46f

    .line 170
    .line 171
    .line 172
    mul-float/2addr v1, v0

    .line 173
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetOffset:F

    .line 174
    .line 175
    mul-float v0, v0, v16

    .line 176
    .line 177
    add-float/2addr v1, v0

    .line 178
    mul-float/2addr v3, v1

    .line 179
    add-float/2addr v13, v3

    .line 180
    sub-float/2addr v13, v2

    .line 181
    const v0, 0x3f51eb85    # 0.82f

    .line 182
    .line 183
    .line 184
    div-float v0, v14, v0

    .line 185
    .line 186
    invoke-static {v0, v6, v5}, LX/34j;->A04(FFF)F

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    mul-float/2addr v13, v0

    .line 191
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->targetStrength:F

    .line 192
    .line 193
    mul-float/2addr v13, v0

    .line 194
    add-float/2addr v11, v13

    .line 195
    :cond_2
    iget v13, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->startY:F

    .line 196
    .line 197
    mul-float v13, v13, v16

    .line 198
    .line 199
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->velocityY:F

    .line 200
    .line 201
    mul-float v0, v0, v16

    .line 202
    .line 203
    mul-float/2addr v0, v14

    .line 204
    add-float/2addr v13, v0

    .line 205
    const/high16 v1, 0x3f000000    # 0.5f

    .line 206
    .line 207
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->gravity:F

    .line 208
    .line 209
    mul-float/2addr v0, v1

    .line 210
    mul-float v0, v0, v16

    .line 211
    .line 212
    mul-float/2addr v0, v14

    .line 213
    mul-float/2addr v0, v14

    .line 214
    add-float/2addr v13, v0

    .line 215
    invoke-interface/range {v17 .. v17}, LX/2la;->AKf()J

    .line 216
    .line 217
    .line 218
    move-result-wide v2

    .line 219
    const-wide v0, 0xffffffffL

    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    invoke-static {v2, v3, v0, v1}, LX/002;->A02(JJ)F

    .line 225
    .line 226
    .line 227
    move-result v1

    .line 228
    const/high16 v0, 0x42400000    # 48.0f

    .line 229
    .line 230
    mul-float v0, v0, v16

    .line 231
    .line 232
    add-float/2addr v1, v0

    .line 233
    cmpl-float v0, v13, v1

    .line 234
    .line 235
    if-gez v0, :cond_1

    .line 236
    .line 237
    iget v0, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->lifetime:F

    .line 238
    .line 239
    div-float v1, v14, v0

    .line 240
    .line 241
    const v0, 0x3f47ae14    # 0.78f

    .line 242
    .line 243
    .line 244
    sub-float/2addr v1, v0

    .line 245
    const v0, 0x3e6147b0    # 0.22000003f

    .line 246
    .line 247
    .line 248
    div-float/2addr v1, v0

    .line 249
    invoke-static {v1, v6, v5}, LX/34j;->A04(FFF)F

    .line 250
    .line 251
    .line 252
    move-result v2

    .line 253
    invoke-static {v11, v13}, LX/005;->A0H(FF)J

    .line 254
    .line 255
    .line 256
    move-result-wide v0

    .line 257
    sub-float p2, v5, v2

    .line 258
    .line 259
    sget-object v2, Lcom/facebook/aura/activation/view/ConfettiDepth;->FOREGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 260
    .line 261
    if-ne v12, v2, :cond_3

    .line 262
    .line 263
    invoke-virtual {v7}, LX/36Z;->A06()Z

    .line 264
    .line 265
    .line 266
    move-result v2

    .line 267
    if-nez v2, :cond_3

    .line 268
    .line 269
    invoke-virtual {v8, v0, v1}, LX/36Z;->A07(J)Z

    .line 270
    .line 271
    .line 272
    move-result v2

    .line 273
    if-eqz v2, :cond_3

    .line 274
    .line 275
    const v2, 0x3eae147b    # 0.34f

    .line 276
    .line 277
    .line 278
    mul-float p2, p2, v2

    .line 279
    .line 280
    :cond_3
    iget-object v3, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->kind:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 281
    .line 282
    sget-object v2, Lcom/facebook/aura/activation/view/ConfettiKind;->CIRCLE:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 283
    .line 284
    if-ne v3, v2, :cond_4

    .line 285
    .line 286
    const/high16 p1, 0x3f800000    # 1.0f

    .line 287
    .line 288
    :goto_1
    iget v3, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->rotation:F

    .line 289
    .line 290
    iget v2, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->spin:F

    .line 291
    .line 292
    mul-float/2addr v14, v2

    .line 293
    add-float/2addr v3, v14

    .line 294
    const v2, 0x42652ee1

    .line 295
    .line 296
    .line 297
    mul-float/2addr v3, v2

    .line 298
    move-wide/from16 v19, v0

    .line 299
    .line 300
    move/from16 v21, v3

    .line 301
    .line 302
    move-object/from16 v18, v4

    .line 303
    .line 304
    invoke-static/range {v17 .. v24}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->drawParticle-JHbHoSQ(LX/2la;Lcom/facebook/aura/activation/view/ConfettiParticle;JFFFF)V

    .line 305
    .line 306
    .line 307
    goto/16 :goto_0

    .line 308
    .line 309
    :cond_4
    iget v3, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumblePhase:F

    .line 310
    .line 311
    iget v2, v4, Lcom/facebook/aura/activation/view/ConfettiParticle;->tumbleRate:F

    .line 312
    .line 313
    mul-float/2addr v2, v14

    .line 314
    add-float/2addr v3, v2

    .line 315
    float-to-double v2, v3

    .line 316
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 317
    .line 318
    .line 319
    move-result-wide v2

    .line 320
    double-to-float v11, v2

    .line 321
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    .line 322
    .line 323
    .line 324
    move-result v3

    .line 325
    const v2, 0x3df5c28f    # 0.12f

    .line 326
    .line 327
    .line 328
    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    .line 329
    .line 330
    .line 331
    move-result p1

    .line 332
    goto :goto_1

    .line 333
    :cond_5
    return-void
.end method

.method public static final drawParticle-JHbHoSQ(LX/2la;Lcom/facebook/aura/activation/view/ConfettiParticle;JFFFF)V
    .locals 26

    .line 0
    move-object/from16 v14, p1

    .line 1
    .line 2
    iget v4, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->width:F

    .line 3
    .line 4
    move-object/from16 v20, p0

    .line 5
    .line 6
    invoke-interface/range {v20 .. v20}, LX/34Y;->AEu()F

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    mul-float/2addr v4, v0

    .line 11
    iget v10, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->height:F

    .line 12
    .line 13
    invoke-interface/range {v20 .. v20}, LX/34Y;->AEu()F

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    mul-float/2addr v10, v0

    .line 18
    const/16 v19, 0x20

    .line 19
    .line 20
    invoke-static/range {p2 .. p3}, LX/002;->A01(J)F

    .line 21
    .line 22
    .line 23
    move-result v9

    .line 24
    invoke-static/range {p2 .. p3}, LX/004;->A02(J)F

    .line 25
    .line 26
    .line 27
    move-result v8

    .line 28
    invoke-interface/range {v20 .. v20}, LX/2la;->AEy()LX/2lC;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    move-object v0, v5

    .line 33
    check-cast v0, LX/2kf;

    .line 34
    .line 35
    iget-object v3, v0, LX/2kf;->A01:LX/2lA;

    .line 36
    .line 37
    invoke-interface {v3, v9, v8}, LX/2lA;->Ahp(FF)V

    .line 38
    .line 39
    .line 40
    const-wide/16 v1, 0x0

    .line 41
    .line 42
    :try_start_0
    iget-object v0, v0, LX/2kf;->A02:LX/2kc;

    .line 43
    .line 44
    iget-object v0, v0, LX/2kc;->A02:LX/2kt;

    .line 45
    .line 46
    iget-wide v15, v0, LX/2kt;->A00:J

    .line 47
    .line 48
    iget-object v6, v0, LX/2kt;->A01:LX/2kd;

    .line 49
    .line 50
    invoke-interface {v6}, LX/2kd;->AcV()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 51
    .line 52
    .line 53
    :try_start_1
    move/from16 v6, p4

    .line 54
    .line 55
    invoke-interface {v3, v6, v1, v2}, LX/2lA;->AcJ(FJ)V

    .line 56
    .line 57
    .line 58
    move/from16 v13, p5

    .line 59
    .line 60
    mul-float v12, p6, p5

    .line 61
    .line 62
    iget-wide v6, v0, LX/2kt;->A00:J

    .line 63
    .line 64
    iget-object v11, v0, LX/2kt;->A01:LX/2kd;

    .line 65
    .line 66
    invoke-interface {v11}, LX/2kd;->AcV()V

    .line 67
    .line 68
    .line 69
    const-wide v17, 0xffffffffL
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    :try_start_2
    invoke-interface {v3, v12, v13, v1, v2}, LX/2lA;->AcY(FFJ)V

    .line 75
    .line 76
    .line 77
    iget-object v11, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->kind:Lcom/facebook/aura/activation/view/ConfettiKind;

    .line 78
    .line 79
    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    .line 80
    .line 81
    .line 82
    move-result v11

    .line 83
    const/4 v12, 0x0

    .line 84
    move/from16 v24, p7

    .line 85
    .line 86
    if-eq v11, v12, :cond_2

    .line 87
    .line 88
    const/4 v12, 0x1

    .line 89
    if-eq v11, v12, :cond_2

    .line 90
    .line 91
    const/4 v12, 0x2

    .line 92
    if-eq v11, v12, :cond_1

    .line 93
    .line 94
    const/4 v1, 0x3

    .line 95
    if-ne v11, v1, :cond_0

    .line 96
    .line 97
    const/high16 v17, 0x40000000    # 2.0f

    .line 98
    .line 99
    iget-wide v11, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->color:J

    .line 100
    .line 101
    neg-float v13, v4

    .line 102
    div-float v13, v13, v17

    .line 103
    .line 104
    neg-float v2, v10

    .line 105
    div-float v2, v2, v17

    .line 106
    .line 107
    invoke-static {v13, v2}, LX/005;->A0H(FF)J

    .line 108
    .line 109
    .line 110
    move-result-wide p3

    .line 111
    div-float v2, v4, v17

    .line 112
    .line 113
    div-float v10, v10, v17

    .line 114
    .line 115
    invoke-static {v2, v10}, LX/005;->A0H(FF)J

    .line 116
    .line 117
    .line 118
    move-result-wide p5

    .line 119
    const/16 v25, 0x1

    .line 120
    .line 121
    const/16 v21, 0x0

    .line 122
    .line 123
    move-object/from16 v22, v21

    .line 124
    .line 125
    move/from16 v23, v4

    .line 126
    .line 127
    move/from16 p0, v1

    .line 128
    .line 129
    move-wide/from16 p1, v11

    .line 130
    .line 131
    invoke-interface/range {v20 .. v32}, LX/2la;->A9c(LX/2hc;LX/2RU;FFIIJJJ)V

    .line 132
    .line 133
    .line 134
    goto :goto_0

    .line 135
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    throw v1

    .line 140
    :cond_1
    const/high16 v12, 0x40000000    # 2.0f

    .line 141
    .line 142
    iget-wide v10, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->color:J

    .line 143
    .line 144
    div-float/2addr v4, v12

    .line 145
    const/16 v21, 0x0

    .line 146
    .line 147
    sget-object v22, LX/2RH;->A00:LX/2RH;

    .line 148
    .line 149
    const/16 v25, 0x3

    .line 150
    .line 151
    move/from16 v23, v4

    .line 152
    .line 153
    move-wide/from16 p0, v10

    .line 154
    .line 155
    move-wide/from16 p2, v1

    .line 156
    .line 157
    invoke-interface/range {v20 .. v29}, LX/2la;->A9S(LX/2hc;LX/2Qt;FFIJJ)V

    .line 158
    .line 159
    .line 160
    goto :goto_0

    .line 161
    :cond_2
    const/high16 v13, 0x40000000    # 2.0f

    .line 162
    .line 163
    iget-wide v1, v14, Lcom/facebook/aura/activation/view/ConfettiParticle;->color:J

    .line 164
    .line 165
    neg-float v12, v4

    .line 166
    div-float/2addr v12, v13

    .line 167
    neg-float v11, v10

    .line 168
    div-float/2addr v11, v13

    .line 169
    invoke-static {v12, v11}, LX/005;->A0H(FF)J

    .line 170
    .line 171
    .line 172
    move-result-wide p2

    .line 173
    invoke-static {v4, v10}, LX/005;->A0H(FF)J

    .line 174
    .line 175
    .line 176
    move-result-wide p4

    .line 177
    invoke-interface/range {v20 .. v20}, LX/34Y;->AEu()F

    .line 178
    .line 179
    .line 180
    move-result v10

    .line 181
    const/high16 v4, 0x3fc00000    # 1.5f

    .line 182
    .line 183
    mul-float/2addr v10, v4

    .line 184
    invoke-static {v10}, LX/001;->A0F(F)J

    .line 185
    .line 186
    .line 187
    move-result-wide v10

    .line 188
    shl-long p6, v10, v19

    .line 189
    .line 190
    and-long v10, v10, v17

    .line 191
    .line 192
    or-long p6, p6, v10

    .line 193
    .line 194
    const/16 v22, 0x0

    .line 195
    .line 196
    sget-object v23, LX/2RH;->A00:LX/2RH;

    .line 197
    .line 198
    const/16 v25, 0x3

    .line 199
    .line 200
    move-object/from16 v21, v20

    .line 201
    .line 202
    move-wide/from16 p0, v1

    .line 203
    .line 204
    invoke-interface/range {v21 .. v33}, LX/2la;->A9o(LX/2hc;LX/2Qt;FIJJJJ)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 205
    .line 206
    .line 207
    :goto_0
    :try_start_3
    invoke-static {v0, v5, v6, v7}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 208
    .line 209
    .line 210
    :try_start_4
    move-wide v1, v15

    .line 211
    invoke-static {v0, v5, v1, v2}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 212
    .line 213
    .line 214
    neg-float v1, v9

    .line 215
    neg-float v0, v8

    .line 216
    invoke-interface {v3, v1, v0}, LX/2lA;->Ahp(FF)V

    .line 217
    .line 218
    .line 219
    return-void

    .line 220
    :catchall_0
    move-exception v1

    .line 221
    :try_start_5
    invoke-static {v0, v5, v6, v7}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 222
    .line 223
    .line 224
    throw v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 225
    :catchall_1
    move-exception v4

    .line 226
    :try_start_6
    move-wide v1, v15

    .line 227
    invoke-static {v0, v5, v1, v2}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 228
    .line 229
    .line 230
    throw v4
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 231
    :catchall_2
    move-exception v2

    .line 232
    neg-float v1, v9

    .line 233
    neg-float v0, v8

    .line 234
    invoke-interface {v3, v1, v0}, LX/2lA;->Ahp(FF)V

    .line 235
    .line 236
    .line 237
    throw v2
.end method

.method public static final getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p0, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->DenseBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    throw v0

    .line 18
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->StandardBurst:Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 19
    .line 20
    return-object v0
.end method

.method public static final localSuccessFrame(LX/2sT;LX/2sT;)LX/36Z;
    .locals 5

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    iget v0, p1, LX/2sT;->A01:I

    .line 5
    .line 6
    iget v1, p0, LX/2sT;->A01:I

    .line 7
    .line 8
    sub-int/2addr v0, v1

    .line 9
    int-to-float v4, v0

    .line 10
    iget v0, p1, LX/2sT;->A03:I

    .line 11
    .line 12
    iget v3, p0, LX/2sT;->A03:I

    .line 13
    .line 14
    sub-int/2addr v0, v3

    .line 15
    int-to-float v2, v0

    .line 16
    iget v0, p1, LX/2sT;->A02:I

    .line 17
    .line 18
    sub-int/2addr v0, v1

    .line 19
    int-to-float v1, v0

    .line 20
    iget v0, p1, LX/2sT;->A00:I

    .line 21
    .line 22
    sub-int/2addr v0, v3

    .line 23
    int-to-float v0, v0

    .line 24
    new-instance v3, LX/36Z;

    .line 25
    .line 26
    invoke-direct {v3, v4, v2, v1, v0}, LX/36Z;-><init>(FFFF)V

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :cond_0
    sget-object v3, LX/36Z;->A04:LX/36Z;

    .line 31
    .line 32
    return-object v3
.end method

.method public static final rememberAuraWaitlistCelebrationState(IZLcom/facebook/aura/activation/view/AuraConfettiDensity;LX/2d4;II)Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;
    .locals 16

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    const/4 v5, 0x4

    .line 3
    and-int/lit8 v0, p5, 0x4

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    sget-object v4, Lcom/facebook/aura/activation/view/AuraConfettiDensity;->STANDARD:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 8
    .line 9
    :cond_0
    move/from16 v7, p4

    .line 10
    .line 11
    and-int/lit16 v0, v7, 0x380

    .line 12
    .line 13
    xor-int/lit16 v0, v0, 0x180

    .line 14
    .line 15
    const/16 v2, 0x100

    .line 16
    .line 17
    const/4 v9, 0x0

    .line 18
    move-object/from16 v3, p3

    .line 19
    .line 20
    if-le v0, v2, :cond_1

    .line 21
    .line 22
    invoke-static {v3, v4}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_2

    .line 27
    .line 28
    :cond_1
    and-int/lit16 v1, v7, 0x180

    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    if-ne v1, v2, :cond_3

    .line 32
    .line 33
    :cond_2
    const/4 v0, 0x1

    .line 34
    :cond_3
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v13

    .line 38
    if-nez v0, :cond_4

    .line 39
    .line 40
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 41
    .line 42
    if-ne v13, v0, :cond_5

    .line 43
    .line 44
    :cond_4
    new-instance v13, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 45
    .line 46
    invoke-direct {v13, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;-><init>(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)V

    .line 47
    .line 48
    .line 49
    invoke-interface {v3, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    :cond_5
    check-cast v13, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 53
    .line 54
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 55
    .line 56
    const/4 v0, 0x6

    .line 57
    invoke-virtual {v1, v3, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getHaptics(LX/2d4;I)LX/1sR;

    .line 58
    .line 59
    .line 60
    move-result-object v12

    .line 61
    invoke-static {v3}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-interface {v3, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    if-nez v0, :cond_6

    .line 74
    .line 75
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 76
    .line 77
    if-ne v1, v0, :cond_7

    .line 78
    .line 79
    :cond_6
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    const-string v1, "animator_duration_scale"

    .line 84
    .line 85
    const/high16 v0, 0x3f800000    # 1.0f

    .line 86
    .line 87
    invoke-static {v2, v1, v0}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    const/4 v0, 0x0

    .line 92
    cmpg-float v0, v1, v0

    .line 93
    .line 94
    invoke-static {v0}, LX/003;->A1C(I)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    xor-int/lit8 v0, v0, 0x1

    .line 99
    .line 100
    invoke-static {v3, v0}, LX/002;->A0k(LX/2d4;Z)Ljava/lang/Boolean;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    :cond_7
    invoke-static {v1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v14

    .line 108
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v15

    .line 112
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 113
    .line 114
    move/from16 v11, p0

    .line 115
    .line 116
    if-ne v15, v4, :cond_8

    .line 117
    .line 118
    invoke-static {v3, v11}, LX/007;->A0c(LX/2d4;I)Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 119
    .line 120
    .line 121
    move-result-object v15

    .line 122
    :cond_8
    check-cast v15, LX/CR1;

    .line 123
    .line 124
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    move/from16 v10, p1

    .line 129
    .line 130
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    and-int/lit8 v0, p4, 0x70

    .line 135
    .line 136
    xor-int/lit8 v0, v0, 0x30

    .line 137
    .line 138
    const/16 v8, 0x20

    .line 139
    .line 140
    if-le v0, v8, :cond_9

    .line 141
    .line 142
    invoke-interface {v3, v10}, LX/2d4;->A6A(Z)Z

    .line 143
    .line 144
    .line 145
    move-result v0

    .line 146
    if-nez v0, :cond_a

    .line 147
    .line 148
    :cond_9
    and-int/lit8 v0, p4, 0x30

    .line 149
    .line 150
    const/4 v6, 0x0

    .line 151
    if-ne v0, v8, :cond_b

    .line 152
    .line 153
    :cond_a
    const/4 v6, 0x1

    .line 154
    :cond_b
    and-int/lit8 v0, p4, 0xe

    .line 155
    .line 156
    xor-int/lit8 v0, v0, 0x6

    .line 157
    .line 158
    if-le v0, v5, :cond_c

    .line 159
    .line 160
    invoke-interface {v3, v11}, LX/2d4;->A67(I)Z

    .line 161
    .line 162
    .line 163
    move-result v0

    .line 164
    if-nez v0, :cond_d

    .line 165
    .line 166
    :cond_c
    and-int/lit8 v0, p4, 0x6

    .line 167
    .line 168
    if-ne v0, v5, :cond_e

    .line 169
    .line 170
    :cond_d
    const/4 v9, 0x1

    .line 171
    :cond_e
    or-int/2addr v6, v9

    .line 172
    invoke-static {v3, v12, v13, v6}, LX/004;->A1V(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    invoke-static {v3, v14, v0}, LX/001;->A1X(LX/2d4;ZZ)Z

    .line 177
    .line 178
    .line 179
    move-result v0

    .line 180
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v9

    .line 184
    if-nez v0, :cond_f

    .line 185
    .line 186
    if-ne v9, v4, :cond_10

    .line 187
    .line 188
    :cond_f
    const/16 p0, 0x0

    .line 189
    .line 190
    new-instance v9, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;

    .line 191
    .line 192
    invoke-direct/range {v9 .. v16}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1;-><init>(ZILX/1sR;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;ZLX/CR1;LX/2M4;)V

    .line 193
    .line 194
    .line 195
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    :cond_10
    invoke-static {v3, v9, v2, v1}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    return-object v13
.end method

.method public static final rememberAuraWaitlistCelebrationState$lambda$3(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final rememberAuraWaitlistCelebrationState$lambda$4(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
