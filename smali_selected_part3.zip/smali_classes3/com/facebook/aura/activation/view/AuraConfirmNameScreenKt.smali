.class public abstract Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AuraConfirmNameScreen(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p0

    .line 1
    .line 2
    move-object/from16 v4, p1

    .line 3
    .line 4
    move-object/from16 v11, p2

    .line 5
    .line 6
    invoke-static {v5, v4}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v6

    .line 10
    const v0, 0x69a44486

    .line 11
    .line 12
    .line 13
    move-object/from16 v1, p3

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v0, p4

    .line 19
    .line 20
    and-int/lit8 v2, p4, 0x6

    .line 21
    .line 22
    if-nez v2, :cond_6

    .line 23
    .line 24
    invoke-static {v1, v5}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v7

    .line 28
    or-int v7, v7, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v2, p4, 0x30

    .line 31
    .line 32
    if-nez v2, :cond_0

    .line 33
    .line 34
    invoke-static {v1, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    or-int/2addr v7, v2

    .line 39
    :cond_0
    and-int/lit8 v3, p5, 0x4

    .line 40
    .line 41
    if-eqz v3, :cond_5

    .line 42
    .line 43
    or-int/lit16 v7, v7, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    invoke-static {v7}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    invoke-static {v2, v1, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_4

    .line 54
    .line 55
    if-eqz v3, :cond_2

    .line 56
    .line 57
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    invoke-static {v1}, LX/603;->A05(LX/2d4;)J

    .line 60
    .line 61
    .line 62
    move-result-wide v2

    .line 63
    const-class v10, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 64
    .line 65
    invoke-static {v10, v2, v3}, Lcom/facebook/aura/session/LocalUserSessionKt;->activityViewModelKey(Ljava/lang/Class;J)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    invoke-static {v1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    new-instance v8, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$Factory;

    .line 74
    .line 75
    invoke-direct {v8, v2}, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$Factory;-><init>(LX/AHE;)V

    .line 76
    .line 77
    .line 78
    invoke-static {v1}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 79
    .line 80
    .line 81
    move-result-object v3

    .line 82
    if-eqz v3, :cond_7

    .line 83
    .line 84
    invoke-static {v3}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-static {v8, v3, v2, v10, v9}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 89
    .line 90
    .line 91
    move-result-object v8

    .line 92
    check-cast v8, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;

    .line 93
    .line 94
    iget-object v2, v8, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;->uiState:LX/2J3;

    .line 95
    .line 96
    const/4 v15, 0x0

    .line 97
    invoke-static {v1, v2, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 102
    .line 103
    sget-object v12, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 104
    .line 105
    sget v33, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 106
    .line 107
    sget-object v38, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt;->lambda$268752177:LX/JDN;

    .line 108
    .line 109
    new-instance v3, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;

    .line 110
    .line 111
    invoke-direct {v3, v8, v4, v5, v2}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$1;-><init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/16A;)V

    .line 112
    .line 113
    .line 114
    const v2, 0x22261f0b

    .line 115
    .line 116
    .line 117
    invoke-static {v1, v3, v2}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 118
    .line 119
    .line 120
    move-result-object v42

    .line 121
    shr-int/lit8 v2, v7, 0x3

    .line 122
    .line 123
    and-int/lit8 p1, v2, 0x70

    .line 124
    .line 125
    const v2, 0x30000186

    .line 126
    .line 127
    .line 128
    or-int p1, p1, v2

    .line 129
    .line 130
    const/high16 p3, 0x30030000

    .line 131
    .line 132
    const p4, 0x1deffdf8

    .line 133
    .line 134
    .line 135
    const-wide/16 v13, 0x0

    .line 136
    .line 137
    move-object/from16 v16, v15

    .line 138
    .line 139
    move-object/from16 v17, v15

    .line 140
    .line 141
    move-object/from16 v18, v15

    .line 142
    .line 143
    move/from16 v20, v6

    .line 144
    .line 145
    move/from16 v21, v6

    .line 146
    .line 147
    move-object/from16 v22, v15

    .line 148
    .line 149
    move-object/from16 v23, v15

    .line 150
    .line 151
    move-object/from16 v24, v15

    .line 152
    .line 153
    move-object/from16 v25, v15

    .line 154
    .line 155
    move-object/from16 v26, v15

    .line 156
    .line 157
    move-object/from16 v27, v15

    .line 158
    .line 159
    move-wide/from16 v28, v13

    .line 160
    .line 161
    move-wide/from16 v30, v13

    .line 162
    .line 163
    move-object/from16 v32, v15

    .line 164
    .line 165
    move-object/from16 v34, v15

    .line 166
    .line 167
    move-object/from16 v35, v15

    .line 168
    .line 169
    move-object/from16 v36, v15

    .line 170
    .line 171
    move/from16 v37, v6

    .line 172
    .line 173
    move-object/from16 v39, v15

    .line 174
    .line 175
    move-object/from16 v40, v15

    .line 176
    .line 177
    move/from16 v41, v6

    .line 178
    .line 179
    move-object/from16 p0, v1

    .line 180
    .line 181
    move/from16 p2, v6

    .line 182
    .line 183
    move/from16 v19, v6

    .line 184
    .line 185
    invoke-static/range {v10 .. v47}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 186
    .line 187
    .line 188
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 189
    .line 190
    .line 191
    move-result-object v2

    .line 192
    if-eqz v2, :cond_3

    .line 193
    .line 194
    new-instance v1, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$2;

    .line 195
    .line 196
    move-object/from16 p2, v4

    .line 197
    .line 198
    move-object/from16 p3, v11

    .line 199
    .line 200
    move/from16 p4, v0

    .line 201
    .line 202
    move-object/from16 p0, v1

    .line 203
    .line 204
    move-object/from16 p1, v5

    .line 205
    .line 206
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$AuraConfirmNameScreen$2;-><init>(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 207
    .line 208
    .line 209
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 210
    .line 211
    :cond_3
    return-void

    .line 212
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 213
    .line 214
    .line 215
    goto :goto_2

    .line 216
    :cond_5
    and-int/lit16 v2, v0, 0x180

    .line 217
    .line 218
    if-nez v2, :cond_1

    .line 219
    .line 220
    invoke-static {v1, v11}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 221
    .line 222
    .line 223
    move-result v2

    .line 224
    or-int/2addr v7, v2

    .line 225
    goto/16 :goto_1

    .line 226
    .line 227
    :cond_6
    move v7, v0

    .line 228
    goto/16 :goto_0

    .line 229
    .line 230
    :cond_7
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    throw v0
.end method

.method public static final AuraConfirmNameScreen$lambda$0(LX/16A;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final ConfirmNameBottomButtons(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v2, p3

    .line 1
    .line 2
    const v0, 0x192f8e32

    .line 3
    .line 4
    .line 5
    move-object/from16 v7, p4

    .line 6
    .line 7
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v6, p0

    .line 15
    .line 16
    if-nez v0, :cond_a

    .line 17
    .line 18
    invoke-static {v7, v6}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v9

    .line 22
    or-int v9, v9, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move-object/from16 v5, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v7, v5}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v9, v0

    .line 35
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 36
    .line 37
    const/16 v8, 0x100

    .line 38
    .line 39
    move-object/from16 v4, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v7, v4}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v9, v0

    .line 48
    :cond_1
    and-int/lit8 v11, p6, 0x8

    .line 49
    .line 50
    if-eqz v11, :cond_9

    .line 51
    .line 52
    or-int/lit16 v9, v9, 0xc00

    .line 53
    .line 54
    :cond_2
    :goto_1
    and-int/lit16 v1, v9, 0x493

    .line 55
    .line 56
    const/16 v0, 0x492

    .line 57
    .line 58
    const/4 v10, 0x0

    .line 59
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-static {v0, v7, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_8

    .line 68
    .line 69
    if-eqz v11, :cond_3

    .line 70
    .line 71
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 72
    .line 73
    :cond_3
    const/4 v12, 0x0

    .line 74
    invoke-static {v2}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 79
    .line 80
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v11

    .line 84
    invoke-interface {v7, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    invoke-static {v9}, LX/004;->A1S(I)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    or-int/2addr v1, v0

    .line 93
    and-int/lit16 v0, v9, 0x380

    .line 94
    .line 95
    if-ne v0, v8, :cond_4

    .line 96
    .line 97
    const/4 v10, 0x1

    .line 98
    :cond_4
    or-int/2addr v1, v10

    .line 99
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    if-nez v1, :cond_5

    .line 104
    .line 105
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 106
    .line 107
    if-ne v0, v1, :cond_6

    .line 108
    .line 109
    :cond_5
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;

    .line 110
    .line 111
    invoke-direct {v0, v6, v5, v4}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$1$1;-><init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 112
    .line 113
    .line 114
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_6
    check-cast v0, LX/JDM;

    .line 118
    .line 119
    const/high16 p4, 0xc00000

    .line 120
    .line 121
    const/16 p5, 0x7e

    .line 122
    .line 123
    const/16 p1, 0x1

    .line 124
    .line 125
    move-object v13, v12

    .line 126
    move-object v14, v12

    .line 127
    move-object v15, v12

    .line 128
    move-object/from16 v16, v12

    .line 129
    .line 130
    move-object/from16 p0, v12

    .line 131
    .line 132
    move-object/from16 p2, v0

    .line 133
    .line 134
    move-object/from16 p3, v7

    .line 135
    .line 136
    invoke-static/range {v11 .. v22}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupsKt;->AuraButtonGroupStyleExplicit-FLdL6rA(LX/3C1;LX/2iK;LX/2wS;LX/JDM;LX/2iK;LX/2wS;Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupSize;ZLX/JDM;LX/2d4;II)V

    .line 137
    .line 138
    .line 139
    :goto_2
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    if-eqz v1, :cond_7

    .line 144
    .line 145
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$2;

    .line 146
    .line 147
    move-object/from16 p0, v0

    .line 148
    .line 149
    move-object/from16 p1, v6

    .line 150
    .line 151
    move-object/from16 p2, v5

    .line 152
    .line 153
    move-object/from16 p3, v4

    .line 154
    .line 155
    move-object/from16 p4, v2

    .line 156
    .line 157
    move/from16 p5, v3

    .line 158
    .line 159
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameBottomButtons$2;-><init>(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 160
    .line 161
    .line 162
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 163
    .line 164
    :cond_7
    return-void

    .line 165
    :cond_8
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 166
    .line 167
    .line 168
    goto :goto_2

    .line 169
    :cond_9
    and-int/lit16 v0, v3, 0xc00

    .line 170
    .line 171
    if-nez v0, :cond_2

    .line 172
    .line 173
    invoke-static {v7, v2}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    or-int/2addr v9, v0

    .line 178
    goto :goto_1

    .line 179
    :cond_a
    move v9, v3

    .line 180
    goto/16 :goto_0
.end method

.method public static final ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V
    .locals 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "LX/0PV;",
            "IZ",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p6

    .line 1
    .line 2
    const v0, -0x3b6f0632

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p7

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p8

    .line 11
    .line 12
    and-int/lit8 v0, p8, 0x6

    .line 13
    .line 14
    move-object/from16 v16, p0

    .line 15
    .line 16
    if-nez v0, :cond_e

    .line 17
    .line 18
    move-object/from16 v0, v16

    .line 19
    .line 20
    invoke-static {v6, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v11

    .line 24
    or-int v11, v11, p8

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 27
    .line 28
    move-object/from16 v15, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-static {v6, v15}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v11, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 38
    .line 39
    move-object/from16 v14, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v6, v14}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v11, v0

    .line 48
    :cond_1
    and-int/lit16 v0, v5, 0xc00

    .line 49
    .line 50
    move-object/from16 v9, p3

    .line 51
    .line 52
    if-nez v0, :cond_2

    .line 53
    .line 54
    invoke-static {v9, v6, v5}, LX/005;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    invoke-static {v0}, LX/003;->A02(I)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    or-int/2addr v11, v0

    .line 63
    :cond_2
    and-int/lit16 v0, v5, 0x6000

    .line 64
    .line 65
    move/from16 v8, p4

    .line 66
    .line 67
    if-nez v0, :cond_3

    .line 68
    .line 69
    invoke-static {v6, v8}, LX/004;->A0H(LX/2d4;I)I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    or-int/2addr v11, v0

    .line 74
    :cond_3
    const/high16 v0, 0x30000

    .line 75
    .line 76
    and-int v0, v0, p8

    .line 77
    .line 78
    move/from16 v13, p5

    .line 79
    .line 80
    if-nez v0, :cond_4

    .line 81
    .line 82
    invoke-static {v6, v13}, LX/004;->A0n(LX/2d4;Z)I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    or-int/2addr v11, v0

    .line 87
    :cond_4
    and-int/lit8 v1, p9, 0x40

    .line 88
    .line 89
    const/high16 v0, 0x180000

    .line 90
    .line 91
    if-nez v1, :cond_5

    .line 92
    .line 93
    and-int v0, v0, p8

    .line 94
    .line 95
    if-nez v0, :cond_6

    .line 96
    .line 97
    invoke-static {v6, v7}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    :cond_5
    or-int/2addr v11, v0

    .line 102
    :cond_6
    const v0, 0x92493

    .line 103
    .line 104
    .line 105
    invoke-static {v0, v11}, LX/005;->A1O(II)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    invoke-static {v0, v6, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_d

    .line 114
    .line 115
    if-eqz v1, :cond_7

    .line 116
    .line 117
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 118
    .line 119
    :cond_7
    const/4 v0, 0x2

    .line 120
    const/4 v4, 0x0

    .line 121
    const/4 v3, 0x0

    .line 122
    new-instance v2, LX/3PN;

    .line 123
    .line 124
    invoke-direct {v2, v4, v0, v3, v8}, LX/3PN;-><init>(Ljava/lang/Boolean;III)V

    .line 125
    .line 126
    .line 127
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 128
    .line 129
    const/4 v0, 0x6

    .line 130
    invoke-static {v6, v1}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 131
    .line 132
    .line 133
    move-result-wide p2

    .line 134
    invoke-virtual {v1, v6, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getShapes(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    iget-object v1, v0, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->large:LX/2bW;

    .line 139
    .line 140
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 141
    .line 142
    .line 143
    move-result-object v12

    .line 144
    and-int/lit16 v10, v11, 0x1c00

    .line 145
    .line 146
    const/16 v0, 0x800

    .line 147
    .line 148
    if-eq v10, v0, :cond_8

    .line 149
    .line 150
    and-int/lit16 v0, v11, 0x1000

    .line 151
    .line 152
    if-eqz v0, :cond_c

    .line 153
    .line 154
    invoke-interface {v6, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-eqz v0, :cond_c

    .line 159
    .line 160
    :cond_8
    const/4 v0, 0x1

    .line 161
    :goto_1
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v10

    .line 165
    if-nez v0, :cond_9

    .line 166
    .line 167
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 168
    .line 169
    if-ne v10, v0, :cond_a

    .line 170
    .line 171
    :cond_9
    new-instance v10, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$1$1;

    .line 172
    .line 173
    invoke-direct {v10, v9}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$1$1;-><init>(LX/0PV;)V

    .line 174
    .line 175
    .line 176
    invoke-interface {v6, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_a
    invoke-static {v12, v10, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 180
    .line 181
    .line 182
    move-result-object v19

    .line 183
    and-int/lit16 v0, v11, 0x3fe

    .line 184
    .line 185
    shr-int/lit8 v10, v11, 0x3

    .line 186
    .line 187
    invoke-static {v10, v0}, LX/002;->A09(II)I

    .line 188
    .line 189
    .line 190
    move-result p6

    .line 191
    const/16 p8, 0x7fa0

    .line 192
    .line 193
    move/from16 v24, v3

    .line 194
    .line 195
    move-object/from16 v25, v4

    .line 196
    .line 197
    move-object/from16 v26, v4

    .line 198
    .line 199
    move-object/from16 v27, v4

    .line 200
    .line 201
    move/from16 v28, v3

    .line 202
    .line 203
    move-object/from16 p0, v4

    .line 204
    .line 205
    move-object/from16 p1, v4

    .line 206
    .line 207
    move-object/from16 p4, v1

    .line 208
    .line 209
    move-object/from16 p5, v6

    .line 210
    .line 211
    move/from16 p7, v3

    .line 212
    .line 213
    move-object/from16 v22, v2

    .line 214
    .line 215
    move-object/from16 v23, v4

    .line 216
    .line 217
    move/from16 v20, v13

    .line 218
    .line 219
    move/from16 v21, v3

    .line 220
    .line 221
    move-object/from16 v18, v14

    .line 222
    .line 223
    move-object/from16 v17, v15

    .line 224
    .line 225
    invoke-static/range {v16 .. v37}, Lcom/facebook/aura/auth/login/ui/NativeLoginUiKitKt;->NativeLoginTextField-_M6-0Kc(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/3C1;ZZLX/3PN;LX/2WL;ZLjava/lang/String;LX/3PP;LX/JDN;ILX/3Gw;Ljava/lang/String;JLX/2bW;LX/2d4;III)V

    .line 226
    .line 227
    .line 228
    :goto_2
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    if-eqz v1, :cond_b

    .line 233
    .line 234
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;

    .line 235
    .line 236
    move-object/from16 p0, v0

    .line 237
    .line 238
    move-object/from16 p1, v16

    .line 239
    .line 240
    move-object/from16 p2, v15

    .line 241
    .line 242
    move-object/from16 p3, v14

    .line 243
    .line 244
    move-object/from16 p4, v9

    .line 245
    .line 246
    move/from16 p5, v8

    .line 247
    .line 248
    move/from16 p6, v13

    .line 249
    .line 250
    move-object/from16 p7, v7

    .line 251
    .line 252
    move/from16 p8, v5

    .line 253
    .line 254
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameField$2;-><init>(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;II)V

    .line 255
    .line 256
    .line 257
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 258
    .line 259
    :cond_b
    return-void

    .line 260
    :cond_c
    const/4 v0, 0x0

    .line 261
    goto :goto_1

    .line 262
    :cond_d
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 263
    .line 264
    .line 265
    goto :goto_2

    .line 266
    :cond_e
    move v11, v5

    .line 267
    goto/16 :goto_0
.end method

.method public static final ConfirmNameForm(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p4

    .line 1
    .line 2
    const v1, -0x586f6736

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p5

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p6

    .line 11
    .line 12
    and-int/lit8 v1, p6, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v1, :cond_6

    .line 17
    .line 18
    invoke-static {v0, v8}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    or-int v1, v1, p6

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v2, p6, 0x30

    .line 25
    .line 26
    move-object/from16 v4, p1

    .line 27
    .line 28
    if-nez v2, :cond_0

    .line 29
    .line 30
    invoke-static {v0, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    or-int/2addr v1, v2

    .line 35
    :cond_0
    and-int/lit16 v2, v3, 0x180

    .line 36
    .line 37
    move-object/from16 v15, p2

    .line 38
    .line 39
    if-nez v2, :cond_1

    .line 40
    .line 41
    invoke-static {v0, v15}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    or-int/2addr v1, v2

    .line 46
    :cond_1
    and-int/lit16 v2, v3, 0xc00

    .line 47
    .line 48
    move-object/from16 v11, p3

    .line 49
    .line 50
    if-nez v2, :cond_2

    .line 51
    .line 52
    invoke-static {v0, v11}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    or-int/2addr v1, v2

    .line 57
    :cond_2
    and-int/lit8 v9, p7, 0x10

    .line 58
    .line 59
    if-eqz v9, :cond_5

    .line 60
    .line 61
    or-int/lit16 v1, v1, 0x6000

    .line 62
    .line 63
    :cond_3
    :goto_1
    and-int/lit16 v5, v1, 0x2493

    .line 64
    .line 65
    const/16 v2, 0x2492

    .line 66
    .line 67
    const/4 v6, 0x0

    .line 68
    invoke-static {v5, v2}, LX/003;->A1H(II)Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-eqz v2, :cond_b

    .line 77
    .line 78
    if-eqz v9, :cond_4

    .line 79
    .line 80
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    :cond_4
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    invoke-static {v0}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 87
    .line 88
    .line 89
    move-result-object v14

    .line 90
    move-object v2, v0

    .line 91
    check-cast v2, LX/J7I;

    .line 92
    .line 93
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 94
    .line 95
    .line 96
    move-result v13

    .line 97
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 98
    .line 99
    .line 100
    move-result-object v12

    .line 101
    invoke-static {v0, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 102
    .line 103
    .line 104
    move-result-object v10

    .line 105
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 106
    .line 107
    iget-object v5, v2, LX/J7I;->A0V:LX/3DJ;

    .line 108
    .line 109
    if-nez v5, :cond_7

    .line 110
    .line 111
    invoke-static {}, LX/1VY;->A00()V

    .line 112
    .line 113
    .line 114
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    throw v0

    .line 119
    :cond_5
    and-int/lit16 v2, v3, 0x6000

    .line 120
    .line 121
    if-nez v2, :cond_3

    .line 122
    .line 123
    invoke-static {v0, v7}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 124
    .line 125
    .line 126
    move-result v2

    .line 127
    or-int/2addr v1, v2

    .line 128
    goto :goto_1

    .line 129
    :cond_6
    move v1, v3

    .line 130
    goto :goto_0

    .line 131
    :cond_7
    invoke-static {v0, v2, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v0, v14, v12, v10, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 135
    .line 136
    .line 137
    iget-object v9, v8, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->title:Ljava/lang/String;

    .line 138
    .line 139
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 140
    .line 141
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 142
    .line 143
    invoke-static {v5, v10}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 144
    .line 145
    .line 146
    move-result-object v17

    .line 147
    iget-object v10, v8, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->subtitle:Ljava/lang/String;

    .line 148
    .line 149
    invoke-static {v10}, LX/002;->A0e(Ljava/lang/String;)LX/2iK;

    .line 150
    .line 151
    .line 152
    move-result-object v18

    .line 153
    sget-object v21, Lcom/facebook/aura/auth/login/ui/NativeLoginTitleStyle;->TEXT_MEDIUM:Lcom/facebook/aura/auth/login/ui/NativeLoginTitleStyle;

    .line 154
    .line 155
    const v23, 0x36000

    .line 156
    .line 157
    .line 158
    const/16 v24, 0x8

    .line 159
    .line 160
    move-object/from16 v16, v9

    .line 161
    .line 162
    move/from16 v19, v6

    .line 163
    .line 164
    move/from16 v20, v6

    .line 165
    .line 166
    move-object/from16 v22, v0

    .line 167
    .line 168
    invoke-static/range {v16 .. v24}, Lcom/facebook/aura/auth/login/ui/NativeLoginUiKitKt;->NativeLoginHero(Ljava/lang/String;LX/3C1;LX/2iK;ZZLcom/facebook/aura/auth/login/ui/NativeLoginTitleStyle;LX/2d4;II)V

    .line 169
    .line 170
    .line 171
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 172
    .line 173
    invoke-static {v0, v5, v9}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 174
    .line 175
    .line 176
    iget-object v14, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->firstName:Ljava/lang/String;

    .line 177
    .line 178
    const v9, 0x7f12057c

    .line 179
    .line 180
    .line 181
    invoke-static {v0, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v16

    .line 185
    sget-object v17, LX/0Nq;->A0B:LX/0PV;

    .line 186
    .line 187
    const/16 v18, 0x6

    .line 188
    .line 189
    iget-boolean v9, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 190
    .line 191
    xor-int/lit8 v19, v9, 0x1

    .line 192
    .line 193
    shr-int/lit8 v9, v1, 0x3

    .line 194
    .line 195
    and-int/lit8 v9, v9, 0x70

    .line 196
    .line 197
    or-int/lit16 v10, v9, 0x6000

    .line 198
    .line 199
    const/16 v23, 0x40

    .line 200
    .line 201
    const/4 v9, 0x0

    .line 202
    move-object/from16 v20, v9

    .line 203
    .line 204
    move-object/from16 v21, v0

    .line 205
    .line 206
    move/from16 v22, v10

    .line 207
    .line 208
    invoke-static/range {v14 .. v23}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V

    .line 209
    .line 210
    .line 211
    invoke-static {v0, v5}, LX/1Vt;->A02(LX/2d4;LX/3C1;)V

    .line 212
    .line 213
    .line 214
    iget-object v5, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->lastName:Ljava/lang/String;

    .line 215
    .line 216
    const v10, 0x7f120580

    .line 217
    .line 218
    .line 219
    invoke-static {v0, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v26

    .line 223
    sget-object p0, LX/0Nq;->A0D:LX/0PV;

    .line 224
    .line 225
    const/16 p1, 0x7

    .line 226
    .line 227
    iget-boolean v10, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->isSaving:Z

    .line 228
    .line 229
    xor-int/lit8 p2, v10, 0x1

    .line 230
    .line 231
    shr-int/lit8 v1, v1, 0x6

    .line 232
    .line 233
    and-int/lit8 v1, v1, 0x70

    .line 234
    .line 235
    or-int/lit16 v1, v1, 0x6000

    .line 236
    .line 237
    move-object/from16 v24, v5

    .line 238
    .line 239
    move-object/from16 v25, v11

    .line 240
    .line 241
    move-object/from16 p3, v9

    .line 242
    .line 243
    move-object/from16 p4, v0

    .line 244
    .line 245
    move/from16 p5, v1

    .line 246
    .line 247
    move/from16 p6, v23

    .line 248
    .line 249
    invoke-static/range {v24 .. v33}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V

    .line 250
    .line 251
    .line 252
    iget-object v5, v4, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;->error:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError;

    .line 253
    .line 254
    instance-of v1, v5, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Server;

    .line 255
    .line 256
    if-eqz v1, :cond_8

    .line 257
    .line 258
    const v1, 0x789a45ba

    .line 259
    .line 260
    .line 261
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 262
    .line 263
    .line 264
    invoke-static {v2, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 265
    .line 266
    .line 267
    check-cast v5, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Server;

    .line 268
    .line 269
    iget-object v5, v5, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Server;->detail:Ljava/lang/String;

    .line 270
    .line 271
    :goto_2
    const/4 v1, 0x2

    .line 272
    invoke-static {v5, v9, v0, v6, v1}, Lcom/facebook/aura/auth/login/ui/NativeLoginUiKitKt;->NativeLoginFieldErrorSlot(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 273
    .line 274
    .line 275
    invoke-static {v2, v7}, LX/002;->A0Y(LX/J7I;LX/3C1;)LX/3C1;

    .line 276
    .line 277
    .line 278
    move-result-object v7

    .line 279
    goto :goto_3

    .line 280
    :cond_8
    sget-object v1, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Generic;->INSTANCE:Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$ConfirmNameError$Generic;

    .line 281
    .line 282
    invoke-static {v5, v1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-result v1

    .line 286
    if-eqz v1, :cond_9

    .line 287
    .line 288
    const v1, 0x789a4c0e

    .line 289
    .line 290
    .line 291
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 292
    .line 293
    .line 294
    const v1, 0x7f120c4e

    .line 295
    .line 296
    .line 297
    invoke-static {v0, v2, v1}, LX/18b;->A06(LX/2d4;LX/J7I;I)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v5

    .line 301
    goto :goto_2

    .line 302
    :cond_9
    if-nez v5, :cond_a

    .line 303
    .line 304
    const v1, -0x654f96f7

    .line 305
    .line 306
    .line 307
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 308
    .line 309
    .line 310
    invoke-static {v2, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 311
    .line 312
    .line 313
    const/4 v5, 0x0

    .line 314
    goto :goto_2

    .line 315
    :cond_a
    const v1, 0x789a3bfd

    .line 316
    .line 317
    .line 318
    invoke-static {v0, v2, v1}, LX/008;->A1D(LX/2d4;LX/J7I;I)Lkotlin/NoWhenBranchMatchedException;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    throw v0

    .line 323
    :cond_b
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 324
    .line 325
    .line 326
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 327
    .line 328
    .line 329
    move-result-object v1

    .line 330
    if-eqz v1, :cond_c

    .line 331
    .line 332
    new-instance v0, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameForm$2;

    .line 333
    .line 334
    move-object/from16 p0, v0

    .line 335
    .line 336
    move-object/from16 p1, v8

    .line 337
    .line 338
    move-object/from16 p2, v4

    .line 339
    .line 340
    move-object/from16 p3, v15

    .line 341
    .line 342
    move-object/from16 p4, v11

    .line 343
    .line 344
    move-object/from16 p5, v7

    .line 345
    .line 346
    move/from16 p6, v3

    .line 347
    .line 348
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt$ConfirmNameForm$2;-><init>(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/JDM;LX/JDM;LX/3C1;II)V

    .line 349
    .line 350
    .line 351
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 352
    .line 353
    :cond_c
    return-void
.end method

.method public static final synthetic access$AuraConfirmNameScreen$lambda$0(LX/16A;)Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$ConfirmNameBottomButtons(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameBottomButtons(Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p9}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameField-X0zcS7w(Ljava/lang/String;LX/JDM;Ljava/lang/String;LX/0PV;IZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ConfirmNameForm(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->ConfirmNameForm(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/model/AuraConfirmNameViewModel$UiState;LX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logConfirmNameClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/AuraConfirmNameScreenKt;->logConfirmNameClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final logConfirmNameClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 7

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_NAME_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v4, p0

    .line 8
    move-object v5, v2

    .line 9
    move-object v6, v2

    .line 10
    move-object p0, v2

    .line 11
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
