.class public final Lcom/facebook/aura/activation/view/SeededRandom;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public state:J


# direct methods
.method public constructor <init>(J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/activation/view/SeededRandom;->state:J

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final unit()F
    .locals 6

    .line 0
    iget-wide v4, p0, Lcom/facebook/aura/activation/view/SeededRandom;->state:J

    .line 1
    .line 2
    const-wide v0, 0x5851f42d4c957f2dL    # 2.8296655102636685E117

    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    mul-long/2addr v4, v0

    .line 8
    const-wide v0, 0x14057b7ef767814fL    # 3.190626645921225E-212

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    add-long/2addr v4, v0

    .line 14
    iput-wide v4, p0, Lcom/facebook/aura/activation/view/SeededRandom;->state:J

    .line 15
    .line 16
    const/16 v0, 0xb

    .line 17
    .line 18
    ushr-long/2addr v4, v0

    .line 19
    long-to-double v2, v4

    .line 20
    const-wide/high16 v0, 0x4340000000000000L    # 9.007199254740992E15

    .line 21
    .line 22
    div-double/2addr v2, v0

    .line 23
    double-to-float v0, v2

    .line 24
    return v0
.end method

.method public final value(FF)F
    .locals 0

    .line 0
    invoke-static {p0, p2, p1}, LX/603;->A01(Lcom/facebook/aura/activation/view/SeededRandom;FF)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method
