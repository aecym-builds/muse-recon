.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1"
    f = "AuraWaitlistConfetti.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public synthetic L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v5, LX/1EL;

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 12
    .line 13
    const/4 v4, 0x0

    .line 14
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;

    .line 15
    .line 16
    invoke-direct {v0, v1, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 17
    .line 18
    .line 19
    sget-object v3, LX/39s;->A00:LX/39s;

    .line 20
    .line 21
    sget-object v2, LX/FkO;->A00:Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-static {v2, v3, v0, v5}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1;->$state:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;

    .line 29
    .line 30
    invoke-direct {v0, v1, v4}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$rememberAuraWaitlistCelebrationState$1$1$1$2;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;LX/2M4;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v2, v3, v0, v5}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 34
    .line 35
    .line 36
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 37
    .line 38
    return-object v0

    .line 39
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    throw v0
.end method
