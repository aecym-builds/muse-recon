.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public final synthetic $ctaBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $isJoined:Z

.field public final synthetic $isJoiningWaitlist:Z

.field public final synthetic $mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

.field public final synthetic $onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lcom/facebook/aura/activation/view/WaitlistScreenMode;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Lcom/facebook/aura/activation/view/WaitlistScreenMode;",
            "ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$isJoined:Z

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$isJoiningWaitlist:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$ctaBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 15
    .line 16
    const/4 v0, 0x3

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 13

    .line 268435456
    const/4 v10, 0x0

    .line 268435457
    move/from16 v1, p3

    .line 268435458
    .line 268435459
    invoke-static {p1, v10, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435460
    .line 268435461
    .line 268435462
    move-result v0

    .line 268435463
    move-object v9, p2

    .line 268435464
    invoke-static {v0, p2, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    if-eqz v0, :cond_6

    .line 268435469
    .line 268435470
    move-object v2, p0

    .line 268435471
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 268435472
    .line 268435473
    iget-object v11, v0, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->title:Ljava/lang/String;

    .line 268435474
    .line 268435475
    iget-object v12, v0, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->subtitle:Ljava/lang/String;

    .line 268435476
    .line 268435477
    const/4 p0, 0x0

    .line 268435478
    const/16 p3, 0x4

    .line 268435479
    .line 268435480
    move-object p1, p2

    .line 268435481
    move p2, v10

    .line 268435482
    invoke-static/range {v11 .. v16}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->WaitlistHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 268435483
    .line 268435484
    .line 268435485
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 268435486
    .line 268435487
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 268435488
    .line 268435489
    invoke-static {v9, v4, v0}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435490
    .line 268435491
    .line 268435492
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 268435493
    .line 268435494
    iget-object v1, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$ctaBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435495
    .line 268435496
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435497
    .line 268435498
    .line 268435499
    move-result-object v0

    .line 268435500
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435501
    .line 268435502
    if-ne v0, v7, :cond_0

    .line 268435503
    .line 268435504
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3$ctaModifier$1$1;

    .line 268435505
    .line 268435506
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3$ctaModifier$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 268435507
    .line 268435508
    .line 268435509
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435510
    .line 268435511
    .line 268435512
    :cond_0
    check-cast v0, LX/JDM;

    .line 268435513
    .line 268435514
    const/4 v3, 0x2

    .line 268435515
    invoke-static {v5, v0}, LX/604;->A07(LX/3C1;LX/JDM;)LX/3C1;

    .line 268435516
    .line 268435517
    .line 268435518
    move-result-object v6

    .line 268435519
    iget-object v0, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 268435520
    .line 268435521
    invoke-interface {v9, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435522
    .line 268435523
    .line 268435524
    move-result v5

    .line 268435525
    iget-object v1, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 268435526
    .line 268435527
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435528
    .line 268435529
    .line 268435530
    move-result-object v0

    .line 268435531
    if-nez v5, :cond_1

    .line 268435532
    .line 268435533
    if-ne v0, v7, :cond_2

    .line 268435534
    .line 268435535
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3$ctaModifier$2$1;

    .line 268435536
    .line 268435537
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3$ctaModifier$2$1;-><init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;)V

    .line 268435538
    .line 268435539
    .line 268435540
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435541
    .line 268435542
    .line 268435543
    :cond_2
    invoke-static {v6, v0}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 268435544
    .line 268435545
    .line 268435546
    move-result-object v8

    .line 268435547
    iget-object v0, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$mode:Lcom/facebook/aura/activation/view/WaitlistScreenMode;

    .line 268435548
    .line 268435549
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 268435550
    .line 268435551
    .line 268435552
    move-result v1

    .line 268435553
    const/4 v0, 0x1

    .line 268435554
    if-eq v1, v10, :cond_4

    .line 268435555
    .line 268435556
    if-eq v1, v0, :cond_4

    .line 268435557
    .line 268435558
    if-ne v1, v3, :cond_5

    .line 268435559
    .line 268435560
    const v0, 0x121f63b7

    .line 268435561
    .line 268435562
    .line 268435563
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 268435564
    .line 268435565
    .line 268435566
    invoke-static {v8, v9, v10, v10}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->NotificationOptInCta(LX/3C1;LX/2d4;II)V

    .line 268435567
    .line 268435568
    .line 268435569
    invoke-static {v9}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 268435570
    .line 268435571
    .line 268435572
    move-result-object v0

    .line 268435573
    :goto_0
    iget-object v1, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;

    .line 268435574
    .line 268435575
    if-eqz v1, :cond_3

    .line 268435576
    .line 268435577
    const v1, 0x31ce793e

    .line 268435578
    .line 268435579
    .line 268435580
    invoke-interface {v9, v1}, LX/2d4;->Agj(I)V

    .line 268435581
    .line 268435582
    .line 268435583
    invoke-static {v9, v4}, LX/1Vt;->A03(LX/2d4;LX/3C1;)V

    .line 268435584
    .line 268435585
    .line 268435586
    iget-object v1, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$onHaveInviteCodeClick:Lkotlin/jvm/functions/Function0;

    .line 268435587
    .line 268435588
    invoke-static {v1, p0, v9, v10, v3}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->HaveInviteCodeLink(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435589
    .line 268435590
    .line 268435591
    :goto_1
    invoke-static {v0, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435592
    .line 268435593
    .line 268435594
    return-void

    .line 268435595
    :cond_3
    const v1, 0x31d03f77

    .line 268435596
    .line 268435597
    .line 268435598
    invoke-interface {v9, v1}, LX/2d4;->Agj(I)V

    .line 268435599
    .line 268435600
    .line 268435601
    goto :goto_1

    .line 268435602
    :cond_4
    const v0, 0x121f45f9

    .line 268435603
    .line 268435604
    .line 268435605
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 268435606
    .line 268435607
    .line 268435608
    iget-boolean v5, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$isJoined:Z

    .line 268435609
    .line 268435610
    iget-boolean v6, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$isJoiningWaitlist:Z

    .line 268435611
    .line 268435612
    iget-object v7, v2, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$AuraWaitlistScreen$3;->$onJoinWaitlistClick:Lkotlin/jvm/functions/Function0;

    .line 268435613
    .line 268435614
    move v11, v10

    .line 268435615
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt;->JoinWaitlistCta(ZZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435616
    .line 268435617
    .line 268435618
    invoke-static {v9}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 268435619
    .line 268435620
    .line 268435621
    move-result-object v0

    .line 268435622
    goto :goto_0

    .line 268435623
    :cond_5
    const v0, 0x121f3b6a

    .line 268435624
    .line 268435625
    .line 268435626
    invoke-static {v9, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 268435627
    .line 268435628
    .line 268435629
    move-result-object v0

    .line 268435630
    throw v0

    .line 268435631
    :cond_6
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435632
    .line 268435633
    .line 268435634
    return-void
.end method
