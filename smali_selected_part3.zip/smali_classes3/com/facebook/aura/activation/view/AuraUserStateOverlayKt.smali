.class public abstract Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AuraUserStateOverlay(Lcom/facebook/aura/user/provider/AuraUserData;LX/AHE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 83
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/user/provider/AuraUserData;",
            "LX/AHE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v31, p4

    .line 1
    .line 2
    const/4 v10, 0x1

    .line 3
    move-object/from16 v81, p1

    .line 4
    .line 5
    move-object/from16 v82, p3

    .line 6
    .line 7
    move-object/from16 v2, v81

    .line 8
    .line 9
    move-object/from16 v1, p2

    .line 10
    .line 11
    move-object/from16 v0, v82

    .line 12
    .line 13
    invoke-static {v2, v1, v0, v10}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    const v1, 0xa393d85

    .line 17
    .line 18
    .line 19
    move-object/from16 v0, p5

    .line 20
    .line 21
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 22
    .line 23
    .line 24
    move/from16 v30, p6

    .line 25
    .line 26
    and-int/lit8 v1, p6, 0x6

    .line 27
    .line 28
    move-object/from16 v5, p0

    .line 29
    .line 30
    if-nez v1, :cond_a

    .line 31
    .line 32
    invoke-static {v0, v5}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    or-int v3, v3, p6

    .line 37
    .line 38
    :goto_0
    and-int/lit8 v1, p6, 0x30

    .line 39
    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    invoke-static {v0, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    or-int/2addr v3, v1

    .line 47
    :cond_0
    move/from16 v1, v30

    .line 48
    .line 49
    and-int/lit16 v1, v1, 0x180

    .line 50
    .line 51
    if-nez v1, :cond_1

    .line 52
    .line 53
    move-object/from16 v1, p2

    .line 54
    .line 55
    invoke-static {v0, v1}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    or-int/2addr v3, v1

    .line 60
    :cond_1
    move/from16 v1, v30

    .line 61
    .line 62
    and-int/lit16 v1, v1, 0xc00

    .line 63
    .line 64
    if-nez v1, :cond_2

    .line 65
    .line 66
    move-object/from16 v1, v82

    .line 67
    .line 68
    invoke-static {v0, v1}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    or-int/2addr v3, v1

    .line 73
    :cond_2
    move/from16 v77, p7

    .line 74
    .line 75
    and-int/lit8 v4, p7, 0x10

    .line 76
    .line 77
    if-eqz v4, :cond_9

    .line 78
    .line 79
    or-int/lit16 v3, v3, 0x6000

    .line 80
    .line 81
    :cond_3
    :goto_1
    and-int/lit16 v2, v3, 0x2493

    .line 82
    .line 83
    const/16 v1, 0x2492

    .line 84
    .line 85
    const/16 v29, 0x1

    .line 86
    .line 87
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    invoke-static {v1, v0, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-eqz v1, :cond_b

    .line 96
    .line 97
    if-eqz v4, :cond_4

    .line 98
    .line 99
    sget-object v31, LX/3C1;->A00:LX/3Cb;

    .line 100
    .line 101
    :cond_4
    sget-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->A05:LX/Ip3;

    .line 102
    .line 103
    invoke-interface {v0, v1}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v28

    .line 107
    check-cast v28, Landroid/view/View;

    .line 108
    .line 109
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v9

    .line 113
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 114
    .line 115
    if-ne v9, v4, :cond_5

    .line 116
    .line 117
    const/4 v1, 0x0

    .line 118
    new-instance v9, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 119
    .line 120
    invoke-direct {v9, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 121
    .line 122
    .line 123
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_5
    check-cast v9, LX/2ss;

    .line 127
    .line 128
    invoke-static {v0, v4}, LX/604;->A0I(LX/2d4;Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v8

    .line 132
    check-cast v8, LX/2ss;

    .line 133
    .line 134
    sget-object v27, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 135
    .line 136
    const/4 v1, 0x6

    .line 137
    move-object/from16 v2, v27

    .line 138
    .line 139
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 140
    .line 141
    .line 142
    move-result-object v26

    .line 143
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    invoke-static {v0, v2, v4}, LX/004;->A1B(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v25

    .line 151
    check-cast v25, LX/1EL;

    .line 152
    .line 153
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    const/4 v15, 0x0

    .line 158
    invoke-static {v0, v2, v4, v15}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v24

    .line 162
    check-cast v24, Landroidx/compose/runtime/MutableState;

    .line 163
    .line 164
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    if-ne v2, v4, :cond_6

    .line 169
    .line 170
    invoke-static {v15}, LX/004;->A12(Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    invoke-interface {v0, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_6
    check-cast v2, Landroidx/compose/runtime/MutableState;

    .line 178
    .line 179
    invoke-static {v0, v4, v15}, LX/005;->A0k(LX/2d4;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v80

    .line 183
    check-cast v80, Landroidx/compose/runtime/MutableState;

    .line 184
    .line 185
    const v7, 0x3f333333    # 0.7f

    .line 186
    .line 187
    .line 188
    move-object/from16 v6, v31

    .line 189
    .line 190
    invoke-static {v6, v7}, LX/2sI;->A03(LX/3C1;F)LX/3C1;

    .line 191
    .line 192
    .line 193
    move-result-object v11

    .line 194
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v6

    .line 198
    if-ne v6, v4, :cond_7

    .line 199
    .line 200
    new-instance v6, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;

    .line 201
    .line 202
    invoke-direct {v6, v9, v8}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$1$1;-><init>(LX/2ss;LX/2ss;)V

    .line 203
    .line 204
    .line 205
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    :cond_7
    check-cast v6, LX/JDM;

    .line 209
    .line 210
    invoke-static {v11, v6}, LX/7mL;->A03(LX/3C1;LX/JDM;)LX/3C1;

    .line 211
    .line 212
    .line 213
    move-result-object v12

    .line 214
    sget-object v11, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 215
    .line 216
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v6

    .line 220
    if-ne v6, v4, :cond_8

    .line 221
    .line 222
    new-instance v6, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;

    .line 223
    .line 224
    invoke-direct {v6, v9, v8}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$2$1;-><init>(LX/2ss;LX/2ss;)V

    .line 225
    .line 226
    .line 227
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    :cond_8
    check-cast v6, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 231
    .line 232
    invoke-static {v12, v6, v11}, LX/3BV;->A00(LX/3C1;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;Ljava/lang/Object;)LX/3C1;

    .line 233
    .line 234
    .line 235
    move-result-object v6

    .line 236
    const/high16 v11, 0x41400000    # 12.0f

    .line 237
    .line 238
    invoke-static {v6, v11}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 239
    .line 240
    .line 241
    move-result-object v6

    .line 242
    invoke-static {v6, v7}, LX/1qG;->A00(LX/3C1;F)LX/3C1;

    .line 243
    .line 244
    .line 245
    move-result-object v9

    .line 246
    move-object/from16 v6, v26

    .line 247
    .line 248
    iget-wide v6, v6, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 249
    .line 250
    const/4 v14, 0x0

    .line 251
    sget-object v23, LX/2oZ;->A00:LX/2bW;

    .line 252
    .line 253
    move-object/from16 v8, v23

    .line 254
    .line 255
    invoke-static {v9, v8, v6, v7}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 256
    .line 257
    .line 258
    move-result-object v6

    .line 259
    invoke-static {v6, v11}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 260
    .line 261
    .line 262
    move-result-object v11

    .line 263
    invoke-static {v0}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 264
    .line 265
    .line 266
    move-result-object v9

    .line 267
    move-object v6, v0

    .line 268
    check-cast v6, LX/J7I;

    .line 269
    .line 270
    iget-wide v7, v6, LX/J7I;->A06:J

    .line 271
    .line 272
    invoke-static {v7, v8}, LX/001;->A0A(J)I

    .line 273
    .line 274
    .line 275
    move-result v12

    .line 276
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 277
    .line 278
    .line 279
    move-result-object v8

    .line 280
    invoke-static {v0, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 281
    .line 282
    .line 283
    move-result-object v11

    .line 284
    const/high16 v22, 0x41400000    # 12.0f

    .line 285
    .line 286
    sget-object v21, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 287
    .line 288
    iget-object v7, v6, LX/J7I;->A0V:LX/3DJ;

    .line 289
    .line 290
    if-nez v7, :cond_c

    .line 291
    .line 292
    invoke-static {}, LX/1VY;->A00()V

    .line 293
    .line 294
    .line 295
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    throw v0

    .line 300
    :cond_9
    move/from16 v1, v30

    .line 301
    .line 302
    and-int/lit16 v1, v1, 0x6000

    .line 303
    .line 304
    if-nez v1, :cond_3

    .line 305
    .line 306
    move-object/from16 v1, v31

    .line 307
    .line 308
    invoke-static {v0, v1}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 309
    .line 310
    .line 311
    move-result v1

    .line 312
    or-int/2addr v3, v1

    .line 313
    goto/16 :goto_1

    .line 314
    .line 315
    :cond_a
    move/from16 v3, v30

    .line 316
    .line 317
    goto/16 :goto_0

    .line 318
    .line 319
    :cond_b
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 320
    .line 321
    .line 322
    goto/16 :goto_5

    .line 323
    .line 324
    :cond_c
    move-object/from16 v7, v21

    .line 325
    .line 326
    invoke-static {v0, v6, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 327
    .line 328
    .line 329
    sget-object v20, LX/3Cl;->A04:LX/JDN;

    .line 330
    .line 331
    move-object/from16 v7, v20

    .line 332
    .line 333
    invoke-static {v0, v9, v7}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 334
    .line 335
    .line 336
    move-result-object v19

    .line 337
    move-object/from16 v7, v19

    .line 338
    .line 339
    invoke-static {v0, v8, v7, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 340
    .line 341
    .line 342
    move-result-object v18

    .line 343
    sget-object v17, LX/3Cl;->A02:LX/JDM;

    .line 344
    .line 345
    move-object/from16 v7, v17

    .line 346
    .line 347
    invoke-static {v0, v11, v7}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 348
    .line 349
    .line 350
    move-result-object v16

    .line 351
    sget-object v7, LX/2Id;->A04:LX/2rU;

    .line 352
    .line 353
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 354
    .line 355
    invoke-static {v0, v7}, LX/003;->A0Z(LX/2d4;LX/2rU;)LX/3BI;

    .line 356
    .line 357
    .line 358
    move-result-object v13

    .line 359
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 360
    .line 361
    .line 362
    move-result v12

    .line 363
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 364
    .line 365
    .line 366
    move-result-object v11

    .line 367
    invoke-static {v0, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 368
    .line 369
    .line 370
    move-result-object v8

    .line 371
    move-object/from16 v7, v21

    .line 372
    .line 373
    invoke-static {v0, v6, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 374
    .line 375
    .line 376
    move-object/from16 v7, v20

    .line 377
    .line 378
    invoke-static {v0, v13, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 379
    .line 380
    .line 381
    move-object/from16 v7, v19

    .line 382
    .line 383
    invoke-static {v0, v11, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 384
    .line 385
    .line 386
    move-object/from16 v11, v18

    .line 387
    .line 388
    move-object/from16 v7, v17

    .line 389
    .line 390
    invoke-static {v7, v11, v0, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 391
    .line 392
    .line 393
    move-object/from16 v7, v16

    .line 394
    .line 395
    invoke-static {v0, v8, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 396
    .line 397
    .line 398
    sget-object v7, LX/CgK;->A00:LX/CgK;

    .line 399
    .line 400
    move-object/from16 v8, v27

    .line 401
    .line 402
    invoke-static {v0, v8}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 403
    .line 404
    .line 405
    move-result-object v36

    .line 406
    const/16 v50, 0x3ff6

    .line 407
    .line 408
    const-string v32, "Debug Activation State"

    .line 409
    .line 410
    const-wide/16 v34, 0x0

    .line 411
    .line 412
    move-object/from16 v33, v14

    .line 413
    .line 414
    move-object/from16 v37, v14

    .line 415
    .line 416
    move-object/from16 v38, v14

    .line 417
    .line 418
    move-object/from16 v39, v14

    .line 419
    .line 420
    move/from16 v40, v15

    .line 421
    .line 422
    move/from16 v41, v15

    .line 423
    .line 424
    move/from16 v42, v15

    .line 425
    .line 426
    move/from16 v43, v15

    .line 427
    .line 428
    move-object/from16 v44, v14

    .line 429
    .line 430
    move-object/from16 v45, v14

    .line 431
    .line 432
    move-object/from16 v46, v14

    .line 433
    .line 434
    move-object/from16 v47, v0

    .line 435
    .line 436
    move/from16 v48, v1

    .line 437
    .line 438
    move/from16 v49, v15

    .line 439
    .line 440
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 441
    .line 442
    .line 443
    invoke-static {v7, v9, v10}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 444
    .line 445
    .line 446
    move-result-object v7

    .line 447
    invoke-static {v0, v7}, LX/1Vt;->A04(LX/2d4;LX/3C1;)V

    .line 448
    .line 449
    .line 450
    invoke-static {v0, v8}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 451
    .line 452
    .line 453
    move-result-object v36

    .line 454
    invoke-static {v3}, LX/005;->A1J(I)Z

    .line 455
    .line 456
    .line 457
    move-result v7

    .line 458
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    move-result-object v8

    .line 462
    if-nez v7, :cond_d

    .line 463
    .line 464
    if-ne v8, v4, :cond_e

    .line 465
    .line 466
    :cond_d
    new-instance v8, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$1$1$1;

    .line 467
    .line 468
    move-object/from16 v7, p2

    .line 469
    .line 470
    invoke-direct {v8, v7}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$1$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 471
    .line 472
    .line 473
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 474
    .line 475
    .line 476
    :cond_e
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 477
    .line 478
    invoke-static {v9, v14, v14, v8, v10}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 479
    .line 480
    .line 481
    move-result-object v8

    .line 482
    const/high16 v7, 0x40800000    # 4.0f

    .line 483
    .line 484
    invoke-static {v8, v7}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 485
    .line 486
    .line 487
    move-result-object v33

    .line 488
    const/16 v50, 0x3ff4

    .line 489
    .line 490
    const-string v32, "\u2715"

    .line 491
    .line 492
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 493
    .line 494
    .line 495
    invoke-static {v6, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 496
    .line 497
    .line 498
    const/high16 v11, 0x41000000    # 8.0f

    .line 499
    .line 500
    invoke-static {v0, v9, v11}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 501
    .line 502
    .line 503
    if-nez p0, :cond_19

    .line 504
    .line 505
    const v8, 0x678ea5f1

    .line 506
    .line 507
    .line 508
    move-object/from16 v7, v27

    .line 509
    .line 510
    invoke-static {v0, v7, v8}, LX/002;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 511
    .line 512
    .line 513
    move-result-object v7

    .line 514
    iget-object v7, v7, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption2Regular:LX/2hg;

    .line 515
    .line 516
    const/16 v54, 0x3ff6

    .line 517
    .line 518
    const-string v36, "No user data"

    .line 519
    .line 520
    move-wide/from16 v38, v34

    .line 521
    .line 522
    move-object/from16 v40, v7

    .line 523
    .line 524
    move-object/from16 v41, v14

    .line 525
    .line 526
    move-object/from16 v42, v14

    .line 527
    .line 528
    move-object/from16 v43, v14

    .line 529
    .line 530
    move/from16 v44, v15

    .line 531
    .line 532
    move/from16 v45, v15

    .line 533
    .line 534
    move/from16 v46, v15

    .line 535
    .line 536
    move/from16 v47, v15

    .line 537
    .line 538
    move-object/from16 v48, v14

    .line 539
    .line 540
    move-object/from16 v49, v14

    .line 541
    .line 542
    move-object/from16 v50, v14

    .line 543
    .line 544
    move-object/from16 v51, v0

    .line 545
    .line 546
    move/from16 v52, v1

    .line 547
    .line 548
    move/from16 v53, v15

    .line 549
    .line 550
    invoke-static/range {v36 .. v54}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 551
    .line 552
    .line 553
    invoke-static {v6, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 554
    .line 555
    .line 556
    :goto_2
    move/from16 v1, v22

    .line 557
    .line 558
    invoke-static {v0, v9, v1}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 559
    .line 560
    .line 561
    invoke-static {v15}, LX/001;->A0g(Z)LX/3BI;

    .line 562
    .line 563
    .line 564
    move-result-object v12

    .line 565
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 566
    .line 567
    .line 568
    move-result v13

    .line 569
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 570
    .line 571
    .line 572
    move-result-object v8

    .line 573
    invoke-static {v0, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 574
    .line 575
    .line 576
    move-result-object v7

    .line 577
    move-object/from16 v1, v21

    .line 578
    .line 579
    invoke-static {v0, v6, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 580
    .line 581
    .line 582
    move-object/from16 v1, v20

    .line 583
    .line 584
    invoke-static {v0, v12, v1}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 585
    .line 586
    .line 587
    move-object/from16 v1, v19

    .line 588
    .line 589
    invoke-static {v0, v8, v1}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 590
    .line 591
    .line 592
    move-object/from16 v8, v18

    .line 593
    .line 594
    move-object/from16 v1, v17

    .line 595
    .line 596
    invoke-static {v1, v8, v0, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 597
    .line 598
    .line 599
    move-object/from16 v1, v16

    .line 600
    .line 601
    invoke-static {v0, v7, v1}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 602
    .line 603
    .line 604
    invoke-static {v2}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 605
    .line 606
    .line 607
    move-result v1

    .line 608
    if-eqz v1, :cond_18

    .line 609
    .line 610
    const-string v58, "Setting status..."

    .line 611
    .line 612
    :goto_3
    move-object/from16 v1, v27

    .line 613
    .line 614
    invoke-static {v0, v1}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 615
    .line 616
    .line 617
    move-result-object v37

    .line 618
    sget-object v40, LX/2W8;->A01:LX/2W8;

    .line 619
    .line 620
    const v49, 0xfffffb

    .line 621
    .line 622
    .line 623
    move-object/from16 v36, v14

    .line 624
    .line 625
    move-object/from16 v38, v14

    .line 626
    .line 627
    move-object/from16 v39, v14

    .line 628
    .line 629
    move-object/from16 v41, v14

    .line 630
    .line 631
    move-object/from16 v42, v14

    .line 632
    .line 633
    move-object/from16 v43, v14

    .line 634
    .line 635
    move-object/from16 v44, v14

    .line 636
    .line 637
    move-object/from16 v45, v14

    .line 638
    .line 639
    move/from16 v46, v15

    .line 640
    .line 641
    move/from16 v47, v15

    .line 642
    .line 643
    move/from16 v48, v15

    .line 644
    .line 645
    move-wide/from16 v50, v34

    .line 646
    .line 647
    move-wide/from16 v52, v34

    .line 648
    .line 649
    move-wide/from16 v54, v34

    .line 650
    .line 651
    move-wide/from16 v56, v34

    .line 652
    .line 653
    invoke-static/range {v36 .. v57}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 654
    .line 655
    .line 656
    move-result-object v62

    .line 657
    invoke-static {v9, v11}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 658
    .line 659
    .line 660
    move-result-object v12

    .line 661
    move-object/from16 v1, v26

    .line 662
    .line 663
    iget-wide v7, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 664
    .line 665
    move-object/from16 v1, v23

    .line 666
    .line 667
    invoke-static {v12, v1, v7, v8}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 668
    .line 669
    .line 670
    move-result-object v8

    .line 671
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 672
    .line 673
    .line 674
    move-result-object v7

    .line 675
    if-ne v7, v4, :cond_f

    .line 676
    .line 677
    new-instance v7, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$1$1;

    .line 678
    .line 679
    move-object/from16 v1, v24

    .line 680
    .line 681
    invoke-direct {v7, v2, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$1$1;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 682
    .line 683
    .line 684
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 685
    .line 686
    .line 687
    :cond_f
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 688
    .line 689
    invoke-static {v8, v14, v14, v7, v10}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 690
    .line 691
    .line 692
    move-result-object v7

    .line 693
    move/from16 v1, v22

    .line 694
    .line 695
    invoke-static {v7, v1, v11}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 696
    .line 697
    .line 698
    move-result-object v59

    .line 699
    const/16 v76, 0x3ff4

    .line 700
    .line 701
    move-wide/from16 v60, v34

    .line 702
    .line 703
    move-object/from16 v63, v14

    .line 704
    .line 705
    move-object/from16 v64, v14

    .line 706
    .line 707
    move-object/from16 v65, v14

    .line 708
    .line 709
    move/from16 v66, v15

    .line 710
    .line 711
    move/from16 v67, v15

    .line 712
    .line 713
    move/from16 v68, v15

    .line 714
    .line 715
    move/from16 v69, v15

    .line 716
    .line 717
    move-object/from16 v70, v14

    .line 718
    .line 719
    move-object/from16 v71, v14

    .line 720
    .line 721
    move-object/from16 v72, v14

    .line 722
    .line 723
    move-object/from16 v73, v0

    .line 724
    .line 725
    move/from16 v74, v15

    .line 726
    .line 727
    move/from16 v75, v15

    .line 728
    .line 729
    invoke-static/range {v58 .. v76}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 730
    .line 731
    .line 732
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 733
    .line 734
    .line 735
    move-result v50

    .line 736
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 737
    .line 738
    .line 739
    move-result-object v8

    .line 740
    if-ne v8, v4, :cond_10

    .line 741
    .line 742
    new-instance v8, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$2$1;

    .line 743
    .line 744
    move-object/from16 v1, v24

    .line 745
    .line 746
    invoke-direct {v8, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 747
    .line 748
    .line 749
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 750
    .line 751
    .line 752
    :cond_10
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 753
    .line 754
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 755
    .line 756
    .line 757
    move-result-object v7

    .line 758
    if-ne v7, v4, :cond_11

    .line 759
    .line 760
    new-instance v7, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$3$1;

    .line 761
    .line 762
    invoke-direct {v7, v2}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$3$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 763
    .line 764
    .line 765
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 766
    .line 767
    .line 768
    :cond_11
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 769
    .line 770
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 771
    .line 772
    .line 773
    move-result-object v1

    .line 774
    if-ne v1, v4, :cond_12

    .line 775
    .line 776
    new-instance v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$4$1;

    .line 777
    .line 778
    invoke-direct {v1, v2}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$2$4$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 779
    .line 780
    .line 781
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 782
    .line 783
    .line 784
    :cond_12
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 785
    .line 786
    shl-int/lit8 v2, v3, 0x3

    .line 787
    .line 788
    and-int/lit16 v2, v2, 0x380

    .line 789
    .line 790
    const v12, 0x1b0030

    .line 791
    .line 792
    .line 793
    or-int/2addr v2, v12

    .line 794
    const/16 v12, 0x800

    .line 795
    .line 796
    move-object/from16 v51, v8

    .line 797
    .line 798
    move-object/from16 v52, v81

    .line 799
    .line 800
    move-object/from16 v53, v28

    .line 801
    .line 802
    move-object/from16 v54, v25

    .line 803
    .line 804
    move-object/from16 v55, v7

    .line 805
    .line 806
    move-object/from16 v56, v1

    .line 807
    .line 808
    move-object/from16 v57, v0

    .line 809
    .line 810
    move/from16 v58, v2

    .line 811
    .line 812
    invoke-static/range {v50 .. v58}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->WaitlistStatusDropdownMenu(ZLkotlin/jvm/functions/Function0;LX/AHE;Landroid/view/View;LX/1EL;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 813
    .line 814
    .line 815
    invoke-static {v6, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 816
    .line 817
    .line 818
    invoke-static {v0, v9, v11}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 819
    .line 820
    .line 821
    invoke-static/range {v80 .. v80}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 822
    .line 823
    .line 824
    move-result v1

    .line 825
    if-eqz v1, :cond_17

    .line 826
    .line 827
    const-string v32, "Resetting..."

    .line 828
    .line 829
    :goto_4
    move-object/from16 v1, v27

    .line 830
    .line 831
    invoke-static {v0, v1}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 832
    .line 833
    .line 834
    move-result-object v37

    .line 835
    move-wide/from16 v50, v34

    .line 836
    .line 837
    move-wide/from16 v52, v34

    .line 838
    .line 839
    move-wide/from16 v54, v34

    .line 840
    .line 841
    move-wide/from16 v56, v34

    .line 842
    .line 843
    invoke-static/range {v36 .. v57}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 844
    .line 845
    .line 846
    move-result-object v36

    .line 847
    move-object/from16 v1, v26

    .line 848
    .line 849
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->negativeAccent:J

    .line 850
    .line 851
    move-wide/from16 v16, v1

    .line 852
    .line 853
    invoke-static {v9, v11}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 854
    .line 855
    .line 856
    move-result-object v8

    .line 857
    move-object/from16 v1, v26

    .line 858
    .line 859
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 860
    .line 861
    move-object/from16 v7, v23

    .line 862
    .line 863
    invoke-static {v8, v7, v1, v2}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 864
    .line 865
    .line 866
    move-result-object v2

    .line 867
    move-object/from16 v7, v25

    .line 868
    .line 869
    move-object/from16 v1, v81

    .line 870
    .line 871
    invoke-static {v0, v7, v1}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 872
    .line 873
    .line 874
    move-result v1

    .line 875
    and-int/lit16 v3, v3, 0x1c00

    .line 876
    .line 877
    if-eq v3, v12, :cond_13

    .line 878
    .line 879
    const/16 v29, 0x0

    .line 880
    .line 881
    :cond_13
    move/from16 v7, v29

    .line 882
    .line 883
    move-object/from16 v3, v28

    .line 884
    .line 885
    invoke-static {v0, v3, v1, v7}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 886
    .line 887
    .line 888
    move-result v3

    .line 889
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 890
    .line 891
    .line 892
    move-result-object v1

    .line 893
    if-nez v3, :cond_14

    .line 894
    .line 895
    if-ne v1, v4, :cond_15

    .line 896
    .line 897
    :cond_14
    const-string p1, "Reset failed"

    .line 898
    .line 899
    new-instance v1, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;

    .line 900
    .line 901
    move-object/from16 v78, v1

    .line 902
    .line 903
    move-object/from16 v79, v25

    .line 904
    .line 905
    move-object/from16 p0, v28

    .line 906
    .line 907
    invoke-direct/range {v78 .. v84}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$3$3$1;-><init>(LX/1EL;Landroidx/compose/runtime/MutableState;LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;Ljava/lang/String;)V

    .line 908
    .line 909
    .line 910
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 911
    .line 912
    .line 913
    :cond_15
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 914
    .line 915
    invoke-static {v2, v14, v14, v1, v10}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 916
    .line 917
    .line 918
    move-result-object v2

    .line 919
    move/from16 v1, v22

    .line 920
    .line 921
    invoke-static {v2, v1, v11}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 922
    .line 923
    .line 924
    move-result-object v33

    .line 925
    const/16 v50, 0x3ff0

    .line 926
    .line 927
    move-wide/from16 v34, v16

    .line 928
    .line 929
    move-object/from16 v37, v14

    .line 930
    .line 931
    move/from16 v40, v15

    .line 932
    .line 933
    move/from16 v41, v15

    .line 934
    .line 935
    move/from16 v42, v15

    .line 936
    .line 937
    move/from16 v43, v15

    .line 938
    .line 939
    move-object/from16 v46, v14

    .line 940
    .line 941
    move-object/from16 v47, v0

    .line 942
    .line 943
    move/from16 v49, v15

    .line 944
    .line 945
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 946
    .line 947
    .line 948
    invoke-static {v6, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 949
    .line 950
    .line 951
    :goto_5
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 952
    .line 953
    .line 954
    move-result-object v1

    .line 955
    if-eqz v1, :cond_16

    .line 956
    .line 957
    new-instance v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$4;

    .line 958
    .line 959
    move-object/from16 v70, v0

    .line 960
    .line 961
    move-object/from16 v71, v5

    .line 962
    .line 963
    move-object/from16 v72, v81

    .line 964
    .line 965
    move-object/from16 v73, p2

    .line 966
    .line 967
    move-object/from16 v74, v82

    .line 968
    .line 969
    move-object/from16 v75, v31

    .line 970
    .line 971
    move/from16 v76, v30

    .line 972
    .line 973
    invoke-direct/range {v70 .. v77}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$AuraUserStateOverlay$4;-><init>(Lcom/facebook/aura/user/provider/AuraUserData;LX/AHE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 974
    .line 975
    .line 976
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 977
    .line 978
    :cond_16
    return-void

    .line 979
    :cond_17
    const-string v32, "Reset Hatch Activation"

    .line 980
    .line 981
    goto/16 :goto_4

    .line 982
    .line 983
    :cond_18
    const-string v58, "Set Waitlist Status \u25be"

    .line 984
    .line 985
    goto/16 :goto_3

    .line 986
    .line 987
    :cond_19
    const v7, 0x6792408e

    .line 988
    .line 989
    .line 990
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 991
    .line 992
    .line 993
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->hasHatchAccess:Ljava/lang/Boolean;

    .line 994
    .line 995
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 996
    .line 997
    .line 998
    move-result-object v8

    .line 999
    const-string v7, "hasHatchAccess"

    .line 1000
    .line 1001
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1002
    .line 1003
    .line 1004
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->hasClearedAcquisition:Ljava/lang/Boolean;

    .line 1005
    .line 1006
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 1007
    .line 1008
    .line 1009
    move-result-object v8

    .line 1010
    const-string v7, "hasClearedAcquisition"

    .line 1011
    .line 1012
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1013
    .line 1014
    .line 1015
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->isInviteCodeEntryAvailable:Ljava/lang/Boolean;

    .line 1016
    .line 1017
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v8

    .line 1021
    const-string v7, "isInviteCodeEntryAvailable"

    .line 1022
    .line 1023
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1024
    .line 1025
    .line 1026
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->isWaitlistAvailable:Ljava/lang/Boolean;

    .line 1027
    .line 1028
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 1029
    .line 1030
    .line 1031
    move-result-object v8

    .line 1032
    const-string v7, "isWaitlistAvailable"

    .line 1033
    .line 1034
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1035
    .line 1036
    .line 1037
    iget-object v8, v5, Lcom/facebook/aura/user/provider/AuraUserData;->waitlistStatus:LX/7Kq;

    .line 1038
    .line 1039
    const-string v7, "null"

    .line 1040
    .line 1041
    if-eqz v8, :cond_1b

    .line 1042
    .line 1043
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 1044
    .line 1045
    .line 1046
    move-result-object v12

    .line 1047
    :goto_6
    const-string v8, "waitlistStatus"

    .line 1048
    .line 1049
    invoke-static {v8, v12, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1050
    .line 1051
    .line 1052
    iget-boolean v8, v5, Lcom/facebook/aura/user/provider/AuraUserData;->hasRedeemedInviteCode:Z

    .line 1053
    .line 1054
    invoke-static {v8}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v12

    .line 1058
    const-string v8, "hasRedeemedInviteCode"

    .line 1059
    .line 1060
    invoke-static {v8, v12, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1061
    .line 1062
    .line 1063
    iget-boolean v8, v5, Lcom/facebook/aura/user/provider/AuraUserData;->hasAcceptedTos:Z

    .line 1064
    .line 1065
    invoke-static {v8}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 1066
    .line 1067
    .line 1068
    move-result-object v12

    .line 1069
    const-string v8, "hasAcceptedTos"

    .line 1070
    .line 1071
    invoke-static {v8, v12, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1072
    .line 1073
    .line 1074
    iget-object v8, v5, Lcom/facebook/aura/user/provider/AuraUserData;->ageConfirmationStatus:LX/BDp;

    .line 1075
    .line 1076
    if-eqz v8, :cond_1a

    .line 1077
    .line 1078
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 1079
    .line 1080
    .line 1081
    move-result-object v7

    .line 1082
    :cond_1a
    const-string v8, "ageConfirmationStatus"

    .line 1083
    .line 1084
    invoke-static {v8, v7, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1085
    .line 1086
    .line 1087
    iget-object v8, v5, Lcom/facebook/aura/user/provider/AuraUserData;->ageVerificationMethods:Ljava/util/List;

    .line 1088
    .line 1089
    const-string v7, ", "

    .line 1090
    .line 1091
    invoke-static {v7, v8, v14}, LX/3Rq;->A1A(Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 1092
    .line 1093
    .line 1094
    move-result-object v8

    .line 1095
    const-string v7, "ageVerificationMethods"

    .line 1096
    .line 1097
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1098
    .line 1099
    .line 1100
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->ageVerificationLayout:Lcom/facebook/aura/user/provider/AgeCheckLayout;

    .line 1101
    .line 1102
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v8

    .line 1106
    const-string v7, "ageVerificationLayout"

    .line 1107
    .line 1108
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1109
    .line 1110
    .line 1111
    iget-object v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->isPassGeogating:Ljava/lang/Boolean;

    .line 1112
    .line 1113
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 1114
    .line 1115
    .line 1116
    move-result-object v8

    .line 1117
    const-string v7, "isPassGeogating"

    .line 1118
    .line 1119
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1120
    .line 1121
    .line 1122
    iget-boolean v7, v5, Lcom/facebook/aura/user/provider/AuraUserData;->hasCompletedHatchActivation:Z

    .line 1123
    .line 1124
    invoke-static {v7}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 1125
    .line 1126
    .line 1127
    move-result-object v8

    .line 1128
    const-string v7, "hasCompletedHatchActivation"

    .line 1129
    .line 1130
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1131
    .line 1132
    .line 1133
    invoke-virtual {v5, v15, v15, v15}, Lcom/facebook/aura/user/provider/AuraUserData;->getCurrentActivationState(ZZZ)Lcom/facebook/aura/activation/data/ActivationState;

    .line 1134
    .line 1135
    .line 1136
    move-result-object v7

    .line 1137
    invoke-virtual {v7}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 1138
    .line 1139
    .line 1140
    move-result-object v8

    .line 1141
    const-string v7, "activationState"

    .line 1142
    .line 1143
    invoke-static {v7, v8, v0, v1}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1144
    .line 1145
    .line 1146
    invoke-static {v6, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1147
    .line 1148
    .line 1149
    goto/16 :goto_2

    .line 1150
    .line 1151
    :cond_1b
    move-object v12, v7

    .line 1152
    goto :goto_6
.end method

.method public static final AuraUserStateOverlay$lambda$1(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraUserStateOverlay$lambda$10(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraUserStateOverlay$lambda$11(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraUserStateOverlay$lambda$13(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraUserStateOverlay$lambda$14(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraUserStateOverlay$lambda$2(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraUserStateOverlay$lambda$4(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraUserStateOverlay$lambda$5(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final AuraUserStateOverlay$lambda$7(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AuraUserStateOverlay$lambda$8(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V
    .locals 44

    .line 0
    const v0, -0x75c63587

    .line 1
    .line 2
    .line 3
    move-object/from16 v5, p2

    .line 4
    .line 5
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v4, p3

    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v6, p0

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-static {v5, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int v7, p3, v0

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 23
    .line 24
    move-object/from16 v8, p1

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-static {v5, v8}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    or-int/2addr v7, v0

    .line 33
    :cond_0
    invoke-static {v7}, LX/005;->A1G(I)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    invoke-static {v0, v5, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_3

    .line 42
    .line 43
    sget-object v0, LX/2Id;->A04:LX/2rU;

    .line 44
    .line 45
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 46
    .line 47
    invoke-static {v5, v0}, LX/003;->A0Z(LX/2d4;LX/2rU;)LX/3BI;

    .line 48
    .line 49
    .line 50
    move-result-object v12

    .line 51
    move-object v2, v5

    .line 52
    check-cast v2, LX/J7I;

    .line 53
    .line 54
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 55
    .line 56
    .line 57
    move-result v11

    .line 58
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 59
    .line 60
    .line 61
    move-result-object v10

    .line 62
    invoke-static {v5, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v9

    .line 66
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 67
    .line 68
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 69
    .line 70
    if-nez v0, :cond_2

    .line 71
    .line 72
    invoke-static {}, LX/1VY;->A00()V

    .line 73
    .line 74
    .line 75
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    throw v0

    .line 80
    :cond_1
    move v7, v4

    .line 81
    goto :goto_0

    .line 82
    :cond_2
    invoke-static {v5, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    invoke-static {v5, v12, v10, v9, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 86
    .line 87
    .line 88
    const-string v0, ":"

    .line 89
    .line 90
    invoke-static {v6, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v10

    .line 94
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 95
    .line 96
    const/4 v0, 0x6

    .line 97
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 98
    .line 99
    .line 100
    move-result-object v9

    .line 101
    iget-object v14, v9, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption2Regular:LX/2hg;

    .line 102
    .line 103
    const/16 v18, 0x0

    .line 104
    .line 105
    const/16 v28, 0x3ff6

    .line 106
    .line 107
    const/4 v11, 0x0

    .line 108
    const-wide/16 v12, 0x0

    .line 109
    .line 110
    const/16 v30, 0x0

    .line 111
    .line 112
    move-object v15, v11

    .line 113
    move-object/from16 v16, v11

    .line 114
    .line 115
    move-object/from16 v17, v11

    .line 116
    .line 117
    move/from16 v19, v18

    .line 118
    .line 119
    move/from16 v20, v18

    .line 120
    .line 121
    move/from16 v21, v18

    .line 122
    .line 123
    move-object/from16 v22, v11

    .line 124
    .line 125
    move-object/from16 v23, v11

    .line 126
    .line 127
    move-object/from16 v24, v11

    .line 128
    .line 129
    move-object/from16 v25, v5

    .line 130
    .line 131
    move/from16 v26, v18

    .line 132
    .line 133
    move/from16 v27, v18

    .line 134
    .line 135
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 136
    .line 137
    .line 138
    const/high16 v9, 0x40800000    # 4.0f

    .line 139
    .line 140
    invoke-static {v5, v3, v9}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    iget-object v1, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption2Regular:LX/2hg;

    .line 148
    .line 149
    shr-int/lit8 v0, v7, 0x3

    .line 150
    .line 151
    and-int/lit8 p1, v0, 0xe

    .line 152
    .line 153
    move-object/from16 v29, v8

    .line 154
    .line 155
    move-wide/from16 v31, v12

    .line 156
    .line 157
    move-object/from16 v33, v1

    .line 158
    .line 159
    move-object/from16 v34, v11

    .line 160
    .line 161
    move-object/from16 v35, v11

    .line 162
    .line 163
    move-object/from16 v36, v11

    .line 164
    .line 165
    move/from16 v37, v18

    .line 166
    .line 167
    move/from16 v38, v18

    .line 168
    .line 169
    move/from16 v39, v18

    .line 170
    .line 171
    move/from16 v40, v18

    .line 172
    .line 173
    move-object/from16 v41, v11

    .line 174
    .line 175
    move-object/from16 v42, v11

    .line 176
    .line 177
    move-object/from16 v43, v11

    .line 178
    .line 179
    move-object/from16 p0, v5

    .line 180
    .line 181
    move/from16 p2, v18

    .line 182
    .line 183
    move/from16 p3, v28

    .line 184
    .line 185
    invoke-static/range {v29 .. v47}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 186
    .line 187
    .line 188
    const/4 v0, 0x1

    .line 189
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 190
    .line 191
    .line 192
    goto :goto_1

    .line 193
    :cond_3
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 194
    .line 195
    .line 196
    :goto_1
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    if-eqz v1, :cond_4

    .line 201
    .line 202
    new-instance v0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$StateRow$2;

    .line 203
    .line 204
    invoke-direct {v0, v6, v8, v4}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$StateRow$2;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 205
    .line 206
    .line 207
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 208
    .line 209
    :cond_4
    return-void
.end method

.method public static final WaitlistStatusDropdownMenu(ZLkotlin/jvm/functions/Function0;LX/AHE;Landroid/view/View;LX/1EL;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/AHE;",
            "Landroid/view/View;",
            "LX/1EL;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    move-object/from16 v5, p2

    .line 4
    .line 5
    move-object/from16 v4, p3

    .line 6
    .line 7
    move-object/from16 v3, p4

    .line 8
    .line 9
    invoke-static {v6, v5, v4, v3, v0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 10
    .line 11
    .line 12
    move-object/from16 v2, p5

    .line 13
    .line 14
    move-object/from16 v1, p6

    .line 15
    .line 16
    invoke-static {v2, v1}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const v0, 0x509333bb

    .line 20
    .line 21
    .line 22
    move-object/from16 v13, p7

    .line 23
    .line 24
    invoke-interface {v13, v0}, LX/2d4;->Agl(I)V

    .line 25
    .line 26
    .line 27
    move/from16 v0, p8

    .line 28
    .line 29
    and-int/lit8 v8, p8, 0x6

    .line 30
    .line 31
    move/from16 v7, p0

    .line 32
    .line 33
    if-nez v8, :cond_9

    .line 34
    .line 35
    invoke-static {v13, v7}, LX/004;->A0i(LX/2d4;Z)I

    .line 36
    .line 37
    .line 38
    move-result v10

    .line 39
    or-int v10, v10, p8

    .line 40
    .line 41
    :goto_0
    and-int/lit8 v8, p8, 0x30

    .line 42
    .line 43
    if-nez v8, :cond_0

    .line 44
    .line 45
    invoke-static {v13, v6}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v8

    .line 49
    or-int/2addr v10, v8

    .line 50
    :cond_0
    and-int/lit16 v8, v0, 0x180

    .line 51
    .line 52
    if-nez v8, :cond_1

    .line 53
    .line 54
    invoke-static {v13, v5}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 55
    .line 56
    .line 57
    move-result v8

    .line 58
    or-int/2addr v10, v8

    .line 59
    :cond_1
    and-int/lit16 v8, v0, 0xc00

    .line 60
    .line 61
    if-nez v8, :cond_2

    .line 62
    .line 63
    invoke-static {v13, v4}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 64
    .line 65
    .line 66
    move-result v8

    .line 67
    or-int/2addr v10, v8

    .line 68
    :cond_2
    and-int/lit16 v8, v0, 0x6000

    .line 69
    .line 70
    if-nez v8, :cond_3

    .line 71
    .line 72
    const v8, 0x8000

    .line 73
    .line 74
    .line 75
    invoke-static {v13, v3, v8, v0}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 76
    .line 77
    .line 78
    move-result v8

    .line 79
    invoke-static {v8}, LX/3Rp;->A00(I)I

    .line 80
    .line 81
    .line 82
    move-result v8

    .line 83
    or-int/2addr v10, v8

    .line 84
    :cond_3
    const/high16 v8, 0x30000

    .line 85
    .line 86
    and-int v8, v8, p8

    .line 87
    .line 88
    if-nez v8, :cond_4

    .line 89
    .line 90
    invoke-static {v13, v2}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    or-int/2addr v10, v8

    .line 95
    :cond_4
    const/high16 v8, 0x180000

    .line 96
    .line 97
    and-int v8, v8, p8

    .line 98
    .line 99
    if-nez v8, :cond_5

    .line 100
    .line 101
    invoke-static {v13, v1}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v8

    .line 105
    or-int/2addr v10, v8

    .line 106
    :cond_5
    const v8, 0x92493

    .line 107
    .line 108
    .line 109
    invoke-static {v8, v10}, LX/005;->A1O(II)Z

    .line 110
    .line 111
    .line 112
    move-result v8

    .line 113
    invoke-static {v8, v13, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 114
    .line 115
    .line 116
    move-result v8

    .line 117
    if-eqz v8, :cond_8

    .line 118
    .line 119
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 124
    .line 125
    if-ne v8, v9, :cond_6

    .line 126
    .line 127
    sget-object v12, LX/7Kq;->A06:LX/7Kq;

    .line 128
    .line 129
    sget-object v11, LX/7Kq;->A04:LX/7Kq;

    .line 130
    .line 131
    sget-object v9, LX/7Kq;->A03:LX/7Kq;

    .line 132
    .line 133
    sget-object v8, LX/7Kq;->A02:LX/7Kq;

    .line 134
    .line 135
    filled-new-array {v12, v11, v9, v8}, [LX/7Kq;

    .line 136
    .line 137
    .line 138
    move-result-object v8

    .line 139
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 140
    .line 141
    .line 142
    move-result-object v8

    .line 143
    invoke-interface {v13, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_6
    check-cast v8, Ljava/util/List;

    .line 147
    .line 148
    new-instance v9, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;

    .line 149
    .line 150
    move-object v14, v9

    .line 151
    move-object v15, v8

    .line 152
    move-object/from16 v16, v6

    .line 153
    .line 154
    move-object/from16 v17, v2

    .line 155
    .line 156
    move-object/from16 v18, v3

    .line 157
    .line 158
    move-object/from16 v19, v5

    .line 159
    .line 160
    move-object/from16 p0, v1

    .line 161
    .line 162
    move-object/from16 p1, v4

    .line 163
    .line 164
    invoke-direct/range {v14 .. v21}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$1;-><init>(Ljava/util/List;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/1EL;LX/AHE;Lkotlin/jvm/functions/Function0;Landroid/view/View;)V

    .line 165
    .line 166
    .line 167
    const v8, -0x3618578a

    .line 168
    .line 169
    .line 170
    invoke-static {v13, v9, v8}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 171
    .line 172
    .line 173
    move-result-object v18

    .line 174
    and-int/lit8 p1, v10, 0x7e

    .line 175
    .line 176
    const/16 p2, 0x30

    .line 177
    .line 178
    const/16 p3, 0x7fc

    .line 179
    .line 180
    const/4 v11, 0x0

    .line 181
    const-wide/16 p4, 0x0

    .line 182
    .line 183
    const/16 v19, 0x0

    .line 184
    .line 185
    move-object v12, v11

    .line 186
    move-object v14, v11

    .line 187
    move-object v15, v11

    .line 188
    move-object/from16 v16, v11

    .line 189
    .line 190
    move/from16 p0, v19

    .line 191
    .line 192
    move-wide/from16 p6, p4

    .line 193
    .line 194
    move/from16 p8, v7

    .line 195
    .line 196
    move-object/from16 v17, v6

    .line 197
    .line 198
    invoke-static/range {v11 .. v28}, LX/2qx;->A00(LX/1Ou;LX/3Lr;LX/2d4;LX/3C1;LX/2bW;LX/1AV;Lkotlin/jvm/functions/Function0;LX/JDQ;FFIIIJJZ)V

    .line 199
    .line 200
    .line 201
    :goto_1
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 202
    .line 203
    .line 204
    move-result-object v9

    .line 205
    if-eqz v9, :cond_7

    .line 206
    .line 207
    new-instance v8, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;

    .line 208
    .line 209
    move-object v10, v8

    .line 210
    move v11, v7

    .line 211
    move-object v12, v6

    .line 212
    move-object v13, v5

    .line 213
    move-object v14, v4

    .line 214
    move-object v15, v3

    .line 215
    move-object/from16 v16, v2

    .line 216
    .line 217
    move-object/from16 v17, v1

    .line 218
    .line 219
    move/from16 v18, v0

    .line 220
    .line 221
    invoke-direct/range {v10 .. v18}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;-><init>(ZLkotlin/jvm/functions/Function0;LX/AHE;Landroid/view/View;LX/1EL;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 222
    .line 223
    .line 224
    iput-object v8, v9, LX/J7V;->A06:LX/JDN;

    .line 225
    .line 226
    :cond_7
    return-void

    .line 227
    :cond_8
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 228
    .line 229
    .line 230
    goto :goto_1

    .line 231
    :cond_9
    move v10, v0

    .line 232
    goto/16 :goto_0
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$1(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$10(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$11(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$13(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$14(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$2(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$4(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$5(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AuraUserStateOverlay$lambda$8(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->StateRow(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
