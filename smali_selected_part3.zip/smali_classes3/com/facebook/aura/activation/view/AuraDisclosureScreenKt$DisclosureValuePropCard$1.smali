.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $sections:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/data/HatchDisclosureSection;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;->$sections:Ljava/util/List;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 14

    .line 268435456
    move/from16 v1, p3

    .line 268435457
    .line 268435458
    and-int/lit8 v0, p3, 0x11

    .line 268435459
    .line 268435460
    const/16 p1, 0x10

    .line 268435461
    .line 268435462
    const/4 v3, 0x1

    .line 268435463
    const/4 v12, 0x0

    .line 268435464
    invoke-static {v0, p1}, LX/003;->A1H(II)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    move-object/from16 v13, p2

    .line 268435469
    .line 268435470
    invoke-static {v0, v13, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v0

    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1;->$sections:Ljava/util/List;

    .line 268435477
    .line 268435478
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 268435479
    .line 268435480
    .line 268435481
    move-result-object v7

    .line 268435482
    const/4 v1, 0x0

    .line 268435483
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 268435484
    .line 268435485
    .line 268435486
    move-result v0

    .line 268435487
    if-eqz v0, :cond_4

    .line 268435488
    .line 268435489
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268435490
    .line 268435491
    .line 268435492
    move-result-object v5

    .line 268435493
    add-int/lit8 v6, v1, 0x1

    .line 268435494
    .line 268435495
    if-gez v1, :cond_0

    .line 268435496
    .line 268435497
    invoke-static {}, LX/B8B;->A1A()V

    .line 268435498
    .line 268435499
    .line 268435500
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435501
    .line 268435502
    .line 268435503
    move-result-object v0

    .line 268435504
    throw v0

    .line 268435505
    :cond_0
    check-cast v5, Lcom/facebook/aura/activation/data/HatchDisclosureSection;

    .line 268435506
    .line 268435507
    if-lez v1, :cond_2

    .line 268435508
    .line 268435509
    const v0, -0x43da96a8

    .line 268435510
    .line 268435511
    .line 268435512
    invoke-static {v13, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 268435513
    .line 268435514
    .line 268435515
    move-result-object v4

    .line 268435516
    invoke-static {v13}, LX/007;->A0i(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 268435517
    .line 268435518
    .line 268435519
    move-result-object v0

    .line 268435520
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->icon:Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;

    .line 268435521
    .line 268435522
    iget v2, v0, Lcom/facebook/aura/vds/compose/theme/AuraDimensionsIcon;->xSmall:F

    .line 268435523
    .line 268435524
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 268435525
    .line 268435526
    add-float/2addr v2, v1

    .line 268435527
    const/4 v0, 0x0

    .line 268435528
    invoke-static {v4, v2, v1, v0, v1}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 268435529
    .line 268435530
    .line 268435531
    move-result-object v0

    .line 268435532
    invoke-static {v0, v13, v12, v12}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 268435533
    .line 268435534
    .line 268435535
    :goto_1
    invoke-static {v13}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435536
    .line 268435537
    .line 268435538
    iget-object v0, v5, Lcom/facebook/aura/activation/data/HatchDisclosureSection;->icon:Ljava/lang/String;

    .line 268435539
    .line 268435540
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->disclosureSectionIconRes(Ljava/lang/String;)Ljava/lang/Integer;

    .line 268435541
    .line 268435542
    .line 268435543
    move-result-object v8

    .line 268435544
    iget-object v9, v5, Lcom/facebook/aura/activation/data/HatchDisclosureSection;->title:Ljava/lang/String;

    .line 268435545
    .line 268435546
    iget-object v10, v5, Lcom/facebook/aura/activation/data/HatchDisclosureSection;->description:Ljava/lang/String;

    .line 268435547
    .line 268435548
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 268435549
    .line 268435550
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435551
    .line 268435552
    .line 268435553
    move-result-object v1

    .line 268435554
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435555
    .line 268435556
    if-ne v1, v0, :cond_1

    .line 268435557
    .line 268435558
    sget-object v1, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$DisclosureValuePropCard$1$1$1$1;

    .line 268435559
    .line 268435560
    invoke-interface {v13, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435561
    .line 268435562
    .line 268435563
    :cond_1
    invoke-static {v2, v1, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 268435564
    .line 268435565
    .line 268435566
    move-result-object v11

    .line 268435567
    move p0, v12

    .line 268435568
    invoke-static/range {v8 .. v15}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt;->DisclosureValuePropRow(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 268435569
    .line 268435570
    .line 268435571
    move v1, v6

    .line 268435572
    goto :goto_0

    .line 268435573
    :cond_2
    const v0, -0x43d6740e

    .line 268435574
    .line 268435575
    .line 268435576
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 268435577
    .line 268435578
    .line 268435579
    goto :goto_1

    .line 268435580
    :cond_3
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 268435581
    .line 268435582
    .line 268435583
    :cond_4
    return-void
.end method
