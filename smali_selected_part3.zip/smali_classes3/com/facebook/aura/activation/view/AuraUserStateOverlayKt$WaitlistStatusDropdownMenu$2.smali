.class public final Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $expanded:Z

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStatusChangeStarted:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $parentView:Landroid/view/View;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(ZLkotlin/jvm/functions/Function0;LX/AHE;Landroid/view/View;LX/1EL;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/AHE;",
            "Landroid/view/View;",
            "LX/1EL;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;I)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$expanded:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$userSession:LX/AHE;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$parentView:Landroid/view/View;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$coroutineScope:LX/1EL;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$$changed:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 268435456
    iget-boolean v1, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$expanded:Z

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$userSession:LX/AHE;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$parentView:Landroid/view/View;

    .line 268435463
    .line 268435464
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$coroutineScope:LX/1EL;

    .line 268435465
    .line 268435466
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onStatusChangeStarted:Lkotlin/jvm/functions/Function0;

    .line 268435467
    .line 268435468
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$onStatusChangeFinished:Lkotlin/jvm/functions/Function0;

    .line 268435469
    .line 268435470
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt$WaitlistStatusDropdownMenu$2;->$$changed:I

    .line 268435471
    .line 268435472
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435473
    .line 268435474
    .line 268435475
    move-result p0

    .line 268435476
    move-object v8, p1

    .line 268435477
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/activation/view/AuraUserStateOverlayKt;->WaitlistStatusDropdownMenu(ZLkotlin/jvm/functions/Function0;LX/AHE;Landroid/view/View;LX/1EL;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 268435478
    .line 268435479
    .line 268435480
    return-void
.end method
