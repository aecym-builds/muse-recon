.class public final Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2RG;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

.field public final synthetic $ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;",
            "Lkotlin/jvm/functions/Function0<",
            "LX/2sT;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2sT;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2RG;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->invoke(LX/2RG;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2RG;)V
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->confettiElapsedMs:LX/Dvf;

    .line 7
    .line 8
    invoke-static {v0}, LX/603;->A00(LX/Dvf;)F

    .line 9
    .line 10
    .line 11
    move-result v4

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$celebrationState:Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;

    .line 13
    .line 14
    iget-object v0, v0, Lcom/facebook/aura/activation/view/AuraWaitlistCelebrationState;->density:Lcom/facebook/aura/activation/view/AuraConfettiDensity;

    .line 15
    .line 16
    invoke-static {v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->getBurst(Lcom/facebook/aura/activation/view/AuraConfettiDensity;)Lcom/facebook/aura/activation/view/ConfettiBurst;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    const/4 v0, 0x0

    .line 21
    cmpl-float v0, v4, v0

    .line 22
    .line 23
    if-ltz v0, :cond_0

    .line 24
    .line 25
    iget v0, v3, Lcom/facebook/aura/activation/view/ConfettiBurst;->durationMs:I

    .line 26
    .line 27
    int-to-float v0, v0

    .line 28
    cmpg-float v0, v4, v0

    .line 29
    .line 30
    const/4 v2, 0x1

    .line 31
    if-ltz v0, :cond_1

    .line 32
    .line 33
    :cond_0
    const/4 v2, 0x0

    .line 34
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$surfaceBoundsInRoot$delegate:Landroidx/compose/runtime/MutableState;

    .line 35
    .line 36
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    check-cast v1, LX/2sT;

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt$auraWaitlistConfetti$2$1;->$ctaBoundsInRoot:Lkotlin/jvm/functions/Function0;

    .line 43
    .line 44
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, LX/2sT;

    .line 49
    .line 50
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->localSuccessFrame(LX/2sT;LX/2sT;)LX/36Z;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    if-eqz v2, :cond_2

    .line 55
    .line 56
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiDepth;->BACKGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 57
    .line 58
    invoke-static {p1, v3, v0, v4, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->drawConfettiLayer(LX/2la;Lcom/facebook/aura/activation/view/ConfettiBurst;Lcom/facebook/aura/activation/view/ConfettiDepth;FLX/36Z;)V

    .line 59
    .line 60
    .line 61
    :cond_2
    invoke-interface {p1}, LX/2RG;->A9T()V

    .line 62
    .line 63
    .line 64
    if-eqz v2, :cond_3

    .line 65
    .line 66
    sget-object v0, Lcom/facebook/aura/activation/view/ConfettiDepth;->FOREGROUND:Lcom/facebook/aura/activation/view/ConfettiDepth;

    .line 67
    .line 68
    invoke-static {p1, v3, v0, v4, v1}, Lcom/facebook/aura/activation/view/AuraWaitlistConfettiKt;->drawConfettiLayer(LX/2la;Lcom/facebook/aura/activation/view/ConfettiBurst;Lcom/facebook/aura/activation/view/ConfettiDepth;FLX/36Z;)V

    .line 69
    .line 70
    .line 71
    :cond_3
    return-void
.end method
