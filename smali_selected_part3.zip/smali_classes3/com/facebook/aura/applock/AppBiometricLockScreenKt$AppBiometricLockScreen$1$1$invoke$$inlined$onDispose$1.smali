.class public final Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$1$1$invoke$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CdD;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 1

    .line 0
    const-string p0, "AppBiometricLockScreen"

    .line 1
    .line 2
    const-string v0, "AppBiometricLockScreen left composition"

    .line 3
    .line 4
    invoke-static {p0, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
