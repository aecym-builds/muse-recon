.class public interface abstract Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;
.super Ljava/lang/Object;
.source ""
