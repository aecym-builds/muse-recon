.class public abstract Lcom/facebook/aura/applock/AppBiometricLockScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "AppBiometricLockScreen"


# direct methods
.method public static final AppBiometricLockRetryScreen(ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 51
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v1, 0x2c246751

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p3

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v7, p4

    .line 9
    .line 10
    and-int/lit8 v1, p4, 0x6

    .line 11
    .line 12
    move/from16 p4, p0

    .line 13
    .line 14
    if-nez v1, :cond_2

    .line 15
    .line 16
    move/from16 v1, p4

    .line 17
    .line 18
    invoke-static {v0, v1}, LX/004;->A0E(LX/2d4;I)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    or-int/2addr v1, v7

    .line 23
    :goto_0
    and-int/lit8 v2, v7, 0x30

    .line 24
    .line 25
    move-object/from16 p3, p1

    .line 26
    .line 27
    if-nez v2, :cond_0

    .line 28
    .line 29
    move-object/from16 v2, p3

    .line 30
    .line 31
    invoke-static {v0, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    or-int/2addr v1, v2

    .line 36
    :cond_0
    and-int/lit16 v2, v7, 0x180

    .line 37
    .line 38
    if-nez v2, :cond_1

    .line 39
    .line 40
    move-object/from16 v2, p2

    .line 41
    .line 42
    invoke-static {v0, v2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    or-int/2addr v1, v2

    .line 47
    :cond_1
    and-int/lit16 v3, v1, 0x93

    .line 48
    .line 49
    const/16 v2, 0x92

    .line 50
    .line 51
    const/4 v4, 0x1

    .line 52
    const/16 v20, 0x0

    .line 53
    .line 54
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-eqz v2, :cond_3

    .line 63
    .line 64
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 65
    .line 66
    const/16 v19, 0x0

    .line 67
    .line 68
    sget-object v5, LX/2sI;->A01:LX/2wD;

    .line 69
    .line 70
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 71
    .line 72
    const/16 v18, 0x6

    .line 73
    .line 74
    invoke-static {v0, v5, v6}, LX/07H;->A0D(LX/2d4;LX/3C1;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/3C1;

    .line 75
    .line 76
    .line 77
    move-result-object v12

    .line 78
    invoke-static/range {v20 .. v20}, LX/001;->A0g(Z)LX/3BI;

    .line 79
    .line 80
    .line 81
    move-result-object v11

    .line 82
    move-object v3, v0

    .line 83
    check-cast v3, LX/J7I;

    .line 84
    .line 85
    iget-wide v8, v3, LX/J7I;->A06:J

    .line 86
    .line 87
    invoke-static {v8, v9}, LX/001;->A0A(J)I

    .line 88
    .line 89
    .line 90
    move-result v15

    .line 91
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 92
    .line 93
    .line 94
    move-result-object v10

    .line 95
    invoke-static {v0, v12}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 96
    .line 97
    .line 98
    move-result-object v9

    .line 99
    sget-object v14, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 100
    .line 101
    iget-object v8, v3, LX/J7I;->A0V:LX/3DJ;

    .line 102
    .line 103
    if-nez v8, :cond_4

    .line 104
    .line 105
    invoke-static {}, LX/1VY;->A00()V

    .line 106
    .line 107
    .line 108
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0

    .line 113
    :cond_2
    move v1, v7

    .line 114
    goto :goto_0

    .line 115
    :cond_3
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 116
    .line 117
    .line 118
    goto/16 :goto_1

    .line 119
    .line 120
    :cond_4
    invoke-static {v0, v3, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 121
    .line 122
    .line 123
    sget-object v13, LX/3Cl;->A04:LX/JDN;

    .line 124
    .line 125
    invoke-static {v0, v11, v13}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 126
    .line 127
    .line 128
    move-result-object v12

    .line 129
    invoke-static {v0, v10, v12, v15}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 130
    .line 131
    .line 132
    move-result-object v17

    .line 133
    sget-object v11, LX/3Cl;->A02:LX/JDM;

    .line 134
    .line 135
    invoke-static {v0, v9, v11}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 136
    .line 137
    .line 138
    move-result-object v10

    .line 139
    invoke-static {v5}, LX/6jg;->A02(LX/3C1;)LX/3C1;

    .line 140
    .line 141
    .line 142
    move-result-object v5

    .line 143
    invoke-static {v5}, LX/6jg;->A01(LX/3C1;)LX/3C1;

    .line 144
    .line 145
    .line 146
    move-result-object v8

    .line 147
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 148
    .line 149
    invoke-static {v8, v5}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    sget-object v8, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 154
    .line 155
    const/16 v16, 0x30

    .line 156
    .line 157
    move/from16 v5, v16

    .line 158
    .line 159
    invoke-static {v9, v8, v0, v5}, Lcom/facebook/aura/ui/adaptive/AuraContentFrameKt;->auraContentWidth(LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;LX/2d4;I)LX/3C1;

    .line 160
    .line 161
    .line 162
    move-result-object v8

    .line 163
    invoke-static {v0}, LX/008;->A0k(LX/2d4;)LX/3BI;

    .line 164
    .line 165
    .line 166
    move-result-object v15

    .line 167
    invoke-static {v3}, LX/002;->A0J(LX/J7I;)I

    .line 168
    .line 169
    .line 170
    move-result v9

    .line 171
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 172
    .line 173
    .line 174
    move-result-object v5

    .line 175
    invoke-static {v0, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 176
    .line 177
    .line 178
    move-result-object v8

    .line 179
    invoke-static {v0, v3, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 180
    .line 181
    .line 182
    invoke-static {v0, v15, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 183
    .line 184
    .line 185
    invoke-static {v0, v5, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 186
    .line 187
    .line 188
    move-object/from16 v5, v17

    .line 189
    .line 190
    invoke-static {v11, v5, v0, v9}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 191
    .line 192
    .line 193
    invoke-static {v0, v8, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 194
    .line 195
    .line 196
    new-instance v8, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;

    .line 197
    .line 198
    move/from16 v5, p4

    .line 199
    .line 200
    invoke-direct {v8, v5}, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;-><init>(I)V

    .line 201
    .line 202
    .line 203
    const/high16 v5, 0x42a00000    # 80.0f

    .line 204
    .line 205
    invoke-static {v2, v5}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 206
    .line 207
    .line 208
    move-result-object v22

    .line 209
    const/16 v32, 0x1fc

    .line 210
    .line 211
    move-object/from16 v21, v8

    .line 212
    .line 213
    move-object/from16 v23, v19

    .line 214
    .line 215
    move-object/from16 v24, v19

    .line 216
    .line 217
    move/from16 v25, v20

    .line 218
    .line 219
    move/from16 v26, v20

    .line 220
    .line 221
    move-object/from16 v27, v19

    .line 222
    .line 223
    move/from16 v28, v20

    .line 224
    .line 225
    move-object/from16 v29, v19

    .line 226
    .line 227
    move-object/from16 v30, v0

    .line 228
    .line 229
    move/from16 v31, v16

    .line 230
    .line 231
    invoke-static/range {v21 .. v32}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage(Lcom/facebook/aura/vds/compose/common/AuraDrawableSource;LX/3C1;Ljava/lang/String;LX/HVa;ZZLcom/facebook/common/callercontext/ContextChain;ZLX/HWR;LX/2d4;II)V

    .line 232
    .line 233
    .line 234
    const/high16 v5, 0x41c00000    # 24.0f

    .line 235
    .line 236
    invoke-static {v0, v2, v5}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 237
    .line 238
    .line 239
    const v8, 0x7f1201bd

    .line 240
    .line 241
    .line 242
    invoke-static {v0, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v21

    .line 246
    move/from16 v8, v18

    .line 247
    .line 248
    invoke-virtual {v6, v0, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 249
    .line 250
    .line 251
    move-result-object v8

    .line 252
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 253
    .line 254
    invoke-static {v0, v6}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 255
    .line 256
    .line 257
    move-result-wide v23

    .line 258
    const/16 v39, 0x3ff2

    .line 259
    .line 260
    move-object/from16 v22, v19

    .line 261
    .line 262
    move-object/from16 v25, v8

    .line 263
    .line 264
    move-object/from16 v26, v19

    .line 265
    .line 266
    move-object/from16 v28, v19

    .line 267
    .line 268
    move/from16 v29, v20

    .line 269
    .line 270
    move/from16 v30, v20

    .line 271
    .line 272
    move/from16 v31, v20

    .line 273
    .line 274
    move/from16 v32, v20

    .line 275
    .line 276
    move-object/from16 v33, v19

    .line 277
    .line 278
    move-object/from16 v34, v19

    .line 279
    .line 280
    move-object/from16 v35, v19

    .line 281
    .line 282
    move-object/from16 v36, v0

    .line 283
    .line 284
    move/from16 v37, v20

    .line 285
    .line 286
    move/from16 v38, v20

    .line 287
    .line 288
    invoke-static/range {v21 .. v39}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 289
    .line 290
    .line 291
    const/high16 v8, 0x41000000    # 8.0f

    .line 292
    .line 293
    invoke-static {v0, v2, v8}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 294
    .line 295
    .line 296
    const v8, 0x7f1201bb

    .line 297
    .line 298
    .line 299
    invoke-static {v0, v8}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v21

    .line 303
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v9

    .line 307
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 308
    .line 309
    if-ne v9, v8, :cond_5

    .line 310
    .line 311
    sget-object v9, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockRetryScreen$1$1$1$1;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockRetryScreen$1$1$1$1;

    .line 312
    .line 313
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    :cond_5
    move/from16 v8, v20

    .line 317
    .line 318
    invoke-static {v2, v9, v8}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 319
    .line 320
    .line 321
    move-result-object v22

    .line 322
    invoke-static {v0, v6}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 323
    .line 324
    .line 325
    move-result-object v25

    .line 326
    invoke-static {v0, v6}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 327
    .line 328
    .line 329
    move-result-wide v23

    .line 330
    const/16 v39, 0x3ff0

    .line 331
    .line 332
    invoke-static/range {v21 .. v39}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 333
    .line 334
    .line 335
    invoke-static {v0, v2, v5}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 336
    .line 337
    .line 338
    const v5, 0x7f1201bf

    .line 339
    .line 340
    .line 341
    invoke-static {v0, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v22

    .line 345
    sget-object v5, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 346
    .line 347
    move-object/from16 v8, v19

    .line 348
    .line 349
    move/from16 v6, v16

    .line 350
    .line 351
    invoke-virtual {v5, v8, v0, v6, v4}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primaryAlt(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 352
    .line 353
    .line 354
    move-result-object v25

    .line 355
    sget-object v26, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->LARGE:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 356
    .line 357
    sget-object v24, LX/2sI;->A02:LX/2wD;

    .line 358
    .line 359
    shl-int/lit8 v50, v1, 0x9

    .line 360
    .line 361
    const v8, 0xe000

    .line 362
    .line 363
    .line 364
    and-int v50, v50, v8

    .line 365
    .line 366
    const p1, 0x7ffbfc5

    .line 367
    .line 368
    .line 369
    const v49, 0x30c00

    .line 370
    .line 371
    .line 372
    move-object/from16 v21, v19

    .line 373
    .line 374
    move-object/from16 v23, v19

    .line 375
    .line 376
    move/from16 v28, v20

    .line 377
    .line 378
    move-object/from16 v35, p3

    .line 379
    .line 380
    move-object/from16 v36, v19

    .line 381
    .line 382
    move-object/from16 v37, v19

    .line 383
    .line 384
    move-object/from16 v38, v19

    .line 385
    .line 386
    move-object/from16 v39, v19

    .line 387
    .line 388
    move-object/from16 v40, v19

    .line 389
    .line 390
    move-object/from16 v41, v19

    .line 391
    .line 392
    move-object/from16 v42, v19

    .line 393
    .line 394
    move-object/from16 v43, v19

    .line 395
    .line 396
    move/from16 v44, v20

    .line 397
    .line 398
    move/from16 v45, v20

    .line 399
    .line 400
    move/from16 v46, v20

    .line 401
    .line 402
    move/from16 v47, v20

    .line 403
    .line 404
    move-object/from16 v48, v0

    .line 405
    .line 406
    move/from16 p0, v20

    .line 407
    .line 408
    invoke-static/range {v21 .. v52}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 409
    .line 410
    .line 411
    const/high16 v6, 0x41400000    # 12.0f

    .line 412
    .line 413
    invoke-static {v0, v2, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 414
    .line 415
    .line 416
    const v2, 0x7f12081b

    .line 417
    .line 418
    .line 419
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v22

    .line 423
    move-object/from16 v6, v19

    .line 424
    .line 425
    move/from16 v2, v16

    .line 426
    .line 427
    invoke-virtual {v5, v6, v0, v2, v4}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 428
    .line 429
    .line 430
    move-result-object v25

    .line 431
    shl-int/lit8 v50, v1, 0x6

    .line 432
    .line 433
    and-int v50, v50, v8

    .line 434
    .line 435
    move-object/from16 v35, p2

    .line 436
    .line 437
    invoke-static/range {v21 .. v52}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 438
    .line 439
    .line 440
    invoke-static {v3, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 441
    .line 442
    .line 443
    invoke-static {v3, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 444
    .line 445
    .line 446
    :goto_1
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 447
    .line 448
    .line 449
    move-result-object v4

    .line 450
    if-eqz v4, :cond_6

    .line 451
    .line 452
    new-instance v3, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockRetryScreen$2;

    .line 453
    .line 454
    move/from16 v2, p4

    .line 455
    .line 456
    move-object/from16 v1, p3

    .line 457
    .line 458
    move-object/from16 v0, p2

    .line 459
    .line 460
    invoke-direct {v3, v2, v1, v0, v7}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockRetryScreen$2;-><init>(ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 461
    .line 462
    .line 463
    iput-object v3, v4, LX/J7V;->A06:LX/JDN;

    .line 464
    .line 465
    :cond_6
    return-void
.end method

.method public static final AppBiometricLockScreen(LX/2d4;I)V
    .locals 18

    .line 0
    const v0, 0x786a79da

    .line 1
    .line 2
    .line 3
    move-object/from16 v14, p0

    .line 4
    .line 5
    invoke-interface {v14, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    const/4 v8, 0x1

    .line 9
    const/4 v6, 0x0

    .line 10
    move/from16 v3, p1

    .line 11
    .line 12
    invoke-static {v3}, LX/003;->A1B(I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {v0, v14, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_14

    .line 21
    .line 22
    invoke-static {v14}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-static {v14}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    invoke-static {v14}, LX/603;->A05(LX/2d4;)J

    .line 31
    .line 32
    .line 33
    move-result-wide v0

    .line 34
    invoke-static {v2}, LX/602;->A02(Landroid/content/Context;)Landroid/content/Context;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    new-instance v9, Lcom/facebook/aura/applock/AppBiometricLockViewModel$Factory;

    .line 39
    .line 40
    invoke-direct {v9, v5, v4}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$Factory;-><init>(LX/AHE;Landroid/content/Context;)V

    .line 41
    .line 42
    .line 43
    const-class v7, Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 44
    .line 45
    invoke-static {v7, v0, v1}, Lcom/facebook/aura/session/LocalUserSessionKt;->activityViewModelKey(Ljava/lang/Class;J)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    sget-object v4, LX/3J2;->A00:LX/Ip3;

    .line 50
    .line 51
    invoke-interface {v14, v4}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-string v0, "null cannot be cast to non-null type androidx.activity.ComponentActivity"

    .line 56
    .line 57
    invoke-static {v1, v0}, LX/I1c;->A0g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    check-cast v1, Landroidx/activity/ComponentActivity;

    .line 61
    .line 62
    invoke-static {v1}, LX/004;->A14(LX/15O;)LX/13i;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-static {v9, v1, v0, v7, v5}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 67
    .line 68
    .line 69
    move-result-object v5

    .line 70
    check-cast v5, Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 71
    .line 72
    iget-object v0, v5, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->uiState:LX/2J3;

    .line 73
    .line 74
    const/4 v15, 0x0

    .line 75
    invoke-static {v14, v0, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 76
    .line 77
    .line 78
    move-result-object v13

    .line 79
    invoke-interface {v14, v4}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v10

    .line 83
    const-string v0, "null cannot be cast to non-null type androidx.fragment.app.FragmentActivity"

    .line 84
    .line 85
    invoke-static {v10, v0}, LX/I1c;->A0g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    check-cast v10, Landroidx/fragment/app/FragmentActivity;

    .line 89
    .line 90
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v9

    .line 94
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 95
    .line 96
    if-ne v9, v4, :cond_0

    .line 97
    .line 98
    invoke-virtual {v2}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    invoke-interface {v14, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    :cond_0
    check-cast v9, Ljava/util/concurrent/Executor;

    .line 106
    .line 107
    invoke-static {v9}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    const v0, 0x7f1201ba

    .line 111
    .line 112
    .line 113
    invoke-static {v14, v0}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v12

    .line 117
    const v0, 0x7f1201b9

    .line 118
    .line 119
    .line 120
    invoke-static {v14, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v11

    .line 124
    const v0, 0x7f120809

    .line 125
    .line 126
    .line 127
    invoke-static {v14, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    invoke-static {v14, v12, v11, v1}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    if-nez v0, :cond_1

    .line 140
    .line 141
    if-ne v7, v4, :cond_2

    .line 142
    .line 143
    :cond_1
    invoke-static {v12, v11, v1}, Lcom/facebook/aura/applock/AppLockBiometricSettingsKt;->createAppLockPromptInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LX/0sI;

    .line 144
    .line 145
    .line 146
    move-result-object v7

    .line 147
    invoke-interface {v14, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_2
    check-cast v7, LX/0sI;

    .line 151
    .line 152
    invoke-interface {v14, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    invoke-static {v14, v10, v9, v7, v0}, LX/603;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    if-nez v0, :cond_3

    .line 165
    .line 166
    if-ne v1, v4, :cond_4

    .line 167
    .line 168
    :cond_3
    new-instance v1, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;

    .line 169
    .line 170
    invoke-direct {v1, v5, v10, v9, v7}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;Landroidx/fragment/app/FragmentActivity;Ljava/util/concurrent/Executor;LX/0sI;)V

    .line 171
    .line 172
    .line 173
    invoke-interface {v14, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    :cond_4
    check-cast v1, LX/JDM;

    .line 177
    .line 178
    sget-object v9, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 179
    .line 180
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    if-ne v0, v4, :cond_5

    .line 185
    .line 186
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$1$1;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$1$1;

    .line 187
    .line 188
    invoke-interface {v14, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 189
    .line 190
    .line 191
    :cond_5
    invoke-static {v14, v0, v9}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    invoke-static {v14, v5, v1}, LX/004;->A1U(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v7

    .line 198
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    if-nez v7, :cond_6

    .line 203
    .line 204
    if-ne v0, v4, :cond_7

    .line 205
    .line 206
    :cond_6
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;

    .line 207
    .line 208
    invoke-direct {v0, v5, v1}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;LX/JDM;)V

    .line 209
    .line 210
    .line 211
    invoke-interface {v14, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_7
    check-cast v0, LX/JDM;

    .line 215
    .line 216
    const/16 p0, 0x6

    .line 217
    .line 218
    const/16 p1, 0x2

    .line 219
    .line 220
    move-object/from16 v17, v0

    .line 221
    .line 222
    move-object/from16 v16, v9

    .line 223
    .line 224
    invoke-static/range {v14 .. v19}, LX/CcX;->A05(LX/2d4;LX/07p;Ljava/lang/Object;LX/JDM;II)V

    .line 225
    .line 226
    .line 227
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    if-ne v0, v4, :cond_8

    .line 232
    .line 233
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$3$1;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$3$1;

    .line 234
    .line 235
    invoke-interface {v14, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    :cond_8
    invoke-static {v14, v0, v8, v6}, LX/602;->A1A(LX/2d4;Ljava/lang/Object;IZ)V

    .line 239
    .line 240
    .line 241
    const v10, 0x7f0801e0

    .line 242
    .line 243
    .line 244
    invoke-interface {v13}, LX/16A;->getValue()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v11

    .line 248
    check-cast v11, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 249
    .line 250
    instance-of v0, v11, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 251
    .line 252
    if-eqz v0, :cond_e

    .line 253
    .line 254
    const v0, 0x7b46e60

    .line 255
    .line 256
    .line 257
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 258
    .line 259
    .line 260
    check-cast v11, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 261
    .line 262
    invoke-interface {v14, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result v0

    .line 266
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v12

    .line 270
    if-nez v0, :cond_9

    .line 271
    .line 272
    if-ne v12, v4, :cond_a

    .line 273
    .line 274
    :cond_9
    new-instance v12, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$4$1;

    .line 275
    .line 276
    invoke-direct {v12, v2}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$4$1;-><init>(Landroid/content/Context;)V

    .line 277
    .line 278
    .line 279
    invoke-interface {v14, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 280
    .line 281
    .line 282
    :cond_a
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 283
    .line 284
    invoke-interface {v14, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v0

    .line 288
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v13

    .line 292
    if-nez v0, :cond_b

    .line 293
    .line 294
    if-ne v13, v4, :cond_c

    .line 295
    .line 296
    :cond_b
    new-instance v13, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$5$1;

    .line 297
    .line 298
    invoke-direct {v13, v5}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$5$1;-><init>(Ljava/lang/Object;)V

    .line 299
    .line 300
    .line 301
    invoke-interface {v14, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 302
    .line 303
    .line 304
    :cond_c
    check-cast v13, LX/DqV;

    .line 305
    .line 306
    check-cast v13, Lkotlin/jvm/functions/Function0;

    .line 307
    .line 308
    sget v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;->$stable:I

    .line 309
    .line 310
    shl-int/lit8 v15, v0, 0x3

    .line 311
    .line 312
    invoke-static/range {v10 .. v15}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockUnavailableScreen(ILcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 313
    .line 314
    .line 315
    :goto_0
    invoke-static {v14}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    :goto_1
    invoke-interface {v14}, LX/2d4;->AAg()LX/J7V;

    .line 319
    .line 320
    .line 321
    move-result-object v1

    .line 322
    if-eqz v1, :cond_d

    .line 323
    .line 324
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;

    .line 325
    .line 326
    invoke-direct {v0, v3}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;-><init>(I)V

    .line 327
    .line 328
    .line 329
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 330
    .line 331
    :cond_d
    return-void

    .line 332
    :cond_e
    instance-of v0, v11, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;

    .line 333
    .line 334
    if-eqz v0, :cond_13

    .line 335
    .line 336
    const v0, 0x7b4923e

    .line 337
    .line 338
    .line 339
    invoke-static {v1, v14, v0}, LX/002;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 340
    .line 341
    .line 342
    move-result v0

    .line 343
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v2

    .line 347
    if-nez v0, :cond_f

    .line 348
    .line 349
    if-ne v2, v4, :cond_10

    .line 350
    .line 351
    :cond_f
    new-instance v2, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$6$1;

    .line 352
    .line 353
    invoke-direct {v2, v1}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$6$1;-><init>(LX/JDM;)V

    .line 354
    .line 355
    .line 356
    invoke-interface {v14, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 357
    .line 358
    .line 359
    :cond_10
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 360
    .line 361
    invoke-interface {v14, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 362
    .line 363
    .line 364
    move-result v1

    .line 365
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    if-nez v1, :cond_11

    .line 370
    .line 371
    if-ne v0, v4, :cond_12

    .line 372
    .line 373
    :cond_11
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$7$1;

    .line 374
    .line 375
    invoke-direct {v0, v5}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$7$1;-><init>(Ljava/lang/Object;)V

    .line 376
    .line 377
    .line 378
    invoke-interface {v14, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 379
    .line 380
    .line 381
    :cond_12
    check-cast v0, LX/DqV;

    .line 382
    .line 383
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 384
    .line 385
    invoke-static {v10, v2, v0, v14, v6}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockRetryScreen(ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 386
    .line 387
    .line 388
    goto :goto_0

    .line 389
    :cond_13
    const v0, 0x7b4a7ef

    .line 390
    .line 391
    .line 392
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 393
    .line 394
    .line 395
    invoke-static {v10, v14, v6}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockSplashScreen(ILX/2d4;I)V

    .line 396
    .line 397
    .line 398
    goto :goto_0

    .line 399
    :cond_14
    invoke-interface {v14}, LX/2d4;->AgJ()V

    .line 400
    .line 401
    .line 402
    goto :goto_1
.end method

.method public static final AppBiometricLockScreen$lambda$0(LX/16A;)Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final AppBiometricLockSplashScreen(ILX/2d4;I)V
    .locals 22

    .line 0
    const v0, -0xcfd51a8

    .line 1
    .line 2
    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v4, p2

    .line 9
    .line 10
    and-int/lit8 v0, p2, 0x6

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    move/from16 v6, p0

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-static {v5, v6}, LX/004;->A0E(LX/2d4;I)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    or-int v1, v1, p2

    .line 22
    .line 23
    :goto_0
    and-int/lit8 v0, v1, 0x3

    .line 24
    .line 25
    const/16 v17, 0x0

    .line 26
    .line 27
    invoke-static {v0, v2}, LX/003;->A1H(II)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    invoke-static {v0, v5, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 38
    .line 39
    sget-object v2, LX/2sI;->A01:LX/2wD;

    .line 40
    .line 41
    invoke-static {v5}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 46
    .line 47
    const/4 v15, 0x0

    .line 48
    invoke-static {v2, v0, v1}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 49
    .line 50
    .line 51
    move-result-object v10

    .line 52
    invoke-static/range {v17 .. v17}, LX/001;->A0g(Z)LX/3BI;

    .line 53
    .line 54
    .line 55
    move-result-object v9

    .line 56
    move-object v7, v5

    .line 57
    check-cast v7, LX/J7I;

    .line 58
    .line 59
    iget-wide v0, v7, LX/J7I;->A06:J

    .line 60
    .line 61
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 62
    .line 63
    .line 64
    move-result v13

    .line 65
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    invoke-static {v5, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    sget-object v12, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 74
    .line 75
    iget-object v0, v7, LX/J7I;->A0V:LX/3DJ;

    .line 76
    .line 77
    if-nez v0, :cond_2

    .line 78
    .line 79
    invoke-static {}, LX/1VY;->A00()V

    .line 80
    .line 81
    .line 82
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    throw v0

    .line 87
    :cond_0
    move v1, v4

    .line 88
    goto :goto_0

    .line 89
    :cond_1
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 90
    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_2
    invoke-static {v5, v7, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 94
    .line 95
    .line 96
    sget-object v11, LX/3Cl;->A04:LX/JDN;

    .line 97
    .line 98
    invoke-static {v5, v9, v11}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 99
    .line 100
    .line 101
    move-result-object v10

    .line 102
    invoke-static {v5, v3, v10, v13}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 103
    .line 104
    .line 105
    move-result-object v14

    .line 106
    sget-object v9, LX/3Cl;->A02:LX/JDM;

    .line 107
    .line 108
    invoke-static {v5, v1, v9}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 109
    .line 110
    .line 111
    move-result-object v3

    .line 112
    invoke-static {v2}, LX/6jg;->A02(LX/3C1;)LX/3C1;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    sget-object v13, LX/2Id;->A00:LX/2sS;

    .line 117
    .line 118
    sget-object v2, LX/Dn6;->A06:LX/Dps;

    .line 119
    .line 120
    const/16 v1, 0x36

    .line 121
    .line 122
    invoke-static {v2, v5, v13, v1}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 123
    .line 124
    .line 125
    move-result-object v13

    .line 126
    invoke-static {v7}, LX/002;->A0J(LX/J7I;)I

    .line 127
    .line 128
    .line 129
    move-result v2

    .line 130
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-static {v5, v7, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 139
    .line 140
    .line 141
    invoke-static {v5, v13, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v5, v1, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 145
    .line 146
    .line 147
    invoke-static {v9, v14, v5, v2}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 148
    .line 149
    .line 150
    invoke-static {v5, v0, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 151
    .line 152
    .line 153
    const/high16 v0, 0x42800000    # 64.0f

    .line 154
    .line 155
    invoke-static {v5, v8, v0}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 156
    .line 157
    .line 158
    new-instance v13, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;

    .line 159
    .line 160
    invoke-direct {v13, v6}, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;-><init>(I)V

    .line 161
    .line 162
    .line 163
    const/high16 v0, 0x42a00000    # 80.0f

    .line 164
    .line 165
    invoke-static {v8, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 166
    .line 167
    .line 168
    move-result-object v14

    .line 169
    const/16 p1, 0x30

    .line 170
    .line 171
    const/16 p2, 0x1fc

    .line 172
    .line 173
    move-object/from16 v16, v15

    .line 174
    .line 175
    move/from16 v18, v17

    .line 176
    .line 177
    move-object/from16 v19, v15

    .line 178
    .line 179
    move/from16 v20, v17

    .line 180
    .line 181
    move-object/from16 v21, v15

    .line 182
    .line 183
    move-object/from16 p0, v5

    .line 184
    .line 185
    invoke-static/range {v13 .. v24}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage(Lcom/facebook/aura/vds/compose/common/AuraDrawableSource;LX/3C1;Ljava/lang/String;LX/HVa;ZZLcom/facebook/common/callercontext/ContextChain;ZLX/HWR;LX/2d4;II)V

    .line 186
    .line 187
    .line 188
    invoke-static {v7}, LX/007;->A1D(LX/J7I;)V

    .line 189
    .line 190
    .line 191
    :goto_1
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    if-eqz v1, :cond_3

    .line 196
    .line 197
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockSplashScreen$2;

    .line 198
    .line 199
    invoke-direct {v0, v6, v4}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockSplashScreen$2;-><init>(II)V

    .line 200
    .line 201
    .line 202
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 203
    .line 204
    :cond_3
    return-void
.end method

.method public static final AppBiometricLockUnavailableScreen(ILcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 46
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v1, 0x30e26dfd

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p4

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v4, p5

    .line 9
    .line 10
    and-int/lit8 v1, p5, 0x6

    .line 11
    .line 12
    if-nez v1, :cond_3

    .line 13
    .line 14
    move/from16 v1, p0

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/004;->A0E(LX/2d4;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    or-int v1, v1, p5

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v2, p5, 0x30

    .line 23
    .line 24
    move-object/from16 v45, p1

    .line 25
    .line 26
    if-nez v2, :cond_0

    .line 27
    .line 28
    move-object/from16 v2, v45

    .line 29
    .line 30
    invoke-static {v2, v0, v4}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    invoke-static {v2}, LX/003;->A07(I)I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    or-int/2addr v1, v2

    .line 39
    :cond_0
    and-int/lit16 v2, v4, 0x180

    .line 40
    .line 41
    move-object/from16 v44, p2

    .line 42
    .line 43
    if-nez v2, :cond_1

    .line 44
    .line 45
    move-object/from16 v2, v44

    .line 46
    .line 47
    invoke-static {v0, v2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    or-int/2addr v1, v2

    .line 52
    :cond_1
    and-int/lit16 v2, v4, 0xc00

    .line 53
    .line 54
    move-object/from16 v43, p3

    .line 55
    .line 56
    if-nez v2, :cond_2

    .line 57
    .line 58
    move-object/from16 v2, v43

    .line 59
    .line 60
    invoke-static {v0, v2}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    or-int/2addr v1, v2

    .line 65
    :cond_2
    and-int/lit16 v3, v1, 0x493

    .line 66
    .line 67
    const/16 v2, 0x492

    .line 68
    .line 69
    const/16 v19, 0x0

    .line 70
    .line 71
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    if-eqz v2, :cond_4

    .line 80
    .line 81
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 82
    .line 83
    sget-object v8, LX/2sI;->A01:LX/2wD;

    .line 84
    .line 85
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 86
    .line 87
    const/16 v18, 0x6

    .line 88
    .line 89
    invoke-static {v0, v7}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 90
    .line 91
    .line 92
    move-result-wide v5

    .line 93
    const/16 v17, 0x0

    .line 94
    .line 95
    invoke-static {v8, v5, v6}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 96
    .line 97
    .line 98
    move-result-object v12

    .line 99
    invoke-static/range {v19 .. v19}, LX/001;->A0g(Z)LX/3BI;

    .line 100
    .line 101
    .line 102
    move-result-object v11

    .line 103
    move-object v2, v0

    .line 104
    check-cast v2, LX/J7I;

    .line 105
    .line 106
    iget-wide v5, v2, LX/J7I;->A06:J

    .line 107
    .line 108
    invoke-static {v5, v6}, LX/001;->A0A(J)I

    .line 109
    .line 110
    .line 111
    move-result v10

    .line 112
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 113
    .line 114
    .line 115
    move-result-object v9

    .line 116
    invoke-static {v0, v12}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 117
    .line 118
    .line 119
    move-result-object v6

    .line 120
    sget-object v15, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 121
    .line 122
    iget-object v5, v2, LX/J7I;->A0V:LX/3DJ;

    .line 123
    .line 124
    if-nez v5, :cond_5

    .line 125
    .line 126
    invoke-static {}, LX/1VY;->A00()V

    .line 127
    .line 128
    .line 129
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    throw v0

    .line 134
    :cond_3
    move v1, v4

    .line 135
    goto :goto_0

    .line 136
    :cond_4
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 137
    .line 138
    .line 139
    goto/16 :goto_3

    .line 140
    .line 141
    :cond_5
    invoke-static {v0, v2, v15}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 142
    .line 143
    .line 144
    sget-object v14, LX/3Cl;->A04:LX/JDN;

    .line 145
    .line 146
    invoke-static {v0, v11, v14}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 147
    .line 148
    .line 149
    move-result-object v13

    .line 150
    invoke-static {v0, v9, v13, v10}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 151
    .line 152
    .line 153
    move-result-object v16

    .line 154
    sget-object v12, LX/3Cl;->A02:LX/JDM;

    .line 155
    .line 156
    invoke-static {v0, v6, v12}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 157
    .line 158
    .line 159
    move-result-object v11

    .line 160
    invoke-static {v8}, LX/6jg;->A02(LX/3C1;)LX/3C1;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    invoke-static {v5}, LX/6jg;->A01(LX/3C1;)LX/3C1;

    .line 165
    .line 166
    .line 167
    move-result-object v6

    .line 168
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 169
    .line 170
    invoke-static {v6, v5}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 171
    .line 172
    .line 173
    move-result-object v8

    .line 174
    sget-object v6, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 175
    .line 176
    const/16 v5, 0x30

    .line 177
    .line 178
    invoke-static {v8, v6, v0, v5}, Lcom/facebook/aura/ui/adaptive/AuraContentFrameKt;->auraContentWidth(LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;LX/2d4;I)LX/3C1;

    .line 179
    .line 180
    .line 181
    move-result-object v8

    .line 182
    invoke-static {v0}, LX/008;->A0k(LX/2d4;)LX/3BI;

    .line 183
    .line 184
    .line 185
    move-result-object v10

    .line 186
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 187
    .line 188
    .line 189
    move-result v9

    .line 190
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 191
    .line 192
    .line 193
    move-result-object v6

    .line 194
    invoke-static {v0, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 195
    .line 196
    .line 197
    move-result-object v8

    .line 198
    invoke-static {v0, v2, v15}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 199
    .line 200
    .line 201
    invoke-static {v0, v10, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 202
    .line 203
    .line 204
    invoke-static {v0, v6, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 205
    .line 206
    .line 207
    move-object/from16 v6, v16

    .line 208
    .line 209
    invoke-static {v12, v6, v0, v9}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 210
    .line 211
    .line 212
    invoke-static {v0, v8, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 213
    .line 214
    .line 215
    new-instance v8, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;

    .line 216
    .line 217
    move/from16 v6, p0

    .line 218
    .line 219
    invoke-direct {v8, v6}, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;-><init>(I)V

    .line 220
    .line 221
    .line 222
    const/high16 v6, 0x42a00000    # 80.0f

    .line 223
    .line 224
    invoke-static {v3, v6}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 225
    .line 226
    .line 227
    move-result-object v21

    .line 228
    const/16 v31, 0x1fc

    .line 229
    .line 230
    move-object/from16 v20, v8

    .line 231
    .line 232
    move-object/from16 v22, v17

    .line 233
    .line 234
    move-object/from16 v23, v17

    .line 235
    .line 236
    move/from16 v24, v19

    .line 237
    .line 238
    move/from16 v25, v19

    .line 239
    .line 240
    move-object/from16 v26, v17

    .line 241
    .line 242
    move/from16 v27, v19

    .line 243
    .line 244
    move-object/from16 v28, v17

    .line 245
    .line 246
    move-object/from16 v29, v0

    .line 247
    .line 248
    move/from16 v30, v5

    .line 249
    .line 250
    invoke-static/range {v20 .. v31}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage(Lcom/facebook/aura/vds/compose/common/AuraDrawableSource;LX/3C1;Ljava/lang/String;LX/HVa;ZZLcom/facebook/common/callercontext/ContextChain;ZLX/HWR;LX/2d4;II)V

    .line 251
    .line 252
    .line 253
    const/high16 v6, 0x41c00000    # 24.0f

    .line 254
    .line 255
    invoke-static {v0, v3, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 256
    .line 257
    .line 258
    const v8, 0x7f1201bd

    .line 259
    .line 260
    .line 261
    invoke-static {v0, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v10

    .line 265
    move/from16 v8, v18

    .line 266
    .line 267
    invoke-virtual {v7, v0, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 268
    .line 269
    .line 270
    move-result-object v8

    .line 271
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 272
    .line 273
    invoke-static {v0, v7}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 274
    .line 275
    .line 276
    move-result-wide v12

    .line 277
    const/16 v28, 0x3ff2

    .line 278
    .line 279
    move-object/from16 v11, v17

    .line 280
    .line 281
    move-object v14, v8

    .line 282
    move-object v15, v11

    .line 283
    move-object/from16 v16, v11

    .line 284
    .line 285
    move/from16 v18, v19

    .line 286
    .line 287
    move/from16 v20, v19

    .line 288
    .line 289
    move/from16 v21, v19

    .line 290
    .line 291
    move-object/from16 v24, v11

    .line 292
    .line 293
    move-object/from16 v25, v0

    .line 294
    .line 295
    move/from16 v26, v19

    .line 296
    .line 297
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 298
    .line 299
    .line 300
    const/high16 v8, 0x41000000    # 8.0f

    .line 301
    .line 302
    invoke-static {v0, v3, v8}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 303
    .line 304
    .line 305
    move-object/from16 v8, v45

    .line 306
    .line 307
    iget-object v8, v8, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;->reason:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 308
    .line 309
    sget-object v9, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NO_DEVICE_CREDENTIAL:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 310
    .line 311
    if-ne v8, v9, :cond_8

    .line 312
    .line 313
    const v8, 0x2986b023

    .line 314
    .line 315
    .line 316
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 317
    .line 318
    .line 319
    const v8, 0x7f1201bc

    .line 320
    .line 321
    .line 322
    invoke-static {v0, v2, v8}, LX/18b;->A06(LX/2d4;LX/J7I;I)Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v10

    .line 326
    :goto_1
    invoke-static {v0, v7}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 327
    .line 328
    .line 329
    move-result-object v14

    .line 330
    invoke-static {v0, v7}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 331
    .line 332
    .line 333
    move-result-wide v12

    .line 334
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 335
    .line 336
    .line 337
    invoke-static {v0, v3, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 338
    .line 339
    .line 340
    move-object/from16 v6, v45

    .line 341
    .line 342
    iget-object v7, v6, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;->reason:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 343
    .line 344
    sget-object v6, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NONE_ENROLLED:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 345
    .line 346
    const v10, 0xe000

    .line 347
    .line 348
    .line 349
    if-eq v7, v6, :cond_7

    .line 350
    .line 351
    if-eq v7, v9, :cond_7

    .line 352
    .line 353
    const v3, 0x299418a9

    .line 354
    .line 355
    .line 356
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 357
    .line 358
    .line 359
    move/from16 v3, v19

    .line 360
    .line 361
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 362
    .line 363
    .line 364
    :goto_2
    const v3, 0x7f12081b

    .line 365
    .line 366
    .line 367
    invoke-static {v0, v3}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v12

    .line 371
    sget-object v7, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 372
    .line 373
    const/4 v6, 0x1

    .line 374
    invoke-virtual {v7, v11, v0, v5, v6}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 375
    .line 376
    .line 377
    move-result-object v15

    .line 378
    sget-object v16, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->LARGE:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 379
    .line 380
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 381
    .line 382
    shl-int/lit8 v40, v1, 0x3

    .line 383
    .line 384
    and-int v40, v40, v10

    .line 385
    .line 386
    const v42, 0x7ffbfc5

    .line 387
    .line 388
    .line 389
    const v39, 0x30c00

    .line 390
    .line 391
    .line 392
    move-object v13, v11

    .line 393
    move/from16 v22, v19

    .line 394
    .line 395
    move-object/from16 v25, v43

    .line 396
    .line 397
    move-object/from16 v26, v11

    .line 398
    .line 399
    move-object/from16 v27, v11

    .line 400
    .line 401
    move-object/from16 v28, v11

    .line 402
    .line 403
    move-object/from16 v29, v11

    .line 404
    .line 405
    move-object/from16 v30, v11

    .line 406
    .line 407
    move-object/from16 v31, v11

    .line 408
    .line 409
    move-object/from16 v32, v11

    .line 410
    .line 411
    move-object/from16 v33, v11

    .line 412
    .line 413
    move/from16 v34, v19

    .line 414
    .line 415
    move/from16 v35, v19

    .line 416
    .line 417
    move/from16 v36, v19

    .line 418
    .line 419
    move/from16 v37, v19

    .line 420
    .line 421
    move-object/from16 v38, v0

    .line 422
    .line 423
    move/from16 v41, v19

    .line 424
    .line 425
    invoke-static/range {v11 .. v42}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 426
    .line 427
    .line 428
    invoke-static {v2, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 429
    .line 430
    .line 431
    invoke-static {v2, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 432
    .line 433
    .line 434
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 435
    .line 436
    .line 437
    move-result-object v1

    .line 438
    if-eqz v1, :cond_6

    .line 439
    .line 440
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockUnavailableScreen$2;

    .line 441
    .line 442
    move-object v5, v0

    .line 443
    move/from16 v6, p0

    .line 444
    .line 445
    move-object/from16 v7, v45

    .line 446
    .line 447
    move-object/from16 v8, v44

    .line 448
    .line 449
    move-object/from16 v9, v43

    .line 450
    .line 451
    move v10, v4

    .line 452
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockUnavailableScreen$2;-><init>(ILcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 453
    .line 454
    .line 455
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 456
    .line 457
    :cond_6
    return-void

    .line 458
    :cond_7
    const v6, 0x298f2798

    .line 459
    .line 460
    .line 461
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 462
    .line 463
    .line 464
    const v6, 0x7f121098

    .line 465
    .line 466
    .line 467
    invoke-static {v0, v6}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v12

    .line 471
    sget-object v8, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 472
    .line 473
    const/4 v7, 0x1

    .line 474
    invoke-virtual {v8, v11, v0, v5, v7}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primaryAlt(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 475
    .line 476
    .line 477
    move-result-object v15

    .line 478
    sget-object v16, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->LARGE:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 479
    .line 480
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 481
    .line 482
    shl-int/lit8 v40, v1, 0x6

    .line 483
    .line 484
    and-int v40, v40, v10

    .line 485
    .line 486
    const v42, 0x7ffbfc5

    .line 487
    .line 488
    .line 489
    const v39, 0x30c00

    .line 490
    .line 491
    .line 492
    move-object v13, v11

    .line 493
    move/from16 v22, v19

    .line 494
    .line 495
    move-object/from16 v25, v44

    .line 496
    .line 497
    move-object/from16 v26, v11

    .line 498
    .line 499
    move-object/from16 v27, v11

    .line 500
    .line 501
    move-object/from16 v28, v11

    .line 502
    .line 503
    move-object/from16 v29, v11

    .line 504
    .line 505
    move-object/from16 v30, v11

    .line 506
    .line 507
    move-object/from16 v31, v11

    .line 508
    .line 509
    move-object/from16 v32, v11

    .line 510
    .line 511
    move-object/from16 v33, v11

    .line 512
    .line 513
    move/from16 v34, v19

    .line 514
    .line 515
    move/from16 v35, v19

    .line 516
    .line 517
    move/from16 v36, v19

    .line 518
    .line 519
    move/from16 v37, v19

    .line 520
    .line 521
    move-object/from16 v38, v0

    .line 522
    .line 523
    move/from16 v41, v19

    .line 524
    .line 525
    invoke-static/range {v11 .. v42}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 526
    .line 527
    .line 528
    const/high16 v7, 0x41400000    # 12.0f

    .line 529
    .line 530
    move/from16 v6, v19

    .line 531
    .line 532
    invoke-static {v0, v2, v3, v7, v6}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 533
    .line 534
    .line 535
    goto/16 :goto_2

    .line 536
    .line 537
    :cond_8
    const v8, 0x298851e9

    .line 538
    .line 539
    .line 540
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 541
    .line 542
    .line 543
    const v8, 0x7f1201be

    .line 544
    .line 545
    .line 546
    invoke-static {v0, v2, v8}, LX/18b;->A06(LX/2d4;LX/J7I;I)Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v10

    .line 550
    goto/16 :goto_1
.end method

.method public static final synthetic access$AppBiometricLockRetryScreen(ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockRetryScreen(ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AppBiometricLockSplashScreen(ILX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockSplashScreen(ILX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AppBiometricLockUnavailableScreen(ILcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockUnavailableScreen(ILcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
