.class public final Lcom/facebook/aura/applock/AppBiometricLockViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final biometricManager:LX/0wY;

.field public final overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

.field public final repository:Lcom/facebook/aura/applock/AppLockRepository;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/applock/AppLockRepository;LX/0wY;Lcom/facebook/aura/overlay/api/OverlayApi;)V
    .locals 1

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->repository:Lcom/facebook/aura/applock/AppLockRepository;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->biometricManager:LX/0wY;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 11
    .line 12
    invoke-direct {p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->observeShouldLock()V

    .line 13
    .line 14
    .line 15
    invoke-direct {p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->initialUiState()Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 24
    .line 25
    invoke-static {v0}, LX/002;->A1G(LX/2J3;)LX/ERk;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->uiState:LX/2J3;

    .line 30
    .line 31
    return-void
.end method

.method public static final synthetic access$getOverlayApi$p(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)Lcom/facebook/aura/overlay/api/OverlayApi;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)Lcom/facebook/aura/applock/AppLockRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->repository:Lcom/facebook/aura/applock/AppLockRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$uiStateForAuthenticationError(Lcom/facebook/aura/applock/AppBiometricLockViewModel;ILjava/lang/CharSequence;)Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->uiStateForAuthenticationError(ILjava/lang/CharSequence;)Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final initialUiState()Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;
    .locals 2

    .line 0
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->biometricManager:LX/0wY;

    .line 1
    .line 2
    sget v0, Lcom/facebook/aura/applock/AppLockBiometricSettingsKt;->appLockAllowedAuthenticators:I

    .line 3
    .line 4
    invoke-virtual {v1, v0}, LX/0wY;->A00(I)I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eqz v1, :cond_4

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v0, :cond_3

    .line 12
    .line 13
    const/16 v0, 0xb

    .line 14
    .line 15
    if-eq v1, v0, :cond_2

    .line 16
    .line 17
    const/16 v0, 0xc

    .line 18
    .line 19
    if-eq v1, v0, :cond_1

    .line 20
    .line 21
    const/16 v0, 0xf

    .line 22
    .line 23
    if-eq v1, v0, :cond_0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->UNKNOWN:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 26
    .line 27
    :goto_0
    new-instance v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 28
    .line 29
    invoke-direct {v1, v0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;)V

    .line 30
    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_0
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->SECURITY_UPDATE_REQUIRED:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NO_HARDWARE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_2
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NONE_ENROLLED:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_3
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->HARDWARE_UNAVAILABLE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_4
    sget-object v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Ready;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Ready;

    .line 46
    .line 47
    :goto_1
    check-cast v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 48
    .line 49
    return-object v1

    .line 50
    :catch_0
    move-exception p0

    .line 51
    const-string v1, "canAuthenticate refused"

    .line 52
    .line 53
    const-string v0, "AppBiometricLockViewModel"

    .line 54
    .line 55
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 56
    .line 57
    .line 58
    sget-object v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->UNKNOWN:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 59
    .line 60
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 61
    .line 62
    invoke-direct {v0, v1}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;)V

    .line 63
    .line 64
    .line 65
    return-object v0
.end method

.method private final observeShouldLock()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    sget-object v2, Lcom/facebook/aura/executors/AuraDispatchers;->mainImmediate:LX/DSG;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1;

    .line 8
    .line 9
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;LX/2M4;)V

    .line 10
    .line 11
    .line 12
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method private final uiStateForAuthenticationError(ILjava/lang/CharSequence;)Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    if-eq p1, p0, :cond_3

    .line 2
    .line 3
    const/16 p0, 0xb

    .line 4
    .line 5
    if-eq p1, p0, :cond_2

    .line 6
    .line 7
    const/16 p0, 0xc

    .line 8
    .line 9
    if-eq p1, p0, :cond_1

    .line 10
    .line 11
    const/16 p0, 0xe

    .line 12
    .line 13
    if-eq p1, p0, :cond_4

    .line 14
    .line 15
    const/16 p0, 0xf

    .line 16
    .line 17
    if-eq p1, p0, :cond_0

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    new-instance p1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;

    .line 24
    .line 25
    invoke-direct {p1, p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    check-cast p1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 29
    .line 30
    return-object p1

    .line 31
    :cond_0
    sget-object p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->SECURITY_UPDATE_REQUIRED:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_1
    sget-object p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NO_HARDWARE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_2
    sget-object p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NONE_ENROLLED:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_3
    sget-object p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->HARDWARE_UNAVAILABLE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_4
    sget-object p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->NO_DEVICE_CREDENTIAL:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 44
    .line 45
    :goto_1
    new-instance p1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 46
    .line 47
    invoke-direct {p1, p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;)V

    .line 48
    .line 49
    .line 50
    goto :goto_0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final logOut()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/logout/AuraLogoutHelper;->INSTANCE:Lcom/facebook/aura/auth/logout/AuraLogoutHelper;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/logout/AuraLogoutHelper;->isLoggingOut:LX/2J3;

    .line 3
    .line 4
    invoke-static {v0}, LX/3Rq;->A1W(LX/2J3;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchClientCvmEventLogger;->logLogoutClick()V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Lcom/facebook/aura/auth/logout/AuraLogoutHelper;->performLogout()V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final refreshAvailability()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    instance-of v0, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 11
    .line 12
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    instance-of v0, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Authenticating;

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 21
    .line 22
    invoke-direct {p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->initialUiState()Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method public final requestUnlock(Landroidx/fragment/app/FragmentActivity;Ljava/util/concurrent/Executor;LX/0sI;Z)V
    .locals 3

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 4
    .line 5
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    instance-of v0, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Ready;

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    if-eqz p4, :cond_2

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 16
    .line 17
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    instance-of v0, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;

    .line 22
    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Authenticating;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Authenticating;

    .line 28
    .line 29
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    new-instance v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;

    .line 33
    .line 34
    invoke-direct {v1, p0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)V

    .line 35
    .line 36
    .line 37
    new-instance v0, LX/0eC;

    .line 38
    .line 39
    invoke-direct {v0, v1, p1, p2}, LX/0eC;-><init>(LX/0ww;Landroidx/fragment/app/FragmentActivity;Ljava/util/concurrent/Executor;)V

    .line 40
    .line 41
    .line 42
    :try_start_0
    invoke-virtual {v0, p3}, LX/0eC;->A02(LX/0sI;)V

    .line 43
    .line 44
    .line 45
    return-void
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    .line 46
    :catch_0
    move-exception v0

    .line 47
    iget-object v2, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    if-nez v1, :cond_1

    .line 54
    .line 55
    const-string v1, ""

    .line 56
    .line 57
    :cond_1
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;

    .line 58
    .line 59
    invoke-direct {v0, v1}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Error;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    return-void

    .line 66
    :catch_1
    move-exception v2

    .line 67
    const-string v1, "biometric prompt refused"

    .line 68
    .line 69
    const-string v0, "AppBiometricLockViewModel"

    .line 70
    .line 71
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 72
    .line 73
    .line 74
    iget-object v2, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 75
    .line 76
    sget-object v1, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;->UNKNOWN:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;

    .line 77
    .line 78
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;

    .line 79
    .line 80
    invoke-direct {v0, v1}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Unavailable;-><init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Reason;)V

    .line 81
    .line 82
    .line 83
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    :cond_2
    return-void
.end method
