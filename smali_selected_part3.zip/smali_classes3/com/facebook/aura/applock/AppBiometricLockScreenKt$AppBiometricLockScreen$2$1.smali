.class public final Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CcW;",
        "LX/CcV;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $launchPrompt:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/applock/AppBiometricLockViewModel;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;->$viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;->$launchPrompt:LX/JDM;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/CcW;)LX/CcV;
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v1, "AppBiometricLockScreen"

    .line 5
    .line 6
    const-string v0, "resume: refreshing availability and launching prompt"

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;->$viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->refreshAvailability()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;->$launchPrompt:LX/JDM;

    .line 17
    .line 18
    invoke-static {v2, v0}, LX/002;->A1R(ZLX/JDM;)V

    .line 19
    .line 20
    .line 21
    new-instance v0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1$invoke$$inlined$onPauseOrDispose$1;

    .line 22
    .line 23
    invoke-direct {v0, p1}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1$invoke$$inlined$onPauseOrDispose$1;-><init>(LX/CcW;)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CcW;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$2$1;->invoke(LX/CcW;)LX/CcV;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
