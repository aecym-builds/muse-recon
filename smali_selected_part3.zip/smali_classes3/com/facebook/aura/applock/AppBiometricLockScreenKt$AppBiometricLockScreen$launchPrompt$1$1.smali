.class public final Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroidx/fragment/app/FragmentActivity;

.field public final synthetic $executor:Ljava/util/concurrent/Executor;

.field public final synthetic $promptInfo:LX/0sI;

.field public final synthetic $viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;Landroidx/fragment/app/FragmentActivity;Ljava/util/concurrent/Executor;LX/0sI;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$activity:Landroidx/fragment/app/FragmentActivity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$executor:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$promptInfo:LX/0sI;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->invoke(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$viewModel:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$activity:Landroidx/fragment/app/FragmentActivity;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$executor:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$launchPrompt$1$1;->$promptInfo:LX/0sI;

    .line 7
    .line 8
    invoke-virtual {v3, v2, v1, v0, p1}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->requestUnlock(Landroidx/fragment/app/FragmentActivity;Ljava/util/concurrent/Executor;LX/0sI;Z)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
