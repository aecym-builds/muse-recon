.class public abstract Lcom/facebook/aura/applock/AppBiometricLockViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "AppBiometricLockViewModel"
