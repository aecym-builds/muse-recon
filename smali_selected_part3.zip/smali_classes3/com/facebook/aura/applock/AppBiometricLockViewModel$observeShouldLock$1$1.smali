.class public final Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 1

    .line 0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1$1;->emit(ZLX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public final emit(ZLX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    const-string v2, "shouldLock=%b, updating overlay"

    .line 268435457
    .line 268435458
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object v1

    .line 268435462
    const-string v0, "AppBiometricLockViewModel"

    .line 268435463
    .line 268435464
    invoke-static {v1, v0, v2}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435465
    .line 268435466
    .line 268435467
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$observeShouldLock$1$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 268435468
    .line 268435469
    iget-object v1, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 268435470
    .line 268435471
    sget-object v0, Lcom/facebook/aura/navigation/key/AppLockOverlayScreenKey;->INSTANCE:Lcom/facebook/aura/navigation/key/AppLockOverlayScreenKey;

    .line 268435472
    .line 268435473
    invoke-static {v0, v1, p1}, LX/602;->A1F(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/overlay/api/OverlayApi;I)V

    .line 268435474
    .line 268435475
    .line 268435476
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435477
    .line 268435478
    return-object v0
.end method
