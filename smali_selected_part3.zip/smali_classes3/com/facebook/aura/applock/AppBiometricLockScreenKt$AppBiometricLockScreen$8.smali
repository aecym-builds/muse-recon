.class public final Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I


# direct methods
.method public constructor <init>(I)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;->$$changed:I

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/applock/AppBiometricLockScreenKt$AppBiometricLockScreen$8;->$$changed:I

    .line 1
    .line 2
    invoke-static {p0}, LX/0z0;->A00(I)I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    invoke-static {p1, p0}, Lcom/facebook/aura/applock/AppBiometricLockScreenKt;->AppBiometricLockScreen(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
