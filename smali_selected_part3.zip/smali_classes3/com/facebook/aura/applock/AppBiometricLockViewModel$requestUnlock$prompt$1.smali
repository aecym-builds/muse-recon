.class public final Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;
.super LX/0ww;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/applock/AppBiometricLockViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onAuthenticationError(ILjava/lang/CharSequence;)V
    .locals 3

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const-string v1, "AppBiometricLockViewModel"

    .line 17
    .line 18
    const-string v0, "biometric auth error %d: %s"

    .line 19
    .line 20
    invoke-static {v1, v0, v2}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 24
    .line 25
    iget-object v1, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    invoke-static {v0, p1, p2}, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->access$uiStateForAuthenticationError(Lcom/facebook/aura/applock/AppBiometricLockViewModel;ILjava/lang/CharSequence;)Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public onAuthenticationFailed()V
    .locals 0

    .line 0
    return-void
.end method

.method public onAuthenticationSucceeded(LX/0wx;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Ready;->INSTANCE:Lcom/facebook/aura/applock/AppBiometricLockViewModel$UiState$Ready;

    .line 5
    .line 6
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/applock/AppBiometricLockViewModel$requestUnlock$prompt$1;->this$0:Lcom/facebook/aura/applock/AppBiometricLockViewModel;

    .line 10
    .line 11
    iget-object v0, v0, Lcom/facebook/aura/applock/AppBiometricLockViewModel;->repository:Lcom/facebook/aura/applock/AppLockRepository;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/applock/AppLockRepository;->markUnlocked()V

    .line 14
    .line 15
    .line 16
    return-void
.end method
