.class public final Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/overlay/api/OverlayApi;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 8
    .line 9
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    invoke-static {}, LX/602;->A11()LX/BqD;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    const/4 v1, 0x0

    .line 18
    new-instance v0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1;

    .line 19
    .line 20
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1;-><init>(Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;LX/2M4;)V

    .line 21
    .line 22
    .line 23
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public static final synthetic access$getOverlayApi$p(Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;)Lcom/facebook/aura/overlay/api/OverlayApi;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 1
    .line 2
    return-object p0
.end method
