.class public final Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1$1;->this$0:Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/appupdate/AppUpdateState;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/appupdate/AppUpdateState;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    instance-of p2, p1, Lcom/facebook/aura/appupdate/AppUpdateState$HardBlock;

    .line 268435457
    .line 268435458
    iget-object p0, p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1$1;->this$0:Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;

    .line 268435459
    .line 268435460
    iget-object p1, p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;->overlayApi:Lcom/facebook/aura/overlay/api/OverlayApi;

    .line 268435461
    .line 268435462
    sget-object p0, Lcom/facebook/aura/navigation/key/AppUpdateHardBlockOverlayScreenKey;->INSTANCE:Lcom/facebook/aura/navigation/key/AppUpdateHardBlockOverlayScreenKey;

    .line 268435463
    .line 268435464
    invoke-static {p0, p1, p2}, LX/602;->A1F(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/overlay/api/OverlayApi;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object p0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/appupdate/AppUpdateState;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$1$1;->emit(Lcom/facebook/aura/appupdate/AppUpdateState;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
