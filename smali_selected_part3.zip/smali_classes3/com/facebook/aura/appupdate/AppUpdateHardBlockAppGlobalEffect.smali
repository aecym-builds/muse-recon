.class public final Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/globaleffects/api/AppGlobalEffect;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;

.field public static final runsUnderBlockingOverlay:Z = true


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;->INSTANCE:Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public Effect(LX/2d4;I)V
    .locals 5

    .line 0
    const v0, 0xc1088a3

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v1, p2, 0x1

    .line 7
    .line 8
    invoke-static {v1}, LX/003;->A1B(I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-interface {p1, v1, v0}, LX/2d4;->Afw(IZ)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-static {p1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {p1}, LX/603;->A05(LX/2d4;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v1

    .line 26
    new-instance v4, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$Factory;

    .line 27
    .line 28
    invoke-direct {v4, v0}, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel$Factory;-><init>(LX/AHE;)V

    .line 29
    .line 30
    .line 31
    const-class v0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockOverlayViewModel;

    .line 32
    .line 33
    invoke-static {v0, v1, v2}, Lcom/facebook/aura/session/LocalUserSessionKt;->activityViewModelKey(Ljava/lang/Class;J)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-static {p1}, LX/3Rq;->A02(LX/2d4;)Landroidx/activity/ComponentActivity;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-static {v2}, LX/004;->A14(LX/15O;)LX/13i;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v4, v2, v1, v3, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 50
    .line 51
    .line 52
    :goto_0
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    if-eqz v1, :cond_0

    .line 57
    .line 58
    new-instance v0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect$Effect$1;

    .line 59
    .line 60
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect$Effect$1;-><init>(Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;I)V

    .line 61
    .line 62
    .line 63
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 64
    .line 65
    :cond_0
    return-void

    .line 66
    :cond_1
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 67
    .line 68
    .line 69
    goto :goto_0
.end method

.method public getRunsUnderBlockingOverlay()Z
    .locals 0

    .line 0
    sget-boolean p0, Lcom/facebook/aura/appupdate/AppUpdateHardBlockAppGlobalEffect;->runsUnderBlockingOverlay:Z

    .line 1
    .line 2
    return p0
.end method
