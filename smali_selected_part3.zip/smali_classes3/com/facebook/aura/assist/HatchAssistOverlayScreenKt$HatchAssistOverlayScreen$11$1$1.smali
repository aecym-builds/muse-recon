.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2gu;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $identityState:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $overlayAlpha$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistIdentityState;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;->$overlayAlpha$delegate:LX/16A;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2gu;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;->invoke(LX/2gu;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2gu;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;->$overlayAlpha$delegate:LX/16A;

    .line 5
    .line 6
    invoke-static {v0}, LX/16A;->A00(LX/16A;)F

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistIdentityState;->progress:LX/16A;

    .line 13
    .line 14
    invoke-static {v0}, LX/16A;->A00(LX/16A;)F

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/high16 v0, 0x3f800000    # 1.0f

    .line 19
    .line 20
    sub-float/2addr v0, v1

    .line 21
    mul-float/2addr v2, v0

    .line 22
    invoke-interface {p1, v2}, LX/2gu;->AdD(F)V

    .line 23
    .line 24
    .line 25
    return-void
.end method
