.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 268435456
    and-int/lit8 v1, p2, 0x3

    .line 268435457
    .line 268435458
    const/4 v0, 0x2

    .line 268435459
    const/4 v3, 0x1

    .line 268435460
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    if-eqz v0, :cond_0

    .line 268435469
    .line 268435470
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435471
    .line 268435472
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435473
    .line 268435474
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;

    .line 268435475
    .line 268435476
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 268435477
    .line 268435478
    .line 268435479
    const v0, 0x31ea6fe3

    .line 268435480
    .line 268435481
    .line 268435482
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435483
    .line 268435484
    .line 268435485
    move-result-object v2

    .line 268435486
    const/16 v1, 0x30

    .line 268435487
    .line 268435488
    const/4 v0, 0x0

    .line 268435489
    invoke-static {v0, v2, p1, v1, v3}, Lcom/facebook/aura/assist/AssistCameraHostKt;->AssistCameraHost(LX/3C1;LX/JDN;LX/2d4;II)V

    .line 268435490
    .line 268435491
    .line 268435492
    return-void

    .line 268435493
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435494
    .line 268435495
    .line 268435496
    return-void
.end method
