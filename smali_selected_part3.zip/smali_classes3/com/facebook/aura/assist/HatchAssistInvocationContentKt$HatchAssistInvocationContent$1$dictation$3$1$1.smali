.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Landroid/content/Context;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onMicClick(Landroid/content/Context;Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
