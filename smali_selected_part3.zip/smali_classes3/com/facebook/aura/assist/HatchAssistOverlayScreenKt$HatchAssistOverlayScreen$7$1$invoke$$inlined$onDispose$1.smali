.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$7$1$invoke$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CdD;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 0

    .line 0
    return-void
.end method
