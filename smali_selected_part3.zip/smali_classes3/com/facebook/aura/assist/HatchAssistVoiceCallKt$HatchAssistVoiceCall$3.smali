.class public final Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Lcom/facebook/aura/assist/AssistVoiceLayout;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$modifier:LX/3C1;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$$changed:I

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$$default:I

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 7

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$modifier:LX/3C1;

    .line 268435463
    .line 268435464
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$$changed:I

    .line 268435465
    .line 268435466
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435467
    .line 268435468
    .line 268435469
    move-result v6

    .line 268435470
    iget p0, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$3;->$$default:I

    .line 268435471
    .line 268435472
    move-object v5, p1

    .line 268435473
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt;->HatchAssistVoiceCall(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435474
    .line 268435475
    .line 268435476
    return-void
.end method
