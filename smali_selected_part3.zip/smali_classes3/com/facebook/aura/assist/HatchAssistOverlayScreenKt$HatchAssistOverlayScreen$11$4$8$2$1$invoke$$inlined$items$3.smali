.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDO<",
        "LX/1Xg;",
        "Ljava/lang/Integer;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

.field public final synthetic $items:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;->$items:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;->$convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    check-cast p3, LX/2d4;

    .line 7
    .line 8
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-virtual {p0, p1, v1, p3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;->invoke(LX/1Xg;ILX/2d4;I)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(LX/1Xg;ILX/2d4;I)V
    .locals 7

    .line 268435456
    and-int/lit8 v0, p4, 0x6

    .line 268435457
    .line 268435458
    if-nez v0, :cond_1

    .line 268435459
    .line 268435460
    invoke-static {p3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    or-int v3, p4, v0

    .line 268435465
    .line 268435466
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 268435467
    .line 268435468
    if-nez v0, :cond_0

    .line 268435469
    .line 268435470
    invoke-static {p3, p2}, LX/004;->A0F(LX/2d4;I)I

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v0

    .line 268435474
    or-int/2addr v3, v0

    .line 268435475
    :cond_0
    and-int/lit16 v1, v3, 0x93

    .line 268435476
    .line 268435477
    const/16 v0, 0x92

    .line 268435478
    .line 268435479
    const/4 p4, 0x0

    .line 268435480
    const/4 v2, 0x1

    .line 268435481
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435482
    .line 268435483
    .line 268435484
    move-result v0

    .line 268435485
    invoke-static {v0, p3, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435486
    .line 268435487
    .line 268435488
    move-result v0

    .line 268435489
    if-eqz v0, :cond_2

    .line 268435490
    .line 268435491
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;->$items:Ljava/util/List;

    .line 268435492
    .line 268435493
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 268435494
    .line 268435495
    .line 268435496
    move-result-object v5

    .line 268435497
    check-cast v5, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;

    .line 268435498
    .line 268435499
    const v0, -0x776f3b

    .line 268435500
    .line 268435501
    .line 268435502
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 268435503
    .line 268435504
    .line 268435505
    invoke-static {p3, p4}, Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocusKt;->rememberConversationRowEmbeddedViewFocus(LX/2d4;I)Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocus;

    .line 268435506
    .line 268435507
    .line 268435508
    move-result-object v1

    .line 268435509
    iget-object v0, v1, Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocus;->modifier:LX/3C1;

    .line 268435510
    .line 268435511
    const/4 v3, 0x0

    .line 268435512
    invoke-static {v0, v3, p3, p4, v2}, Lcom/facebook/aura/conversation/ui/HatchBubbleStyleKt;->bubbleMaxWidth-rAjV9yQ(LX/3C1;FLX/2d4;II)LX/3C1;

    .line 268435513
    .line 268435514
    .line 268435515
    move-result-object v2

    .line 268435516
    const/4 v4, 0x6

    .line 268435517
    const/high16 v0, 0x40c00000    # 6.0f

    .line 268435518
    .line 268435519
    invoke-static {v2, v3, v0}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435520
    .line 268435521
    .line 268435522
    move-result-object v6

    .line 268435523
    sget-object v3, Lcom/facebook/aura/model/HatchMessageRole;->AGENT:Lcom/facebook/aura/model/HatchMessageRole;

    .line 268435524
    .line 268435525
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;->$convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 268435526
    .line 268435527
    iget-object v2, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 268435528
    .line 268435529
    sget v0, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->$stable:I

    .line 268435530
    .line 268435531
    shl-int/lit8 v0, v0, 0x3

    .line 268435532
    .line 268435533
    or-int/lit8 v0, v0, 0x6

    .line 268435534
    .line 268435535
    invoke-static {v3, v2, p3, v0}, Lcom/facebook/aura/conversation/ui/HatchBubbleStyleKt;->bubbleBackground(Lcom/facebook/aura/model/HatchMessageRole;Lcom/facebook/aura/identity/provider/HatchConversationTheme;LX/2d4;I)J

    .line 268435536
    .line 268435537
    .line 268435538
    move-result-wide p0

    .line 268435539
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 268435540
    .line 268435541
    invoke-virtual {v0, p3, v4}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 268435542
    .line 268435543
    .line 268435544
    move-result-object v0

    .line 268435545
    iget v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->bubbleCornerRadius:F

    .line 268435546
    .line 268435547
    invoke-static {v0, v0, v0, v0}, LX/2bA;->A01(FFFF)LX/2bC;

    .line 268435548
    .line 268435549
    .line 268435550
    move-result-object p2

    .line 268435551
    invoke-interface/range {v5 .. v11}, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;->Render-iJQMabo(LX/3C1;JLX/2bC;LX/2d4;I)V

    .line 268435552
    .line 268435553
    .line 268435554
    sget v0, Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocus;->$stable:I

    .line 268435555
    .line 268435556
    invoke-static {v1, p3, v0}, Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocusKt;->ReleaseEmbeddedViewFocusEffect(Lcom/facebook/aura/conversation/view/ConversationRowEmbeddedViewFocus;LX/2d4;I)V

    .line 268435557
    .line 268435558
    .line 268435559
    invoke-static {p3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435560
    .line 268435561
    .line 268435562
    return-void

    .line 268435563
    :cond_1
    move v3, p4

    .line 268435564
    goto :goto_0

    .line 268435565
    :cond_2
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 268435566
    .line 268435567
    .line 268435568
    return-void
.end method
