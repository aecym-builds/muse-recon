.class public abstract Lcom/facebook/aura/assist/AssistVoicePresentationKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final LocalAssistVoicePresentation:LX/Ip3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ip3<",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            ">;"
        }
    .end annotation
.end field

.field public static final reverseVoiceEasing:LX/1V8;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$LocalAssistVoicePresentation$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$LocalAssistVoicePresentation$1;

    .line 1
    .line 2
    invoke-static {v0}, LX/003;->A0S(Lkotlin/jvm/functions/Function0;)LX/Jng;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->LocalAssistVoicePresentation:LX/Ip3;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;

    .line 9
    .line 10
    sput-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->reverseVoiceEasing:LX/1V8;

    .line 11
    .line 12
    return-void
.end method

.method public static final AssistIdentityPlaceholder(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/3C1;LX/2d4;II)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const v0, -0x3aef82a4

    .line 5
    .line 6
    .line 7
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    if-nez v0, :cond_7

    .line 13
    .line 14
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    or-int/2addr v3, p3

    .line 19
    :goto_0
    and-int/lit8 v2, p4, 0x2

    .line 20
    .line 21
    if-eqz v2, :cond_6

    .line 22
    .line 23
    or-int/lit8 v3, v3, 0x30

    .line 24
    .line 25
    :cond_0
    :goto_1
    and-int/lit8 v1, v3, 0x13

    .line 26
    .line 27
    const/16 v0, 0x12

    .line 28
    .line 29
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-static {v0, p2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    if-eqz v2, :cond_1

    .line 40
    .line 41
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 42
    .line 43
    :cond_1
    sget-object v0, Lcom/facebook/aura/assist/AssistIdentityStateKt;->LocalAssistIdentityState:LX/Ip3;

    .line 44
    .line 45
    invoke-interface {p2, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 50
    .line 51
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->getIdentityHeight()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    invoke-static {p2}, LX/3Rp;->A02(LX/2d4;)LX/34Y;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-interface {v0, v1}, LX/34Y;->AhT(I)F

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-static {p1}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const/high16 v0, 0x42200000    # 40.0f

    .line 72
    .line 73
    invoke-static {v1, v0}, LX/603;->A0J(LX/1Ot;F)LX/1Ot;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    iget v0, v0, LX/1Ot;->A00:F

    .line 78
    .line 79
    invoke-static {v2, v0}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-static {v3}, LX/002;->A1S(I)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    if-nez v0, :cond_2

    .line 92
    .line 93
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 94
    .line 95
    if-ne v1, v0, :cond_3

    .line 96
    .line 97
    :cond_2
    new-instance v1, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;

    .line 98
    .line 99
    invoke-direct {v1, p0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;)V

    .line 100
    .line 101
    .line 102
    invoke-interface {p2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    :cond_3
    invoke-static {v2, v1}, LX/3Ae;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-static {p2, v0}, LX/1Vt;->A04(LX/2d4;LX/3C1;)V

    .line 110
    .line 111
    .line 112
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    if-eqz v1, :cond_4

    .line 117
    .line 118
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$2;

    .line 119
    .line 120
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$2;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/3C1;II)V

    .line 121
    .line 122
    .line 123
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 124
    .line 125
    :cond_4
    return-void

    .line 126
    :cond_5
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 127
    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_6
    and-int/lit8 v0, p3, 0x30

    .line 131
    .line 132
    if-nez v0, :cond_0

    .line 133
    .line 134
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    or-int/2addr v3, v0

    .line 139
    goto :goto_1

    .line 140
    :cond_7
    move v3, p3

    .line 141
    goto :goto_0
.end method

.method public static final synthetic access$getReverseVoiceEasing$p()LX/1V8;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->reverseVoiceEasing:LX/1V8;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final animateBounds(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/36Z;LX/36Z;Ljava/lang/String;LX/2d4;I)LX/16A;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "LX/36Z;",
            "LX/36Z;",
            "Ljava/lang/String;",
            "LX/2d4;",
            "I)",
            "LX/16A<",
            "LX/36Z;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p0, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p1, p2, p3, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    iget-object v7, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 9
    .line 10
    sget-object v4, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$1;

    .line 11
    .line 12
    shr-int/lit8 v0, p5, 0x3

    .line 13
    .line 14
    and-int/lit16 v0, v0, 0x380

    .line 15
    .line 16
    sget-object v8, LX/7m4;->A07:LX/2pq;

    .line 17
    .line 18
    shl-int/lit8 v0, v0, 0x3

    .line 19
    .line 20
    and-int/lit16 v2, v0, 0x1c00

    .line 21
    .line 22
    invoke-virtual {v7}, LX/DwH;->A0G()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    move-object v9, p4

    .line 27
    if-nez v0, :cond_2

    .line 28
    .line 29
    const v0, 0x6355e4b0

    .line 30
    .line 31
    .line 32
    invoke-static {v7, p4, v0}, LX/002;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 43
    .line 44
    if-ne v0, v1, :cond_1

    .line 45
    .line 46
    :cond_0
    invoke-static {}, Landroidx/compose/runtime/snapshots/Snapshot;->A03()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 47
    .line 48
    .line 49
    move-result-object v6

    .line 50
    invoke-static {v6}, LX/003;->A0p(Landroidx/compose/runtime/snapshots/Snapshot;)LX/JDM;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    invoke-static {v6}, Landroidx/compose/runtime/snapshots/Snapshot;->A04(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    :try_start_0
    invoke-static {v7, p4, v6, v1, v5}, LX/603;->A0i(LX/DwH;LX/2d4;Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;LX/JDM;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 63
    :catchall_0
    move-exception v0

    .line 64
    invoke-static {v6, v1, v5}, Landroidx/compose/runtime/snapshots/Snapshot;->A07(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;LX/JDM;)V

    .line 65
    .line 66
    .line 67
    throw v0

    .line 68
    :cond_1
    :goto_0
    invoke-static {p4}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    goto :goto_1

    .line 73
    :cond_2
    const v0, 0x6359c50d

    .line 74
    .line 75
    .line 76
    invoke-static {p4, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 77
    .line 78
    .line 79
    move-result-object v6

    .line 80
    invoke-static {v7}, LX/602;->A0Y(LX/DwH;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    :goto_1
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    const v5, -0x56bd29b

    .line 89
    .line 90
    .line 91
    invoke-interface {p4, v5}, LX/2d4;->Agj(I)V

    .line 92
    .line 93
    .line 94
    move-object p0, p1

    .line 95
    if-eqz v0, :cond_3

    .line 96
    .line 97
    move-object p0, p2

    .line 98
    :cond_3
    invoke-static {v6, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 99
    .line 100
    .line 101
    invoke-interface {p4, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    if-nez v0, :cond_4

    .line 110
    .line 111
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 112
    .line 113
    if-ne v1, v0, :cond_5

    .line 114
    .line 115
    :cond_4
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$$inlined$animateRect$1;

    .line 116
    .line 117
    invoke-direct {v0, v7}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$$inlined$animateRect$1;-><init>(LX/DwH;)V

    .line 118
    .line 119
    .line 120
    invoke-static {p4, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    :cond_5
    check-cast v1, LX/16A;

    .line 125
    .line 126
    invoke-static {v1}, LX/16A;->A0C(LX/16A;)Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    invoke-interface {p4, v5}, LX/2d4;->Agj(I)V

    .line 131
    .line 132
    .line 133
    if-eqz v0, :cond_6

    .line 134
    .line 135
    move-object p1, p2

    .line 136
    :cond_6
    invoke-static {v6, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 137
    .line 138
    .line 139
    invoke-interface {p4, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    if-nez v0, :cond_7

    .line 148
    .line 149
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 150
    .line 151
    if-ne v1, v0, :cond_8

    .line 152
    .line 153
    :cond_7
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$$inlined$animateRect$2;

    .line 154
    .line 155
    invoke-direct {v0, v7}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$$inlined$animateRect$2;-><init>(LX/DwH;)V

    .line 156
    .line 157
    .line 158
    invoke-static {p4, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    :cond_8
    check-cast v1, LX/16A;

    .line 163
    .line 164
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-virtual {v4, v1, p4, v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$animateBounds$1;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v6

    .line 176
    check-cast v6, LX/DwR;

    .line 177
    .line 178
    shl-int/lit8 p2, v2, 0x6

    .line 179
    .line 180
    const/high16 v0, 0x70000

    .line 181
    .line 182
    and-int/2addr p2, v0

    .line 183
    invoke-static/range {v6 .. v12}, LX/DwL;->A01(LX/DwR;LX/DwH;LX/2pq;LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)LX/DwG;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    return-object v0
.end method

.method public static final assistAnimatedBounds(LX/3C1;LX/16A;ZLkotlin/jvm/functions/Function0;)LX/3C1;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "LX/16A<",
            "LX/36Z;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)",
            "LX/3C1;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1, p3}, LX/3Rq;->A1S(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$2;

    .line 4
    .line 5
    invoke-direct {v0, p1}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$2;-><init>(LX/16A;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p0, v0}, LX/7mL;->A02(LX/3C1;LX/JDM;)LX/3C1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$3;

    .line 13
    .line 14
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$3;-><init>(LX/16A;ZLkotlin/jvm/functions/Function0;)V

    .line 15
    .line 16
    .line 17
    invoke-static {p0, v0}, LX/2ub;->A00(LX/3C1;LX/JDQ;)LX/3C1;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public static synthetic assistAnimatedBounds$default(LX/3C1;LX/16A;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)LX/3C1;
    .locals 2

    .line 0
    invoke-static {p4, p2}, LX/3Rr;->A1O(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    and-int/lit8 v0, p4, 0x4

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object p3, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistAnimatedBounds$1;

    .line 9
    .line 10
    :cond_0
    invoke-static {p0, p1, v1, p3}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->assistAnimatedBounds(LX/3C1;LX/16A;ZLkotlin/jvm/functions/Function0;)LX/3C1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public static final assistComposerInteraction(LX/3C1;Z)LX/3C1;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistComposerInteraction$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistComposerInteraction$1;

    .line 7
    .line 8
    invoke-static {p0, v0}, LX/36n;->A00(LX/3C1;LX/JDM;)LX/3C1;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistComposerInteraction$2;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$assistComposerInteraction$2;

    .line 15
    .line 16
    invoke-static {p1, v0, p0}, LX/3BV;->A00(LX/3C1;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;Ljava/lang/Object;)LX/3C1;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    :cond_0
    return-object p0
.end method

.method public static final getLocalAssistVoicePresentation()LX/Ip3;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ip3<",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->LocalAssistVoicePresentation:LX/Ip3;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final rememberAssistVoicePresentation(ZLX/2d4;I)Lcom/facebook/aura/assist/AssistVoicePresentation;
    .locals 10

    .line 0
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    and-int/lit8 v0, p2, 0xe

    .line 5
    .line 6
    or-int/lit8 v1, v0, 0x30

    .line 7
    .line 8
    const-string v0, "assistantVoice"

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    move-object v9, p1

    .line 12
    invoke-static {p1, v2, v0, v1}, LX/DwL;->A04(LX/2d4;Ljava/lang/Object;Ljava/lang/String;I)LX/DwH;

    .line 13
    .line 14
    .line 15
    move-result-object v7

    .line 16
    sget-object v2, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;

    .line 17
    .line 18
    sget-object v8, LX/7m4;->A02:LX/2pq;

    .line 19
    .line 20
    invoke-virtual {v7}, LX/DwH;->A0G()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    const v0, 0x6355e4b0

    .line 27
    .line 28
    .line 29
    invoke-static {v7, p1, v0}, LX/002;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-nez v1, :cond_0

    .line 38
    .line 39
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 40
    .line 41
    if-ne v0, v1, :cond_1

    .line 42
    .line 43
    :cond_0
    invoke-static {}, Landroidx/compose/runtime/snapshots/Snapshot;->A03()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-static {v4}, LX/003;->A0p(Landroidx/compose/runtime/snapshots/Snapshot;)LX/JDM;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    invoke-static {v4}, Landroidx/compose/runtime/snapshots/Snapshot;->A04(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    :try_start_0
    invoke-static {v7, p1, v4, v1, v3}, LX/603;->A0i(LX/DwH;LX/2d4;Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;LX/JDM;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 60
    :catchall_0
    move-exception v0

    .line 61
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/snapshots/Snapshot;->A07(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;LX/JDM;)V

    .line 62
    .line 63
    .line 64
    throw v0

    .line 65
    :cond_1
    :goto_0
    invoke-static {p1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    goto :goto_1

    .line 70
    :cond_2
    const v0, 0x6359c50d

    .line 71
    .line 72
    .line 73
    invoke-static {p1, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    invoke-static {v7}, LX/602;->A0Y(LX/DwH;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    :goto_1
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const v4, -0x7241015

    .line 86
    .line 87
    .line 88
    invoke-interface {p1, v4}, LX/2d4;->Agj(I)V

    .line 89
    .line 90
    .line 91
    const/high16 v3, 0x3f800000    # 1.0f

    .line 92
    .line 93
    invoke-static {v0}, LX/007;->A02(I)F

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    invoke-static {v5, v0}, LX/006;->A0o(LX/J7I;F)Ljava/lang/Float;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    invoke-interface {p1, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    if-nez v0, :cond_3

    .line 110
    .line 111
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 112
    .line 113
    if-ne v1, v0, :cond_4

    .line 114
    .line 115
    :cond_3
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$1;

    .line 116
    .line 117
    invoke-direct {v0, v7}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$1;-><init>(LX/DwH;)V

    .line 118
    .line 119
    .line 120
    invoke-static {p1, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    :cond_4
    check-cast v1, LX/16A;

    .line 125
    .line 126
    invoke-static {v1}, LX/16A;->A0C(LX/16A;)Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    invoke-interface {p1, v4}, LX/2d4;->Agj(I)V

    .line 131
    .line 132
    .line 133
    if-nez v0, :cond_5

    .line 134
    .line 135
    const/4 v3, 0x0

    .line 136
    :cond_5
    invoke-static {v5, v3}, LX/006;->A0o(LX/J7I;F)Ljava/lang/Float;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    invoke-interface {v9, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    if-nez v0, :cond_6

    .line 149
    .line 150
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 151
    .line 152
    if-ne v1, v0, :cond_7

    .line 153
    .line 154
    :cond_6
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;

    .line 155
    .line 156
    invoke-direct {v0, v7}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;-><init>(LX/DwH;)V

    .line 157
    .line 158
    .line 159
    invoke-static {v9, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    :cond_7
    check-cast v1, LX/16A;

    .line 164
    .line 165
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    invoke-virtual {v2, v1, v9, v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    check-cast v6, LX/DwR;

    .line 178
    .line 179
    const/high16 p2, 0x30000

    .line 180
    .line 181
    invoke-static/range {v6 .. v12}, LX/DwL;->A01(LX/DwR;LX/DwH;LX/2pq;LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)LX/DwG;

    .line 182
    .line 183
    .line 184
    move-result-object v2

    .line 185
    invoke-interface {v9, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    if-nez v0, :cond_8

    .line 194
    .line 195
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 196
    .line 197
    if-ne v1, v0, :cond_9

    .line 198
    .line 199
    :cond_8
    new-instance v1, Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 200
    .line 201
    invoke-direct {v1, v7, v2}, Lcom/facebook/aura/assist/AssistVoicePresentation;-><init>(LX/DwH;LX/16A;)V

    .line 202
    .line 203
    .line 204
    invoke-interface {v9, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_9
    check-cast v1, Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 208
    .line 209
    return-object v1
.end method
