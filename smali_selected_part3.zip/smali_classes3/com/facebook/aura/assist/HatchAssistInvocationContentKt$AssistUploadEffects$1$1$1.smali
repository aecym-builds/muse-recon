.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect;LX/2M4;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowUploadSizeExceeded;

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_1

    .line 268435459
    .line 268435460
    sget-object v3, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 268435461
    .line 268435462
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;->$context:Landroid/content/Context;

    .line 268435463
    .line 268435464
    const v1, 0x7f120d3b

    .line 268435465
    .line 268435466
    .line 268435467
    check-cast p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowUploadSizeExceeded;

    .line 268435468
    .line 268435469
    iget v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowUploadSizeExceeded;->maxSizeMb:I

    .line 268435470
    .line 268435471
    :goto_0
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 268435472
    .line 268435473
    .line 268435474
    move-result-object v0

    .line 268435475
    invoke-static {v2, v0, v1}, LX/602;->A0b(Landroid/content/Context;Ljava/lang/Object;I)Ljava/lang/String;

    .line 268435476
    .line 268435477
    .line 268435478
    move-result-object v0

    .line 268435479
    invoke-virtual {v3, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(Ljava/lang/String;)V

    .line 268435480
    .line 268435481
    .line 268435482
    :cond_0
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435483
    .line 268435484
    return-object v0

    .line 268435485
    :cond_1
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowAttachmentUploadFailed;

    .line 268435486
    .line 268435487
    if-eqz v0, :cond_2

    .line 268435488
    .line 268435489
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 268435490
    .line 268435491
    const v0, 0x7f120bed

    .line 268435492
    .line 268435493
    .line 268435494
    :goto_2
    invoke-virtual {v1, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 268435495
    .line 268435496
    .line 268435497
    goto :goto_1

    .line 268435498
    :cond_2
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowAttachmentLimitReached;

    .line 268435499
    .line 268435500
    if-eqz v0, :cond_3

    .line 268435501
    .line 268435502
    sget-object v3, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 268435503
    .line 268435504
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;->$context:Landroid/content/Context;

    .line 268435505
    .line 268435506
    const v1, 0x7f120bec

    .line 268435507
    .line 268435508
    .line 268435509
    const/16 v0, 0xa

    .line 268435510
    .line 268435511
    goto :goto_0

    .line 268435512
    :cond_3
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowLiveSessionAttachmentMessage;

    .line 268435513
    .line 268435514
    if-eqz v0, :cond_4

    .line 268435515
    .line 268435516
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 268435517
    .line 268435518
    check-cast p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowLiveSessionAttachmentMessage;

    .line 268435519
    .line 268435520
    iget v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowLiveSessionAttachmentMessage;->messageRes:I

    .line 268435521
    .line 268435522
    goto :goto_2

    .line 268435523
    :cond_4
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$ShowUnsendFailed;

    .line 268435524
    .line 268435525
    if-eqz v0, :cond_5

    .line 268435526
    .line 268435527
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 268435528
    .line 268435529
    const v0, 0x7f1209bb

    .line 268435530
    .line 268435531
    .line 268435532
    goto :goto_2

    .line 268435533
    :cond_5
    instance-of v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect$SessionDeleted;

    .line 268435534
    .line 268435535
    if-nez v0, :cond_0

    .line 268435536
    .line 268435537
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 268435538
    .line 268435539
    .line 268435540
    move-result-object v0

    .line 268435541
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;->emit(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewEffect;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
