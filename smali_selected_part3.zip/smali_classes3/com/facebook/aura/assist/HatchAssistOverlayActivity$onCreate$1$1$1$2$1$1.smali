.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object v8, p1

    .line 268435461
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_6

    .line 268435466
    .line 268435467
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435468
    .line 268435469
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435470
    .line 268435471
    invoke-static {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->access$assistSideChatSessionIdOrNull(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Ljava/lang/String;

    .line 268435472
    .line 268435473
    .line 268435474
    move-result-object v3

    .line 268435475
    invoke-interface {p1, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435480
    .line 268435481
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435482
    .line 268435483
    .line 268435484
    move-result-object v4

    .line 268435485
    if-nez v0, :cond_0

    .line 268435486
    .line 268435487
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435488
    .line 268435489
    if-ne v4, v0, :cond_1

    .line 268435490
    .line 268435491
    :cond_0
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$1$1;

    .line 268435492
    .line 268435493
    invoke-direct {v4, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 268435494
    .line 268435495
    .line 268435496
    invoke-interface {p1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435497
    .line 268435498
    .line 268435499
    :cond_1
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 268435500
    .line 268435501
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435502
    .line 268435503
    invoke-interface {p1, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435504
    .line 268435505
    .line 268435506
    move-result v0

    .line 268435507
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435508
    .line 268435509
    .line 268435510
    move-result-object v5

    .line 268435511
    if-nez v0, :cond_2

    .line 268435512
    .line 268435513
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435514
    .line 268435515
    if-ne v5, v0, :cond_3

    .line 268435516
    .line 268435517
    :cond_2
    new-instance v5, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$2$1;

    .line 268435518
    .line 268435519
    invoke-direct {v5, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$2$1;-><init>(Ljava/lang/Object;)V

    .line 268435520
    .line 268435521
    .line 268435522
    invoke-interface {p1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435523
    .line 268435524
    .line 268435525
    :cond_3
    check-cast v5, LX/DqV;

    .line 268435526
    .line 268435527
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 268435528
    .line 268435529
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435530
    .line 268435531
    invoke-interface {p1, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435532
    .line 268435533
    .line 268435534
    move-result v0

    .line 268435535
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435536
    .line 268435537
    .line 268435538
    move-result-object v6

    .line 268435539
    if-nez v0, :cond_4

    .line 268435540
    .line 268435541
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435542
    .line 268435543
    if-ne v6, v0, :cond_5

    .line 268435544
    .line 268435545
    :cond_4
    new-instance v6, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$3$1;

    .line 268435546
    .line 268435547
    invoke-direct {v6, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$3$1;-><init>(Ljava/lang/Object;)V

    .line 268435548
    .line 268435549
    .line 268435550
    invoke-interface {p1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435551
    .line 268435552
    .line 268435553
    :cond_5
    check-cast v6, LX/DqV;

    .line 268435554
    .line 268435555
    check-cast v6, LX/JDN;

    .line 268435556
    .line 268435557
    sget p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->$stable:I

    .line 268435558
    .line 268435559
    const/16 p1, 0x20

    .line 268435560
    .line 268435561
    const/4 v7, 0x0

    .line 268435562
    invoke-static/range {v2 .. v10}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;->HatchAssistInvocationContent(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;LX/3C1;LX/2d4;II)V

    .line 268435563
    .line 268435564
    .line 268435565
    return-void

    .line 268435566
    :cond_6
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435567
    .line 268435568
    .line 268435569
    return-void
.end method
