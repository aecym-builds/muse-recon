.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $conversationListState:Landroidx/compose/foundation/lazy/LazyListState;

.field public final synthetic $currentIsStreaming$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/foundation/lazy/LazyListState;LX/16A;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/lazy/LazyListState;",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$conversationListState:Landroidx/compose/foundation/lazy/LazyListState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$currentIsStreaming$delegate:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 1

    .line 0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->emit(ZLX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public final emit(ZLX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    if-eqz p1, :cond_3

    .line 268435457
    .line 268435458
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$currentIsStreaming$delegate:LX/16A;

    .line 268435459
    .line 268435460
    invoke-static {v0}, LX/16A;->A0C(LX/16A;)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435467
    .line 268435468
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435469
    .line 268435470
    .line 268435471
    move-result-object v0

    .line 268435472
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v0

    .line 268435476
    if-nez v0, :cond_1

    .line 268435477
    .line 268435478
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$conversationListState:Landroidx/compose/foundation/lazy/LazyListState;

    .line 268435479
    .line 268435480
    invoke-static {v0}, LX/602;->A0t(Landroidx/compose/foundation/lazy/LazyListState;)Ljava/util/List;

    .line 268435481
    .line 268435482
    .line 268435483
    move-result-object v0

    .line 268435484
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 268435485
    .line 268435486
    .line 268435487
    move-result-object v1

    .line 268435488
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 268435489
    .line 268435490
    .line 268435491
    move-result v0

    .line 268435492
    if-eqz v0, :cond_2

    .line 268435493
    .line 268435494
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268435495
    .line 268435496
    .line 268435497
    move-result-object v2

    .line 268435498
    move-object v0, v2

    .line 268435499
    check-cast v0, LX/2gb;

    .line 268435500
    .line 268435501
    check-cast v0, LX/Ds8;

    .line 268435502
    .line 268435503
    iget v0, v0, LX/Ds8;->A07:I

    .line 268435504
    .line 268435505
    if-nez v0, :cond_0

    .line 268435506
    .line 268435507
    :goto_0
    check-cast v2, LX/2gb;

    .line 268435508
    .line 268435509
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435510
    .line 268435511
    if-eqz v2, :cond_4

    .line 268435512
    .line 268435513
    check-cast v2, LX/Ds8;

    .line 268435514
    .line 268435515
    iget v0, v2, LX/Ds8;->A09:I

    .line 268435516
    .line 268435517
    :goto_1
    invoke-static {v0, v1}, LX/603;->A15(ILandroidx/compose/runtime/MutableState;)V

    .line 268435518
    .line 268435519
    .line 268435520
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435521
    .line 268435522
    return-object v0

    .line 268435523
    :cond_2
    const/4 v2, 0x0

    .line 268435524
    goto :goto_0

    .line 268435525
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435526
    .line 268435527
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435528
    .line 268435529
    .line 268435530
    move-result-object v0

    .line 268435531
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435532
    .line 268435533
    .line 268435534
    move-result v0

    .line 268435535
    if-lez v0, :cond_1

    .line 268435536
    .line 268435537
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$conversationListState:Landroidx/compose/foundation/lazy/LazyListState;

    .line 268435538
    .line 268435539
    invoke-virtual {v0}, Landroidx/compose/foundation/lazy/LazyListState;->A02()I

    .line 268435540
    .line 268435541
    .line 268435542
    move-result v0

    .line 268435543
    if-nez v0, :cond_1

    .line 268435544
    .line 268435545
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$conversationListState:Landroidx/compose/foundation/lazy/LazyListState;

    .line 268435546
    .line 268435547
    invoke-virtual {v0}, Landroidx/compose/foundation/lazy/LazyListState;->A03()I

    .line 268435548
    .line 268435549
    .line 268435550
    move-result v0

    .line 268435551
    if-nez v0, :cond_1

    .line 268435552
    .line 268435553
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1$2;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435554
    .line 268435555
    :cond_4
    const/4 v0, 0x0

    .line 268435556
    goto :goto_1
.end method
