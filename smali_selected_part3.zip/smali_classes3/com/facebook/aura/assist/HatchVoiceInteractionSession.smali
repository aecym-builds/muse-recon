.class public final Lcom/facebook/aura/assist/HatchVoiceInteractionSession;
.super Landroid/service/voice/VoiceInteractionSession;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final AURA_MAIN_ACTIVITY_CLASS_NAME:Ljava/lang/String; = "com.facebook.aura.main.AuraMainActivity"

.field public static final Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

.field public static final SHOW_IDENTITY:Ljava/lang/String; = "show_assist_identity"

.field public static final TAG:Ljava/lang/String; = "HatchVoiceInteraction"

.field public static activeSession:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/facebook/aura/assist/HatchVoiceInteractionSession;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

.field public controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

.field public identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

.field public invocationToken:J

.field public overlayShowing:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Landroid/service/voice/VoiceInteractionSession;-><init>(Landroid/content/Context;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

    .line 8
    .line 9
    return-void
.end method

.method public static final synthetic access$clearIdentityHost(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->clearIdentityHost()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getActiveSession$cp()Ljava/lang/ref/WeakReference;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getAppContext$p(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getControlsActivity$p(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)Lcom/facebook/aura/assist/HatchAssistOverlayActivity;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getIdentityHost$p(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)Lcom/facebook/aura/assist/AssistIdentityHost;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$setControlsActivity$p(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$showIdentity(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->showIdentity(JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final clearIdentityHost()V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    iput-object v1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityHost;->dispose()V

    .line 8
    .line 9
    .line 10
    :cond_0
    iput-object v1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 11
    .line 12
    return-void
.end method

.method private final getAuthenticatedUserSession()LX/AHE;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->hasPersistedSession()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    return-object v0

    .line 10
    :cond_0
    invoke-virtual {p0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSessionUnchecked()LX/AHE;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method private final showIdentity(JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 5
    .line 6
    :goto_0
    move-object v3, p3

    .line 7
    if-ne v0, p3, :cond_1

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 10
    .line 11
    :cond_0
    return-void

    .line 12
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->getAuthenticatedUserSession()LX/AHE;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->clearIdentityHost()V

    .line 19
    .line 20
    .line 21
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 22
    .line 23
    new-instance v5, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$1;

    .line 24
    .line 25
    move-wide v1, p1

    .line 26
    invoke-direct {v5, p0, p1, p2}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$1;-><init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;J)V

    .line 27
    .line 28
    .line 29
    new-instance v6, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$2;

    .line 30
    .line 31
    invoke-direct {v6, p0, p3}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$2;-><init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;Lcom/facebook/aura/assist/AssistIdentityState;)V

    .line 32
    .line 33
    .line 34
    new-instance v7, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;

    .line 35
    .line 36
    invoke-direct {v7, p0, p3, p1, p2}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;-><init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;Lcom/facebook/aura/assist/AssistIdentityState;J)V

    .line 37
    .line 38
    .line 39
    new-instance v0, Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 40
    .line 41
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/assist/AssistIdentityHost;-><init>(JLcom/facebook/aura/assist/AssistIdentityState;LX/AHE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 42
    .line 43
    .line 44
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 45
    .line 46
    new-instance v2, Landroid/os/Bundle;

    .line 47
    .line 48
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 49
    .line 50
    .line 51
    const-string v1, "show_assist_identity"

    .line 52
    .line 53
    const/4 v0, 0x1

    .line 54
    invoke-virtual {v2, v1, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    invoke-virtual {p0, v2, v0}, Landroid/service/voice/VoiceInteractionSession;->show(Landroid/os/Bundle;I)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_2
    const/4 v0, 0x0

    .line 63
    goto :goto_0
.end method


# virtual methods
.method public onCloseSystemDialogs()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v2, v0, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 5
    .line 6
    if-eqz v2, :cond_0

    .line 7
    .line 8
    invoke-virtual {v2}, Lcom/facebook/aura/assist/AssistIdentityState;->getIdentity()Lcom/facebook/aura/assist/AssistIdentityPresentation;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-boolean v1, v0, Lcom/facebook/aura/assist/AssistIdentityPresentation;->showingVoice:Z

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    if-ne v1, v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v2}, Lcom/facebook/aura/assist/AssistIdentityState;->collapse()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    invoke-super {p0}, Landroid/service/voice/VoiceInteractionSession;->onCloseSystemDialogs()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public onComputeInsets(Landroid/service/voice/VoiceInteractionSession$Insets;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 5
    .line 6
    if-nez v2, :cond_0

    .line 7
    .line 8
    invoke-super {p0, p1}, Landroid/service/voice/VoiceInteractionSession;->onComputeInsets(Landroid/service/voice/VoiceInteractionSession$Insets;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    iget-object v0, p1, Landroid/service/voice/VoiceInteractionSession$Insets;->contentInsets:Landroid/graphics/Rect;

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/graphics/Rect;->setEmpty()V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x3

    .line 18
    iput v0, p1, Landroid/service/voice/VoiceInteractionSession$Insets;->touchableInsets:I

    .line 19
    .line 20
    iget-object v0, v2, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 21
    .line 22
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->isInteractive()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    iget-object v1, p1, Landroid/service/voice/VoiceInteractionSession$Insets;->touchableRegion:Landroid/graphics/Region;

    .line 27
    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    iget-object v0, v2, Lcom/facebook/aura/assist/AssistIdentityHost;->touchableBounds:Landroid/graphics/Rect;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/graphics/Region;->set(Landroid/graphics/Rect;)Z

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_1
    invoke-virtual {v1}, Landroid/graphics/Region;->setEmpty()V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public onCreate()V
    .locals 1

    .line 0
    invoke-super {p0}, Landroid/service/voice/VoiceInteractionSession;->onCreate()V

    .line 1
    .line 2
    .line 3
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p0, v0}, Landroid/service/voice/VoiceInteractionSession;->setUiEnabled(Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public onDestroy()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->clearIdentityHost()V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-ne v0, p0, :cond_0

    .line 13
    .line 14
    sput-object v1, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 15
    .line 16
    :cond_0
    invoke-super {p0}, Landroid/service/voice/VoiceInteractionSession;->onDestroy()V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public onHandleScreenshot(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 0
    invoke-super {p0, p1}, Landroid/service/voice/VoiceInteractionSession;->onHandleScreenshot(Landroid/graphics/Bitmap;)V

    .line 1
    .line 2
    .line 3
    iget-boolean p0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->overlayShowing:Z

    .line 4
    .line 5
    if-nez p0, :cond_0

    .line 6
    .line 7
    sget-object p0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->setScreenshot(Landroid/graphics/Bitmap;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method

.method public onHide()V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->clearIdentityHost()V

    .line 1
    .line 2
    .line 3
    invoke-super {p0}, Landroid/service/voice/VoiceInteractionSession;->onHide()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public onPrepareShow(Landroid/os/Bundle;I)V
    .locals 3

    .line 0
    invoke-super {p0, p1, p2}, Landroid/service/voice/VoiceInteractionSession;->onPrepareShow(Landroid/os/Bundle;I)V

    .line 1
    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz p1, :cond_2

    .line 6
    .line 7
    const-string v0, "show_assist_identity"

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-ne v0, v1, :cond_2

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 16
    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    :cond_0
    invoke-virtual {p0, v1}, Landroid/service/voice/VoiceInteractionSession;->setUiEnabled(Z)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 24
    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/service/voice/VoiceInteractionSession;->getWindow()Landroid/app/Dialog;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    invoke-static {v1, v2}, LX/0s0;->A00(Landroid/view/Window;Z)V

    .line 38
    .line 39
    .line 40
    const v0, -0x7fffffd8

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 44
    .line 45
    .line 46
    const v0, 0x8000002

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, v0}, Landroid/view/Window;->clearFlags(I)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V

    .line 56
    .line 57
    .line 58
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    .line 59
    .line 60
    invoke-direct {v0, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    .line 67
    .line 68
    .line 69
    const/4 v0, -0x1

    .line 70
    invoke-virtual {v1, v0, v0}, Landroid/view/Window;->setLayout(II)V

    .line 71
    .line 72
    .line 73
    :cond_1
    return-void

    .line 74
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 75
    .line 76
    if-eqz v0, :cond_3

    .line 77
    .line 78
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 79
    .line 80
    invoke-virtual {v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAssistOverlayActive()Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    const/4 v0, 0x1

    .line 85
    if-nez v1, :cond_4

    .line 86
    .line 87
    :cond_3
    const/4 v0, 0x0

    .line 88
    :cond_4
    iput-boolean v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->overlayShowing:Z

    .line 89
    .line 90
    if-nez v0, :cond_1

    .line 91
    .line 92
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->clearIdentityHost()V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v2}, Landroid/service/voice/VoiceInteractionSession;->setUiEnabled(Z)V

    .line 96
    .line 97
    .line 98
    const-string v1, "HatchVoiceInteraction"

    .line 99
    .line 100
    const-string v0, "onPrepareShow entry"

    .line 101
    .line 102
    invoke-static {v1, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    sget-object v1, Lcom/facebook/aura/startup/AuraStartupOrchestrator;->INSTANCE:Lcom/facebook/aura/startup/AuraStartupOrchestrator;

    .line 106
    .line 107
    sget-object v0, Lcom/facebook/aura/startup/appjob/ScopeFilter;->FULL:Lcom/facebook/aura/startup/appjob/ScopeFilter;

    .line 108
    .line 109
    invoke-virtual {v1, v0}, Lcom/facebook/aura/startup/AuraStartupOrchestrator;->start(Lcom/facebook/aura/startup/appjob/ScopeFilter;)V

    .line 110
    .line 111
    .line 112
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 113
    .line 114
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->beginInvocation()J

    .line 115
    .line 116
    .line 117
    move-result-wide v0

    .line 118
    iput-wide v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->invocationToken:J

    .line 119
    .line 120
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->getAuthenticatedUserSession()LX/AHE;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    if-eqz v2, :cond_1

    .line 125
    .line 126
    sget-object v1, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->INSTANCE:Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;

    .line 127
    .line 128
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

    .line 129
    .line 130
    invoke-virtual {v1, v0, v2}, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->initialize(Landroid/content/Context;LX/AHE;)V

    .line 131
    .line 132
    .line 133
    return-void
.end method

.method public onShow(Landroid/os/Bundle;I)V
    .locals 13

    .line 0
    invoke-super {p0, p1, p2}, Landroid/service/voice/VoiceInteractionSession;->onShow(Landroid/os/Bundle;I)V

    .line 1
    .line 2
    .line 3
    if-eqz p1, :cond_1

    .line 4
    .line 5
    const-string v0, "show_assist_identity"

    .line 6
    .line 7
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v0, 0x1

    .line 12
    if-ne v1, v0, :cond_1

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/service/voice/VoiceInteractionSession;->getContext()Landroid/content/Context;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1, v0}, Lcom/facebook/aura/assist/AssistIdentityHost;->createView(Landroid/content/Context;)Landroidx/compose/ui/platform/ComposeView;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p0, v0}, Landroid/service/voice/VoiceInteractionSession;->setContentView(Landroid/view/View;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void

    .line 33
    :cond_1
    iget-boolean v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->overlayShowing:Z

    .line 34
    .line 35
    if-eqz v0, :cond_2

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 38
    .line 39
    if-eqz v0, :cond_0

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->onInvokedAgain$fbandroid_express_aura_java_com_facebook_aura_assist_assist()V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_2
    const-string v0, "onShow entry"

    .line 46
    .line 47
    const-string v4, "HatchVoiceInteraction"

    .line 48
    .line 49
    invoke-static {v4, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 53
    .line 54
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 55
    .line 56
    sget-object v8, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 57
    .line 58
    sget-object v9, Lcom/facebook/aura/analytics/hatch/HatchComponent;->SYSTEM_ASSISTANT:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 59
    .line 60
    const/4 v7, 0x0

    .line 61
    move-object v10, v7

    .line 62
    move-object v11, v7

    .line 63
    move-object v12, v7

    .line 64
    invoke-virtual/range {v5 .. v12}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->getAuthenticatedUserSession()LX/AHE;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    const-string v0, "onShow: no authenticated session, launching full app"

    .line 74
    .line 75
    invoke-static {v4, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    sget-object v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 79
    .line 80
    invoke-virtual {p0}, Landroid/service/voice/VoiceInteractionSession;->getContext()Landroid/content/Context;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    const/4 v0, 0x0

    .line 88
    invoke-virtual {v2, v1, v7, v0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0}, Landroid/service/voice/VoiceInteractionSession;->hide()V

    .line 92
    .line 93
    .line 94
    return-void

    .line 95
    :cond_3
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

    .line 96
    .line 97
    const-class v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 98
    .line 99
    new-instance v1, Landroid/content/Intent;

    .line 100
    .line 101
    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 102
    .line 103
    .line 104
    const/high16 v0, 0x10000000

    .line 105
    .line 106
    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    const-string v2, "com.facebook.aura.extra.ASSIST_INVOCATION_TOKEN"

    .line 111
    .line 112
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->invocationToken:J

    .line 113
    .line 114
    invoke-virtual {v3, v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->appContext:Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;

    .line 122
    .line 123
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 124
    .line 125
    .line 126
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 127
    :catch_0
    move-exception v1

    .line 128
    const-string v0, "Failed to launch assist overlay activity"

    .line 129
    .line 130
    invoke-static {v4, v0, v1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 131
    .line 132
    .line 133
    sget-object v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 134
    .line 135
    invoke-virtual {p0}, Landroid/service/voice/VoiceInteractionSession;->getContext()Landroid/content/Context;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    const/4 v0, 0x0

    .line 143
    invoke-virtual {v2, v1, v7, v0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 144
    .line 145
    .line 146
    return-void
.end method

.method public onTaskFinished(Landroid/content/Intent;I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->getIdentity()Lcom/facebook/aura/assist/AssistIdentityPresentation;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-boolean v1, v0, Lcom/facebook/aura/assist/AssistIdentityPresentation;->showingVoice:Z

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    if-ne v1, v0, :cond_0

    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/service/voice/VoiceInteractionSession;->onTaskFinished(Landroid/content/Intent;I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method
