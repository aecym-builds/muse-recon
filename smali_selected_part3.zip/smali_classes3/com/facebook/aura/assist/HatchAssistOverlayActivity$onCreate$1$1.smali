.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $isStartupComplete$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "Lcom/facebook/aura/assist/HatchAssistOverlayActivity;",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->$isStartupComplete$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 5

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object v4, p1

    .line 268435461
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435468
    .line 268435469
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435470
    .line 268435471
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;->$isStartupComplete$delegate:LX/16A;

    .line 268435472
    .line 268435473
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;

    .line 268435474
    .line 268435475
    invoke-direct {v1, v3, v2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;LX/16A;)V

    .line 268435476
    .line 268435477
    .line 268435478
    const v0, 0x35aeb5b2

    .line 268435479
    .line 268435480
    .line 268435481
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435482
    .line 268435483
    .line 268435484
    move-result-object v3

    .line 268435485
    const/16 p0, 0x180

    .line 268435486
    .line 268435487
    const/4 p1, 0x3

    .line 268435488
    const/4 v1, 0x0

    .line 268435489
    move-object v2, v1

    .line 268435490
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/vds/compose/theme/root/AuraRootKt;->AuraRoot(Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/vds/compose/theme/AuraColors;LX/JDN;LX/2d4;II)V

    .line 268435491
    .line 268435492
    .line 268435493
    return-void

    .line 268435494
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435495
    .line 268435496
    .line 268435497
    return-void
.end method
