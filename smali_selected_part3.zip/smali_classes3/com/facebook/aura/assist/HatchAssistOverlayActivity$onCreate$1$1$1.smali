.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $isStartupComplete$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "Lcom/facebook/aura/assist/HatchAssistOverlayActivity;",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->$isStartupComplete$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 7

    .line 268435456
    and-int/lit8 v0, p2, 0x3

    .line 268435457
    .line 268435458
    const/4 v5, 0x0

    .line 268435459
    const/4 v4, 0x2

    .line 268435460
    invoke-static {v0, v4}, LX/003;->A1H(II)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    if-eqz v0, :cond_4

    .line 268435469
    .line 268435470
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->$isStartupComplete$delegate:LX/16A;

    .line 268435471
    .line 268435472
    invoke-static {v0}, LX/16A;->A0C(LX/16A;)Z

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v0

    .line 268435476
    const/4 v3, 0x0

    .line 268435477
    if-eqz v0, :cond_1

    .line 268435478
    .line 268435479
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435480
    .line 268435481
    if-eqz v0, :cond_1

    .line 268435482
    .line 268435483
    const v0, 0x162cbb30

    .line 268435484
    .line 268435485
    .line 268435486
    invoke-static {p1, v0}, LX/003;->A0q(LX/2d4;I)V

    .line 268435487
    .line 268435488
    .line 268435489
    sget-object v2, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 268435490
    .line 268435491
    iget-object v6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435492
    .line 268435493
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 268435494
    .line 268435495
    const-string v0, "userSession"

    .line 268435496
    .line 268435497
    if-nez v1, :cond_0

    .line 268435498
    .line 268435499
    invoke-static {v0}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 268435500
    .line 268435501
    .line 268435502
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435503
    .line 268435504
    .line 268435505
    move-result-object v0

    .line 268435506
    throw v0

    .line 268435507
    :cond_0
    invoke-virtual {v2, v1}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 268435508
    .line 268435509
    .line 268435510
    move-result-object v4

    .line 268435511
    sget-object v0, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSessionOrNull:LX/Ip3;

    .line 268435512
    .line 268435513
    invoke-virtual {v0, v1}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 268435514
    .line 268435515
    .line 268435516
    move-result-object v3

    .line 268435517
    sget-object v1, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 268435518
    .line 268435519
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayNavigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 268435520
    .line 268435521
    invoke-virtual {v1, v0}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 268435522
    .line 268435523
    .line 268435524
    move-result-object v2

    .line 268435525
    sget-object v1, Lcom/facebook/aura/assist/AssistIdentityStateKt;->LocalAssistIdentityState:LX/Ip3;

    .line 268435526
    .line 268435527
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->identityState:Landroidx/compose/runtime/MutableState;

    .line 268435528
    .line 268435529
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435530
    .line 268435531
    .line 268435532
    move-result-object v0

    .line 268435533
    invoke-virtual {v1, v0}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 268435534
    .line 268435535
    .line 268435536
    move-result-object v1

    .line 268435537
    sget-object v0, Lcom/facebook/aura/widgets/api/WidgetRendererKt;->LocalWidgetHostCanOpenScreens:LX/Ip3;

    .line 268435538
    .line 268435539
    invoke-static {v0, v5}, LX/602;->A08(LX/Ip3;Z)LX/Ip4;

    .line 268435540
    .line 268435541
    .line 268435542
    move-result-object v0

    .line 268435543
    filled-new-array {v4, v3, v2, v1, v0}, [LX/Ip4;

    .line 268435544
    .line 268435545
    .line 268435546
    move-result-object v3

    .line 268435547
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435548
    .line 268435549
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435550
    .line 268435551
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;

    .line 268435552
    .line 268435553
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V

    .line 268435554
    .line 268435555
    .line 268435556
    const v0, -0x6b16570e

    .line 268435557
    .line 268435558
    .line 268435559
    invoke-static {p1, v1, v3, v0}, LX/003;->A0t(LX/2d4;Ljava/lang/Object;[LX/Ip4;I)V

    .line 268435560
    .line 268435561
    .line 268435562
    return-void

    .line 268435563
    :cond_1
    const v0, 0x162b1a81

    .line 268435564
    .line 268435565
    .line 268435566
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 268435567
    .line 268435568
    .line 268435569
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435570
    .line 268435571
    invoke-interface {p1, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435572
    .line 268435573
    .line 268435574
    move-result v1

    .line 268435575
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435576
    .line 268435577
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435578
    .line 268435579
    .line 268435580
    move-result-object v0

    .line 268435581
    if-nez v1, :cond_2

    .line 268435582
    .line 268435583
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435584
    .line 268435585
    if-ne v0, v1, :cond_3

    .line 268435586
    .line 268435587
    :cond_2
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$1$1;

    .line 268435588
    .line 268435589
    invoke-direct {v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 268435590
    .line 268435591
    .line 268435592
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435593
    .line 268435594
    .line 268435595
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435596
    .line 268435597
    invoke-static {v0, v3, p1, v5, v4}, Lcom/facebook/aura/assist/HatchAssistLoadingScreenKt;->HatchAssistLoadingScreen(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435598
    .line 268435599
    .line 268435600
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435601
    .line 268435602
    .line 268435603
    return-void

    .line 268435604
    :cond_4
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435605
    .line 268435606
    .line 268435607
    return-void
.end method
