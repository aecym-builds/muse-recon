.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$onCleared$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $appContext:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$onCleared$2;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->INSTANCE:Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$onCleared$2;->$appContext:Landroid/content/Context;

    .line 3
    .line 4
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    const-string v0, "assist"

    .line 8
    .line 9
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->evictExpired(Landroid/content/Context;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
