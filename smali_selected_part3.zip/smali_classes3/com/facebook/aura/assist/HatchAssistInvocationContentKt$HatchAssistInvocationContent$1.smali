.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/3C1;",
        "LX/JDN<",
        "-",
        "LX/2d4;",
        "-",
        "Ljava/lang/Integer;",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onCollapseVoice:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRequestPermission:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/JDN;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "LX/JDN<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onRequestPermission:LX/JDN;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onCollapseVoice:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    const/4 v0, 0x4

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static final invoke$lambda$0(LX/16A;)Lcom/facebook/aura/assist/AssistOverlayState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            ">;)",
            "Lcom/facebook/aura/assist/AssistOverlayState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final invoke$lambda$1(LX/16A;)Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;",
            ">;)",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/602;->A0K(LX/16A;)Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final invoke$lambda$2(LX/16A;)LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;>;)",
            "LX/Ddn<",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/602;->A14(LX/16A;)LX/Ddn;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final invoke$lambda$3(LX/16A;)Landroid/graphics/Bitmap;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Landroid/graphics/Bitmap;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Landroid/graphics/Bitmap;

    .line 5
    .line 6
    return-object p0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3C1;

    .line 1
    .line 2
    check-cast p2, LX/JDN;

    .line 3
    .line 4
    check-cast p3, LX/2d4;

    .line 5
    .line 6
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->invoke(LX/3C1;LX/JDN;LX/2d4;I)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v0
.end method

.method public final invoke(LX/3C1;LX/JDN;LX/2d4;I)V
    .locals 48
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 268435456
    const/16 v21, 0x0

    .line 268435457
    .line 268435458
    move-object/from16 v40, p1

    .line 268435459
    .line 268435460
    move-object/from16 v1, v40

    .line 268435461
    .line 268435462
    move/from16 v0, v21

    .line 268435463
    .line 268435464
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    and-int/lit8 v0, p4, 0x6

    .line 268435468
    .line 268435469
    move-object/from16 v2, p3

    .line 268435470
    .line 268435471
    if-nez v0, :cond_23

    .line 268435472
    .line 268435473
    invoke-static {v2, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435474
    .line 268435475
    .line 268435476
    move-result v0

    .line 268435477
    or-int v20, p4, v0

    .line 268435478
    .line 268435479
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 268435480
    .line 268435481
    move-object/from16 v46, p2

    .line 268435482
    .line 268435483
    if-nez v0, :cond_0

    .line 268435484
    .line 268435485
    move-object/from16 v0, v46

    .line 268435486
    .line 268435487
    invoke-static {v2, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 268435488
    .line 268435489
    .line 268435490
    move-result v0

    .line 268435491
    or-int v20, v20, v0

    .line 268435492
    .line 268435493
    :cond_0
    invoke-static/range {v20 .. v20}, LX/005;->A1I(I)Z

    .line 268435494
    .line 268435495
    .line 268435496
    move-result v1

    .line 268435497
    move/from16 v0, v20

    .line 268435498
    .line 268435499
    invoke-static {v1, v2, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435500
    .line 268435501
    .line 268435502
    move-result v0

    .line 268435503
    if-eqz v0, :cond_24

    .line 268435504
    .line 268435505
    invoke-static {v2}, LX/3Rr;->A06(LX/2d4;)Landroid/content/Context;

    .line 268435506
    .line 268435507
    .line 268435508
    move-result-object v19

    .line 268435509
    invoke-static {v2}, LX/602;->A0S(LX/2d4;)LX/AHE;

    .line 268435510
    .line 268435511
    .line 268435512
    move-result-object v18

    .line 268435513
    move-object/from16 v6, p0

    .line 268435514
    .line 268435515
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435516
    .line 268435517
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->overlayState:LX/2J3;

    .line 268435518
    .line 268435519
    move/from16 v0, v21

    .line 268435520
    .line 268435521
    invoke-static {v2, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 268435522
    .line 268435523
    .line 268435524
    move-result-object v13

    .line 268435525
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435526
    .line 268435527
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435528
    .line 268435529
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->uiState:LX/2J3;

    .line 268435530
    .line 268435531
    move/from16 v0, v21

    .line 268435532
    .line 268435533
    invoke-static {v2, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 268435534
    .line 268435535
    .line 268435536
    move-result-object v12

    .line 268435537
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435538
    .line 268435539
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435540
    .line 268435541
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->listItems:LX/2J3;

    .line 268435542
    .line 268435543
    move/from16 v0, v21

    .line 268435544
    .line 268435545
    invoke-static {v2, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 268435546
    .line 268435547
    .line 268435548
    move-result-object v11

    .line 268435549
    sget-object v1, Lcom/facebook/aura/assist/HatchAssistContextHolder;->screenshot:LX/2J3;

    .line 268435550
    .line 268435551
    invoke-static {v2, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 268435552
    .line 268435553
    .line 268435554
    move-result-object v10

    .line 268435555
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435556
    .line 268435557
    iget-object v0, v1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435558
    .line 268435559
    iget-object v9, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 268435560
    .line 268435561
    sget-object v25, Lcom/facebook/aura/composer/api/DictationMode;->AUTO_SUBMIT:Lcom/facebook/aura/composer/api/DictationMode;

    .line 268435562
    .line 268435563
    sget-object v26, Lcom/facebook/aura/composer/api/view/DictationFeedbackStyle;->OVERLAY:Lcom/facebook/aura/composer/api/view/DictationFeedbackStyle;

    .line 268435564
    .line 268435565
    iget-object v8, v1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->micFocusRequests:LX/2Lw;

    .line 268435566
    .line 268435567
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435568
    .line 268435569
    .line 268435570
    move-result v0

    .line 268435571
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435572
    .line 268435573
    .line 268435574
    move-result-object v7

    .line 268435575
    if-nez v0, :cond_1

    .line 268435576
    .line 268435577
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435578
    .line 268435579
    if-ne v7, v0, :cond_2

    .line 268435580
    .line 268435581
    :cond_1
    new-instance v7, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$1$1;

    .line 268435582
    .line 268435583
    invoke-direct {v7, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$1$1;-><init>(Ljava/lang/Object;)V

    .line 268435584
    .line 268435585
    .line 268435586
    invoke-interface {v2, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435587
    .line 268435588
    .line 268435589
    :cond_2
    check-cast v7, LX/DqV;

    .line 268435590
    .line 268435591
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435592
    .line 268435593
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435594
    .line 268435595
    .line 268435596
    move-result v0

    .line 268435597
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435598
    .line 268435599
    .line 268435600
    move-result-object v5

    .line 268435601
    if-nez v0, :cond_3

    .line 268435602
    .line 268435603
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435604
    .line 268435605
    if-ne v5, v0, :cond_4

    .line 268435606
    .line 268435607
    :cond_3
    new-instance v5, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$2$1;

    .line 268435608
    .line 268435609
    invoke-direct {v5, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$2$1;-><init>(Ljava/lang/Object;)V

    .line 268435610
    .line 268435611
    .line 268435612
    invoke-interface {v2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435613
    .line 268435614
    .line 268435615
    :cond_4
    check-cast v5, LX/DqV;

    .line 268435616
    .line 268435617
    move-object/from16 v0, v19

    .line 268435618
    .line 268435619
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435620
    .line 268435621
    .line 268435622
    move-result v1

    .line 268435623
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435624
    .line 268435625
    invoke-static {v2, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435626
    .line 268435627
    .line 268435628
    move-result v1

    .line 268435629
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onRequestPermission:LX/JDN;

    .line 268435630
    .line 268435631
    invoke-static {v2, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435632
    .line 268435633
    .line 268435634
    move-result v0

    .line 268435635
    iget-object v4, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435636
    .line 268435637
    iget-object v3, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onRequestPermission:LX/JDN;

    .line 268435638
    .line 268435639
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435640
    .line 268435641
    .line 268435642
    move-result-object v1

    .line 268435643
    if-nez v0, :cond_5

    .line 268435644
    .line 268435645
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435646
    .line 268435647
    if-ne v1, v0, :cond_6

    .line 268435648
    .line 268435649
    :cond_5
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;

    .line 268435650
    .line 268435651
    move-object/from16 v0, v19

    .line 268435652
    .line 268435653
    invoke-direct {v1, v0, v4, v3}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;-><init>(Landroid/content/Context;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/JDN;)V

    .line 268435654
    .line 268435655
    .line 268435656
    invoke-interface {v2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435657
    .line 268435658
    .line 268435659
    :cond_6
    check-cast v1, LX/JDM;

    .line 268435660
    .line 268435661
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 268435662
    .line 268435663
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 268435664
    .line 268435665
    const/16 v31, 0x6c00

    .line 268435666
    .line 268435667
    const/16 v32, 0x20

    .line 268435668
    .line 268435669
    move/from16 v27, v21

    .line 268435670
    .line 268435671
    move-object/from16 v28, v8

    .line 268435672
    .line 268435673
    move-object/from16 v29, v5

    .line 268435674
    .line 268435675
    move-object/from16 v30, v2

    .line 268435676
    .line 268435677
    move-object/from16 v22, v9

    .line 268435678
    .line 268435679
    move-object/from16 v23, v1

    .line 268435680
    .line 268435681
    move-object/from16 v24, v7

    .line 268435682
    .line 268435683
    invoke-static/range {v22 .. v32}, Lcom/facebook/aura/composer/api/view/ComposerDictationUisKt;->rememberComposerDictationUi(Lcom/facebook/aura/composer/api/ComposerDictation;LX/JDM;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/DictationMode;Lcom/facebook/aura/composer/api/view/DictationFeedbackStyle;ZLX/2Lw;Lkotlin/jvm/functions/Function0;LX/2d4;II)Lcom/facebook/aura/composer/api/view/ComposerDictationUi;

    .line 268435684
    .line 268435685
    .line 268435686
    move-result-object v39

    .line 268435687
    invoke-interface {v13}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435688
    .line 268435689
    .line 268435690
    move-result-object v22

    .line 268435691
    check-cast v22, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435692
    .line 268435693
    invoke-static {v12}, LX/602;->A0K(LX/16A;)Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 268435694
    .line 268435695
    .line 268435696
    move-result-object v23

    .line 268435697
    invoke-static {v11}, LX/602;->A14(LX/16A;)LX/Ddn;

    .line 268435698
    .line 268435699
    .line 268435700
    move-result-object v24

    .line 268435701
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435702
    .line 268435703
    .line 268435704
    move-result-object v41

    .line 268435705
    check-cast v41, Landroid/graphics/Bitmap;

    .line 268435706
    .line 268435707
    iget-object v3, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435708
    .line 268435709
    iget-object v0, v3, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435710
    .line 268435711
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->composerTextState:LX/3QE;

    .line 268435712
    .line 268435713
    move-object/from16 v29, v0

    .line 268435714
    .line 268435715
    invoke-interface {v2, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435716
    .line 268435717
    .line 268435718
    move-result v0

    .line 268435719
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435720
    .line 268435721
    .line 268435722
    move-result-object v17

    .line 268435723
    if-nez v0, :cond_7

    .line 268435724
    .line 268435725
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435726
    .line 268435727
    move-object/from16 v0, v17

    .line 268435728
    .line 268435729
    if-ne v0, v1, :cond_8

    .line 268435730
    .line 268435731
    :cond_7
    new-instance v17, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$1$1;

    .line 268435732
    .line 268435733
    move-object/from16 v0, v17

    .line 268435734
    .line 268435735
    invoke-direct {v0, v3}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$1$1;-><init>(Ljava/lang/Object;)V

    .line 268435736
    .line 268435737
    .line 268435738
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435739
    .line 268435740
    .line 268435741
    :cond_8
    check-cast v17, LX/DqV;

    .line 268435742
    .line 268435743
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435744
    .line 268435745
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435746
    .line 268435747
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435748
    .line 268435749
    .line 268435750
    move-result v0

    .line 268435751
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435752
    .line 268435753
    .line 268435754
    move-result-object v15

    .line 268435755
    if-nez v0, :cond_9

    .line 268435756
    .line 268435757
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435758
    .line 268435759
    if-ne v15, v0, :cond_a

    .line 268435760
    .line 268435761
    :cond_9
    new-instance v15, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$2$1;

    .line 268435762
    .line 268435763
    invoke-direct {v15, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$2$1;-><init>(Ljava/lang/Object;)V

    .line 268435764
    .line 268435765
    .line 268435766
    invoke-interface {v2, v15}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435767
    .line 268435768
    .line 268435769
    :cond_a
    check-cast v15, LX/DqV;

    .line 268435770
    .line 268435771
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435772
    .line 268435773
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435774
    .line 268435775
    .line 268435776
    move-result v0

    .line 268435777
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435778
    .line 268435779
    .line 268435780
    move-result-object v14

    .line 268435781
    if-nez v0, :cond_b

    .line 268435782
    .line 268435783
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435784
    .line 268435785
    if-ne v14, v0, :cond_c

    .line 268435786
    .line 268435787
    :cond_b
    new-instance v14, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$3$1;

    .line 268435788
    .line 268435789
    invoke-direct {v14, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$3$1;-><init>(Ljava/lang/Object;)V

    .line 268435790
    .line 268435791
    .line 268435792
    invoke-interface {v2, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435793
    .line 268435794
    .line 268435795
    :cond_c
    check-cast v14, LX/DqV;

    .line 268435796
    .line 268435797
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435798
    .line 268435799
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435800
    .line 268435801
    .line 268435802
    move-result v0

    .line 268435803
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435804
    .line 268435805
    .line 268435806
    move-result-object v13

    .line 268435807
    if-nez v0, :cond_d

    .line 268435808
    .line 268435809
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435810
    .line 268435811
    if-ne v13, v0, :cond_e

    .line 268435812
    .line 268435813
    :cond_d
    new-instance v13, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$4$1;

    .line 268435814
    .line 268435815
    invoke-direct {v13, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$4$1;-><init>(Ljava/lang/Object;)V

    .line 268435816
    .line 268435817
    .line 268435818
    invoke-interface {v2, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435819
    .line 268435820
    .line 268435821
    :cond_e
    check-cast v13, LX/DqV;

    .line 268435822
    .line 268435823
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435824
    .line 268435825
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435826
    .line 268435827
    .line 268435828
    move-result v0

    .line 268435829
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435830
    .line 268435831
    .line 268435832
    move-result-object v12

    .line 268435833
    if-nez v0, :cond_f

    .line 268435834
    .line 268435835
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435836
    .line 268435837
    if-ne v12, v0, :cond_10

    .line 268435838
    .line 268435839
    :cond_f
    new-instance v12, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$5$1;

    .line 268435840
    .line 268435841
    invoke-direct {v12, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$5$1;-><init>(Ljava/lang/Object;)V

    .line 268435842
    .line 268435843
    .line 268435844
    invoke-interface {v2, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435845
    .line 268435846
    .line 268435847
    :cond_10
    check-cast v12, LX/DqV;

    .line 268435848
    .line 268435849
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435850
    .line 268435851
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435852
    .line 268435853
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435854
    .line 268435855
    .line 268435856
    move-result v0

    .line 268435857
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435858
    .line 268435859
    .line 268435860
    move-result-object v11

    .line 268435861
    if-nez v0, :cond_11

    .line 268435862
    .line 268435863
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435864
    .line 268435865
    if-ne v11, v0, :cond_12

    .line 268435866
    .line 268435867
    :cond_11
    new-instance v11, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$6$1;

    .line 268435868
    .line 268435869
    invoke-direct {v11, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$6$1;-><init>(Ljava/lang/Object;)V

    .line 268435870
    .line 268435871
    .line 268435872
    invoke-interface {v2, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435873
    .line 268435874
    .line 268435875
    :cond_12
    check-cast v11, LX/DqV;

    .line 268435876
    .line 268435877
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435878
    .line 268435879
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435880
    .line 268435881
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435882
    .line 268435883
    .line 268435884
    move-result v0

    .line 268435885
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435886
    .line 268435887
    .line 268435888
    move-result-object v7

    .line 268435889
    if-nez v0, :cond_13

    .line 268435890
    .line 268435891
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435892
    .line 268435893
    if-ne v7, v0, :cond_14

    .line 268435894
    .line 268435895
    :cond_13
    new-instance v7, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$7$1;

    .line 268435896
    .line 268435897
    invoke-direct {v7, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$7$1;-><init>(Ljava/lang/Object;)V

    .line 268435898
    .line 268435899
    .line 268435900
    invoke-interface {v2, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435901
    .line 268435902
    .line 268435903
    :cond_14
    check-cast v7, LX/DqV;

    .line 268435904
    .line 268435905
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435906
    .line 268435907
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435908
    .line 268435909
    .line 268435910
    move-result v0

    .line 268435911
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435912
    .line 268435913
    .line 268435914
    move-result-object v5

    .line 268435915
    if-nez v0, :cond_15

    .line 268435916
    .line 268435917
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435918
    .line 268435919
    if-ne v5, v0, :cond_16

    .line 268435920
    .line 268435921
    :cond_15
    new-instance v5, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$8$1;

    .line 268435922
    .line 268435923
    invoke-direct {v5, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$8$1;-><init>(Ljava/lang/Object;)V

    .line 268435924
    .line 268435925
    .line 268435926
    invoke-interface {v2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435927
    .line 268435928
    .line 268435929
    :cond_16
    check-cast v5, LX/DqV;

    .line 268435930
    .line 268435931
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435932
    .line 268435933
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435934
    .line 268435935
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435936
    .line 268435937
    .line 268435938
    move-result v1

    .line 268435939
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435940
    .line 268435941
    .line 268435942
    move-result-object v4

    .line 268435943
    if-nez v1, :cond_17

    .line 268435944
    .line 268435945
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435946
    .line 268435947
    if-ne v4, v1, :cond_18

    .line 268435948
    .line 268435949
    :cond_17
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$9$1;

    .line 268435950
    .line 268435951
    invoke-direct {v4, v0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$9$1;-><init>(Ljava/lang/Object;)V

    .line 268435952
    .line 268435953
    .line 268435954
    invoke-interface {v2, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435955
    .line 268435956
    .line 268435957
    :cond_18
    check-cast v4, LX/DqV;

    .line 268435958
    .line 268435959
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435960
    .line 268435961
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435962
    .line 268435963
    invoke-interface {v2, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435964
    .line 268435965
    .line 268435966
    move-result v0

    .line 268435967
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435968
    .line 268435969
    .line 268435970
    move-result-object v3

    .line 268435971
    if-nez v0, :cond_19

    .line 268435972
    .line 268435973
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435974
    .line 268435975
    if-ne v3, v0, :cond_1a

    .line 268435976
    .line 268435977
    :cond_19
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$10$1;

    .line 268435978
    .line 268435979
    invoke-direct {v3, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$10$1;-><init>(Ljava/lang/Object;)V

    .line 268435980
    .line 268435981
    .line 268435982
    invoke-interface {v2, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435983
    .line 268435984
    .line 268435985
    :cond_1a
    check-cast v3, LX/DqV;

    .line 268435986
    .line 268435987
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435988
    .line 268435989
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435990
    .line 268435991
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->announcement:LX/2Lw;

    .line 268435992
    .line 268435993
    move-object/from16 v28, v0

    .line 268435994
    .line 268435995
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268435996
    .line 268435997
    move-object/from16 v25, v0

    .line 268435998
    .line 268435999
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268436000
    .line 268436001
    move-object/from16 v26, v0

    .line 268436002
    .line 268436003
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$onCollapseVoice:Lkotlin/jvm/functions/Function0;

    .line 268436004
    .line 268436005
    move-object/from16 v27, v0

    .line 268436006
    .line 268436007
    move-object/from16 v1, v18

    .line 268436008
    .line 268436009
    move-object/from16 v0, v19

    .line 268436010
    .line 268436011
    invoke-static {v2, v1, v0}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268436012
    .line 268436013
    .line 268436014
    move-result v0

    .line 268436015
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436016
    .line 268436017
    invoke-static {v2, v1, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268436018
    .line 268436019
    .line 268436020
    move-result v0

    .line 268436021
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436022
    .line 268436023
    invoke-static {v2, v1, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268436024
    .line 268436025
    .line 268436026
    move-result v1

    .line 268436027
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436028
    .line 268436029
    move-object v9, v0

    .line 268436030
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436031
    .line 268436032
    move-object v8, v0

    .line 268436033
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268436034
    .line 268436035
    .line 268436036
    move-result-object v16

    .line 268436037
    if-nez v1, :cond_1b

    .line 268436038
    .line 268436039
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268436040
    .line 268436041
    move-object/from16 v0, v16

    .line 268436042
    .line 268436043
    if-ne v0, v1, :cond_1c

    .line 268436044
    .line 268436045
    :cond_1b
    new-instance v16, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;

    .line 268436046
    .line 268436047
    move-object/from16 v10, v18

    .line 268436048
    .line 268436049
    move-object/from16 v1, v16

    .line 268436050
    .line 268436051
    move-object/from16 v0, v19

    .line 268436052
    .line 268436053
    invoke-direct {v1, v10, v0, v9, v8}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;-><init>(LX/AHE;Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V

    .line 268436054
    .line 268436055
    .line 268436056
    invoke-interface {v2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268436057
    .line 268436058
    .line 268436059
    :cond_1c
    check-cast v16, Lkotlin/jvm/functions/Function0;

    .line 268436060
    .line 268436061
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436062
    .line 268436063
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268436064
    .line 268436065
    .line 268436066
    move-result v1

    .line 268436067
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436068
    .line 268436069
    invoke-static {v2, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268436070
    .line 268436071
    .line 268436072
    move-result v1

    .line 268436073
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436074
    .line 268436075
    move-object v10, v0

    .line 268436076
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436077
    .line 268436078
    move-object v8, v0

    .line 268436079
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268436080
    .line 268436081
    .line 268436082
    move-result-object v9

    .line 268436083
    if-nez v1, :cond_1d

    .line 268436084
    .line 268436085
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268436086
    .line 268436087
    if-ne v9, v0, :cond_1e

    .line 268436088
    .line 268436089
    :cond_1d
    new-instance v9, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$12$1;

    .line 268436090
    .line 268436091
    invoke-direct {v9, v10, v8}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$12$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;)V

    .line 268436092
    .line 268436093
    .line 268436094
    invoke-interface {v2, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268436095
    .line 268436096
    .line 268436097
    :cond_1e
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 268436098
    .line 268436099
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436100
    .line 268436101
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268436102
    .line 268436103
    .line 268436104
    move-result v0

    .line 268436105
    iget-object v1, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436106
    .line 268436107
    invoke-static {v2, v1, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268436108
    .line 268436109
    .line 268436110
    move-result v1

    .line 268436111
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436112
    .line 268436113
    move-object/from16 v18, v0

    .line 268436114
    .line 268436115
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$threadId:Ljava/lang/String;

    .line 268436116
    .line 268436117
    move-object v10, v0

    .line 268436118
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268436119
    .line 268436120
    .line 268436121
    move-result-object v8

    .line 268436122
    if-nez v1, :cond_1f

    .line 268436123
    .line 268436124
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268436125
    .line 268436126
    if-ne v8, v0, :cond_20

    .line 268436127
    .line 268436128
    :cond_1f
    new-instance v8, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$13$1;

    .line 268436129
    .line 268436130
    move-object/from16 v1, v18

    .line 268436131
    .line 268436132
    invoke-direct {v8, v1, v10}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$13$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;)V

    .line 268436133
    .line 268436134
    .line 268436135
    invoke-interface {v2, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268436136
    .line 268436137
    .line 268436138
    :cond_20
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 268436139
    .line 268436140
    check-cast v17, LX/JDM;

    .line 268436141
    .line 268436142
    check-cast v15, LX/JDO;

    .line 268436143
    .line 268436144
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 268436145
    .line 268436146
    check-cast v5, LX/JDM;

    .line 268436147
    .line 268436148
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 268436149
    .line 268436150
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 268436151
    .line 268436152
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436153
    .line 268436154
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268436155
    .line 268436156
    .line 268436157
    move-result v1

    .line 268436158
    iget-object v0, v6, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268436159
    .line 268436160
    move-object v6, v0

    .line 268436161
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268436162
    .line 268436163
    .line 268436164
    move-result-object v0

    .line 268436165
    if-nez v1, :cond_21

    .line 268436166
    .line 268436167
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268436168
    .line 268436169
    if-ne v0, v1, :cond_22

    .line 268436170
    .line 268436171
    :cond_21
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$14$1;

    .line 268436172
    .line 268436173
    invoke-direct {v0, v6}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$14$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V

    .line 268436174
    .line 268436175
    .line 268436176
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268436177
    .line 268436178
    .line 268436179
    :cond_22
    check-cast v0, LX/JDM;

    .line 268436180
    .line 268436181
    check-cast v14, LX/JDM;

    .line 268436182
    .line 268436183
    check-cast v13, Lkotlin/jvm/functions/Function0;

    .line 268436184
    .line 268436185
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 268436186
    .line 268436187
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 268436188
    .line 268436189
    sget p1, Lcom/facebook/aura/assist/AssistOverlayState;->$stable:I

    .line 268436190
    .line 268436191
    sget v1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->$stable:I

    .line 268436192
    .line 268436193
    shl-int/lit8 v1, v1, 0x3

    .line 268436194
    .line 268436195
    or-int p1, p1, v1

    .line 268436196
    .line 268436197
    shl-int/lit8 p2, v20, 0x18

    .line 268436198
    .line 268436199
    const/high16 v1, 0xe000000

    .line 268436200
    .line 268436201
    and-int p2, p2, v1

    .line 268436202
    .line 268436203
    shl-int/lit8 p3, v20, 0x9

    .line 268436204
    .line 268436205
    const v1, 0xe000

    .line 268436206
    .line 268436207
    .line 268436208
    and-int p3, p3, v1

    .line 268436209
    .line 268436210
    move-object/from16 v30, v9

    .line 268436211
    .line 268436212
    move-object/from16 v31, v8

    .line 268436213
    .line 268436214
    move-object/from16 v32, v17

    .line 268436215
    .line 268436216
    move-object/from16 v33, v15

    .line 268436217
    .line 268436218
    move-object/from16 v34, v28

    .line 268436219
    .line 268436220
    move-object/from16 v35, v7

    .line 268436221
    .line 268436222
    move-object/from16 v36, v5

    .line 268436223
    .line 268436224
    move-object/from16 v37, v4

    .line 268436225
    .line 268436226
    move-object/from16 v38, v3

    .line 268436227
    .line 268436228
    move-object/from16 v42, v0

    .line 268436229
    .line 268436230
    move-object/from16 v43, v14

    .line 268436231
    .line 268436232
    move-object/from16 v44, v13

    .line 268436233
    .line 268436234
    move-object/from16 v45, v12

    .line 268436235
    .line 268436236
    move-object/from16 v47, v11

    .line 268436237
    .line 268436238
    move-object/from16 p0, v2

    .line 268436239
    .line 268436240
    move/from16 p4, v21

    .line 268436241
    .line 268436242
    move-object/from16 v28, v16

    .line 268436243
    .line 268436244
    invoke-static/range {v22 .. v52}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->HatchAssistOverlayScreen(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/Ddn;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3QE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDO;LX/2Lw;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;LX/3C1;Landroid/graphics/Bitmap;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;LX/2d4;IIII)V

    .line 268436245
    .line 268436246
    .line 268436247
    return-void

    .line 268436248
    :cond_23
    move/from16 v20, p4

    .line 268436249
    .line 268436250
    goto/16 :goto_0

    .line 268436251
    .line 268436252
    :cond_24
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 268436253
    .line 268436254
    .line 268436255
    return-void
.end method
