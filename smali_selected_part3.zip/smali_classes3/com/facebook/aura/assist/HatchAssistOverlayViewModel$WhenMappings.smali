.class public abstract synthetic Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    invoke-static {}, Lcom/facebook/aura/assist/AssistOverlayPhase;->values()[Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    :try_start_0
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 8
    .line 9
    invoke-static {v0, v1}, LX/007;->A1G(Ljava/lang/Enum;[I)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    .line 12
    :catch_0
    :try_start_1
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A1H(Ljava/lang/Enum;[I)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 15
    .line 16
    .line 17
    :catch_1
    :try_start_2
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 18
    .line 19
    invoke-static {v0, v1}, LX/007;->A1I(Ljava/lang/Enum;[I)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 20
    .line 21
    .line 22
    :catch_2
    :try_start_3
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 23
    .line 24
    invoke-static {v0, v1}, LX/007;->A1J(Ljava/lang/Enum;[I)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 25
    .line 26
    .line 27
    :catch_3
    :try_start_4
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->ERROR:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 28
    .line 29
    invoke-static {v0, v1}, LX/007;->A1K(Ljava/lang/Enum;[I)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 30
    .line 31
    .line 32
    :catch_4
    sput-object v1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 33
    .line 34
    return-void
.end method
