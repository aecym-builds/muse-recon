.class public final Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $identityState:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $identityVisible:Z

.field public final synthetic $layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOpenApp:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/assist/AssistIdentityState;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Lcom/facebook/aura/assist/AssistVoiceLayout;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$threadId:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$identityVisible:Z

    .line 13
    .line 14
    const/4 v0, 0x2

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 13

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object v12, p1

    .line 268435461
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    sget-object v9, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 268435468
    .line 268435469
    sget-object v10, LX/2sI;->A01:LX/2wD;

    .line 268435470
    .line 268435471
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435472
    .line 268435473
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 268435474
    .line 268435475
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435476
    .line 268435477
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435478
    .line 268435479
    iget-object v6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$threadId:Ljava/lang/String;

    .line 268435480
    .line 268435481
    iget-object v7, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 268435482
    .line 268435483
    iget-boolean v8, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;->$identityVisible:Z

    .line 268435484
    .line 268435485
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;

    .line 268435486
    .line 268435487
    invoke-direct/range {v1 .. v8}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/assist/AssistIdentityState;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V

    .line 268435488
    .line 268435489
    .line 268435490
    const v0, -0x4594a099

    .line 268435491
    .line 268435492
    .line 268435493
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435494
    .line 268435495
    .line 268435496
    move-result-object v11

    .line 268435497
    const/16 p0, 0x1b6

    .line 268435498
    .line 268435499
    const/4 p1, 0x0

    .line 268435500
    invoke-virtual/range {v9 .. v14}, Lcom/facebook/aura/assist/api/AssistCalls;->EmbodimentHost(LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 268435501
    .line 268435502
    .line 268435503
    return-void

    .line 268435504
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435505
    .line 268435506
    .line 268435507
    return-void
.end method
