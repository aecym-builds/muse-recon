.class public final synthetic Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$3$1;
.super LX/DVE;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "LX/JDN<",
        "Ljava/lang/String;",
        "Lkotlin/jvm/functions/Function0<",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 0
    const-class v3, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    const-string v5, "requestPermissionThenRun(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V"

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    const/4 v1, 0x2

    .line 6
    const-string v4, "requestPermissionThenRun"

    .line 7
    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/lang/String;

    .line 1
    .line 2
    check-cast p2, Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1$1$3$1;->invoke(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    iget-object p0, p0, LX/DqR;->receiver:Ljava/lang/Object;

    .line 268435460
    .line 268435461
    check-cast p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435462
    .line 268435463
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->access$requestPermissionThenRun(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 268435464
    .line 268435465
    .line 268435466
    return-void
.end method
