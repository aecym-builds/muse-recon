.class public final Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $identityState:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $identityVisible:Z

.field public final synthetic $layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOpenApp:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/assist/AssistIdentityState;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Lcom/facebook/aura/assist/AssistVoiceLayout;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$threadId:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityVisible:Z

    .line 13
    .line 14
    const/4 v0, 0x3

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/33K;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->invoke(LX/33K;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 11

    .line 268435456
    and-int/lit8 v1, p3, 0x11

    .line 268435457
    .line 268435458
    const/16 v0, 0x10

    .line 268435459
    .line 268435460
    const/4 v9, 0x0

    .line 268435461
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object v8, p2

    .line 268435466
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435467
    .line 268435468
    .line 268435469
    move-result v0

    .line 268435470
    if-eqz v0, :cond_5

    .line 268435471
    .line 268435472
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435473
    .line 268435474
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistVoicePresentation;->getShowingVoice()Z

    .line 268435475
    .line 268435476
    .line 268435477
    move-result v0

    .line 268435478
    if-eqz v0, :cond_4

    .line 268435479
    .line 268435480
    const v0, -0x2aec1d18

    .line 268435481
    .line 268435482
    .line 268435483
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435484
    .line 268435485
    .line 268435486
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435487
    .line 268435488
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 268435489
    .line 268435490
    iget-object v6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435491
    .line 268435492
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 268435493
    .line 268435494
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435495
    .line 268435496
    invoke-interface {p2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435497
    .line 268435498
    .line 268435499
    move-result v1

    .line 268435500
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435501
    .line 268435502
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435503
    .line 268435504
    .line 268435505
    move-result-object v0

    .line 268435506
    if-nez v1, :cond_0

    .line 268435507
    .line 268435508
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435509
    .line 268435510
    if-ne v0, v1, :cond_1

    .line 268435511
    .line 268435512
    :cond_0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1$1$1;

    .line 268435513
    .line 268435514
    invoke-direct {v0, v2}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1$1$1;-><init>(Lcom/facebook/aura/assist/AssistIdentityState;)V

    .line 268435515
    .line 268435516
    .line 268435517
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435518
    .line 268435519
    .line 268435520
    :cond_1
    invoke-static {v3, v0}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 268435521
    .line 268435522
    .line 268435523
    move-result-object v2

    .line 268435524
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435525
    .line 268435526
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->getPhase()Lcom/facebook/aura/assist/AssistIdentityPhase;

    .line 268435527
    .line 268435528
    .line 268435529
    move-result-object v1

    .line 268435530
    sget-object v0, Lcom/facebook/aura/assist/AssistIdentityPhase;->EXPANDED:Lcom/facebook/aura/assist/AssistIdentityPhase;

    .line 268435531
    .line 268435532
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435533
    .line 268435534
    .line 268435535
    move-result v0

    .line 268435536
    invoke-static {v2, v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->assistComposerInteraction(LX/3C1;Z)LX/3C1;

    .line 268435537
    .line 268435538
    .line 268435539
    move-result-object v7

    .line 268435540
    move v10, v9

    .line 268435541
    invoke-static/range {v4 .. v10}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt;->HatchAssistVoiceCall(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435542
    .line 268435543
    .line 268435544
    :goto_0
    move-object v0, v8

    .line 268435545
    check-cast v0, LX/J7I;

    .line 268435546
    .line 268435547
    const/4 v7, 0x0

    .line 268435548
    invoke-static {v0, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435549
    .line 268435550
    .line 268435551
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435552
    .line 268435553
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 268435554
    .line 268435555
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$threadId:Ljava/lang/String;

    .line 268435556
    .line 268435557
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 268435558
    .line 268435559
    iget-boolean v0, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2$1;->$identityVisible:Z

    .line 268435560
    .line 268435561
    if-nez v0, :cond_2

    .line 268435562
    .line 268435563
    invoke-virtual {v1}, Lcom/facebook/aura/assist/AssistVoicePresentation;->getShowingVoice()Z

    .line 268435564
    .line 268435565
    .line 268435566
    move-result v0

    .line 268435567
    if-eqz v0, :cond_3

    .line 268435568
    .line 268435569
    :cond_2
    const/4 v9, 0x1

    .line 268435570
    :cond_3
    move v5, v9

    .line 268435571
    move-object v6, p2

    .line 268435572
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/assist/HatchAssistPresentationKt;->AssistIdentityPresentationEffect(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2d4;I)V

    .line 268435573
    .line 268435574
    .line 268435575
    return-void

    .line 268435576
    :cond_4
    const v0, -0x2ae63445

    .line 268435577
    .line 268435578
    .line 268435579
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435580
    .line 268435581
    .line 268435582
    goto :goto_0

    .line 268435583
    :cond_5
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435584
    .line 268435585
    .line 268435586
    return-void
.end method
