.class public final Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/3B6;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $child:LX/3B5;

.field public final synthetic $layout:Lcom/facebook/aura/assist/AssistVoiceLayout;


# direct methods
.method public constructor <init>(LX/3B5;Lcom/facebook/aura/assist/AssistVoiceLayout;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;->$child:LX/3B5;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/3B6;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;->invoke(LX/3B6;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/3B6;)V
    .locals 5

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;->$child:LX/3B5;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 7
    .line 8
    iget v2, v0, Lcom/facebook/aura/assist/AssistVoiceLayout;->controlsTop:F

    .line 9
    .line 10
    iget v0, v3, LX/3B5;->A00:I

    .line 11
    .line 12
    int-to-float v0, v0

    .line 13
    sub-float/2addr v2, v0

    .line 14
    const/high16 v1, 0x41400000    # 12.0f

    .line 15
    .line 16
    invoke-interface {p1}, LX/34Y;->AEu()F

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    mul-float/2addr v1, v0

    .line 21
    sub-float/2addr v2, v1

    .line 22
    invoke-static {v2}, LX/0sc;->A01(F)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-ge v1, v4, :cond_0

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    :cond_0
    const/4 v0, 0x0

    .line 30
    invoke-virtual {p1, v3, v0, v4, v1}, LX/3B6;->A0A(LX/3B5;FII)V

    .line 31
    .line 32
    .line 33
    return-void
.end method
