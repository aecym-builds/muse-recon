.class public final Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/7TA<",
        "Ljava/lang/Boolean;",
        ">;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/DwR<",
        "Ljava/lang/Float;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(LX/7TA;LX/2d4;I)LX/DwR;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/7TA<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2d4;",
            "I)",
            "LX/DwR<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    const v0, 0x7d6e5c6

    .line 268435461
    .line 268435462
    .line 268435463
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435464
    .line 268435465
    .line 268435466
    invoke-interface {p1}, LX/7TA;->ALa()Ljava/lang/Object;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v0

    .line 268435474
    if-eqz v0, :cond_0

    .line 268435475
    .line 268435476
    sget-object v1, LX/33X;->A01:LX/1V8;

    .line 268435477
    .line 268435478
    :goto_0
    const/16 v0, 0x15e

    .line 268435479
    .line 268435480
    invoke-static {v1, v0, p0}, LX/001;->A0S(LX/1V8;II)LX/E1b;

    .line 268435481
    .line 268435482
    .line 268435483
    move-result-object v0

    .line 268435484
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435485
    .line 268435486
    .line 268435487
    return-object v0

    .line 268435488
    :cond_0
    sget-object v1, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->reverseVoiceEasing:LX/1V8;

    .line 268435489
    .line 268435490
    goto :goto_0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/7TA;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$progress$1;->invoke(LX/7TA;LX/2d4;I)LX/DwR;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
