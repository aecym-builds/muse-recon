.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.assist.HatchAssistOverlayViewModel$submitCurrentInput$3"
    f = "HatchAssistOverlayViewModel.kt"
    l = {
        0x178,
        0x188
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->label:I

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    const/4 v4, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    if-eq v0, v3, :cond_2

    .line 10
    .line 11
    if-ne v0, v4, :cond_9

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    :goto_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    return-object v5

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->INSTANCE:Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 25
    .line 26
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->getGateway(LX/AHE;)Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    iget-object v0, v1, Lcom/facebook/aura/gateway/HatchGatewayConnection;->connectionState:LX/2J3;

    .line 33
    .line 34
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    instance-of v0, v0, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Connected;

    .line 39
    .line 40
    if-nez v0, :cond_8

    .line 41
    .line 42
    new-instance v2, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;

    .line 43
    .line 44
    invoke-direct {v2, v1, v6}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;-><init>(Lcom/facebook/aura/gateway/HatchGatewayConnection;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    iput-object v6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->L$0:Ljava/lang/Object;

    .line 48
    .line 49
    iput v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->label:I

    .line 50
    .line 51
    const-wide/16 v0, 0x2710

    .line 52
    .line 53
    invoke-static {p0, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-ne p1, v5, :cond_3

    .line 58
    .line 59
    return-object v5

    .line 60
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :cond_3
    check-cast p1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState;

    .line 64
    .line 65
    if-eqz p1, :cond_4

    .line 66
    .line 67
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;

    .line 68
    .line 69
    if-eqz v0, :cond_8

    .line 70
    .line 71
    :cond_4
    check-cast p1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;

    .line 72
    .line 73
    if-eqz p1, :cond_5

    .line 74
    .line 75
    iget-object v5, p1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;->message:Ljava/lang/String;

    .line 76
    .line 77
    if-nez v5, :cond_6

    .line 78
    .line 79
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 80
    .line 81
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 82
    .line 83
    const v0, 0x7f1201d0

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 91
    .line 92
    iget-object v4, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 93
    .line 94
    :cond_7
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    move-object v2, v3

    .line 99
    check-cast v2, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 100
    .line 101
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->ERROR:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 102
    .line 103
    iget-object v0, v2, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 104
    .line 105
    invoke-virtual {v2, v0, v1, v5}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-interface {v4, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_7

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_8
    sget-object v3, Lcom/facebook/aura/executors/AuraDispatchers;->mainImmediate:LX/DSG;

    .line 117
    .line 118
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 119
    .line 120
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 121
    .line 122
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;

    .line 123
    .line 124
    invoke-direct {v0, v2, v1, v6}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V

    .line 125
    .line 126
    .line 127
    iput-object v6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->L$0:Ljava/lang/Object;

    .line 128
    .line 129
    iput v4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;->label:I

    .line 130
    .line 131
    invoke-static {p0, v3, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-ne v0, v5, :cond_0

    .line 136
    .line 137
    return-object v5

    .line 138
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    throw v0
.end method
