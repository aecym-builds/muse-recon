.class public final Lcom/facebook/aura/assist/AssistVoiceLayout;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final controlsTop:F

.field public final identity:LX/36Z;

.field public final leading:LX/36Z;

.field public final stacked:Z

.field public final trailing:LX/36Z;


# direct methods
.method public constructor <init>(LX/36Z;LX/36Z;LX/36Z;ZF)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->identity:LX/36Z;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->leading:LX/36Z;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->trailing:LX/36Z;

    .line 11
    .line 12
    iput-boolean p4, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->stacked:Z

    .line 13
    .line 14
    iput p5, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->controlsTop:F

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final getControlsTop()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->controlsTop:F

    .line 1
    .line 2
    return p0
.end method

.method public final getIdentity()LX/36Z;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->identity:LX/36Z;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLeading()LX/36Z;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->leading:LX/36Z;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStacked()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->stacked:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getTrailing()LX/36Z;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoiceLayout;->trailing:LX/36Z;

    .line 1
    .line 2
    return-object p0
.end method
