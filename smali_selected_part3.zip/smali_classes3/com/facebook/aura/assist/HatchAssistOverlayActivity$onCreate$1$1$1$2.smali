.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 268435456
    and-int/lit8 v1, p2, 0x3

    .line 268435457
    .line 268435458
    const/4 v0, 0x2

    .line 268435459
    const/4 v2, 0x0

    .line 268435460
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    if-eqz v0, :cond_0

    .line 268435469
    .line 268435470
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435471
    .line 268435472
    iget-wide v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 268435473
    .line 268435474
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 268435475
    .line 268435476
    .line 268435477
    move-result-object v1

    .line 268435478
    const v0, 0x1233874

    .line 268435479
    .line 268435480
    .line 268435481
    invoke-interface {p1, v0, v1}, LX/2d4;->Agd(ILjava/lang/Object;)V

    .line 268435482
    .line 268435483
    .line 268435484
    sget-object v1, Lcom/facebook/aura/navigation/LocalResultEventBus;->INSTANCE:Lcom/facebook/aura/navigation/LocalResultEventBus;

    .line 268435485
    .line 268435486
    invoke-static {p1, v2}, Lcom/facebook/aura/navigation/ResultEventBusKt;->rememberResultEventBus(LX/2d4;I)Lcom/facebook/aura/navigation/ResultEventBus;

    .line 268435487
    .line 268435488
    .line 268435489
    move-result-object v0

    .line 268435490
    invoke-virtual {v1, v0}, Lcom/facebook/aura/navigation/LocalResultEventBus;->provides(Lcom/facebook/aura/navigation/ResultEventBus;)LX/Ip4;

    .line 268435491
    .line 268435492
    .line 268435493
    move-result-object v3

    .line 268435494
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435495
    .line 268435496
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435497
    .line 268435498
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;

    .line 268435499
    .line 268435500
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1$1$2$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 268435501
    .line 268435502
    .line 268435503
    const v0, 0x1fbf565f

    .line 268435504
    .line 268435505
    .line 268435506
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435507
    .line 268435508
    .line 268435509
    move-result-object v1

    .line 268435510
    sget v0, Lcom/facebook/aura/navigation/ResultEventBus;->$stable:I

    .line 268435511
    .line 268435512
    or-int/lit8 v0, v0, 0x8

    .line 268435513
    .line 268435514
    or-int/lit8 v0, v0, 0x30

    .line 268435515
    .line 268435516
    invoke-static {p1, v3, v1, v0}, LX/Izg;->A01(LX/2d4;LX/Ip4;LX/JDN;I)V

    .line 268435517
    .line 268435518
    .line 268435519
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435520
    .line 268435521
    .line 268435522
    return-void

    .line 268435523
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435524
    .line 268435525
    .line 268435526
    return-void
.end method
