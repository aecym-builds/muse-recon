.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 1

    .line 0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1$1;->emit(ZLX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public final emit(ZLX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    if-eqz p1, :cond_1

    .line 268435457
    .line 268435458
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435459
    .line 268435460
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435461
    .line 268435462
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 268435463
    .line 268435464
    const/4 v0, 0x0

    .line 268435465
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 268435466
    .line 268435467
    .line 268435468
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435469
    .line 268435470
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 268435471
    .line 268435472
    :cond_0
    invoke-static {v1}, LX/604;->A16(LX/2J2;)Z

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v0

    .line 268435476
    if-eqz v0, :cond_0

    .line 268435477
    .line 268435478
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435479
    .line 268435480
    return-object v0
.end method
