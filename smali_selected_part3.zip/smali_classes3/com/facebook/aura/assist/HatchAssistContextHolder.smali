.class public final Lcom/facebook/aura/assist/HatchAssistContextHolder;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

.field public static final _screenshot:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field public static generation:J

.field public static final screenshot:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 6
    .line 7
    invoke-static {}, LX/3Rp;->A16()LX/Ddv;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->_screenshot:LX/2J2;

    .line 12
    .line 13
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->screenshot:LX/2J3;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final declared-synchronized beginInvocation()J
    .locals 4

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-object v1, Lcom/facebook/aura/assist/HatchAssistContextHolder;->_screenshot:LX/2J2;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-wide v2, Lcom/facebook/aura/assist/HatchAssistContextHolder;->generation:J

    .line 8
    .line 9
    const-wide/16 v0, 0x1

    .line 10
    .line 11
    add-long/2addr v2, v0

    .line 12
    sput-wide v2, Lcom/facebook/aura/assist/HatchAssistContextHolder;->generation:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    .line 14
    monitor-exit p0

    .line 15
    return-wide v2

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    throw v0
.end method

.method public final declared-synchronized clearIfCurrent(J)V
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-wide v1, Lcom/facebook/aura/assist/HatchAssistContextHolder;->generation:J

    .line 2
    .line 3
    cmp-long v0, p1, v1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/assist/HatchAssistContextHolder;->_screenshot:LX/2J2;

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    .line 13
    :cond_0
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception v0

    .line 16
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 17
    throw v0
.end method

.method public final getScreenshot()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->screenshot:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final declared-synchronized setScreenshot(Landroid/graphics/Bitmap;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->_screenshot:LX/2J2;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LX/2J2;->Afc(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    .line 5
    .line 6
    monitor-exit p0

    .line 7
    return-void

    .line 8
    :catchall_0
    move-exception v0

    .line 9
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 10
    throw v0
.end method
