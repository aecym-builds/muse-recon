.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Lcom/facebook/aura/composer/api/DictationOutcome;",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, Lcom/facebook/aura/composer/api/DictationOutcome;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;->invoke(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V
    .locals 3

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435461
    .line 268435462
    if-eqz p2, :cond_1

    .line 268435463
    .line 268435464
    iget-object p2, v2, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 268435465
    .line 268435466
    :cond_0
    invoke-interface {p2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object p1

    .line 268435470
    move-object p0, p1

    .line 268435471
    check-cast p0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435472
    .line 268435473
    sget-object v2, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435474
    .line 268435475
    iget-object v1, p0, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 268435476
    .line 268435477
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 268435478
    .line 268435479
    invoke-virtual {p0, v1, v2, v0}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435480
    .line 268435481
    .line 268435482
    move-result-object v0

    .line 268435483
    invoke-interface {p2, p1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435484
    .line 268435485
    .line 268435486
    move-result v0

    .line 268435487
    if-eqz v0, :cond_0

    .line 268435488
    .line 268435489
    return-void

    .line 268435490
    :cond_1
    sget-object v0, Lcom/facebook/aura/composer/api/DictationOutcome;->COMPLETED:Lcom/facebook/aura/composer/api/DictationOutcome;

    .line 268435491
    .line 268435492
    if-ne p1, v0, :cond_2

    .line 268435493
    .line 268435494
    iget-object v0, v2, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 268435495
    .line 268435496
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->hasComposerText()Z

    .line 268435497
    .line 268435498
    .line 268435499
    move-result v1

    .line 268435500
    const/4 v0, 0x1

    .line 268435501
    if-nez v1, :cond_3

    .line 268435502
    .line 268435503
    :cond_2
    const/4 v0, 0x0

    .line 268435504
    :cond_3
    invoke-static {v2, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->access$onDictationStopped(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/composer/api/DictationOutcome;Z)V

    .line 268435505
    .line 268435506
    .line 268435507
    return-void
.end method
