.class public abstract Lcom/facebook/aura/assist/HatchAssistOverlayViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ASSIST_SCREENSHOT_FILE_SCOPE:Ljava/lang/String; = "assist"

.field public static final CONNECTION_TIMEOUT_MS:J = 0x2710L
