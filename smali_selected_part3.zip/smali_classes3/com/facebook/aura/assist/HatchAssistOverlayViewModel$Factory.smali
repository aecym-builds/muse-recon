.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final context:Landroid/content/Context;

.field public final conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/AHE;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->userSession:LX/AHE;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->create()Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->userSession:LX/AHE;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;-><init>(Landroid/content/Context;LX/AHE;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
