.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDO<",
        "LX/1Xg;",
        "Ljava/lang/Integer;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $agentNameState$inlined:LX/16A;

.field public final synthetic $convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

.field public final synthetic $density$inlined:LX/34Y;

.field public final synthetic $frozenHeightPx$delegate$inlined:Landroidx/compose/runtime/MutableState;

.field public final synthetic $items:Ljava/util/List;

.field public final synthetic $listItems$inlined:LX/Ddn;

.field public final synthetic $onWidgetSendMessage$inlined:LX/JDM;

.field public final synthetic $onWidgetSetState$inlined:LX/JDO;


# direct methods
.method public constructor <init>(Ljava/util/List;LX/Ddn;LX/34Y;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/16A;LX/JDM;LX/JDO;Landroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$items:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$listItems$inlined:LX/Ddn;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$density$inlined:LX/34Y;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$agentNameState$inlined:LX/16A;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$onWidgetSendMessage$inlined:LX/JDM;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$onWidgetSetState$inlined:LX/JDO;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$frozenHeightPx$delegate$inlined:Landroidx/compose/runtime/MutableState;

    .line 15
    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    check-cast p3, LX/2d4;

    .line 7
    .line 8
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-virtual {p0, p1, v1, p3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->invoke(LX/1Xg;ILX/2d4;I)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(LX/1Xg;ILX/2d4;I)V
    .locals 25

    .line 268435456
    move-object/from16 v0, p3

    .line 268435457
    .line 268435458
    and-int/lit8 v1, p4, 0x6

    .line 268435459
    .line 268435460
    if-nez v1, :cond_6

    .line 268435461
    .line 268435462
    move-object/from16 v1, p1

    .line 268435463
    .line 268435464
    invoke-static {v0, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v1

    .line 268435468
    or-int v3, p4, v1

    .line 268435469
    .line 268435470
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 268435471
    .line 268435472
    move/from16 v4, p2

    .line 268435473
    .line 268435474
    if-nez v1, :cond_0

    .line 268435475
    .line 268435476
    invoke-static {v0, v4}, LX/004;->A0F(LX/2d4;I)I

    .line 268435477
    .line 268435478
    .line 268435479
    move-result v1

    .line 268435480
    or-int/2addr v3, v1

    .line 268435481
    :cond_0
    and-int/lit16 v2, v3, 0x93

    .line 268435482
    .line 268435483
    const/16 v1, 0x92

    .line 268435484
    .line 268435485
    const/4 v15, 0x1

    .line 268435486
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 268435487
    .line 268435488
    .line 268435489
    move-result v1

    .line 268435490
    invoke-static {v1, v0, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435491
    .line 268435492
    .line 268435493
    move-result v1

    .line 268435494
    if-eqz v1, :cond_7

    .line 268435495
    .line 268435496
    move-object/from16 v1, p0

    .line 268435497
    .line 268435498
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$items:Ljava/util/List;

    .line 268435499
    .line 268435500
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 268435501
    .line 268435502
    .line 268435503
    move-result-object v5

    .line 268435504
    check-cast v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;

    .line 268435505
    .line 268435506
    const v2, -0x3cbec78a

    .line 268435507
    .line 268435508
    .line 268435509
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 268435510
    .line 268435511
    .line 268435512
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$listItems$inlined:LX/Ddn;

    .line 268435513
    .line 268435514
    invoke-static {v2}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 268435515
    .line 268435516
    .line 268435517
    move-result-object v2

    .line 268435518
    const/4 v9, 0x0

    .line 268435519
    const/4 v8, 0x0

    .line 268435520
    if-ne v5, v2, :cond_5

    .line 268435521
    .line 268435522
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$frozenHeightPx$delegate$inlined:Landroidx/compose/runtime/MutableState;

    .line 268435523
    .line 268435524
    invoke-interface {v2}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435525
    .line 268435526
    .line 268435527
    move-result-object v2

    .line 268435528
    invoke-static {v2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435529
    .line 268435530
    .line 268435531
    move-result v2

    .line 268435532
    if-lez v2, :cond_5

    .line 268435533
    .line 268435534
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 268435535
    .line 268435536
    iget-object v3, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$density$inlined:LX/34Y;

    .line 268435537
    .line 268435538
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$frozenHeightPx$delegate$inlined:Landroidx/compose/runtime/MutableState;

    .line 268435539
    .line 268435540
    invoke-interface {v2}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435541
    .line 268435542
    .line 268435543
    move-result-object v2

    .line 268435544
    invoke-static {v2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435545
    .line 268435546
    .line 268435547
    move-result v2

    .line 268435548
    invoke-interface {v3, v2}, LX/34Y;->AhT(I)F

    .line 268435549
    .line 268435550
    .line 268435551
    move-result v3

    .line 268435552
    const/high16 v2, 0x7fc00000    # Float.NaN

    .line 268435553
    .line 268435554
    invoke-static {v10, v2, v3}, LX/2sI;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435555
    .line 268435556
    .line 268435557
    move-result-object v3

    .line 268435558
    :goto_1
    instance-of v2, v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;

    .line 268435559
    .line 268435560
    const/4 v4, 0x6

    .line 268435561
    if-eqz v2, :cond_3

    .line 268435562
    .line 268435563
    const v2, -0x3cb97aee

    .line 268435564
    .line 268435565
    .line 268435566
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 268435567
    .line 268435568
    .line 268435569
    check-cast v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;

    .line 268435570
    .line 268435571
    iget-object v4, v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;->message:Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;

    .line 268435572
    .line 268435573
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 268435574
    .line 268435575
    iget-object v7, v2, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 268435576
    .line 268435577
    iget-object v12, v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;->key:Ljava/lang/String;

    .line 268435578
    .line 268435579
    sget p1, Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;->$stable:I

    .line 268435580
    .line 268435581
    shl-int/lit8 v17, p1, 0x3

    .line 268435582
    .line 268435583
    const v2, 0x36c06

    .line 268435584
    .line 268435585
    .line 268435586
    or-int v17, v17, v2

    .line 268435587
    .line 268435588
    const/16 v23, 0x0

    .line 268435589
    .line 268435590
    move-object v11, v4

    .line 268435591
    move v13, v8

    .line 268435592
    move/from16 v14, v23

    .line 268435593
    .line 268435594
    move-object/from16 v16, v0

    .line 268435595
    .line 268435596
    invoke-static/range {v10 .. v17}, Lcom/facebook/aura/conversation/view/HatchMessageEntryAnimationsKt;->messageEntryAnimation-hGBTI10(LX/3C1;Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;Ljava/lang/String;FZZLX/2d4;I)LX/3C1;

    .line 268435597
    .line 268435598
    .line 268435599
    move-result-object v2

    .line 268435600
    invoke-interface {v2, v3}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 268435601
    .line 268435602
    .line 268435603
    move-result-object v3

    .line 268435604
    const/high16 v2, 0x40c00000    # 6.0f

    .line 268435605
    .line 268435606
    invoke-static {v3, v8, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435607
    .line 268435608
    .line 268435609
    move-result-object v6

    .line 268435610
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$agentNameState$inlined:LX/16A;

    .line 268435611
    .line 268435612
    invoke-interface {v0, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435613
    .line 268435614
    .line 268435615
    move-result v2

    .line 268435616
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435617
    .line 268435618
    .line 268435619
    move-result-object v5

    .line 268435620
    if-nez v2, :cond_1

    .line 268435621
    .line 268435622
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435623
    .line 268435624
    if-ne v5, v2, :cond_2

    .line 268435625
    .line 268435626
    :cond_1
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$agentNameState$inlined:LX/16A;

    .line 268435627
    .line 268435628
    new-instance v5, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$5$1$1;

    .line 268435629
    .line 268435630
    invoke-direct {v5, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$5$1$1;-><init>(LX/16A;)V

    .line 268435631
    .line 268435632
    .line 268435633
    invoke-interface {v0, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435634
    .line 268435635
    .line 268435636
    :cond_2
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 268435637
    .line 268435638
    iget-object v3, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$onWidgetSendMessage$inlined:LX/JDM;

    .line 268435639
    .line 268435640
    iget-object v2, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$onWidgetSetState$inlined:LX/JDO;

    .line 268435641
    .line 268435642
    sget v1, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->$stable:I

    .line 268435643
    .line 268435644
    shl-int/lit8 v1, v1, 0x9

    .line 268435645
    .line 268435646
    or-int p1, p1, v1

    .line 268435647
    .line 268435648
    const p4, 0x1fcff0

    .line 268435649
    .line 268435650
    .line 268435651
    move-object v10, v9

    .line 268435652
    move-object v11, v9

    .line 268435653
    move-object v12, v9

    .line 268435654
    move-object v13, v9

    .line 268435655
    move-object v14, v9

    .line 268435656
    move-object v15, v9

    .line 268435657
    move-object/from16 v17, v2

    .line 268435658
    .line 268435659
    move-object/from16 v18, v9

    .line 268435660
    .line 268435661
    move-object/from16 v19, v9

    .line 268435662
    .line 268435663
    move-object/from16 v20, v9

    .line 268435664
    .line 268435665
    move-object/from16 v21, v9

    .line 268435666
    .line 268435667
    move-object/from16 v22, v9

    .line 268435668
    .line 268435669
    move-object/from16 v24, v9

    .line 268435670
    .line 268435671
    move-object/from16 p0, v0

    .line 268435672
    .line 268435673
    move/from16 p2, v23

    .line 268435674
    .line 268435675
    move/from16 p3, v23

    .line 268435676
    .line 268435677
    move-object/from16 v16, v3

    .line 268435678
    .line 268435679
    invoke-static/range {v4 .. v29}, Lcom/facebook/aura/conversation/view/HatchMessageItemKt;->HatchMessageItem(Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/identity/provider/HatchConversationTheme;FLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDO;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDN;LX/JDM;Ljava/lang/String;ZLX/JDN;LX/2d4;IIII)V

    .line 268435680
    .line 268435681
    .line 268435682
    :goto_2
    check-cast v0, LX/J7I;

    .line 268435683
    .line 268435684
    const/4 v1, 0x0

    .line 268435685
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435686
    .line 268435687
    .line 268435688
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435689
    .line 268435690
    .line 268435691
    return-void

    .line 268435692
    :cond_3
    instance-of v2, v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$TypingCursor;

    .line 268435693
    .line 268435694
    if-eqz v2, :cond_4

    .line 268435695
    .line 268435696
    const v2, -0x3cab0b64

    .line 268435697
    .line 268435698
    .line 268435699
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 268435700
    .line 268435701
    .line 268435702
    check-cast v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$TypingCursor;

    .line 268435703
    .line 268435704
    iget-object v7, v5, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$TypingCursor;->activityText:Ljava/lang/String;

    .line 268435705
    .line 268435706
    sget-object v3, Lcom/facebook/aura/model/HatchMessageRole;->AGENT:Lcom/facebook/aura/model/HatchMessageRole;

    .line 268435707
    .line 268435708
    iget-object v1, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;->$convState$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 268435709
    .line 268435710
    iget-object v2, v1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 268435711
    .line 268435712
    sget v1, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->$stable:I

    .line 268435713
    .line 268435714
    shl-int/lit8 v1, v1, 0x3

    .line 268435715
    .line 268435716
    or-int/lit8 v1, v1, 0x6

    .line 268435717
    .line 268435718
    invoke-static {v3, v2, v0, v1}, Lcom/facebook/aura/conversation/ui/HatchBubbleStyleKt;->bubbleBackground(Lcom/facebook/aura/model/HatchMessageRole;Lcom/facebook/aura/identity/provider/HatchConversationTheme;LX/2d4;I)J

    .line 268435719
    .line 268435720
    .line 268435721
    move-result-wide v5

    .line 268435722
    invoke-static {v10, v0, v4}, Lcom/facebook/aura/conversation/view/HatchMessageEntryAnimationsKt;->streamingCursorEntryAnimation(LX/3C1;LX/2d4;I)LX/3C1;

    .line 268435723
    .line 268435724
    .line 268435725
    move-result-object v2

    .line 268435726
    const/high16 v1, 0x40c00000    # 6.0f

    .line 268435727
    .line 268435728
    invoke-static {v2, v8, v1}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435729
    .line 268435730
    .line 268435731
    move-result-object v8

    .line 268435732
    const/4 v10, 0x0

    .line 268435733
    move-object v9, v0

    .line 268435734
    move v11, v10

    .line 268435735
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/conversation/view/HatchAgentIndicatorsKt;->HatchStreamingCursor-KTwxG1Y(JLjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 268435736
    .line 268435737
    .line 268435738
    goto :goto_2

    .line 268435739
    :cond_4
    const v1, -0x3ca4dcd1

    .line 268435740
    .line 268435741
    .line 268435742
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 268435743
    .line 268435744
    .line 268435745
    goto :goto_2

    .line 268435746
    :cond_5
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 268435747
    .line 268435748
    move-object v10, v3

    .line 268435749
    goto/16 :goto_1

    .line 268435750
    .line 268435751
    :cond_6
    move/from16 v3, p4

    .line 268435752
    .line 268435753
    goto/16 :goto_0

    .line 268435754
    .line 268435755
    :cond_7
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 268435756
    .line 268435757
    .line 268435758
    return-void
.end method
