.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CcW;",
        "LX/CcV;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/CcW;)LX/CcV;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-virtual {v1, v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->setOnScreen(Z)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;

    .line 13
    .line 14
    invoke-direct {v0, p1, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;-><init>(LX/CcW;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CcW;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;->invoke(LX/CcW;)LX/CcV;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
