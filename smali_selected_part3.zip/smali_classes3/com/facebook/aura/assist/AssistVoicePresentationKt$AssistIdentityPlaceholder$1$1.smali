.class public final Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2f1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoicePresentation;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2f1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;->invoke(LX/2f1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2f1;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$AssistIdentityPlaceholder$1$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 5
    .line 6
    invoke-virtual {p1}, LX/2f1;->A02()LX/2sT;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0}, LX/1FB;->A00(LX/2sT;)LX/36Z;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {p0, v0}, Lcom/facebook/aura/assist/AssistVoicePresentation;->setIdentityBounds(LX/36Z;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
