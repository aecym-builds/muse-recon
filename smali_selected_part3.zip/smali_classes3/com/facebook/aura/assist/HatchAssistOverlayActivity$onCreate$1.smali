.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static final synthetic access$invoke$lambda$0(LX/16A;)Z
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final invoke$lambda$0(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435467
    .line 268435468
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 268435469
    .line 268435470
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v0

    .line 268435474
    if-nez v0, :cond_0

    .line 268435475
    .line 268435476
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435477
    .line 268435478
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 268435479
    .line 268435480
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 268435481
    .line 268435482
    .line 268435483
    move-result-object v3

    .line 268435484
    check-cast v3, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435485
    .line 268435486
    sget-object v1, Lcom/facebook/aura/startup/AuraStartupOrchestrator;->isUiBlockingReady:LX/2J3;

    .line 268435487
    .line 268435488
    const/4 v0, 0x0

    .line 268435489
    invoke-static {p1, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 268435490
    .line 268435491
    .line 268435492
    move-result-object v2

    .line 268435493
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 268435494
    .line 268435495
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;

    .line 268435496
    .line 268435497
    invoke-direct {v1, v3, v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;LX/16A;)V

    .line 268435498
    .line 268435499
    .line 268435500
    const v0, 0x2b222d26

    .line 268435501
    .line 268435502
    .line 268435503
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435504
    .line 268435505
    .line 268435506
    move-result-object v1

    .line 268435507
    const/4 v0, 0x6

    .line 268435508
    invoke-static {v1, p1, v0}, Lcom/facebook/aura/ui/adaptive/AuraAdaptiveInfoKt;->ProvideAuraAdaptiveInfo(LX/JDN;LX/2d4;I)V

    .line 268435509
    .line 268435510
    .line 268435511
    :cond_0
    return-void

    .line 268435512
    :cond_1
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435513
    .line 268435514
    .line 268435515
    return-void
.end method
