.class public final Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1a6;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $avatarSize:F

.field public final synthetic $bottomInset:I

.field public final synthetic $density:LX/34Y;

.field public final synthetic $identityState:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $identityVisible:Z

.field public final synthetic $leftInset:I

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOpenApp:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

.field public final synthetic $rightInset:I

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/34Y;IIIFLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/AssistVoicePresentation;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/34Y;",
            "IIIF",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$density:LX/34Y;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$bottomInset:I

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$leftInset:I

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$rightInset:I

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$avatarSize:F

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$threadId:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    iput-boolean p11, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$identityVisible:Z

    .line 21
    .line 22
    const/4 v0, 0x3

    .line 23
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1a6;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->invoke(LX/1a6;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1a6;LX/2d4;I)V
    .locals 14

    .line 268435456
    move/from16 v1, p3

    .line 268435457
    .line 268435458
    invoke-static {p1, v1}, LX/002;->A0L(Ljava/lang/Object;I)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    move-object/from16 v2, p2

    .line 268435463
    .line 268435464
    if-nez v0, :cond_0

    .line 268435465
    .line 268435466
    invoke-static {v2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435467
    .line 268435468
    .line 268435469
    move-result v0

    .line 268435470
    or-int v1, p3, v0

    .line 268435471
    .line 268435472
    :cond_0
    invoke-static {v1}, LX/005;->A1G(I)Z

    .line 268435473
    .line 268435474
    .line 268435475
    move-result v0

    .line 268435476
    invoke-static {v0, v2, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435477
    .line 268435478
    .line 268435479
    move-result v0

    .line 268435480
    if-eqz v0, :cond_4

    .line 268435481
    .line 268435482
    move-object v4, p0

    .line 268435483
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$density:LX/34Y;

    .line 268435484
    .line 268435485
    iget v8, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$bottomInset:I

    .line 268435486
    .line 268435487
    iget v7, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$leftInset:I

    .line 268435488
    .line 268435489
    iget v6, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$rightInset:I

    .line 268435490
    .line 268435491
    iget v1, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$avatarSize:F

    .line 268435492
    .line 268435493
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435494
    .line 268435495
    invoke-interface {p1}, LX/1a6;->AHa()F

    .line 268435496
    .line 268435497
    .line 268435498
    move-result v0

    .line 268435499
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435500
    .line 268435501
    .line 268435502
    move-result v10

    .line 268435503
    invoke-interface {p1}, LX/1a6;->AHW()F

    .line 268435504
    .line 268435505
    .line 268435506
    move-result v0

    .line 268435507
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435508
    .line 268435509
    .line 268435510
    move-result v9

    .line 268435511
    int-to-float v0, v8

    .line 268435512
    sub-float/2addr v9, v0

    .line 268435513
    const/high16 v13, 0x41400000    # 12.0f

    .line 268435514
    .line 268435515
    invoke-interface {v5, v13}, LX/34Y;->AhZ(F)F

    .line 268435516
    .line 268435517
    .line 268435518
    move-result v0

    .line 268435519
    sub-float/2addr v9, v0

    .line 268435520
    int-to-float v11, v7

    .line 268435521
    sub-float v12, v10, v11

    .line 268435522
    .line 268435523
    int-to-float v6, v6

    .line 268435524
    sub-float/2addr v12, v6

    .line 268435525
    const/high16 v0, 0x41c00000    # 24.0f

    .line 268435526
    .line 268435527
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435528
    .line 268435529
    .line 268435530
    move-result v8

    .line 268435531
    const/high16 v0, 0x43600000    # 224.0f

    .line 268435532
    .line 268435533
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435534
    .line 268435535
    .line 268435536
    move-result v0

    .line 268435537
    add-float/2addr v8, v0

    .line 268435538
    invoke-interface {v5, v1}, LX/34Y;->AhZ(F)F

    .line 268435539
    .line 268435540
    .line 268435541
    move-result v7

    .line 268435542
    const/high16 v0, 0x43080000    # 136.0f

    .line 268435543
    .line 268435544
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435545
    .line 268435546
    .line 268435547
    move-result v1

    .line 268435548
    invoke-interface {v5}, LX/1yo;->AFv()F

    .line 268435549
    .line 268435550
    .line 268435551
    move-result v0

    .line 268435552
    mul-float/2addr v1, v0

    .line 268435553
    invoke-static {v7, v1}, Ljava/lang/Math;->max(FF)F

    .line 268435554
    .line 268435555
    .line 268435556
    move-result v0

    .line 268435557
    add-float/2addr v8, v0

    .line 268435558
    cmpg-float v1, v12, v8

    .line 268435559
    .line 268435560
    const/16 p2, 0x0

    .line 268435561
    .line 268435562
    const/high16 v0, 0x42d00000    # 104.0f

    .line 268435563
    .line 268435564
    if-gez v1, :cond_1

    .line 268435565
    .line 268435566
    const/16 p2, 0x1

    .line 268435567
    .line 268435568
    const/high16 v0, 0x42600000    # 56.0f

    .line 268435569
    .line 268435570
    :cond_1
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435571
    .line 268435572
    .line 268435573
    move-result p0

    .line 268435574
    const/high16 v0, 0x42600000    # 56.0f

    .line 268435575
    .line 268435576
    if-eqz p2, :cond_2

    .line 268435577
    .line 268435578
    const/high16 v0, 0x42d00000    # 104.0f

    .line 268435579
    .line 268435580
    :cond_2
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435581
    .line 268435582
    .line 268435583
    move-result v8

    .line 268435584
    invoke-virtual {v3}, Lcom/facebook/aura/assist/AssistIdentityState;->getIdentityHeight()I

    .line 268435585
    .line 268435586
    .line 268435587
    move-result v0

    .line 268435588
    int-to-float v1, v0

    .line 268435589
    invoke-static {v1, v8}, Ljava/lang/Math;->max(FF)F

    .line 268435590
    .line 268435591
    .line 268435592
    move-result v12

    .line 268435593
    add-float v3, v12, v8

    .line 268435594
    .line 268435595
    const/high16 v0, 0x40000000    # 2.0f

    .line 268435596
    .line 268435597
    div-float/2addr v3, v0

    .line 268435598
    sub-float v7, v9, v3

    .line 268435599
    .line 268435600
    invoke-interface {v5, v13}, LX/34Y;->AhZ(F)F

    .line 268435601
    .line 268435602
    .line 268435603
    move-result v0

    .line 268435604
    add-float/2addr v11, v0

    .line 268435605
    sub-float/2addr v10, v6

    .line 268435606
    invoke-interface {v5, v13}, LX/34Y;->AhZ(F)F

    .line 268435607
    .line 268435608
    .line 268435609
    move-result v0

    .line 268435610
    sub-float/2addr v10, v0

    .line 268435611
    const/high16 v0, 0x41000000    # 8.0f

    .line 268435612
    .line 268435613
    invoke-interface {v5, v0}, LX/34Y;->AhZ(F)F

    .line 268435614
    .line 268435615
    .line 268435616
    move-result v0

    .line 268435617
    add-float v6, v11, p0

    .line 268435618
    .line 268435619
    add-float v5, v6, v0

    .line 268435620
    .line 268435621
    sub-float v3, v9, v1

    .line 268435622
    .line 268435623
    sub-float v1, v10, p0

    .line 268435624
    .line 268435625
    sub-float v0, v1, v0

    .line 268435626
    .line 268435627
    new-instance v13, LX/36Z;

    .line 268435628
    .line 268435629
    invoke-direct {v13, v5, v3, v0, v9}, LX/36Z;-><init>(FFFF)V

    .line 268435630
    .line 268435631
    .line 268435632
    add-float/2addr v8, v7

    .line 268435633
    new-instance p0, LX/36Z;

    .line 268435634
    .line 268435635
    invoke-direct {p0, v11, v7, v6, v8}, LX/36Z;-><init>(FFFF)V

    .line 268435636
    .line 268435637
    .line 268435638
    new-instance p1, LX/36Z;

    .line 268435639
    .line 268435640
    invoke-direct {p1, v1, v7, v10, v8}, LX/36Z;-><init>(FFFF)V

    .line 268435641
    .line 268435642
    .line 268435643
    sub-float/2addr v9, v12

    .line 268435644
    new-instance v6, Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 268435645
    .line 268435646
    move-object v12, v6

    .line 268435647
    move/from16 p3, v9

    .line 268435648
    .line 268435649
    invoke-direct/range {v12 .. v17}, Lcom/facebook/aura/assist/AssistVoiceLayout;-><init>(LX/36Z;LX/36Z;LX/36Z;ZF)V

    .line 268435650
    .line 268435651
    .line 268435652
    sget-object v3, Lcom/facebook/aura/header/view/HatchStatusPillMetricsKt;->LocalHatchStatusPillMetrics:LX/Ip3;

    .line 268435653
    .line 268435654
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435655
    .line 268435656
    .line 268435657
    move-result-object v1

    .line 268435658
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435659
    .line 268435660
    if-ne v1, v0, :cond_3

    .line 268435661
    .line 268435662
    new-instance v1, Lcom/facebook/aura/header/view/HatchStatusPillMetrics;

    .line 268435663
    .line 268435664
    invoke-direct {v1}, Lcom/facebook/aura/header/view/HatchStatusPillMetrics;-><init>()V

    .line 268435665
    .line 268435666
    .line 268435667
    invoke-interface {v2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435668
    .line 268435669
    .line 268435670
    :cond_3
    invoke-virtual {v3, v1}, LX/Ip3;->A02(Ljava/lang/Object;)LX/Ip4;

    .line 268435671
    .line 268435672
    .line 268435673
    move-result-object v1

    .line 268435674
    iget-object v5, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 268435675
    .line 268435676
    iget-object v7, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435677
    .line 268435678
    iget-object v8, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 268435679
    .line 268435680
    iget-object v9, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$threadId:Ljava/lang/String;

    .line 268435681
    .line 268435682
    iget-object v10, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$onOpenApp:Lkotlin/jvm/functions/Function0;

    .line 268435683
    .line 268435684
    iget-boolean v11, v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;->$identityVisible:Z

    .line 268435685
    .line 268435686
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;

    .line 268435687
    .line 268435688
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1$2;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/assist/AssistIdentityState;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V

    .line 268435689
    .line 268435690
    .line 268435691
    const v0, 0x135ccc22

    .line 268435692
    .line 268435693
    .line 268435694
    invoke-static {v2, v1, v4, v0}, LX/003;->A0r(LX/2d4;LX/Ip4;Ljava/lang/Object;I)V

    .line 268435695
    .line 268435696
    .line 268435697
    return-void

    .line 268435698
    :cond_4
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 268435699
    .line 268435700
    .line 268435701
    return-void
.end method
