.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;
.super Landroid/app/KeyguardManager$KeyguardDismissCallback;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    invoke-direct {p0}, Landroid/app/KeyguardManager$KeyguardDismissCallback;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onDismissCancelled()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onDismissError()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onDismissSucceeded()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->access$onUnlocked(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
