.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Void;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ")",
            "Ljava/lang/Void;"
        }
    .end annotation

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    return-object p0
.end method
