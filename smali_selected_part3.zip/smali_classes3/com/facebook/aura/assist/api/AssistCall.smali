.class public interface abstract Lcom/facebook/aura/assist/api/AssistCall;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract CallEndedEffect(Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation
.end method

.method public abstract CallStartHost(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDQ<",
            "-",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation
.end method

.method public abstract Caption(LX/3C1;LX/2d4;I)V
.end method

.method public abstract EmbodimentHost(LX/3C1;LX/JDQ;LX/2d4;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/33K;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation
.end method

.method public abstract LeadingControls(LX/2d4;I)V
.end method

.method public abstract TrailingControls(LX/2d4;I)V
.end method

.method public abstract isOngoing(LX/AHE;)LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            ")",
            "LX/2Lw<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end method

.method public abstract ongoing(LX/AHE;)Lcom/facebook/aura/assist/api/AssistOngoingCall;
.end method

.method public abstract presentCompactly(LX/AHE;)Lcom/facebook/aura/assist/api/AssistCompactPresentation;
.end method
