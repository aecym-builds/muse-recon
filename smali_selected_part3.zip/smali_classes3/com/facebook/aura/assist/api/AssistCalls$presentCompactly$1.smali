.class public final Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/assist/api/AssistCompactPresentation;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final release()V
    .locals 0

    .line 0
    return-void
.end method
