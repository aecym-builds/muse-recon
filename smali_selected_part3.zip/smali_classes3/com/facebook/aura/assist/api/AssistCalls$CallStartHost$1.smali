.class public final Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $content:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStart:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $threadId:Ljava/lang/String;

.field public final synthetic $tmp1_rcvr:Lcom/facebook/aura/assist/api/AssistCalls;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/api/AssistCalls;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/api/AssistCalls;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDQ<",
            "-",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;I)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$tmp1_rcvr:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$threadId:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$onStart:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$content:LX/JDQ;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$$changed:I

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 6

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$tmp1_rcvr:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$threadId:Ljava/lang/String;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$onStart:Lkotlin/jvm/functions/Function0;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$content:LX/JDQ;

    .line 268435463
    .line 268435464
    iget v0, p0, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;->$$changed:I

    .line 268435465
    .line 268435466
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435467
    .line 268435468
    .line 268435469
    move-result p0

    .line 268435470
    move-object v5, p1

    .line 268435471
    invoke-virtual/range {v1 .. v6}, Lcom/facebook/aura/assist/api/AssistCalls;->CallStartHost(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;I)V

    .line 268435472
    .line 268435473
    .line 268435474
    return-void
.end method
