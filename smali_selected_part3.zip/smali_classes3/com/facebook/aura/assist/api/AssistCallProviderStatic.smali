.class public Lcom/facebook/aura/assist/api/AssistCallProviderStatic;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static call(I)Lcom/facebook/aura/assist/api/AssistCall;
    .locals 0

    .line 0
    if-nez p0, :cond_0

    .line 1
    .line 2
    sget-object p0, Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;->INSTANCE:Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;->call()Lcom/facebook/aura/assist/api/AssistCall;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0

    .line 9
    :cond_0
    invoke-static {p0}, LX/009;->A0Z(I)Ljava/lang/IllegalArgumentException;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    throw p0
.end method

.method public static getKeys()[I
    .locals 1

    .line 0
    invoke-static {}, LX/3Rq;->A1X()[I

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method
