.class public interface abstract Lcom/facebook/aura/assist/api/AssistCallProvider;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract call()Lcom/facebook/aura/assist/api/AssistCall;
.end method
