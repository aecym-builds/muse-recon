.class public final Lcom/facebook/aura/assist/api/AssistCalls;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getCall()Lcom/facebook/aura/assist/api/AssistCall;
    .locals 1

    .line 0
    invoke-static {}, LX/602;->A01()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez p0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;->INSTANCE:Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/partners/voice/assist/VoiceAssistCallProvider;->call()Lcom/facebook/aura/assist/api/AssistCall;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0

    .line 17
    :cond_0
    invoke-static {v0}, LX/005;->A0g(Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    throw v0
.end method


# virtual methods
.method public final CallEndedEffect(Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const v0, -0x715c1da4

    .line 5
    .line 6
    .line 7
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    if-nez v0, :cond_4

    .line 13
    .line 14
    invoke-static {p2, p1}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    or-int/2addr v2, p3

    .line 19
    :goto_0
    invoke-static {v2}, LX/004;->A1R(I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0, p2, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 34
    .line 35
    if-ne v1, v0, :cond_0

    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 38
    .line 39
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-interface {p2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    check-cast v1, Lcom/facebook/aura/assist/api/AssistCall;

    .line 47
    .line 48
    if-nez v1, :cond_2

    .line 49
    .line 50
    const v0, 0x3163c2c9

    .line 51
    .line 52
    .line 53
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 54
    .line 55
    .line 56
    :goto_1
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    if-eqz v1, :cond_1

    .line 64
    .line 65
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls$CallEndedEffect$2;

    .line 66
    .line 67
    invoke-direct {v0, p0, p1, p3}, Lcom/facebook/aura/assist/api/AssistCalls$CallEndedEffect$2;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;Lkotlin/jvm/functions/Function0;I)V

    .line 68
    .line 69
    .line 70
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 71
    .line 72
    :cond_1
    return-void

    .line 73
    :cond_2
    const v0, 0x7534c438

    .line 74
    .line 75
    .line 76
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 77
    .line 78
    .line 79
    and-int/lit8 v0, v2, 0xe

    .line 80
    .line 81
    invoke-interface {v1, p1, p2, v0}, Lcom/facebook/aura/assist/api/AssistCall;->CallEndedEffect(Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 86
    .line 87
    .line 88
    goto :goto_2

    .line 89
    :cond_4
    move v2, p3

    .line 90
    goto :goto_0
.end method

.method public final CallStartHost(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;I)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDQ<",
            "-",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    move-object v4, p2

    .line 1
    move-object/from16 v5, p3

    .line 2
    .line 3
    invoke-static {p2, v5}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    const v0, 0x3d1a8c34

    .line 7
    .line 8
    .line 9
    move-object/from16 v11, p4

    .line 10
    .line 11
    invoke-interface {v11, v0}, LX/2d4;->Agl(I)V

    .line 12
    .line 13
    .line 14
    move/from16 v6, p5

    .line 15
    .line 16
    and-int/lit8 v0, p5, 0x6

    .line 17
    .line 18
    move-object v3, p1

    .line 19
    if-nez v0, :cond_6

    .line 20
    .line 21
    invoke-static {v11, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    or-int v1, v1, p5

    .line 26
    .line 27
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    invoke-static {v11, p2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    or-int/2addr v1, v0

    .line 36
    :cond_0
    and-int/lit16 v0, v6, 0x180

    .line 37
    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    invoke-static {v11, v5}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    or-int/2addr v1, v0

    .line 45
    :cond_1
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v11, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_5

    .line 54
    .line 55
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v7

    .line 59
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 60
    .line 61
    if-ne v7, v0, :cond_2

    .line 62
    .line 63
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 64
    .line 65
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    invoke-interface {v11, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    check-cast v7, Lcom/facebook/aura/assist/api/AssistCall;

    .line 73
    .line 74
    if-nez v7, :cond_4

    .line 75
    .line 76
    const v0, 0x60a869c1

    .line 77
    .line 78
    .line 79
    invoke-interface {v11, v0}, LX/2d4;->Agj(I)V

    .line 80
    .line 81
    .line 82
    shr-int/lit8 v0, v1, 0x3

    .line 83
    .line 84
    and-int/lit8 v0, v0, 0x70

    .line 85
    .line 86
    or-int/lit8 v0, v0, 0x6

    .line 87
    .line 88
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    const/4 v0, 0x0

    .line 93
    invoke-interface {v5, v0, v11, v1}, LX/JDQ;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    :goto_1
    invoke-static {v11}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :goto_2
    invoke-interface {v11}, LX/2d4;->AAg()LX/J7V;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    if-eqz v0, :cond_3

    .line 104
    .line 105
    new-instance v1, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;

    .line 106
    .line 107
    move-object v2, p0

    .line 108
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/assist/api/AssistCalls$CallStartHost$1;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;I)V

    .line 109
    .line 110
    .line 111
    iput-object v1, v0, LX/J7V;->A06:LX/JDN;

    .line 112
    .line 113
    :cond_3
    return-void

    .line 114
    :cond_4
    const v0, 0x60a86d7c

    .line 115
    .line 116
    .line 117
    invoke-interface {v11, v0}, LX/2d4;->Agj(I)V

    .line 118
    .line 119
    .line 120
    and-int/lit16 v12, v1, 0x3fe

    .line 121
    .line 122
    move-object v8, p1

    .line 123
    move-object v9, p2

    .line 124
    move-object v10, v5

    .line 125
    invoke-interface/range {v7 .. v12}, Lcom/facebook/aura/assist/api/AssistCall;->CallStartHost(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/JDQ;LX/2d4;I)V

    .line 126
    .line 127
    .line 128
    goto :goto_1

    .line 129
    :cond_5
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 130
    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_6
    move v1, v6

    .line 134
    goto :goto_0
.end method

.method public final Caption(LX/3C1;LX/2d4;II)V
    .locals 3

    .line 0
    const v0, -0x4fd3eb8c

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v2, p4, 0x1

    .line 7
    .line 8
    if-eqz v2, :cond_5

    .line 9
    .line 10
    or-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    :goto_0
    invoke-static {v0}, LX/004;->A1R(I)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    invoke-static {v1, p2, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_4

    .line 21
    .line 22
    if-eqz v2, :cond_0

    .line 23
    .line 24
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 25
    .line 26
    :cond_0
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 31
    .line 32
    if-ne v2, v1, :cond_1

    .line 33
    .line 34
    sget-object v1, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 35
    .line 36
    invoke-direct {v1}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    invoke-interface {p2, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    check-cast v2, Lcom/facebook/aura/assist/api/AssistCall;

    .line 44
    .line 45
    if-nez v2, :cond_3

    .line 46
    .line 47
    const v0, 0x59a1309c

    .line 48
    .line 49
    .line 50
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 51
    .line 52
    .line 53
    :goto_1
    invoke-static {p2}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls$Caption$2;

    .line 63
    .line 64
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/assist/api/AssistCalls$Caption$2;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;LX/3C1;II)V

    .line 65
    .line 66
    .line 67
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 68
    .line 69
    :cond_2
    return-void

    .line 70
    :cond_3
    const v1, 0x5578d005

    .line 71
    .line 72
    .line 73
    invoke-interface {p2, v1}, LX/2d4;->Agj(I)V

    .line 74
    .line 75
    .line 76
    and-int/lit8 v0, v0, 0xe

    .line 77
    .line 78
    invoke-interface {v2, p1, p2, v0}, Lcom/facebook/aura/assist/api/AssistCall;->Caption(LX/3C1;LX/2d4;I)V

    .line 79
    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_4
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 83
    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_5
    and-int/lit8 v0, p3, 0x6

    .line 87
    .line 88
    if-nez v0, :cond_6

    .line 89
    .line 90
    invoke-static {p2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    or-int/2addr v0, p3

    .line 95
    goto :goto_0

    .line 96
    :cond_6
    move v0, p3

    .line 97
    goto :goto_0
.end method

.method public final EmbodimentHost(LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/33K;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v10, p1

    .line 1
    const/4 v5, 0x1

    .line 2
    move-object/from16 v11, p2

    .line 3
    .line 4
    invoke-static {v11, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    const v0, -0x3c1cda62

    .line 8
    .line 9
    .line 10
    move-object/from16 v3, p3

    .line 11
    .line 12
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 13
    .line 14
    .line 15
    move/from16 v13, p5

    .line 16
    .line 17
    and-int/lit8 v6, p5, 0x1

    .line 18
    .line 19
    move/from16 v12, p4

    .line 20
    .line 21
    if-eqz v6, :cond_3

    .line 22
    .line 23
    or-int/lit8 v1, p4, 0x6

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 26
    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    invoke-static {v3, v11}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    or-int/2addr v1, v0

    .line 34
    :cond_0
    and-int/lit8 v2, v1, 0x13

    .line 35
    .line 36
    const/16 v0, 0x12

    .line 37
    .line 38
    const/4 v4, 0x0

    .line 39
    invoke-static {v2, v0}, LX/003;->A1H(II)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_6

    .line 48
    .line 49
    if-eqz v6, :cond_1

    .line 50
    .line 51
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 52
    .line 53
    :cond_1
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 58
    .line 59
    if-ne v2, v0, :cond_2

    .line 60
    .line 61
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 62
    .line 63
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-interface {v3, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_2
    check-cast v2, Lcom/facebook/aura/assist/api/AssistCall;

    .line 71
    .line 72
    if-nez v2, :cond_7

    .line 73
    .line 74
    const v0, 0x57b048e9

    .line 75
    .line 76
    .line 77
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 78
    .line 79
    .line 80
    and-int/lit8 v9, v1, 0xe

    .line 81
    .line 82
    shl-int/lit8 v0, v1, 0x6

    .line 83
    .line 84
    and-int/lit16 v0, v0, 0x1c00

    .line 85
    .line 86
    or-int/2addr v9, v0

    .line 87
    invoke-static {v4}, LX/001;->A0g(Z)LX/3BI;

    .line 88
    .line 89
    .line 90
    move-result-object v8

    .line 91
    move-object v7, v3

    .line 92
    check-cast v7, LX/J7I;

    .line 93
    .line 94
    invoke-static {v7}, LX/003;->A0F(LX/J7I;)I

    .line 95
    .line 96
    .line 97
    move-result v6

    .line 98
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    invoke-static {v3, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 107
    .line 108
    iget-object v0, v7, LX/J7I;->A0V:LX/3DJ;

    .line 109
    .line 110
    if-nez v0, :cond_5

    .line 111
    .line 112
    invoke-static {}, LX/1VY;->A00()V

    .line 113
    .line 114
    .line 115
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    throw v0

    .line 120
    :cond_3
    and-int/lit8 v0, p4, 0x6

    .line 121
    .line 122
    if-nez v0, :cond_4

    .line 123
    .line 124
    invoke-static {v3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    or-int v1, v1, p4

    .line 129
    .line 130
    goto :goto_0

    .line 131
    :cond_4
    move v1, v12

    .line 132
    goto :goto_0

    .line 133
    :cond_5
    invoke-static {v3, v7, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v3, v8, v4, v2, v6}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 137
    .line 138
    .line 139
    sget-object v1, LX/3Jn;->A00:LX/3Jn;

    .line 140
    .line 141
    shr-int/lit8 v0, v9, 0x6

    .line 142
    .line 143
    and-int/lit8 v0, v0, 0x70

    .line 144
    .line 145
    or-int/lit8 v0, v0, 0x6

    .line 146
    .line 147
    invoke-static {v1, v3, v11, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 148
    .line 149
    .line 150
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 151
    .line 152
    .line 153
    goto :goto_1

    .line 154
    :cond_6
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 155
    .line 156
    .line 157
    goto :goto_2

    .line 158
    :cond_7
    const v0, 0x57b05034

    .line 159
    .line 160
    .line 161
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 162
    .line 163
    .line 164
    and-int/lit8 v0, v1, 0x7e

    .line 165
    .line 166
    invoke-interface {v2, v10, v11, v3, v0}, Lcom/facebook/aura/assist/api/AssistCall;->EmbodimentHost(LX/3C1;LX/JDQ;LX/2d4;I)V

    .line 167
    .line 168
    .line 169
    :goto_1
    invoke-static {v3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    if-eqz v0, :cond_8

    .line 177
    .line 178
    new-instance v8, Lcom/facebook/aura/assist/api/AssistCalls$EmbodimentHost$1;

    .line 179
    .line 180
    move-object v9, p0

    .line 181
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/assist/api/AssistCalls$EmbodimentHost$1;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;LX/3C1;LX/JDQ;II)V

    .line 182
    .line 183
    .line 184
    iput-object v8, v0, LX/J7V;->A06:LX/JDN;

    .line 185
    .line 186
    :cond_8
    return-void
.end method

.method public final LeadingControls(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, -0x4933c439

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v1, p2, 0x1

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-static {v1}, LX/003;->A1B(I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-interface {p1, v1, v0}, LX/2d4;->Afw(IZ)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_3

    .line 18
    .line 19
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 24
    .line 25
    if-ne v1, v0, :cond_0

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 28
    .line 29
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-interface {p1, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v1, Lcom/facebook/aura/assist/api/AssistCall;

    .line 37
    .line 38
    if-nez v1, :cond_2

    .line 39
    .line 40
    const v0, 0x60e11309

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 44
    .line 45
    .line 46
    :goto_0
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    if-eqz v1, :cond_1

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls$LeadingControls$2;

    .line 56
    .line 57
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/assist/api/AssistCalls$LeadingControls$2;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;I)V

    .line 58
    .line 59
    .line 60
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 61
    .line 62
    :cond_1
    return-void

    .line 63
    :cond_2
    const v0, 0x34ac6bf8

    .line 64
    .line 65
    .line 66
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 67
    .line 68
    .line 69
    invoke-interface {v1, p1, v2}, Lcom/facebook/aura/assist/api/AssistCall;->LeadingControls(LX/2d4;I)V

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_3
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 74
    .line 75
    .line 76
    goto :goto_1
.end method

.method public final TrailingControls(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, -0x2c63f52b

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v1, p2, 0x1

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-static {v1}, LX/003;->A1B(I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-interface {p1, v1, v0}, LX/2d4;->Afw(IZ)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_3

    .line 18
    .line 19
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 24
    .line 25
    if-ne v1, v0, :cond_0

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 28
    .line 29
    invoke-direct {v0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-interface {p1, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v1, Lcom/facebook/aura/assist/api/AssistCall;

    .line 37
    .line 38
    if-nez v1, :cond_2

    .line 39
    .line 40
    const v0, 0x3bd1453a

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 44
    .line 45
    .line 46
    :goto_0
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    if-eqz v1, :cond_1

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/assist/api/AssistCalls$TrailingControls$2;

    .line 56
    .line 57
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/assist/api/AssistCalls$TrailingControls$2;-><init>(Lcom/facebook/aura/assist/api/AssistCalls;I)V

    .line 58
    .line 59
    .line 60
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 61
    .line 62
    :cond_1
    return-void

    .line 63
    :cond_2
    const v0, 0x5cc4afa7

    .line 64
    .line 65
    .line 66
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 67
    .line 68
    .line 69
    invoke-interface {v1, p1, v2}, Lcom/facebook/aura/assist/api/AssistCall;->TrailingControls(LX/2d4;I)V

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_3
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 74
    .line 75
    .line 76
    goto :goto_1
.end method

.method public final isOngoing(LX/AHE;)LX/2Lw;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            ")",
            "LX/2Lw<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-interface {v0, p1}, Lcom/facebook/aura/assist/api/AssistCall;->isOngoing(LX/AHE;)LX/2Lw;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    :cond_0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    new-instance v0, LX/3A7;

    .line 21
    .line 22
    invoke-direct {v0, v1}, LX/3A7;-><init>(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_1
    return-object v0
.end method

.method public final ongoing(LX/AHE;)Lcom/facebook/aura/assist/api/AssistOngoingCall;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-interface {v0, p1}, Lcom/facebook/aura/assist/api/AssistCall;->ongoing(LX/AHE;)Lcom/facebook/aura/assist/api/AssistOngoingCall;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    return-object v0
.end method

.method public final presentCompactly(LX/AHE;)Lcom/facebook/aura/assist/api/AssistCompactPresentation;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/assist/api/AssistCalls;->getCall()Lcom/facebook/aura/assist/api/AssistCall;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-interface {v0, p1}, Lcom/facebook/aura/assist/api/AssistCall;->presentCompactly(LX/AHE;)Lcom/facebook/aura/assist/api/AssistCompactPresentation;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    :cond_0
    sget-object v0, Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls$presentCompactly$1;

    .line 17
    .line 18
    :cond_1
    return-object v0
.end method
