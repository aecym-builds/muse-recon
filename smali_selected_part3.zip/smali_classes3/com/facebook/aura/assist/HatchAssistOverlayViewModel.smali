.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _micFocusRequests:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final _overlayState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            ">;"
        }
    .end annotation
.end field

.field public final context:Landroid/content/Context;

.field public final conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

.field public hasInitializedSession:Z

.field public final micFocusRequests:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final overlayState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            ">;"
        }
    .end annotation
.end field

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/AHE;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V
    .locals 5

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    sget-object v2, Lcom/facebook/aura/assist/AssistOverlayMode;->VOICE:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 16
    .line 17
    new-instance v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 18
    .line 19
    invoke-direct {v0, v2, v1, v4}, Lcom/facebook/aura/assist/AssistOverlayState;-><init>(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-static {v0}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    iput-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 27
    .line 28
    const/4 v0, -0x1

    .line 29
    sget-object v3, LX/FkO;->A00:Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-static {v3, v0}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    iput-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_micFocusRequests:LX/EYl;

    .line 36
    .line 37
    invoke-static {v2}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->overlayState:LX/2J3;

    .line 42
    .line 43
    invoke-static {v1}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->micFocusRequests:LX/2Lw;

    .line 48
    .line 49
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1;

    .line 54
    .line 55
    invoke-direct {v0, p0, v4}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/2M4;)V

    .line 56
    .line 57
    .line 58
    sget-object v2, LX/39s;->A00:LX/39s;

    .line 59
    .line 60
    invoke-static {p0, v3, v2, v0, v1}, LX/602;->A0C(LX/1EJ;Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERX;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2;

    .line 65
    .line 66
    invoke-direct {v0, p0, v4}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/2M4;)V

    .line 67
    .line 68
    .line 69
    invoke-static {v3, v2, v0, v1}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 70
    .line 71
    .line 72
    return-void
.end method

.method public static final synthetic access$getContext$p(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)Landroid/content/Context;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_overlayState$p(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$onDictationStopped(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/composer/api/DictationOutcome;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onDictationStopped(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final bargeInToVoice()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->isVoiceDictationAvailable()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onKeyboardModeSelected()V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->stopGeneration()V

    .line 13
    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/composer/api/DictationStartTrigger;->MIC:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceDictation(Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method private final hasSubmittableInput()Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->composerTextState:LX/3QE;

    .line 3
    .line 4
    invoke-virtual {v0}, LX/3QE;->A08()Ljava/lang/CharSequence;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 15
    .line 16
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->uiState:LX/2J3;

    .line 17
    .line 18
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 23
    .line 24
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->pendingImageUris:LX/Ddn;

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    const/4 v0, 0x0

    .line 31
    if-nez p0, :cond_1

    .line 32
    .line 33
    :cond_0
    const/4 v0, 0x1

    .line 34
    :cond_1
    return v0
.end method

.method private final isScreenReaderEnabled()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-static {p0}, LX/0bQ;->A00(Landroid/content/Context;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method private final isVoiceDictationAvailable()Z
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/composer/api/DictationMode;->AUTO_SUBMIT:Lcom/facebook/aura/composer/api/DictationMode;

    .line 5
    .line 6
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->isAvailable(Lcom/facebook/aura/composer/api/DictationMode;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    sget-object v1, Lcom/facebook/aura/conversation/api/ConversationInputBlocks;->INSTANCE:Lcom/facebook/aura/conversation/api/ConversationInputBlocks;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Lcom/facebook/aura/conversation/api/ConversationInputBlocks;->isBlocked(LX/AHE;)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, 0x1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :cond_1
    return v0
.end method

.method private final onDictationStopped(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/composer/api/DictationOutcome;->FAILED:Lcom/facebook/aura/composer/api/DictationOutcome;

    .line 1
    .line 2
    if-ne p1, v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->requestComposerFocus()V

    .line 7
    .line 8
    .line 9
    :cond_0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 10
    .line 11
    :cond_1
    invoke-interface {p0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    move-object v3, v4

    .line 16
    check-cast v3, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/composer/api/DictationOutcome;->FAILED:Lcom/facebook/aura/composer/api/DictationOutcome;

    .line 19
    .line 20
    if-eq p1, v0, :cond_3

    .line 21
    .line 22
    if-nez p2, :cond_3

    .line 23
    .line 24
    iget-object v0, v3, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 25
    .line 26
    :goto_0
    iget-object v2, v3, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 27
    .line 28
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 29
    .line 30
    if-ne v2, v1, :cond_2

    .line 31
    .line 32
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 33
    .line 34
    :goto_1
    iget-object v2, v3, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {v3, v0, v1, v2}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {p0, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    return-void

    .line 47
    :cond_2
    iget-object v1, v3, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_3
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayMode;->KEYBOARD:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 51
    .line 52
    goto :goto_0
.end method

.method public static synthetic onDictationStopped$default(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/composer/api/DictationOutcome;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p3, p2}, LX/3Rr;->A1O(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onDictationStopped(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final startVoiceDictation(Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V
    .locals 6

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/composer/api/DictationMode;->AUTO_SUBMIT:Lcom/facebook/aura/composer/api/DictationMode;

    .line 5
    .line 6
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$1;

    .line 7
    .line 8
    invoke-direct {v3, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V

    .line 9
    .line 10
    .line 11
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$2;

    .line 12
    .line 13
    invoke-direct {v4, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$2;-><init>(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    move-object v1, p1

    .line 17
    move v5, p2

    .line 18
    invoke-interface/range {v0 .. v5}, Lcom/facebook/aura/composer/api/ComposerDictation;->start(Lcom/facebook/aura/composer/api/DictationStartTrigger;Lcom/facebook/aura/composer/api/DictationMode;Lkotlin/jvm/functions/Function0;LX/JDM;Z)V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 22
    .line 23
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 24
    .line 25
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/ComposerDictationState;->getPhase()LX/2J3;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Lcom/facebook/aura/composer/api/DictationPhase;

    .line 34
    .line 35
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/DictationPhase;->isActive()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 42
    .line 43
    :cond_0
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    move-object v0, v4

    .line 48
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 49
    .line 50
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayMode;->VOICE:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 51
    .line 52
    sget-object v2, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 53
    .line 54
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 55
    .line 56
    new-instance v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 57
    .line 58
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/assist/AssistOverlayState;-><init>(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_0

    .line 66
    .line 67
    :cond_1
    return-void
.end method

.method public static synthetic startVoiceDictation$default(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/composer/api/DictationStartTrigger;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p3, p2}, LX/3Rr;->A1O(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceDictation(Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 1
    .line 2
    const-string v0, "android.permission.RECORD_AUDIO"

    .line 3
    .line 4
    invoke-virtual {v1, p1, v0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->isVoiceDictationAvailable()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-direct {p0, p2, p3}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceDictation(Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 21
    .line 22
    :cond_1
    invoke-static {v1}, LX/604;->A16(LX/2J2;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    return-void
.end method

.method public static synthetic startVoiceWithPermission$default(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final submitCurrentInput(Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;)V
    .locals 6

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->hasSubmittableInput()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    :cond_0
    invoke-static {v5}, LX/604;->A13(LX/2J2;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    return-void

    .line 15
    :cond_1
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    move-object v2, v4

    .line 20
    check-cast v2, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 21
    .line 22
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    iget-object v0, v2, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 26
    .line 27
    invoke-virtual {v2, v0, v1, v3}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;

    .line 46
    .line 47
    invoke-direct {v0, p0, p1, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v1, v0, v2}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method


# virtual methods
.method public final cancelVoiceDictation()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-static {v1}, LX/604;->A13(LX/2J2;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    return-void
.end method

.method public final endVoiceDictation()V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->isFinalizing()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_2

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->end(Z)V

    .line 16
    .line 17
    .line 18
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 19
    .line 20
    :cond_0
    invoke-interface {p0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    move-object v0, v4

    .line 25
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 26
    .line 27
    iget-object v2, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 28
    .line 29
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 30
    .line 31
    if-ne v2, v1, :cond_1

    .line 32
    .line 33
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 34
    .line 35
    iget-object v2, v0, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 36
    .line 37
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v0, v2, v3, v1}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    :cond_1
    invoke-interface {p0, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    :cond_2
    return-void
.end method

.method public final endVoiceDictationAndSend()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$endVoiceDictationAndSend$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V

    .line 7
    .line 8
    .line 9
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->endAndSend(LX/JDN;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final getConversationViewModel()Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMicFocusRequests()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->micFocusRequests:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOverlayState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->overlayState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public onCleared()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->uiState:LX/2J3;

    .line 11
    .line 12
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 17
    .line 18
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->pendingImageUris:LX/Ddn;

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-static {v3}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    sget-object v1, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->INSTANCE:Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 37
    .line 38
    invoke-virtual {v1, v0, v2}, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->delete(Landroid/content/Context;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 49
    .line 50
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$onCleared$2;

    .line 55
    .line 56
    invoke-direct {v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$onCleared$2;-><init>(Landroid/content/Context;)V

    .line 57
    .line 58
    .line 59
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public final onComposerFocusChanged(Z)V
    .locals 2

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 3
    .line 4
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 9
    .line 10
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->onComposerFocusChanged(Z)V

    .line 19
    .line 20
    .line 21
    :cond_1
    return-void
.end method

.method public final onInvokedAgain()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-static {v0}, LX/0bQ;->A00(Landroid/content/Context;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 9
    .line 10
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 15
    .line 16
    iget-object v3, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 19
    .line 20
    if-eq v3, v0, :cond_1

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 23
    .line 24
    if-eq v3, v0, :cond_1

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 27
    .line 28
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 29
    .line 30
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->isFinalizing()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 37
    .line 38
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->hasComposerText()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_1

    .line 43
    .line 44
    sget-object v1, Lcom/facebook/aura/livesession/api/LiveSessions;->INSTANCE:Lcom/facebook/aura/livesession/api/LiveSessions;

    .line 45
    .line 46
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 47
    .line 48
    invoke-virtual {v1, v0}, Lcom/facebook/aura/livesession/api/LiveSessions;->isActive(LX/AHE;)LX/2J3;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-static {v0}, LX/3Rq;->A1W(LX/2J3;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_1

    .line 57
    .line 58
    sget-object v0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;->INSTANCE:Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;

    .line 59
    .line 60
    invoke-virtual {v0}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;->isInCallNow()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-nez v0, :cond_1

    .line 65
    .line 66
    sget-object v2, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 67
    .line 68
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 69
    .line 70
    const-string v0, "android.permission.RECORD_AUDIO"

    .line 71
    .line 72
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_1

    .line 77
    .line 78
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->isVoiceDictationAvailable()Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_1

    .line 83
    .line 84
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 85
    .line 86
    if-ne v3, v0, :cond_0

    .line 87
    .line 88
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->stopGeneration()V

    .line 89
    .line 90
    .line 91
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 92
    .line 93
    sget-object v1, Lcom/facebook/aura/composer/api/DictationStartTrigger;->ASSIST_AGAIN:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 94
    .line 95
    const/4 v0, 0x0

    .line 96
    invoke-direct {p0, v2, v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 97
    .line 98
    .line 99
    :cond_1
    return-void
.end method

.method public final onKeyboardModeSelected()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->end(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 9
    .line 10
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 15
    .line 16
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 19
    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 23
    .line 24
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->stopGeneration()V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 28
    .line 29
    :cond_1
    invoke-static {v1}, LX/604;->A16(LX/2J2;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    return-void
.end method

.method public final onMicClick(Landroid/content/Context;Z)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 7
    .line 8
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/ComposerDictationState;->getPhase()LX/2J3;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/composer/api/DictationPhase;

    .line 17
    .line 18
    invoke-interface {v0}, Lcom/facebook/aura/composer/api/DictationPhase;->isActive()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_1

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 25
    .line 26
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 27
    .line 28
    invoke-interface {v0, v1}, Lcom/facebook/aura/composer/api/ComposerDictation;->end(Z)V

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 32
    .line 33
    :cond_0
    invoke-static {v1}, LX/604;->A13(LX/2J2;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    return-void

    .line 40
    :cond_1
    sget-object v0, Lcom/facebook/aura/composer/api/DictationStartTrigger;->MIC:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 41
    .line 42
    invoke-direct {p0, p1, v0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public final onPrimaryVoiceAction(Landroid/content/Context;)V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eq v1, v2, :cond_3

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    if-eq v1, v0, :cond_2

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    if-eq v1, v0, :cond_1

    .line 25
    .line 26
    const/4 v0, 0x3

    .line 27
    if-eq v1, v0, :cond_0

    .line 28
    .line 29
    const/4 v0, 0x4

    .line 30
    if-eq v1, v0, :cond_0

    .line 31
    .line 32
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    throw v0

    .line 37
    :cond_0
    sget-object v0, Lcom/facebook/aura/composer/api/DictationStartTrigger;->MIC:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 38
    .line 39
    invoke-direct {p0, p1, v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 40
    .line 41
    .line 42
    :cond_1
    return-void

    .line 43
    :cond_2
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->bargeInToVoice()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_3
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->endVoiceDictationAndSend()V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public final onSessionHidden()V
    .locals 6

    .line 0
    sget-object v0, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->INSTANCE:Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->onAssistOverlayDismissed()V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 6
    .line 7
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v5, 0x0

    .line 11
    const/4 v0, 0x1

    .line 12
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 16
    .line 17
    const-string v0, ""

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->setComposerText(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iput-boolean v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->hasInitializedSession:Z

    .line 23
    .line 24
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 25
    .line 26
    :cond_0
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    sget-object v2, Lcom/facebook/aura/assist/AssistOverlayMode;->VOICE:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 31
    .line 32
    sget-object v1, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 33
    .line 34
    new-instance v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 35
    .line 36
    invoke-direct {v0, v2, v1, v5}, Lcom/facebook/aura/assist/AssistOverlayState;-><init>(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-interface {v4, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_0

    .line 44
    .line 45
    return-void
.end method

.method public final onSessionShown(Z)V
    .locals 3

    .line 0
    sget-object v1, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->INSTANCE:Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->getGateway(LX/AHE;)Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {v0, v1}, Lcom/facebook/aura/gateway/HatchGatewayConnection;->setAssistOverlayActive(Z)V

    .line 10
    .line 11
    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->hasInitializedSession:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iput-boolean v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->hasInitializedSession:Z

    .line 17
    .line 18
    if-eqz p1, :cond_2

    .line 19
    .line 20
    sget-object v1, Lcom/facebook/aura/livesession/api/LiveSessions;->INSTANCE:Lcom/facebook/aura/livesession/api/LiveSessions;

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Lcom/facebook/aura/livesession/api/LiveSessions;->isActive(LX/AHE;)LX/2J3;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0}, LX/3Rq;->A1W(LX/2J3;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_2

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;->INSTANCE:Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker;->isInCallNow()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_2

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 43
    .line 44
    invoke-static {v0}, LX/0bQ;->A00(Landroid/content/Context;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    sget-object v2, Lcom/facebook/aura/microphone/api/Microphone;->INSTANCE:Lcom/facebook/aura/microphone/api/Microphone;

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->userSession:LX/AHE;

    .line 53
    .line 54
    sget-object v0, Lcom/facebook/aura/microphone/api/MicrophonePriority;->TRANSIENT:Lcom/facebook/aura/microphone/api/MicrophonePriority;

    .line 55
    .line 56
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/microphone/api/Microphone;->preempt(LX/AHE;Lcom/facebook/aura/microphone/api/MicrophonePriority;)V

    .line 57
    .line 58
    .line 59
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_micFocusRequests:LX/EYl;

    .line 60
    .line 61
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 62
    .line 63
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    :cond_0
    return-void

    .line 67
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 68
    .line 69
    sget-object v1, Lcom/facebook/aura/composer/api/DictationStartTrigger;->ASSIST_OPEN:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    invoke-direct {p0, v2, v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 77
    .line 78
    :cond_3
    invoke-static {v1}, LX/604;->A16(LX/2J2;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    return-void
.end method

.method public final onVoiceModeSelected(Landroid/content/Context;)V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 15
    .line 16
    if-ne v1, v0, :cond_0

    .line 17
    .line 18
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->bargeInToVoice()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    sget-object v0, Lcom/facebook/aura/composer/api/DictationStartTrigger;->MIC:Lcom/facebook/aura/composer/api/DictationStartTrigger;

    .line 23
    .line 24
    invoke-direct {p0, p1, v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->startVoiceWithPermission(Landroid/content/Context;Lcom/facebook/aura/composer/api/DictationStartTrigger;Z)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final prepareForVoiceCall()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-interface {v1, v0}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-static {v1}, LX/604;->A16(LX/2J2;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    return-void
.end method

.method public final removePendingImage(I)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->attachments:Lcom/facebook/aura/conversation/viewmodel/HatchConversationAttachments;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationAttachments;->removePendingImageUri(I)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    if-eqz v2, :cond_0

    .line 9
    .line 10
    sget-object v1, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->INSTANCE:Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->context:Landroid/content/Context;

    .line 13
    .line 14
    invoke-virtual {v1, v0, v2}, Lcom/facebook/aura/components/screenshot/HatchScreenshotFiles;->delete(Landroid/content/Context;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final stopGeneration()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->stopGeneration()V

    .line 3
    .line 4
    .line 5
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 6
    .line 7
    :cond_0
    invoke-static {p0}, LX/604;->A13(LX/2J2;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    return-void
.end method

.method public final submitHardwareEnterTurn(Ljava/lang/String;)Z
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->hasSubmittableInput()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    return v0

    .line 8
    :cond_0
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->submitKeyboardTurn(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    return v0
.end method

.method public final submitKeyboardTurn(Ljava/lang/String;)V
    .locals 4

    .line 0
    invoke-static {p1}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->ASSIST:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 8
    .line 9
    invoke-direct {v0, v3, p1, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;-><init>(ZLjava/lang/String;Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-direct {p0, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->submitCurrentInput(Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final submitWidgetMessage(Lcom/facebook/aura/model/HatchSendMessage;)V
    .locals 6

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->dictation:Lcom/facebook/aura/composer/api/ComposerDictation;

    .line 7
    .line 8
    invoke-interface {v0, v1}, Lcom/facebook/aura/composer/api/ComposerDictation;->cancel(Z)V

    .line 9
    .line 10
    .line 11
    iget-object v5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 12
    .line 13
    :cond_0
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    move-object v3, v4

    .line 18
    check-cast v3, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 19
    .line 20
    sget-object v2, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    iget-object v0, v3, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 24
    .line 25
    invoke-virtual {v3, v0, v2, v1}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 36
    .line 37
    invoke-virtual {v0, p1}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->onWidgetSendMessage(Lcom/facebook/aura/model/HatchSendMessage;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
