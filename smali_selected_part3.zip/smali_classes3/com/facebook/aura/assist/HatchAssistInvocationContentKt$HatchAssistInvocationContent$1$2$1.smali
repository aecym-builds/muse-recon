.class public final synthetic Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$2$1;
.super LX/DVE;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "LX/JDO<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 0
    const-class v3, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    const-string v5, "onWidgetSetState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V"

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    const/4 v1, 0x4

    .line 6
    const-string v4, "onWidgetSetState"

    .line 7
    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/lang/String;

    .line 268435459
    .line 268435460
    check-cast p3, Ljava/lang/String;

    .line 268435461
    .line 268435462
    invoke-static {p4}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435463
    .line 268435464
    .line 268435465
    move-result v0

    .line 268435466
    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$2$1;->invoke(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 268435467
    .line 268435468
    .line 268435469
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435470
    .line 268435471
    return-object v0
.end method

.method public final invoke(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object p0, p0, LX/DqR;->receiver:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 6
    .line 7
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->onWidgetSetState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
