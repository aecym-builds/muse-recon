.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2gu;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $identityState:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $overlayAlpha$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/AssistVoicePresentation;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$overlayAlpha$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2gu;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->invoke(LX/2gu;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2gu;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$overlayAlpha$delegate:LX/16A;

    .line 5
    .line 6
    invoke-static {v0}, LX/16A;->A00(LX/16A;)F

    .line 7
    .line 8
    .line 9
    move-result v3

    .line 10
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$identityState:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistIdentityState;->progress:LX/16A;

    .line 13
    .line 14
    invoke-static {v0}, LX/16A;->A00(LX/16A;)F

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/high16 v2, 0x3f800000    # 1.0f

    .line 19
    .line 20
    sub-float v0, v2, v0

    .line 21
    .line 22
    mul-float/2addr v3, v0

    .line 23
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/assist/AssistVoicePresentation;->progress:LX/16A;

    .line 26
    .line 27
    invoke-static {v0}, LX/16A;->A00(LX/16A;)F

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    const/high16 v0, 0x40200000    # 2.5f

    .line 32
    .line 33
    mul-float/2addr v1, v0

    .line 34
    sub-float v1, v2, v1

    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-static {v1, v0, v2}, LX/34j;->A04(FFF)F

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    mul-float/2addr v3, v0

    .line 42
    invoke-interface {p1, v3}, LX/2gu;->AdD(F)V

    .line 43
    .line 44
    .line 45
    return-void
.end method
