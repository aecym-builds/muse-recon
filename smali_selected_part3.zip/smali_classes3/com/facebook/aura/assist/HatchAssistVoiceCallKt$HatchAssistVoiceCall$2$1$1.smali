.class public final Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/2vi;",
        "LX/2sf;",
        "Landroidx/compose/ui/unit/Constraints;",
        "LX/3CP;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $layout:Lcom/facebook/aura/assist/AssistVoiceLayout;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoiceLayout;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2vi;

    .line 1
    .line 2
    check-cast p2, LX/2sf;

    .line 3
    .line 4
    check-cast p3, Landroidx/compose/ui/unit/Constraints;

    .line 5
    .line 6
    iget-wide v0, p3, Landroidx/compose/ui/unit/Constraints;->A00:J

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1;->invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;
    .locals 5

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 5
    .line 6
    iget v0, v0, Lcom/facebook/aura/assist/AssistVoiceLayout;->controlsTop:F

    .line 7
    .line 8
    invoke-static {v0}, LX/0sc;->A01(F)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-ge v1, v2, :cond_0

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    :cond_0
    invoke-static {p3, p4}, Landroidx/compose/ui/unit/Constraints;->A03(J)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-static {p3, p4}, Landroidx/compose/ui/unit/Constraints;->A01(J)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    invoke-static {v0, v4, v2, v1}, Landroidx/compose/ui/unit/Constraints;->A05(IIII)J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    invoke-interface {p2, v0, v1}, LX/2sf;->AQh(J)LX/3B5;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-static {p3, p4}, Landroidx/compose/ui/unit/Constraints;->A00(J)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1;->$layout:Lcom/facebook/aura/assist/AssistVoiceLayout;

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;

    .line 38
    .line 39
    invoke-direct {v0, v3, v1}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$HatchAssistVoiceCall$2$1$1$1;-><init>(LX/3B5;Lcom/facebook/aura/assist/AssistVoiceLayout;)V

    .line 40
    .line 41
    .line 42
    invoke-static {p1, v0, v4, v2}, LX/602;->A0B(LX/2vi;LX/JDM;II)LX/3CP;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0
.end method
