.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

.field public final synthetic $overlayState:Lcom/facebook/aura/assist/AssistOverlayState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/vds/compose/theme/AuraColors;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;->$colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;->invoke(LX/1Xg;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 25

    .line 268435456
    const/4 v14, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    move/from16 v1, p3

    .line 268435460
    .line 268435461
    invoke-static {v0, v14, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object/from16 v4, p2

    .line 268435466
    .line 268435467
    invoke-static {v0, v4, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    if-eqz v0, :cond_1

    .line 268435472
    .line 268435473
    move-object/from16 v1, p0

    .line 268435474
    .line 268435475
    iget-object v0, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435476
    .line 268435477
    iget-object v12, v0, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 268435478
    .line 268435479
    if-nez v12, :cond_0

    .line 268435480
    .line 268435481
    const v0, 0x20dfafac

    .line 268435482
    .line 268435483
    .line 268435484
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 268435485
    .line 268435486
    .line 268435487
    const v0, 0x7f1201d1

    .line 268435488
    .line 268435489
    .line 268435490
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435491
    .line 268435492
    .line 268435493
    move-result-object v12

    .line 268435494
    :goto_0
    invoke-static {v4}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435495
    .line 268435496
    .line 268435497
    iget-object v0, v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;->$colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 268435498
    .line 268435499
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->errorText:J

    .line 268435500
    .line 268435501
    const/16 v2, 0xe

    .line 268435502
    .line 268435503
    invoke-static {v2}, LX/2S9;->A02(I)J

    .line 268435504
    .line 268435505
    .line 268435506
    move-result-wide v22

    .line 268435507
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 268435508
    .line 268435509
    const/4 v6, 0x0

    .line 268435510
    const/high16 v2, 0x40c00000    # 6.0f

    .line 268435511
    .line 268435512
    invoke-static {v3, v2}, LX/2pj;->A05(LX/3C1;F)LX/3C1;

    .line 268435513
    .line 268435514
    .line 268435515
    move-result-object v5

    .line 268435516
    const v19, 0x1fff0

    .line 268435517
    .line 268435518
    .line 268435519
    const-wide/16 v24, 0x0

    .line 268435520
    .line 268435521
    const/16 v17, 0xc30

    .line 268435522
    .line 268435523
    move-object v7, v6

    .line 268435524
    move-object v8, v6

    .line 268435525
    move-object v9, v6

    .line 268435526
    move-object v10, v6

    .line 268435527
    move-object v11, v6

    .line 268435528
    move-object v13, v6

    .line 268435529
    move v15, v14

    .line 268435530
    move/from16 v16, v14

    .line 268435531
    .line 268435532
    move/from16 v18, v14

    .line 268435533
    .line 268435534
    move-wide/from16 v20, v0

    .line 268435535
    .line 268435536
    move-wide/from16 p1, v24

    .line 268435537
    .line 268435538
    move/from16 p3, v14

    .line 268435539
    .line 268435540
    invoke-static/range {v4 .. v28}, LX/2rV;->A00(LX/2d4;LX/3C1;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2wS;LX/2RW;Ljava/lang/String;LX/JDM;IIIIIIJJJJZ)V

    .line 268435541
    .line 268435542
    .line 268435543
    return-void

    .line 268435544
    :cond_0
    const v0, 0x20dfa887

    .line 268435545
    .line 268435546
    .line 268435547
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 268435548
    .line 268435549
    .line 268435550
    goto :goto_0

    .line 268435551
    :cond_1
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 268435552
    .line 268435553
    .line 268435554
    return-void
.end method
