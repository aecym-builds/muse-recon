.class public final Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/assist/AssistIdentityState;

.field public final synthetic $token:J

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchVoiceInteractionSession;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;Lcom/facebook/aura/assist/AssistIdentityState;J)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->this$0:Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->$state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->$token:J

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->this$0:Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 1
    .line 2
    iget-object v0, v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 3
    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    iget-object v1, v0, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 7
    .line 8
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->$state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 9
    .line 10
    if-ne v1, v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->resetAfterVoiceCall$fbandroid_express_aura_java_com_facebook_aura_assist_assist()V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void

    .line 20
    :cond_1
    const/4 v1, 0x0

    .line 21
    goto :goto_0

    .line 22
    :cond_2
    sget-object v2, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 23
    .line 24
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->$token:J

    .line 25
    .line 26
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->clearIfCurrent(J)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->this$0:Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 30
    .line 31
    invoke-static {v0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->access$clearIdentityHost(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)V

    .line 32
    .line 33
    .line 34
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$showIdentity$3;->this$0:Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-virtual {v1, v0}, Landroid/service/voice/VoiceInteractionSession;->setUiEnabled(Z)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
