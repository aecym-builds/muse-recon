.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/gateway/HatchGatewayConnectionState;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.assist.HatchAssistOverlayViewModel$submitCurrentInput$3$result$1"
    f = "HatchAssistOverlayViewModel.kt"
    l = {
        0x179
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $gateway:Lcom/facebook/aura/gateway/HatchGatewayConnection;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchGatewayConnection;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchGatewayConnection;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->$gateway:Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->$gateway:Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;-><init>(Lcom/facebook/aura/gateway/HatchGatewayConnection;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/gateway/HatchGatewayConnectionState;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->$gateway:Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;-><init>(Lcom/facebook/aura/gateway/HatchGatewayConnection;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-object p1

    .line 13
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->$gateway:Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 17
    .line 18
    iget-object v2, v0, Lcom/facebook/aura/gateway/HatchGatewayConnection;->connectionState:LX/2J3;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1$1;

    .line 22
    .line 23
    invoke-direct {v0, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1$1;-><init>(LX/2M4;)V

    .line 24
    .line 25
    .line 26
    iput v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$result$1;->label:I

    .line 27
    .line 28
    invoke-static {p0, v0, v2}, LX/IxD;->A00(LX/2M4;LX/JDN;LX/2Lw;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    if-ne p1, v4, :cond_0

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    throw v0
.end method
