.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.assist.HatchAssistOverlayViewModel$submitCurrentInput$3$2"
    f = "HatchAssistOverlayViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 8
    .line 9
    iget-object p1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 10
    .line 11
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$submitCurrentInput$3$2;->$sendButtonOrigin:Lcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-virtual {p1, v0, p0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->sendMessage(ZLcom/facebook/aura/analytics/hatch/HatchSendButtonOrigin;)Z

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0

    .line 20
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    throw v0
.end method
