.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$changed1:I

.field public final synthetic $$changed2:I

.field public final synthetic $$default:I

.field public final synthetic $announcement:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationAnnouncement;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $composerCallAction:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $composerTextState:LX/3QE;

.field public final synthetic $convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

.field public final synthetic $conversationListItems:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $dictation:Lcom/facebook/aura/composer/api/view/ComposerDictationUi;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onClearImageClick:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onCollapseVoice:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onComposerFocusChanged:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onComposerFocusRequested:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDictationStarted:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDismissRequest:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDraftEdited:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onEndDictation:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onHardwareEnter:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onImageAttached:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOpenFullApp:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSendClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStartComposing:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onStopGeneration:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onWidgetSendMessage:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/model/HatchSendMessage;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onWidgetSetState:LX/JDO;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDO<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

.field public final synthetic $screenScreenshot:Landroid/graphics/Bitmap;

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/Ddn;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3QE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDO;LX/2Lw;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;LX/3C1;Landroid/graphics/Bitmap;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;IIII)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3QE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/model/HatchSendMessage;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDO<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2Lw<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationAnnouncement;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/composer/api/view/ComposerDictationUi;",
            "LX/3C1;",
            "Landroid/graphics/Bitmap;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;IIII)V"
        }
    .end annotation

    .line 709064
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$conversationListItems:LX/Ddn;

    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$threadId:Ljava/lang/String;

    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onCollapseVoice:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onOpenFullApp:Lkotlin/jvm/functions/Function0;

    iput-object p8, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$composerTextState:LX/3QE;

    iput-object p9, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onSendClick:Lkotlin/jvm/functions/Function0;

    iput-object p10, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onHardwareEnter:Lkotlin/jvm/functions/Function0;

    iput-object p11, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onWidgetSendMessage:LX/JDM;

    iput-object p12, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onWidgetSetState:LX/JDO;

    iput-object p13, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$announcement:LX/2Lw;

    iput-object p14, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onStartComposing:Lkotlin/jvm/functions/Function0;

    move-object/from16 v0, p15

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onComposerFocusChanged:LX/JDM;

    move-object/from16 v0, p16

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDictationStarted:Lkotlin/jvm/functions/Function0;

    move-object/from16 v0, p17

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDraftEdited:Lkotlin/jvm/functions/Function0;

    move-object/from16 v0, p18

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$dictation:Lcom/facebook/aura/composer/api/view/ComposerDictationUi;

    move-object/from16 v0, p19

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$modifier:LX/3C1;

    move-object/from16 v0, p20

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$screenScreenshot:Landroid/graphics/Bitmap;

    move-object/from16 v0, p21

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onImageAttached:LX/JDM;

    move-object/from16 v0, p22

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onClearImageClick:LX/JDM;

    move-object/from16 v0, p23

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onEndDictation:Lkotlin/jvm/functions/Function0;

    move-object/from16 v0, p24

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onStopGeneration:Lkotlin/jvm/functions/Function0;

    move-object/from16 v0, p25

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$composerCallAction:LX/JDN;

    move-object/from16 v0, p26

    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onComposerFocusRequested:Lkotlin/jvm/functions/Function0;

    move/from16 v0, p27

    iput v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed:I

    move/from16 v0, p28

    iput v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed1:I

    move/from16 v0, p29

    iput v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed2:I

    move/from16 v0, p30

    iput v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$default:I

    const/4 v0, 0x2

    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 46

    .line 268435456
    move-object/from16 v0, p0

    .line 268435457
    .line 268435458
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435459
    .line 268435460
    move-object/from16 p0, v1

    .line 268435461
    .line 268435462
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 268435463
    .line 268435464
    move-object/from16 v45, v1

    .line 268435465
    .line 268435466
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$conversationListItems:LX/Ddn;

    .line 268435467
    .line 268435468
    move-object/from16 v44, v1

    .line 268435469
    .line 268435470
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$threadId:Ljava/lang/String;

    .line 268435471
    .line 268435472
    move-object/from16 v16, v1

    .line 268435473
    .line 268435474
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDismissRequest:Lkotlin/jvm/functions/Function0;

    .line 268435475
    .line 268435476
    move-object/from16 v17, v1

    .line 268435477
    .line 268435478
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onCollapseVoice:Lkotlin/jvm/functions/Function0;

    .line 268435479
    .line 268435480
    move-object/from16 v18, v1

    .line 268435481
    .line 268435482
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onOpenFullApp:Lkotlin/jvm/functions/Function0;

    .line 268435483
    .line 268435484
    move-object/from16 v19, v1

    .line 268435485
    .line 268435486
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$composerTextState:LX/3QE;

    .line 268435487
    .line 268435488
    move-object/from16 v20, v1

    .line 268435489
    .line 268435490
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onSendClick:Lkotlin/jvm/functions/Function0;

    .line 268435491
    .line 268435492
    move-object/from16 v21, v1

    .line 268435493
    .line 268435494
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onHardwareEnter:Lkotlin/jvm/functions/Function0;

    .line 268435495
    .line 268435496
    move-object/from16 v22, v1

    .line 268435497
    .line 268435498
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onWidgetSendMessage:LX/JDM;

    .line 268435499
    .line 268435500
    move-object/from16 v23, v1

    .line 268435501
    .line 268435502
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onWidgetSetState:LX/JDO;

    .line 268435503
    .line 268435504
    move-object/from16 v24, v1

    .line 268435505
    .line 268435506
    iget-object v15, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$announcement:LX/2Lw;

    .line 268435507
    .line 268435508
    iget-object v14, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onStartComposing:Lkotlin/jvm/functions/Function0;

    .line 268435509
    .line 268435510
    iget-object v12, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onComposerFocusChanged:LX/JDM;

    .line 268435511
    .line 268435512
    iget-object v11, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDictationStarted:Lkotlin/jvm/functions/Function0;

    .line 268435513
    .line 268435514
    iget-object v10, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onDraftEdited:Lkotlin/jvm/functions/Function0;

    .line 268435515
    .line 268435516
    iget-object v9, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$dictation:Lcom/facebook/aura/composer/api/view/ComposerDictationUi;

    .line 268435517
    .line 268435518
    iget-object v8, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$modifier:LX/3C1;

    .line 268435519
    .line 268435520
    iget-object v7, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$screenScreenshot:Landroid/graphics/Bitmap;

    .line 268435521
    .line 268435522
    iget-object v6, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onImageAttached:LX/JDM;

    .line 268435523
    .line 268435524
    iget-object v5, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onClearImageClick:LX/JDM;

    .line 268435525
    .line 268435526
    iget-object v4, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onEndDictation:Lkotlin/jvm/functions/Function0;

    .line 268435527
    .line 268435528
    iget-object v3, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onStopGeneration:Lkotlin/jvm/functions/Function0;

    .line 268435529
    .line 268435530
    iget-object v2, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$composerCallAction:LX/JDN;

    .line 268435531
    .line 268435532
    iget-object v1, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$onComposerFocusRequested:Lkotlin/jvm/functions/Function0;

    .line 268435533
    .line 268435534
    iget v13, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed:I

    .line 268435535
    .line 268435536
    invoke-static {v13}, LX/0z0;->A00(I)I

    .line 268435537
    .line 268435538
    .line 268435539
    move-result v40

    .line 268435540
    iget v13, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed1:I

    .line 268435541
    .line 268435542
    invoke-static {v13}, LX/0z0;->A01(I)I

    .line 268435543
    .line 268435544
    .line 268435545
    move-result v41

    .line 268435546
    iget v13, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$changed2:I

    .line 268435547
    .line 268435548
    invoke-static {v13}, LX/0z0;->A01(I)I

    .line 268435549
    .line 268435550
    .line 268435551
    move-result v42

    .line 268435552
    iget v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;->$$default:I

    .line 268435553
    .line 268435554
    move-object/from16 v39, p1

    .line 268435555
    .line 268435556
    move-object/from16 v28, v11

    .line 268435557
    .line 268435558
    move-object/from16 v29, v10

    .line 268435559
    .line 268435560
    move-object/from16 v30, v9

    .line 268435561
    .line 268435562
    move-object/from16 v31, v8

    .line 268435563
    .line 268435564
    move-object/from16 v32, v7

    .line 268435565
    .line 268435566
    move-object/from16 v33, v6

    .line 268435567
    .line 268435568
    move-object/from16 v34, v5

    .line 268435569
    .line 268435570
    move-object/from16 v35, v4

    .line 268435571
    .line 268435572
    move-object/from16 v36, v3

    .line 268435573
    .line 268435574
    move-object/from16 v37, v2

    .line 268435575
    .line 268435576
    move-object/from16 v38, v1

    .line 268435577
    .line 268435578
    move/from16 v43, v0

    .line 268435579
    .line 268435580
    move-object/from16 v25, v15

    .line 268435581
    .line 268435582
    move-object/from16 v26, v14

    .line 268435583
    .line 268435584
    move-object/from16 v27, v12

    .line 268435585
    .line 268435586
    move-object/from16 v13, p0

    .line 268435587
    .line 268435588
    move-object/from16 v14, v45

    .line 268435589
    .line 268435590
    move-object/from16 v15, v44

    .line 268435591
    .line 268435592
    invoke-static/range {v13 .. v43}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->HatchAssistOverlayScreen(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/Ddn;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3QE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDO;LX/2Lw;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;LX/3C1;Landroid/graphics/Bitmap;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;LX/2d4;IIII)V

    .line 268435593
    .line 268435594
    .line 268435595
    return-void
.end method
