.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOpenSettings:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$onOpenSettings:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$modifier:LX/3C1;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$$changed:I

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$$default:I

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 6

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$onOpenSettings:Lkotlin/jvm/functions/Function0;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$modifier:LX/3C1;

    .line 268435461
    .line 268435462
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$$changed:I

    .line 268435463
    .line 268435464
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v5

    .line 268435468
    iget p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;->$$default:I

    .line 268435469
    .line 268435470
    move-object v4, p1

    .line 268435471
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->EnableScreenshotDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435472
    .line 268435473
    .line 268435474
    return-void
.end method
