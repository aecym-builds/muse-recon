.class public final Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic launchFullApp$default(Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;Landroid/content/Context;Ljava/lang/String;ZILjava/lang/Object;)V
    .locals 2

    .line 0
    invoke-static {p4, p2}, LX/3Rr;->A0e(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, v1, v0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final clearIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 3

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 13
    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-wide v1, v0, Lcom/facebook/aura/assist/AssistIdentityHost;->token:J

    .line 21
    .line 22
    cmp-long v0, v1, p1

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 27
    .line 28
    if-ne v0, p3, :cond_0

    .line 29
    .line 30
    invoke-static {p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->access$clearIdentityHost(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;)V

    .line 31
    .line 32
    .line 33
    const/4 v0, 0x0

    .line 34
    invoke-virtual {p0, v0}, Landroid/service/voice/VoiceInteractionSession;->setUiEnabled(Z)V

    .line 35
    .line 36
    .line 37
    :cond_0
    return-void
.end method

.method public final detachIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/HatchAssistOverlayActivity;)Z
    .locals 6

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 5
    .line 6
    const/4 v5, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    check-cast v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 14
    .line 15
    if-eqz v4, :cond_0

    .line 16
    .line 17
    iget-object v3, v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    iget-wide v1, v3, Lcom/facebook/aura/assist/AssistIdentityHost;->token:J

    .line 22
    .line 23
    cmp-long v0, v1, p1

    .line 24
    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    iget-object v0, v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 28
    .line 29
    if-ne v0, p3, :cond_0

    .line 30
    .line 31
    invoke-virtual {v3}, Lcom/facebook/aura/assist/AssistIdentityHost;->isCallActive()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    iget-object v0, v3, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 38
    .line 39
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->isParked()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_0

    .line 44
    .line 45
    const/4 v0, 0x0

    .line 46
    iput-object v0, v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->controlsActivity:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 47
    .line 48
    iget-object v0, v3, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 49
    .line 50
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->detachPresentation()V

    .line 51
    .line 52
    .line 53
    return p0

    .line 54
    :cond_0
    return v5
.end method

.method public final launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v0, "com.facebook.aura.action.ASSIST"

    .line 5
    .line 6
    new-instance v1, Landroid/content/Intent;

    .line 7
    .line 8
    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "com.facebook.aura.main.AuraMainActivity"

    .line 12
    .line 13
    invoke-virtual {v1, p1, v0}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const/high16 v0, 0x34000000

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    const-string v0, "com.facebook.aura.extra.ASSIST_SIDE_CHAT_SESSION_ID"

    .line 26
    .line 27
    invoke-virtual {p0, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 28
    .line 29
    .line 30
    if-eqz p3, :cond_0

    .line 31
    .line 32
    const-string v1, "com.facebook.aura.extra.ASSIST_SIDE_CHAT_IS_NEW"

    .line 33
    .line 34
    const/4 v0, 0x1

    .line 35
    invoke-virtual {p0, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 36
    .line 37
    .line 38
    :cond_0
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :try_start_0
    invoke-virtual {p1, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 42
    .line 43
    .line 44
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    :catch_0
    move-exception p0

    .line 46
    const-string v1, "Failed to launch Hatch from assistant session"

    .line 47
    .line 48
    const-string v0, "HatchVoiceInteraction"

    .line 49
    .line 50
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final retainedIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(J)Lcom/facebook/aura/assist/AssistIdentityState;
    .locals 4

    .line 0
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v3, v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->identityHost:Lcom/facebook/aura/assist/AssistIdentityHost;

    .line 14
    .line 15
    if-eqz v3, :cond_0

    .line 16
    .line 17
    iget-wide v1, v3, Lcom/facebook/aura/assist/AssistIdentityHost;->token:J

    .line 18
    .line 19
    cmp-long v0, v1, p1

    .line 20
    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v3}, Lcom/facebook/aura/assist/AssistIdentityHost;->isCallActive()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget-object v0, v3, Lcom/facebook/aura/assist/AssistIdentityHost;->state:Lcom/facebook/aura/assist/AssistIdentityState;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    return-object p0
.end method

.method public final showIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    invoke-static {p3, p4}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->activeSession:Ljava/lang/ref/WeakReference;

    .line 4
    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 12
    .line 13
    if-eqz p0, :cond_0

    .line 14
    .line 15
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->access$showIdentity(Lcom/facebook/aura/assist/HatchVoiceInteractionSession;JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method
