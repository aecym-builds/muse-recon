.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CcV;


# instance fields
.field public final synthetic $conversation$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

.field public final synthetic this$0:LX/CcW;


# direct methods
.method public constructor <init>(LX/CcW;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;->this$0:LX/CcW;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;->$conversation$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public runPauseOrOnDisposeEffect()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1$invoke$$inlined$onPauseOrDispose$1;->$conversation$inlined:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-virtual {p0, v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->setOnScreen(Z)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
