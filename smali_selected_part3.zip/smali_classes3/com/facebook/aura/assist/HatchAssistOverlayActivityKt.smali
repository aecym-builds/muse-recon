.class public abstract Lcom/facebook/aura/assist/HatchAssistOverlayActivityKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final EXTRA_ASSIST_INVOCATION_TOKEN:Ljava/lang/String; = "com.facebook.aura.extra.ASSIST_INVOCATION_TOKEN"

.field public static final EXTRA_RESTORE_ASSIST_VOICE:Ljava/lang/String; = "com.facebook.aura.extra.RESTORE_ASSIST_VOICE"
