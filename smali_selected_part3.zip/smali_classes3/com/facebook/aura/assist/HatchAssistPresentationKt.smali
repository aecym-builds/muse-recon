.class public abstract Lcom/facebook/aura/assist/HatchAssistPresentationKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AssistIdentityPresentationEffect(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2d4;I)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Lcom/facebook/aura/assist/AssistVoiceLayout;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, -0x2cedcf8b

    .line 1
    .line 2
    .line 3
    move-object/from16 v10, p5

    .line 4
    .line 5
    invoke-interface {v10, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v7, p6

    .line 9
    .line 10
    and-int/lit8 v0, p6, 0x6

    .line 11
    .line 12
    move-object/from16 v9, p0

    .line 13
    .line 14
    if-nez v0, :cond_9

    .line 15
    .line 16
    invoke-static {v10, v9}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v12

    .line 20
    or-int v12, v12, p6

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 23
    .line 24
    move-object/from16 v8, p1

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-static {v10, v8}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    or-int/2addr v12, v0

    .line 33
    :cond_0
    and-int/lit16 v0, v7, 0x180

    .line 34
    .line 35
    const/16 v1, 0x100

    .line 36
    .line 37
    move-object/from16 p6, p2

    .line 38
    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    move-object/from16 v0, p6

    .line 42
    .line 43
    invoke-static {v10, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v12, v0

    .line 48
    :cond_1
    and-int/lit16 v0, v7, 0xc00

    .line 49
    .line 50
    const/16 v13, 0x800

    .line 51
    .line 52
    move-object/from16 p5, p3

    .line 53
    .line 54
    if-nez v0, :cond_2

    .line 55
    .line 56
    move-object/from16 v0, p5

    .line 57
    .line 58
    invoke-static {v10, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    or-int/2addr v12, v0

    .line 63
    :cond_2
    and-int/lit16 v2, v7, 0x6000

    .line 64
    .line 65
    const/16 v0, 0x4000

    .line 66
    .line 67
    move/from16 v11, p4

    .line 68
    .line 69
    if-nez v2, :cond_3

    .line 70
    .line 71
    invoke-static {v10, v11}, LX/004;->A0m(LX/2d4;Z)I

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    or-int/2addr v12, v2

    .line 76
    :cond_3
    and-int/lit16 v3, v12, 0x2493

    .line 77
    .line 78
    const/16 v2, 0x2492

    .line 79
    .line 80
    const/16 v16, 0x1

    .line 81
    .line 82
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    invoke-static {v2, v10, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eqz v2, :cond_8

    .line 91
    .line 92
    iget-object v2, v9, Lcom/facebook/aura/assist/AssistVoicePresentation;->identityBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 93
    .line 94
    invoke-static {v2}, LX/602;->A09(Landroidx/compose/runtime/MutableState;)LX/36Z;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    iget-object v3, v8, Lcom/facebook/aura/assist/AssistVoiceLayout;->identity:LX/36Z;

    .line 99
    .line 100
    and-int/lit8 v2, v12, 0xe

    .line 101
    .line 102
    or-int/lit16 v2, v2, 0xc00

    .line 103
    .line 104
    const-string p2, "assistantIdentityBounds"

    .line 105
    .line 106
    move-object/from16 v17, v9

    .line 107
    .line 108
    move-object/from16 p1, v3

    .line 109
    .line 110
    move-object/from16 p3, v10

    .line 111
    .line 112
    move/from16 p4, v2

    .line 113
    .line 114
    invoke-static/range {v17 .. v22}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->animateBounds(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/36Z;LX/36Z;Ljava/lang/String;LX/2d4;I)LX/16A;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    sget-object v2, Lcom/facebook/aura/assist/AssistIdentityStateKt;->LocalAssistIdentityState:LX/Ip3;

    .line 119
    .line 120
    invoke-interface {v10, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v5

    .line 124
    check-cast v5, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 125
    .line 126
    invoke-static {v10}, LX/602;->A03(LX/2d4;)Landroid/view/View;

    .line 127
    .line 128
    .line 129
    move-result-object v4

    .line 130
    invoke-virtual {v9}, Lcom/facebook/aura/assist/AssistVoicePresentation;->isVoice()Z

    .line 131
    .line 132
    .line 133
    move-result v3

    .line 134
    invoke-virtual {v9}, Lcom/facebook/aura/assist/AssistVoicePresentation;->getShowingVoice()Z

    .line 135
    .line 136
    .line 137
    move-result v2

    .line 138
    invoke-interface {v10, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v14

    .line 142
    invoke-static {v10, v3, v14}, LX/001;->A1X(LX/2d4;ZZ)Z

    .line 143
    .line 144
    .line 145
    move-result v15

    .line 146
    invoke-interface {v10, v2}, LX/2d4;->A6A(Z)Z

    .line 147
    .line 148
    .line 149
    move-result v14

    .line 150
    invoke-static {v10, v6, v4, v15, v14}, LX/603;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;ZZ)Z

    .line 151
    .line 152
    .line 153
    move-result v15

    .line 154
    and-int/lit16 v14, v12, 0x380

    .line 155
    .line 156
    invoke-static {v14, v1}, LX/003;->A1I(II)Z

    .line 157
    .line 158
    .line 159
    move-result v14

    .line 160
    or-int/2addr v14, v15

    .line 161
    and-int/lit16 v1, v12, 0x1c00

    .line 162
    .line 163
    invoke-static {v1, v13}, LX/003;->A1I(II)Z

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    or-int/2addr v14, v1

    .line 168
    const v1, 0xe000

    .line 169
    .line 170
    .line 171
    and-int/2addr v12, v1

    .line 172
    if-eq v12, v0, :cond_4

    .line 173
    .line 174
    const/16 v16, 0x0

    .line 175
    .line 176
    :cond_4
    or-int v14, v14, v16

    .line 177
    .line 178
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    if-nez v14, :cond_5

    .line 183
    .line 184
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 185
    .line 186
    if-ne v0, v1, :cond_6

    .line 187
    .line 188
    :cond_5
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$AssistIdentityPresentationEffect$1$1;

    .line 189
    .line 190
    move-object/from16 p0, p6

    .line 191
    .line 192
    move-object/from16 p1, p5

    .line 193
    .line 194
    move/from16 p2, v11

    .line 195
    .line 196
    move v15, v2

    .line 197
    move-object/from16 v16, v6

    .line 198
    .line 199
    move-object/from16 v17, v4

    .line 200
    .line 201
    move-object v12, v0

    .line 202
    move-object v13, v5

    .line 203
    move v14, v3

    .line 204
    invoke-direct/range {v12 .. v20}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$AssistIdentityPresentationEffect$1$1;-><init>(Lcom/facebook/aura/assist/AssistIdentityState;ZZLX/16A;Landroid/view/View;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V

    .line 205
    .line 206
    .line 207
    invoke-interface {v10, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 208
    .line 209
    .line 210
    :cond_6
    invoke-static {v10, v0}, LX/001;->A1F(LX/2d4;Ljava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    :goto_1
    invoke-interface {v10}, LX/2d4;->AAg()LX/J7V;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    if-eqz v1, :cond_7

    .line 218
    .line 219
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$AssistIdentityPresentationEffect$2;

    .line 220
    .line 221
    move-object v12, v0

    .line 222
    move-object v13, v9

    .line 223
    move-object v14, v8

    .line 224
    move-object/from16 v15, p6

    .line 225
    .line 226
    move-object/from16 v16, p5

    .line 227
    .line 228
    move/from16 v17, v11

    .line 229
    .line 230
    move/from16 p0, v7

    .line 231
    .line 232
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$AssistIdentityPresentationEffect$2;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZI)V

    .line 233
    .line 234
    .line 235
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 236
    .line 237
    :cond_7
    return-void

    .line 238
    :cond_8
    invoke-interface {v10}, LX/2d4;->AgJ()V

    .line 239
    .line 240
    .line 241
    goto :goto_1

    .line 242
    :cond_9
    move v12, v7

    .line 243
    goto/16 :goto_0
.end method

.method public static final HatchAssistPresentation(Lcom/facebook/aura/assist/AssistVoicePresentation;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/2d4;II)V
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistVoicePresentation;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "Z",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p4

    .line 1
    .line 2
    move/from16 v3, p5

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move-object/from16 v11, p0

    .line 6
    .line 7
    move-object/from16 v6, p2

    .line 8
    .line 9
    move-object/from16 v5, p3

    .line 10
    .line 11
    invoke-static {v11, v6, v5, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 12
    .line 13
    .line 14
    const v1, -0x1a431f4

    .line 15
    .line 16
    .line 17
    move-object/from16 v2, p6

    .line 18
    .line 19
    invoke-interface {v2, v1}, LX/2d4;->Agl(I)V

    .line 20
    .line 21
    .line 22
    move/from16 v1, p7

    .line 23
    .line 24
    and-int/lit8 v7, p7, 0x6

    .line 25
    .line 26
    if-nez v7, :cond_a

    .line 27
    .line 28
    invoke-static {v2, v11}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v8

    .line 32
    or-int v8, v8, p7

    .line 33
    .line 34
    :goto_0
    and-int/lit8 v7, p7, 0x30

    .line 35
    .line 36
    move-object/from16 v12, p1

    .line 37
    .line 38
    if-nez v7, :cond_0

    .line 39
    .line 40
    invoke-static {v2, v12}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v7

    .line 44
    or-int/2addr v8, v7

    .line 45
    :cond_0
    and-int/lit16 v7, v1, 0x180

    .line 46
    .line 47
    if-nez v7, :cond_1

    .line 48
    .line 49
    invoke-static {v2, v6}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 50
    .line 51
    .line 52
    move-result v7

    .line 53
    or-int/2addr v8, v7

    .line 54
    :cond_1
    and-int/lit16 v7, v1, 0xc00

    .line 55
    .line 56
    if-nez v7, :cond_2

    .line 57
    .line 58
    invoke-static {v2, v5}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v7

    .line 62
    or-int/2addr v8, v7

    .line 63
    :cond_2
    move/from16 p1, p8

    .line 64
    .line 65
    and-int/lit8 v10, p8, 0x10

    .line 66
    .line 67
    if-eqz v10, :cond_9

    .line 68
    .line 69
    or-int/lit16 v8, v8, 0x6000

    .line 70
    .line 71
    :cond_3
    :goto_1
    and-int/lit8 v9, p8, 0x20

    .line 72
    .line 73
    const/high16 v7, 0x30000

    .line 74
    .line 75
    if-nez v9, :cond_4

    .line 76
    .line 77
    and-int v7, v7, p7

    .line 78
    .line 79
    if-nez v7, :cond_5

    .line 80
    .line 81
    invoke-static {v2, v3}, LX/004;->A0n(LX/2d4;Z)I

    .line 82
    .line 83
    .line 84
    move-result v7

    .line 85
    :cond_4
    or-int/2addr v8, v7

    .line 86
    :cond_5
    invoke-static {v8}, LX/005;->A1C(I)Z

    .line 87
    .line 88
    .line 89
    move-result v7

    .line 90
    invoke-static {v7, v2, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 91
    .line 92
    .line 93
    move-result v7

    .line 94
    if-eqz v7, :cond_8

    .line 95
    .line 96
    if-eqz v10, :cond_6

    .line 97
    .line 98
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 99
    .line 100
    :cond_6
    invoke-static {v9, v3}, LX/001;->A1Q(IZ)Z

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    sget-object v7, Lcom/facebook/aura/assist/AssistIdentityStateKt;->LocalAssistIdentityState:LX/Ip3;

    .line 105
    .line 106
    invoke-interface {v2, v7}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v19

    .line 110
    check-cast v19, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 111
    .line 112
    invoke-static {v2}, LX/3Rp;->A02(LX/2d4;)LX/34Y;

    .line 113
    .line 114
    .line 115
    move-result-object v14

    .line 116
    invoke-static {v2, v0}, Lcom/facebook/aura/avatarsize/HatchAvatarSizeRepositoryKt;->rememberHatchAvatarSize(LX/2d4;I)Lcom/facebook/aura/avatarsize/HatchAvatarSize;

    .line 117
    .line 118
    .line 119
    move-result-object v7

    .line 120
    invoke-static {v7, v2, v0}, Lcom/facebook/aura/avatarsize/HatchAvatarSizeKt;->rememberAvatarSizeDp(Lcom/facebook/aura/avatarsize/HatchAvatarSize;LX/2d4;I)F

    .line 121
    .line 122
    .line 123
    move-result v18

    .line 124
    sget-object v7, LX/3Fe;->A0A:LX/Ip3;

    .line 125
    .line 126
    invoke-interface {v2, v7}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v8

    .line 130
    check-cast v8, LX/2i3;

    .line 131
    .line 132
    const/16 p7, 0x6

    .line 133
    .line 134
    invoke-static {v2}, LX/1Jo;->A01(LX/2d4;)LX/1Jo;

    .line 135
    .line 136
    .line 137
    move-result-object v7

    .line 138
    iget-object v10, v7, LX/1Jo;->A04:LX/1JW;

    .line 139
    .line 140
    invoke-static {v2}, LX/1Jo;->A01(LX/2d4;)LX/1Jo;

    .line 141
    .line 142
    .line 143
    move-result-object v7

    .line 144
    iget-object v9, v7, LX/1Jo;->A01:LX/1JW;

    .line 145
    .line 146
    new-instance v7, LX/2wV;

    .line 147
    .line 148
    invoke-direct {v7, v10, v9}, LX/2wV;-><init>(LX/2uk;LX/2uk;)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v7, v14}, LX/2wV;->AD7(LX/34Y;)I

    .line 152
    .line 153
    .line 154
    move-result v15

    .line 155
    invoke-virtual {v7, v14, v8}, LX/2wV;->AH8(LX/34Y;LX/2i3;)I

    .line 156
    .line 157
    .line 158
    move-result v16

    .line 159
    invoke-virtual {v7, v14, v8}, LX/2wV;->AJu(LX/34Y;LX/2i3;)I

    .line 160
    .line 161
    .line 162
    move-result v17

    .line 163
    const/16 p3, 0x0

    .line 164
    .line 165
    invoke-static {v4}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 166
    .line 167
    .line 168
    move-result-object p4

    .line 169
    new-instance v13, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;

    .line 170
    .line 171
    move-object/from16 v22, v12

    .line 172
    .line 173
    move-object/from16 v23, v6

    .line 174
    .line 175
    move/from16 p0, v3

    .line 176
    .line 177
    move-object/from16 v20, v11

    .line 178
    .line 179
    move-object/from16 v21, v5

    .line 180
    .line 181
    invoke-direct/range {v13 .. v24}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$1;-><init>(LX/34Y;IIIFLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/AssistVoicePresentation;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)V

    .line 182
    .line 183
    .line 184
    const v7, 0x2bfeb762

    .line 185
    .line 186
    .line 187
    invoke-static {v2, v13, v7}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 188
    .line 189
    .line 190
    move-result-object p5

    .line 191
    const/16 p6, 0xc00

    .line 192
    .line 193
    move/from16 p8, v0

    .line 194
    .line 195
    move-object/from16 p2, v2

    .line 196
    .line 197
    invoke-static/range {p2 .. p8}, LX/2vl;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/JDQ;IIZ)V

    .line 198
    .line 199
    .line 200
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    if-eqz v2, :cond_7

    .line 205
    .line 206
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$2;

    .line 207
    .line 208
    move-object/from16 v18, v11

    .line 209
    .line 210
    move-object/from16 v19, v12

    .line 211
    .line 212
    move-object/from16 v20, v6

    .line 213
    .line 214
    move-object/from16 v21, v5

    .line 215
    .line 216
    move-object/from16 v22, v4

    .line 217
    .line 218
    move/from16 v23, v3

    .line 219
    .line 220
    move/from16 p0, v1

    .line 221
    .line 222
    move-object/from16 v17, v0

    .line 223
    .line 224
    invoke-direct/range {v17 .. v25}, Lcom/facebook/aura/assist/HatchAssistPresentationKt$HatchAssistPresentation$2;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;ZII)V

    .line 225
    .line 226
    .line 227
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 228
    .line 229
    :cond_7
    return-void

    .line 230
    :cond_8
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 231
    .line 232
    .line 233
    goto :goto_2

    .line 234
    :cond_9
    and-int/lit16 v7, v1, 0x6000

    .line 235
    .line 236
    if-nez v7, :cond_3

    .line 237
    .line 238
    invoke-static {v2, v4}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 239
    .line 240
    .line 241
    move-result v7

    .line 242
    or-int/2addr v8, v7

    .line 243
    goto/16 :goto_1

    .line 244
    .line 245
    :cond_a
    move v8, v1

    .line 246
    goto/16 :goto_0
.end method

.method public static final synthetic access$AssistIdentityPresentationEffect(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/assist/HatchAssistPresentationKt;->AssistIdentityPresentationEffect(Lcom/facebook/aura/assist/AssistVoicePresentation;Lcom/facebook/aura/assist/AssistVoiceLayout;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
