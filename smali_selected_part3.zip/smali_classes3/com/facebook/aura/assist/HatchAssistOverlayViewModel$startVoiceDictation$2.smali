.class public final synthetic Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$2;
.super LX/DRw;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRw;",
        "LX/JDM<",
        "Lcom/facebook/aura/composer/api/DictationOutcome;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 0
    const-class v3, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    const-string v5, "onDictationStopped(Lcom/facebook/aura/composer/api/DictationOutcome;Z)V"

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v4, "onDictationStopped"

    .line 7
    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DRw;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/composer/api/DictationOutcome;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$startVoiceDictation$2;->invoke(Lcom/facebook/aura/composer/api/DictationOutcome;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/composer/api/DictationOutcome;)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, LX/DRw;->receiver:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v2, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 7
    .line 8
    const/4 v1, 0x2

    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-static {v2, p1, v3, v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onDictationStopped$default(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Lcom/facebook/aura/composer/api/DictationOutcome;ZILjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
