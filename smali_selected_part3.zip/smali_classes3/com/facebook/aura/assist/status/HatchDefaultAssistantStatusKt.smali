.class public abstract Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatusKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEFAULT_ASSISTANT_NUDGE_ID:Ljava/lang/String; = "default_assistant"
