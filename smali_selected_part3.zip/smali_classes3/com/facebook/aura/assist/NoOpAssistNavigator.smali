.class public final Lcom/facebook/aura/assist/NoOpAssistNavigator;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/navigation/AuraNavigator;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/assist/NoOpAssistNavigator;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/NoOpAssistNavigator;->INSTANCE:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge addBeforeBackStackChangeListener(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method

.method public back()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public currentKey(Z)Lcom/facebook/aura/navigation/AuraNavKey;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public currentTabRoot()Lcom/facebook/aura/navigation/AuraTabRootNavKey;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public dismissBottomSheetStack(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public isInBackStack(LX/JDM;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public isInBackStack(Lcom/facebook/aura/navigation/AuraNavKey;)Z
    .locals 0

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    return p0
.end method

.method public navigate(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/navigation/LaunchFlag;)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public navigateWithContext(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/analytics/hatch/HatchClickPoint;Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;Lcom/facebook/aura/navigation/LaunchFlag;)V
    .locals 0

    .line 0
    return-void
.end method

.method public popAll(LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method

.method public popAll(Ljava/util/Collection;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    return-void
.end method

.method public popLast(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public popTabSubstack(Lcom/facebook/aura/navigation/AuraTabRootNavKey;Lcom/facebook/aura/navigation/AuraTabRootNavKey;)V
    .locals 0

    .line 0
    return-void
.end method

.method public popToRoot()V
    .locals 0

    .line 0
    return-void
.end method

.method public popToTabRoot(Lcom/facebook/aura/navigation/AuraTabRootNavKey;)V
    .locals 0

    .line 0
    return-void
.end method

.method public reconcileTabs(Ljava/util/Set;LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+",
            "Lcom/facebook/aura/navigation/AuraTabRootNavKey;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraTabRootNavKey;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method

.method public bridge removeBeforeBackStackChangeListener(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method
