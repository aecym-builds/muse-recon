.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;)Ljava/lang/Object;
    .locals 0

    .line 0
    const-string p0, "contribution"

    .line 1
    .line 2
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    const-string p0, "contribution"

    .line 268435457
    .line 268435458
    return-object p0
.end method
