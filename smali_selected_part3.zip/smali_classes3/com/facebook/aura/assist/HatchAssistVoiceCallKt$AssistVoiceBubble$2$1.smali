.class public final Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistVoiceCallKt$AssistVoiceBubble$2$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1
    .line 2
    return-object p0
.end method

.method public final invoke()V
    .locals 0

    .line 268435456
    return-void
.end method
