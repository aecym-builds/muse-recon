.class public abstract Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ASSIST_SCREENSHOT_ENABLED_SETTING:Ljava/lang/String; = "assist_screenshot_enabled"

.field public static final MAX_PANEL_FRACTION:F = 0.85f


# direct methods
.method public static final EnableScreenshotDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p2

    .line 1
    .line 2
    const v0, 0x5f63673e

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v1, v3}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    or-int v5, v5, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v13, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v13}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v5, v0

    .line 35
    :cond_0
    and-int/lit8 v6, p5, 0x4

    .line 36
    .line 37
    if-eqz v6, :cond_5

    .line 38
    .line 39
    or-int/lit16 v5, v5, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v4, v5, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v15, 0x0

    .line 46
    invoke-static {v4, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, v1, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_4

    .line 55
    .line 56
    if-eqz v6, :cond_2

    .line 57
    .line 58
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    const v0, 0x7f1201d5

    .line 61
    .line 62
    .line 63
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v8

    .line 67
    const v0, 0x7f1201d4

    .line 68
    .line 69
    .line 70
    invoke-static {v1, v0}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v9

    .line 74
    const v0, 0x7f1201d6

    .line 75
    .line 76
    .line 77
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    const v0, 0x7f120809

    .line 82
    .line 83
    .line 84
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$1;

    .line 89
    .line 90
    invoke-direct {v4, v6, v3, v0, v13}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 91
    .line 92
    .line 93
    const v0, 0x1820e4d

    .line 94
    .line 95
    .line 96
    invoke-static {v1, v4, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 97
    .line 98
    .line 99
    move-result-object v12

    .line 100
    shr-int/lit8 v0, v5, 0x6

    .line 101
    .line 102
    and-int/lit8 v4, v0, 0xe

    .line 103
    .line 104
    const/high16 v0, 0x30000

    .line 105
    .line 106
    or-int/2addr v4, v0

    .line 107
    shl-int/lit8 v0, v5, 0xf

    .line 108
    .line 109
    invoke-static {v0, v4}, LX/001;->A06(II)I

    .line 110
    .line 111
    .line 112
    move-result p2

    .line 113
    const/16 p4, 0x798

    .line 114
    .line 115
    const/4 v10, 0x0

    .line 116
    move-object v11, v10

    .line 117
    move-object v14, v10

    .line 118
    move/from16 v16, v15

    .line 119
    .line 120
    move-object/from16 p0, v10

    .line 121
    .line 122
    move/from16 p3, v15

    .line 123
    .line 124
    move-object/from16 p1, v1

    .line 125
    .line 126
    invoke-static/range {v7 .. v21}, Lcom/facebook/aura/vds/compose/dialog/AuraAlertDialogKt;->AuraAlertDialog(LX/3C1;Ljava/lang/String;Ljava/lang/String;LX/JDN;LX/JDN;LX/JDN;Lkotlin/jvm/functions/Function0;LX/0yv;ZZLX/JDM;LX/2d4;III)V

    .line 127
    .line 128
    .line 129
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    if-eqz v1, :cond_3

    .line 134
    .line 135
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;

    .line 136
    .line 137
    move-object/from16 p0, v0

    .line 138
    .line 139
    move-object/from16 p1, v3

    .line 140
    .line 141
    move-object/from16 p2, v13

    .line 142
    .line 143
    move-object/from16 p3, v7

    .line 144
    .line 145
    move/from16 p4, v2

    .line 146
    .line 147
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$EnableScreenshotDialog$2;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 148
    .line 149
    .line 150
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 151
    .line 152
    :cond_3
    return-void

    .line 153
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 154
    .line 155
    .line 156
    goto :goto_2

    .line 157
    :cond_5
    and-int/lit16 v0, v2, 0x180

    .line 158
    .line 159
    if-nez v0, :cond_1

    .line 160
    .line 161
    invoke-static {v1, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    or-int/2addr v5, v0

    .line 166
    goto :goto_1

    .line 167
    :cond_6
    move v5, v2

    .line 168
    goto/16 :goto_0
.end method

.method public static final HatchAssistOverlayScreen(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/Ddn;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3QE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDO;LX/2Lw;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;LX/3C1;Landroid/graphics/Bitmap;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;LX/2d4;IIII)V
    .locals 144
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3QE;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/model/HatchSendMessage;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDO<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2Lw<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationAnnouncement;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/composer/api/view/ComposerDictationUi;",
            "LX/3C1;",
            "Landroid/graphics/Bitmap;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "IIII)V"
        }
    .end annotation

    move-object/from16 v35, p19

    move-object/from16 v53, p24

    move-object/from16 v52, p18

    move-object/from16 v28, p20

    move-object/from16 v33, p21

    move-object/from16 v29, p22

    move-object/from16 v31, p23

    move-object/from16 v30, p25

    const/4 v5, 0x0

    .line 845749
    move-object/from16 v143, p1

    move-object/from16 v1, p0

    move-object/from16 v0, v143

    invoke-static {v1, v0}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v49

    .line 845750
    const/16 v50, 0x2

    move-object/from16 v142, p2

    move-object/from16 v1, v142

    move/from16 v0, v50

    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v51, 0x4

    .line 845751
    move-object/from16 v141, p4

    move-object/from16 v140, p5

    move-object/from16 v2, v141

    move/from16 v1, v51

    move-object/from16 v0, v140

    invoke-static {v2, v1, v0}, LX/003;->A10(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 845752
    const/16 v34, 0x6

    .line 845753
    move-object/from16 v139, p6

    move-object/from16 v138, p7

    move/from16 v2, v34

    move-object/from16 v1, v139

    move-object/from16 v0, v138

    invoke-static {v1, v2, v0}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 845754
    const/16 v8, 0x8

    .line 845755
    move-object/from16 v137, p8

    move-object/from16 v136, p9

    move-object/from16 v1, v137

    move-object/from16 v0, v136

    invoke-static {v1, v8, v0}, LX/003;->A14(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 845756
    const/16 v2, 0xa

    .line 845757
    move-object/from16 v135, p10

    move-object/from16 v134, p11

    move-object/from16 v1, v135

    move-object/from16 v0, v134

    invoke-static {v1, v2, v0}, LX/003;->A15(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 845758
    move-object/from16 v133, p12

    move-object/from16 v132, p13

    move-object/from16 v1, v133

    move-object/from16 v0, v132

    invoke-static {v1, v0}, LX/004;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 845759
    const/16 v12, 0xe

    .line 845760
    move-object/from16 v131, p14

    move-object/from16 v130, p15

    move-object/from16 v1, v131

    move-object/from16 v0, v130

    invoke-static {v1, v12, v0}, LX/3Rr;->A1A(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 845761
    const/16 v1, 0x10

    move-object/from16 v129, p16

    move-object/from16 v0, v129

    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const v0, -0xfb441b4

    .line 845762
    move-object/from16 v1, p26

    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    move/from16 v19, p27

    and-int/lit8 v0, p27, 0x6

    if-nez v0, :cond_4b

    .line 845763
    move-object/from16 v0, p0

    move/from16 v2, v19

    invoke-static {v0, v1, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    move-result v0

    .line 845764
    invoke-static {v0}, LX/003;->A06(I)I

    move-result v0

    .line 845765
    or-int v6, p27, v0

    :goto_0
    and-int/lit8 v0, p27, 0x30

    if-nez v0, :cond_0

    .line 845766
    move-object/from16 v0, v143

    move/from16 v2, v19

    invoke-static {v0, v1, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    move-result v0

    .line 845767
    invoke-static {v0}, LX/003;->A07(I)I

    move-result v0

    .line 845768
    or-int/2addr v6, v0

    :cond_0
    move/from16 v0, v19

    and-int/lit16 v0, v0, 0x180

    if-nez v0, :cond_1

    .line 845769
    move-object/from16 v0, v142

    invoke-static {v1, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845770
    or-int/2addr v6, v0

    :cond_1
    move/from16 v0, v19

    and-int/lit16 v0, v0, 0xc00

    move-object/from16 v37, p3

    if-nez v0, :cond_2

    .line 845771
    move-object/from16 v0, v37

    invoke-static {v1, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845772
    or-int/2addr v6, v0

    :cond_2
    move/from16 v0, v19

    and-int/lit16 v0, v0, 0x6000

    if-nez v0, :cond_3

    .line 845773
    move-object/from16 v0, v141

    invoke-static {v1, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845774
    or-int/2addr v6, v0

    :cond_3
    const/high16 v0, 0x30000

    and-int v0, v0, p27

    if-nez v0, :cond_4

    .line 845775
    move-object/from16 v0, v140

    invoke-static {v1, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845776
    or-int/2addr v6, v0

    :cond_4
    const/high16 v0, 0x180000

    and-int v0, v0, p27

    if-nez v0, :cond_5

    .line 845777
    move-object/from16 v0, v139

    invoke-static {v1, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845778
    or-int/2addr v6, v0

    :cond_5
    const/high16 v0, 0xc00000

    and-int v0, v0, p27

    if-nez v0, :cond_6

    .line 845779
    move-object/from16 v0, v138

    invoke-static {v1, v0}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845780
    or-int/2addr v6, v0

    :cond_6
    const/high16 v0, 0x6000000

    and-int v0, v0, p27

    if-nez v0, :cond_7

    .line 845781
    move-object/from16 v0, v137

    invoke-static {v1, v0}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845782
    or-int/2addr v6, v0

    :cond_7
    const/high16 v0, 0x30000000

    and-int v0, v0, p27

    if-nez v0, :cond_8

    .line 845783
    move-object/from16 v0, v136

    invoke-static {v1, v0}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845784
    or-int/2addr v6, v0

    :cond_8
    move/from16 v18, p28

    and-int/lit8 v0, p28, 0x6

    if-nez v0, :cond_4a

    .line 845785
    move-object/from16 v0, v135

    invoke-static {v1, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845786
    or-int v16, p28, v0

    :goto_1
    and-int/lit8 v0, p28, 0x30

    if-nez v0, :cond_9

    .line 845787
    move-object/from16 v0, v134

    invoke-static {v1, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845788
    or-int v16, v16, v0

    :cond_9
    const/high16 v4, 0x800000

    move/from16 v0, v18

    and-int/lit16 v0, v0, 0x180

    if-nez v0, :cond_a

    .line 845789
    move-object/from16 v0, v133

    move/from16 v2, v18

    invoke-static {v0, v1, v2}, LX/005;->A1Y(Ljava/lang/Object;LX/2d4;I)Z

    move-result v0

    .line 845790
    invoke-static {v0}, LX/003;->A08(I)I

    move-result v0

    .line 845791
    or-int v16, v16, v0

    :cond_a
    move/from16 v0, v18

    and-int/lit16 v0, v0, 0xc00

    if-nez v0, :cond_b

    .line 845792
    move-object/from16 v0, v132

    invoke-static {v1, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845793
    or-int v16, v16, v0

    :cond_b
    move/from16 v0, v18

    and-int/lit16 v0, v0, 0x6000

    if-nez v0, :cond_c

    .line 845794
    move-object/from16 v0, v131

    invoke-static {v1, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845795
    or-int v16, v16, v0

    :cond_c
    const/high16 v0, 0x30000

    and-int v0, p28, v0

    if-nez v0, :cond_d

    .line 845796
    move-object/from16 v0, v130

    invoke-static {v1, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845797
    or-int v16, v16, v0

    :cond_d
    const/high16 v0, 0x180000

    and-int v0, p28, v0

    if-nez v0, :cond_e

    .line 845798
    move-object/from16 v0, v129

    invoke-static {v1, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845799
    or-int v16, v16, v0

    :cond_e
    const/high16 v0, 0xc00000

    and-int v0, p28, v0

    move-object/from16 v93, p17

    if-nez v0, :cond_f

    .line 845800
    move-object/from16 v0, v93

    invoke-static {v1, v0}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845801
    or-int v16, v16, v0

    :cond_f
    const/high16 v0, 0x40000

    move/from16 v128, p30

    and-int v20, p30, v0

    const/high16 v0, 0x6000000

    if-nez v20, :cond_10

    and-int v0, p28, v0

    if-nez v0, :cond_11

    .line 845802
    move-object/from16 v0, v52

    invoke-static {v1, v0}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845803
    :cond_10
    or-int v16, v16, v0

    :cond_11
    const/high16 v0, 0x80000

    and-int v15, p30, v0

    const/high16 v0, 0x30000000

    if-nez v15, :cond_12

    and-int v0, p28, v0

    if-nez v0, :cond_13

    .line 845804
    move-object/from16 v0, v35

    invoke-static {v1, v0}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845805
    :cond_12
    or-int v16, v16, v0

    :cond_13
    const/high16 v0, 0x100000

    and-int v14, p30, v0

    move/from16 v24, p29

    if-eqz v14, :cond_48

    or-int/lit8 v2, p29, 0x6

    :goto_2
    const/high16 v0, 0x200000

    and-int v13, p30, v0

    if-eqz v13, :cond_47

    or-int/lit8 v2, v2, 0x30

    :cond_14
    :goto_3
    const/high16 v0, 0x400000

    and-int v11, p30, v0

    if-eqz v11, :cond_46

    or-int/lit16 v2, v2, 0x180

    :cond_15
    :goto_4
    and-int v10, p30, v4

    if-eqz v10, :cond_45

    or-int/lit16 v2, v2, 0xc00

    :cond_16
    :goto_5
    const/high16 v0, 0x1000000

    and-int v9, p30, v0

    or-int/lit16 v0, v2, 0x6000

    move/from16 v17, v0

    if-nez v9, :cond_17

    move/from16 v17, v2

    move/from16 v0, v24

    and-int/lit16 v0, v0, 0x6000

    if-nez v0, :cond_17

    .line 845806
    move-object/from16 v0, v53

    invoke-static {v1, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845807
    or-int v17, v2, v0

    :cond_17
    const/high16 v0, 0x2000000

    and-int v7, p30, v0

    const/high16 v0, 0x30000

    if-nez v7, :cond_18

    and-int v0, p29, v0

    if-nez v0, :cond_19

    .line 845808
    move-object/from16 v0, v30

    invoke-static {v1, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 845809
    :cond_18
    or-int v17, v17, v0

    :cond_19
    const v3, 0x12492493

    and-int v2, v6, v3

    const v0, 0x12492492

    if-ne v2, v0, :cond_1a

    and-int v3, v3, v16

    if-ne v3, v0, :cond_1a

    const v3, 0x12493

    and-int v3, v3, v17

    const v2, 0x12492

    const/4 v0, 0x0

    if-eq v3, v2, :cond_1b

    :cond_1a
    const/4 v0, 0x1

    .line 845810
    :cond_1b
    invoke-static {v0, v1, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    move-result v0

    .line 845811
    if-eqz v0, :cond_56

    if-eqz v20, :cond_1c

    .line 845812
    sget-object v52, LX/3C1;->A00:LX/3Cb;

    :cond_1c
    if-eqz v15, :cond_1d

    const/16 v35, 0x0

    .line 845813
    :cond_1d
    if-eqz v14, :cond_1f

    .line 845814
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v28

    .line 845815
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 845816
    move-object/from16 v2, v28

    if-ne v2, v0, :cond_1e

    .line 845817
    sget-object v28, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$1$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$1$1;

    .line 845818
    move-object/from16 v0, v28

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845819
    :cond_1e
    check-cast v28, LX/JDM;

    :cond_1f
    if-eqz v13, :cond_21

    .line 845820
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v33

    .line 845821
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 845822
    move-object/from16 v0, v33

    if-ne v0, v2, :cond_20

    .line 845823
    sget-object v33, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$2$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$2$1;

    .line 845824
    move-object/from16 v0, v33

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845825
    :cond_20
    check-cast v33, LX/JDM;

    :cond_21
    if-eqz v11, :cond_23

    .line 845826
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v29

    .line 845827
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 845828
    move-object/from16 v2, v29

    if-ne v2, v0, :cond_22

    .line 845829
    sget-object v29, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$3$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$3$1;

    .line 845830
    move-object/from16 v0, v29

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845831
    :cond_22
    check-cast v29, Lkotlin/jvm/functions/Function0;

    :cond_23
    if-eqz v10, :cond_25

    .line 845832
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v31

    .line 845833
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 845834
    move-object/from16 v0, v31

    if-ne v0, v2, :cond_24

    .line 845835
    sget-object v31, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$4$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$4$1;

    .line 845836
    move-object/from16 v0, v31

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845837
    :cond_24
    check-cast v31, Lkotlin/jvm/functions/Function0;

    :cond_25
    if-eqz v9, :cond_26

    const/16 v53, 0x0

    :cond_26
    if-eqz v7, :cond_28

    .line 845838
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v30

    .line 845839
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 845840
    move-object/from16 v2, v30

    if-ne v2, v0, :cond_27

    .line 845841
    sget-object v30, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$5$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$5$1;

    .line 845842
    move-object/from16 v0, v30

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845843
    :cond_27
    check-cast v30, Lkotlin/jvm/functions/Function0;

    .line 845844
    :cond_28
    sget-object v0, Lcom/facebook/aura/assist/AssistIdentityStateKt;->LocalAssistIdentityState:LX/Ip3;

    .line 845845
    invoke-interface {v1, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    move-result-object v0

    .line 845846
    check-cast v0, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 845847
    sget-object v2, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->LocalAssistVoicePresentation:LX/Ip3;

    .line 845848
    invoke-interface {v1, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    move-result-object v21

    .line 845849
    check-cast v21, Lcom/facebook/aura/assist/AssistVoicePresentation;

    if-nez v21, :cond_44

    const v2, 0xc5604d2

    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    move/from16 v2, v34

    invoke-static {v5, v1, v2}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->rememberAssistVoicePresentation(ZLX/2d4;I)Lcom/facebook/aura/assist/AssistVoicePresentation;

    move-result-object v21

    .line 845850
    invoke-static {v1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    move-result-object v7

    .line 845851
    :goto_6
    invoke-static {v1}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    move-result-object v48

    .line 845852
    invoke-static {v1, v5}, Lcom/facebook/aura/conversation/view/HatchConversationHistorySidePanelKt;->rememberAgentNameState(LX/2d4;I)LX/16A;

    move-result-object v39

    .line 845853
    sget-object v2, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 845854
    invoke-interface {v1, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    move-result-object v13

    .line 845855
    check-cast v13, LX/AHE;

    .line 845856
    invoke-static/range {v143 .. v143}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiStateKt;->isConversationIdle(Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;)Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .line 845857
    invoke-static {v1, v2}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    .line 845858
    invoke-interface {v1, v13}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v9

    .line 845859
    invoke-static {v6}, LX/005;->A1L(I)Z

    move-result v2

    .line 845860
    or-int/2addr v9, v2

    .line 845861
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v2

    if-nez v9, :cond_29

    .line 845862
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 845863
    if-ne v2, v9, :cond_2a

    .line 845864
    :cond_29
    sget-object v11, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContents;->INSTANCE:Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContents;

    .line 845865
    if-nez p3, :cond_43

    .line 845866
    const-string v10, "primary_session_id"

    .line 845867
    :goto_7
    sget-object v9, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;->ASSIST:Lcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;

    .line 845868
    new-instance v2, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$timelineSource$1$1;

    invoke-direct {v2, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$timelineSource$1$1;-><init>(LX/16A;)V

    .line 845869
    invoke-static {v2}, LX/3Ll;->A01(Lkotlin/jvm/functions/Function0;)LX/EOK;

    move-result-object v3

    .line 845870
    new-instance v2, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContext;

    invoke-direct {v2, v13, v10, v9, v3}, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContext;-><init>(LX/AHE;Ljava/lang/String;Lcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;LX/2Lw;)V

    .line 845871
    invoke-virtual {v11, v2}, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContents;->observe(Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContext;)LX/2Lw;

    move-result-object v2

    .line 845872
    invoke-interface {v1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845873
    :cond_2a
    check-cast v2, LX/2Lw;

    .line 845874
    sget-object v70, LX/Dwg;->A01:LX/Dwg;

    .line 845875
    const/16 v47, 0x0

    const/16 v43, 0x30

    move-object/from16 v68, v1

    move-object/from16 v69, v47

    move-object/from16 v71, v2

    move/from16 v72, v43

    move/from16 v73, v12

    invoke-static/range {v68 .. v73}, LX/1x0;->A01(LX/2d4;LX/15h;Ljava/lang/Object;LX/2Lw;II)LX/16A;

    move-result-object v36

    .line 845876
    const v2, 0x7f1201d7

    invoke-static {v1, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    move-result-object v20

    .line 845877
    sget-object v2, LX/3Fe;->A05:LX/Ip3;

    .line 845878
    invoke-interface {v1, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    move-result-object v32

    .line 845879
    check-cast v32, LX/1Ju;

    .line 845880
    invoke-static {v1}, LX/3Rp;->A02(LX/2d4;)LX/34Y;

    move-result-object v38

    .line 845881
    invoke-static {v1}, LX/1Jo;->A01(LX/2d4;)LX/1Jo;

    move-result-object v2

    .line 845882
    iget-object v9, v2, LX/1Jo;->A02:LX/1JW;

    .line 845883
    invoke-static {v1}, LX/1Jo;->A01(LX/2d4;)LX/1Jo;

    move-result-object v2

    .line 845884
    iget-object v3, v2, LX/1Jo;->A0B:LX/1Jn;

    .line 845885
    new-instance v2, LX/2wV;

    invoke-direct {v2, v9, v3}, LX/2wV;-><init>(LX/2uk;LX/2uk;)V

    .line 845886
    invoke-static {v2, v1, v5}, Lcom/facebook/aura/assist/AssistCameraHostKt;->rememberAssistCameraInsets(LX/2uk;LX/2d4;I)LX/2uk;

    move-result-object v61

    .line 845887
    move-object/from16 v3, v61

    move-object/from16 v2, v38

    invoke-interface {v3, v2}, LX/2uk;->AD7(LX/34Y;)I

    move-result v9

    .line 845888
    move-object/from16 v2, v21

    invoke-interface {v1, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v2

    .line 845889
    invoke-static {v2, v1, v9}, LX/001;->A1Z(ZLX/2d4;I)Z

    move-result v2

    .line 845890
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_2b

    .line 845891
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 845892
    if-ne v3, v2, :cond_2c

    .line 845893
    :cond_2b
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$6$1;

    move-object/from16 v2, v21

    invoke-direct {v3, v2, v9}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$6$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;I)V

    .line 845894
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845895
    :cond_2c
    invoke-static {v1, v3}, LX/001;->A1F(LX/2d4;Ljava/lang/Object;)V

    .line 845896
    invoke-static {v1, v5}, Lcom/facebook/aura/ui/adaptive/AuraLayoutSizeKt;->auraLayoutHeight(LX/2d4;I)F

    move-result v68

    .line 845897
    sget-object v41, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    move/from16 v3, v34

    move-object/from16 v2, v41

    invoke-virtual {v2, v1, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    move-result-object v46

    .line 845898
    invoke-static {v1}, LX/18g;->A00(LX/2d4;)Z

    move-result v27

    .line 845899
    move-object/from16 v2, v143

    iget-object v2, v2, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 845900
    if-eqz v27, :cond_42

    .line 845901
    iget-wide v2, v2, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->chatBackgroundDark:J

    move-wide/from16 v90, v2

    .line 845902
    :goto_8
    new-array v9, v5, [Ljava/lang/Object;

    .line 845903
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    .line 845904
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 845905
    if-ne v3, v2, :cond_2d

    .line 845906
    sget-object v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$isVisible$2$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$isVisible$2$1;

    .line 845907
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845908
    :cond_2d
    invoke-static {v1, v3, v9}, LX/39E;->A01(LX/2d4;Ljava/lang/Object;[Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v10

    .line 845909
    invoke-static {v1, v2, v5}, LX/005;->A0k(LX/2d4;Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object v3

    .line 845910
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 845911
    sget-object v42, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-interface {v1, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v9

    .line 845912
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v11

    if-nez v9, :cond_2e

    .line 845913
    if-ne v11, v2, :cond_2f

    .line 845914
    :cond_2e
    new-instance v11, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$7$1;

    invoke-direct {v11, v10}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$7$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 845915
    invoke-interface {v1, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845916
    :cond_2f
    move-object/from16 v9, v42

    invoke-static {v1, v11, v9}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 845917
    invoke-static {v10}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v9

    .line 845918
    const/high16 v57, 0x43480000    # 200.0f

    if-eqz v9, :cond_30

    const/16 v57, 0x0

    .line 845919
    :cond_30
    const/16 v11, 0x15e

    .line 845920
    sget-object v9, LX/33X;->A01:LX/1V8;

    .line 845921
    invoke-static {v9, v11, v5}, LX/001;->A0S(LX/1V8;II)LX/E1b;

    move-result-object v54

    .line 845922
    const/16 v58, 0x1b0

    move-object/from16 v55, v1

    move-object/from16 v56, v47

    move/from16 v59, v8

    invoke-static/range {v54 .. v59}, LX/34R;->A02(LX/DwJ;LX/2d4;LX/JDM;FII)LX/16A;

    move-result-object v63

    .line 845923
    invoke-static {v10}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v8

    .line 845924
    invoke-static {v8}, LX/007;->A02(I)F

    move-result v12

    .line 845925
    const/16 v8, 0x12c

    .line 845926
    invoke-static {v9, v8, v5}, LX/001;->A0S(LX/1V8;II)LX/E1b;

    move-result-object v13

    .line 845927
    const/4 v9, 0x0

    const/16 v11, 0xc30

    const/16 v8, 0x14

    invoke-static {v13, v1, v12, v11, v8}, LX/34R;->A01(LX/DwJ;LX/2d4;FII)LX/16A;

    move-result-object v44

    .line 845928
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v8

    .line 845929
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    .line 845930
    invoke-static/range {v44 .. v44}, LX/16A;->A00(LX/16A;)F

    move-result v8

    .line 845931
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v14

    move-object/from16 v8, v44

    invoke-interface {v1, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v11

    const v8, 0xe000

    and-int v45, v6, v8

    .line 845932
    invoke-static/range {v45 .. v45}, LX/602;->A1R(I)Z

    move-result v8

    .line 845933
    or-int/2addr v11, v8

    .line 845934
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v13

    if-nez v11, :cond_31

    .line 845935
    if-ne v13, v2, :cond_32

    .line 845936
    :cond_31
    new-instance v13, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$8$1;

    move-object/from16 v12, v141

    move-object/from16 v11, v44

    move-object/from16 v8, v47

    invoke-direct {v13, v12, v3, v11, v8}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$8$1;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;LX/16A;LX/2M4;)V

    .line 845937
    invoke-interface {v1, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845938
    :cond_32
    invoke-static {v1, v13, v15, v14}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 845939
    invoke-interface {v1, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v11

    .line 845940
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    if-nez v11, :cond_33

    .line 845941
    if-ne v8, v2, :cond_34

    .line 845942
    :cond_33
    new-instance v8, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$animatedDismiss$1$1;

    invoke-direct {v8, v10, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$animatedDismiss$1$1;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 845943
    invoke-interface {v1, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845944
    :cond_34
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 845945
    const/high16 v12, 0x1c00000

    and-int v10, v6, v12

    .line 845946
    invoke-static {v10, v4}, LX/003;->A1I(II)Z

    move-result v3

    .line 845947
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v25

    if-nez v3, :cond_35

    .line 845948
    move-object/from16 v3, v25

    if-ne v3, v2, :cond_36

    .line 845949
    :cond_35
    invoke-static {v5}, LX/004;->A12(Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v25

    .line 845950
    move-object/from16 v3, v25

    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845951
    :cond_36
    check-cast v25, Landroidx/compose/runtime/MutableState;

    .line 845952
    invoke-static {v10, v4}, LX/003;->A1I(II)Z

    move-result v3

    .line 845953
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v26

    if-nez v3, :cond_37

    .line 845954
    move-object/from16 v3, v26

    if-ne v3, v2, :cond_38

    .line 845955
    :cond_37
    invoke-static {v5}, LX/004;->A12(Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v26

    .line 845956
    move-object/from16 v3, v26

    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845957
    :cond_38
    check-cast v26, Landroidx/compose/runtime/MutableState;

    .line 845958
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    .line 845959
    invoke-static {v1, v3, v2}, LX/004;->A1C(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v79

    .line 845960
    check-cast v79, LX/3Gw;

    const/4 v15, 0x3

    .line 845961
    invoke-static {v5, v5, v1, v5, v15}, LX/DPI;->A00(IILX/2d4;II)Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v54

    .line 845962
    and-int/lit8 v67, v17, 0xe

    .line 845963
    move/from16 v10, v67

    move/from16 v3, v51

    invoke-static {v10, v3}, LX/003;->A1I(II)Z

    move-result v10

    move-object/from16 v3, v48

    invoke-static {v1, v3, v10}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    move-result v3

    .line 845964
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v11

    if-nez v3, :cond_39

    .line 845965
    if-ne v11, v2, :cond_3a

    .line 845966
    :cond_39
    new-instance v11, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$launchCamera$1$1;

    move-object/from16 v10, v28

    move-object/from16 v3, v48

    invoke-direct {v11, v10, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$launchCamera$1$1;-><init>(LX/JDM;Landroid/content/Context;)V

    .line 845967
    invoke-interface {v1, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845968
    :cond_3a
    check-cast v11, LX/JDM;

    .line 845969
    invoke-static {v11, v1, v5}, Lcom/facebook/aura/composer/camera/HatchInAppCameraKt;->rememberHatchInAppCameraLauncher(LX/JDM;LX/2d4;I)Lkotlin/jvm/functions/Function0;

    move-result-object v13

    .line 845970
    and-int v12, v16, v12

    .line 845971
    invoke-static {v12, v4}, LX/003;->A1I(II)Z

    move-result v10

    .line 845972
    move/from16 v3, v17

    and-int/lit16 v14, v3, 0x380

    .line 845973
    invoke-static {v14}, LX/3Rs;->A1M(I)Z

    move-result v3

    invoke-static {v1, v13, v10, v3}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    move-result v3

    .line 845974
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v23

    if-nez v3, :cond_3b

    .line 845975
    move-object/from16 v3, v23

    if-ne v3, v2, :cond_3c

    .line 845976
    :cond_3b
    new-instance v23, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$openCamera$1$1;

    move-object/from16 v11, v23

    move-object/from16 v10, v93

    move-object/from16 v3, v29

    invoke-direct {v11, v10, v3, v13}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$openCamera$1$1;-><init>(Lcom/facebook/aura/composer/api/view/ComposerDictationUi;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 845977
    invoke-interface {v1, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845978
    :cond_3c
    check-cast v23, Lkotlin/jvm/functions/Function0;

    .line 845979
    invoke-static {v12, v4}, LX/003;->A1I(II)Z

    move-result v11

    .line 845980
    const/16 v10, 0x100

    .line 845981
    invoke-static {v14, v10}, LX/003;->A1I(II)Z

    move-result v3

    .line 845982
    or-int/2addr v11, v3

    move-object/from16 v3, v35

    invoke-interface {v1, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v12

    .line 845983
    move-object/from16 v4, v25

    move-object/from16 v3, v48

    invoke-static {v1, v4, v3, v11, v12}, LX/603;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;ZZ)Z

    move-result v11

    .line 845984
    move-object/from16 v4, v26

    move-object/from16 v3, v20

    invoke-static {v1, v4, v3, v11}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    move-result v3

    .line 845985
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v22

    if-nez v3, :cond_3d

    .line 845986
    move-object/from16 v3, v22

    if-ne v3, v2, :cond_3e

    .line 845987
    :cond_3d
    new-instance v22, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$openScreenshot$1$1;

    move-object/from16 v71, v22

    move-object/from16 v72, v93

    move-object/from16 v73, v29

    move-object/from16 v74, v35

    move-object/from16 v75, v48

    move-object/from16 v76, v20

    move-object/from16 v77, v25

    move-object/from16 v78, v4

    invoke-direct/range {v71 .. v78}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$openScreenshot$1$1;-><init>(Lcom/facebook/aura/composer/api/view/ComposerDictationUi;Lkotlin/jvm/functions/Function0;Landroid/graphics/Bitmap;Landroid/content/Context;Ljava/lang/String;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 845988
    move-object/from16 v3, v22

    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 845989
    :cond_3e
    check-cast v22, Lkotlin/jvm/functions/Function0;

    .line 845990
    and-int/lit16 v3, v6, 0x380

    .line 845991
    invoke-static {v3, v10}, LX/003;->A1I(II)Z

    move-result v3

    .line 845992
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v20

    if-nez v3, :cond_3f

    .line 845993
    move-object/from16 v3, v20

    if-ne v3, v2, :cond_4d

    .line 845994
    :cond_3f
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    move-result-object v10

    .line 845995
    invoke-interface/range {v142 .. v142}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_40
    :goto_9
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4c

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 845996
    instance-of v3, v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;

    if-nez v3, :cond_41

    .line 845997
    instance-of v3, v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$TypingCursor;

    if-eqz v3, :cond_40

    .line 845998
    :cond_41
    invoke-virtual {v10, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_9

    .line 845999
    :cond_42
    iget-wide v2, v2, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->chatBackgroundLight:J

    move-wide/from16 v90, v2

    goto/16 :goto_8

    .line 846000
    :cond_43
    move-object/from16 v10, v37

    goto/16 :goto_7

    .line 846001
    :cond_44
    const v2, 0xc55fffa

    .line 846002
    invoke-static {v1, v2}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    move-result-object v7

    .line 846003
    goto/16 :goto_6

    .line 846004
    :cond_45
    move/from16 v0, v24

    and-int/lit16 v0, v0, 0xc00

    if-nez v0, :cond_16

    .line 846005
    move-object/from16 v0, v31

    invoke-static {v1, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 846006
    or-int/2addr v2, v0

    goto/16 :goto_5

    :cond_46
    move/from16 v0, v24

    and-int/lit16 v0, v0, 0x180

    if-nez v0, :cond_15

    .line 846007
    move-object/from16 v0, v29

    invoke-static {v1, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 846008
    or-int/2addr v2, v0

    goto/16 :goto_4

    :cond_47
    and-int/lit8 v0, p29, 0x30

    if-nez v0, :cond_14

    .line 846009
    move-object/from16 v0, v33

    invoke-static {v1, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 846010
    or-int/2addr v2, v0

    goto/16 :goto_3

    :cond_48
    and-int/lit8 v0, p29, 0x6

    if-nez v0, :cond_49

    .line 846011
    move-object/from16 v0, v28

    invoke-static {v1, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 846012
    or-int v2, p29, v0

    goto/16 :goto_2

    :cond_49
    move/from16 v2, v24

    goto/16 :goto_2

    :cond_4a
    move/from16 v16, v18

    goto/16 :goto_1

    :cond_4b
    move/from16 v6, v19

    goto/16 :goto_0

    .line 846013
    :cond_4c
    invoke-static {v10}, LX/Adc;->A0H(Ljava/util/List;)LX/Add;

    move-result-object v3

    .line 846014
    invoke-static {v1, v3}, LX/002;->A1F(LX/2d4;Ljava/lang/Iterable;)LX/Ddn;

    move-result-object v20

    .line 846015
    :cond_4d
    check-cast v20, LX/Ddn;

    .line 846016
    invoke-static/range {v20 .. v20}, LX/603;->A0f(Ljava/util/List;)Ljava/lang/Integer;

    move-result-object v14

    .line 846017
    invoke-interface/range {v36 .. v36}, LX/16A;->getValue()Ljava/lang/Object;

    move-result-object v13

    .line 846018
    move-object/from16 v10, v36

    move-object/from16 v4, v54

    move-object/from16 v3, v20

    invoke-static {v1, v3, v10, v4}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 846019
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v12

    if-nez v3, :cond_4e

    .line 846020
    if-ne v12, v2, :cond_4f

    .line 846021
    :cond_4e
    new-instance v12, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$9$1;

    move-object v11, v4

    move-object/from16 v4, v47

    move-object/from16 v3, v20

    invoke-direct {v12, v3, v11, v10, v4}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$9$1;-><init>(LX/Ddn;Landroidx/compose/foundation/lazy/LazyListState;LX/16A;LX/2M4;)V

    .line 846022
    invoke-interface {v1, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846023
    :cond_4f
    invoke-static {v1, v12, v14, v13}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 846024
    move-object/from16 v3, v47

    invoke-static {v3, v5, v1, v5, v15}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->rememberPendingAgentPermissionCount(Ljava/lang/String;ZLX/2d4;II)I

    move-result v13

    .line 846025
    invoke-interface/range {v20 .. v20}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_50

    .line 846026
    invoke-static/range {v36 .. v36}, LX/602;->A1W(LX/16A;)Z

    move-result v3

    .line 846027
    if-eqz v3, :cond_50

    if-nez v13, :cond_50

    .line 846028
    move-object/from16 v3, p0

    iget-object v4, v3, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 846029
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayPhase;->ERROR:Lcom/facebook/aura/assist/AssistOverlayPhase;

    if-eq v4, v3, :cond_50

    .line 846030
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    if-eq v4, v3, :cond_50

    .line 846031
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    if-eq v4, v3, :cond_50

    .line 846032
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    .line 846033
    const/16 v40, 0x1

    if-eqz v3, :cond_51

    :cond_50
    const/16 v40, 0x0

    :cond_51
    const/high16 v3, 0x41e00000    # 28.0f

    .line 846034
    invoke-static {v3}, LX/2bA;->A00(F)LX/2bC;

    move-result-object v66

    .line 846035
    move-object/from16 v3, v41

    invoke-static {v1, v3}, LX/07H;->A00(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)F

    move-result v60

    .line 846036
    sget-object v11, LX/2sI;->A01:LX/2wD;

    move-object/from16 v3, v52

    invoke-interface {v3, v11}, LX/3C1;->then(LX/3C1;)LX/3C1;

    move-result-object v80

    .line 846037
    invoke-virtual/range {v21 .. v21}, Lcom/facebook/aura/assist/AssistVoicePresentation;->getShowingVoice()Z

    move-result v3

    if-eqz v3, :cond_52

    .line 846038
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->getPhase()Lcom/facebook/aura/assist/AssistIdentityPhase;

    move-result-object v4

    sget-object v3, Lcom/facebook/aura/assist/AssistIdentityPhase;->EXPANDED:Lcom/facebook/aura/assist/AssistIdentityPhase;

    const/16 v84, 0x0

    if-ne v4, v3, :cond_53

    :cond_52
    const/16 v84, 0x1

    .line 846039
    :cond_53
    move-object/from16 v3, v21

    invoke-interface {v1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v4

    .line 846040
    invoke-static {v6}, LX/603;->A1Q(I)Z

    move-result v3

    .line 846041
    invoke-static {v1, v8, v4, v3}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    move-result v3

    .line 846042
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v10

    if-nez v3, :cond_54

    .line 846043
    if-ne v10, v2, :cond_55

    .line 846044
    :cond_54
    new-instance v10, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$10$1;

    move-object/from16 v4, v140

    move-object/from16 v3, v21

    invoke-direct {v10, v3, v4, v8}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$10$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 846045
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846046
    :cond_55
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 846047
    move-object/from16 v78, v47

    move-object/from16 v81, v47

    move-object/from16 v82, v47

    move-object/from16 v83, v10

    invoke-static/range {v78 .. v84}, LX/3GU;->A01(LX/346;LX/3Gw;LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    move-result-object v10

    .line 846048
    sget-object v62, LX/2Id;->A06:Landroidx/compose/ui/Alignment;

    .line 846049
    move-object/from16 v3, v62

    invoke-static {v3, v5}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    move-result-object v8

    .line 846050
    iget-wide v3, v7, LX/J7I;->A06:J

    .line 846051
    const/16 v65, 0x20

    .line 846052
    invoke-static {v3, v4}, LX/001;->A0A(J)I

    move-result v4

    .line 846053
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v3

    .line 846054
    invoke-static {v1, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v12

    .line 846055
    sget-object v56, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 846056
    iget-object v10, v7, LX/J7I;->A0V:LX/3DJ;

    .line 846057
    if-nez v10, :cond_57

    invoke-static {}, LX/1VY;->A00()V

    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    move-result-object v0

    throw v0

    .line 846058
    :cond_56
    invoke-interface {v1}, LX/2d4;->AgJ()V

    goto/16 :goto_d

    .line 846059
    :cond_57
    move-object/from16 v10, v56

    invoke-static {v1, v7, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 846060
    sget-object v57, LX/3Cl;->A04:LX/JDN;

    .line 846061
    move-object/from16 v10, v57

    invoke-static {v1, v8, v10}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    move-result-object v58

    .line 846062
    move-object/from16 v8, v58

    invoke-static {v1, v3, v8, v4}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    move-result-object v59

    .line 846063
    sget-object v15, LX/3Cl;->A02:LX/JDM;

    .line 846064
    invoke-static {v1, v12, v15}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    move-result-object v55

    .line 846065
    sget-object v41, LX/3C1;->A00:LX/3Cb;

    .line 846066
    move-object/from16 v3, v44

    invoke-static {v1, v3, v0}, LX/003;->A1M(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 846067
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_58

    .line 846068
    if-ne v4, v2, :cond_59

    .line 846069
    :cond_58
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;

    move-object/from16 v3, v44

    invoke-direct {v4, v0, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$1$1;-><init>(Lcom/facebook/aura/assist/AssistIdentityState;LX/16A;)V

    .line 846070
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846071
    :cond_59
    invoke-static {v11, v4}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    move-result-object v10

    .line 846072
    move-object/from16 v3, v46

    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->scrim:J

    .line 846073
    sget-object v64, LX/2oZ;->A00:LX/2bW;

    .line 846074
    move-object/from16 v8, v64

    invoke-static {v10, v8, v3, v4}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    move-result-object v3

    .line 846075
    invoke-static {v3, v1, v5}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 846076
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 846077
    const v4, 0x3f59999a    # 0.85f

    mul-float v4, v4, v68

    .line 846078
    const/high16 v3, 0x7fc00000    # Float.NaN

    .line 846079
    invoke-static {v14, v3, v4}, LX/2sI;->A0A(LX/3C1;FF)LX/3C1;

    move-result-object v4

    .line 846080
    invoke-static/range {v63 .. v63}, LX/602;->A00(LX/16A;)F

    move-result v3

    .line 846081
    invoke-static {v4, v9, v3}, LX/7mL;->A01(LX/3C1;FF)LX/3C1;

    move-result-object v10

    .line 846082
    move-object/from16 v3, v44

    invoke-interface {v1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v4

    .line 846083
    move-object/from16 v3, v21

    invoke-static {v1, v0, v3, v4}, LX/004;->A1V(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    move-result v3

    .line 846084
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    if-nez v3, :cond_5a

    .line 846085
    if-ne v8, v2, :cond_5b

    .line 846086
    :cond_5a
    new-instance v8, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;

    move-object/from16 v4, v44

    move-object/from16 v3, v21

    invoke-direct {v8, v0, v3, v4}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$2$1;-><init>(Lcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/AssistVoicePresentation;LX/16A;)V

    .line 846087
    invoke-interface {v1, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846088
    :cond_5b
    invoke-static {v10, v8}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    move-result-object v3

    .line 846089
    invoke-virtual/range {v21 .. v21}, Lcom/facebook/aura/assist/AssistVoicePresentation;->getShowingVoice()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v3, v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->assistComposerInteraction(LX/3C1;Z)LX/3C1;

    move-result-object v4

    .line 846090
    move-object/from16 v0, v21

    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v0

    .line 846091
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v0, :cond_5c

    .line 846092
    if-ne v3, v2, :cond_5d

    .line 846093
    :cond_5c
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;

    move-object/from16 v0, v21

    invoke-direct {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;)V

    .line 846094
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846095
    :cond_5d
    check-cast v3, LX/JDQ;

    invoke-static {v4, v3}, LX/2ub;->A00(LX/3C1;LX/JDQ;)LX/3C1;

    move-result-object v4

    .line 846096
    invoke-virtual/range {v21 .. v21}, Lcom/facebook/aura/assist/AssistVoicePresentation;->isVoice()Z

    move-result v0

    if-eqz v0, :cond_5e

    .line 846097
    move-object/from16 v0, v21

    iget-object v0, v0, Lcom/facebook/aura/assist/AssistVoicePresentation;->capturedBottomInset$delegate:LX/CR1;

    .line 846098
    invoke-interface {v0}, LX/CR1;->AGk()I

    move-result v3

    .line 846099
    new-instance v61, LX/1JX;

    move-object/from16 v0, v61

    invoke-direct {v0, v3}, LX/1JX;-><init>(I)V

    .line 846100
    :cond_5e
    move-object/from16 v0, v61

    invoke-static {v0, v4}, LX/2oz;->A00(LX/2uk;LX/3C1;)LX/3C1;

    move-result-object v3

    .line 846101
    move/from16 v0, v60

    invoke-static {v3, v0, v9}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    move-result-object v4

    .line 846102
    sget-object v3, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Standard:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    move/from16 v0, v43

    invoke-static {v4, v3, v1, v0}, Lcom/facebook/aura/ui/adaptive/AuraContentFrameKt;->auraContentWidth(LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;LX/2d4;I)LX/3C1;

    move-result-object v11

    .line 846103
    sget-object v4, LX/Dn6;->A05:LX/Dps;

    .line 846104
    sget-object v63, LX/2Id;->A02:LX/2sS;

    .line 846105
    move-object/from16 v3, v63

    move/from16 v0, v34

    invoke-static {v4, v1, v3, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    move-result-object v10

    .line 846106
    invoke-static {v7}, LX/002;->A0J(LX/J7I;)I

    move-result v8

    .line 846107
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v4

    .line 846108
    invoke-static {v1, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v3

    .line 846109
    move-object/from16 v0, v56

    invoke-static {v1, v7, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 846110
    move-object/from16 v0, v57

    invoke-static {v1, v10, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846111
    move-object/from16 v0, v58

    invoke-static {v1, v4, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846112
    move-object/from16 v0, v59

    invoke-static {v15, v0, v1, v8}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 846113
    move-object/from16 v0, v55

    invoke-static {v1, v3, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846114
    sget-object v61, LX/CgJ;->A00:LX/CgJ;

    .line 846115
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    .line 846116
    if-eqz v0, :cond_6f

    if-eqz v35, :cond_6f

    const v0, -0x137dbf92

    .line 846117
    move-object/from16 v3, v25

    invoke-static {v3, v1, v0}, LX/002;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    move-result v4

    .line 846118
    move/from16 v3, v67

    move/from16 v0, v51

    invoke-static {v3, v0}, LX/003;->A1I(II)Z

    move-result v0

    .line 846119
    or-int/2addr v4, v0

    .line 846120
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    if-nez v4, :cond_5f

    .line 846121
    if-ne v8, v2, :cond_60

    .line 846122
    :cond_5f
    new-instance v8, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$1$1;

    move-object/from16 v0, v28

    move-object/from16 v3, v25

    invoke-direct {v8, v0, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$1$1;-><init>(LX/JDM;Landroidx/compose/runtime/MutableState;)V

    .line 846123
    invoke-interface {v1, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846124
    :cond_60
    check-cast v8, LX/JDM;

    .line 846125
    move-object/from16 v0, v25

    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v3

    .line 846126
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    if-nez v3, :cond_61

    .line 846127
    if-ne v0, v2, :cond_62

    .line 846128
    :cond_61
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$2$1;

    move-object/from16 v3, v25

    invoke-direct {v0, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 846129
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846130
    :cond_62
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 846131
    move-object/from16 v4, v61

    move/from16 v3, v49

    invoke-static {v4, v14, v3}, LX/002;->A0X(LX/CgJ;LX/3C1;Z)LX/3C1;

    move-result-object v4

    .line 846132
    move-object/from16 v3, v66

    invoke-static {v4, v3}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    move-result-object v10

    .line 846133
    move-wide/from16 v3, v90

    move-object/from16 v9, v64

    invoke-static {v10, v9, v3, v4}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    move-result-object v13

    .line 846134
    shr-int/lit8 v3, v16, 0x1b

    and-int/lit8 v3, v3, 0xe

    or-int/lit8 v16, v3, 0x30

    .line 846135
    const-string v10, "assist"

    move-object/from16 v9, v35

    move-object v11, v8

    move-object v12, v0

    move v14, v5

    move-object v15, v1

    move/from16 v17, v65

    invoke-static/range {v9 .. v17}, Lcom/facebook/aura/components/screenshot/HatchScreenshotModeKt;->HatchScreenshotMode(Landroid/graphics/Bitmap;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/2d4;II)V

    .line 846136
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846137
    :goto_a
    move/from16 v0, v49

    invoke-static {v7, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846138
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    .line 846139
    xor-int/lit8 v14, v0, 0x1

    .line 846140
    move-object/from16 v0, v44

    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v0

    .line 846141
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v0, :cond_63

    .line 846142
    if-ne v3, v2, :cond_64

    .line 846143
    :cond_63
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$5$1;

    move-object/from16 v0, v44

    invoke-direct {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$5$1;-><init>(LX/16A;)V

    .line 846144
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846145
    :cond_64
    move-object/from16 v0, v41

    invoke-static {v0, v3}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    move-result-object v13

    .line 846146
    const/high16 v0, 0x380000

    .line 846147
    invoke-static {v6, v0}, LX/005;->A1P(II)Z

    move-result v3

    .line 846148
    const/16 v8, 0x4000

    .line 846149
    move/from16 v0, v45

    invoke-static {v0, v8}, LX/003;->A1I(II)Z

    move-result v0

    .line 846150
    or-int/2addr v0, v3

    .line 846151
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v0, :cond_65

    .line 846152
    if-ne v4, v2, :cond_66

    .line 846153
    :cond_65
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$6$1;

    move-object/from16 v3, v139

    move-object/from16 v0, v141

    invoke-direct {v4, v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$6$1;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 846154
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846155
    :cond_66
    check-cast v4, Lkotlin/jvm/functions/Function0;

    shr-int/lit8 v0, v6, 0x6

    and-int/lit16 v0, v0, 0x1c70

    .line 846156
    move-object/from16 v9, v21

    move-object/from16 v10, v37

    move-object v11, v4

    move-object/from16 v12, v140

    move-object v15, v1

    move/from16 v16, v0

    move/from16 v17, v5

    invoke-static/range {v9 .. v17}, Lcom/facebook/aura/assist/HatchAssistPresentationKt;->HatchAssistPresentation(Lcom/facebook/aura/assist/AssistVoicePresentation;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/2d4;II)V

    .line 846157
    move-object/from16 v0, v143

    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 846158
    invoke-virtual {v0}, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->isCustom()Z

    move-result v3

    if-eqz v3, :cond_6e

    .line 846159
    if-eqz v27, :cond_6d

    .line 846160
    iget-wide v3, v0, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->userBubbleColorDark:J

    .line 846161
    :goto_b
    move-wide v9, v3

    move-object/from16 v11, v47

    move-object v12, v1

    move v13, v5

    move/from16 v14, v50

    invoke-static/range {v9 .. v14}, Lcom/facebook/aura/assist/HatchAssistLaunchGlowKt;->HatchAssistLaunchGlow-3J-VO9M(JLX/3C1;LX/2d4;II)V

    .line 846162
    move/from16 v0, v49

    invoke-static {v11, v1, v5, v0}, Lcom/facebook/aura/assist/AssistToastHostKt;->AssistToastHost(LX/3C1;LX/2d4;II)V

    .line 846163
    invoke-static {v7, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846164
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    .line 846165
    if-eqz v0, :cond_6c

    const v0, 0x7fbb0c26

    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846166
    move-object/from16 v3, v26

    move-object/from16 v0, v48

    invoke-static {v1, v3, v0}, LX/003;->A1M(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 846167
    move/from16 v0, v45

    invoke-static {v0, v8}, LX/003;->A1I(II)Z

    move-result v0

    .line 846168
    or-int/2addr v3, v0

    .line 846169
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_67

    .line 846170
    if-ne v4, v2, :cond_68

    .line 846171
    :cond_67
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$12$1;

    move-object/from16 v3, v48

    move-object/from16 v0, v141

    move-object/from16 v6, v26

    invoke-direct {v4, v3, v0, v6}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$12$1;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 846172
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846173
    :cond_68
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 846174
    move-object/from16 v0, v26

    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v3

    .line 846175
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    if-nez v3, :cond_69

    .line 846176
    if-ne v0, v2, :cond_6a

    .line 846177
    :cond_69
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$13$1;

    move-object/from16 v2, v26

    invoke-direct {v0, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$13$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 846178
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846179
    :cond_6a
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 846180
    move-object v8, v4

    move-object v9, v0

    move-object v10, v11

    move-object v11, v1

    move v12, v5

    move/from16 v13, v51

    invoke-static/range {v8 .. v13}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->EnableScreenshotDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 846181
    :goto_c
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846182
    :goto_d
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    move-result-object v1

    if-eqz v1, :cond_6b

    .line 846183
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;

    move-object/from16 v98, v0

    move-object/from16 v99, p0

    move-object/from16 v100, v143

    move-object/from16 v101, v142

    move-object/from16 v102, v37

    move-object/from16 v103, v141

    move-object/from16 v104, v140

    move-object/from16 v105, v139

    move-object/from16 v106, v138

    move-object/from16 v107, v137

    move-object/from16 v108, v136

    move-object/from16 v109, v135

    move-object/from16 v110, v134

    move-object/from16 v111, v133

    move-object/from16 v112, v132

    move-object/from16 v113, v131

    move-object/from16 v114, v130

    move-object/from16 v115, v129

    move-object/from16 v116, v93

    move-object/from16 v117, v52

    move-object/from16 v118, v35

    move-object/from16 v119, v28

    move-object/from16 v120, v33

    move-object/from16 v121, v29

    move-object/from16 v122, v31

    move-object/from16 v123, v53

    move-object/from16 v124, v30

    move/from16 v125, v19

    move/from16 v126, v18

    move/from16 v127, v24

    invoke-direct/range {v98 .. v128}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$14;-><init>(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/Ddn;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3QE;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDO;LX/2Lw;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;LX/3C1;Landroid/graphics/Bitmap;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;IIII)V

    .line 846184
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 846185
    :cond_6b
    return-void

    .line 846186
    :cond_6c
    const v0, 0x7fc0e9b6

    .line 846187
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    goto :goto_c

    .line 846188
    :cond_6d
    iget-wide v3, v0, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->userBubbleColorLight:J

    goto/16 :goto_b

    .line 846189
    :cond_6e
    move-object/from16 v0, v46

    iget-wide v3, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->accent:J

    goto/16 :goto_b

    .line 846190
    :cond_6f
    const v0, -0x1370af34

    .line 846191
    invoke-static {v1, v0}, LX/002;->A0t(LX/2d4;I)Ljava/lang/Object;

    move-result-object v8

    .line 846192
    if-ne v8, v2, :cond_70

    .line 846193
    const/high16 v0, 0x42600000    # 56.0f

    .line 846194
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    move-result-object v0

    .line 846195
    invoke-static {v1, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v8

    .line 846196
    :cond_70
    check-cast v8, Landroidx/compose/runtime/MutableState;

    .line 846197
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    .line 846198
    if-ne v0, v2, :cond_71

    .line 846199
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 846200
    invoke-static {v1, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v0

    .line 846201
    :cond_71
    check-cast v0, Landroidx/compose/runtime/MutableState;

    .line 846202
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v1, v13}, LX/2d4;->A67(I)Z

    move-result v3

    .line 846203
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v10

    if-nez v3, :cond_72

    .line 846204
    if-ne v10, v2, :cond_73

    .line 846205
    :cond_72
    new-instance v10, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$3$1;

    move-object/from16 v3, v47

    invoke-direct {v10, v13, v0, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$3$1;-><init>(ILandroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 846206
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846207
    :cond_73
    invoke-static {v1, v10, v11}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 846208
    invoke-static/range {v20 .. v20}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;

    .line 846209
    instance-of v3, v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;

    if-eqz v3, :cond_74

    check-cast v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;

    if-eqz v4, :cond_74

    .line 846210
    iget-object v3, v4, Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem$Message;->message:Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;

    .line 846211
    if-eqz v3, :cond_74

    .line 846212
    iget-boolean v4, v3, Lcom/facebook/aura/conversation/viewmodel/HatchMessageUiModel;->isStreaming:Z

    .line 846213
    const/4 v13, 0x1

    move/from16 v3, v49

    if-eq v4, v3, :cond_75

    :cond_74
    const/4 v13, 0x0

    .line 846214
    :cond_75
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v10

    .line 846215
    if-ne v10, v2, :cond_76

    .line 846216
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 846217
    invoke-static {v1, v3}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v10

    .line 846218
    :cond_76
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 846219
    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v34

    .line 846220
    move-object/from16 v3, v34

    invoke-static {v1, v3}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 846221
    move-object/from16 v3, v54

    invoke-static {v1, v3, v4}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 846222
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v12

    if-nez v3, :cond_77

    .line 846223
    if-ne v12, v2, :cond_78

    .line 846224
    :cond_77
    new-instance v12, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1;

    move-object v11, v4

    move-object/from16 v4, v54

    move-object/from16 v3, v47

    invoke-direct {v12, v4, v11, v10, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$4$1;-><init>(Landroidx/compose/foundation/lazy/LazyListState;LX/16A;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 846225
    invoke-interface {v1, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846226
    :cond_78
    move-object/from16 v3, v54

    invoke-static {v1, v12, v3}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 846227
    invoke-interface {v1, v13}, LX/2d4;->A6A(Z)Z

    move-result v3

    .line 846228
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_79

    .line 846229
    if-ne v4, v2, :cond_7a

    .line 846230
    :cond_79
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$5$1;

    move-object/from16 v3, v47

    invoke-direct {v4, v13, v10, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$5$1;-><init>(ZLandroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 846231
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846232
    :cond_7a
    move-object/from16 v3, v34

    invoke-static {v1, v4, v3}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 846233
    if-nez v40, :cond_9e

    const v3, -0x1359aa6b

    .line 846234
    invoke-interface {v1, v3}, LX/2d4;->Agj(I)V

    .line 846235
    move-object/from16 v3, v61

    invoke-static {v3, v14, v5}, LX/002;->A0X(LX/CgJ;LX/3C1;Z)LX/3C1;

    move-result-object v4

    .line 846236
    move-object/from16 v3, v66

    invoke-static {v4, v3}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    move-result-object v12

    .line 846237
    move-wide/from16 v3, v90

    move-object/from16 v11, v64

    invoke-static {v12, v11, v3, v4}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    move-result-object v73

    .line 846238
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    .line 846239
    invoke-static {v1, v3, v2}, LX/004;->A1C(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v72

    .line 846240
    check-cast v72, LX/3Gw;

    .line 846241
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    .line 846242
    if-ne v3, v2, :cond_7b

    .line 846243
    sget-object v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$7$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$7$1;

    .line 846244
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846245
    :cond_7b
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 846246
    move-object/from16 v71, v47

    move-object/from16 v74, v47

    move-object/from16 v75, v47

    move-object/from16 v76, v3

    move/from16 v77, v49

    invoke-static/range {v71 .. v77}, LX/3GU;->A01(LX/346;LX/3Gw;LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    move-result-object v4

    .line 846247
    sget-object v61, LX/2Id;->A0E:Landroidx/compose/ui/Alignment;

    .line 846248
    move-object/from16 v3, v61

    invoke-static {v3, v5}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    move-result-object v34

    .line 846249
    invoke-static {v7}, LX/002;->A0J(LX/J7I;)I

    move-result v13

    .line 846250
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v12

    .line 846251
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v11

    .line 846252
    move-object/from16 v3, v56

    invoke-static {v1, v7, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 846253
    move-object/from16 v4, v34

    move-object/from16 v3, v57

    invoke-static {v1, v4, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846254
    move-object/from16 v3, v58

    invoke-static {v1, v12, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846255
    move-object/from16 v4, v59

    invoke-static {v15, v4, v1, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 846256
    move-object/from16 v3, v55

    invoke-static {v1, v11, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846257
    sget-object v34, LX/3Jn;->A00:LX/3Jn;

    .line 846258
    move/from16 v3, v60

    invoke-static {v14, v3, v9}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    move-result-object v78

    .line 846259
    invoke-static {v8}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    move-result-object v3

    .line 846260
    iget v11, v3, LX/1Ot;->A00:F

    .line 846261
    add-float v11, v11, v60

    .line 846262
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    move-result-object v3

    .line 846263
    invoke-static {v3}, LX/001;->A0D(Ljava/lang/Object;)I

    move-result v4

    .line 846264
    move-object/from16 v3, v38

    invoke-interface {v3, v4}, LX/34Y;->AhT(I)F

    move-result v3

    add-float v3, v3, v60

    .line 846265
    new-instance v13, LX/1XE;

    .line 846266
    invoke-direct {v13, v9, v11, v9, v3}, LX/1XE;-><init>(FFFF)V

    .line 846267
    move-object/from16 v3, v36

    invoke-interface {v1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v12

    and-int/lit8 v4, v6, 0x70

    move/from16 v3, v65

    if-eq v4, v3, :cond_7c

    and-int/lit8 v3, v6, 0x40

    if-eqz v3, :cond_9d

    move-object/from16 v3, v143

    invoke-interface {v1, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9d

    :cond_7c
    const/4 v3, 0x1

    :goto_e
    or-int/2addr v12, v3

    .line 846268
    move-object/from16 v11, v38

    move-object/from16 v4, v39

    move-object/from16 v3, v20

    invoke-static {v1, v3, v11, v4, v12}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    move-result v11

    .line 846269
    invoke-static/range {v16 .. v16}, LX/008;->A1X(I)Z

    move-result v3

    .line 846270
    or-int/2addr v11, v3

    .line 846271
    invoke-static/range {v16 .. v16}, LX/004;->A1S(I)Z

    move-result v3

    .line 846272
    or-int/2addr v11, v3

    and-int/lit8 v4, v6, 0xe

    move/from16 v3, v51

    if-eq v4, v3, :cond_7d

    and-int/lit8 v3, v6, 0x8

    if-eqz v3, :cond_9c

    move-object/from16 v3, p0

    invoke-interface {v1, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9c

    :cond_7d
    const/4 v3, 0x1

    :goto_f
    or-int/2addr v11, v3

    .line 846273
    move-object/from16 v3, v46

    invoke-static {v1, v3, v11}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    move-result v4

    .line 846274
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v4, :cond_7e

    .line 846275
    if-ne v3, v2, :cond_7f

    .line 846276
    :cond_7e
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;

    move-object/from16 v79, v3

    move-object/from16 v80, v20

    move-object/from16 v81, p0

    move-object/from16 v82, v36

    move-object/from16 v83, v143

    move-object/from16 v84, v38

    move-object/from16 v85, v39

    move-object/from16 v86, v135

    move-object/from16 v87, v134

    move-object/from16 v88, v10

    move-object/from16 v89, v46

    invoke-direct/range {v79 .. v89}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;-><init>(LX/Ddn;Lcom/facebook/aura/assist/AssistOverlayState;LX/16A;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/34Y;LX/16A;LX/JDM;LX/JDO;Landroidx/compose/runtime/MutableState;Lcom/facebook/aura/vds/compose/theme/AuraColors;)V

    .line 846277
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846278
    :cond_7f
    check-cast v3, LX/JDM;

    const/16 v80, 0xc00

    const/16 v81, 0x1f0

    .line 846279
    move-object/from16 v72, v47

    move-object/from16 v73, v47

    move-object/from16 v74, v13

    move-object/from16 v75, v54

    move-object/from16 v76, v1

    move-object/from16 v77, v47

    move-object/from16 v79, v3

    move/from16 v82, v49

    move/from16 v83, v5

    invoke-static/range {v71 .. v83}, LX/EIg;->A01(LX/3IY;LX/32u;LX/Dps;LX/2or;Landroidx/compose/foundation/lazy/LazyListState;LX/2d4;LX/2sS;LX/3C1;LX/JDM;IIZZ)V

    .line 846280
    sget-object v10, LX/2Id;->A0C:Landroidx/compose/ui/Alignment;

    .line 846281
    move-object/from16 v3, v34

    invoke-virtual {v3, v10, v14}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    move-result-object v11

    move-object/from16 v3, v38

    invoke-interface {v1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v3

    .line 846282
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_80

    .line 846283
    if-ne v4, v2, :cond_81

    .line 846284
    :cond_80
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$3$1;

    move-object/from16 v3, v38

    invoke-direct {v4, v3, v8}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$3$1;-><init>(LX/34Y;Landroidx/compose/runtime/MutableState;)V

    .line 846285
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846286
    :cond_81
    check-cast v4, LX/JDM;

    invoke-static {v11, v4}, LX/3N4;->A00(LX/3C1;LX/JDM;)LX/3C1;

    move-result-object v3

    .line 846287
    move-object/from16 v4, v61

    invoke-static {v4, v5}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    move-result-object v11

    .line 846288
    invoke-static {v7}, LX/002;->A0J(LX/J7I;)I

    move-result v12

    .line 846289
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v8

    .line 846290
    invoke-static {v1, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v4

    .line 846291
    move-object/from16 v3, v56

    invoke-static {v1, v7, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 846292
    move-object/from16 v3, v57

    invoke-static {v1, v11, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846293
    move-object/from16 v3, v58

    invoke-static {v1, v8, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846294
    move-object/from16 v8, v59

    invoke-static {v15, v8, v1, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 846295
    move-object/from16 v3, v55

    invoke-static {v1, v4, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846296
    const/high16 v3, 0x42c80000    # 100.0f

    .line 846297
    invoke-static {v14, v3}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    move-result-object v13

    .line 846298
    invoke-static/range {v90 .. v91}, LX/001;->A0d(J)LX/JOw;

    move-result-object v8

    .line 846299
    sget-wide v11, LX/JOw;->A06:J

    .line 846300
    invoke-static {v8, v11, v12}, LX/005;->A0p(LX/JOw;J)Ljava/util/List;

    move-result-object v4

    .line 846301
    const/high16 v3, 0x7f800000    # Float.POSITIVE_INFINITY

    invoke-static {v4, v9, v3}, LX/2hZ;->A02(Ljava/util/List;FF)LX/2hU;

    move-result-object v8

    .line 846302
    move-object/from16 v3, v64

    invoke-static {v13, v8, v3}, LX/2pC;->A02(LX/3C1;LX/2hZ;LX/2bW;)LX/3C1;

    move-result-object v3

    .line 846303
    invoke-static {v3, v1, v5}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 846304
    move-object/from16 v4, v34

    move-object/from16 v3, v41

    invoke-virtual {v4, v10, v3}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    move-result-object v4

    .line 846305
    move/from16 v3, v60

    invoke-static {v4, v9, v3, v9, v9}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v4

    .line 846306
    move-object/from16 v3, v21

    invoke-static {v3, v4, v1, v5, v5}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->AssistIdentityPlaceholder(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/3C1;LX/2d4;II)V

    .line 846307
    move/from16 v3, v49

    invoke-static {v7, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846308
    move-object/from16 v8, v34

    move-object/from16 v4, v62

    move-object/from16 v3, v41

    invoke-virtual {v8, v4, v3}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    move-result-object v3

    .line 846309
    invoke-interface {v3, v14}, LX/3C1;->then(LX/3C1;)LX/3C1;

    move-result-object v4

    .line 846310
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    .line 846311
    if-ne v3, v2, :cond_82

    .line 846312
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$5$1;

    invoke-direct {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$5$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 846313
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846314
    :cond_82
    check-cast v3, LX/JDM;

    invoke-static {v4, v3}, LX/3N4;->A00(LX/3C1;LX/JDM;)LX/3C1;

    move-result-object v71

    const/16 v78, 0x1e

    .line 846315
    move/from16 v73, v5

    move/from16 v74, v9

    move/from16 v75, v5

    move/from16 v77, v5

    invoke-static/range {v71 .. v78}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionPendingCard-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V

    .line 846316
    move/from16 v0, v49

    invoke-static {v7, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846317
    const/high16 v3, 0x41400000    # 12.0f

    .line 846318
    move-object/from16 v0, v41

    invoke-static {v1, v7, v0, v3, v5}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 846319
    :goto_10
    move-object/from16 v0, v143

    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->conversationTheme:Lcom/facebook/aura/identity/provider/HatchConversationTheme;

    .line 846320
    if-eqz v27, :cond_9b

    .line 846321
    iget-wide v3, v0, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->userBubbleColorDark:J

    move-wide/from16 v66, v3

    .line 846322
    :goto_11
    move/from16 v3, v27

    invoke-virtual {v0, v3}, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->userTextColor-vNxB06k(Z)J

    move-result-wide v64

    .line 846323
    sget-object v3, LX/Dn6;->A06:LX/Dps;

    .line 846324
    move-object/from16 v0, v63

    invoke-static {v3, v1, v0, v5}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    move-result-object v10

    .line 846325
    invoke-static {v7}, LX/002;->A0J(LX/J7I;)I

    move-result v8

    .line 846326
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v4

    .line 846327
    invoke-static {v1, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v3

    .line 846328
    move-object/from16 v0, v56

    invoke-static {v1, v7, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 846329
    move-object/from16 v0, v57

    invoke-static {v1, v10, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846330
    move-object/from16 v0, v58

    invoke-static {v1, v4, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846331
    move-object/from16 v0, v59

    invoke-static {v15, v0, v1, v8}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 846332
    move-object/from16 v0, v55

    invoke-static {v1, v3, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 846333
    const v0, -0x7b1cf4d4

    .line 846334
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    if-eqz v40, :cond_9a

    const v0, -0x7b1f2940

    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846335
    const/high16 v3, 0x41800000    # 16.0f

    .line 846336
    move-object/from16 v0, v41

    invoke-static {v0, v9, v9, v9, v3}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v4

    .line 846337
    move/from16 v3, v43

    move-object/from16 v0, v21

    invoke-static {v0, v4, v1, v3, v5}, Lcom/facebook/aura/assist/AssistVoicePresentationKt;->AssistIdentityPlaceholder(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/3C1;LX/2d4;II)V

    .line 846338
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846339
    :goto_12
    shr-int/lit8 v0, v16, 0x6

    and-int/lit8 v8, v0, 0xe

    .line 846340
    move-object/from16 v4, v133

    move-object/from16 v3, v47

    move/from16 v0, v50

    invoke-static {v4, v3, v1, v8, v0}, Lcom/facebook/aura/conversation/view/HatchReplyAnnouncementKt;->HatchReplyAnnouncement(LX/2Lw;LX/3C1;LX/2d4;II)V

    const v0, -0x77957da3

    .line 846341
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846342
    invoke-static {v1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    move-result-object v3

    .line 846343
    invoke-interface {v1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v4

    .line 846344
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    if-nez v4, :cond_83

    .line 846345
    if-ne v0, v2, :cond_84

    .line 846346
    :cond_83
    sget-object v0, Lcom/facebook/aura/livesession/api/LiveSessions;->INSTANCE:Lcom/facebook/aura/livesession/api/LiveSessions;

    invoke-virtual {v0, v3}, Lcom/facebook/aura/livesession/api/LiveSessions;->isActive(LX/AHE;)LX/2J3;

    move-result-object v0

    .line 846347
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846348
    :cond_84
    check-cast v0, LX/2J3;

    .line 846349
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846350
    invoke-static {v1, v0, v5}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    move-result-object v8

    .line 846351
    move-object/from16 v0, v143

    iget-boolean v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->isInputBlocked:Z

    .line 846352
    if-eqz v0, :cond_88

    const v0, -0x7b177dd6

    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846353
    sget-object v0, LX/3Fe;->A0E:LX/Ip3;

    .line 846354
    invoke-interface {v1, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    move-result-object v0

    .line 846355
    check-cast v0, LX/2M7;

    .line 846356
    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v4

    .line 846357
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v4, :cond_85

    .line 846358
    if-ne v3, v2, :cond_86

    .line 846359
    :cond_85
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$1$1;

    invoke-direct {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$1$1;-><init>(LX/2M7;)V

    .line 846360
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846361
    :cond_86
    move-object/from16 v0, v42

    invoke-static {v1, v3, v0}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 846362
    if-nez p3, :cond_87

    .line 846363
    const-string v3, "primary_session_id"

    .line 846364
    :goto_13
    const-string v0, "primary_session_id"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    .line 846365
    sget-object v11, Lcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;->ASSIST:Lcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;

    .line 846366
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmallPlusNano:F

    .line 846367
    const/high16 v4, 0x41b00000    # 22.0f

    .line 846368
    move-object/from16 v0, v41

    invoke-static {v0, v9, v8, v9, v4}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v12

    .line 846369
    const/16 v14, 0x180

    .line 846370
    move-object v9, v3

    move-object v13, v1

    move v15, v5

    invoke-static/range {v9 .. v15}, Lcom/facebook/aura/conversation/view/HatchComposerStatusCardsKt;->HatchComposerStatusCards(Ljava/lang/String;ZLcom/facebook/aura/conversation/widget/api/ConversationTimelineSurface;LX/3C1;LX/2d4;II)V

    .line 846371
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846372
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846373
    :goto_14
    move/from16 v0, v49

    invoke-static {v7, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846374
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846375
    goto/16 :goto_a

    .line 846376
    :cond_87
    move-object/from16 v3, v37

    goto :goto_13

    .line 846377
    :cond_88
    const v0, -0x7b0d9bb4

    .line 846378
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846379
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846380
    move-object/from16 v0, v143

    iget-object v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->pendingImageUris:LX/Ddn;

    move-object/from16 v38, v0

    .line 846381
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 846382
    sget-object v3, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 846383
    invoke-static {v4, v3}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v94

    .line 846384
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    if-eq v4, v0, :cond_89

    .line 846385
    const/16 v95, 0x0

    if-ne v4, v3, :cond_8a

    :cond_89
    const/16 v95, 0x1

    .line 846386
    :cond_8a
    invoke-static {v8}, LX/16A;->A0C(LX/16A;)Z

    move-result v96

    .line 846387
    invoke-static/range {v37 .. v37}, LX/003;->A1R(Ljava/lang/Object;)Z

    move-result v98

    .line 846388
    sget-object v100, Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;->ASSIST:Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;

    .line 846389
    move-object/from16 v0, v143

    iget-boolean v0, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->shouldFocusComposer:Z

    move/from16 v36, v0

    .line 846390
    invoke-interface/range {v20 .. v20}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_99

    const v0, -0x77939410

    .line 846391
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    const v0, 0x7f1201cf

    .line 846392
    invoke-static {v1, v7, v0}, LX/18b;->A06(LX/2d4;LX/J7I;I)Ljava/lang/String;

    move-result-object v103

    .line 846393
    :goto_15
    const/high16 v0, 0x41400000    # 12.0f

    .line 846394
    invoke-static {v14, v9, v9, v9, v0}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v4

    .line 846395
    move-object/from16 v0, v21

    invoke-interface {v1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v0

    .line 846396
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v3

    if-nez v0, :cond_8b

    .line 846397
    if-ne v3, v2, :cond_8c

    .line 846398
    :cond_8b
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$2$1;

    move-object/from16 v0, v21

    invoke-direct {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$2$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;)V

    .line 846399
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846400
    :cond_8c
    invoke-static {v4, v3}, LX/3Ae;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    move-result-object v56

    .line 846401
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    .line 846402
    invoke-static {v1, v0, v2}, LX/004;->A1C(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v55

    .line 846403
    check-cast v55, LX/3Gw;

    .line 846404
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    .line 846405
    if-ne v0, v2, :cond_8d

    .line 846406
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$4$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$4$1;

    .line 846407
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846408
    :cond_8d
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 846409
    move-object/from16 v54, v47

    move-object/from16 v57, v47

    move-object/from16 v58, v47

    move-object/from16 v59, v0

    move/from16 v60, v49

    invoke-static/range {v54 .. v60}, LX/3GU;->A01(LX/346;LX/3Gw;LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    move-result-object v102

    .line 846410
    const/high16 v0, 0xe000000

    .line 846411
    invoke-static {v6, v0}, LX/009;->A1N(II)Z

    move-result v3

    .line 846412
    move-object/from16 v0, v32

    invoke-static {v1, v0, v3}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    move-result v0

    .line 846413
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v14

    if-nez v0, :cond_8e

    .line 846414
    if-ne v14, v2, :cond_8f

    .line 846415
    :cond_8e
    new-instance v14, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$5$1;

    move-object/from16 v3, v32

    move-object/from16 v0, v137

    invoke-direct {v14, v0, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$5$1;-><init>(Lkotlin/jvm/functions/Function0;LX/1Ju;)V

    .line 846416
    invoke-interface {v1, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846417
    :cond_8f
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 846418
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v34

    .line 846419
    move-object/from16 v0, v34

    if-ne v0, v2, :cond_90

    .line 846420
    sget-object v34, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$6$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$6$1;

    .line 846421
    move-object/from16 v0, v34

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846422
    :cond_90
    check-cast v34, Lkotlin/jvm/functions/Function0;

    .line 846423
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v32

    .line 846424
    move-object/from16 v0, v32

    if-ne v0, v2, :cond_91

    .line 846425
    sget-object v32, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$7$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$7$1;

    .line 846426
    move-object/from16 v0, v32

    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846427
    :cond_91
    check-cast v32, Lkotlin/jvm/functions/Function0;

    .line 846428
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v15

    .line 846429
    if-ne v15, v2, :cond_92

    .line 846430
    sget-object v15, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$8$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$8$1;

    .line 846431
    invoke-interface {v1, v15}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846432
    :cond_92
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 846433
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v13

    .line 846434
    if-ne v13, v2, :cond_93

    .line 846435
    sget-object v13, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$9$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$9$1;

    .line 846436
    invoke-interface {v1, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846437
    :cond_93
    check-cast v13, LX/JDM;

    .line 846438
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v12

    .line 846439
    if-ne v12, v2, :cond_94

    .line 846440
    sget-object v12, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$10$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$10$1;

    .line 846441
    invoke-interface {v1, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846442
    :cond_94
    check-cast v12, LX/JDM;

    .line 846443
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v11

    .line 846444
    if-ne v11, v2, :cond_95

    .line 846445
    sget-object v11, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$11$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$11$1;

    .line 846446
    invoke-interface {v1, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846447
    :cond_95
    check-cast v11, LX/JDM;

    .line 846448
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v10

    .line 846449
    if-ne v10, v2, :cond_96

    .line 846450
    sget-object v10, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$12$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$12$1;

    .line 846451
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846452
    :cond_96
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 846453
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    .line 846454
    if-ne v8, v2, :cond_97

    .line 846455
    sget-object v8, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$13$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$13$1;

    .line 846456
    invoke-interface {v1, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846457
    :cond_97
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 846458
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    .line 846459
    if-ne v4, v2, :cond_98

    .line 846460
    sget-object v4, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$14$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$9$14$1;

    .line 846461
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 846462
    :cond_98
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 846463
    sget-object v114, Lcom/facebook/aura/assist/ComposableSingletons$HatchAssistOverlayScreenKt;->lambda$1565060939:LX/JDR;

    .line 846464
    shr-int/lit8 v0, v6, 0x15

    and-int/lit8 v3, v0, 0xe

    const v0, 0x30000c00

    or-int/2addr v3, v0

    shr-int/lit8 v0, v6, 0x18

    and-int/lit8 v0, v0, 0x70

    or-int/2addr v3, v0

    shl-int/lit8 v0, v16, 0x6

    .line 846465
    invoke-static {v0, v3}, LX/002;->A06(II)I

    move-result v119

    .line 846466
    shl-int/lit8 v121, v17, 0x9

    const v0, 0xe000

    and-int v121, v121, v0

    const v0, 0x361b0c36

    or-int v121, v121, v0

    shr-int/lit8 v3, v16, 0x3

    const/high16 v0, 0x380000

    and-int/2addr v3, v0

    or-int/lit8 v122, v3, 0x36

    shr-int/lit8 v0, v17, 0x9

    and-int/lit8 v0, v0, 0xe

    or-int/lit16 v0, v0, 0x6c00

    move/from16 v20, v0

    shr-int/lit8 v0, v6, 0x3

    and-int/lit16 v0, v0, 0x380

    or-int v20, v20, v0

    shr-int/lit8 v0, v17, 0xf

    and-int/lit8 v3, v0, 0xe

    const v0, 0xd86000

    or-int/2addr v3, v0

    shr-int/lit8 v0, v16, 0x9

    .line 846467
    invoke-static {v0, v3}, LX/004;->A05(II)I

    move-result v124

    .line 846468
    shr-int/lit8 v0, v17, 0xc

    and-int/lit8 v125, v0, 0xe

    const v126, 0x840c044

    const v127, 0x1903001e

    const v120, 0xd80c36

    .line 846469
    move-object/from16 v55, v138

    move-object/from16 v56, v136

    move/from16 v58, v49

    move-object/from16 v59, v14

    move-object/from16 v60, v132

    move/from16 v61, v5

    move-wide/from16 v62, v66

    move/from16 v66, v5

    move/from16 v67, v49

    move/from16 v68, v49

    move-object/from16 v69, v38

    move-object/from16 v71, v47

    move-object/from16 v72, v47

    move-object/from16 v73, v47

    move-object/from16 v74, v34

    move-object/from16 v75, v23

    move-object/from16 v76, v22

    move-object/from16 v77, v32

    move-object/from16 v78, v15

    move-object/from16 v79, v47

    move-object/from16 v80, v13

    move-object/from16 v81, v33

    move-object/from16 v82, v12

    move-object/from16 v83, v11

    move-object/from16 v84, v47

    move-object/from16 v85, v10

    move-object/from16 v86, v47

    move-object/from16 v87, v8

    move-object/from16 v88, v4

    move-object/from16 v89, v47

    move-object/from16 v90, v47

    move-object/from16 v91, v47

    move-object/from16 v92, v47

    move-object/from16 v97, v31

    move-object/from16 v99, v37

    move-object/from16 v101, v47

    move-object/from16 v104, v47

    move-object/from16 v105, v47

    move/from16 v106, v36

    move-object/from16 v107, v30

    move-object/from16 v108, v131

    move-object/from16 v109, v130

    move-object/from16 v110, v129

    move/from16 v111, v5

    move/from16 v112, v5

    move/from16 v113, v9

    move-object/from16 v115, v47

    move-object/from16 v116, v47

    move-object/from16 v117, v53

    move-object/from16 v118, v1

    move/from16 v123, v20

    invoke-static/range {v55 .. v127}, Lcom/facebook/aura/composer/view/HatchComposerKt;->HatchComposer-pFCJyS8(LX/3QE;Lkotlin/jvm/functions/Function0;Ljava/lang/Object;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZJJZZZLX/Ddn;LX/Ddn;LX/1c6;LX/1c6;Landroid/graphics/Bitmap;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/composer/api/view/ComposerDictationUi;ZZZLkotlin/jvm/functions/Function0;ZLjava/lang/String;Lcom/facebook/aura/analytics/hatch/HatchComposerEntryPoint;Ljava/lang/String;LX/3C1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZZFLX/JDR;LX/Ddn;LX/JDM;LX/JDN;LX/2d4;IIIIIIIII)V

    .line 846470
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846471
    goto/16 :goto_14

    .line 846472
    :cond_99
    const v0, -0x779389e0

    .line 846473
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    const v0, 0x7f120831

    .line 846474
    invoke-static {v1, v7, v0}, LX/18b;->A06(LX/2d4;LX/J7I;I)Ljava/lang/String;

    move-result-object v103

    .line 846475
    goto/16 :goto_15

    .line 846476
    :cond_9a
    const v0, -0x7b1ca394

    .line 846477
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846478
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846479
    goto/16 :goto_12

    .line 846480
    :cond_9b
    iget-wide v3, v0, Lcom/facebook/aura/identity/provider/HatchConversationTheme;->userBubbleColorLight:J

    move-wide/from16 v66, v3

    goto/16 :goto_11

    .line 846481
    :cond_9c
    const/4 v3, 0x0

    goto/16 :goto_f

    :cond_9d
    const/4 v3, 0x0

    goto/16 :goto_e

    .line 846482
    :cond_9e
    const v0, -0x1302e68e

    .line 846483
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 846484
    invoke-static {v7, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 846485
    goto/16 :goto_10
.end method

.method public static final HatchAssistOverlayScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$11(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$14(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$16(LX/16A;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "LX/1Ot;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/602;->A00(LX/16A;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$17(LX/16A;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A00(LX/16A;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$21(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$22(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$24(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$25(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$10(Landroidx/compose/runtime/MutableState;)I
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$11(Landroidx/compose/runtime/MutableState;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;I)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, LX/603;->A15(ILandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$12(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$18$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$3(Landroidx/compose/runtime/MutableState;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, LX/1Ot;->A00:F

    .line 5
    .line 6
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$4(Landroidx/compose/runtime/MutableState;F)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;F)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0L(FLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$6(Landroidx/compose/runtime/MutableState;)I
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$33$3$7(Landroidx/compose/runtime/MutableState;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;I)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, LX/603;->A15(ILandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAssistOverlayScreen$lambda$5(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAssistOverlayScreen$lambda$7(LX/16A;)LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;",
            ">;>;)",
            "LX/Ddn<",
            "Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/602;->A14(LX/16A;)LX/Ddn;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$EnableScreenshotDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->EnableScreenshotDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$11(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$14(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$17(LX/16A;)F
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A00(LX/16A;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$22(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$25(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$33$3$10(Landroidx/compose/runtime/MutableState;)I
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$33$3$11(Landroidx/compose/runtime/MutableState;I)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, LX/603;->A15(ILandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$33$3$12(LX/16A;)Z
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$33$3$4(Landroidx/compose/runtime/MutableState;F)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0L(FLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$33$3$7(Landroidx/compose/runtime/MutableState;I)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, LX/603;->A15(ILandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$5(LX/16A;)Z
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAssistOverlayScreen$lambda$7(LX/16A;)LX/Ddn;
    .locals 0

    .line 0
    invoke-static {p0}, LX/602;->A14(LX/16A;)LX/Ddn;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$isAssistScreenshotEnabled(Landroid/content/Context;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->isAssistScreenshotEnabled(Landroid/content/Context;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$openAssistSettings(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt;->openAssistSettings(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final isAssistScreenshotEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v0, "assist_screenshot_enabled"

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-static {p0, v0, v1}, Landroid/provider/Settings$Secure;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eq v0, v1, :cond_0

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    :cond_0
    return v1
.end method

.method public static final openAssistSettings(Landroid/content/Context;)V
    .locals 3

    .line 0
    const/high16 v2, 0x10000000

    .line 1
    .line 2
    :try_start_0
    const-string v1, "android.settings.VOICE_INPUT_SETTINGS"

    .line 3
    .line 4
    new-instance v0, Landroid/content/Intent;

    .line 5
    .line 6
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    :catchall_0
    move-exception v0

    .line 20
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :goto_0
    instance-of v0, v0, LX/2PH;

    .line 25
    .line 26
    xor-int/lit8 v0, v0, 0x1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    :try_start_1
    const-string v1, "android.settings.SETTINGS"

    .line 31
    .line 32
    new-instance v0, Landroid/content/Intent;

    .line 33
    .line 34
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 42
    .line 43
    .line 44
    return-void
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 45
    :catchall_1
    move-exception v0

    .line 46
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 47
    .line 48
    .line 49
    :cond_0
    return-void
.end method
