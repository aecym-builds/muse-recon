.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/2vi;",
        "LX/2sf;",
        "Landroidx/compose/ui/unit/Constraints;",
        "LX/3CP;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/AssistVoicePresentation;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2vi;

    .line 1
    .line 2
    check-cast p2, LX/2sf;

    .line 3
    .line 4
    check-cast p3, Landroidx/compose/ui/unit/Constraints;

    .line 5
    .line 6
    iget-wide v0, p3, Landroidx/compose/ui/unit/Constraints;->A00:J

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;->invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;
    .locals 5

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, p3, p4}, LX/2sf;->AQh(J)LX/3B5;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    iget v3, v4, LX/3B5;->A01:I

    .line 8
    .line 9
    iget v2, v4, LX/3B5;->A00:I

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1;->$presentation:Lcom/facebook/aura/assist/AssistVoicePresentation;

    .line 12
    .line 13
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1$1;

    .line 14
    .line 15
    invoke-direct {v0, v1, v4}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$3$1$1;-><init>(Lcom/facebook/aura/assist/AssistVoicePresentation;LX/3B5;)V

    .line 16
    .line 17
    .line 18
    invoke-static {p1, v0, v3, v2}, LX/602;->A0B(LX/2vi;LX/JDM;II)LX/3CP;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method
