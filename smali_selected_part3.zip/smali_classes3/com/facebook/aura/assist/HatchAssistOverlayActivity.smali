.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity;
.super Landroidx/activity/ComponentActivity;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/assist/HatchAssistOverlayActivity$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchAssistOverlayActivity"


# instance fields
.field public assistSessionId:Ljava/lang/String;

.field public final identityState:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/assist/AssistIdentityState;",
            ">;"
        }
    .end annotation
.end field

.field public invocationToken:J

.field public invocationViewModelStore:LX/14b;

.field public final isAwaitingUnlock:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public isUnlockRequested:Z

.field public final overlayNavigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final overlayViewModelState:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            ">;"
        }
    .end annotation
.end field

.field public ownActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

.field public savedActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

.field public userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->Companion:Lcom/facebook/aura/assist/HatchAssistOverlayActivity$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Landroidx/activity/ComponentActivity;-><init>()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-static {}, LX/JAr;->A01()LX/DxF;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-static {v1, v0}, LX/001;->A0U(LX/DxE;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 13
    .line 14
    new-instance v0, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 15
    .line 16
    invoke-direct {v0}, Lcom/facebook/aura/assist/AssistIdentityState;-><init>()V

    .line 17
    .line 18
    .line 19
    invoke-static {v1, v0}, LX/001;->A0U(LX/DxE;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->identityState:Landroidx/compose/runtime/MutableState;

    .line 24
    .line 25
    invoke-static {}, LX/002;->A0i()Ljava/lang/Boolean;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v1, v0}, LX/001;->A0U(LX/DxE;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 34
    .line 35
    const-string v0, "assist_session_id"

    .line 36
    .line 37
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->assistSessionId:Ljava/lang/String;

    .line 38
    .line 39
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;

    .line 40
    .line 41
    invoke-direct {v0, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 42
    .line 43
    .line 44
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayNavigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 45
    .line 46
    return-void
.end method

.method public static final synthetic access$assistSideChatSessionIdOrNull(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->assistSideChatSessionIdOrNull()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$collapseVoice(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->collapseVoice()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getIdentityState$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Landroidx/compose/runtime/MutableState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->identityState:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getInvocationToken$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static final synthetic access$getOverlayNavigator$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/navigation/AuraNavigator;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayNavigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOverlayViewModelState$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Landroidx/compose/runtime/MutableState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$isAwaitingUnlock$p(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Landroidx/compose/runtime/MutableState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$onUnlocked(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->onUnlocked()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$requestPermissionThenRun(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->requestPermissionThenRun(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final activateOverlay()V
    .locals 4

    .line 0
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    const/4 v1, 0x1

    .line 3
    invoke-virtual {v0, v1}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->markAssistOverlayActive(Z)V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0, v1}, Lcom/facebook/aura/assist/AssistIdentityState;->setActivityVisible(Z)V

    .line 11
    .line 12
    .line 13
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->isParked()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->restore()V

    .line 28
    .line 29
    .line 30
    :cond_0
    sget-object v3, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 31
    .line 32
    iget-wide v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 33
    .line 34
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v3, v1, v2, v0, p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->showIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 42
    .line 43
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 48
    .line 49
    if-eqz v3, :cond_1

    .line 50
    .line 51
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    const-string v1, "com.facebook.aura.extra.RESTORE_ASSIST_VOICE"

    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    xor-int/lit8 v0, v0, 0x1

    .line 63
    .line 64
    invoke-virtual {v3, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onSessionShown(Z)V

    .line 65
    .line 66
    .line 67
    :cond_1
    return-void
.end method

.method private final assistSideChatSessionIdOrNull()Ljava/lang/String;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->assistSessionId:Ljava/lang/String;

    .line 1
    .line 2
    const-string v0, "assist_session_id"

    .line 3
    .line 4
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    :cond_0
    return-object p0
.end method

.method private final clearConversation()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onSessionHidden()V

    .line 11
    .line 12
    .line 13
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-interface {v0, v1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationViewModelStore:LX/14b;

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, LX/14b;->A00()V

    .line 24
    .line 25
    .line 26
    :cond_1
    iput-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationViewModelStore:LX/14b;

    .line 27
    .line 28
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->restoreActiveChatScreen()V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method private final clearInvocation()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 1
    .line 2
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 3
    .line 4
    invoke-virtual {v2, v0, v1, p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->clearIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearConversation()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method private final collapseVoice()V
    .locals 0

    .line 0
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/assist/AssistIdentityState;->collapse()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final dismissKeyguardIfLocked()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const-class v0, Landroid/app/KeyguardManager;

    .line 9
    .line 10
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/app/KeyguardManager;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/app/KeyguardManager;->isKeyguardLocked()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x1

    .line 23
    if-ne v0, v1, :cond_0

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 26
    .line 27
    invoke-static {v1, v0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v1}, Landroid/app/Activity;->setShowWhenLocked(Z)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0}, Landroid/app/Activity;->hasWindowFocus()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->requestUnlock()V

    .line 40
    .line 41
    .line 42
    :cond_0
    return-void
.end method

.method private final getAuthenticatedUserSession()LX/AHE;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->hasPersistedSession()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    return-object v0

    .line 10
    :cond_0
    invoke-virtual {p0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSessionUnchecked()LX/AHE;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method private final onUnlocked()V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-virtual {p0, v1}, Landroid/app/Activity;->setShowWhenLocked(Z)V

    .line 2
    .line 3
    .line 4
    iput-boolean v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isUnlockRequested:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    invoke-static {v1, v0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroidx/core/app/ComponentActivity;->getLifecycle()LX/AaB;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, LX/E0b;

    .line 16
    .line 17
    iget-object v1, v0, LX/E0b;->A01:LX/15h;

    .line 18
    .line 19
    sget-object v0, LX/15h;->A05:LX/15h;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, LX/15h;->A00(LX/15h;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->activateOverlay()V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method private final requestPermissionThenRun(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    :try_start_0
    sget-object v3, Lcom/facebook/aura/commands/api/NodePermissionPrompts;->INSTANCE:Lcom/facebook/aura/commands/api/NodePermissionPrompts;

    .line 1
    .line 2
    filled-new-array {p1}, [Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestPermissionThenRun$1;

    .line 7
    .line 8
    invoke-direct {v1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestPermissionThenRun$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 9
    .line 10
    .line 11
    const/high16 v0, 0x10080000

    .line 12
    .line 13
    invoke-virtual {v3, p0, v2, v0, v1}, Lcom/facebook/aura/commands/api/NodePermissionPrompts;->launch(Landroid/content/Context;[Ljava/lang/String;ILX/JDM;)V

    .line 14
    .line 15
    .line 16
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception v2

    .line 18
    const-string v1, "Failed to launch permission activity"

    .line 19
    .line 20
    const-string v0, "HatchAssistOverlayActivity"

    .line 21
    .line 22
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method private final requestUnlock()V
    .locals 2

    .line 0
    const-class v0, Landroid/app/KeyguardManager;

    .line 1
    .line 2
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    check-cast v1, Landroid/app/KeyguardManager;

    .line 7
    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    iput-boolean v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isUnlockRequested:Z

    .line 12
    .line 13
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;

    .line 14
    .line 15
    invoke-direct {v0, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$requestUnlock$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, p0, v0}, Landroid/app/KeyguardManager;->requestDismissKeyguard(Landroid/app/Activity;Landroid/app/KeyguardManager$KeyguardDismissCallback;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void
.end method

.method private final restoreActiveChatScreen()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->ownActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 1
    .line 2
    if-eqz v3, :cond_1

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    iput-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->ownActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig;->Companion:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$Companion;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig;->activeChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 10
    .line 11
    if-ne v0, v3, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->savedActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$Companion;->setActiveChatScreen(Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    iput-object v2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->savedActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 19
    .line 20
    :cond_1
    return-void
.end method

.method private final startAuthenticatedInvocation(Landroid/content/Intent;)Z
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->getAuthenticatedUserSession()LX/AHE;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    return v2

    .line 8
    :cond_0
    iput-object v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->INSTANCE:Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;

    .line 11
    .line 12
    invoke-virtual {v0, p0, v1}, Lcom/facebook/aura/gateway/service/HatchGatewayServiceManager;->initialize(Landroid/content/Context;LX/AHE;)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/conversation/repo/HatchPrimaryConversationRepository;->Companion:Lcom/facebook/aura/conversation/repo/HatchPrimaryConversationRepository$Companion;

    .line 16
    .line 17
    invoke-virtual {v0, p0, v1}, Lcom/facebook/aura/conversation/repo/HatchPrimaryConversationRepository$Companion;->getInstance(Landroid/content/Context;LX/AHE;)Lcom/facebook/aura/conversation/repo/HatchPrimaryConversationRepository;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v1, v0, Lcom/facebook/aura/conversation/repo/HatchPrimaryConversationRepository;->repository:Lcom/facebook/aura/conversation/repo/HatchConversationRepository;

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    invoke-virtual {v1, v2}, Lcom/facebook/aura/conversation/repo/HatchConversationRepository;->connectIfDisconnected(Z)V

    .line 25
    .line 26
    .line 27
    invoke-direct {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startInvocation(Landroid/content/Intent;)V

    .line 28
    .line 29
    .line 30
    return v0
.end method

.method private final startConversation()V
    .locals 11

    .line 0
    sget-object v1, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 1
    .line 2
    move-object v7, p0

    .line 3
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 4
    .line 5
    const-string v5, "userSession"

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    invoke-static {v5}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    throw v0

    .line 17
    :cond_0
    invoke-virtual {v1, v0}, Lcom/facebook/aura/assist/api/AssistCalls;->ongoing(LX/AHE;)Lcom/facebook/aura/assist/api/AssistOngoingCall;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/assist/status/HatchAssistSideChatSetting;->INSTANCE:Lcom/facebook/aura/assist/status/HatchAssistSideChatSetting;

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/assist/status/HatchAssistSideChatSetting;->isEnabled()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    const/4 p0, 0x1

    .line 30
    if-nez v0, :cond_2

    .line 31
    .line 32
    :cond_1
    const/4 p0, 0x0

    .line 33
    :cond_2
    const-string v9, "assist_session_id"

    .line 34
    .line 35
    if-eqz v1, :cond_4

    .line 36
    .line 37
    iget-object v0, v1, Lcom/facebook/aura/assist/api/AssistOngoingCall;->threadId:Ljava/lang/String;

    .line 38
    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    move-object v9, v0

    .line 42
    :cond_3
    :goto_0
    iput-object v9, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->assistSessionId:Ljava/lang/String;

    .line 43
    .line 44
    new-instance v4, LX/14b;

    .line 45
    .line 46
    invoke-direct {v4}, LX/14b;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v4, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationViewModelStore:LX/14b;

    .line 50
    .line 51
    iget-object v8, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 52
    .line 53
    if-nez v8, :cond_5

    .line 54
    .line 55
    invoke-static {v5}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    throw v0

    .line 63
    :cond_4
    if-eqz p0, :cond_3

    .line 64
    .line 65
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    goto :goto_0

    .line 70
    :cond_5
    const/4 v10, 0x1

    .line 71
    new-instance v6, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel$Factory;

    .line 72
    .line 73
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel$Factory;-><init>(Landroid/content/Context;LX/AHE;Ljava/lang/String;ZZ)V

    .line 74
    .line 75
    .line 76
    sget-object v3, LX/13j;->A00:LX/13j;

    .line 77
    .line 78
    new-instance v1, LX/15D;

    .line 79
    .line 80
    invoke-direct {v1, v6, v4, v3}, LX/15D;-><init>(LX/15L;LX/14b;LX/13i;)V

    .line 81
    .line 82
    .line 83
    const-class v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 84
    .line 85
    invoke-virtual {v1, v0}, LX/15D;->A01(Ljava/lang/Class;)LX/1EJ;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    check-cast v2, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 90
    .line 91
    iget-object v1, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->userSession:LX/AHE;

    .line 92
    .line 93
    if-nez v1, :cond_6

    .line 94
    .line 95
    invoke-static {v5}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    throw v0

    .line 103
    :cond_6
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;

    .line 104
    .line 105
    invoke-direct {v0, v7, v1, v2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$Factory;-><init>(Landroid/content/Context;LX/AHE;Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V

    .line 106
    .line 107
    .line 108
    new-instance v1, LX/15D;

    .line 109
    .line 110
    invoke-direct {v1, v0, v4, v3}, LX/15D;-><init>(LX/15L;LX/14b;LX/13i;)V

    .line 111
    .line 112
    .line 113
    const-class v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 114
    .line 115
    invoke-virtual {v1, v0}, LX/15D;->A01(Ljava/lang/Class;)LX/1EJ;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    iget-object v0, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->assistSessionId:Ljava/lang/String;

    .line 120
    .line 121
    invoke-direct {v7, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->suppressAssistChatNotifications(Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    iget-object v0, v7, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 125
    .line 126
    invoke-interface {v0, v1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    return-void
.end method

.method private final startInvocation(Landroid/content/Intent;)V
    .locals 7

    .line 0
    const-string v2, "com.facebook.aura.extra.ASSIST_INVOCATION_TOKEN"

    .line 1
    .line 2
    const-wide/16 v0, 0x0

    .line 3
    .line 4
    invoke-virtual {p1, v2, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 5
    .line 6
    .line 7
    move-result-wide v1

    .line 8
    const-string v0, "com.facebook.aura.extra.RESTORE_ASSIST_VOICE"

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    invoke-virtual {p1, v0, v6}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 18
    .line 19
    invoke-virtual {v0, v1, v2}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->retainedIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(J)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    if-eqz v5, :cond_3

    .line 24
    .line 25
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearConversation()V

    .line 26
    .line 27
    .line 28
    :goto_0
    iget-object v4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->identityState:Landroidx/compose/runtime/MutableState;

    .line 29
    .line 30
    if-nez v5, :cond_0

    .line 31
    .line 32
    new-instance v5, Lcom/facebook/aura/assist/AssistIdentityState;

    .line 33
    .line 34
    invoke-direct {v5}, Lcom/facebook/aura/assist/AssistIdentityState;-><init>()V

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {p0}, Landroidx/core/app/ComponentActivity;->getLifecycle()LX/AaB;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, LX/E0b;

    .line 48
    .line 49
    iget-object v3, v0, LX/E0b;->A01:LX/15h;

    .line 50
    .line 51
    sget-object v0, LX/15h;->A05:LX/15h;

    .line 52
    .line 53
    invoke-virtual {v3, v0}, LX/15h;->A00(LX/15h;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_1

    .line 58
    .line 59
    const/4 v6, 0x1

    .line 60
    :cond_1
    invoke-virtual {v5, v6}, Lcom/facebook/aura/assist/AssistIdentityState;->setActivityVisible(Z)V

    .line 61
    .line 62
    .line 63
    invoke-interface {v4, v5}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iput-wide v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 67
    .line 68
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startConversation()V

    .line 69
    .line 70
    .line 71
    sget-object v3, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 72
    .line 73
    iget-wide v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 74
    .line 75
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v3, v1, v2, v0, p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->showIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/AssistIdentityState;Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :cond_2
    const/4 v5, 0x0

    .line 84
    :cond_3
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearInvocation()V

    .line 85
    .line 86
    .line 87
    goto :goto_0
.end method

.method private final suppressAssistChatNotifications(Ljava/lang/String;)V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig;->Companion:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$Companion;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig;->activeChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 3
    .line 4
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->savedActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 5
    .line 6
    const-string v0, "assist_session_id"

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    xor-int/lit8 v1, v0, 0x1

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    :cond_0
    new-instance v0, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 18
    .line 19
    invoke-direct {v0, p1, v1}, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;-><init>(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->ownActiveChatScreen:Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;

    .line 23
    .line 24
    invoke-virtual {v2, v0}, Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$Companion;->setActiveChatScreen(Lcom/facebook/aura/notifications/model/HatchChatLocalNotificationConfig$ActiveChatScreen;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    const/4 v3, 0x0

    .line 5
    invoke-static {v0, v3}, LX/0s0;->A00(Landroid/view/Window;Z)V

    .line 6
    .line 7
    .line 8
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/high16 v0, -0x80000000

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/high16 v0, 0x8000000

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/view/Window;->clearFlags(I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {v0, v3}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    new-instance v0, LX/0xQ;

    .line 49
    .line 50
    invoke-direct {v0, v1, v2}, LX/0xQ;-><init>(Landroid/view/View;Landroid/view/Window;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0, v3}, LX/0xQ;->A01(Z)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {v0, v3}, Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V

    .line 61
    .line 62
    .line 63
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 64
    .line 65
    const/16 v0, 0x22

    .line 66
    .line 67
    const/4 v2, 0x1

    .line 68
    if-lt v1, v0, :cond_0

    .line 69
    .line 70
    invoke-virtual {p0, v3, v3, v3, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overrideActivityTransition(IIII)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0, v2, v3, v3, v3}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overrideActivityTransition(IIII)V

    .line 74
    .line 75
    .line 76
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    invoke-direct {p0, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startAuthenticatedInvocation(Landroid/content/Intent;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-nez v0, :cond_1

    .line 88
    .line 89
    const-string v1, "HatchAssistOverlayActivity"

    .line 90
    .line 91
    const-string v0, "onCreate: no authenticated session, falling back to full app"

    .line 92
    .line 93
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    sget-object v1, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 97
    .line 98
    const/4 v0, 0x0

    .line 99
    invoke-virtual {v1, p0, v0, v3}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 103
    .line 104
    .line 105
    return-void

    .line 106
    :cond_0
    invoke-virtual {p0, v3, v3}, Landroid/app/Activity;->overridePendingTransition(II)V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->dismissKeyguardIfLocked()V

    .line 111
    .line 112
    .line 113
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;

    .line 114
    .line 115
    invoke-direct {v1, p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$onCreate$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V

    .line 116
    .line 117
    .line 118
    const v0, -0x2ee773f7

    .line 119
    .line 120
    .line 121
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-static {p0, v0}, LX/14O;->A00(Landroidx/activity/ComponentActivity;LX/JDN;)V

    .line 126
    .line 127
    .line 128
    return-void
.end method

.method public onDestroy()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 1
    .line 2
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 3
    .line 4
    invoke-virtual {v2, v0, v1, p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->detachIdentity$fbandroid_express_aura_java_com_facebook_aura_assist_assist(JLcom/facebook/aura/assist/HatchAssistOverlayActivity;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearConversation()V

    .line 11
    .line 12
    .line 13
    :goto_0
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearInvocation()V

    .line 18
    .line 19
    .line 20
    sget-object v2, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 21
    .line 22
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 23
    .line 24
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->clearIfCurrent(J)V

    .line 25
    .line 26
    .line 27
    goto :goto_0
.end method

.method public final onInvokedAgain$fbandroid_express_aura_java_com_facebook_aura_assist_assist()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 7
    .line 8
    if-eqz p0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onInvokedAgain()V

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method

.method public onNewIntent(Landroid/content/Intent;)V
    .locals 6

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onNewIntent(Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 8
    .line 9
    .line 10
    const-string v0, "com.facebook.aura.extra.RESTORE_ASSIST_VOICE"

    .line 11
    .line 12
    invoke-virtual {p1, v0, v5}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    const-string v2, "com.facebook.aura.extra.ASSIST_INVOCATION_TOKEN"

    .line 19
    .line 20
    const-wide/16 v0, 0x0

    .line 21
    .line 22
    invoke-virtual {p1, v2, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 23
    .line 24
    .line 25
    move-result-wide v3

    .line 26
    iget-wide v1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 27
    .line 28
    cmp-long v0, v3, v1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startAuthenticatedInvocation(Landroid/content/Intent;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_1

    .line 38
    .line 39
    sget-object v1, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    invoke-virtual {v1, p0, v0, v5}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->dismissKeyguardIfLocked()V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public onPause()V
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-virtual {v0, v1}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->markAssistOverlayActive(Z)V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0, v1}, Lcom/facebook/aura/assist/AssistIdentityState;->setActivityVisible(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 14
    .line 15
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->endVoiceDictation()V

    .line 24
    .line 25
    .line 26
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public onResume()V
    .locals 1

    .line 0
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p0, v0, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 8
    .line 9
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->activateOverlay()V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public onTopResumedActivityChanged(Z)V
    .locals 3

    .line 0
    invoke-super {p0, p1}, Landroid/app/Activity;->onTopResumedActivityChanged(Z)V

    .line 1
    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 4
    .line 5
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroid/app/Activity;->isInPictureInPictureMode()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {v2, v1, p1, v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->markTopResumedActivity(IZZ)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 1

    .line 0
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    .line 1
    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 6
    .line 7
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-boolean v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isUnlockRequested:Z

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->requestUnlock()V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final parkVoiceControls$fbandroid_express_aura_java_com_facebook_aura_assist_assist()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-virtual {p0, v0}, Landroid/app/Activity;->moveTaskToBack(Z)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/assist/AssistIdentityState;->restore()V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public final resetAfterVoiceCall$fbandroid_express_aura_java_com_facebook_aura_assist_assist()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/603;->A0L(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Lcom/facebook/aura/assist/AssistIdentityState;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    invoke-virtual {v1}, Lcom/facebook/aura/assist/AssistIdentityState;->getActivityVisible()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-virtual {v1}, Lcom/facebook/aura/assist/AssistIdentityState;->getPhase()Lcom/facebook/aura/assist/AssistIdentityPhase;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    sget-object v0, Lcom/facebook/aura/assist/AssistIdentityPhase;->EXPANDED:Lcom/facebook/aura/assist/AssistIdentityPhase;

    .line 15
    .line 16
    if-ne v1, v0, :cond_1

    .line 17
    .line 18
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->clearConversation()V

    .line 19
    .line 20
    .line 21
    sget-object v2, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 22
    .line 23
    iget-wide v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->invocationToken:J

    .line 24
    .line 25
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->clearIfCurrent(J)V

    .line 26
    .line 27
    .line 28
    invoke-direct {p0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startConversation()V

    .line 29
    .line 30
    .line 31
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->isAwaitingUnlock:Landroidx/compose/runtime/MutableState;

    .line 32
    .line 33
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_0

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 40
    .line 41
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    check-cast v1, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 46
    .line 47
    if-eqz v1, :cond_0

    .line 48
    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-virtual {v1, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onSessionShown(Z)V

    .line 51
    .line 52
    .line 53
    :cond_0
    return-void

    .line 54
    :cond_1
    const-class v0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 55
    .line 56
    new-instance v3, Landroid/content/Intent;

    .line 57
    .line 58
    invoke-direct {v3, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 59
    .line 60
    .line 61
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistContextHolder;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistContextHolder;

    .line 62
    .line 63
    invoke-virtual {v0}, Lcom/facebook/aura/assist/HatchAssistContextHolder;->beginInvocation()J

    .line 64
    .line 65
    .line 66
    move-result-wide v1

    .line 67
    const-string v0, "com.facebook.aura.extra.ASSIST_INVOCATION_TOKEN"

    .line 68
    .line 69
    invoke-virtual {v3, v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 77
    .line 78
    .line 79
    invoke-direct {p0, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->startInvocation(Landroid/content/Intent;)V

    .line 80
    .line 81
    .line 82
    goto :goto_0
.end method
