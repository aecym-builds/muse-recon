.class public final Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/1V8;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;->INSTANCE:Lcom/facebook/aura/assist/AssistVoicePresentationKt$reverseVoiceEasing$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final transform(F)F
    .locals 2

    .line 0
    sget-object p0, LX/33X;->A01:LX/1V8;

    .line 1
    .line 2
    const/high16 v1, 0x3f800000    # 1.0f

    .line 3
    .line 4
    sub-float v0, v1, p1

    .line 5
    .line 6
    invoke-interface {p0, v0}, LX/1V8;->transform(F)F

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    sub-float/2addr v1, v0

    .line 11
    return v1
.end method
