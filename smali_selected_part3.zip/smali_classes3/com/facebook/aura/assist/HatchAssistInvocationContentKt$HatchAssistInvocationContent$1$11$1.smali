.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

.field public final synthetic $session:LX/AHE;

.field public final synthetic $threadId:Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/AHE;Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$session:LX/AHE;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$threadId:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/assist/api/AssistCalls;->INSTANCE:Lcom/facebook/aura/assist/api/AssistCalls;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$session:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/assist/api/AssistCalls;->ongoing(LX/AHE;)Lcom/facebook/aura/assist/api/AssistOngoingCall;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sget-object v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 9
    .line 10
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$context:Landroid/content/Context;

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    iget-object v2, v0, Lcom/facebook/aura/assist/api/AssistOngoingCall;->threadId:Ljava/lang/String;

    .line 15
    .line 16
    :goto_0
    const/4 v1, 0x0

    .line 17
    :cond_0
    invoke-virtual {v4, v3, v2, v1}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$threadId:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$11$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 26
    .line 27
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->isUnsentNewThread()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    const/4 v1, 0x1

    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    goto :goto_0
.end method
