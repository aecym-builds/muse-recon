.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.assist.HatchAssistInvocationContentKt$AssistUploadEffects$1$1"
    f = "HatchAssistInvocationContent.kt"
    l = {
        0x74
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;-><init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;Landroid/content/Context;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-eq v0, v3, :cond_1

    .line 8
    .line 9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    throw v0

    .line 14
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$conversation:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 18
    .line 19
    iget-object v2, v0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->viewEffects:LX/2QV;

    .line 20
    .line 21
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->$context:Landroid/content/Context;

    .line 22
    .line 23
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;

    .line 24
    .line 25
    invoke-direct {v0, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1$1;-><init>(Landroid/content/Context;)V

    .line 26
    .line 27
    .line 28
    iput v3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;->label:I

    .line 29
    .line 30
    invoke-interface {v2, v0, p0}, LX/2QV;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-ne v0, v4, :cond_2

    .line 35
    .line 36
    return-object v4

    .line 37
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_2
    invoke-static {}, LX/001;->A19()Lkotlin/KotlinNothingValueException;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    throw v0
.end method
