.class public final Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/1O1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $agentNameState:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

.field public final synthetic $convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

.field public final synthetic $density:LX/34Y;

.field public final synthetic $frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $listItems:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onWidgetSendMessage:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/model/HatchSendMessage;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onWidgetSetState:LX/JDO;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDO<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

.field public final synthetic $timelineContents$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/Ddn<",
            "Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Ddn;Lcom/facebook/aura/assist/AssistOverlayState;LX/16A;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/34Y;LX/16A;LX/JDM;LX/JDO;Landroidx/compose/runtime/MutableState;Lcom/facebook/aura/vds/compose/theme/AuraColors;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationListItem;",
            ">;",
            "Lcom/facebook/aura/assist/AssistOverlayState;",
            "LX/16A<",
            "+",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/conversation/widget/api/ConversationTimelineContent;",
            ">;>;",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;",
            "LX/34Y;",
            "LX/16A<",
            "Ljava/lang/String;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/model/HatchSendMessage;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDO<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/facebook/aura/vds/compose/theme/AuraColors;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$listItems:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$timelineContents$delegate:LX/16A;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$density:LX/34Y;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$agentNameState:LX/16A;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$onWidgetSendMessage:LX/JDM;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$onWidgetSetState:LX/JDO;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1O1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->invoke(LX/1O1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/1O1;)V
    .locals 21

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object/from16 v3, p1

    .line 2
    .line 3
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v9, p0

    .line 7
    .line 8
    iget-object v0, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$timelineContents$delegate:LX/16A;

    .line 9
    .line 10
    invoke-static {v0}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object v6

    .line 14
    sget-object v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$1;

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$2;

    .line 17
    .line 18
    iget-object v5, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 19
    .line 20
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    const/4 v12, 0x0

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    new-instance v2, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$1;

    .line 28
    .line 29
    invoke-direct {v2, v1, v6}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$1;-><init>(LX/JDM;Ljava/util/List;)V

    .line 30
    .line 31
    .line 32
    :goto_0
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$2;

    .line 33
    .line 34
    invoke-direct {v1, v0, v6}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$2;-><init>(LX/JDM;Ljava/util/List;)V

    .line 35
    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;

    .line 38
    .line 39
    invoke-direct {v0, v6, v5}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$3;-><init>(Ljava/util/List;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;)V

    .line 40
    .line 41
    .line 42
    const v13, 0x2fd4df92

    .line 43
    .line 44
    .line 45
    const/4 v6, 0x1

    .line 46
    invoke-static {v0, v13, v6}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-interface {v3, v2, v1, v0, v4}, LX/1O1;->APU(LX/JDM;LX/JDM;LX/JDO;I)V

    .line 51
    .line 52
    .line 53
    iget-object v15, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$listItems:LX/Ddn;

    .line 54
    .line 55
    sget-object v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$4;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$4;

    .line 56
    .line 57
    iget-object v11, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$density:LX/34Y;

    .line 58
    .line 59
    iget-object v10, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$convState:Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 60
    .line 61
    iget-object v8, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$agentNameState:LX/16A;

    .line 62
    .line 63
    iget-object v7, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$onWidgetSendMessage:LX/JDM;

    .line 64
    .line 65
    iget-object v5, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$onWidgetSetState:LX/JDO;

    .line 66
    .line 67
    iget-object v4, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$frozenHeightPx$delegate:Landroidx/compose/runtime/MutableState;

    .line 68
    .line 69
    sget-object v0, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;->INSTANCE:Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$1;

    .line 70
    .line 71
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-eqz v1, :cond_0

    .line 76
    .line 77
    new-instance v12, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$2;

    .line 78
    .line 79
    invoke-direct {v12, v1, v15}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$2;-><init>(LX/JDM;Ljava/util/List;)V

    .line 80
    .line 81
    .line 82
    :cond_0
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$3;

    .line 83
    .line 84
    invoke-direct {v1, v0, v15}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$3;-><init>(LX/JDM;Ljava/util/List;)V

    .line 85
    .line 86
    .line 87
    new-instance v14, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;

    .line 88
    .line 89
    move-object/from16 v16, v15

    .line 90
    .line 91
    move-object/from16 p1, v4

    .line 92
    .line 93
    move-object/from16 p0, v5

    .line 94
    .line 95
    move-object/from16 v20, v7

    .line 96
    .line 97
    move-object/from16 v19, v8

    .line 98
    .line 99
    move-object/from16 v18, v10

    .line 100
    .line 101
    move-object/from16 v17, v11

    .line 102
    .line 103
    invoke-direct/range {v14 .. v22}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$invoke$$inlined$items$default$4;-><init>(Ljava/util/List;LX/Ddn;LX/34Y;Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/16A;LX/JDM;LX/JDO;Landroidx/compose/runtime/MutableState;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v14, v13, v6}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-interface {v3, v12, v1, v0, v2}, LX/1O1;->APU(LX/JDM;LX/JDM;LX/JDO;I)V

    .line 111
    .line 112
    .line 113
    iget-object v2, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$overlayState:Lcom/facebook/aura/assist/AssistOverlayState;

    .line 114
    .line 115
    iget-object v1, v2, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 116
    .line 117
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->ERROR:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 118
    .line 119
    if-ne v1, v0, :cond_1

    .line 120
    .line 121
    iget-object v0, v9, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1;->$colors:Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 122
    .line 123
    new-instance v1, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;

    .line 124
    .line 125
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/assist/HatchAssistOverlayScreenKt$HatchAssistOverlayScreen$11$4$8$2$1$6;-><init>(Lcom/facebook/aura/assist/AssistOverlayState;Lcom/facebook/aura/vds/compose/theme/AuraColors;)V

    .line 126
    .line 127
    .line 128
    const v0, 0x7294e0bb

    .line 129
    .line 130
    .line 131
    invoke-static {v1, v0, v6}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    const/4 v1, 0x0

    .line 136
    const-string v0, "error"

    .line 137
    .line 138
    invoke-interface {v3, v0, v1, v2}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 139
    .line 140
    .line 141
    :cond_1
    return-void

    .line 142
    :cond_2
    move-object v2, v12

    .line 143
    goto :goto_0
.end method
