.class public abstract Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AssistOnScreenEffect(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V
    .locals 9

    .line 0
    const v0, -0x50ac86fd

    .line 1
    .line 2
    .line 3
    move-object v5, p1

    .line 4
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p2, 0x6

    .line 8
    .line 9
    const/4 v4, 0x4

    .line 10
    const/4 p1, 0x2

    .line 11
    move-object v7, p0

    .line 12
    if-nez v0, :cond_6

    .line 13
    .line 14
    invoke-static {p0, v5, p2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-static {v0}, LX/003;->A06(I)I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    or-int/2addr v3, p2

    .line 23
    :goto_0
    and-int/lit8 v0, v3, 0x3

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-static {v0, p1}, LX/003;->A1H(II)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, v5, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_5

    .line 35
    .line 36
    and-int/lit8 v1, v3, 0xe

    .line 37
    .line 38
    if-eq v1, v4, :cond_0

    .line 39
    .line 40
    and-int/lit8 v0, v3, 0x8

    .line 41
    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    invoke-interface {v5, p0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    :cond_0
    const/4 v2, 0x1

    .line 51
    :cond_1
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v8

    .line 55
    if-nez v2, :cond_2

    .line 56
    .line 57
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 58
    .line 59
    if-ne v8, v0, :cond_3

    .line 60
    .line 61
    :cond_2
    new-instance v8, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;

    .line 62
    .line 63
    invoke-direct {v8, p0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$1$1;-><init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;)V

    .line 64
    .line 65
    .line 66
    invoke-interface {v5, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    :cond_3
    check-cast v8, LX/JDM;

    .line 70
    .line 71
    sget p0, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->$stable:I

    .line 72
    .line 73
    or-int/2addr p0, v1

    .line 74
    const/4 v6, 0x0

    .line 75
    invoke-static/range {v5 .. v10}, LX/CcX;->A05(LX/2d4;LX/07p;Ljava/lang/Object;LX/JDM;II)V

    .line 76
    .line 77
    .line 78
    :goto_1
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    if-eqz v1, :cond_4

    .line 83
    .line 84
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$2;

    .line 85
    .line 86
    invoke-direct {v0, v7, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistOnScreenEffect$2;-><init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;I)V

    .line 87
    .line 88
    .line 89
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 90
    .line 91
    :cond_4
    return-void

    .line 92
    :cond_5
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_6
    move v3, p2

    .line 97
    goto :goto_0
.end method

.method public static final AssistUploadEffects(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V
    .locals 5

    .line 0
    const v0, -0x280fcd66

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v0, p2, 0x6

    .line 7
    .line 8
    const/4 v4, 0x4

    .line 9
    const/4 v2, 0x2

    .line 10
    if-nez v0, :cond_6

    .line 11
    .line 12
    invoke-static {p0, p1, p2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {v0}, LX/003;->A06(I)I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    or-int/2addr v3, p2

    .line 21
    :goto_0
    and-int/lit8 v0, v3, 0x3

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    invoke-static {v0, v2}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0, p1, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    invoke-static {p1}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    and-int/lit8 v0, v3, 0xe

    .line 39
    .line 40
    if-eq v0, v4, :cond_0

    .line 41
    .line 42
    and-int/lit8 v0, v3, 0x8

    .line 43
    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    invoke-interface {p1, p0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    :cond_0
    const/4 v1, 0x1

    .line 53
    :cond_1
    invoke-static {p1, v2, v1}, LX/006;->A1Y(LX/2d4;Ljava/lang/Object;Z)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-nez v1, :cond_2

    .line 62
    .line 63
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v0, v1, :cond_3

    .line 66
    .line 67
    :cond_2
    const/4 v1, 0x0

    .line 68
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;

    .line 69
    .line 70
    invoke-direct {v0, p0, v2, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$1$1;-><init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;Landroid/content/Context;LX/2M4;)V

    .line 71
    .line 72
    .line 73
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_3
    invoke-static {p1, v0, p0}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    if-eqz v1, :cond_4

    .line 84
    .line 85
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$2;

    .line 86
    .line 87
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$AssistUploadEffects$2;-><init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;I)V

    .line 88
    .line 89
    .line 90
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 91
    .line 92
    :cond_4
    return-void

    .line 93
    :cond_5
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_6
    move v3, p2

    .line 98
    goto :goto_0
.end method

.method public static final HatchAssistInvocationContent(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;LX/3C1;LX/2d4;II)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v10, p5

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    move-object v5, p0

    .line 4
    move-object v7, p2

    .line 5
    move-object v8, p3

    .line 6
    move-object v9, p4

    .line 7
    invoke-static {p0, p2, p3, p4, v1}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const v0, -0x3171e3ca

    .line 11
    .line 12
    .line 13
    move-object/from16 v2, p6

    .line 14
    .line 15
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 p0, p7

    .line 19
    .line 20
    and-int/lit8 v0, p7, 0x6

    .line 21
    .line 22
    if-nez v0, :cond_9

    .line 23
    .line 24
    invoke-static {v5, v2, p0}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0}, LX/003;->A06(I)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    or-int v4, v4, p7

    .line 33
    .line 34
    :goto_0
    and-int/lit8 v0, p7, 0x30

    .line 35
    .line 36
    move-object v6, p1

    .line 37
    if-nez v0, :cond_0

    .line 38
    .line 39
    invoke-static {v2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v4, v0

    .line 44
    :cond_0
    and-int/lit16 v0, p0, 0x180

    .line 45
    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    invoke-static {v2, p2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    or-int/2addr v4, v0

    .line 53
    :cond_1
    and-int/lit16 v0, p0, 0xc00

    .line 54
    .line 55
    if-nez v0, :cond_2

    .line 56
    .line 57
    invoke-static {v2, p3}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    or-int/2addr v4, v0

    .line 62
    :cond_2
    and-int/lit16 v0, p0, 0x6000

    .line 63
    .line 64
    if-nez v0, :cond_3

    .line 65
    .line 66
    invoke-static {v2, p4}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    or-int/2addr v4, v0

    .line 71
    :cond_3
    move/from16 p1, p8

    .line 72
    .line 73
    and-int/lit8 v3, p8, 0x20

    .line 74
    .line 75
    const/high16 v0, 0x30000

    .line 76
    .line 77
    if-nez v3, :cond_4

    .line 78
    .line 79
    and-int v0, v0, p7

    .line 80
    .line 81
    if-nez v0, :cond_5

    .line 82
    .line 83
    invoke-static {v2, v10}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    :cond_4
    or-int/2addr v4, v0

    .line 88
    :cond_5
    invoke-static {v4}, LX/005;->A1C(I)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    invoke-static {v0, v2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_8

    .line 97
    .line 98
    if-eqz v3, :cond_6

    .line 99
    .line 100
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 101
    .line 102
    :cond_6
    iget-object v0, v5, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 103
    .line 104
    sget v3, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->$stable:I

    .line 105
    .line 106
    invoke-static {v0, v2, v3}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;->AssistUploadEffects(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V

    .line 107
    .line 108
    .line 109
    iget-object v0, v5, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 110
    .line 111
    invoke-static {v0, v2, v3}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;->AssistOnScreenEffect(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V

    .line 112
    .line 113
    .line 114
    new-instance v3, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;

    .line 115
    .line 116
    move-object p2, v3

    .line 117
    move-object p3, v5

    .line 118
    move-object/from16 p5, v6

    .line 119
    .line 120
    move-object/from16 p6, v7

    .line 121
    .line 122
    move-object/from16 p7, v8

    .line 123
    .line 124
    invoke-direct/range {p2 .. p7}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/JDN;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 125
    .line 126
    .line 127
    const v0, 0x37de2d7c

    .line 128
    .line 129
    .line 130
    invoke-static {v2, v3, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 131
    .line 132
    .line 133
    move-result-object p5

    .line 134
    sget v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->$stable:I

    .line 135
    .line 136
    or-int/lit16 v3, v0, 0xc00

    .line 137
    .line 138
    and-int/lit8 v0, v4, 0xe

    .line 139
    .line 140
    or-int/2addr v3, v0

    .line 141
    and-int/lit8 v0, v4, 0x70

    .line 142
    .line 143
    or-int/2addr v3, v0

    .line 144
    shr-int/lit8 v0, v4, 0x9

    .line 145
    .line 146
    and-int/lit16 v0, v0, 0x380

    .line 147
    .line 148
    or-int/2addr v3, v0

    .line 149
    move-object p2, v5

    .line 150
    move-object p3, v6

    .line 151
    move-object p4, v10

    .line 152
    move/from16 p7, v3

    .line 153
    .line 154
    move/from16 p8, v1

    .line 155
    .line 156
    move-object/from16 p6, v2

    .line 157
    .line 158
    invoke-static/range {p2 .. p8}, Lcom/facebook/aura/assist/HatchAssistVoiceModeKt;->HatchAssistVoiceMode(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;LX/3C1;LX/JDO;LX/2d4;II)V

    .line 159
    .line 160
    .line 161
    :goto_1
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    if-eqz v0, :cond_7

    .line 166
    .line 167
    new-instance v4, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$2;

    .line 168
    .line 169
    invoke-direct/range {v4 .. v12}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$2;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;LX/3C1;II)V

    .line 170
    .line 171
    .line 172
    iput-object v4, v0, LX/J7V;->A06:LX/JDN;

    .line 173
    .line 174
    :cond_7
    return-void

    .line 175
    :cond_8
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 176
    .line 177
    .line 178
    goto :goto_1

    .line 179
    :cond_9
    move v4, p0

    .line 180
    goto/16 :goto_0
.end method

.method public static final synthetic access$AssistOnScreenEffect(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;->AssistOnScreenEffect(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AssistUploadEffects(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt;->AssistUploadEffects(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
