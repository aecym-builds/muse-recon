.class public final Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/7TA<",
        "Ljava/lang/Boolean;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $this_animateValue:LX/DwH;


# direct methods
.method public constructor <init>(LX/DwH;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;->$this_animateValue:LX/DwH;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke()LX/7TA;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/7TA<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;->$this_animateValue:LX/DwH;

    .line 1
    .line 2
    invoke-virtual {p0}, LX/DwH;->A03()LX/7TA;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentationKt$rememberAssistVoicePresentation$$inlined$animateFloat$2;->$this_animateValue:LX/DwH;

    .line 268435457
    .line 268435458
    invoke-virtual {p0}, LX/DwH;->A03()LX/7TA;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
