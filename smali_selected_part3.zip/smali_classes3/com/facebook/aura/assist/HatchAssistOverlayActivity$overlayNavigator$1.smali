.class public final Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/navigation/AuraNavigator;


# instance fields
.field public final synthetic $$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/assist/NoOpAssistNavigator;->INSTANCE:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 6
    .line 7
    iput-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 8
    .line 9
    return-void
.end method

.method private final routeOrIgnore(Lcom/facebook/aura/navigation/AuraNavKey;)V
    .locals 5

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/AgentPermissionMessageEditorScreenKey;

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/AgentPermissionTaskDetailsSheetKey;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/AgentComputerScreenKey;

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/RemoteBrowserScreenKey;

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutInfoSheetKey;

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutLodgingPolicySheetKey;

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutPayWithLinkSheetKey;

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutPaymentSetupSheetKey;

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutWalletCardSelectionSheetKey;

    .line 37
    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/CheckoutWalletSheetKey;

    .line 41
    .line 42
    if-nez v0, :cond_0

    .line 43
    .line 44
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/ConnectorOrderDetailGroupSheetKey;

    .line 45
    .line 46
    if-nez v0, :cond_0

    .line 47
    .line 48
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/DeliveryCheckoutStopSheetKey;

    .line 49
    .line 50
    if-nez v0, :cond_0

    .line 51
    .line 52
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/FlightCheckoutLegSheetKey;

    .line 53
    .line 54
    if-nez v0, :cond_0

    .line 55
    .line 56
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/FlightCheckoutSummarySheetKey;

    .line 57
    .line 58
    if-nez v0, :cond_0

    .line 59
    .line 60
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/ModelLockSupportSheetKey;

    .line 61
    .line 62
    if-nez v0, :cond_0

    .line 63
    .line 64
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/PurchasePaymentMethodsSheetKey;

    .line 65
    .line 66
    if-nez v0, :cond_0

    .line 67
    .line 68
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/ReservationCheckoutDetailsSheetKey;

    .line 69
    .line 70
    if-nez v0, :cond_0

    .line 71
    .line 72
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/SecureStorageCaptureSheetKey;

    .line 73
    .line 74
    if-nez v0, :cond_0

    .line 75
    .line 76
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/ShopifyCheckoutCartSheetKey;

    .line 77
    .line 78
    if-nez v0, :cond_0

    .line 79
    .line 80
    instance-of v0, p1, Lcom/facebook/aura/navigation/key/ShopifyCheckoutSummarySheetKey;

    .line 81
    .line 82
    if-eqz v0, :cond_2

    .line 83
    .line 84
    :cond_0
    sget-object v4, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;

    .line 85
    .line 86
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 87
    .line 88
    invoke-static {v3}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->access$assistSideChatSessionIdOrNull(Lcom/facebook/aura/assist/HatchAssistOverlayActivity;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    iget-object v0, v3, Lcom/facebook/aura/assist/HatchAssistOverlayActivity;->overlayViewModelState:Landroidx/compose/runtime/MutableState;

    .line 93
    .line 94
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    check-cast v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 99
    .line 100
    const/4 v1, 0x0

    .line 101
    if-eqz v0, :cond_1

    .line 102
    .line 103
    iget-object v0, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->conversationViewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 104
    .line 105
    if-eqz v0, :cond_1

    .line 106
    .line 107
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->isUnsentNewThread()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-static {v0}, LX/602;->A1S(I)Z

    .line 112
    .line 113
    .line 114
    move-result v1

    .line 115
    :cond_1
    invoke-virtual {v4, v3, v2, v1}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession$Companion;->launchFullApp(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 116
    .line 117
    .line 118
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayActivity;

    .line 119
    .line 120
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 121
    .line 122
    .line 123
    :cond_2
    return-void
.end method


# virtual methods
.method public addBeforeBackStackChangeListener(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public back()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/assist/NoOpAssistNavigator;->back()Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public currentKey(Z)Lcom/facebook/aura/navigation/AuraNavKey;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Lcom/facebook/aura/assist/NoOpAssistNavigator;->currentKey(Z)Lcom/facebook/aura/navigation/AuraNavKey;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public currentTabRoot()Lcom/facebook/aura/navigation/AuraTabRootNavKey;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/assist/NoOpAssistNavigator;->currentTabRoot()Lcom/facebook/aura/navigation/AuraTabRootNavKey;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public dismissBottomSheetStack(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public isInBackStack(LX/JDM;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Lcom/facebook/aura/assist/NoOpAssistNavigator;->isInBackStack(LX/JDM;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0
.end method

.method public isInBackStack(Lcom/facebook/aura/navigation/AuraNavKey;)Z
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->$$delegate_0:Lcom/facebook/aura/assist/NoOpAssistNavigator;

    .line 268435461
    .line 268435462
    invoke-virtual {v0, p1}, Lcom/facebook/aura/assist/NoOpAssistNavigator;->isInBackStack(Lcom/facebook/aura/navigation/AuraNavKey;)Z

    .line 268435463
    .line 268435464
    .line 268435465
    move-result v0

    .line 268435466
    return v0
.end method

.method public navigate(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/navigation/LaunchFlag;)V
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->routeOrIgnore(Lcom/facebook/aura/navigation/AuraNavKey;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method

.method public navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayActivity$overlayNavigator$1;->routeOrIgnore(Lcom/facebook/aura/navigation/AuraNavKey;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public navigateWithContext(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/analytics/hatch/HatchClickPoint;Lcom/facebook/aura/analytics/hatch/HatchEventSubtype;Lcom/facebook/aura/navigation/LaunchFlag;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p4}, LX/3Rq;->A1S(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public popAll(LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public popAll(Ljava/util/Collection;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    return-void
.end method

.method public popLast(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public popTabSubstack(Lcom/facebook/aura/navigation/AuraTabRootNavKey;Lcom/facebook/aura/navigation/AuraTabRootNavKey;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public popToRoot()V
    .locals 0

    .line 0
    return-void
.end method

.method public popToTabRoot(Lcom/facebook/aura/navigation/AuraTabRootNavKey;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public reconcileTabs(Ljava/util/Set;LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+",
            "Lcom/facebook/aura/navigation/AuraTabRootNavKey;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/AuraTabRootNavKey;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public removeBeforeBackStackChangeListener(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
