.class public final Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2$1;->this$0:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 268435457
    .line 268435458
    iget-object v2, v0, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->_overlayState:LX/2J2;

    .line 268435459
    .line 268435460
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v3

    .line 268435464
    move-object v4, v3

    .line 268435465
    check-cast v4, Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435466
    .line 268435467
    iget-object v1, v4, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435468
    .line 268435469
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->LISTENING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435470
    .line 268435471
    if-eq v1, v0, :cond_4

    .line 268435472
    .line 268435473
    iget-object v0, v4, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435474
    .line 268435475
    sget-object p0, Lcom/facebook/aura/assist/AssistOverlayPhase;->ERROR:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435476
    .line 268435477
    if-eq v0, p0, :cond_7

    .line 268435478
    .line 268435479
    iget-boolean v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->isAwaitingResponse:Z

    .line 268435480
    .line 268435481
    iget-object v1, v4, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435482
    .line 268435483
    if-eqz v0, :cond_5

    .line 268435484
    .line 268435485
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->SUBMITTING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435486
    .line 268435487
    if-eq v1, v0, :cond_1

    .line 268435488
    .line 268435489
    iget-object v1, v4, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435490
    .line 268435491
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435492
    .line 268435493
    if-ne v1, v0, :cond_6

    .line 268435494
    .line 268435495
    :cond_1
    sget-object v5, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435496
    .line 268435497
    :goto_0
    const/4 v1, 0x0

    .line 268435498
    if-ne v5, p0, :cond_3

    .line 268435499
    .line 268435500
    :goto_1
    iget-object v1, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->connectionState:Lcom/facebook/aura/gateway/HatchGatewayConnectionState;

    .line 268435501
    .line 268435502
    instance-of v0, v1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;

    .line 268435503
    .line 268435504
    if-eqz v0, :cond_2

    .line 268435505
    .line 268435506
    check-cast v1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;

    .line 268435507
    .line 268435508
    if-eqz v1, :cond_2

    .line 268435509
    .line 268435510
    iget-object v1, v1, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;->message:Ljava/lang/String;

    .line 268435511
    .line 268435512
    if-nez v1, :cond_3

    .line 268435513
    .line 268435514
    :cond_2
    iget-object v1, v4, Lcom/facebook/aura/assist/AssistOverlayState;->errorMessage:Ljava/lang/String;

    .line 268435515
    .line 268435516
    :cond_3
    iget-object v0, v4, Lcom/facebook/aura/assist/AssistOverlayState;->mode:Lcom/facebook/aura/assist/AssistOverlayMode;

    .line 268435517
    .line 268435518
    invoke-virtual {v4, v0, v5, v1}, Lcom/facebook/aura/assist/AssistOverlayState;->copy(Lcom/facebook/aura/assist/AssistOverlayMode;Lcom/facebook/aura/assist/AssistOverlayPhase;Ljava/lang/String;)Lcom/facebook/aura/assist/AssistOverlayState;

    .line 268435519
    .line 268435520
    .line 268435521
    move-result-object v0

    .line 268435522
    invoke-interface {v2, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435523
    .line 268435524
    .line 268435525
    move-result v0

    .line 268435526
    if-eqz v0, :cond_0

    .line 268435527
    .line 268435528
    :cond_4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435529
    .line 268435530
    return-object v0

    .line 268435531
    :cond_5
    sget-object v0, Lcom/facebook/aura/assist/AssistOverlayPhase;->RESPONDING:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435532
    .line 268435533
    if-ne v1, v0, :cond_6

    .line 268435534
    .line 268435535
    sget-object v5, Lcom/facebook/aura/assist/AssistOverlayPhase;->IDLE:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435536
    .line 268435537
    goto :goto_0

    .line 268435538
    :cond_6
    iget-object v0, p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;->connectionState:Lcom/facebook/aura/gateway/HatchGatewayConnectionState;

    .line 268435539
    .line 268435540
    instance-of v0, v0, Lcom/facebook/aura/gateway/HatchGatewayConnectionState$Error;

    .line 268435541
    .line 268435542
    if-eqz v0, :cond_7

    .line 268435543
    .line 268435544
    move-object v5, p0

    .line 268435545
    goto :goto_1

    .line 268435546
    :cond_7
    iget-object v5, v4, Lcom/facebook/aura/assist/AssistOverlayState;->phase:Lcom/facebook/aura/assist/AssistOverlayPhase;

    .line 268435547
    .line 268435548
    goto :goto_0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel$2$1;->emit(Lcom/facebook/aura/conversation/viewmodel/HatchConversationUiState;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
