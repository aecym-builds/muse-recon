.class public final Lcom/facebook/aura/assist/AssistVoicePresentation;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final capturedBottomInset$delegate:LX/CR1;

.field public final composerBounds$delegate:Landroidx/compose/runtime/MutableState;

.field public final identityBounds$delegate:Landroidx/compose/runtime/MutableState;

.field public final inputBottomInset$delegate:LX/CR1;

.field public final progress:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final transition:LX/DwH;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DwH<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DwH;LX/16A;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DwH<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->progress:LX/16A;

    .line 10
    .line 11
    sget-object v2, LX/36Z;->A04:LX/36Z;

    .line 12
    .line 13
    invoke-static {}, LX/JAr;->A01()LX/DxF;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {v1, v2}, LX/001;->A0U(LX/DxE;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->identityBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 22
    .line 23
    invoke-static {v1, v2}, LX/001;->A0U(LX/DxE;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->composerBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 28
    .line 29
    new-instance v0, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 30
    .line 31
    invoke-direct {v0, v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;-><init>(I)V

    .line 32
    .line 33
    .line 34
    iput-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->inputBottomInset$delegate:LX/CR1;

    .line 35
    .line 36
    new-instance v0, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 37
    .line 38
    invoke-direct {v0, v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;-><init>(I)V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->capturedBottomInset$delegate:LX/CR1;

    .line 42
    .line 43
    return-void
.end method


# virtual methods
.method public final captureComposer()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->inputBottomInset$delegate:LX/CR1;

    .line 1
    .line 2
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, v0}, Lcom/facebook/aura/assist/AssistVoicePresentation;->setCapturedBottomInset(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final getCapturedBottomInset()I
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->capturedBottomInset$delegate:LX/CR1;

    .line 1
    .line 2
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public final getComposerBounds()LX/36Z;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->composerBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {p0}, LX/602;->A09(Landroidx/compose/runtime/MutableState;)LX/36Z;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public final getIdentityBounds()LX/36Z;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->identityBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {p0}, LX/602;->A09(Landroidx/compose/runtime/MutableState;)LX/36Z;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public final getInputBottomInset()I
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->inputBottomInset$delegate:LX/CR1;

    .line 1
    .line 2
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public final getProgress()LX/16A;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->progress:LX/16A;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShowingVoice()Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 1
    .line 2
    invoke-static {v0}, LX/602;->A0Y(LX/DwH;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 13
    .line 14
    invoke-static {v0}, LX/602;->A0X(LX/DwH;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    const/4 v0, 0x0

    .line 23
    if-eqz p0, :cond_1

    .line 24
    .line 25
    :cond_0
    const/4 v0, 0x1

    .line 26
    :cond_1
    return v0
.end method

.method public final getTransition()LX/DwH;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/DwH<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isVoice()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->transition:LX/DwH;

    .line 1
    .line 2
    invoke-static {p0}, LX/602;->A0X(LX/DwH;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final setCapturedBottomInset(I)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->capturedBottomInset$delegate:LX/CR1;

    .line 1
    .line 2
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final setComposerBounds(LX/36Z;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->composerBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final setIdentityBounds(LX/36Z;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->identityBounds$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final setInputBottomInset(I)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/AssistVoicePresentation;->inputBottomInset$delegate:LX/CR1;

    .line 1
    .line 2
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
