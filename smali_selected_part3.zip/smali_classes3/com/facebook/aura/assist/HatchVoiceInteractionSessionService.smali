.class public final Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;
.super Landroid/service/voice/VoiceInteractionSessionService;
.source ""


# static fields
.field public static final $stable:I = 0x8


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/service/voice/VoiceInteractionSessionService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onNewSession(Landroid/os/Bundle;)Landroid/service/voice/VoiceInteractionSession;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;

    .line 1
    .line 2
    invoke-direct {v0, p0}, Lcom/facebook/aura/assist/HatchVoiceInteractionSession;-><init>(Lcom/facebook/aura/assist/HatchVoiceInteractionSessionService;)V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method
