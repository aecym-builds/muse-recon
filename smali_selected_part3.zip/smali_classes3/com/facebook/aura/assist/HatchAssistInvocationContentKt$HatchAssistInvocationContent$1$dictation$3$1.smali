.class public final Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $onRequestPermission:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;",
            "LX/JDN<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$onRequestPermission:LX/JDN;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->invoke(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    const-string v4, "android.permission.RECORD_AUDIO"

    .line 5
    .line 6
    invoke-virtual {v1, v0, v4}, Lcom/facebook/aura/utils/HatchPermissionUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$context:Landroid/content/Context;

    .line 15
    .line 16
    invoke-virtual {v1, v0, p1}, Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;->onMicClick(Landroid/content/Context;Z)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    iget-object v3, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$onRequestPermission:LX/JDN;

    .line 21
    .line 22
    iget-object v2, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$overlayViewModel:Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;

    .line 23
    .line 24
    iget-object v1, p0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1;->$context:Landroid/content/Context;

    .line 25
    .line 26
    new-instance v0, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;

    .line 27
    .line 28
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/assist/HatchAssistInvocationContentKt$HatchAssistInvocationContent$1$dictation$3$1$1;-><init>(Lcom/facebook/aura/assist/HatchAssistOverlayViewModel;Landroid/content/Context;)V

    .line 29
    .line 30
    .line 31
    invoke-interface {v3, v4, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    return-void
.end method
