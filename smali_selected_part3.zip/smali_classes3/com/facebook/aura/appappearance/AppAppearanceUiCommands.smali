.class public final Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/uicontrol/UiCommandContributor;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;

.field public static final specs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/nodes/core/NodeCommandSpec;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->INSTANCE:Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/nodes/core/NodeArgType;->STRING:Lcom/facebook/aura/nodes/core/NodeArgType;

    .line 8
    .line 9
    const-string v0, "\"light\", \"dark\", or \"automatic\" to follow the device setting."

    .line 10
    .line 11
    new-instance v1, Lcom/facebook/aura/nodes/core/NodeArgSpec;

    .line 12
    .line 13
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/nodes/core/NodeArgSpec;-><init>(Lcom/facebook/aura/nodes/core/NodeArgType;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "appearance_mode"

    .line 17
    .line 18
    invoke-static {v0, v1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    const-string v2, "Switch the whole app between light and dark mode, or Automatic to follow the device (Settings > Appearance > Mode). Use this for \"dark mode\" or \"light mode\" requests; chat_theme only changes chat bubble colors."

    .line 23
    .line 24
    const-string v1, "Confirmation that the app\'s light or dark mode changed."

    .line 25
    .line 26
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v2, v1, v3, v0}, LX/603;->A0b(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/facebook/aura/nodes/core/NodeCommandSpec;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v0, "ui.set.appearance.mode"

    .line 35
    .line 36
    invoke-static {v0, v1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sput-object v0, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->specs:Ljava/util/Map;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final appearanceModeValue(Lkotlinx/serialization/json/JsonObject;)Ljava/lang/Integer;
    .locals 1

    .line 0
    const-string v0, "appearance_mode"

    .line 1
    .line 2
    invoke-static {p1, v0}, Lcom/facebook/aura/uicontrol/UiActionParserKt;->trimmedStringParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const/4 p1, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-static {v0}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    sparse-switch v0, :sswitch_data_0

    .line 18
    .line 19
    .line 20
    :cond_0
    return-object p1

    .line 21
    :sswitch_0
    const-string v0, "system"

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :sswitch_1
    const-string v0, "dark"

    .line 25
    .line 26
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    goto :goto_1

    .line 34
    :sswitch_2
    const-string v0, "light"

    .line 35
    .line 36
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    goto :goto_1

    .line 44
    :sswitch_3
    const-string v0, "automatic"

    .line 45
    .line 46
    :goto_0
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    const/4 v0, -0x1

    .line 53
    :goto_1
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    return-object p1

    .line 58
    :sswitch_data_0
    .sparse-switch
        -0x34e38dd1 -> :sswitch_0
        0x2eef76 -> :sswitch_1
        0x6233516 -> :sswitch_2
        0x63c2322b -> :sswitch_3
    .end sparse-switch
.end method


# virtual methods
.method public getSpecs()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/nodes/core/NodeCommandSpec;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->specs:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public invalidParams(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string p0, "ui.set.appearance.mode"

    .line 5
    .line 6
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    sget-object p0, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->INSTANCE:Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;

    .line 13
    .line 14
    invoke-direct {p0, p2}, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->appearanceModeValue(Lkotlinx/serialization/json/JsonObject;)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    if-nez p0, :cond_0

    .line 19
    .line 20
    const-string p0, "Pass appearance_mode \"light\", \"dark\", or \"automatic\"."

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_0
    const/4 p0, 0x0

    .line 24
    return-object p0
.end method

.method public parse(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/uicontrol/ContributedUiAction;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v0, "ui.set.appearance.mode"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-direct {p0, p2}, Lcom/facebook/aura/appappearance/AppAppearanceUiCommands;->appearanceModeValue(Lkotlinx/serialization/json/JsonObject;)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    new-instance v1, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;

    .line 24
    .line 25
    invoke-direct {v1, v0}, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;-><init>(I)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-object v1
.end method
