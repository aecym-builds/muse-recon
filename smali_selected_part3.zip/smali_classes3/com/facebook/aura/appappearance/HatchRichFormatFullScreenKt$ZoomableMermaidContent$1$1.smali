.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic $offset$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scale$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2ss;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final invoke(LX/32h;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/32h;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    new-instance v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;

    .line 5
    .line 6
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;-><init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V

    .line 7
    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object p0, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->A00:LX/JDQ;

    .line 11
    .line 12
    move-object v0, p1

    .line 13
    move-object v1, p2

    .line 14
    move-object v4, v3

    .line 15
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->A06(LX/32h;LX/2M4;LX/JDM;LX/JDM;LX/JDM;LX/JDQ;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 20
    .line 21
    if-eq v1, v0, :cond_0

    .line 22
    .line 23
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    .line 25
    :cond_0
    return-object v1
.end method
