.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

.field public final synthetic $showSource$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 29

    .line 0
    move-object/from16 v1, p3

    .line 1
    .line 2
    and-int/lit8 v0, p4, 0x6

    .line 3
    .line 4
    move/from16 v12, p1

    .line 5
    .line 6
    if-nez v0, :cond_4

    .line 7
    .line 8
    invoke-static {v1, v12}, LX/004;->A09(LX/2d4;F)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    or-int v6, p4, v0

    .line 13
    .line 14
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 15
    .line 16
    move/from16 v5, p2

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    invoke-static {v1, v5}, LX/004;->A0A(LX/2d4;F)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int/2addr v6, v0

    .line 25
    :cond_0
    and-int/lit16 v3, v6, 0x93

    .line 26
    .line 27
    const/16 v0, 0x92

    .line 28
    .line 29
    const/4 v4, 0x1

    .line 30
    const/4 v2, 0x0

    .line 31
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, v1, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_7

    .line 40
    .line 41
    move-object/from16 v7, p0

    .line 42
    .line 43
    iget-object v0, v7, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 44
    .line 45
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    const/4 v15, 0x0

    .line 50
    const/4 v6, 0x6

    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    const v0, 0x7a0ffe98

    .line 54
    .line 55
    .line 56
    invoke-static {v1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 57
    .line 58
    .line 59
    move-result-object v13

    .line 60
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 61
    .line 62
    invoke-static {v1}, LX/3J3;->A03(LX/2d4;)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    const/high16 v0, 0x41800000    # 16.0f

    .line 67
    .line 68
    invoke-static {v6, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    iget-object v14, v7, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 73
    .line 74
    invoke-static {v1}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 75
    .line 76
    .line 77
    move-result-object v11

    .line 78
    move-object v0, v1

    .line 79
    check-cast v0, LX/J7I;

    .line 80
    .line 81
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 82
    .line 83
    .line 84
    move-result v10

    .line 85
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 86
    .line 87
    .line 88
    move-result-object v9

    .line 89
    invoke-static {v1, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v8

    .line 93
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    iget-object v6, v0, LX/J7I;->A0V:LX/3DJ;

    .line 96
    .line 97
    if-eqz v6, :cond_5

    .line 98
    .line 99
    invoke-static {v1, v0, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 100
    .line 101
    .line 102
    invoke-static {v1, v11, v9, v8, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 103
    .line 104
    .line 105
    invoke-static {v1, v3, v12}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 106
    .line 107
    .line 108
    iget-object v14, v14, Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;->mermaidSource:Ljava/lang/String;

    .line 109
    .line 110
    iget-wide v6, v13, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 111
    .line 112
    sget-object v20, LX/IzA;->A01:LX/36I;

    .line 113
    .line 114
    const/16 v8, 0xd

    .line 115
    .line 116
    invoke-static {v8}, LX/2S9;->A02(I)J

    .line 117
    .line 118
    .line 119
    move-result-wide v26

    .line 120
    const/16 v8, 0x14

    .line 121
    .line 122
    invoke-static {v8}, LX/2S9;->A02(I)J

    .line 123
    .line 124
    .line 125
    move-result-wide p3

    .line 126
    sget-object v8, LX/2hg;->A03:LX/2hg;

    .line 127
    .line 128
    sget-wide v24, LX/JOw;->A07:J

    .line 129
    .line 130
    sget-wide v28, LX/2hw;->A01:J

    .line 131
    .line 132
    new-instance v18, LX/2hg;

    .line 133
    .line 134
    move-object/from16 v19, v15

    .line 135
    .line 136
    move-object/from16 v21, v15

    .line 137
    .line 138
    move/from16 v22, v2

    .line 139
    .line 140
    move/from16 v23, v2

    .line 141
    .line 142
    move-wide/from16 p1, v24

    .line 143
    .line 144
    invoke-direct/range {v18 .. v33}, LX/2hg;-><init>(LX/2SR;LX/IzA;LX/2W8;IIJJJJJ)V

    .line 145
    .line 146
    .line 147
    const/16 p3, 0x3ff2

    .line 148
    .line 149
    move-object/from16 v20, v15

    .line 150
    .line 151
    move/from16 v24, v2

    .line 152
    .line 153
    move/from16 v25, v2

    .line 154
    .line 155
    move-object/from16 v26, v15

    .line 156
    .line 157
    move-object/from16 v27, v15

    .line 158
    .line 159
    move-object/from16 v28, v15

    .line 160
    .line 161
    move-object/from16 p0, v1

    .line 162
    .line 163
    move/from16 p1, v2

    .line 164
    .line 165
    move/from16 p2, v2

    .line 166
    .line 167
    move-wide/from16 v16, v6

    .line 168
    .line 169
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 170
    .line 171
    .line 172
    invoke-static {v1, v0, v3, v5, v4}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 173
    .line 174
    .line 175
    :goto_1
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :cond_1
    const v0, 0x7a18ca55

    .line 180
    .line 181
    .line 182
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 183
    .line 184
    .line 185
    invoke-static {v1, v2}, Lcom/facebook/aura/conversation/view/richcontent/HatchMermaidContentKt;->rememberMermaidThemeColors(LX/2d4;I)Lcom/facebook/aura/conversation/view/richcontent/MermaidThemeColors;

    .line 186
    .line 187
    .line 188
    move-result-object v5

    .line 189
    iget-object v0, v7, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 190
    .line 191
    iget-object v3, v0, Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;->mermaidSource:Ljava/lang/String;

    .line 192
    .line 193
    sget v0, Lcom/facebook/aura/conversation/view/richcontent/MermaidThemeColors;->$stable:I

    .line 194
    .line 195
    shl-int/lit8 v0, v0, 0x3

    .line 196
    .line 197
    invoke-static {v3, v5, v1, v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchMermaidContentKt;->rememberMermaidRenderResult(Ljava/lang/String;Lcom/facebook/aura/conversation/view/richcontent/MermaidThemeColors;LX/2d4;I)Lcom/facebook/aura/conversation/view/richcontent/MermaidSvgRenderer$RenderResult;

    .line 198
    .line 199
    .line 200
    move-result-object v3

    .line 201
    if-nez v3, :cond_2

    .line 202
    .line 203
    const v0, 0x7a1cc2ea

    .line 204
    .line 205
    .line 206
    invoke-static {v1, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 207
    .line 208
    .line 209
    move-result-object v10

    .line 210
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 211
    .line 212
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 213
    .line 214
    .line 215
    move-result-object v9

    .line 216
    move-object v8, v1

    .line 217
    check-cast v8, LX/J7I;

    .line 218
    .line 219
    invoke-static {v8}, LX/003;->A0F(LX/J7I;)I

    .line 220
    .line 221
    .line 222
    move-result v7

    .line 223
    invoke-static {v8}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 224
    .line 225
    .line 226
    move-result-object v6

    .line 227
    invoke-static {v1, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 228
    .line 229
    .line 230
    move-result-object v5

    .line 231
    sget-object v3, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 232
    .line 233
    iget-object v0, v8, LX/J7I;->A0V:LX/3DJ;

    .line 234
    .line 235
    if-eqz v0, :cond_5

    .line 236
    .line 237
    invoke-static {v1, v8, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 238
    .line 239
    .line 240
    invoke-static {v1, v9, v6, v5, v7}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 241
    .line 242
    .line 243
    const/high16 v0, 0x42400000    # 48.0f

    .line 244
    .line 245
    invoke-static {v1, v10, v0}, LX/604;->A0e(LX/2d4;LX/3C1;F)V

    .line 246
    .line 247
    .line 248
    invoke-static {v8, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 249
    .line 250
    .line 251
    :goto_2
    check-cast v1, LX/J7I;

    .line 252
    .line 253
    move-object v0, v1

    .line 254
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 255
    .line 256
    .line 257
    goto :goto_1

    .line 258
    :cond_2
    instance-of v0, v3, Lcom/facebook/aura/conversation/view/richcontent/MermaidSvgRenderer$RenderResult$Success;

    .line 259
    .line 260
    if-eqz v0, :cond_3

    .line 261
    .line 262
    const v0, 0x7a201b2b

    .line 263
    .line 264
    .line 265
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 266
    .line 267
    .line 268
    check-cast v3, Lcom/facebook/aura/conversation/view/richcontent/MermaidSvgRenderer$RenderResult$Success;

    .line 269
    .line 270
    iget-object v4, v3, Lcom/facebook/aura/conversation/view/richcontent/MermaidSvgRenderer$RenderResult$Success;->parsedSvg:LX/J0X;

    .line 271
    .line 272
    sget-object v3, LX/2sI;->A01:LX/2wD;

    .line 273
    .line 274
    const/16 v0, 0x30

    .line 275
    .line 276
    invoke-static {v4, v3, v1, v0, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->ZoomableMermaidContent(LX/J0X;LX/3C1;LX/2d4;II)V

    .line 277
    .line 278
    .line 279
    goto :goto_2

    .line 280
    :cond_3
    instance-of v0, v3, Lcom/facebook/aura/conversation/view/richcontent/MermaidSvgRenderer$RenderResult$Error;

    .line 281
    .line 282
    if-eqz v0, :cond_6

    .line 283
    .line 284
    const v0, 0x7a227276

    .line 285
    .line 286
    .line 287
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 288
    .line 289
    .line 290
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 291
    .line 292
    invoke-static {v0, v1, v6}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 293
    .line 294
    .line 295
    goto :goto_2

    .line 296
    :cond_4
    move/from16 v6, p4

    .line 297
    .line 298
    goto/16 :goto_0

    .line 299
    .line 300
    :cond_5
    invoke-static {}, LX/1VY;->A00()V

    .line 301
    .line 302
    .line 303
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    throw v0

    .line 308
    :cond_6
    const v0, 0x6f4b3b02

    .line 309
    .line 310
    .line 311
    invoke-static {v1, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    throw v0

    .line 316
    :cond_7
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 317
    .line 318
    .line 319
    return-void
.end method
