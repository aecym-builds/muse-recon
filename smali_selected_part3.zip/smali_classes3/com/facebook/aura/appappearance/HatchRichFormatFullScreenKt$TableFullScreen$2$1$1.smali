.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->invoke(Ljava/lang/String;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$userSession:LX/AHE;

    .line 6
    .line 7
    iget-object v2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$context:Landroid/content/Context;

    .line 8
    .line 9
    iget-object v3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    move-object p1, p0

    .line 13
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/conversation/links/HatchUrlClickHandlerKt;->handleUrlClick(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/JDN;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
