.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "Ljava/lang/Float;",
        "LX/2qg;",
        "Ljava/lang/Float;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offset$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scale$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2ss;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    invoke-static {p1}, LX/001;->A04(Ljava/lang/Object;)F

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    check-cast p2, LX/2qg;

    .line 5
    .line 6
    iget-wide v1, p2, LX/2qg;->A00:J

    .line 7
    .line 8
    invoke-static {p3}, LX/001;->A04(Ljava/lang/Object;)F

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-virtual {p0, v3, v1, v2, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->invoke-d-4ec7I(FJF)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke-d-4ec7I(FJF)V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 3
    .line 4
    .line 5
    move-result v2

    .line 6
    mul-float/2addr v2, p1

    .line 7
    const/high16 v1, 0x3f000000    # 0.5f

    .line 8
    .line 9
    const/high16 v0, 0x41000000    # 8.0f

    .line 10
    .line 11
    invoke-static {v2, v1, v0}, LX/34j;->A04(FFF)F

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    iget-object v3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 16
    .line 17
    invoke-static {v3}, LX/603;->A06(Landroidx/compose/runtime/MutableState;)J

    .line 18
    .line 19
    .line 20
    move-result-wide v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$scale$delegate:LX/2ss;

    .line 22
    .line 23
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    div-float v0, v4, v0

    .line 28
    .line 29
    invoke-static {v1, v2, v0}, LX/2qg;->A01(JF)J

    .line 30
    .line 31
    .line 32
    move-result-wide v0

    .line 33
    invoke-static {v0, v1, p2, p3}, LX/2qg;->A04(JJ)J

    .line 34
    .line 35
    .line 36
    move-result-wide v0

    .line 37
    invoke-static {v3, v0, v1}, LX/603;->A17(Landroidx/compose/runtime/MutableState;J)V

    .line 38
    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;->$scale$delegate:LX/2ss;

    .line 41
    .line 42
    invoke-interface {v0, v4}, LX/2ss;->Adw(F)V

    .line 43
    .line 44
    .line 45
    return-void
.end method
