.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2gu;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offset$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scale$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2ss;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2gu;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->invoke(LX/2gu;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2gu;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$scale$delegate:LX/2ss;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-interface {p1, v0}, LX/2gu;->Af2(F)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$scale$delegate:LX/2ss;

    .line 14
    .line 15
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-interface {p1, v0}, LX/2gu;->Af3(F)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 23
    .line 24
    invoke-static {v0}, LX/603;->A06(Landroidx/compose/runtime/MutableState;)J

    .line 25
    .line 26
    .line 27
    move-result-wide v0

    .line 28
    invoke-static {v0, v1}, LX/004;->A03(J)F

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-interface {p1, v0}, LX/2gu;->AfZ(F)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 36
    .line 37
    invoke-static {v0}, LX/603;->A06(Landroidx/compose/runtime/MutableState;)J

    .line 38
    .line 39
    .line 40
    move-result-wide v0

    .line 41
    invoke-static {v0, v1}, LX/004;->A02(J)F

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-interface {p1, v0}, LX/2gu;->Afa(F)V

    .line 46
    .line 47
    .line 48
    return-void
.end method
