.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $block:Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;

.field public final synthetic $bottomPadding:F

.field public final synthetic $theme:Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;

.field public final synthetic $topPadding:F


# direct methods
.method public constructor <init>(FFLcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$topPadding:F

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$bottomPadding:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$block:Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$theme:Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 8

    .line 268435456
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object v7, p1

    .line 268435461
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    sget-object v3, LX/2sI;->A01:LX/2wD;

    .line 268435468
    .line 268435469
    iget v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$topPadding:F

    .line 268435470
    .line 268435471
    iget v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$bottomPadding:F

    .line 268435472
    .line 268435473
    const/4 v2, 0x0

    .line 268435474
    invoke-static {v3, v2, v1, v2, v0}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 268435475
    .line 268435476
    .line 268435477
    move-result-object v1

    .line 268435478
    const/high16 v0, 0x41800000    # 16.0f

    .line 268435479
    .line 268435480
    invoke-static {v1, v0, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435481
    .line 268435482
    .line 268435483
    move-result-object v2

    .line 268435484
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$block:Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;

    .line 268435485
    .line 268435486
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;->$theme:Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;

    .line 268435487
    .line 268435488
    const p0, 0x186c00

    .line 268435489
    .line 268435490
    .line 268435491
    const/16 p1, 0x20

    .line 268435492
    .line 268435493
    const/4 v3, 0x1

    .line 268435494
    const/4 v5, 0x0

    .line 268435495
    move v4, v3

    .line 268435496
    move v6, v3

    .line 268435497
    invoke-static/range {v0 .. v9}, Lcom/facebook/aura/markdown/render/block/TableRendererKt;->TableRenderer(Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;LX/3C1;ZZIZLX/2d4;II)V

    .line 268435498
    .line 268435499
    .line 268435500
    return-void

    .line 268435501
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 268435502
    .line 268435503
    .line 268435504
    return-void
.end method
