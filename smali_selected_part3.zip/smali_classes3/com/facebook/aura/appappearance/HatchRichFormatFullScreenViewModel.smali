.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public contentViewModelData:Lcom/facebook/aura/model/HatchContentViewModelData;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getContentViewModelData()Lcom/facebook/aura/model/HatchContentViewModelData;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;->contentViewModelData:Lcom/facebook/aura/model/HatchContentViewModelData;

    .line 1
    .line 2
    return-object p0
.end method

.method public final loadIfNeeded(Ljava/lang/String;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;->contentViewModelData:Lcom/facebook/aura/model/HatchContentViewModelData;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/model/HatchContentCache;->INSTANCE:Lcom/facebook/aura/model/HatchContentCache;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Lcom/facebook/aura/model/HatchContentCache;->getAndDelete(Ljava/lang/String;)Lcom/facebook/aura/model/HatchContentViewModelData;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;->contentViewModelData:Lcom/facebook/aura/model/HatchContentViewModelData;

    .line 11
    .line 12
    :cond_0
    return-void
.end method
