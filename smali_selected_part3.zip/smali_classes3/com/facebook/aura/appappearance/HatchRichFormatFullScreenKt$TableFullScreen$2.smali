.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $data:Lcom/facebook/aura/model/HatchContentViewModelData$Table;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/model/HatchContentViewModelData$Table;LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$Table;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$userSession:LX/AHE;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 7
    .line 8
    const/4 v0, 0x4

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 14

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move v7, p1

    .line 3
    move-object/from16 p1, p3

    .line 4
    .line 5
    if-nez v0, :cond_5

    .line 6
    .line 7
    invoke-static {p1, v7}, LX/004;->A09(LX/2d4;F)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    or-int v1, p4, v0

    .line 12
    .line 13
    :goto_0
    const/16 v5, 0x30

    .line 14
    .line 15
    and-int/lit8 v0, p4, 0x30

    .line 16
    .line 17
    move/from16 v8, p2

    .line 18
    .line 19
    if-nez v0, :cond_0

    .line 20
    .line 21
    invoke-static {p1, v8}, LX/004;->A0A(LX/2d4;F)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    or-int/2addr v1, v0

    .line 26
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, p1, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_6

    .line 35
    .line 36
    move-object v2, p0

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$Table;

    .line 38
    .line 39
    iget-object v0, v0, Lcom/facebook/aura/model/HatchContentViewModelData$Table;->tableParams:Lcom/facebook/aura/model/HatchTableParamsModel;

    .line 40
    .line 41
    invoke-interface {p1, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$Table;

    .line 46
    .line 47
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 54
    .line 55
    if-ne v6, v0, :cond_2

    .line 56
    .line 57
    :cond_1
    iget-object v0, v1, Lcom/facebook/aura/model/HatchContentViewModelData$Table;->tableParams:Lcom/facebook/aura/model/HatchTableParamsModel;

    .line 58
    .line 59
    invoke-static {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchMarkdownTableCardKt;->toAuraBlockTable(Lcom/facebook/aura/model/HatchTableParamsModel;)Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    invoke-interface {p1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    :cond_2
    check-cast v6, Lcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;

    .line 67
    .line 68
    sget-object v9, Lcom/facebook/aura/markdown/render/AuraMarkdownDefaults;->INSTANCE:Lcom/facebook/aura/markdown/render/AuraMarkdownDefaults;

    .line 69
    .line 70
    const/high16 p2, 0x30000

    .line 71
    .line 72
    const/16 p3, 0x1f

    .line 73
    .line 74
    const/4 v10, 0x0

    .line 75
    const/4 p0, 0x0

    .line 76
    move-object v11, v10

    .line 77
    move-object v12, v10

    .line 78
    move-object v13, v10

    .line 79
    invoke-virtual/range {v9 .. v17}, Lcom/facebook/aura/markdown/render/AuraMarkdownDefaults;->fromAuraTheme-6p0HZu4(LX/2hg;LX/JOw;LX/2W8;LX/JOw;ZLX/2d4;II)Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;

    .line 80
    .line 81
    .line 82
    move-result-object v9

    .line 83
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$userSession:LX/AHE;

    .line 84
    .line 85
    invoke-interface {p1, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$context:Landroid/content/Context;

    .line 90
    .line 91
    invoke-static {p1, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 96
    .line 97
    invoke-static {p1, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    iget-object v4, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$userSession:LX/AHE;

    .line 102
    .line 103
    iget-object v3, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$context:Landroid/content/Context;

    .line 104
    .line 105
    iget-object v1, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 106
    .line 107
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    if-nez v0, :cond_3

    .line 112
    .line 113
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 114
    .line 115
    if-ne v2, v0, :cond_4

    .line 116
    .line 117
    :cond_3
    new-instance v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;

    .line 118
    .line 119
    invoke-direct {v2, v4, v3, v1}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$1$1;-><init>(LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 120
    .line 121
    .line 122
    invoke-interface {p1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    :cond_4
    check-cast v2, LX/JDM;

    .line 126
    .line 127
    new-instance v1, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;

    .line 128
    .line 129
    invoke-direct {v1, v7, v8, v6, v9}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2$2;-><init>(FFLcom/facebook/aura/markdown/parser/ast/AuraBlock$Table;Lcom/facebook/aura/markdown/render/AuraMarkdownTheme;)V

    .line 130
    .line 131
    .line 132
    const v0, -0x3849058a

    .line 133
    .line 134
    .line 135
    invoke-static {p1, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v2, v0, p1, v5}, Lcom/facebook/aura/conversation/view/richcontent/HatchAuraMarkdownProvidersKt;->HatchAuraMarkdownUrlHandler(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 140
    .line 141
    .line 142
    return-void

    .line 143
    :cond_5
    move/from16 v1, p4

    .line 144
    .line 145
    goto/16 :goto_0

    .line 146
    .line 147
    :cond_6
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 148
    .line 149
    .line 150
    return-void
.end method
