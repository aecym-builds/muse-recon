.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

.field public final synthetic $showSource$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 31

    .line 268435456
    move/from16 v1, p2

    .line 268435457
    .line 268435458
    and-int/lit8 v0, p2, 0x3

    .line 268435459
    .line 268435460
    const/4 v8, 0x0

    .line 268435461
    invoke-static {v0}, LX/004;->A1P(I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object/from16 v15, p1

    .line 268435466
    .line 268435467
    invoke-static {v0, v15, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    if-eqz v0, :cond_7

    .line 268435472
    .line 268435473
    move-object/from16 v2, p0

    .line 268435474
    .line 268435475
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435476
    .line 268435477
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 268435478
    .line 268435479
    .line 268435480
    move-result v0

    .line 268435481
    if-eqz v0, :cond_4

    .line 268435482
    .line 268435483
    const v0, -0x56a12f31

    .line 268435484
    .line 268435485
    .line 268435486
    invoke-interface {v15, v0}, LX/2d4;->Agj(I)V

    .line 268435487
    .line 268435488
    .line 268435489
    const v0, 0x7f080113

    .line 268435490
    .line 268435491
    .line 268435492
    invoke-static {v15, v0, v8}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 268435493
    .line 268435494
    .line 268435495
    move-result-object v4

    .line 268435496
    const v0, 0x7f1209cc

    .line 268435497
    .line 268435498
    .line 268435499
    invoke-static {v15, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435500
    .line 268435501
    .line 268435502
    move-result-object v5

    .line 268435503
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$context:Landroid/content/Context;

    .line 268435504
    .line 268435505
    invoke-interface {v15, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435506
    .line 268435507
    .line 268435508
    move-result v1

    .line 268435509
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 268435510
    .line 268435511
    invoke-static {v15, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435512
    .line 268435513
    .line 268435514
    move-result v0

    .line 268435515
    iget-object v3, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$context:Landroid/content/Context;

    .line 268435516
    .line 268435517
    iget-object v1, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 268435518
    .line 268435519
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435520
    .line 268435521
    .line 268435522
    move-result-object v6

    .line 268435523
    if-nez v0, :cond_0

    .line 268435524
    .line 268435525
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435526
    .line 268435527
    if-ne v6, v0, :cond_1

    .line 268435528
    .line 268435529
    :cond_0
    new-instance v6, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;

    .line 268435530
    .line 268435531
    invoke-direct {v6, v3, v1}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;-><init>(Landroid/content/Context;Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;)V

    .line 268435532
    .line 268435533
    .line 268435534
    invoke-interface {v15, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435535
    .line 268435536
    .line 268435537
    :cond_1
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 268435538
    .line 268435539
    sget v16, LX/2l9;->$stable:I

    .line 268435540
    .line 268435541
    const/16 v18, 0x7f8

    .line 268435542
    .line 268435543
    const/4 v7, 0x0

    .line 268435544
    const/4 v9, 0x0

    .line 268435545
    const/16 v22, 0x0

    .line 268435546
    .line 268435547
    move-object v10, v7

    .line 268435548
    move-object v11, v7

    .line 268435549
    move-object v12, v7

    .line 268435550
    move v13, v8

    .line 268435551
    move v14, v8

    .line 268435552
    move/from16 v17, v8

    .line 268435553
    .line 268435554
    invoke-static/range {v4 .. v18}, Lcom/facebook/aura/vds/compose/button/AuraElevatedButtonKt;->AuraElevatedIconButton-Xjqr6CI(LX/2l9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZFLcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;LX/3C1;ZZLX/2d4;III)V

    .line 268435555
    .line 268435556
    .line 268435557
    const v0, 0x7f0800ae

    .line 268435558
    .line 268435559
    .line 268435560
    invoke-static {v15, v0, v8}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 268435561
    .line 268435562
    .line 268435563
    move-result-object v19

    .line 268435564
    const v0, 0x7f1212a6

    .line 268435565
    .line 268435566
    .line 268435567
    invoke-static {v15, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435568
    .line 268435569
    .line 268435570
    move-result-object v20

    .line 268435571
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435572
    .line 268435573
    invoke-interface {v15, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435574
    .line 268435575
    .line 268435576
    move-result v1

    .line 268435577
    iget-object v2, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435578
    .line 268435579
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435580
    .line 268435581
    .line 268435582
    move-result-object v0

    .line 268435583
    if-nez v1, :cond_2

    .line 268435584
    .line 268435585
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435586
    .line 268435587
    if-ne v0, v1, :cond_3

    .line 268435588
    .line 268435589
    :cond_2
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$2$1;

    .line 268435590
    .line 268435591
    invoke-direct {v0, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 268435592
    .line 268435593
    .line 268435594
    invoke-interface {v15, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435595
    .line 268435596
    .line 268435597
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435598
    .line 268435599
    move-object/from16 v21, v0

    .line 268435600
    .line 268435601
    move/from16 v23, v8

    .line 268435602
    .line 268435603
    move/from16 v24, v9

    .line 268435604
    .line 268435605
    move-object/from16 v25, v7

    .line 268435606
    .line 268435607
    move-object/from16 v26, v7

    .line 268435608
    .line 268435609
    move-object/from16 v27, v7

    .line 268435610
    .line 268435611
    move/from16 v28, v8

    .line 268435612
    .line 268435613
    move/from16 v29, v8

    .line 268435614
    .line 268435615
    move-object/from16 v30, v15

    .line 268435616
    .line 268435617
    move/from16 p0, v16

    .line 268435618
    .line 268435619
    move/from16 p1, v8

    .line 268435620
    .line 268435621
    move/from16 p2, v18

    .line 268435622
    .line 268435623
    invoke-static/range {v19 .. v33}, Lcom/facebook/aura/vds/compose/button/AuraElevatedButtonKt;->AuraElevatedIconButton-Xjqr6CI(LX/2l9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZFLcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;LX/3C1;ZZLX/2d4;III)V

    .line 268435624
    .line 268435625
    .line 268435626
    :goto_0
    invoke-static {v15}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 268435627
    .line 268435628
    .line 268435629
    return-void

    .line 268435630
    :cond_4
    const v0, -0x56967b53

    .line 268435631
    .line 268435632
    .line 268435633
    invoke-interface {v15, v0}, LX/2d4;->Agj(I)V

    .line 268435634
    .line 268435635
    .line 268435636
    const v0, 0x7f0800ad

    .line 268435637
    .line 268435638
    .line 268435639
    invoke-static {v15, v0, v8}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 268435640
    .line 268435641
    .line 268435642
    move-result-object v4

    .line 268435643
    const v0, 0x7f1212a7

    .line 268435644
    .line 268435645
    .line 268435646
    invoke-static {v15, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435647
    .line 268435648
    .line 268435649
    move-result-object v3

    .line 268435650
    iget-object v0, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435651
    .line 268435652
    invoke-interface {v15, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435653
    .line 268435654
    .line 268435655
    move-result v1

    .line 268435656
    iget-object v2, v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;->$showSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 268435657
    .line 268435658
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435659
    .line 268435660
    .line 268435661
    move-result-object v0

    .line 268435662
    if-nez v1, :cond_5

    .line 268435663
    .line 268435664
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435665
    .line 268435666
    if-ne v0, v1, :cond_6

    .line 268435667
    .line 268435668
    :cond_5
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$3$1;

    .line 268435669
    .line 268435670
    invoke-direct {v0, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$3$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 268435671
    .line 268435672
    .line 268435673
    invoke-interface {v15, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435674
    .line 268435675
    .line 268435676
    :cond_6
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435677
    .line 268435678
    invoke-static {v15, v4, v3, v0}, LX/2l9;->A09(LX/2d4;LX/2l9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 268435679
    .line 268435680
    .line 268435681
    goto :goto_0

    .line 268435682
    :cond_7
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 268435683
    .line 268435684
    .line 268435685
    return-void
.end method
