.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const-string v0, "clipboard"

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    instance-of v0, v2, Landroid/content/ClipboardManager;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    check-cast v2, Landroid/content/ClipboardManager;

    .line 13
    .line 14
    if-eqz v2, :cond_0

    .line 15
    .line 16
    const-string v1, "mermaid source"

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2$1$1;->$data:Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 19
    .line 20
    iget-object v0, v0, Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;->mermaidSource:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v1, v0}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v2, v0}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method
