.class public abstract Lcom/facebook/aura/appappearance/AppAppearanceUiCommandsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final APPEARANCE_MODE_PARAM:Ljava/lang/String; = "appearance_mode"

.field public static final UI_SET_APPEARANCE_MODE:Ljava/lang/String; = "ui.set.appearance.mode"
