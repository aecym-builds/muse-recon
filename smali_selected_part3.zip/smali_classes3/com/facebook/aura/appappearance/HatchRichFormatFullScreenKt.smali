.class public abstract Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final MAX_ZOOM:F = 8.0f

.field public static final MIN_ZOOM:F = 0.5f


# direct methods
.method public static final CodeFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Code;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/model/HatchContentViewModelData$Code;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, 0x1731972

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v3, p3

    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v2, p0

    .line 13
    .line 14
    if-nez v0, :cond_6

    .line 15
    .line 16
    invoke-static {v1, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    or-int v6, v6, p3

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 23
    .line 24
    move-object/from16 v4, p1

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-static {v1, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    or-int/2addr v6, v0

    .line 33
    :cond_0
    and-int/lit8 v5, v6, 0x13

    .line 34
    .line 35
    const/16 v0, 0x12

    .line 36
    .line 37
    const/16 v18, 0x0

    .line 38
    .line 39
    const/4 v8, 0x1

    .line 40
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {v0, v1, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_5

    .line 49
    .line 50
    invoke-static {v1}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 55
    .line 56
    sget-object v11, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Immersive:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 57
    .line 58
    invoke-static {v1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iget-wide v12, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 63
    .line 64
    iget-object v0, v2, Lcom/facebook/aura/model/HatchContentViewModelData$Code;->codeParams:Lcom/facebook/aura/model/HatchCodeParams;

    .line 65
    .line 66
    iget-object v14, v0, Lcom/facebook/aura/model/HatchCodeParams;->language:Ljava/lang/String;

    .line 67
    .line 68
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-lez v0, :cond_1

    .line 73
    .line 74
    invoke-static {v14}, LX/005;->A0n(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-virtual {v14, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-static {v0, v5}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v14

    .line 86
    :cond_1
    sget-object v17, Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;->START:Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;

    .line 87
    .line 88
    const v20, 0x7f0802e9

    .line 89
    .line 90
    .line 91
    invoke-static {v6}, LX/004;->A1S(I)Z

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-nez v5, :cond_2

    .line 100
    .line 101
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 102
    .line 103
    if-ne v0, v5, :cond_3

    .line 104
    .line 105
    :cond_2
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$2$1;

    .line 106
    .line 107
    invoke-direct {v0, v4}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$2$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 108
    .line 109
    .line 110
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 114
    .line 115
    new-instance v6, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$3;

    .line 116
    .line 117
    invoke-direct {v6, v7, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$3;-><init>(Landroid/content/Context;Lcom/facebook/aura/model/HatchContentViewModelData$Code;)V

    .line 118
    .line 119
    .line 120
    const v5, 0x44cfcf7f

    .line 121
    .line 122
    .line 123
    invoke-static {v1, v6, v5}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 124
    .line 125
    .line 126
    move-result-object v26

    .line 127
    new-instance v6, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$4;

    .line 128
    .line 129
    invoke-direct {v6, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$4;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$Code;)V

    .line 130
    .line 131
    .line 132
    const v5, -0x12c36209

    .line 133
    .line 134
    .line 135
    invoke-static {v1, v6, v5}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 136
    .line 137
    .line 138
    move-result-object v41

    .line 139
    const/high16 p2, 0x36000000

    .line 140
    .line 141
    const p3, 0xffefb22

    .line 142
    .line 143
    .line 144
    const/4 v10, 0x0

    .line 145
    const-wide/16 v27, 0x0

    .line 146
    .line 147
    const/16 v32, 0x0

    .line 148
    .line 149
    const p0, 0xc00186

    .line 150
    .line 151
    .line 152
    const/high16 p1, 0x180000

    .line 153
    .line 154
    move-object v15, v10

    .line 155
    move/from16 v19, v18

    .line 156
    .line 157
    move-object/from16 v21, v10

    .line 158
    .line 159
    move-object/from16 v22, v10

    .line 160
    .line 161
    move-object/from16 v23, v10

    .line 162
    .line 163
    move-object/from16 v24, v10

    .line 164
    .line 165
    move-object/from16 v25, v10

    .line 166
    .line 167
    move-wide/from16 v29, v27

    .line 168
    .line 169
    move-object/from16 v31, v10

    .line 170
    .line 171
    move-object/from16 v33, v10

    .line 172
    .line 173
    move-object/from16 v34, v10

    .line 174
    .line 175
    move-object/from16 v35, v10

    .line 176
    .line 177
    move/from16 v36, v18

    .line 178
    .line 179
    move-object/from16 v37, v10

    .line 180
    .line 181
    move-object/from16 v38, v10

    .line 182
    .line 183
    move-object/from16 v39, v10

    .line 184
    .line 185
    move/from16 v40, v18

    .line 186
    .line 187
    move-object/from16 v42, v1

    .line 188
    .line 189
    move-object/from16 v16, v0

    .line 190
    .line 191
    invoke-static/range {v9 .. v46}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 192
    .line 193
    .line 194
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    if-eqz v1, :cond_4

    .line 199
    .line 200
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$5;

    .line 201
    .line 202
    invoke-direct {v0, v2, v4, v3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$CodeFullScreen$5;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$Code;Lkotlin/jvm/functions/Function0;I)V

    .line 203
    .line 204
    .line 205
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 206
    .line 207
    :cond_4
    return-void

    .line 208
    :cond_5
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 209
    .line 210
    .line 211
    goto :goto_1

    .line 212
    :cond_6
    move v6, v3

    .line 213
    goto/16 :goto_0
.end method

.method public static final HatchRichFormatFullScreen(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const v0, -0x6f8f1ae8

    .line 5
    .line 6
    .line 7
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    if-nez v0, :cond_a

    .line 13
    .line 14
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v6

    .line 18
    or-int/2addr v6, p3

    .line 19
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 20
    .line 21
    const/16 v5, 0x20

    .line 22
    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    invoke-static {p2, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    or-int/2addr v6, v0

    .line 30
    :cond_0
    and-int/lit8 v1, v6, 0x13

    .line 31
    .line 32
    const/16 v0, 0x12

    .line 33
    .line 34
    const/4 v7, 0x1

    .line 35
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0, p2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_9

    .line 44
    .line 45
    invoke-static {p2}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    if-eqz v2, :cond_b

    .line 50
    .line 51
    invoke-static {v2}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-class v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;

    .line 56
    .line 57
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    const/4 v4, 0x0

    .line 62
    invoke-static {v4, v2, v1, v4, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;

    .line 67
    .line 68
    invoke-virtual {v0, p0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;->loadIfNeeded(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    iget-object v3, v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenViewModel;->contentViewModelData:Lcom/facebook/aura/model/HatchContentViewModelData;

    .line 72
    .line 73
    invoke-interface {p2, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    and-int/lit8 v2, v6, 0x70

    .line 78
    .line 79
    if-eq v2, v5, :cond_1

    .line 80
    .line 81
    const/4 v7, 0x0

    .line 82
    :cond_1
    or-int/2addr v1, v7

    .line 83
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    if-nez v1, :cond_2

    .line 88
    .line 89
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 90
    .line 91
    if-ne v0, v1, :cond_3

    .line 92
    .line 93
    :cond_2
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$HatchRichFormatFullScreen$1$1;

    .line 94
    .line 95
    invoke-direct {v0, v3, p1, v4}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$HatchRichFormatFullScreen$1$1;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 96
    .line 97
    .line 98
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :cond_3
    invoke-static {p2, v0, v3}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    if-eqz v3, :cond_8

    .line 105
    .line 106
    const v0, -0x3e43800f

    .line 107
    .line 108
    .line 109
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 110
    .line 111
    .line 112
    instance-of v0, v3, Lcom/facebook/aura/model/HatchContentViewModelData$Code;

    .line 113
    .line 114
    if-eqz v0, :cond_5

    .line 115
    .line 116
    const v0, -0x3e428e3c

    .line 117
    .line 118
    .line 119
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 120
    .line 121
    .line 122
    check-cast v3, Lcom/facebook/aura/model/HatchContentViewModelData$Code;

    .line 123
    .line 124
    invoke-static {v3, p1, p2, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->CodeFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Code;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 125
    .line 126
    .line 127
    :goto_1
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :goto_2
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :goto_3
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    if-eqz v1, :cond_4

    .line 138
    .line 139
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$HatchRichFormatFullScreen$2;

    .line 140
    .line 141
    invoke-direct {v0, p0, p1, p3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$HatchRichFormatFullScreen$2;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;I)V

    .line 142
    .line 143
    .line 144
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 145
    .line 146
    :cond_4
    return-void

    .line 147
    :cond_5
    instance-of v0, v3, Lcom/facebook/aura/model/HatchContentViewModelData$Table;

    .line 148
    .line 149
    if-eqz v0, :cond_6

    .line 150
    .line 151
    const v0, -0x3e40d07d

    .line 152
    .line 153
    .line 154
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 155
    .line 156
    .line 157
    check-cast v3, Lcom/facebook/aura/model/HatchContentViewModelData$Table;

    .line 158
    .line 159
    invoke-static {v3, p1, p2, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->TableFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Table;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 160
    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_6
    instance-of v0, v3, Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 164
    .line 165
    if-eqz v0, :cond_7

    .line 166
    .line 167
    const v0, -0x3e3eebdf

    .line 168
    .line 169
    .line 170
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 171
    .line 172
    .line 173
    check-cast v3, Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;

    .line 174
    .line 175
    invoke-static {v3, p1, p2, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->MermaidFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 176
    .line 177
    .line 178
    goto :goto_1

    .line 179
    :cond_7
    const v0, -0x3e3d9f78

    .line 180
    .line 181
    .line 182
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 183
    .line 184
    .line 185
    goto :goto_1

    .line 186
    :cond_8
    const v0, -0x3e3d7136

    .line 187
    .line 188
    .line 189
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 190
    .line 191
    .line 192
    goto :goto_2

    .line 193
    :cond_9
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 194
    .line 195
    .line 196
    goto :goto_3

    .line 197
    :cond_a
    move v6, p3

    .line 198
    goto/16 :goto_0

    .line 199
    .line 200
    :cond_b
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    throw v0
.end method

.method public static final MermaidFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v1, -0x723fa98b

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p3

    .line 9
    .line 10
    and-int/lit8 v1, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v3, p0

    .line 13
    .line 14
    if-nez v1, :cond_6

    .line 15
    .line 16
    invoke-static {v0, v3}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    or-int v6, v6, p3

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v1, p3, 0x30

    .line 23
    .line 24
    move-object/from16 v4, p1

    .line 25
    .line 26
    if-nez v1, :cond_0

    .line 27
    .line 28
    invoke-static {v0, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    or-int/2addr v6, v1

    .line 33
    :cond_0
    and-int/lit8 v7, v6, 0x13

    .line 34
    .line 35
    const/16 v1, 0x12

    .line 36
    .line 37
    const/4 v5, 0x0

    .line 38
    invoke-static {v7, v1}, LX/003;->A1H(II)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-static {v1, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_5

    .line 47
    .line 48
    invoke-static {v0}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 49
    .line 50
    .line 51
    move-result-object v9

    .line 52
    new-array v8, v5, [Ljava/lang/Object;

    .line 53
    .line 54
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 59
    .line 60
    if-ne v1, v7, :cond_1

    .line 61
    .line 62
    sget-object v1, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$showSource$2$1;->INSTANCE:Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$showSource$2$1;

    .line 63
    .line 64
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :cond_1
    invoke-static {v0, v1, v8}, LX/39E;->A01(LX/2d4;Ljava/lang/Object;[Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 72
    .line 73
    sget-object v12, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Immersive:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 74
    .line 75
    invoke-static {v0}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    iget-wide v13, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 80
    .line 81
    const v21, 0x7f0802e9

    .line 82
    .line 83
    .line 84
    sget-object v18, Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;->HIDDEN:Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;

    .line 85
    .line 86
    invoke-static {v6}, LX/006;->A1W(I)Z

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    if-nez v6, :cond_2

    .line 95
    .line 96
    if-ne v1, v7, :cond_3

    .line 97
    .line 98
    :cond_2
    new-instance v1, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;

    .line 99
    .line 100
    invoke-direct {v1, v4}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 101
    .line 102
    .line 103
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    :cond_3
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 107
    .line 108
    new-instance v7, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;

    .line 109
    .line 110
    invoke-direct {v7, v9, v3, v8}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$2;-><init>(Landroid/content/Context;Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Landroidx/compose/runtime/MutableState;)V

    .line 111
    .line 112
    .line 113
    const v6, -0x3a816278

    .line 114
    .line 115
    .line 116
    invoke-static {v0, v7, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 117
    .line 118
    .line 119
    move-result-object v27

    .line 120
    new-instance v7, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;

    .line 121
    .line 122
    invoke-direct {v7, v3, v8}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$3;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Landroidx/compose/runtime/MutableState;)V

    .line 123
    .line 124
    .line 125
    const v6, -0x7b38edf0

    .line 126
    .line 127
    .line 128
    invoke-static {v0, v7, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 129
    .line 130
    .line 131
    move-result-object v42

    .line 132
    const/high16 p2, 0x36000000

    .line 133
    .line 134
    const p3, 0xffefb32

    .line 135
    .line 136
    .line 137
    const/4 v11, 0x0

    .line 138
    const-wide/16 v28, 0x0

    .line 139
    .line 140
    const/16 v33, 0x0

    .line 141
    .line 142
    const p0, 0xc00186

    .line 143
    .line 144
    .line 145
    const/high16 p1, 0x180000

    .line 146
    .line 147
    move-object v15, v11

    .line 148
    move-object/from16 v16, v11

    .line 149
    .line 150
    move/from16 v20, v5

    .line 151
    .line 152
    move-object/from16 v22, v11

    .line 153
    .line 154
    move-object/from16 v23, v11

    .line 155
    .line 156
    move-object/from16 v24, v11

    .line 157
    .line 158
    move-object/from16 v25, v11

    .line 159
    .line 160
    move-object/from16 v26, v11

    .line 161
    .line 162
    move-wide/from16 v30, v28

    .line 163
    .line 164
    move-object/from16 v32, v11

    .line 165
    .line 166
    move-object/from16 v34, v11

    .line 167
    .line 168
    move-object/from16 v35, v11

    .line 169
    .line 170
    move-object/from16 v36, v11

    .line 171
    .line 172
    move/from16 v37, v5

    .line 173
    .line 174
    move-object/from16 v38, v11

    .line 175
    .line 176
    move-object/from16 v39, v11

    .line 177
    .line 178
    move-object/from16 v40, v11

    .line 179
    .line 180
    move/from16 v41, v5

    .line 181
    .line 182
    move-object/from16 v43, v0

    .line 183
    .line 184
    move-object/from16 v17, v1

    .line 185
    .line 186
    move/from16 v19, v5

    .line 187
    .line 188
    invoke-static/range {v10 .. v47}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 189
    .line 190
    .line 191
    :goto_1
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    if-eqz v1, :cond_4

    .line 196
    .line 197
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$4;

    .line 198
    .line 199
    invoke-direct {v0, v3, v4, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$4;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Lkotlin/jvm/functions/Function0;I)V

    .line 200
    .line 201
    .line 202
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 203
    .line 204
    :cond_4
    return-void

    .line 205
    :cond_5
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 206
    .line 207
    .line 208
    goto :goto_1

    .line 209
    :cond_6
    move v6, v2

    .line 210
    goto/16 :goto_0
.end method

.method public static final MermaidFullScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final MermaidFullScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final TableFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Table;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/model/HatchContentViewModelData$Table;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, -0x5b16fb50

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p3

    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v4, p0

    .line 13
    .line 14
    if-nez v0, :cond_6

    .line 15
    .line 16
    invoke-static {v1, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int v0, v0, p3

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v5, p3, 0x30

    .line 23
    .line 24
    move-object/from16 v3, p1

    .line 25
    .line 26
    if-nez v5, :cond_0

    .line 27
    .line 28
    invoke-static {v1, v3}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    or-int/2addr v0, v5

    .line 33
    :cond_0
    and-int/lit8 v6, v0, 0x13

    .line 34
    .line 35
    const/16 v5, 0x12

    .line 36
    .line 37
    const/16 v19, 0x0

    .line 38
    .line 39
    invoke-static {v6, v5}, LX/003;->A1H(II)Z

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    invoke-static {v5, v1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    if-eqz v5, :cond_5

    .line 48
    .line 49
    invoke-static {v1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 50
    .line 51
    .line 52
    move-result-object v8

    .line 53
    invoke-static {v1}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 54
    .line 55
    .line 56
    move-result-object v7

    .line 57
    invoke-static {v1}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 62
    .line 63
    sget-object v12, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Immersive:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 64
    .line 65
    invoke-static {v1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    iget-wide v13, v5, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 70
    .line 71
    const v5, 0x7f120d37

    .line 72
    .line 73
    .line 74
    invoke-static {v1, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v15

    .line 78
    sget-object v18, Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;->START:Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;

    .line 79
    .line 80
    const/4 v9, 0x0

    .line 81
    const v21, 0x7f0802e9

    .line 82
    .line 83
    .line 84
    and-int/lit8 v5, v0, 0x70

    .line 85
    .line 86
    const/16 v0, 0x20

    .line 87
    .line 88
    if-ne v5, v0, :cond_1

    .line 89
    .line 90
    const/4 v9, 0x1

    .line 91
    :cond_1
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    if-nez v9, :cond_2

    .line 96
    .line 97
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 98
    .line 99
    if-ne v0, v5, :cond_3

    .line 100
    .line 101
    :cond_2
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$1$1;

    .line 102
    .line 103
    invoke-direct {v0, v3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 104
    .line 105
    .line 106
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 110
    .line 111
    new-instance v5, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;

    .line 112
    .line 113
    invoke-direct {v5, v4, v8, v7, v6}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$2;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$Table;LX/AHE;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 114
    .line 115
    .line 116
    const v6, -0x3b9c840b

    .line 117
    .line 118
    .line 119
    invoke-static {v1, v5, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 120
    .line 121
    .line 122
    move-result-object v42

    .line 123
    const/high16 p2, 0x36000000

    .line 124
    .line 125
    const p3, 0xffffb22

    .line 126
    .line 127
    .line 128
    const/4 v11, 0x0

    .line 129
    const-wide/16 v28, 0x0

    .line 130
    .line 131
    const/16 v33, 0x0

    .line 132
    .line 133
    const p0, 0xc00186

    .line 134
    .line 135
    .line 136
    move-object/from16 v16, v11

    .line 137
    .line 138
    move/from16 v20, v19

    .line 139
    .line 140
    move-object/from16 v22, v11

    .line 141
    .line 142
    move-object/from16 v23, v11

    .line 143
    .line 144
    move-object/from16 v24, v11

    .line 145
    .line 146
    move-object/from16 v25, v11

    .line 147
    .line 148
    move-object/from16 v26, v11

    .line 149
    .line 150
    move-object/from16 v27, v11

    .line 151
    .line 152
    move-wide/from16 v30, v28

    .line 153
    .line 154
    move-object/from16 v32, v11

    .line 155
    .line 156
    move-object/from16 v34, v11

    .line 157
    .line 158
    move-object/from16 v35, v11

    .line 159
    .line 160
    move-object/from16 v36, v11

    .line 161
    .line 162
    move/from16 v37, v19

    .line 163
    .line 164
    move-object/from16 v38, v11

    .line 165
    .line 166
    move-object/from16 v39, v11

    .line 167
    .line 168
    move-object/from16 v40, v11

    .line 169
    .line 170
    move/from16 v41, v19

    .line 171
    .line 172
    move-object/from16 v43, v1

    .line 173
    .line 174
    move/from16 p1, v19

    .line 175
    .line 176
    move-object/from16 v17, v0

    .line 177
    .line 178
    invoke-static/range {v10 .. v47}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 179
    .line 180
    .line 181
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    if-eqz v1, :cond_4

    .line 186
    .line 187
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$3;

    .line 188
    .line 189
    invoke-direct {v0, v4, v3, v2}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$TableFullScreen$3;-><init>(Lcom/facebook/aura/model/HatchContentViewModelData$Table;Lkotlin/jvm/functions/Function0;I)V

    .line 190
    .line 191
    .line 192
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 193
    .line 194
    :cond_4
    return-void

    .line 195
    :cond_5
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 196
    .line 197
    .line 198
    goto :goto_1

    .line 199
    :cond_6
    move v0, v2

    .line 200
    goto/16 :goto_0
.end method

.method public static final ZoomableMermaidContent(LX/J0X;LX/3C1;LX/2d4;II)V
    .locals 12

    .line 0
    move-object v4, p1

    .line 1
    const v0, -0x536a39bf

    .line 2
    .line 3
    .line 4
    move-object v7, p2

    .line 5
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move v3, p3

    .line 9
    and-int/lit8 v0, p3, 0x6

    .line 10
    .line 11
    move-object v5, p0

    .line 12
    if-nez v0, :cond_9

    .line 13
    .line 14
    invoke-static {p2, p0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v10

    .line 18
    or-int/2addr v10, p3

    .line 19
    :goto_0
    and-int/lit8 v2, p4, 0x2

    .line 20
    .line 21
    if-eqz v2, :cond_8

    .line 22
    .line 23
    or-int/lit8 v10, v10, 0x30

    .line 24
    .line 25
    :cond_0
    :goto_1
    and-int/lit8 v1, v10, 0x13

    .line 26
    .line 27
    const/16 v0, 0x12

    .line 28
    .line 29
    const/4 v9, 0x0

    .line 30
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-static {v0, p2, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_c

    .line 39
    .line 40
    if-eqz v2, :cond_1

    .line 41
    .line 42
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 43
    .line 44
    :cond_1
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    sget-object p1, LX/2d6;->A00:Ljava/lang/Object;

    .line 49
    .line 50
    if-ne p0, p1, :cond_2

    .line 51
    .line 52
    const/high16 v0, 0x3f800000    # 1.0f

    .line 53
    .line 54
    new-instance p0, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 55
    .line 56
    invoke-direct {p0, v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 57
    .line 58
    .line 59
    invoke-interface {p2, p0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    :cond_2
    check-cast p0, LX/2ss;

    .line 63
    .line 64
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v11

    .line 68
    if-ne v11, p1, :cond_3

    .line 69
    .line 70
    const-wide/16 v0, 0x0

    .line 71
    .line 72
    invoke-static {v0, v1}, LX/2qg;->A06(J)LX/2qg;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-static {p2, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 77
    .line 78
    .line 79
    move-result-object v11

    .line 80
    :cond_3
    check-cast v11, Landroidx/compose/runtime/MutableState;

    .line 81
    .line 82
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    if-ne v2, p1, :cond_4

    .line 87
    .line 88
    new-instance v2, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;

    .line 89
    .line 90
    invoke-direct {v2, p0, v11}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$transformableState$1$1;-><init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V

    .line 91
    .line 92
    .line 93
    invoke-interface {p2, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    :cond_4
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    if-ne v1, p1, :cond_5

    .line 101
    .line 102
    const/4 v0, 0x1

    .line 103
    new-instance v1, LX/8mB;

    .line 104
    .line 105
    invoke-direct {v1, v2, v0}, LX/8mB;-><init>(Ljava/lang/Object;I)V

    .line 106
    .line 107
    .line 108
    invoke-interface {p2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :cond_5
    invoke-static {p2, v1}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    if-ne v6, p1, :cond_6

    .line 120
    .line 121
    new-instance v0, LX/8mB;

    .line 122
    .line 123
    invoke-direct {v0, v1, v9}, LX/8mB;-><init>(Ljava/lang/Object;I)V

    .line 124
    .line 125
    .line 126
    new-instance v6, LX/3L3;

    .line 127
    .line 128
    invoke-direct {v6, v0}, LX/3L3;-><init>(LX/JDO;)V

    .line 129
    .line 130
    .line 131
    invoke-interface {p2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    :cond_6
    check-cast v6, LX/3L6;

    .line 135
    .line 136
    invoke-static {v4}, LX/1qF;->A00(LX/3C1;)LX/3C1;

    .line 137
    .line 138
    .line 139
    move-result-object v2

    .line 140
    const/16 v0, 0x11

    .line 141
    .line 142
    new-instance v1, LX/8m4;

    .line 143
    .line 144
    invoke-direct {v1, v0}, LX/8m4;-><init>(I)V

    .line 145
    .line 146
    .line 147
    new-instance v0, LX/3L2;

    .line 148
    .line 149
    invoke-direct {v0, v6, v1}, LX/3L2;-><init>(LX/3L6;LX/JDM;)V

    .line 150
    .line 151
    .line 152
    invoke-interface {v2, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 157
    .line 158
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    if-ne v0, p1, :cond_7

    .line 163
    .line 164
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;

    .line 165
    .line 166
    invoke-direct {v0, p0, v11}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1;-><init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V

    .line 167
    .line 168
    .line 169
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    :cond_7
    check-cast v0, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 173
    .line 174
    invoke-static {v2, v0, v1}, LX/3BV;->A00(LX/3C1;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;Ljava/lang/Object;)LX/3C1;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-static {v9}, LX/001;->A0g(Z)LX/3BI;

    .line 179
    .line 180
    .line 181
    move-result-object p3

    .line 182
    move-object v8, v7

    .line 183
    check-cast v8, LX/J7I;

    .line 184
    .line 185
    invoke-static {v8}, LX/003;->A0F(LX/J7I;)I

    .line 186
    .line 187
    .line 188
    move-result p2

    .line 189
    invoke-static {v8}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    invoke-static {v7, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 194
    .line 195
    .line 196
    move-result-object v2

    .line 197
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 198
    .line 199
    iget-object v0, v8, LX/J7I;->A0V:LX/3DJ;

    .line 200
    .line 201
    if-nez v0, :cond_a

    .line 202
    .line 203
    invoke-static {}, LX/1VY;->A00()V

    .line 204
    .line 205
    .line 206
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    throw v0

    .line 211
    :cond_8
    and-int/lit8 v0, p3, 0x30

    .line 212
    .line 213
    if-nez v0, :cond_0

    .line 214
    .line 215
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    or-int/2addr v10, v0

    .line 220
    goto/16 :goto_1

    .line 221
    .line 222
    :cond_9
    move v10, p3

    .line 223
    goto/16 :goto_0

    .line 224
    .line 225
    :cond_a
    invoke-static {v7, v8, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 226
    .line 227
    .line 228
    invoke-static {v7, p3, v6, v2, p2}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 229
    .line 230
    .line 231
    sget-object v1, LX/2sI;->A01:LX/2wD;

    .line 232
    .line 233
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    if-ne v0, p1, :cond_b

    .line 238
    .line 239
    new-instance v0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;

    .line 240
    .line 241
    invoke-direct {v0, p0, v11}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$2$1$1;-><init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V

    .line 242
    .line 243
    .line 244
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_b
    invoke-static {v1, v0}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 248
    .line 249
    .line 250
    move-result-object v1

    .line 251
    and-int/lit8 v0, v10, 0xe

    .line 252
    .line 253
    or-int/lit8 v0, v0, 0x30

    .line 254
    .line 255
    invoke-static {v5, v1, v7, v0, v9}, Lcom/facebook/aura/conversation/view/richcontent/HatchMermaidContentKt;->MermaidSvgCanvas(LX/J0X;LX/3C1;LX/2d4;II)V

    .line 256
    .line 257
    .line 258
    const/4 v0, 0x1

    .line 259
    invoke-static {v8, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 260
    .line 261
    .line 262
    goto :goto_2

    .line 263
    :cond_c
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 264
    .line 265
    .line 266
    :goto_2
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 267
    .line 268
    .line 269
    move-result-object v2

    .line 270
    if-eqz v2, :cond_d

    .line 271
    .line 272
    new-instance v1, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$3;

    .line 273
    .line 274
    move/from16 v0, p4

    .line 275
    .line 276
    invoke-direct {v1, v5, v4, v3, v0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$3;-><init>(LX/J0X;LX/3C1;II)V

    .line 277
    .line 278
    .line 279
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 280
    .line 281
    :cond_d
    return-void
.end method

.method public static final ZoomableMermaidContent$lambda$1(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final ZoomableMermaidContent$lambda$2(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final ZoomableMermaidContent$lambda$4(Landroidx/compose/runtime/MutableState;)J
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;)J"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/603;->A06(Landroidx/compose/runtime/MutableState;)J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method public static final ZoomableMermaidContent$lambda$5(Landroidx/compose/runtime/MutableState;J)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;J)V"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1, p2}, LX/603;->A17(Landroidx/compose/runtime/MutableState;J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CodeFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Code;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->CodeFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Code;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MermaidFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->MermaidFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$MermaidDiagram;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MermaidFullScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$MermaidFullScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$TableFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Table;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->TableFullScreen(Lcom/facebook/aura/model/HatchContentViewModelData$Table;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ZoomableMermaidContent(LX/J0X;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt;->ZoomableMermaidContent(LX/J0X;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ZoomableMermaidContent$lambda$1(LX/2ss;)F
    .locals 0

    .line 0
    invoke-interface {p0}, LX/2ss;->AFu()F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$ZoomableMermaidContent$lambda$2(LX/2ss;F)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/2ss;->Adw(F)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ZoomableMermaidContent$lambda$4(Landroidx/compose/runtime/MutableState;)J
    .locals 1

    .line 0
    invoke-static {p0}, LX/603;->A06(Landroidx/compose/runtime/MutableState;)J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method public static final synthetic access$ZoomableMermaidContent$lambda$5(Landroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, LX/603;->A17(Landroidx/compose/runtime/MutableState;J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
