.class public final Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/uicontrol/ContributedUiAction;


# instance fields
.field public final value:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 4
    .line 5
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;IILjava/lang/Object;)Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 5
    .line 6
    :cond_0
    new-instance v0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(I)Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;

    .line 1
    .line 2
    invoke-direct {p0, p1}, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;-><init>(I)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return v2

    .line 17
    :cond_1
    return v3
.end method

.method public getIconRes()Ljava/lang/Integer;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public getSuggestionLabel()Lcom/facebook/aura/uicontrol/UiSuggestionLabel;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public final getValue()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;->value:I

    .line 1
    .line 2
    return p0
.end method

.method public perform(LX/AHE;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/uicontrol/UiActionExecutor$Result;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v4, Lcom/facebook/aura/uicontrol/UiActionExecutor$Result$Performed;->INSTANCE:Lcom/facebook/aura/uicontrol/UiActionExecutor$Result$Performed;

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sget-object v2, Lcom/facebook/aura/executors/AuraDispatchers;->mainImmediate:LX/DSG;

    .line 39
    .line 40
    const/4 v1, 0x0

    .line 41
    new-instance v0, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$2;

    .line 42
    .line 43
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$2;-><init>(Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;LX/2M4;)V

    .line 44
    .line 45
    .line 46
    iput-object v1, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->L$0:Ljava/lang/Object;

    .line 47
    .line 48
    iput v3, v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;->label:I

    .line 49
    .line 50
    invoke-static {v5, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    if-ne v0, v4, :cond_0

    .line 55
    .line 56
    return-object v4

    .line 57
    :cond_2
    new-instance v5, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;

    .line 58
    .line 59
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction$perform$1;-><init>(Lcom/facebook/aura/appappearance/SetAppearanceModeUiAction;LX/2M4;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
