.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onDismissClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;->$onDismissClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 8

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ARTIFACT_PREVIEW:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CLOSE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    move-object v5, v2

    .line 10
    move-object v6, v2

    .line 11
    move-object v7, v2

    .line 12
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$MermaidFullScreen$1$1;->$onDismissClick:Lkotlin/jvm/functions/Function0;

    .line 16
    .line 17
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    return-void
.end method
