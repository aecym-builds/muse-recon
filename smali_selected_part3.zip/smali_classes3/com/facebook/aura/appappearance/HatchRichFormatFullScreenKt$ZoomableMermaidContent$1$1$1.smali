.class public final Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2qg;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $offset$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scale$delegate:LX/2ss;


# direct methods
.method public constructor <init>(LX/2ss;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2ss;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2qg;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2qg;

    .line 1
    .line 2
    iget-wide v0, p1, LX/2qg;->A00:J

    .line 3
    .line 4
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->invoke-k-4lQ0M(J)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke-k-4lQ0M(J)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->$scale$delegate:LX/2ss;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    const/high16 v0, 0x3fc00000    # 1.5f

    .line 7
    .line 8
    cmpl-float v0, v1, v0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->$scale$delegate:LX/2ss;

    .line 11
    .line 12
    if-lez v0, :cond_0

    .line 13
    .line 14
    const/high16 v0, 0x3f800000    # 1.0f

    .line 15
    .line 16
    invoke-interface {v1, v0}, LX/2ss;->Adw(F)V

    .line 17
    .line 18
    .line 19
    iget-object p0, p0, Lcom/facebook/aura/appappearance/HatchRichFormatFullScreenKt$ZoomableMermaidContent$1$1$1;->$offset$delegate:Landroidx/compose/runtime/MutableState;

    .line 20
    .line 21
    const-wide/16 v0, 0x0

    .line 22
    .line 23
    invoke-static {p0, v0, v1}, LX/603;->A17(Landroidx/compose/runtime/MutableState;J)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_0
    const/high16 v0, 0x40400000    # 3.0f

    .line 28
    .line 29
    invoke-interface {v1, v0}, LX/2ss;->Adw(F)V

    .line 30
    .line 31
    .line 32
    return-void
.end method
