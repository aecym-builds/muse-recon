.class public abstract Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "DevicePermissionManageController"


# direct methods
.method public static final synthetic access$maybeOpenSettingsIfPermanentlyDenied(Landroid/content/Context;Ljava/util/Collection;)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->maybeOpenSettingsIfPermanentlyDenied(Landroid/content/Context;Ljava/util/Collection;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$rememberDevicePermissionLauncher$lambda$2(Landroidx/compose/runtime/MutableState;)Lcom/facebook/aura/navigation/key/PermissionDestination;
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$rememberDevicePermissionLauncher$lambda$3(Landroidx/compose/runtime/MutableState;Lcom/facebook/aura/navigation/key/PermissionDestination;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$runtimePermissionsFor(Lcom/facebook/aura/navigation/key/PermissionDestination;)[Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->runtimePermissionsFor(Lcom/facebook/aura/navigation/key/PermissionDestination;)[Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final findActivity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 0
    instance-of v0, p0, Landroid/app/Activity;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    check-cast p0, Landroid/app/Activity;

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_0
    instance-of v0, p0, Landroid/content/ContextWrapper;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    check-cast p0, Landroid/content/ContextWrapper;

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->findActivity(Landroid/content/Context;)Landroid/app/Activity;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0

    .line 25
    :cond_1
    const/4 p0, 0x0

    .line 26
    return-object p0
.end method

.method public static final maybeOpenSettingsIfPermanentlyDenied(Landroid/content/Context;Ljava/util/Collection;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_1

    .line 5
    .line 6
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->findActivity(Landroid/content/Context;)Landroid/app/Activity;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    if-eqz v2, :cond_1

    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    invoke-static {v1}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {v2, v0}, LX/0rg;->A01(Landroid/app/Activity;Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    sget-object v0, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 39
    .line 40
    invoke-virtual {v0, p0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->openAppSettings(Landroid/content/Context;)Z

    .line 41
    .line 42
    .line 43
    :cond_1
    return-void
.end method

.method public static final rememberDevicePermissionLauncher(Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;II)LX/JDM;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)",
            "LX/JDM<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p1

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    move-object/from16 v15, p0

    .line 4
    .line 5
    invoke-static {v15, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    and-int/lit8 v0, p4, 0x2

    .line 9
    .line 10
    move-object/from16 v7, p2

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v9

    .line 18
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 19
    .line 20
    if-ne v9, v0, :cond_0

    .line 21
    .line 22
    sget-object v9, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$1$1;

    .line 23
    .line 24
    invoke-interface {v7, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    check-cast v9, LX/JDN;

    .line 28
    .line 29
    :cond_1
    invoke-static {v7}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object v14

    .line 33
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v6

    .line 37
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 38
    .line 39
    if-ne v6, v5, :cond_2

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    invoke-static {v7, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 43
    .line 44
    .line 45
    move-result-object v6

    .line 46
    :cond_2
    check-cast v6, Landroidx/compose/runtime/MutableState;

    .line 47
    .line 48
    new-instance v3, LX/13u;

    .line 49
    .line 50
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    invoke-interface {v7, v14}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    and-int/lit8 v8, p3, 0xe

    .line 58
    .line 59
    xor-int/lit8 v12, v8, 0x6

    .line 60
    .line 61
    const/4 v11, 0x4

    .line 62
    if-le v12, v11, :cond_3

    .line 63
    .line 64
    invoke-interface {v7, v15}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_4

    .line 69
    .line 70
    :cond_3
    and-int/lit8 v1, p3, 0x6

    .line 71
    .line 72
    const/4 v0, 0x0

    .line 73
    if-ne v1, v11, :cond_5

    .line 74
    .line 75
    :cond_4
    const/4 v0, 0x1

    .line 76
    :cond_5
    or-int/2addr v2, v0

    .line 77
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-nez v2, :cond_6

    .line 82
    .line 83
    if-ne v0, v5, :cond_7

    .line 84
    .line 85
    :cond_6
    new-instance v0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$settingsLauncher$1$1;

    .line 86
    .line 87
    invoke-direct {v0, v14, v15}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$settingsLauncher$1$1;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 88
    .line 89
    .line 90
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    :cond_7
    check-cast v0, LX/JDM;

    .line 94
    .line 95
    invoke-static {v3, v7, v0}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    new-instance v3, LX/149;

    .line 100
    .line 101
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 102
    .line 103
    .line 104
    invoke-interface {v7, v14}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v10

    .line 108
    and-int/lit8 v0, p3, 0x70

    .line 109
    .line 110
    xor-int/lit8 v0, v0, 0x30

    .line 111
    .line 112
    const/16 v1, 0x20

    .line 113
    .line 114
    if-le v0, v1, :cond_8

    .line 115
    .line 116
    invoke-interface {v7, v9}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    if-nez v2, :cond_9

    .line 121
    .line 122
    :cond_8
    and-int/lit8 v2, p3, 0x30

    .line 123
    .line 124
    const/4 v13, 0x0

    .line 125
    if-ne v2, v1, :cond_a

    .line 126
    .line 127
    :cond_9
    const/4 v13, 0x1

    .line 128
    :cond_a
    or-int/2addr v13, v10

    .line 129
    if-le v12, v11, :cond_b

    .line 130
    .line 131
    invoke-interface {v7, v15}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    if-nez v2, :cond_c

    .line 136
    .line 137
    :cond_b
    and-int/lit8 v10, p3, 0x6

    .line 138
    .line 139
    const/4 v2, 0x0

    .line 140
    if-ne v10, v11, :cond_d

    .line 141
    .line 142
    :cond_c
    const/4 v2, 0x1

    .line 143
    :cond_d
    or-int/2addr v13, v2

    .line 144
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    if-nez v13, :cond_e

    .line 149
    .line 150
    if-ne v2, v5, :cond_f

    .line 151
    .line 152
    :cond_e
    new-instance v2, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;

    .line 153
    .line 154
    invoke-direct {v2, v15, v6, v14, v9}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroid/content/Context;LX/JDN;)V

    .line 155
    .line 156
    .line 157
    invoke-interface {v7, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    :cond_f
    check-cast v2, LX/JDM;

    .line 161
    .line 162
    invoke-static {v3, v7, v2}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    new-instance v10, LX/14B;

    .line 167
    .line 168
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 169
    .line 170
    .line 171
    invoke-interface {v7, v14}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v13

    .line 175
    if-le v0, v1, :cond_10

    .line 176
    .line 177
    invoke-interface {v7, v9}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-nez v0, :cond_11

    .line 182
    .line 183
    :cond_10
    and-int/lit8 v0, p3, 0x30

    .line 184
    .line 185
    const/4 v2, 0x0

    .line 186
    if-ne v0, v1, :cond_12

    .line 187
    .line 188
    :cond_11
    const/4 v2, 0x1

    .line 189
    :cond_12
    or-int/2addr v2, v13

    .line 190
    if-le v12, v11, :cond_13

    .line 191
    .line 192
    invoke-interface {v7, v15}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    if-nez v0, :cond_14

    .line 197
    .line 198
    :cond_13
    and-int/lit8 v0, p3, 0x6

    .line 199
    .line 200
    const/4 v1, 0x0

    .line 201
    if-ne v0, v11, :cond_15

    .line 202
    .line 203
    :cond_14
    const/4 v1, 0x1

    .line 204
    :cond_15
    or-int/2addr v1, v2

    .line 205
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    if-nez v1, :cond_16

    .line 210
    .line 211
    if-ne v0, v5, :cond_17

    .line 212
    .line 213
    :cond_16
    new-instance v0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;

    .line 214
    .line 215
    invoke-direct {v0, v15, v6, v14, v9}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroid/content/Context;LX/JDN;)V

    .line 216
    .line 217
    .line 218
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    :cond_17
    check-cast v0, LX/JDM;

    .line 222
    .line 223
    invoke-static {v10, v7, v0}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    invoke-static {v15, v7, v8}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt;->rememberHealthConnectConnectAction(Lkotlin/jvm/functions/Function0;LX/2d4;I)Lkotlin/jvm/functions/Function0;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    invoke-interface {v7, v14}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    invoke-static {v7, v4, v3, v2, v0}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 236
    .line 237
    .line 238
    move-result v0

    .line 239
    invoke-static {v7, v1, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v13

    .line 247
    if-nez v0, :cond_18

    .line 248
    .line 249
    if-ne v13, v5, :cond_19

    .line 250
    .line 251
    :cond_18
    new-instance v13, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;

    .line 252
    .line 253
    move-object/from16 p4, v6

    .line 254
    .line 255
    move-object/from16 p1, v2

    .line 256
    .line 257
    move-object/from16 p2, v4

    .line 258
    .line 259
    move-object/from16 p3, v1

    .line 260
    .line 261
    move-object/from16 p0, v3

    .line 262
    .line 263
    invoke-direct/range {v13 .. v20}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;LX/166;LX/166;LX/166;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 264
    .line 265
    .line 266
    invoke-interface {v7, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    :cond_19
    check-cast v13, LX/JDM;

    .line 270
    .line 271
    return-object v13
.end method

.method public static final rememberDevicePermissionLauncher$lambda$2(Landroidx/compose/runtime/MutableState;)Lcom/facebook/aura/navigation/key/PermissionDestination;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;)",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final rememberDevicePermissionLauncher$lambda$3(Landroidx/compose/runtime/MutableState;Lcom/facebook/aura/navigation/key/PermissionDestination;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberDevicePermissionManageController(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;II)LX/JDM;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchSurface;",
            "Lcom/facebook/aura/analytics/hatch/HatchSubsurface;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)",
            "LX/JDM<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p1, p2, p3, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    and-int/lit8 v0, p7, 0x10

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-interface {p5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p4

    .line 16
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 17
    .line 18
    if-ne p4, v0, :cond_0

    .line 19
    .line 20
    sget-object p4, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$1$1;

    .line 21
    .line 22
    invoke-interface {p5, p4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    check-cast p4, LX/JDN;

    .line 26
    .line 27
    :cond_1
    invoke-static {p5}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    invoke-static {p5}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 32
    .line 33
    .line 34
    move-result-object v6

    .line 35
    shr-int/lit8 v0, p6, 0x9

    .line 36
    .line 37
    and-int/lit8 v0, v0, 0x7e

    .line 38
    .line 39
    const/4 v4, 0x0

    .line 40
    invoke-static {p3, p4, p5, v0, v1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->rememberDevicePermissionLauncher(Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;II)LX/JDM;

    .line 41
    .line 42
    .line 43
    move-result-object p3

    .line 44
    invoke-static {p5, v5, v6, p3}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    and-int/lit8 v0, p6, 0xe

    .line 49
    .line 50
    xor-int/lit8 v0, v0, 0x6

    .line 51
    .line 52
    const/4 v2, 0x4

    .line 53
    if-le v0, v2, :cond_2

    .line 54
    .line 55
    invoke-static {p5, p0}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_3

    .line 60
    .line 61
    :cond_2
    and-int/lit8 v1, p6, 0x6

    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    if-ne v1, v2, :cond_4

    .line 65
    .line 66
    :cond_3
    const/4 v0, 0x1

    .line 67
    :cond_4
    or-int/2addr v3, v0

    .line 68
    and-int/lit8 v0, p6, 0x70

    .line 69
    .line 70
    xor-int/lit8 v0, v0, 0x30

    .line 71
    .line 72
    const/16 v2, 0x20

    .line 73
    .line 74
    if-le v0, v2, :cond_5

    .line 75
    .line 76
    invoke-static {p5, p1}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-nez v0, :cond_6

    .line 81
    .line 82
    :cond_5
    and-int/lit8 v1, p6, 0x30

    .line 83
    .line 84
    const/4 v0, 0x0

    .line 85
    if-ne v1, v2, :cond_7

    .line 86
    .line 87
    :cond_6
    const/4 v0, 0x1

    .line 88
    :cond_7
    or-int/2addr v3, v0

    .line 89
    and-int/lit16 v0, p6, 0x380

    .line 90
    .line 91
    xor-int/lit16 v0, v0, 0x180

    .line 92
    .line 93
    const/16 v1, 0x100

    .line 94
    .line 95
    if-le v0, v1, :cond_8

    .line 96
    .line 97
    invoke-static {p5, p2}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-nez v0, :cond_9

    .line 102
    .line 103
    :cond_8
    and-int/lit16 v0, p6, 0x180

    .line 104
    .line 105
    if-ne v0, v1, :cond_a

    .line 106
    .line 107
    :cond_9
    const/4 v4, 0x1

    .line 108
    :cond_a
    or-int/2addr v3, v4

    .line 109
    invoke-interface {p5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    if-nez v3, :cond_b

    .line 114
    .line 115
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 116
    .line 117
    if-ne v4, v0, :cond_c

    .line 118
    .line 119
    :cond_b
    new-instance v4, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;

    .line 120
    .line 121
    invoke-direct/range {v4 .. v10}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;-><init>(Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/JDM;)V

    .line 122
    .line 123
    .line 124
    invoke-interface {p5, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    :cond_c
    check-cast v4, LX/JDM;

    .line 128
    .line 129
    return-object v4
.end method

.method public static final runtimePermissionsFor(Lcom/facebook/aura/navigation/key/PermissionDestination;)[Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    const/4 v0, 0x2

    .line 7
    const/4 p0, 0x1

    .line 8
    const/4 v2, 0x0

    .line 9
    packed-switch v1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    throw v0

    .line 17
    :pswitch_0
    new-array v1, v0, [Ljava/lang/String;

    .line 18
    .line 19
    const/4 v0, 0x3

    .line 20
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    aput-object v0, v1, v2

    .line 25
    .line 26
    invoke-static {p0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    goto :goto_2

    .line 31
    :pswitch_1
    new-array v1, v0, [Ljava/lang/String;

    .line 32
    .line 33
    const-string v0, "android.permission.READ_CONTACTS"

    .line 34
    .line 35
    aput-object v0, v1, v2

    .line 36
    .line 37
    const/4 v0, 0x6

    .line 38
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    goto :goto_2

    .line 43
    :pswitch_2
    new-array v1, p0, [Ljava/lang/String;

    .line 44
    .line 45
    const/4 v0, 0x5

    .line 46
    goto :goto_0

    .line 47
    :pswitch_3
    sget-object v0, Lcom/facebook/aura/permissions/access/PhotoAccessUtils;->INSTANCE:Lcom/facebook/aura/permissions/access/PhotoAccessUtils;

    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/facebook/aura/permissions/access/PhotoAccessUtils;->requestPermissions()[Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    return-object v1

    .line 54
    :pswitch_4
    new-array v1, p0, [Ljava/lang/String;

    .line 55
    .line 56
    const/4 v0, 0x4

    .line 57
    goto :goto_0

    .line 58
    :pswitch_5
    new-array v1, p0, [Ljava/lang/String;

    .line 59
    .line 60
    :goto_0
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    goto :goto_1

    .line 65
    :pswitch_6
    new-array v1, p0, [Ljava/lang/String;

    .line 66
    .line 67
    const-string v0, "android.permission.RECORD_AUDIO"

    .line 68
    .line 69
    :goto_1
    aput-object v0, v1, v2

    .line 70
    .line 71
    return-object v1

    .line 72
    :pswitch_7
    new-array v1, v0, [Ljava/lang/String;

    .line 73
    .line 74
    const-string v0, "android.permission.BLUETOOTH_CONNECT"

    .line 75
    .line 76
    aput-object v0, v1, v2

    .line 77
    .line 78
    const-string v0, "android.permission.BLUETOOTH_SCAN"

    .line 79
    .line 80
    goto :goto_2

    .line 81
    :pswitch_8
    new-array v1, v0, [Ljava/lang/String;

    .line 82
    .line 83
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    .line 84
    .line 85
    aput-object v0, v1, v2

    .line 86
    .line 87
    const/16 v0, 0x2f

    .line 88
    .line 89
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    :goto_2
    aput-object v0, v1, p0

    .line 94
    .line 95
    return-object v1

    .line 96
    :pswitch_9
    const/4 v1, 0x0

    .line 97
    return-object v1

    .line 98
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_1
        :pswitch_0
        :pswitch_9
        :pswitch_2
        :pswitch_4
        :pswitch_5
        :pswitch_3
        :pswitch_9
        :pswitch_6
        :pswitch_7
        :pswitch_9
    .end packed-switch
.end method
