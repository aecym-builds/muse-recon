.class public final Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/3B6;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $measured:LX/3B5;


# direct methods
.method public constructor <init>(LX/3B5;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;->$measured:LX/3B5;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/3B6;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;->invoke(LX/3B6;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/3B6;)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;->$measured:LX/3B5;

    .line 5
    .line 6
    invoke-static {p1, v0, v1, v1}, LX/3B6;->A02(LX/3B6;LX/3B5;II)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
