.class public final Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRuntimePermissionResult:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroid/content/Context;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;",
            "Landroid/content/Context;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$onRuntimePermissionResult:LX/JDN;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->invoke(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    check-cast v4, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    if-eqz v4, :cond_2

    .line 10
    .line 11
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$onRuntimePermissionResult:LX/JDN;

    .line 14
    .line 15
    if-nez p1, :cond_0

    .line 16
    .line 17
    invoke-static {v4}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->runtimePermissionsFor(Lcom/facebook/aura/navigation/key/PermissionDestination;)[Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-static {v0}, LX/B82;->A0D([Ljava/lang/Object;)Ljava/util/List;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    :cond_0
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 30
    .line 31
    :cond_1
    invoke-static {v2, v0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->maybeOpenSettingsIfPermanentlyDenied(Landroid/content/Context;Ljava/util/Collection;)V

    .line 32
    .line 33
    .line 34
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-interface {v1, v4, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 42
    .line 43
    invoke-interface {v0, v3}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->INSTANCE:Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;

    .line 47
    .line 48
    invoke-virtual {v0}, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->notifyChanged()V

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$singlePermissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 52
    .line 53
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    return-void
.end method
