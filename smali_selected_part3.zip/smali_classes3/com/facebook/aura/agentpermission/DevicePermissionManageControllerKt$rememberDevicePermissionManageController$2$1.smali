.class public final Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/navigation/key/PermissionDestination;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $launch:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public final synthetic $subsurface:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

.field public final synthetic $surface:Lcom/facebook/aura/analytics/hatch/HatchSurface;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "Lcom/facebook/aura/analytics/hatch/HatchSurface;",
            "Lcom/facebook/aura/analytics/hatch/HatchSubsurface;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$surface:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$subsurface:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$launch:LX/JDM;

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->invoke(Lcom/facebook/aura/navigation/key/PermissionDestination;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/navigation/key/PermissionDestination;)V
    .locals 6

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Lcom/facebook/aura/agentpermission/LocalConnectorConsentSheetKt;->requiresLocalConnectorConsent(Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$context:Landroid/content/Context;

    .line 11
    .line 12
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$launch:LX/JDM;

    .line 19
    .line 20
    new-instance v0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1$1;

    .line 21
    .line 22
    invoke-direct {v0, v1, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1$1;-><init>(LX/JDM;Lcom/facebook/aura/navigation/key/PermissionDestination;)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Lcom/facebook/aura/agentpermission/LocalConnectorConsentHandshake;->onAccept:Lkotlin/jvm/functions/Function0;

    .line 26
    .line 27
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 28
    .line 29
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$surface:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 30
    .line 31
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$subsurface:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 32
    .line 33
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 34
    .line 35
    new-instance v0, Lcom/facebook/aura/navigation/key/LocalConnectorConsentSheetKey;

    .line 36
    .line 37
    invoke-direct {v0, p1, v3, v2, v1}, Lcom/facebook/aura/navigation/key/LocalConnectorConsentSheetKey;-><init>(Lcom/facebook/aura/navigation/key/PermissionDestination;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 38
    .line 39
    .line 40
    invoke-interface {v4, v0, v5}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionManageController$2$1;->$launch:LX/JDM;

    .line 45
    .line 46
    invoke-interface {v0, p1}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    return-void
.end method
