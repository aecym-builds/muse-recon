.class public final Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/2vi;",
        "LX/2sf;",
        "Landroidx/compose/ui/unit/Constraints;",
        "LX/3CP;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2vi;

    .line 1
    .line 2
    check-cast p2, LX/2sf;

    .line 3
    .line 4
    check-cast p3, Landroidx/compose/ui/unit/Constraints;

    .line 5
    .line 6
    iget-wide v0, p3, Landroidx/compose/ui/unit/Constraints;->A00:J

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;->invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final invoke-3p2s80s(LX/2vi;LX/2sf;J)LX/3CP;
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    invoke-static {p3, p4}, Landroidx/compose/ui/unit/Constraints;->A0B(J)Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    invoke-static {p3, p4}, Landroidx/compose/ui/unit/Constraints;->A01(J)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    div-int/lit8 v0, v0, 0x2

    .line 15
    .line 16
    :cond_0
    invoke-static {p3, p4, v2, v0}, Landroidx/compose/ui/unit/Constraints;->A08(JII)J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    invoke-interface {p2, v0, v1}, LX/2sf;->AQh(J)LX/3B5;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    iget v2, p0, LX/3B5;->A01:I

    .line 25
    .line 26
    iget v1, p0, LX/3B5;->A00:I

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;

    .line 29
    .line 30
    invoke-direct {v0, p0}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1$1;-><init>(LX/3B5;)V

    .line 31
    .line 32
    .line 33
    invoke-static {p1, v0, v2, v1}, LX/602;->A0B(LX/2vi;LX/JDM;II)LX/3CP;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    return-object v0
.end method
