.class public final Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        ">;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRuntimePermissionResult:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroid/content/Context;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;",
            "Landroid/content/Context;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$onRuntimePermissionResult:LX/JDN;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/util/Map;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->invoke(Ljava/util/Map;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/util/Map;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v8

    .line 10
    check-cast v8, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 11
    .line 12
    if-eqz v8, :cond_3

    .line 13
    .line 14
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 15
    .line 16
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$onRuntimePermissionResult:LX/JDN;

    .line 17
    .line 18
    invoke-static {v7, v8}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    if-nez v5, :cond_2

    .line 23
    .line 24
    invoke-static {}, LX/001;->A16()Ljava/util/LinkedHashMap;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    invoke-static {p1}, LX/002;->A1A(Ljava/util/Map;)Ljava/util/Iterator;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    invoke-static {v3}, LX/001;->A18(Ljava/util/Iterator;)Ljava/util/Map$Entry;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_0

    .line 51
    .line 52
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    invoke-virtual {v4}, Ljava/util/AbstractMap;->keySet()Ljava/util/Set;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v7, v0}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt;->maybeOpenSettingsIfPermanentlyDenied(Landroid/content/Context;Ljava/util/Collection;)V

    .line 69
    .line 70
    .line 71
    :cond_2
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-interface {v6, v8, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 79
    .line 80
    const/4 v0, 0x0

    .line 81
    invoke-interface {v1, v0}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    sget-object v0, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->INSTANCE:Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;

    .line 85
    .line 86
    invoke-virtual {v0}, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->notifyChanged()V

    .line 87
    .line 88
    .line 89
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$runtimePermissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 90
    .line 91
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    return-void
.end method
