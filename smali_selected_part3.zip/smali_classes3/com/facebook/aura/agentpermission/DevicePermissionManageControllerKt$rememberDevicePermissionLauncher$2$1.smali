.class public final Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/navigation/key/PermissionDestination;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $healthConnectConnect:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $runtimePermissionLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "[",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $settingsLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $singlePermissionLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;LX/166;LX/166;LX/166;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/166<",
            "[",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;>;",
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lcom/facebook/aura/navigation/key/PermissionDestination;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$singlePermissionLauncher:LX/166;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$settingsLauncher:LX/166;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$healthConnectConnect:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/navigation/key/PermissionDestination;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->invoke(Lcom/facebook/aura/navigation/key/PermissionDestination;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/navigation/key/PermissionDestination;)V
    .locals 5

    .line 0
    const-string v3, "DevicePermissionManageController"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    :try_start_0
    sget-object v0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    throw v0

    .line 21
    :pswitch_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 22
    .line 23
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 34
    .line 35
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 39
    .line 40
    const/4 v0, 0x3

    .line 41
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const/4 v0, 0x1

    .line 46
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    goto/16 :goto_1

    .line 55
    .line 56
    :pswitch_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 57
    .line 58
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_1

    .line 63
    .line 64
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 69
    .line 70
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 74
    .line 75
    const-string v1, "android.permission.READ_CONTACTS"

    .line 76
    .line 77
    const/4 v0, 0x6

    .line 78
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    goto/16 :goto_1

    .line 87
    .line 88
    :pswitch_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 89
    .line 90
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_2

    .line 95
    .line 96
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 101
    .line 102
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$singlePermissionLauncher:LX/166;

    .line 106
    .line 107
    const/4 v0, 0x5

    .line 108
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    goto :goto_0

    .line 113
    :pswitch_3
    sget-object v4, Lcom/facebook/aura/permissions/access/PhotoAccessUtils;->INSTANCE:Lcom/facebook/aura/permissions/access/PhotoAccessUtils;

    .line 114
    .line 115
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 116
    .line 117
    invoke-virtual {v4, v0}, Lcom/facebook/aura/permissions/access/PhotoAccessUtils;->isFullLibraryGranted(Landroid/content/Context;)Z

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    if-eqz v0, :cond_3

    .line 122
    .line 123
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 128
    .line 129
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 133
    .line 134
    invoke-virtual {v4}, Lcom/facebook/aura/permissions/access/PhotoAccessUtils;->requestPermissions()[Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-virtual {v1, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :pswitch_4
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$settingsLauncher:LX/166;

    .line 143
    .line 144
    const/16 v0, 0x3a

    .line 145
    .line 146
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    new-instance v1, Landroid/content/Intent;

    .line 151
    .line 152
    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v4, v1}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    return-void

    .line 159
    :pswitch_5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 160
    .line 161
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    if-eqz v0, :cond_4

    .line 166
    .line 167
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 168
    .line 169
    .line 170
    return-void

    .line 171
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 172
    .line 173
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$singlePermissionLauncher:LX/166;

    .line 177
    .line 178
    const/4 v0, 0x4

    .line 179
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    goto :goto_0

    .line 184
    :pswitch_6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 185
    .line 186
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    if-eqz v0, :cond_5

    .line 191
    .line 192
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 197
    .line 198
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$singlePermissionLauncher:LX/166;

    .line 202
    .line 203
    const/4 v0, 0x2

    .line 204
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    :goto_0
    invoke-virtual {v1, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    return-void

    .line 212
    :pswitch_7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 213
    .line 214
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 215
    .line 216
    .line 217
    move-result v0

    .line 218
    if-eqz v0, :cond_6

    .line 219
    .line 220
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 221
    .line 222
    .line 223
    return-void

    .line 224
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 225
    .line 226
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$singlePermissionLauncher:LX/166;

    .line 230
    .line 231
    const-string v0, "android.permission.RECORD_AUDIO"

    .line 232
    .line 233
    invoke-virtual {v1, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    return-void

    .line 237
    :pswitch_8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 238
    .line 239
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    if-eqz v0, :cond_7

    .line 244
    .line 245
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 246
    .line 247
    .line 248
    return-void

    .line 249
    :cond_7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 250
    .line 251
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 255
    .line 256
    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    .line 257
    .line 258
    const-string v0, "android.permission.BLUETOOTH_SCAN"

    .line 259
    .line 260
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    goto :goto_1

    .line 265
    :pswitch_9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$context:Landroid/content/Context;

    .line 266
    .line 267
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/DevicePermissionStateKt;->isDevicePermissionGranted(Landroid/content/Context;Lcom/facebook/aura/navigation/key/PermissionDestination;)Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_8

    .line 272
    .line 273
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 274
    .line 275
    .line 276
    return-void

    .line 277
    :cond_8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 278
    .line 279
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 280
    .line 281
    .line 282
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$runtimePermissionLauncher:LX/166;

    .line 283
    .line 284
    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    .line 285
    .line 286
    const/16 v0, 0x2f

    .line 287
    .line 288
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    :goto_1
    invoke-virtual {v4, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    return-void

    .line 300
    :pswitch_a
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$healthConnectConnect:Lkotlin/jvm/functions/Function0;

    .line 301
    .line 302
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    return-void
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    .line 306
    :catch_0
    move-exception v1

    .line 307
    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    instance-of v0, v0, Landroid/os/RemoteException;

    .line 312
    .line 313
    if-eqz v0, :cond_9

    .line 314
    .line 315
    const-string v0, "system failed to launch permission flow for "

    .line 316
    .line 317
    invoke-static {v0, p1}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    invoke-static {v3, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 322
    .line 323
    .line 324
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 325
    .line 326
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 327
    .line 328
    .line 329
    invoke-static {}, LX/3Rr;->A14()V

    .line 330
    .line 331
    .line 332
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 333
    .line 334
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    :pswitch_b
    return-void

    .line 338
    :cond_9
    throw v1

    .line 339
    :catch_1
    move-exception v4

    .line 340
    const-string v0, "permission launcher unregistered for "

    .line 341
    .line 342
    invoke-static {p1, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    const-string v0, "; opening app settings"

    .line 347
    .line 348
    invoke-static {v0, v1}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    invoke-static {v3, v0, v4}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 353
    .line 354
    .line 355
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;->$pendingRuntimeDestination$delegate:Landroidx/compose/runtime/MutableState;

    .line 356
    .line 357
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 358
    .line 359
    .line 360
    invoke-static {p0}, LX/604;->A0h(Lcom/facebook/aura/agentpermission/DevicePermissionManageControllerKt$rememberDevicePermissionLauncher$2$1;)V

    .line 361
    .line 362
    .line 363
    return-void

    .line 364
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_1
        :pswitch_0
        :pswitch_a
        :pswitch_2
        :pswitch_5
        :pswitch_6
        :pswitch_3
        :pswitch_4
        :pswitch_7
        :pswitch_8
        :pswitch_b
    .end packed-switch
.end method
