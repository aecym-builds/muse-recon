.class public final Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Landroid/net/Uri;",
        "LX/AHE;",
        "Lcom/facebook/aura/deeplink/AuraDeeplinkRoute;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Landroid/net/Uri;LX/AHE;)Lcom/facebook/aura/deeplink/AuraDeeplinkRoute;
    .locals 2

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    invoke-static {p1}, Lcom/facebook/aura/deeplink/AuraDeeplinkRouteProviderKt;->deeplinkRouteSegments(Landroid/net/Uri;)Ljava/util/List;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    invoke-static {v0, v1}, LX/602;->A0k(Ljava/util/List;I)Ljava/lang/String;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p2

    .line 268435468
    const/4 p1, 0x0

    .line 268435469
    if-eqz p2, :cond_0

    .line 268435470
    .line 268435471
    invoke-static {p2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 268435472
    .line 268435473
    .line 268435474
    move-result v0

    .line 268435475
    if-nez v0, :cond_0

    .line 268435476
    .line 268435477
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 268435478
    .line 268435479
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 268435480
    .line 268435481
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->SETTINGS_CONNECTED_APPS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 268435482
    .line 268435483
    invoke-virtual {p0, v1, p1, v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logDeepLink(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Ljava/util/Map;)V

    .line 268435484
    .line 268435485
    .line 268435486
    new-instance p0, Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

    .line 268435487
    .line 268435488
    invoke-direct {p0, p2}, Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;-><init>(Ljava/lang/String;)V

    .line 268435489
    .line 268435490
    .line 268435491
    sget-object v1, Lcom/facebook/aura/navigation/LaunchFlag;->NAVIGATE:Lcom/facebook/aura/navigation/LaunchFlag;

    .line 268435492
    .line 268435493
    new-instance v0, Lcom/facebook/aura/deeplink/AuraDeeplinkRoute;

    .line 268435494
    .line 268435495
    invoke-direct {v0, p0, v1, p1, p1}, Lcom/facebook/aura/deeplink/AuraDeeplinkRoute;-><init>(Lcom/facebook/aura/navigation/AuraNavKey;Lcom/facebook/aura/navigation/LaunchFlag;Lcom/facebook/aura/navigation/AuraNavKey;LX/JDM;)V

    .line 268435496
    .line 268435497
    .line 268435498
    return-object v0

    .line 268435499
    :cond_0
    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Landroid/net/Uri;

    .line 1
    .line 2
    check-cast p2, LX/AHE;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;->invoke(Landroid/net/Uri;LX/AHE;)Lcom/facebook/aura/deeplink/AuraDeeplinkRoute;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method
