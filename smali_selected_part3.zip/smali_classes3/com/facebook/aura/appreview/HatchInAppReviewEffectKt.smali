.class public abstract Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final REVIEW_PROMPT_DELAY_MS:J = 0xbb8L

.field public static final TAG:Ljava/lang/String; = "HatchInAppReview"


# direct methods
.method public static final HatchInAppReviewEffect(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, 0xfb85f5f

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_3

    .line 15
    .line 16
    invoke-static {p0}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-interface {p0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    if-nez v1, :cond_0

    .line 29
    .line 30
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 31
    .line 32
    if-ne v0, v1, :cond_1

    .line 33
    .line 34
    :cond_0
    const/4 v1, 0x0

    .line 35
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1;

    .line 36
    .line 37
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 38
    .line 39
    .line 40
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    invoke-static {p0, v0, v2}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :goto_0
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    if-eqz v1, :cond_2

    .line 51
    .line 52
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$2;

    .line 53
    .line 54
    invoke-direct {v0, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$2;-><init>(I)V

    .line 55
    .line 56
    .line 57
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 58
    .line 59
    :cond_2
    return-void

    .line 60
    :cond_3
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 61
    .line 62
    .line 63
    goto :goto_0
.end method
