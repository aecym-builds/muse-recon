.class public final Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/globaleffects/api/AppGlobalEffect;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public Effect(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, -0x3616440e

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v2, p2, 0x1

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-static {v2}, LX/003;->A1B(I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-interface {p1, v2, v0}, LX/2d4;->Afw(IZ)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    invoke-static {p1, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt;->HatchInAppReviewEffect(LX/2d4;I)V

    .line 20
    .line 21
    .line 22
    :goto_0
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect$Effect$1;

    .line 29
    .line 30
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect$Effect$1;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewAppGlobalEffect;I)V

    .line 31
    .line 32
    .line 33
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 34
    .line 35
    :cond_0
    return-void

    .line 36
    :cond_1
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 37
    .line 38
    .line 39
    goto :goto_0
.end method

.method public bridge getRunsUnderBlockingOverlay()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
