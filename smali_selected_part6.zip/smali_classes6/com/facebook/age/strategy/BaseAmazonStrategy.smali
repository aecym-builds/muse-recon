.class public abstract Lcom/facebook/age/strategy/BaseAmazonStrategy;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/Fjg;


# instance fields
.field public final A00:Landroid/content/Context;

.field public final A01:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/age/strategy/BaseAmazonStrategy;->A00:Landroid/content/Context;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/age/strategy/BaseAmazonStrategy;->A01:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;

    .line 6
    .line 7
    return-void
.end method

.method public static synthetic A00(Lcom/facebook/age/strategy/BaseAmazonStrategy;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/age/strategy/BaseAmazonStrategy;",
            "LX/2M4<",
            "-",
            "LX/FjS;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 v3, 0x0

    .line 1
    instance-of v0, p1, LX/Gdb;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, LX/Gdb;

    .line 7
    .line 8
    iget v1, v0, LX/Gdb;->$t:I

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v3, :cond_1

    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :cond_1
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object v5, p1

    .line 17
    check-cast v5, LX/Gdb;

    .line 18
    .line 19
    iget v2, v5, LX/Gdb;->A00:I

    .line 20
    .line 21
    const/high16 v1, -0x80000000

    .line 22
    .line 23
    and-int v0, v2, v1

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    sub-int/2addr v2, v1

    .line 28
    iput v2, v5, LX/Gdb;->A00:I

    .line 29
    .line 30
    :goto_0
    iget-object v1, v5, LX/Gdb;->A02:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 33
    .line 34
    iget v0, v5, LX/Gdb;->A00:I

    .line 35
    .line 36
    const/4 v3, 0x1

    .line 37
    if-eqz v0, :cond_4

    .line 38
    .line 39
    if-ne v0, v3, :cond_3

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_2
    new-instance v5, LX/Gdb;

    .line 43
    .line 44
    invoke-direct {v5, p0, p1, v3}, LX/Gdb;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    const/4 v1, 0x0

    .line 57
    :try_start_0
    const/4 v0, 0x4

    .line 58
    new-instance v2, LX/FSW;

    .line 59
    .line 60
    invoke-direct {v2, p0, v1, v0}, LX/FSW;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 61
    .line 62
    .line 63
    iput-object p0, v5, LX/Gdb;->A01:Ljava/lang/Object;

    .line 64
    .line 65
    iput v3, v5, LX/Gdb;->A00:I

    .line 66
    .line 67
    const-wide/16 v0, 0x1388

    .line 68
    .line 69
    invoke-static {v5, v2, v0, v1}, LX/DRJ;->A00(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    if-ne v1, v4, :cond_5

    .line 74
    .line 75
    return-object v4

    .line 76
    :goto_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_5
    move-object v4, v1

    .line 80
    check-cast v4, LX/FjS;

    .line 81
    .line 82
    return-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 83
    :catch_0
    move-exception v1

    .line 84
    instance-of v0, v1, Lkotlinx/coroutines/TimeoutCancellationException;

    .line 85
    .line 86
    if-eqz v0, :cond_6

    .line 87
    .line 88
    sget-object v1, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 89
    .line 90
    :goto_2
    new-instance v0, LX/FjO;

    .line 91
    .line 92
    invoke-direct {v0, v1}, LX/FjO;-><init>(Ljava/lang/Integer;)V

    .line 93
    .line 94
    .line 95
    return-object v0

    .line 96
    :cond_6
    instance-of v0, v1, Ljava/lang/SecurityException;

    .line 97
    .line 98
    if-eqz v0, :cond_7

    .line 99
    .line 100
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_7
    sget-object v1, LX/FkO;->A02:Ljava/lang/Integer;

    .line 104
    .line 105
    goto :goto_2
.end method


# virtual methods
.method public final bridge Abb(Landroid/app/Activity;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "LX/2M4<",
            "-",
            "LX/FjT;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    sget-object p1, LX/FjM;->A03:LX/FjM;

    .line 1
    .line 2
    new-instance p0, LX/FjR;

    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/FjR;-><init>(LX/FjM;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final Abc(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/FjS;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/age/strategy/BaseAmazonStrategy;->A00(Lcom/facebook/age/strategy/BaseAmazonStrategy;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
