.class public final Lcom/facebook/age/strategy/GoogleSystemStrategy;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/Fjg;


# instance fields
.field public final A00:Landroid/content/Context;

.field public final A01:Lkotlin/Lazy;

.field public final A02:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;)V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A00:Landroid/content/Context;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A02:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;

    .line 6
    .line 7
    sget-object v1, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    invoke-static {v1, p0, v0}, LX/HUv;->A00(Ljava/lang/Integer;Ljava/lang/Object;I)Lkotlin/Lazy;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A01:Lkotlin/Lazy;

    .line 15
    .line 16
    return-void
.end method

.method public static final A00(Ljava/lang/Exception;)Ljava/lang/Integer;
    .locals 5

    .line 0
    instance-of v0, p0, Lcom/google/android/gms/common/api/ApiException;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    check-cast p0, Lcom/google/android/gms/common/api/ApiException;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/google/android/gms/common/api/ApiException;->mStatus:Lcom/google/android/gms/common/api/Status;

    .line 7
    .line 8
    iget p0, v0, Lcom/google/android/gms/common/api/Status;->A00:I

    .line 9
    .line 10
    :goto_0
    const/16 v0, 0xb

    .line 11
    .line 12
    invoke-static {v0}, LX/FkO;->A00(I)[Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    array-length v3, v4

    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_1
    if-ge v2, v3, :cond_1

    .line 19
    .line 20
    aget-object v1, v4, v2

    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    packed-switch v0, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    const/4 v0, -0x1

    .line 30
    :goto_2
    if-eq v0, p0, :cond_2

    .line 31
    .line 32
    add-int/lit8 v2, v2, 0x1

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :pswitch_0
    const/16 v0, -0x64

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :pswitch_1
    const/16 v0, -0xa

    .line 39
    .line 40
    goto :goto_2

    .line 41
    :pswitch_2
    const/16 v0, -0x9

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :pswitch_3
    const/4 v0, -0x8

    .line 45
    goto :goto_2

    .line 46
    :pswitch_4
    const/4 v0, -0x7

    .line 47
    goto :goto_2

    .line 48
    :pswitch_5
    const/4 v0, -0x6

    .line 49
    goto :goto_2

    .line 50
    :pswitch_6
    const/4 v0, -0x5

    .line 51
    goto :goto_2

    .line 52
    :pswitch_7
    const/4 v0, -0x4

    .line 53
    goto :goto_2

    .line 54
    :pswitch_8
    const/4 v0, -0x3

    .line 55
    goto :goto_2

    .line 56
    :pswitch_9
    const/4 v0, -0x2

    .line 57
    goto :goto_2

    .line 58
    :cond_0
    const/16 p0, -0x64

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_1
    sget-object v1, LX/FkO;->A02:Ljava/lang/Integer;

    .line 62
    .line 63
    :cond_2
    return-object v1

    .line 64
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final Abb(Landroid/app/Activity;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "LX/2M4<",
            "-",
            "LX/FjT;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 v4, 0x3

    .line 1
    instance-of v0, p2, LX/GbT;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, LX/GbT;

    .line 7
    .line 8
    iget v1, v0, LX/GbT;->$t:I

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v4, :cond_1

    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :cond_1
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object v7, p2

    .line 17
    check-cast v7, LX/GbT;

    .line 18
    .line 19
    iget v2, v7, LX/GbT;->A00:I

    .line 20
    .line 21
    const/high16 v1, -0x80000000

    .line 22
    .line 23
    and-int v0, v2, v1

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    sub-int/2addr v2, v1

    .line 28
    iput v2, v7, LX/GbT;->A00:I

    .line 29
    .line 30
    :goto_0
    iget-object v0, v7, LX/GbT;->A03:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 33
    .line 34
    iget v1, v7, LX/GbT;->A00:I

    .line 35
    .line 36
    const/4 v5, 0x1

    .line 37
    if-eqz v1, :cond_4

    .line 38
    .line 39
    if-ne v1, v5, :cond_3

    .line 40
    .line 41
    goto :goto_3

    .line 42
    :cond_2
    new-instance v7, LX/GbT;

    .line 43
    .line 44
    invoke-direct {v7, p0, p2, v4}, LX/GbT;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_4
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    if-eqz p1, :cond_b

    .line 57
    .line 58
    :try_start_0
    const/4 v8, 0x0

    .line 59
    new-instance v10, LX/FZu;

    .line 60
    .line 61
    invoke-direct {v10, p1}, LX/FZu;-><init>(Landroid/app/Activity;)V

    .line 62
    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A01:Lkotlin/Lazy;

    .line 65
    .line 66
    invoke-static {v0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    check-cast v0, Lcom/google/android/play/agesignals/AgeSignalsManager;

    .line 71
    .line 72
    check-cast v0, LX/FZt;

    .line 73
    .line 74
    iget-object v1, v0, LX/FZt;->A00:LX/FZA;

    .line 75
    .line 76
    iget-object v9, v1, LX/FZA;->A02:LX/FZz;

    .line 77
    .line 78
    if-nez v9, :cond_5

    .line 79
    .line 80
    const/4 v2, -0x2

    .line 81
    goto :goto_1

    .line 82
    :cond_5
    invoke-static {v1}, LX/FZA;->A00(LX/FZA;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-nez v0, :cond_6

    .line 87
    .line 88
    const/4 v2, -0x6

    .line 89
    goto :goto_1

    .line 90
    :cond_6
    new-instance v3, LX/FTy;

    .line 91
    .line 92
    invoke-direct {v3}, LX/FTy;-><init>()V

    .line 93
    .line 94
    .line 95
    new-instance v2, LX/FZs;

    .line 96
    .line 97
    invoke-direct {v2, v3, v3, v10, v1}, LX/FZs;-><init>(LX/FTy;LX/FTy;LX/Fa8;LX/FZA;)V

    .line 98
    .line 99
    .line 100
    iget-object v0, v2, LX/FZw;->A00:LX/FTy;

    .line 101
    .line 102
    new-instance v1, LX/FZy;

    .line 103
    .line 104
    invoke-direct {v1, v2, v9, v0, v3}, LX/FZy;-><init>(LX/FZw;LX/FZz;LX/FTy;LX/FTy;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v9}, LX/FZz;->A01()Landroid/os/Handler;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 112
    .line 113
    .line 114
    iget-object v0, v3, LX/FTy;->A00:LX/FWa;

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :goto_1
    sget-object v1, LX/FZA;->A03:LX/FZ7;

    .line 118
    .line 119
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    invoke-virtual {v1, v0}, LX/FZ7;->A04([Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    new-instance v0, Lcom/google/android/play/agesignals/AgeSignalsException;

    .line 131
    .line 132
    invoke-direct {v0, v2}, Lcom/google/android/play/agesignals/AgeSignalsException;-><init>(I)V

    .line 133
    .line 134
    .line 135
    invoke-static {v0}, LX/FWa;->A00(Ljava/lang/Exception;)LX/FWa;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    :goto_2
    iput-object v8, v7, LX/GbT;->A01:Ljava/lang/Object;

    .line 140
    .line 141
    iput-object v8, v7, LX/GbT;->A02:Ljava/lang/Object;

    .line 142
    .line 143
    iput v5, v7, LX/GbT;->A00:I

    .line 144
    .line 145
    invoke-static {v0, v7}, LX/FNT;->A00(LX/FWb;LX/2M4;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    if-ne v0, v6, :cond_7

    .line 150
    .line 151
    return-object v6

    .line 152
    :goto_3
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    :cond_7
    check-cast v0, LX/Ed6;

    .line 156
    .line 157
    check-cast v0, LX/Ed5;

    .line 158
    .line 159
    iget-object v0, v0, LX/Ed5;->A00:Ljava/lang/Integer;

    .line 160
    .line 161
    if-eqz v0, :cond_a

    .line 162
    .line 163
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    if-ne v1, v5, :cond_8

    .line 168
    .line 169
    sget-object v0, LX/FjM;->A03:LX/FjM;

    .line 170
    .line 171
    :goto_4
    new-instance v6, LX/FjR;

    .line 172
    .line 173
    invoke-direct {v6, v0}, LX/FjR;-><init>(LX/FjM;)V

    .line 174
    .line 175
    .line 176
    goto :goto_5

    .line 177
    :cond_8
    const/4 v0, 0x2

    .line 178
    if-ne v1, v0, :cond_9

    .line 179
    .line 180
    sget-object v0, LX/FjM;->A02:LX/FjM;

    .line 181
    .line 182
    goto :goto_4

    .line 183
    :cond_9
    if-ne v1, v4, :cond_a

    .line 184
    .line 185
    sget-object v0, LX/FjM;->A05:LX/FjM;

    .line 186
    .line 187
    goto :goto_4

    .line 188
    :cond_a
    sget-object v0, LX/FjM;->A04:LX/FjM;

    .line 189
    .line 190
    goto :goto_4

    .line 191
    :goto_5
    return-object v6

    .line 192
    :cond_b
    const-string v0, "Null activity"

    .line 193
    .line 194
    invoke-static {v0}, LX/001;->A0s(Ljava/lang/String;)Ljava/lang/NullPointerException;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    throw v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 199
    :catch_0
    move-exception v0

    .line 200
    invoke-static {v0}, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A00(Ljava/lang/Exception;)Ljava/lang/Integer;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    new-instance v0, LX/FjQ;

    .line 205
    .line 206
    invoke-direct {v0, v1}, LX/FjQ;-><init>(Ljava/lang/Integer;)V

    .line 207
    .line 208
    .line 209
    return-object v0
.end method

.method public final Abc(LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/FjS;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 v2, 0x1

    .line 1
    instance-of v0, p1, LX/Gdb;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, LX/Gdb;

    .line 7
    .line 8
    iget v1, v0, LX/Gdb;->$t:I

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v2, :cond_1

    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :cond_1
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object v6, p1

    .line 17
    check-cast v6, LX/Gdb;

    .line 18
    .line 19
    iget v3, v6, LX/Gdb;->A00:I

    .line 20
    .line 21
    const/high16 v1, -0x80000000

    .line 22
    .line 23
    and-int v0, v3, v1

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    sub-int/2addr v3, v1

    .line 28
    iput v3, v6, LX/Gdb;->A00:I

    .line 29
    .line 30
    :goto_0
    iget-object v3, v6, LX/Gdb;->A02:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 33
    .line 34
    iget v0, v6, LX/Gdb;->A00:I

    .line 35
    .line 36
    if-eqz v0, :cond_4

    .line 37
    .line 38
    if-ne v0, v2, :cond_3

    .line 39
    .line 40
    goto :goto_3

    .line 41
    :cond_2
    new-instance v6, LX/Gdb;

    .line 42
    .line 43
    invoke-direct {v6, p0, p1, v2}, LX/Gdb;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0

    .line 52
    :cond_4
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    :try_start_0
    new-instance v8, LX/Fa9;

    .line 56
    .line 57
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A01:Lkotlin/Lazy;

    .line 61
    .line 62
    invoke-static {v0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, Lcom/google/android/play/agesignals/AgeSignalsManager;

    .line 67
    .line 68
    check-cast v0, LX/FZt;

    .line 69
    .line 70
    iget-object v1, v0, LX/FZt;->A00:LX/FZA;

    .line 71
    .line 72
    iget-object v7, v1, LX/FZA;->A02:LX/FZz;

    .line 73
    .line 74
    if-nez v7, :cond_5

    .line 75
    .line 76
    const/4 v3, -0x2

    .line 77
    goto :goto_1

    .line 78
    :cond_5
    invoke-static {v1}, LX/FZA;->A00(LX/FZA;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_6

    .line 83
    .line 84
    const/4 v3, -0x6

    .line 85
    goto :goto_1

    .line 86
    :cond_6
    new-instance v4, LX/FTy;

    .line 87
    .line 88
    invoke-direct {v4}, LX/FTy;-><init>()V

    .line 89
    .line 90
    .line 91
    new-instance v3, LX/FZr;

    .line 92
    .line 93
    invoke-direct {v3, v4, v4, v8, v1}, LX/FZr;-><init>(LX/FTy;LX/FTy;LX/Fa9;LX/FZA;)V

    .line 94
    .line 95
    .line 96
    iget-object v0, v3, LX/FZw;->A00:LX/FTy;

    .line 97
    .line 98
    new-instance v1, LX/FZy;

    .line 99
    .line 100
    invoke-direct {v1, v3, v7, v0, v4}, LX/FZy;-><init>(LX/FZw;LX/FZz;LX/FTy;LX/FTy;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v7}, LX/FZz;->A01()Landroid/os/Handler;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 108
    .line 109
    .line 110
    iget-object v1, v4, LX/FTy;->A00:LX/FWa;

    .line 111
    .line 112
    goto :goto_2

    .line 113
    :goto_1
    sget-object v1, LX/FZA;->A03:LX/FZ7;

    .line 114
    .line 115
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-virtual {v1, v0}, LX/FZ7;->A04([Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    new-instance v0, Lcom/google/android/play/agesignals/AgeSignalsException;

    .line 127
    .line 128
    invoke-direct {v0, v3}, Lcom/google/android/play/agesignals/AgeSignalsException;-><init>(I)V

    .line 129
    .line 130
    .line 131
    invoke-static {v0}, LX/FWa;->A00(Ljava/lang/Exception;)LX/FWa;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    :goto_2
    const/4 v0, 0x0

    .line 136
    iput-object v0, v6, LX/Gdb;->A01:Ljava/lang/Object;

    .line 137
    .line 138
    iput v2, v6, LX/Gdb;->A00:I

    .line 139
    .line 140
    invoke-static {v1, v6}, LX/FNT;->A00(LX/FWb;LX/2M4;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    if-ne v3, v5, :cond_7

    .line 145
    .line 146
    return-object v5

    .line 147
    :goto_3
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_7
    check-cast v3, LX/FjU;

    .line 151
    .line 152
    check-cast v3, LX/FjL;

    .line 153
    .line 154
    iget-object v0, v3, LX/FjL;->A00:Ljava/lang/Integer;

    .line 155
    .line 156
    if-nez v0, :cond_9

    .line 157
    .line 158
    sget-object v4, LX/FkO;->A0P:Ljava/lang/Integer;

    .line 159
    .line 160
    :goto_4
    iget-object v5, v3, LX/FjL;->A02:Ljava/lang/Integer;

    .line 161
    .line 162
    iget-object v6, v3, LX/FjL;->A01:Ljava/lang/Integer;

    .line 163
    .line 164
    iget-object v0, v3, LX/FjL;->A05:Ljava/util/Date;

    .line 165
    .line 166
    const/4 v8, 0x0

    .line 167
    if-eqz v0, :cond_8

    .line 168
    .line 169
    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    .line 170
    .line 171
    .line 172
    move-result-wide v0

    .line 173
    invoke-static {v0, v1}, LX/EYt;->A07(J)J

    .line 174
    .line 175
    .line 176
    move-result-wide v0

    .line 177
    new-instance v8, Ljava/lang/Long;

    .line 178
    .line 179
    invoke-direct {v8, v0, v1}, Ljava/lang/Long;-><init>(J)V

    .line 180
    .line 181
    .line 182
    :cond_8
    iget-object p0, v3, LX/FjL;->A04:Ljava/lang/String;

    .line 183
    .line 184
    const-string p1, "google"

    .line 185
    .line 186
    iget-object v0, v3, LX/FjL;->A03:Ljava/lang/Integer;

    .line 187
    .line 188
    if-nez v0, :cond_e

    .line 189
    .line 190
    goto :goto_5

    .line 191
    :cond_9
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 192
    .line 193
    .line 194
    move-result v1

    .line 195
    if-ne v1, v2, :cond_a

    .line 196
    .line 197
    sget-object v4, LX/FkO;->A0W:Ljava/lang/Integer;

    .line 198
    .line 199
    goto :goto_4

    .line 200
    :cond_a
    const/4 v0, 0x2

    .line 201
    if-ne v1, v0, :cond_b

    .line 202
    .line 203
    sget-object v4, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 204
    .line 205
    goto :goto_4

    .line 206
    :cond_b
    const/4 v0, 0x3

    .line 207
    if-ne v1, v0, :cond_c

    .line 208
    .line 209
    sget-object v4, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 210
    .line 211
    goto :goto_4

    .line 212
    :cond_c
    const/4 v0, 0x4

    .line 213
    if-ne v1, v0, :cond_d

    .line 214
    .line 215
    sget-object v4, LX/FkO;->A0c:Ljava/lang/Integer;

    .line 216
    .line 217
    goto :goto_4

    .line 218
    :cond_d
    sget-object v4, LX/FkO;->A02:Ljava/lang/Integer;

    .line 219
    .line 220
    goto :goto_4

    .line 221
    :goto_5
    const/4 v7, 0x0

    .line 222
    goto :goto_6

    .line 223
    :cond_e
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    if-ne v1, v2, :cond_f

    .line 228
    .line 229
    sget-object v7, LX/FkO;->A00:Ljava/lang/Integer;

    .line 230
    .line 231
    :goto_6
    new-instance v3, LX/Fjc;

    .line 232
    .line 233
    invoke-direct/range {v3 .. v10}, LX/Fjc;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    new-instance v5, LX/FjP;

    .line 237
    .line 238
    invoke-direct {v5, v3}, LX/FjP;-><init>(LX/Fjc;)V

    .line 239
    .line 240
    .line 241
    goto :goto_7

    .line 242
    :cond_f
    const/4 v0, 0x2

    .line 243
    if-ne v1, v0, :cond_10

    .line 244
    .line 245
    sget-object v7, LX/FkO;->A01:Ljava/lang/Integer;

    .line 246
    .line 247
    goto :goto_6

    .line 248
    :cond_10
    const/4 v0, 0x3

    .line 249
    if-ne v1, v0, :cond_11

    .line 250
    .line 251
    sget-object v7, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 252
    .line 253
    goto :goto_6

    .line 254
    :cond_11
    sget-object v7, LX/FkO;->A0K:Ljava/lang/Integer;

    .line 255
    .line 256
    goto :goto_6

    .line 257
    :goto_7
    return-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 258
    :catch_0
    move-exception v0

    .line 259
    invoke-static {v0}, Lcom/facebook/age/strategy/GoogleSystemStrategy;->A00(Ljava/lang/Exception;)Ljava/lang/Integer;

    .line 260
    .line 261
    .line 262
    move-result-object v1

    .line 263
    new-instance v0, LX/FjO;

    .line 264
    .line 265
    invoke-direct {v0, v1}, LX/FjO;-><init>(Ljava/lang/Integer;)V

    .line 266
    .line 267
    .line 268
    return-object v0
.end method
