.class public final Lcom/facebook/analytics/appstatelogger/foregroundstate/EntityAppState$ForegroundInit;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "ForegroundInit"

    .line 1
    .line 2
    return-object p0
.end method
