.class public final Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/GIo;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/GIo;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;->INSTANCE:Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;->requestFactory()LX/GIr;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2$1;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2$1;

    .line 10
    .line 11
    new-instance v1, Lcom/facebook/aura/network/endpoint/AuraEndpointSelector;

    .line 12
    .line 13
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    new-instance v0, LX/GIo;

    .line 17
    .line 18
    invoke-direct {v0, p0, v2, v1}, LX/GIo;-><init>(LX/GIr;LX/GJM;LX/FrH;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory$instance$2;->invoke()LX/GIo;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
