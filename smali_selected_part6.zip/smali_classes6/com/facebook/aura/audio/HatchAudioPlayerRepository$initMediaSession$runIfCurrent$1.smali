.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lkotlin/jvm/functions/Function0<",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $forGeneration:J

.field public final synthetic $player:LX/EZl;

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->$player:LX/EZl;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->$forGeneration:J

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lkotlin/jvm/functions/Function0;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->invoke(Lkotlin/jvm/functions/Function0;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lkotlin/jvm/functions/Function0;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 5
    .line 6
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->$player:LX/EZl;

    .line 7
    .line 8
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;->$forGeneration:J

    .line 9
    .line 10
    invoke-static {v3, v2, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$isCurrentPlayer(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method
