.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final cumulativeListeningSeconds:D

.field public final durationSeconds:Ljava/lang/Double;

.field public final playbackSessionId:Ljava/lang/String;

.field public final positionSeconds:Ljava/lang/Double;

.field public final reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 9
    .line 10
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 11
    .line 12
    iput-object p5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 15
    .line 16
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;ILjava/lang/Object;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p6, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->copy(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()D
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 1
    .line 2
    return-wide v0
.end method

.method public final component4()Ljava/lang/Double;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/Double;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;-><init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6

    .line 0
    const/4 v5, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 4
    .line 5
    const/4 v4, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-wide v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 27
    .line 28
    iget-wide v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 29
    .line 30
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Double;->compare(DD)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    :cond_0
    return v4

    .line 57
    :cond_1
    return v5
.end method

.method public final getCumulativeListeningSeconds()D
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getDurationSeconds()Ljava/lang/Double;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlaybackSessionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPositionSeconds()Ljava/lang/Double;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReason()Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 13
    .line 14
    invoke-static {v0, v1, v2}, LX/I9H;->A01(DI)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 28
    .line 29
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
