.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlayerRepository$beginPlaybackRequest$3"
    f = "HatchAudioPlayerRepository.kt"
    l = {
        0x107
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $currentGeneration:J

.field public final synthetic $item:Lcom/facebook/aura/audio/HatchAudioItem;

.field public final synthetic $permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLcom/facebook/aura/audio/HatchAudioItem;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/AudioPlaybackPermit;",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            "J",
            "Lcom/facebook/aura/audio/HatchAudioItem;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$currentGeneration:J

    .line 5
    .line 6
    iput-object p5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iget-wide v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$currentGeneration:J

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLcom/facebook/aura/audio/HatchAudioItem;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v4, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    :goto_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v5

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 19
    .line 20
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->isValid()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 25
    .line 26
    if-nez v0, :cond_2

    .line 27
    .line 28
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$currentGeneration:J

    .line 29
    .line 30
    invoke-static {v3, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$failPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 35
    .line 36
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->$currentGeneration:J

    .line 37
    .line 38
    iput v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;->label:I

    .line 39
    .line 40
    invoke-static {v3, v2, v0, v1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$preparePlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;JLX/2M4;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-ne v0, v5, :cond_0

    .line 45
    .line 46
    return-object v5

    .line 47
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0
.end method
