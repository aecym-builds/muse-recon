.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final durationMs:I

.field public final item:Lcom/facebook/aura/audio/HatchAudioItem;

.field public final playbackRate:F

.field public final status:Lcom/facebook/aura/audio/AudioStatus;

.field public final volume:F


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 9
    .line 10
    iput p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 11
    .line 12
    iput p4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 13
    .line 14
    iput p5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 15
    .line 16
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/audio/HatchAudioPlaybackState;Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFFILjava/lang/Object;)Lcom/facebook/aura/audio/HatchAudioPlaybackState;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget p5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->copy(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/audio/HatchAudioItem;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/audio/AudioStatus;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 1
    .line 2
    return p0
.end method

.method public final component4()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 1
    .line 2
    return p0
.end method

.method public final component5()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)Lcom/facebook/aura/audio/HatchAudioPlaybackState;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;-><init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 27
    .line 28
    iget v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 29
    .line 30
    if-ne v1, v0, :cond_0

    .line 31
    .line 32
    iget v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 33
    .line 34
    iget v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 35
    .line 36
    invoke-static {v1, v0}, Ljava/lang/Float;->compare(FF)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    iget v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 43
    .line 44
    iget v0, p1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 45
    .line 46
    invoke-static {v1, v0}, Ljava/lang/Float;->compare(FF)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    :cond_0
    return v2

    .line 53
    :cond_1
    return v3
.end method

.method public final getDurationMs()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 1
    .line 2
    return p0
.end method

.method public final getItem()Lcom/facebook/aura/audio/HatchAudioItem;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlaybackRate()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 1
    .line 2
    return p0
.end method

.method public final getStatus()Lcom/facebook/aura/audio/AudioStatus;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVolume()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 13
    .line 14
    add-int/2addr v1, v0

    .line 15
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    .line 17
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 18
    .line 19
    invoke-static {v1, v0}, LX/007;->A07(IF)I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 24
    .line 25
    invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    add-int/2addr v1, v0

    .line 30
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
