.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/GoY;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public synthetic onAudioAttributesChanged(LX/GoR;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onAudioSessionIdChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onAvailableCommandsChanged(LX/Gi9;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onCues(LX/EuP;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onCues(Ljava/util/List;)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public synthetic onDeviceInfoChanged(LX/EaO;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onDeviceVolumeChanged(IZ)V
    .locals 0

    .line 0
    return-void
.end method

.method public onEvents(LX/GPY;LX/EbJ;)V
    .locals 2

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 5
    .line 6
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->access$sample(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x7

    .line 10
    iget-object v0, p2, LX/EbJ;->A00:LX/EbK;

    .line 11
    .line 12
    iget-object v0, v0, LX/EbK;->A00:Landroid/util/SparseBooleanArray;

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/util/SparseBooleanArray;->get(I)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 21
    .line 22
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->access$updateSampler(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method

.method public synthetic onIsLoadingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onIsPlayingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onLoadingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMaxSeekToPreviousPositionChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMediaItemTransition(LX/GYI;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMediaMetadataChanged(LX/JYv;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMetadata(LX/GeP;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayWhenReadyChanged(ZI)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaybackParametersChanged(LX/EbE;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaybackStateChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaybackSuppressionReasonChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayerErrorChanged(Landroidx/media3/common/PlaybackException;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayerStateChanged(ZI)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaylistMetadataChanged(LX/JYv;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPositionDiscontinuity(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public onPositionDiscontinuity(LX/EcN;LX/EcN;I)V
    .locals 4

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 268435460
    .line 268435461
    iget-wide v2, p1, LX/EcN;->A05:J

    .line 268435462
    .line 268435463
    iget-wide v0, p2, LX/EcN;->A05:J

    .line 268435464
    .line 268435465
    invoke-static {p0, v2, v3, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->access$recordDiscontinuity(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;JJ)V

    .line 268435466
    .line 268435467
    .line 268435468
    return-void
.end method

.method public synthetic onRenderedFirstFrame()V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onRepeatModeChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSeekBackIncrementChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSeekForwardIncrementChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onShuffleModeEnabledChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSkipSilenceEnabledChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSurfaceSizeChanged(II)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTimelineChanged(Landroidx/media3/common/Timeline;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTrackSelectionParametersChanged(LX/GZK;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTracksChanged(LX/GNt;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onVideoSizeChanged(LX/GNa;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onVolumeChanged(F)V
    .locals 0

    .line 0
    return-void
.end method
