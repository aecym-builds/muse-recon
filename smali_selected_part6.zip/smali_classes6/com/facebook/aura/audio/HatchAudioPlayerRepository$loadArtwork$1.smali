.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlayerRepository$loadArtwork$1"
    f = "HatchAudioPlayerRepository.kt"
    l = {
        0x2bf
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $forGeneration:J

.field public final synthetic $url:Ljava/lang/String;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$url:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$forGeneration:J

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$url:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iget-wide p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$forGeneration:J

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;

    .line 7
    .line 8
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-ne v0, v1, :cond_4

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :try_start_0
    sget-object v3, Lcom/facebook/aura/common/image/AuraBitmapLoader;->INSTANCE:Lcom/facebook/aura/common/image/AuraBitmapLoader;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$url:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    invoke-static {v4}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    const-string v5, "HatchAudioArtwork"

    .line 25
    .line 26
    iput v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->label:I

    .line 27
    .line 28
    const/4 v6, 0x0

    .line 29
    move-object v7, v6

    .line 30
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/common/image/AuraBitmapLoader;->load(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/Integer;Landroid/graphics/Bitmap$Config;LX/2M4;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    if-ne p1, v2, :cond_1

    .line 35
    .line 36
    return-object v2

    .line 37
    :goto_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 41
    .line 42
    if-eqz p1, :cond_3

    .line 43
    .line 44
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 45
    .line 46
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 49
    .line 50
    .line 51
    move-result-wide v3

    .line 52
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->$forGeneration:J

    .line 53
    .line 54
    cmp-long v0, v3, v1

    .line 55
    .line 56
    if-nez v0, :cond_3

    .line 57
    .line 58
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 59
    .line 60
    iput-object p1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->artworkBitmap:Landroid/graphics/Bitmap;

    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 63
    .line 64
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 65
    .line 66
    if-eqz v0, :cond_2

    .line 67
    .line 68
    invoke-virtual {v0, p1}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->updateArtwork(Landroid/graphics/Bitmap;)V

    .line 69
    .line 70
    .line 71
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 72
    .line 73
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$syncMediaSession(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 77
    :catch_0
    move-exception v1

    .line 78
    instance-of v0, v1, Ljava/util/concurrent/CancellationException;

    .line 79
    .line 80
    if-nez v0, :cond_5

    .line 81
    .line 82
    :cond_3
    :goto_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 83
    .line 84
    return-object v2

    .line 85
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    :cond_5
    throw v1
.end method
