.class public abstract Lcom/facebook/aura/audio/AudioPlaybackPermit$DefaultImpls;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static awaitPauseRequest(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/AudioPlaybackPermit;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/audio/AudioPlaybackPermit$-CC;->awaitPauseRequest$suspendImpl(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static getAudioUsage(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Ljava/lang/Integer;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public static getContinuesAfterOwnerEnds(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Z
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public static onEnded(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/AudioPlaybackEndReason;I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-interface {p0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->release()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static onPaused(Lcom/facebook/aura/audio/AudioPlaybackPermit;I)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    return-void
.end method

.method public static release(Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 0
    return-void
.end method
