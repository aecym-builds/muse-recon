.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $player:LX/EZl;

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->$player:LX/EZl;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->requestAudioFocus()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-ne v0, v1, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->$player:LX/EZl;

    .line 18
    .line 19
    check-cast v0, LX/GnY;

    .line 20
    .line 21
    invoke-static {v0}, LX/GnY;->A0M(LX/GnY;)V

    .line 22
    .line 23
    .line 24
    invoke-static {v0, v1, v1}, LX/GnY;->A0O(LX/GnY;IZ)V

    .line 25
    .line 26
    .line 27
    :goto_0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    :cond_1
    const/4 v1, 0x0

    .line 33
    goto :goto_0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
