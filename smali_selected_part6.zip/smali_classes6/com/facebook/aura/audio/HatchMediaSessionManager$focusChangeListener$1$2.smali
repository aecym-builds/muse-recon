.class public final Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$2;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$2;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPause:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
