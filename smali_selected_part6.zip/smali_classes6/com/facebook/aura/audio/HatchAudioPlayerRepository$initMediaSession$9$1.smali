.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $player:LX/EZl;

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->$player:LX/EZl;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isDucking:Z

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-boolean v0, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isDucking:Z

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->$player:LX/EZl;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 14
    .line 15
    iget v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 16
    .line 17
    invoke-interface {v1, v0}, LX/GPY;->Afj(F)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method
