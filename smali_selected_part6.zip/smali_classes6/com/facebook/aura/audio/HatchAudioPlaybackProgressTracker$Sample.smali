.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final isAdvancing:Z

.field public final position:Ljava/lang/Double;

.field public final rate:D

.field public final time:D


# direct methods
.method public constructor <init>(DLjava/lang/Double;DZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->time:D

    .line 4
    .line 5
    iput-object p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->position:Ljava/lang/Double;

    .line 6
    .line 7
    iput-wide p4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->rate:D

    .line 8
    .line 9
    iput-boolean p6, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->isAdvancing:Z

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getPosition()Ljava/lang/Double;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->position:Ljava/lang/Double;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRate()D
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->rate:D

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getTime()D
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->time:D

    .line 1
    .line 2
    return-wide v0
.end method

.method public final isAdvancing()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->isAdvancing:Z

    .line 1
    .line 2
    return p0
.end method
