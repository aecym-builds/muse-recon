.class public final Lcom/facebook/aura/audio/HatchMediaSessionManager;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public audioFocusGranted:Z

.field public audioFocusRequest:Landroid/media/AudioFocusRequest;

.field public final audioManager:Landroid/media/AudioManager;

.field public final context:Landroid/content/Context;

.field public final focusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

.field public final isPlaying:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final mainHandler:Landroid/os/Handler;

.field public mediaSession:LX/Hk3;

.field public final onDuck:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onPause:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onPlay:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onSeekTo:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onSetPlaybackSpeed:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onSkipBackward:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onSkipForward:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onStop:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onUnduck:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public wasPlayingBeforeFocusLoss:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x5

    .line 4
    invoke-static {p6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x6

    .line 8
    invoke-static {p7, p8, p9, v0}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 9
    .line 10
    .line 11
    const/16 v0, 0x9

    .line 12
    .line 13
    invoke-static {p10, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    const/16 v0, 0xa

    .line 17
    .line 18
    invoke-static {p11, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 19
    .line 20
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->context:Landroid/content/Context;

    .line 25
    .line 26
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPlay:Lkotlin/jvm/functions/Function0;

    .line 27
    .line 28
    iput-object p3, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPause:Lkotlin/jvm/functions/Function0;

    .line 29
    .line 30
    iput-object p4, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onStop:Lkotlin/jvm/functions/Function0;

    .line 31
    .line 32
    iput-object p5, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSeekTo:LX/JDM;

    .line 33
    .line 34
    iput-object p6, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipForward:Lkotlin/jvm/functions/Function0;

    .line 35
    .line 36
    iput-object p7, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipBackward:Lkotlin/jvm/functions/Function0;

    .line 37
    .line 38
    iput-object p8, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSetPlaybackSpeed:LX/JDM;

    .line 39
    .line 40
    iput-object p9, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onDuck:Lkotlin/jvm/functions/Function0;

    .line 41
    .line 42
    iput-object p10, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onUnduck:Lkotlin/jvm/functions/Function0;

    .line 43
    .line 44
    iput-object p11, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->isPlaying:Lkotlin/jvm/functions/Function0;

    .line 45
    .line 46
    invoke-static {p1}, LX/I1c;->A08(Landroid/content/Context;)Landroid/media/AudioManager;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioManager:Landroid/media/AudioManager;

    .line 51
    .line 52
    invoke-static {}, LX/003;->A0P()Landroid/os/Handler;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 57
    .line 58
    new-instance v0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;

    .line 59
    .line 60
    invoke-direct {v0, p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 61
    .line 62
    .line 63
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->focusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    .line 64
    .line 65
    return-void
.end method

.method private final declared-synchronized abandonAudioFocus()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusRequest:Landroid/media/AudioFocusRequest;

    .line 2
    .line 3
    if-eqz v1, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioManager:Landroid/media/AudioManager;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->abandonAudioFocusRequest(Landroid/media/AudioFocusRequest;)I

    .line 8
    .line 9
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusRequest:Landroid/media/AudioFocusRequest;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusGranted:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    monitor-exit p0

    .line 17
    return-void

    .line 18
    :catchall_0
    move-exception v0

    .line 19
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    throw v0
.end method

.method public static final synthetic access$getMainHandler$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Landroid/os/Handler;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnDuck$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onDuck:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnPause$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPause:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnPlay$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPlay:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnSeekTo$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSeekTo:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnSetPlaybackSpeed$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSetPlaybackSpeed:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnSkipBackward$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipBackward:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnSkipForward$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipForward:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnStop$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onStop:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnUnduck$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onUnduck:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getWasPlayingBeforeFocusLoss$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$isPlaying$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->isPlaying:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$markAudioFocusGranted(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->markAudioFocusGranted()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$markAudioFocusRevoked(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->markAudioFocusRevoked()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$setWasPlayingBeforeFocusLoss$p(Lcom/facebook/aura/audio/HatchMediaSessionManager;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 1
    .line 2
    return-void
.end method

.method private final declared-synchronized markAudioFocusGranted()V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusGranted:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    return-void

    .line 6
    :catchall_0
    move-exception v0

    .line 7
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 8
    throw v0
.end method

.method private final declared-synchronized markAudioFocusRevoked()V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusGranted:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    return-void

    .line 6
    :catchall_0
    move-exception v0

    .line 7
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 8
    throw v0
.end method

.method private final orCreateAudioFocusRequest()Landroid/media/AudioFocusRequest;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusRequest:Landroid/media/AudioFocusRequest;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    new-instance v1, Landroid/media/AudioFocusRequest$Builder;

    .line 6
    .line 7
    invoke-direct {v1, v2}, Landroid/media/AudioFocusRequest$Builder;-><init>(I)V

    .line 8
    .line 9
    .line 10
    new-instance v0, Landroid/media/AudioAttributes$Builder;

    .line 11
    .line 12
    invoke-direct {v0}, Landroid/media/AudioAttributes$Builder;-><init>()V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, v2}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0, v2}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v1, v0}, Landroid/media/AudioFocusRequest$Builder;->setAudioAttributes(Landroid/media/AudioAttributes;)Landroid/media/AudioFocusRequest$Builder;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->focusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 34
    .line 35
    invoke-virtual {v2, v1, v0}, Landroid/media/AudioFocusRequest$Builder;->setOnAudioFocusChangeListener(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;)Landroid/media/AudioFocusRequest$Builder;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Landroid/media/AudioFocusRequest$Builder;->build()Landroid/media/AudioFocusRequest;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusRequest:Landroid/media/AudioFocusRequest;

    .line 44
    .line 45
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    return-object v0
.end method


# virtual methods
.method public final activate(Lcom/facebook/aura/audio/HatchAudioItem;I)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->release()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->context:Landroid/content/Context;

    .line 8
    .line 9
    new-instance v4, LX/Hk3;

    .line 10
    .line 11
    invoke-direct {v4, v0}, LX/Hk3;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    new-instance v6, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;

    .line 15
    .line 16
    invoke-direct {v6, p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 17
    .line 18
    .line 19
    iget-object v5, v4, LX/Hk3;->A01:LX/Hkh;

    .line 20
    .line 21
    new-instance v3, Landroid/os/Handler;

    .line 22
    .line 23
    invoke-direct {v3}, Landroid/os/Handler;-><init>()V

    .line 24
    .line 25
    .line 26
    check-cast v5, LX/HkI;

    .line 27
    .line 28
    iget-object v2, v5, LX/HkI;->A08:Ljava/lang/Object;

    .line 29
    .line 30
    monitor-enter v2

    .line 31
    :try_start_0
    iput-object v6, v5, LX/HkI;->A01:LX/HkC;

    .line 32
    .line 33
    iget-object v1, v5, LX/HkI;->A04:Landroid/media/session/MediaSession;

    .line 34
    .line 35
    iget-object v0, v6, LX/HkC;->mCallbackFwk:Landroid/media/session/MediaSession$Callback;

    .line 36
    .line 37
    invoke-virtual {v1, v0, v3}, Landroid/media/session/MediaSession;->setCallback(Landroid/media/session/MediaSession$Callback;Landroid/os/Handler;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v6, v5, v3}, LX/HkC;->setSessionImpl(LX/Hkh;Landroid/os/Handler;)V

    .line 41
    .line 42
    .line 43
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    invoke-static {}, LX/001;->A0O()Landroid/os/Bundle;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    const-string v3, "android.media.metadata.TITLE"

    .line 49
    .line 50
    iget-object v2, p1, Lcom/facebook/aura/audio/HatchAudioItem;->title:Ljava/lang/String;

    .line 51
    .line 52
    sget-object v6, Landroid/support/v4/media/MediaMetadataCompat;->A02:LX/0w0;

    .line 53
    .line 54
    invoke-virtual {v6, v3}, LX/0vv;->containsKey(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    invoke-virtual {v6, v3}, LX/0vv;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    const/4 v0, 0x1

    .line 69
    if-eq v1, v0, :cond_0

    .line 70
    .line 71
    const-string v1, "The "

    .line 72
    .line 73
    const-string v0, " key cannot be used to put a String"

    .line 74
    .line 75
    invoke-static {v1, v3, v0}, LX/Gi8;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    throw v0

    .line 80
    :cond_0
    invoke-virtual {v5, v3, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 81
    .line 82
    .line 83
    const-string v3, "android.media.metadata.ARTIST"

    .line 84
    .line 85
    iget-object v2, p1, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v6, v3}, LX/0vv;->containsKey(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_1

    .line 92
    .line 93
    invoke-virtual {v6, v3}, LX/0vv;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    const/4 v0, 0x1

    .line 102
    if-eq v1, v0, :cond_1

    .line 103
    .line 104
    const-string v1, "The "

    .line 105
    .line 106
    const-string v0, " key cannot be used to put a String"

    .line 107
    .line 108
    invoke-static {v1, v3, v0}, LX/Gi8;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0

    .line 113
    :cond_1
    invoke-virtual {v5, v3, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 114
    .line 115
    .line 116
    const-string v3, "android.media.metadata.DURATION"

    .line 117
    .line 118
    int-to-long v1, p2

    .line 119
    invoke-virtual {v6, v3}, LX/0vv;->containsKey(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    if-eqz v0, :cond_2

    .line 124
    .line 125
    invoke-virtual {v6, v3}, LX/0vv;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 130
    .line 131
    .line 132
    move-result v0

    .line 133
    if-eqz v0, :cond_2

    .line 134
    .line 135
    const-string v1, "The "

    .line 136
    .line 137
    const-string v0, " key cannot be used to put a long"

    .line 138
    .line 139
    invoke-static {v1, v3, v0}, LX/Gi8;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    throw v0

    .line 144
    :cond_2
    invoke-virtual {v5, v3, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 145
    .line 146
    .line 147
    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat;

    .line 148
    .line 149
    invoke-direct {v0, v5}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v4, v0}, LX/Hk3;->A01(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 153
    .line 154
    .line 155
    const/4 v0, 0x1

    .line 156
    invoke-virtual {v4, v0}, LX/Hk3;->A02(Z)V

    .line 157
    .line 158
    .line 159
    iput-object v4, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 160
    .line 161
    return-void

    .line 162
    :catchall_0
    :try_start_1
    move-exception v0

    .line 163
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 164
    throw v0
.end method

.method public final cancelResumeOnFocusGain()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 2
    .line 3
    return-void
.end method

.method public final getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    iget-object p0, p0, LX/Hk3;->A01:LX/Hkh;

    .line 5
    .line 6
    check-cast p0, LX/HkI;

    .line 7
    .line 8
    iget-object p0, p0, LX/HkI;->A07:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public final release()V
    .locals 4

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {v1, v0}, LX/Hk3;->A02(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v3, v1, LX/Hk3;->A01:LX/Hkh;

    .line 9
    .line 10
    check-cast v3, LX/HkI;

    .line 11
    .line 12
    iget-object v0, v3, LX/HkI;->A05:Landroid/os/RemoteCallbackList;

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/os/RemoteCallbackList;->kill()V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    iget-object v1, v3, LX/HkI;->A04:Landroid/media/session/MediaSession;

    .line 19
    .line 20
    invoke-virtual {v1, v2}, Landroid/media/session/MediaSession;->setCallback(Landroid/media/session/MediaSession$Callback;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, v3, LX/HkI;->A06:Landroid/support/v4/media/session/MediaSessionCompat$MediaSessionImplApi21$ExtraSession;

    .line 24
    .line 25
    iget-object v0, v0, Landroid/support/v4/media/session/MediaSessionCompat$MediaSessionImplApi21$ExtraSession;->A00:Ljava/util/concurrent/atomic/AtomicReference;

    .line 26
    .line 27
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/media/session/MediaSession;->release()V

    .line 31
    .line 32
    .line 33
    :cond_0
    const/4 v0, 0x0

    .line 34
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 35
    .line 36
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->abandonAudioFocus()V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final declared-synchronized requestAudioFocus()Z
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusGranted:Z

    .line 2
    .line 3
    const/4 v2, 0x1

    .line 4
    if-nez v0, :cond_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioManager:Landroid/media/AudioManager;

    .line 7
    .line 8
    :try_start_1
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->orCreateAudioFocusRequest()Landroid/media/AudioFocusRequest;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v1, v0}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioFocusRequest;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eq v0, v2, :cond_0

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    :cond_0
    iput-boolean v2, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->audioFocusGranted:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    .line 21
    :cond_1
    monitor-exit p0

    .line 22
    return v2

    .line 23
    :catchall_0
    move-exception v0

    .line 24
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 25
    throw v0
.end method

.method public final updateArtwork(Landroid/graphics/Bitmap;)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 5
    .line 6
    if-eqz p0, :cond_1

    .line 7
    .line 8
    iget-object v0, p0, LX/Hk3;->A00:LX/HkO;

    .line 9
    .line 10
    iget-object v0, v0, LX/HkO;->A00:LX/Hkr;

    .line 11
    .line 12
    check-cast v0, LX/HkH;

    .line 13
    .line 14
    iget-object v0, v0, LX/HkH;->A01:Landroid/media/session/MediaController;

    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    if-eqz v2, :cond_1

    .line 21
    .line 22
    sget-object v0, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 23
    .line 24
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v2, v1, v3}, Landroid/media/MediaMetadata;->writeToParcel(Landroid/os/Parcel;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 32
    .line 33
    .line 34
    invoke-interface {v0, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/support/v4/media/MediaMetadataCompat;

    .line 39
    .line 40
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 41
    .line 42
    .line 43
    iput-object v2, v0, Landroid/support/v4/media/MediaMetadataCompat;->A00:Landroid/media/MediaMetadata;

    .line 44
    .line 45
    iget-object v0, v0, Landroid/support/v4/media/MediaMetadataCompat;->A01:Landroid/os/Bundle;

    .line 46
    .line 47
    new-instance v3, Landroid/os/Bundle;

    .line 48
    .line 49
    invoke-direct {v3, v0}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 50
    .line 51
    .line 52
    invoke-static {v3}, LX/Hk3;->A00(Landroid/os/Bundle;)V

    .line 53
    .line 54
    .line 55
    const-string v2, "android.media.metadata.ALBUM_ART"

    .line 56
    .line 57
    sget-object v1, Landroid/support/v4/media/MediaMetadataCompat;->A02:LX/0w0;

    .line 58
    .line 59
    invoke-virtual {v1, v2}, LX/0vv;->containsKey(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_0

    .line 64
    .line 65
    invoke-virtual {v1, v2}, LX/0vv;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    const/4 v0, 0x2

    .line 74
    if-eq v1, v0, :cond_0

    .line 75
    .line 76
    const-string v1, "The "

    .line 77
    .line 78
    const-string v0, " key cannot be used to put a Bitmap"

    .line 79
    .line 80
    invoke-static {v1, v2, v0}, LX/Gi8;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    throw v0

    .line 85
    :cond_0
    invoke-virtual {v3, v2, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 86
    .line 87
    .line 88
    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat;

    .line 89
    .line 90
    invoke-direct {v0, v3}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p0, v0}, LX/Hk3;->A01(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 94
    .line 95
    .line 96
    :cond_1
    return-void
.end method

.method public final updatePlaybackState(Lcom/facebook/aura/audio/HatchAudioPlaybackState;I)V
    .locals 25

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object/from16 v2, p1

    .line 2
    .line 3
    invoke-static {v2, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v0, p0

    .line 7
    .line 8
    iget-object v6, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mediaSession:LX/Hk3;

    .line 9
    .line 10
    if-eqz v6, :cond_6

    .line 11
    .line 12
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/4 v0, 0x1

    .line 19
    const/16 v16, 0x3

    .line 20
    .line 21
    if-eq v1, v0, :cond_0

    .line 22
    .line 23
    const/4 v0, 0x2

    .line 24
    if-eq v1, v0, :cond_1

    .line 25
    .line 26
    if-ne v1, v7, :cond_5

    .line 27
    .line 28
    const/16 v16, 0x6

    .line 29
    .line 30
    :cond_0
    :goto_0
    const/4 v12, 0x0

    .line 31
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 32
    .line 33
    .line 34
    move-result-object v14

    .line 35
    move/from16 v0, p2

    .line 36
    .line 37
    int-to-long v8, v0

    .line 38
    iget v15, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 39
    .line 40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 41
    .line 42
    .line 43
    move-result-wide v24

    .line 44
    const-wide/16 v4, 0x0

    .line 45
    .line 46
    const-wide/32 v2, 0x40014f

    .line 47
    .line 48
    .line 49
    const-wide/16 v0, -0x1

    .line 50
    .line 51
    new-instance v11, Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 52
    .line 53
    move-object v13, v12

    .line 54
    move-wide/from16 v20, v4

    .line 55
    .line 56
    move-wide/from16 v22, v2

    .line 57
    .line 58
    move-wide/from16 p1, v0

    .line 59
    .line 60
    move/from16 v17, v7

    .line 61
    .line 62
    move-wide/from16 v18, v8

    .line 63
    .line 64
    invoke-direct/range {v11 .. v27}, Landroid/support/v4/media/session/PlaybackStateCompat;-><init>(Landroid/os/Bundle;Ljava/lang/CharSequence;Ljava/util/List;FIIJJJJJ)V

    .line 65
    .line 66
    .line 67
    iget-object v10, v6, LX/Hk3;->A01:LX/Hkh;

    .line 68
    .line 69
    check-cast v10, LX/HkI;

    .line 70
    .line 71
    iput-object v11, v10, LX/HkI;->A02:Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 72
    .line 73
    iget-object v9, v10, LX/HkI;->A08:Ljava/lang/Object;

    .line 74
    .line 75
    monitor-enter v9

    .line 76
    goto :goto_1

    .line 77
    :cond_1
    const/16 v16, 0x2

    .line 78
    .line 79
    goto :goto_0

    .line 80
    :goto_1
    :try_start_0
    iget-object v8, v10, LX/HkI;->A05:Landroid/os/RemoteCallbackList;

    .line 81
    .line 82
    invoke-virtual {v8}, Landroid/os/RemoteCallbackList;->beginBroadcast()I

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    add-int/lit8 v7, v6, -0x1

    .line 87
    .line 88
    :goto_2
    if-ltz v7, :cond_2

    .line 89
    .line 90
    invoke-virtual {v8, v7}, Landroid/os/RemoteCallbackList;->getBroadcastItem(I)Landroid/os/IInterface;

    .line 91
    .line 92
    .line 93
    move-result-object v6

    .line 94
    check-cast v6, Landroid/support/v4/media/session/IMediaControllerCallback;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 95
    .line 96
    :try_start_1
    invoke-interface {v6, v11}, Landroid/support/v4/media/session/IMediaControllerCallback;->AUu(Landroid/support/v4/media/session/PlaybackStateCompat;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 97
    .line 98
    .line 99
    :catch_0
    add-int/lit8 v7, v7, -0x1

    .line 100
    .line 101
    goto :goto_2

    .line 102
    :cond_2
    :try_start_2
    invoke-virtual {v8}, Landroid/os/RemoteCallbackList;->finishBroadcast()V

    .line 103
    .line 104
    .line 105
    monitor-exit v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 106
    iget-object v8, v10, LX/HkI;->A04:Landroid/media/session/MediaSession;

    .line 107
    .line 108
    iget-object v6, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A00:Landroid/media/session/PlaybackState;

    .line 109
    .line 110
    if-nez v6, :cond_4

    .line 111
    .line 112
    new-instance v12, Landroid/media/session/PlaybackState$Builder;

    .line 113
    .line 114
    invoke-direct {v12}, Landroid/media/session/PlaybackState$Builder;-><init>()V

    .line 115
    .line 116
    .line 117
    iget v13, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A04:I

    .line 118
    .line 119
    iget-wide v14, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A08:J

    .line 120
    .line 121
    iget v9, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A02:F

    .line 122
    .line 123
    iget-wide v6, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A09:J

    .line 124
    .line 125
    move/from16 v16, v9

    .line 126
    .line 127
    move-wide/from16 v17, v6

    .line 128
    .line 129
    invoke-virtual/range {v12 .. v18}, Landroid/media/session/PlaybackState$Builder;->setState(IJFJ)Landroid/media/session/PlaybackState$Builder;

    .line 130
    .line 131
    .line 132
    invoke-virtual {v12, v4, v5}, Landroid/media/session/PlaybackState$Builder;->setBufferedPosition(J)Landroid/media/session/PlaybackState$Builder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v12, v2, v3}, Landroid/media/session/PlaybackState$Builder;->setActions(J)Landroid/media/session/PlaybackState$Builder;

    .line 136
    .line 137
    .line 138
    iget-object v2, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A0B:Ljava/lang/CharSequence;

    .line 139
    .line 140
    invoke-virtual {v12, v2}, Landroid/media/session/PlaybackState$Builder;->setErrorMessage(Ljava/lang/CharSequence;)Landroid/media/session/PlaybackState$Builder;

    .line 141
    .line 142
    .line 143
    iget-object v2, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A01:Ljava/util/List;

    .line 144
    .line 145
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 146
    .line 147
    .line 148
    move-result-object v7

    .line 149
    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    if-eqz v2, :cond_3

    .line 154
    .line 155
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v6

    .line 159
    check-cast v6, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 160
    .line 161
    iget-object v5, v6, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->A03:Ljava/lang/String;

    .line 162
    .line 163
    iget-object v4, v6, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->A02:Ljava/lang/CharSequence;

    .line 164
    .line 165
    iget v2, v6, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->A00:I

    .line 166
    .line 167
    new-instance v3, Landroid/media/session/PlaybackState$CustomAction$Builder;

    .line 168
    .line 169
    invoke-direct {v3, v5, v4, v2}, Landroid/media/session/PlaybackState$CustomAction$Builder;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 170
    .line 171
    .line 172
    iget-object v2, v6, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->A01:Landroid/os/Bundle;

    .line 173
    .line 174
    invoke-virtual {v3, v2}, Landroid/media/session/PlaybackState$CustomAction$Builder;->setExtras(Landroid/os/Bundle;)Landroid/media/session/PlaybackState$CustomAction$Builder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v3}, Landroid/media/session/PlaybackState$CustomAction$Builder;->build()Landroid/media/session/PlaybackState$CustomAction;

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    invoke-virtual {v12, v2}, Landroid/media/session/PlaybackState$Builder;->addCustomAction(Landroid/media/session/PlaybackState$CustomAction;)Landroid/media/session/PlaybackState$Builder;

    .line 182
    .line 183
    .line 184
    goto :goto_3

    .line 185
    :cond_3
    invoke-virtual {v12, v0, v1}, Landroid/media/session/PlaybackState$Builder;->setActiveQueueItemId(J)Landroid/media/session/PlaybackState$Builder;

    .line 186
    .line 187
    .line 188
    iget-object v0, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A0A:Landroid/os/Bundle;

    .line 189
    .line 190
    invoke-virtual {v12, v0}, Landroid/media/session/PlaybackState$Builder;->setExtras(Landroid/os/Bundle;)Landroid/media/session/PlaybackState$Builder;

    .line 191
    .line 192
    .line 193
    invoke-virtual {v12}, Landroid/media/session/PlaybackState$Builder;->build()Landroid/media/session/PlaybackState;

    .line 194
    .line 195
    .line 196
    move-result-object v6

    .line 197
    iput-object v6, v11, Landroid/support/v4/media/session/PlaybackStateCompat;->A00:Landroid/media/session/PlaybackState;

    .line 198
    .line 199
    :cond_4
    invoke-virtual {v8, v6}, Landroid/media/session/MediaSession;->setPlaybackState(Landroid/media/session/PlaybackState;)V

    .line 200
    .line 201
    .line 202
    return-void

    .line 203
    :catchall_0
    move-exception v0

    .line 204
    :try_start_3
    monitor-exit v9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 205
    throw v0

    .line 206
    :cond_5
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    throw v0

    .line 211
    :cond_6
    return-void
.end method
