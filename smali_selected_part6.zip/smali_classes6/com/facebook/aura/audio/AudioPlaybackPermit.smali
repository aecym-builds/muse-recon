.class public interface abstract Lcom/facebook/aura/audio/AudioPlaybackPermit;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract awaitInvalidation(LX/2M4;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method

.method public abstract awaitPauseRequest(LX/2M4;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method

.method public abstract getAudioUsage()Ljava/lang/Integer;
.end method

.method public abstract getContinuesAfterOwnerEnds()Z
.end method

.method public abstract isValid()Z
.end method

.method public abstract onEnded(Lcom/facebook/aura/audio/AudioPlaybackEndReason;I)V
.end method

.method public abstract onPaused(I)V
.end method

.method public abstract release()V
.end method

.method public abstract startPlaybackIfValid(Lkotlin/jvm/functions/Function0;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation
.end method
