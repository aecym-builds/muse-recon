.class public interface abstract Lcom/facebook/aura/audio/AudioPlaybackAdmissionProvider;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract begin(LX/AHE;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
