.class public final Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;

.field public static final TAG:Ljava/lang/String; = "AudioPlaybackAdmission"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;->INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final begin(LX/AHE;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/AHE;",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p3

    .line 5
    check-cast v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object p2, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    iget v1, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->label:I

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    if-eqz v1, :cond_2

    .line 24
    .line 25
    if-ne v1, v0, :cond_1

    .line 26
    .line 27
    iget p1, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->I$2:I

    .line 28
    .line 29
    iget v3, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->I$1:I

    .line 30
    .line 31
    iget v1, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->I$0:I

    .line 32
    .line 33
    iget-object p0, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->L$3:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p0, [I

    .line 36
    .line 37
    iget-object v4, v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;->L$2:Ljava/lang/Object;

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v4, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;

    .line 41
    .line 42
    invoke-direct {v4, p0, p3}, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry$begin$1;-><init>(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :goto_1
    :try_start_0
    invoke-static {p2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    check-cast p2, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision;
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 50
    .line 51
    instance-of v0, p2, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Pending;

    .line 52
    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    return-object p2

    .line 56
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    throw v0

    .line 61
    :cond_2
    invoke-static {p2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    const/4 v0, 0x0

    .line 65
    new-array p0, v0, [I

    .line 66
    .line 67
    const/4 v3, 0x0

    .line 68
    const/4 p2, 0x0

    .line 69
    const/4 p1, 0x0

    .line 70
    const/4 v1, 0x0

    .line 71
    goto :goto_3

    .line 72
    :cond_3
    instance-of v0, p2, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;

    .line 73
    .line 74
    if-eqz v0, :cond_8

    .line 75
    .line 76
    if-eqz v4, :cond_4

    .line 77
    .line 78
    :goto_2
    move-object p2, v4

    .line 79
    :cond_4
    add-int/lit8 v3, v3, 0x1

    .line 80
    .line 81
    :goto_3
    if-ge v3, p1, :cond_5

    .line 82
    .line 83
    aget v0, p0, v3

    .line 84
    .line 85
    :try_start_1
    invoke-static {v0}, Lcom/facebook/aura/audio/AudioPlaybackAdmissionProviderRegistrationStatic;->provider(I)Lcom/facebook/aura/audio/AudioPlaybackAdmissionProvider;

    .line 86
    .line 87
    .line 88
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    throw v0
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 93
    :catch_0
    move-exception v2

    .line 94
    move-object v4, p2

    .line 95
    goto :goto_4

    .line 96
    :catch_1
    move-exception v2

    .line 97
    :goto_4
    const-string v1, "Audio playback admission provider failed"

    .line 98
    .line 99
    const-string v0, "AudioPlaybackAdmission"

    .line 100
    .line 101
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 102
    .line 103
    .line 104
    const/4 v1, 0x1

    .line 105
    goto :goto_2

    .line 106
    :catch_2
    move-exception v0

    .line 107
    throw v0

    .line 108
    :cond_5
    if-nez p2, :cond_6

    .line 109
    .line 110
    if-eqz v1, :cond_7

    .line 111
    .line 112
    const/4 v0, 0x1

    .line 113
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    const-string v0, "Call-bound playback could not start on this device."

    .line 118
    .line 119
    :goto_5
    new-instance p2, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;

    .line 120
    .line 121
    invoke-direct {p2, v1, v0}, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    :cond_6
    return-object p2

    .line 125
    :cond_7
    const/16 v0, 0x6b

    .line 126
    .line 127
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    const-string v0, "Call-bound playback is unavailable on this device."

    .line 132
    .line 133
    goto :goto_5

    .line 134
    :cond_8
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    throw v0
.end method
