.class public final enum Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

.field public static final enum COMPLETION:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

.field public static final enum INTERVAL:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

.field public static final enum PAUSE:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

.field public static final enum START:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

.field public static final enum STOP:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;


# instance fields
.field public final value:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string/jumbo v1, "start"

    .line 2
    .line 3
    .line 4
    const-string v0, "START"

    .line 5
    .line 6
    new-instance v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 7
    .line 8
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sput-object v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->START:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    const-string v1, "interval"

    .line 15
    .line 16
    const-string v0, "INTERVAL"

    .line 17
    .line 18
    new-instance v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 19
    .line 20
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 21
    .line 22
    .line 23
    sput-object v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->INTERVAL:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 24
    .line 25
    const/4 v2, 0x2

    .line 26
    const-string v1, "pause"

    .line 27
    .line 28
    const-string v0, "PAUSE"

    .line 29
    .line 30
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 31
    .line 32
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    sput-object v5, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->PAUSE:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 36
    .line 37
    const/4 v2, 0x3

    .line 38
    const-string v1, "completion"

    .line 39
    .line 40
    const-string v0, "COMPLETION"

    .line 41
    .line 42
    new-instance v4, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 43
    .line 44
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 45
    .line 46
    .line 47
    sput-object v4, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->COMPLETION:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 48
    .line 49
    const/4 v3, 0x4

    .line 50
    const-string/jumbo v2, "stop"

    .line 51
    .line 52
    .line 53
    const-string v1, "STOP"

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 56
    .line 57
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 58
    .line 59
    .line 60
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->STOP:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 61
    .line 62
    filled-new-array {v7, v6, v5, v4, v0}, [Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->$VALUES:[Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 67
    .line 68
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->$ENTRIES:LX/0vk;

    .line 73
    .line 74
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->value:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->$VALUES:[Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->value:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
