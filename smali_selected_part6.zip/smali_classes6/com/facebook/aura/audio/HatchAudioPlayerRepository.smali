.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion;

.field public static final DEFAULT_PLAYBACK_RATE:F = 1.0f

.field public static final KEY_PLAYBACK_RATE:Ljava/lang/String; = "playback_rate"

.field public static final POSITION_POLL_INTERVAL_MS:J = 0x64L

.field public static final SKIP_DURATION_MS:I = 0x3a98

.field public static final TAG:Ljava/lang/String; = "HatchAudioPlayerRepository"

.field public static volatile activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# instance fields
.field public final _defaultPlaybackRate:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final _dismissedMiniPlayerSourceId:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final _playbackState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackState;",
            ">;"
        }
    .end annotation
.end field

.field public final _positionMs:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public activeRequest:Lcom/facebook/aura/audio/PlaybackRequestKey;

.field public admissionInvalidationJob:LX/Cbu;

.field public volatile artworkBitmap:Landroid/graphics/Bitmap;

.field public final cache:Lcom/facebook/aura/audio/HatchAudioCache;

.field public final context:Landroid/content/Context;

.field public volatile currentVolume:F

.field public final defaultPlaybackRate:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final dismissedMiniPlayerSourceId:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public volatile exoPlayer:LX/EZl;

.field public final generation:Ljava/util/concurrent/atomic/AtomicLong;

.field public handoffRecoveryGeneration:Ljava/lang/Long;

.field public volatile isDucking:Z

.field public liveSessionTakeoverJob:LX/Cbu;

.field public volatile mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

.field public pendingAdmission:Lcom/facebook/aura/audio/PendingAdmission;

.field public playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

.field public volatile playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

.field public final playbackRequests:Lcom/facebook/aura/common/coroutines/SingleFlight;

.field public final playbackState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackState;",
            ">;"
        }
    .end annotation
.end field

.field public final positionMs:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public volatile positionPollJob:LX/Cbu;

.field public volatile readyListener:LX/GoY;

.field public volatile scope:LX/1EL;

.field public final transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

.field public volatile transitionJob:LX/Cbu;

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->Companion:Lcom/facebook/aura/audio/HatchAudioPlayerRepository$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;LX/AHE;)V
    .locals 4

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 268435462
    .line 268435463
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->main:LX/DSR;

    .line 268435464
    .line 268435465
    const/4 v2, 0x0

    .line 268435466
    invoke-static {v0}, LX/8mk;->A12(LX/BqG;)LX/EQC;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 268435471
    .line 268435472
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioCache;

    .line 268435473
    .line 268435474
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioCache;-><init>(Landroid/content/Context;LX/AHE;)V

    .line 268435475
    .line 268435476
    .line 268435477
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cache:Lcom/facebook/aura/audio/HatchAudioCache;

    .line 268435478
    .line 268435479
    invoke-static {v2}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 268435480
    .line 268435481
    .line 268435482
    move-result-object v1

    .line 268435483
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 268435484
    .line 268435485
    new-instance v0, LX/ERk;

    .line 268435486
    .line 268435487
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 268435488
    .line 268435489
    .line 268435490
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackState:LX/2J3;

    .line 268435491
    .line 268435492
    const/4 v3, 0x0

    .line 268435493
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 268435494
    .line 268435495
    .line 268435496
    move-result-object v0

    .line 268435497
    new-instance v1, LX/Ddv;

    .line 268435498
    .line 268435499
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 268435500
    .line 268435501
    .line 268435502
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 268435503
    .line 268435504
    new-instance v0, LX/ERk;

    .line 268435505
    .line 268435506
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 268435507
    .line 268435508
    .line 268435509
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionMs:LX/2J3;

    .line 268435510
    .line 268435511
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getPersistedPlaybackRate()F

    .line 268435512
    .line 268435513
    .line 268435514
    move-result v0

    .line 268435515
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 268435516
    .line 268435517
    .line 268435518
    move-result-object v0

    .line 268435519
    new-instance v1, LX/Ddv;

    .line 268435520
    .line 268435521
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 268435522
    .line 268435523
    .line 268435524
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_defaultPlaybackRate:LX/2J2;

    .line 268435525
    .line 268435526
    new-instance v0, LX/ERk;

    .line 268435527
    .line 268435528
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 268435529
    .line 268435530
    .line 268435531
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->defaultPlaybackRate:LX/2J3;

    .line 268435532
    .line 268435533
    invoke-static {v2}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 268435534
    .line 268435535
    .line 268435536
    move-result-object v1

    .line 268435537
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_dismissedMiniPlayerSourceId:LX/2J2;

    .line 268435538
    .line 268435539
    new-instance v0, LX/ERk;

    .line 268435540
    .line 268435541
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 268435542
    .line 268435543
    .line 268435544
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->dismissedMiniPlayerSourceId:LX/2J3;

    .line 268435545
    .line 268435546
    const-wide/16 v1, 0x0

    .line 268435547
    .line 268435548
    invoke-static {v1, v2}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 268435549
    .line 268435550
    .line 268435551
    move-result-object v0

    .line 268435552
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 268435553
    .line 268435554
    invoke-static {v1, v2}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 268435555
    .line 268435556
    .line 268435557
    move-result-object v0

    .line 268435558
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 268435559
    .line 268435560
    sget-object v0, Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;->INSTANCE:Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;

    .line 268435561
    .line 268435562
    invoke-static {p2, v0, v3}, Lcom/facebook/aura/common/coroutines/SingleFlightKt;->SingleFlight(LX/AHE;Lcom/facebook/aura/common/coroutines/OnDuplicateCall;Z)Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 268435563
    .line 268435564
    .line 268435565
    move-result-object v0

    .line 268435566
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackRequests:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 268435567
    .line 268435568
    const/high16 v0, 0x3f800000    # 1.0f

    .line 268435569
    .line 268435570
    iput v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 268435571
    .line 268435572
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;LX/AHE;LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;-><init>(Landroid/content/Context;LX/AHE;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$beginPlaybackRequest(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/PlaybackRequestKey;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->beginPlaybackRequest(Lcom/facebook/aura/audio/PlaybackRequestKey;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$canStartWhenReady(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Z
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->canStartWhenReady()Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$continueWithoutOwner(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->continueWithoutOwner(Lcom/facebook/aura/audio/AudioPlaybackPermit;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$failPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->failPlayback(J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getActiveInstance$cp()Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getCurrentVolume$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$getExoPlayer$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)LX/EZl;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getGeneration$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Ljava/util/concurrent/atomic/AtomicLong;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getHandoffRecoveryGeneration$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->handoffRecoveryGeneration:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getMediaSessionManager$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Lcom/facebook/aura/audio/HatchMediaSessionManager;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getPlaybackPermit$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Lcom/facebook/aura/audio/AudioPlaybackPermit;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getPlaybackProgressLogger$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getTransitionGeneration$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Ljava/util/concurrent/atomic/AtomicLong;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_playbackState$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_positionMs$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$initMediaSession(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;ILX/EZl;J)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->initMediaSession(Lcom/facebook/aura/audio/HatchAudioItem;ILX/EZl;J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$isCurrentPlayer(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isCurrentPlayer(LX/EZl;J)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$isDucking$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isDucking:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$logPlaybackCompleted(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->logPlaybackCompleted()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$preparePlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;JLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->preparePlayback(Lcom/facebook/aura/audio/HatchAudioItem;JLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$requestPlayInternal(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->requestPlayInternal(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$resolveAdmission(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->resolveAdmission(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$setArtworkBitmap$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Landroid/graphics/Bitmap;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->artworkBitmap:Landroid/graphics/Bitmap;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setDucking$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isDucking:Z

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setHandoffRecoveryGeneration$p(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Ljava/lang/Long;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->handoffRecoveryGeneration:Ljava/lang/Long;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$startForegroundPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;IJ)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startForegroundPlayback(Lcom/facebook/aura/audio/HatchAudioItem;IJ)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$startPositionPolling(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startPositionPolling(J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$stopInternal(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->stopInternal(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$syncMediaSession(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->syncMediaSession()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final beginLoading(Lcom/facebook/aura/audio/HatchAudioItem;)J
    .locals 10

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 3
    .line 4
    .line 5
    move-result-wide v3

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-interface {v0, v2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->release()V

    .line 21
    .line 22
    .line 23
    :cond_1
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 24
    .line 25
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->releasePlayer()V

    .line 26
    .line 27
    .line 28
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 29
    .line 30
    if-ne v0, p0, :cond_2

    .line 31
    .line 32
    sput-object v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 33
    .line 34
    sget-object v1, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->stop(Landroid/content/Context;)V

    .line 39
    .line 40
    .line 41
    :cond_2
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->artworkBitmap:Landroid/graphics/Bitmap;

    .line 42
    .line 43
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 44
    .line 45
    const/4 v8, 0x0

    .line 46
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_dismissedMiniPlayerSourceId:LX/2J2;

    .line 54
    .line 55
    invoke-interface {v0, v2}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 59
    .line 60
    sget-object v7, Lcom/facebook/aura/audio/AudioStatus;->LOADING:Lcom/facebook/aura/audio/AudioStatus;

    .line 61
    .line 62
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getPersistedPlaybackRate()F

    .line 63
    .line 64
    .line 65
    move-result v9

    .line 66
    iget p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 67
    .line 68
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 69
    .line 70
    move-object v6, p1

    .line 71
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;-><init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)V

    .line 72
    .line 73
    .line 74
    invoke-interface {v0, v5}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    return-wide v3
.end method

.method private final beginPlaybackRequest(Lcom/facebook/aura/audio/PlaybackRequestKey;LX/2M4;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/PlaybackRequestKey;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/AudioPlaybackRequestResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v4, p2

    .line 1
    move-object v2, p1

    .line 2
    instance-of v0, p2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;

    .line 3
    .line 4
    move-object v7, p0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    move-object v6, v4

    .line 8
    check-cast v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;

    .line 9
    .line 10
    iget v3, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->label:I

    .line 11
    .line 12
    const/high16 v1, -0x80000000

    .line 13
    .line 14
    and-int v0, v3, v1

    .line 15
    .line 16
    if-eqz v0, :cond_7

    .line 17
    .line 18
    sub-int/2addr v3, v1

    .line 19
    iput v3, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->label:I

    .line 20
    .line 21
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->result:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 24
    .line 25
    iget v0, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->label:I

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    if-eqz v0, :cond_5

    .line 29
    .line 30
    if-ne v0, v1, :cond_8

    .line 31
    .line 32
    iget-object v3, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->L$1:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v3, Lcom/facebook/aura/audio/HatchAudioItem;

    .line 35
    .line 36
    iget-object v2, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->L$0:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v2, Lcom/facebook/aura/audio/PlaybackRequestKey;

    .line 39
    .line 40
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    check-cast v5, Lcom/facebook/aura/audio/ResolvedAdmission;

    .line 44
    .line 45
    instance-of v0, v5, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;

    .line 46
    .line 47
    if-eqz v0, :cond_1

    .line 48
    .line 49
    check-cast v5, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;

    .line 50
    .line 51
    iget-object v2, v5, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;->errorCode:Ljava/lang/String;

    .line 52
    .line 53
    iget-object v1, v5, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;->message:Ljava/lang/String;

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Rejected;

    .line 56
    .line 57
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Rejected;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    return-object v0

    .line 61
    :cond_1
    const-string v0, "null cannot be cast to non-null type com.facebook.aura.audio.ResolvedAdmission.Pending"

    .line 62
    .line 63
    invoke-static {v5, v0}, LX/I1c;->A0g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    check-cast v5, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;

    .line 67
    .line 68
    iget-object v1, v5, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;->admission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 69
    .line 70
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 73
    .line 74
    .line 75
    move-result-wide v8

    .line 76
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 77
    .line 78
    const/4 p2, 0x0

    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-interface {v0, p2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 82
    .line 83
    .line 84
    :cond_2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 85
    .line 86
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 87
    .line 88
    if-eqz v0, :cond_3

    .line 89
    .line 90
    invoke-interface {v0, p2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 91
    .line 92
    .line 93
    :cond_3
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 94
    .line 95
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pendingAdmission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 96
    .line 97
    iget-object v6, v1, Lcom/facebook/aura/audio/PendingAdmission;->permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 98
    .line 99
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 100
    .line 101
    iput-object v6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 102
    .line 103
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeRequest:Lcom/facebook/aura/audio/PlaybackRequestKey;

    .line 104
    .line 105
    invoke-direct {p0, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->beginLoading(Lcom/facebook/aura/audio/HatchAudioItem;)J

    .line 106
    .line 107
    .line 108
    move-result-wide p0

    .line 109
    if-eq v0, v6, :cond_4

    .line 110
    .line 111
    if-eqz v0, :cond_4

    .line 112
    .line 113
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->release()V

    .line 114
    .line 115
    .line 116
    :cond_4
    iget-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 117
    .line 118
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;

    .line 119
    .line 120
    invoke-direct/range {v5 .. v12}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JJLX/2M4;)V

    .line 121
    .line 122
    .line 123
    sget-object v2, LX/39s;->A00:LX/39s;

    .line 124
    .line 125
    sget-object v1, LX/FkO;->A00:Ljava/lang/Integer;

    .line 126
    .line 127
    invoke-static {v1, v2, v5, v0}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    iput-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 132
    .line 133
    iget-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 134
    .line 135
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;

    .line 136
    .line 137
    move-wide v8, p0

    .line 138
    move-object p0, v3

    .line 139
    move-object p1, p2

    .line 140
    invoke-direct/range {v5 .. v11}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$3;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLcom/facebook/aura/audio/HatchAudioItem;LX/2M4;)V

    .line 141
    .line 142
    .line 143
    invoke-static {v1, v2, v5, v0}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    iput-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_5
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    iget-object v3, p1, Lcom/facebook/aura/audio/PlaybackRequestKey;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 154
    .line 155
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeRequest:Lcom/facebook/aura/audio/PlaybackRequestKey;

    .line 156
    .line 157
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    if-eqz v0, :cond_6

    .line 162
    .line 163
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 164
    .line 165
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    if-eqz v0, :cond_6

    .line 170
    .line 171
    :goto_1
    sget-object v0, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;->INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;

    .line 172
    .line 173
    return-object v0

    .line 174
    :cond_6
    iget-object v0, p1, Lcom/facebook/aura/audio/PlaybackRequestKey;->admissionRequest:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

    .line 175
    .line 176
    iput-object p1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->L$0:Ljava/lang/Object;

    .line 177
    .line 178
    iput-object v3, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->L$1:Ljava/lang/Object;

    .line 179
    .line 180
    iput v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;->label:I

    .line 181
    .line 182
    invoke-direct {p0, v0, v6}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->resolveAdmission(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v5

    .line 186
    if-ne v5, v4, :cond_0

    .line 187
    .line 188
    return-object v4

    .line 189
    :cond_7
    new-instance v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;

    .line 190
    .line 191
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/2M4;)V

    .line 192
    .line 193
    .line 194
    goto/16 :goto_0

    .line 195
    .line 196
    :cond_8
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    throw v0
.end method

.method private final canStartWhenReady()Z
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForeground()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->isLiveSessionActive()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 15
    .line 16
    const-class v0, Landroid/media/AudioManager;

    .line 17
    .line 18
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Landroid/media/AudioManager;

    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/media/AudioManager;->getMode()I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    const/4 v0, 0x1

    .line 29
    if-eqz p0, :cond_1

    .line 30
    .line 31
    :cond_0
    const/4 v0, 0x0

    .line 32
    :cond_1
    return v0
.end method

.method private final cancelPendingPlayback(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    invoke-interface {v0}, LX/GPY;->getCurrentPosition()J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    long-to-int v2, v0

    .line 9
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackRequests:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 15
    .line 16
    invoke-interface {v0}, Lcom/facebook/aura/common/coroutines/SingleFlight;->clearAndCancelAll()V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 28
    .line 29
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pendingAdmission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 32
    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 39
    .line 40
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->releasePlayer()V

    .line 41
    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    invoke-interface {v0, p1, v2}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->onEnded(Lcom/facebook/aura/audio/AudioPlaybackEndReason;I)V

    .line 48
    .line 49
    .line 50
    :cond_2
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 51
    .line 52
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeRequest:Lcom/facebook/aura/audio/PlaybackRequestKey;

    .line 53
    .line 54
    return-void

    .line 55
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 56
    .line 57
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    goto :goto_0
.end method

.method public static synthetic cancelPendingPlayback$default(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackEndReason;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p1, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->CANCELLED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 5
    .line 6
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cancelPendingPlayback(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private final continueWithoutOwner(Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    if-ne v0, p1, :cond_2

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 6
    .line 7
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pendingAdmission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 8
    .line 9
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->admissionInvalidationJob:LX/Cbu;

    .line 10
    .line 11
    invoke-interface {p1}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->release()V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 17
    .line 18
    .line 19
    move-result-wide v2

    .line 20
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->handoffRecoveryGeneration:Ljava/lang/Long;

    .line 25
    .line 26
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 27
    .line 28
    if-eqz v3, :cond_0

    .line 29
    .line 30
    sget-object v2, LX/GoR;->A03:LX/GoR;

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    invoke-interface {v3, v2, v0}, LX/GPY;->AdJ(LX/GoR;Z)V

    .line 34
    .line 35
    .line 36
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 37
    .line 38
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 43
    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 47
    .line 48
    :cond_1
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 49
    .line 50
    if-ne v1, v0, :cond_2

    .line 51
    .line 52
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 53
    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->requestAudioFocus()Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const/4 v0, 0x1

    .line 61
    if-ne v1, v0, :cond_3

    .line 62
    .line 63
    :cond_2
    return-void

    .line 64
    :cond_3
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pause()V

    .line 65
    .line 66
    .line 67
    return-void
.end method

.method private final failPlayback(J)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 3
    .line 4
    .line 5
    move-result-wide v1

    .line 6
    cmp-long v0, v1, p1

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->FAILED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 11
    .line 12
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->stopInternal(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method private final getPersistedPlaybackRate()F
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getPrefs()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "playback_rate"

    .line 5
    .line 6
    const/high16 v0, 0x3f800000    # 1.0f

    .line 7
    .line 8
    invoke-interface {p0, v1, v0}, LX/BVu;->getFloat(Ljava/lang/String;F)F

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method private final getPrefs()LX/BVu;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/common/prefs/AuraUserPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraUserPrefs;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    check-cast v0, LX/AHu;

    .line 5
    .line 6
    iget-object v1, v0, LX/AHu;->A01:Ljava/lang/String;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraUserPrefStore;->AUDIO_PLAYER:Lcom/facebook/aura/common/prefs/AuraUserPrefStore;

    .line 9
    .line 10
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/common/prefs/AuraUserPrefs;->get(Ljava/lang/String;Lcom/facebook/aura/common/prefs/AuraUserPrefStoreKey;)LX/BVu;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method private final initMediaSession(Lcom/facebook/aura/audio/HatchAudioItem;ILX/EZl;J)V
    .locals 15

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->release()V

    .line 5
    .line 6
    .line 7
    :cond_0
    new-instance v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;

    .line 8
    .line 9
    move-wide/from16 v0, p4

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    invoke-direct {v2, p0, v3, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$runIfCurrent$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)V

    .line 14
    .line 15
    .line 16
    iget-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 17
    .line 18
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$1;

    .line 19
    .line 20
    invoke-direct {v5, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$1;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 21
    .line 22
    .line 23
    new-instance v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$2;

    .line 24
    .line 25
    invoke-direct {v6, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$2;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 26
    .line 27
    .line 28
    new-instance v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$3;

    .line 29
    .line 30
    invoke-direct {v7, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$3;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 31
    .line 32
    .line 33
    new-instance v8, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;

    .line 34
    .line 35
    invoke-direct {v8, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 36
    .line 37
    .line 38
    new-instance v9, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$5;

    .line 39
    .line 40
    invoke-direct {v9, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$5;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 41
    .line 42
    .line 43
    new-instance v10, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$6;

    .line 44
    .line 45
    invoke-direct {v10, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$6;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 46
    .line 47
    .line 48
    new-instance v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$7;

    .line 49
    .line 50
    invoke-direct {v11, v2, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$7;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 51
    .line 52
    .line 53
    new-instance v12, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$8;

    .line 54
    .line 55
    invoke-direct {v12, v2, p0, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$8;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V

    .line 56
    .line 57
    .line 58
    new-instance v13, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;

    .line 59
    .line 60
    invoke-direct {v13, v2, p0, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;-><init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V

    .line 61
    .line 62
    .line 63
    new-instance v14, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$10;

    .line 64
    .line 65
    invoke-direct {v14, p0, v3, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$10;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)V

    .line 66
    .line 67
    .line 68
    new-instance v3, Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 69
    .line 70
    invoke-direct/range {v3 .. v14}, Lcom/facebook/aura/audio/HatchMediaSessionManager;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 71
    .line 72
    .line 73
    move/from16 v0, p2

    .line 74
    .line 75
    move-object/from16 v1, p1

    .line 76
    .line 77
    invoke-virtual {v3, v1, v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->activate(Lcom/facebook/aura/audio/HatchAudioItem;I)V

    .line 78
    .line 79
    .line 80
    iput-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 81
    .line 82
    return-void
.end method

.method private final isCurrentPlayer(LX/EZl;J)Z
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 3
    .line 4
    .line 5
    move-result-wide v1

    .line 6
    cmp-long v0, v1, p2

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    if-eq v1, p1, :cond_1

    .line 14
    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :cond_1
    return v0
.end method

.method private final loadArtwork(Lcom/facebook/aura/audio/HatchAudioItem;IJ)V
    .locals 4

    .line 0
    iget-object v2, p1, Lcom/facebook/aura/audio/HatchAudioItem;->artworkUrl:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz v2, :cond_0

    .line 3
    .line 4
    move-object v3, p0

    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 6
    .line 7
    const/4 p2, 0x0

    .line 8
    new-instance v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;

    .line 9
    .line 10
    move-wide p0, p3

    .line 11
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$loadArtwork$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method private final logPlaybackCompleted()V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 15
    .line 16
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 17
    .line 18
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->MESSAGE_LIST:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 19
    .line 20
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MAIN_CHAT:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 21
    .line 22
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AUDIO_PLAYER:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->INSTANCE:Lcom/facebook/aura/audio/HatchAudioInteractionLogger;

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->chatPlaybackMetadata(Lcom/facebook/aura/audio/HatchAudioItem;)Ljava/util/Map;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const/4 v7, 0x0

    .line 31
    invoke-virtual/range {v2 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logPlayEnd(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void
.end method

.method private final persistPlaybackRate(F)V
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getPrefs()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v2, "playback_rate"

    .line 9
    .line 10
    invoke-static {p0}, LX/Df3;->A04(LX/Df3;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, LX/Df3;->A00:Ljava/util/Map;

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, LX/Df3;->apply()V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method private final preparePlayback(Lcom/facebook/aura/audio/HatchAudioItem;JLX/2M4;)Ljava/lang/Object;
    .locals 32
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioItem;",
            "J",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-wide/from16 v2, p2

    .line 1
    .line 2
    move-object/from16 v7, p4

    .line 3
    .line 4
    move-object/from16 v1, p1

    .line 5
    .line 6
    instance-of v4, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;

    .line 7
    .line 8
    move-object/from16 v0, p0

    .line 9
    .line 10
    if-eqz v4, :cond_0

    .line 11
    .line 12
    move-object v11, v7

    .line 13
    check-cast v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;

    .line 14
    .line 15
    iget v6, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->label:I

    .line 16
    .line 17
    const/high16 v5, -0x80000000

    .line 18
    .line 19
    and-int v4, v6, v5

    .line 20
    .line 21
    if-eqz v4, :cond_0

    .line 22
    .line 23
    sub-int/2addr v6, v5

    .line 24
    iput v6, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v9, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v10, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v5, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->label:I

    .line 31
    .line 32
    const/4 v6, 0x0

    .line 33
    const/4 v4, 0x1

    .line 34
    if-eqz v5, :cond_1

    .line 35
    .line 36
    if-ne v5, v4, :cond_d

    .line 37
    .line 38
    iget-wide v2, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->J$0:J

    .line 39
    .line 40
    iget-object v1, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->L$0:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, Lcom/facebook/aura/audio/HatchAudioItem;

    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_0
    new-instance v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;

    .line 46
    .line 47
    invoke-direct {v11, v0, v7}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/2M4;)V

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    invoke-static {v9}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iget-object v7, v1, Lcom/facebook/aura/audio/HatchAudioItem;->url:Ljava/lang/String;

    .line 55
    .line 56
    const/16 v5, 0x16

    .line 57
    .line 58
    invoke-static {v5}, LX/000;->A00(I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v15

    .line 62
    invoke-static {v7, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    .line 66
    .line 67
    .line 68
    move-result v17

    .line 69
    move-object v12, v7

    .line 70
    move v13, v4

    .line 71
    move v14, v6

    .line 72
    move/from16 v16, v6

    .line 73
    .line 74
    invoke-virtual/range {v12 .. v17}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    .line 75
    .line 76
    .line 77
    move-result v12

    .line 78
    const-string v8, "https://"

    .line 79
    .line 80
    if-nez v12, :cond_2

    .line 81
    .line 82
    iget-object v5, v1, Lcom/facebook/aura/audio/HatchAudioItem;->url:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v5, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 88
    .line 89
    .line 90
    move-result v18

    .line 91
    move-object v13, v5

    .line 92
    move v14, v4

    .line 93
    move v15, v6

    .line 94
    move-object/from16 v16, v8

    .line 95
    .line 96
    move/from16 v17, v6

    .line 97
    .line 98
    invoke-virtual/range {v13 .. v18}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    const/4 v13, 0x0

    .line 103
    if-eqz v5, :cond_3

    .line 104
    .line 105
    :cond_2
    const/4 v13, 0x1

    .line 106
    :cond_3
    if-eqz v13, :cond_6

    .line 107
    .line 108
    if-eqz v12, :cond_4

    .line 109
    .line 110
    iget-object v7, v1, Lcom/facebook/aura/audio/HatchAudioItem;->url:Ljava/lang/String;

    .line 111
    .line 112
    const/4 v5, 0x7

    .line 113
    invoke-virtual {v7, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v5

    .line 117
    invoke-static {v8, v5}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v9

    .line 121
    goto :goto_1

    .line 122
    :cond_4
    iget-object v9, v1, Lcom/facebook/aura/audio/HatchAudioItem;->url:Ljava/lang/String;

    .line 123
    .line 124
    :goto_1
    :try_start_0
    iget-object v8, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cache:Lcom/facebook/aura/audio/HatchAudioCache;

    .line 125
    .line 126
    iget-object v7, v1, Lcom/facebook/aura/audio/HatchAudioItem;->sourceMessageId:Ljava/lang/String;

    .line 127
    .line 128
    iput-object v1, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->L$0:Ljava/lang/Object;

    .line 129
    .line 130
    const/4 v5, 0x0

    .line 131
    iput-object v5, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->L$1:Ljava/lang/Object;

    .line 132
    .line 133
    iput-wide v2, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->J$0:J

    .line 134
    .line 135
    iput-boolean v12, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->Z$0:Z

    .line 136
    .line 137
    iput v13, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->I$0:I

    .line 138
    .line 139
    iput v4, v11, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$1;->label:I

    .line 140
    .line 141
    invoke-virtual {v8, v9, v7, v11}, Lcom/facebook/aura/audio/HatchAudioCache;->getOrDownload(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v9

    .line 145
    if-ne v9, v10, :cond_5

    .line 146
    .line 147
    return-object v10

    .line 148
    :goto_2
    invoke-static {v9}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :cond_5
    check-cast v9, Ljava/io/File;

    .line 152
    .line 153
    goto :goto_3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 154
    :cond_6
    iget-object v5, v1, Lcom/facebook/aura/audio/HatchAudioItem;->url:Ljava/lang/String;

    .line 155
    .line 156
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 157
    .line 158
    .line 159
    move-result-object v7

    .line 160
    goto :goto_4

    .line 161
    :goto_3
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 162
    .line 163
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 164
    .line 165
    .line 166
    move-result-wide v7

    .line 167
    cmp-long v5, v7, v2

    .line 168
    .line 169
    if-nez v5, :cond_c

    .line 170
    .line 171
    invoke-static {v9}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 172
    .line 173
    .line 174
    move-result-object v7

    .line 175
    :goto_4
    sget-object v5, LX/GYI;->A08:LX/GYI;

    .line 176
    .line 177
    new-instance v5, LX/GXy;

    .line 178
    .line 179
    invoke-direct {v5}, LX/GXy;-><init>()V

    .line 180
    .line 181
    .line 182
    iput-object v7, v5, LX/GXy;->A01:Landroid/net/Uri;

    .line 183
    .line 184
    invoke-virtual {v5}, LX/GXy;->A00()LX/GYI;

    .line 185
    .line 186
    .line 187
    move-result-object v16

    .line 188
    invoke-direct {v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getPersistedPlaybackRate()F

    .line 189
    .line 190
    .line 191
    move-result v14

    .line 192
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 193
    .line 194
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 195
    .line 196
    .line 197
    move-result-wide v7

    .line 198
    cmp-long v5, v7, v2

    .line 199
    .line 200
    if-nez v5, :cond_c

    .line 201
    .line 202
    :try_start_1
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 203
    .line 204
    new-instance v13, LX/IEO;

    .line 205
    .line 206
    invoke-direct {v13, v5, v4}, LX/IEO;-><init>(Ljava/lang/Object;I)V

    .line 207
    .line 208
    .line 209
    const/4 v15, 0x2

    .line 210
    new-instance v12, LX/IEO;

    .line 211
    .line 212
    invoke-direct {v12, v5, v15}, LX/IEO;-><init>(Ljava/lang/Object;I)V

    .line 213
    .line 214
    .line 215
    const/16 v7, 0x8

    .line 216
    .line 217
    new-instance v11, LX/IEO;

    .line 218
    .line 219
    invoke-direct {v11, v5, v7}, LX/IEO;-><init>(Ljava/lang/Object;I)V

    .line 220
    .line 221
    .line 222
    new-instance v10, LX/IEL;

    .line 223
    .line 224
    invoke-direct {v10, v6}, LX/IEL;-><init>(I)V

    .line 225
    .line 226
    .line 227
    const/16 v7, 0x9

    .line 228
    .line 229
    new-instance v9, LX/IEO;

    .line 230
    .line 231
    invoke-direct {v9, v5, v7}, LX/IEO;-><init>(Ljava/lang/Object;I)V

    .line 232
    .line 233
    .line 234
    new-instance v8, LX/IDe;

    .line 235
    .line 236
    invoke-direct {v8, v15}, LX/IDe;-><init>(I)V

    .line 237
    .line 238
    .line 239
    new-instance v25, LX/EZi;

    .line 240
    .line 241
    invoke-direct/range {v25 .. v25}, LX/EZi;-><init>()V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 248
    .line 249
    .line 250
    move-result-object v19

    .line 251
    if-nez v19, :cond_7

    .line 252
    .line 253
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 254
    .line 255
    .line 256
    move-result-object v19

    .line 257
    :cond_7
    sget-object v20, LX/GoR;->A03:LX/GoR;

    .line 258
    .line 259
    sget-object v24, LX/EZ4;->A03:LX/EZ4;

    .line 260
    .line 261
    sget-object v23, LX/EbI;->A03:LX/EbI;

    .line 262
    .line 263
    const v27, 0x3f7851ec    # 0.97f

    .line 264
    .line 265
    .line 266
    const v28, 0x3f83d70a    # 1.03f

    .line 267
    .line 268
    .line 269
    const-wide/16 v31, 0x3e8

    .line 270
    .line 271
    const v29, 0x33d6bf95    # 1.0E-7f

    .line 272
    .line 273
    .line 274
    const-wide/16 p1, 0x4e20

    .line 275
    .line 276
    const-wide/32 p3, 0x7a120

    .line 277
    .line 278
    .line 279
    const v30, 0x3f7fbe77    # 0.999f

    .line 280
    .line 281
    .line 282
    new-instance v22, LX/GYX;

    .line 283
    .line 284
    move-object/from16 v26, v22

    .line 285
    .line 286
    invoke-direct/range {v26 .. v36}, LX/GYX;-><init>(FFFFJJJ)V

    .line 287
    .line 288
    .line 289
    sget-object v21, LX/EcJ;->A00:LX/EcJ;

    .line 290
    .line 291
    sget p0, LX/EyQ;->A00:I

    .line 292
    .line 293
    new-instance v7, LX/GnY;

    .line 294
    .line 295
    move-object/from16 v28, v10

    .line 296
    .line 297
    move-object/from16 v29, v12

    .line 298
    .line 299
    move-object/from16 v30, v13

    .line 300
    .line 301
    move-object/from16 v31, v11

    .line 302
    .line 303
    move-object/from16 v26, v8

    .line 304
    .line 305
    move-object/from16 v27, v9

    .line 306
    .line 307
    move-object/from16 v18, v5

    .line 308
    .line 309
    move-object/from16 v17, v7

    .line 310
    .line 311
    invoke-direct/range {v17 .. v32}, LX/GnY;-><init>(Landroid/content/Context;Landroid/os/Looper;LX/GoR;LX/EcJ;LX/EZL;LX/EbI;LX/EZ4;LX/EZi;Lcom/google/common/base/Function;Lcom/google/common/base/Supplier;Lcom/google/common/base/Supplier;Lcom/google/common/base/Supplier;Lcom/google/common/base/Supplier;Lcom/google/common/base/Supplier;I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 312
    .line 313
    .line 314
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 315
    .line 316
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 317
    .line 318
    .line 319
    move-result-wide v8

    .line 320
    cmp-long v5, v8, v2

    .line 321
    .line 322
    if-eqz v5, :cond_8

    .line 323
    .line 324
    invoke-virtual {v7}, LX/GnY;->release()V

    .line 325
    .line 326
    .line 327
    goto/16 :goto_7

    .line 328
    .line 329
    :cond_8
    iput-object v7, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 330
    .line 331
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 332
    .line 333
    if-eqz v5, :cond_9

    .line 334
    .line 335
    invoke-interface {v5}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->getAudioUsage()Ljava/lang/Integer;

    .line 336
    .line 337
    .line 338
    move-result-object v5

    .line 339
    if-eqz v5, :cond_9

    .line 340
    .line 341
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 342
    .line 343
    .line 344
    move-result v8

    .line 345
    new-instance v5, LX/GoR;

    .line 346
    .line 347
    invoke-direct {v5, v4, v8}, LX/GoR;-><init>(II)V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v7, v5, v6}, LX/GnY;->AdJ(LX/GoR;Z)V

    .line 351
    .line 352
    .line 353
    :cond_9
    iget-object v6, v1, Lcom/facebook/aura/audio/HatchAudioItem;->audioType:Ljava/lang/String;

    .line 354
    .line 355
    const/16 v5, 0xf

    .line 356
    .line 357
    invoke-static {v5}, LX/601;->A00(I)Ljava/lang/String;

    .line 358
    .line 359
    .line 360
    move-result-object v5

    .line 361
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 362
    .line 363
    .line 364
    move-result v5

    .line 365
    if-eqz v5, :cond_a

    .line 366
    .line 367
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;

    .line 368
    .line 369
    invoke-direct {v5, v0, v7, v2, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)V

    .line 370
    .line 371
    .line 372
    new-instance v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 373
    .line 374
    invoke-direct {v6, v7, v1, v5}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;-><init>(LX/EZl;Lcom/facebook/aura/audio/HatchAudioItem;Lkotlin/jvm/functions/Function0;)V

    .line 375
    .line 376
    .line 377
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 378
    .line 379
    invoke-virtual {v6, v5}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->start(LX/1EL;)V

    .line 380
    .line 381
    .line 382
    iput-object v6, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 383
    .line 384
    :cond_a
    new-instance v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;

    .line 385
    .line 386
    move-object v8, v5

    .line 387
    move-object v9, v0

    .line 388
    move-wide v10, v2

    .line 389
    move-object v12, v7

    .line 390
    move-object v13, v1

    .line 391
    invoke-direct/range {v8 .. v14}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/EZl;Lcom/facebook/aura/audio/HatchAudioItem;F)V

    .line 392
    .line 393
    .line 394
    iput-object v5, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->readyListener:LX/GoY;

    .line 395
    .line 396
    :try_start_2
    iget-object v1, v7, LX/GnY;->A0j:LX/Gnf;

    .line 397
    .line 398
    invoke-virtual {v1, v5}, LX/Gnf;->A04(Ljava/lang/Object;)V

    .line 399
    .line 400
    .line 401
    invoke-static/range {v16 .. v16}, Lcom/google/common/collect/ImmutableList;->of(Ljava/lang/Object;)Lcom/google/common/collect/ImmutableList;

    .line 402
    .line 403
    .line 404
    move-result-object v9

    .line 405
    invoke-static {v7}, LX/GnY;->A0M(LX/GnY;)V

    .line 406
    .line 407
    .line 408
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 409
    .line 410
    .line 411
    move-result-object v8

    .line 412
    const/4 v6, 0x0

    .line 413
    :goto_5
    invoke-virtual {v9}, Ljava/util/AbstractCollection;->size()I

    .line 414
    .line 415
    .line 416
    move-result v1

    .line 417
    if-ge v6, v1, :cond_b

    .line 418
    .line 419
    iget-object v5, v7, LX/GnY;->A0r:LX/GZH;

    .line 420
    .line 421
    invoke-interface {v9, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 422
    .line 423
    .line 424
    move-result-object v1

    .line 425
    check-cast v1, LX/GYI;

    .line 426
    .line 427
    invoke-interface {v5, v1}, LX/GZH;->A80(LX/GYI;)LX/Gck;

    .line 428
    .line 429
    .line 430
    move-result-object v1

    .line 431
    invoke-virtual {v8, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 432
    .line 433
    .line 434
    add-int/lit8 v6, v6, 0x1

    .line 435
    .line 436
    goto :goto_5

    .line 437
    :cond_b
    invoke-static {v7, v8, v4}, LX/GnY;->A0S(LX/GnY;Ljava/util/List;Z)V

    .line 438
    .line 439
    .line 440
    const/high16 v4, 0x3f800000    # 1.0f

    .line 441
    .line 442
    new-instance v1, LX/EbE;

    .line 443
    .line 444
    invoke-direct {v1, v14, v4}, LX/EbE;-><init>(FF)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v7, v1}, LX/GnY;->AeW(LX/EbE;)V

    .line 448
    .line 449
    .line 450
    iget v1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 451
    .line 452
    invoke-virtual {v7, v1}, LX/GnY;->Afj(F)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {v7}, LX/GnY;->prepare()V

    .line 456
    .line 457
    .line 458
    goto :goto_7
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 459
    :catch_0
    move-exception v4

    .line 460
    instance-of v1, v4, Ljava/util/concurrent/CancellationException;

    .line 461
    .line 462
    if-nez v1, :cond_e

    .line 463
    .line 464
    goto :goto_6

    .line 465
    :catch_1
    move-exception v4

    .line 466
    instance-of v1, v4, Ljava/util/concurrent/CancellationException;

    .line 467
    .line 468
    if-nez v1, :cond_e

    .line 469
    .line 470
    :goto_6
    invoke-direct {v0, v2, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->failPlayback(J)V

    .line 471
    .line 472
    .line 473
    :cond_c
    :goto_7
    sget-object v10, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 474
    .line 475
    return-object v10

    .line 476
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 477
    .line 478
    .line 479
    move-result-object v4

    .line 480
    :cond_e
    throw v4
.end method

.method private final releasePlayer()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->STOP:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 5
    .line 6
    invoke-virtual {v1, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->finish(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V

    .line 7
    .line 8
    .line 9
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->detach()V

    .line 14
    .line 15
    .line 16
    :cond_1
    const/4 v2, 0x0

    .line 17
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 18
    .line 19
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 20
    .line 21
    if-eqz v1, :cond_3

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->readyListener:LX/GoY;

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    invoke-interface {v1, v0}, LX/GPY;->AbJ(LX/GoY;)V

    .line 28
    .line 29
    .line 30
    :cond_2
    invoke-interface {v1}, LX/EZl;->release()V

    .line 31
    .line 32
    .line 33
    :cond_3
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->readyListener:LX/GoY;

    .line 34
    .line 35
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 36
    .line 37
    return-void
.end method

.method private final requestPlayInternal(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioItem;",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/AudioPlaybackRequestResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v8, p1

    .line 1
    .line 2
    move-object/from16 v3, p3

    .line 3
    .line 4
    instance-of v0, v3, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;

    .line 5
    .line 6
    move-object/from16 v7, p0

    .line 7
    .line 8
    if-eqz v0, :cond_3

    .line 9
    .line 10
    move-object v6, v3

    .line 11
    check-cast v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;

    .line 12
    .line 13
    iget v2, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v2, v1

    .line 18
    .line 19
    if-eqz v0, :cond_3

    .line 20
    .line 21
    sub-int/2addr v2, v1

    .line 22
    iput v2, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v0, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->label:I

    .line 29
    .line 30
    const/4 v4, 0x1

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    if-ne v0, v4, :cond_6

    .line 34
    .line 35
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    check-cast v1, Lcom/facebook/aura/common/coroutines/SingleFlightResult;

    .line 39
    .line 40
    instance-of v0, v1, Lcom/facebook/aura/common/coroutines/SingleFlightResult$Result;

    .line 41
    .line 42
    if-eqz v0, :cond_4

    .line 43
    .line 44
    check-cast v1, Lcom/facebook/aura/common/coroutines/SingleFlightResult$Result;

    .line 45
    .line 46
    iget-object v2, v1, Lcom/facebook/aura/common/coroutines/SingleFlightResult$Result;->value:Ljava/lang/Object;

    .line 47
    .line 48
    return-object v2

    .line 49
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v0, v8, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_2

    .line 59
    .line 60
    sget-object v1, Lcom/facebook/aura/gateway/JarvisUtils;->INSTANCE:Lcom/facebook/aura/gateway/JarvisUtils;

    .line 61
    .line 62
    iget-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 63
    .line 64
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/JarvisUtils;->getSelectedAssistantName(LX/AHE;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v13

    .line 68
    const/16 p0, 0x1fef

    .line 69
    .line 70
    const/4 v9, 0x0

    .line 71
    move-object v10, v9

    .line 72
    move-object v11, v9

    .line 73
    move-object v12, v9

    .line 74
    move-object v14, v9

    .line 75
    move-object v15, v9

    .line 76
    move-object/from16 v16, v9

    .line 77
    .line 78
    move-object/from16 v17, v9

    .line 79
    .line 80
    move-object/from16 v18, v9

    .line 81
    .line 82
    move-object/from16 v19, v9

    .line 83
    .line 84
    move-object/from16 v20, v9

    .line 85
    .line 86
    move-object/from16 v21, v9

    .line 87
    .line 88
    move-object/from16 p1, v9

    .line 89
    .line 90
    invoke-static/range {v8 .. v23}, Lcom/facebook/aura/audio/HatchAudioItem;->copy$default(Lcom/facebook/aura/audio/HatchAudioItem;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/analytics/hatch/HatchAudioPlaybackEntryPoint;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/audio/HatchAudioItem;

    .line 91
    .line 92
    .line 93
    move-result-object v8

    .line 94
    :cond_2
    new-instance v3, Lcom/facebook/aura/audio/PlaybackRequestKey;

    .line 95
    .line 96
    move-object/from16 v0, p2

    .line 97
    .line 98
    invoke-direct {v3, v8, v0}, Lcom/facebook/aura/audio/PlaybackRequestKey;-><init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;)V

    .line 99
    .line 100
    .line 101
    iget-object v2, v7, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackRequests:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 102
    .line 103
    const/4 v1, 0x0

    .line 104
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$result$1;

    .line 105
    .line 106
    invoke-direct {v0, v7, v3, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$result$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/PlaybackRequestKey;LX/2M4;)V

    .line 107
    .line 108
    .line 109
    iput-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->L$0:Ljava/lang/Object;

    .line 110
    .line 111
    iput-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->L$1:Ljava/lang/Object;

    .line 112
    .line 113
    iput-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->L$2:Ljava/lang/Object;

    .line 114
    .line 115
    iput-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->L$3:Ljava/lang/Object;

    .line 116
    .line 117
    iput v4, v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;->label:I

    .line 118
    .line 119
    invoke-interface {v2, v3, v0, v6}, Lcom/facebook/aura/common/coroutines/SingleFlight;->invoke(Ljava/lang/Object;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    if-ne v1, v5, :cond_0

    .line 124
    .line 125
    return-object v5

    .line 126
    :cond_3
    new-instance v6, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;

    .line 127
    .line 128
    invoke-direct {v6, v7, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlayInternal$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/2M4;)V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_4
    sget-object v0, Lcom/facebook/aura/common/coroutines/SingleFlightResult$Skipped;->INSTANCE:Lcom/facebook/aura/common/coroutines/SingleFlightResult$Skipped;

    .line 133
    .line 134
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_5

    .line 139
    .line 140
    const-string v1, "playback_cancelled"

    .line 141
    .line 142
    const-string v0, "Playback was cancelled."

    .line 143
    .line 144
    new-instance v2, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Rejected;

    .line 145
    .line 146
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Rejected;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    return-object v2

    .line 150
    :cond_5
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    throw v0

    .line 155
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    throw v0
.end method

.method private final resolveAdmission(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/ResolvedAdmission;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v2, :cond_6

    .line 28
    .line 29
    iget-object p1, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->L$0:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

    .line 32
    .line 33
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision;

    .line 37
    .line 38
    instance-of v0, v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;

    .line 39
    .line 40
    if-eqz v0, :cond_4

    .line 41
    .line 42
    check-cast v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;

    .line 43
    .line 44
    iget-object v2, v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;->errorCode:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v1, v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Rejected;->message:Ljava/lang/String;

    .line 47
    .line 48
    new-instance v0, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;

    .line 49
    .line 50
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/audio/ResolvedAdmission$Rejected;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-object v0

    .line 54
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pendingAdmission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 58
    .line 59
    if-eqz v1, :cond_2

    .line 60
    .line 61
    iget-object v0, v1, Lcom/facebook/aura/audio/PendingAdmission;->key:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

    .line 62
    .line 63
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_2

    .line 68
    .line 69
    iget-object v0, v1, Lcom/facebook/aura/audio/PendingAdmission;->permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 70
    .line 71
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->isValid()Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_2

    .line 76
    .line 77
    new-instance v0, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;

    .line 78
    .line 79
    invoke-direct {v0, v1}, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;-><init>(Lcom/facebook/aura/audio/PendingAdmission;)V

    .line 80
    .line 81
    .line 82
    return-object v0

    .line 83
    :cond_2
    sget-object v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;->INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;

    .line 84
    .line 85
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 86
    .line 87
    iput-object p1, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->L$0:Ljava/lang/Object;

    .line 88
    .line 89
    iput v2, v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;->label:I

    .line 90
    .line 91
    invoke-virtual {v1, v0, p1, v4}, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRegistry;->begin(LX/AHE;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    if-ne v1, v3, :cond_0

    .line 96
    .line 97
    return-object v3

    .line 98
    :cond_3
    new-instance v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;

    .line 99
    .line 100
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$resolveAdmission$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/2M4;)V

    .line 101
    .line 102
    .line 103
    goto :goto_0

    .line 104
    :cond_4
    instance-of v0, v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Pending;

    .line 105
    .line 106
    if-eqz v0, :cond_5

    .line 107
    .line 108
    check-cast v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Pending;

    .line 109
    .line 110
    iget-object v0, v1, Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision$Pending;->permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 111
    .line 112
    new-instance v1, Lcom/facebook/aura/audio/PendingAdmission;

    .line 113
    .line 114
    invoke-direct {v1, p1, v0}, Lcom/facebook/aura/audio/PendingAdmission;-><init>(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;Lcom/facebook/aura/audio/AudioPlaybackPermit;)V

    .line 115
    .line 116
    .line 117
    new-instance v0, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;

    .line 118
    .line 119
    invoke-direct {v0, v1}, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;-><init>(Lcom/facebook/aura/audio/PendingAdmission;)V

    .line 120
    .line 121
    .line 122
    return-object v0

    .line 123
    :cond_5
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    throw v0

    .line 128
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    throw v0
.end method

.method private final startForegroundPlayback(Lcom/facebook/aura/audio/HatchAudioItem;IJ)V
    .locals 4

    .line 0
    sput-object p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 5
    .line 6
    iget-object v1, p1, Lcom/facebook/aura/audio/HatchAudioItem;->title:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->start(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->loadArtwork(Lcom/facebook/aura/audio/HatchAudioItem;IJ)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method private final startPlayback(LX/EZl;JZ)Z
    .locals 3

    .line 0
    new-instance v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;

    .line 1
    .line 2
    invoke-direct {v1, p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    invoke-interface {v0, v1}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->startPlaybackIfValid(Lkotlin/jvm/functions/Function0;)Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    :goto_0
    if-nez v2, :cond_0

    .line 14
    .line 15
    if-nez p4, :cond_2

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 18
    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->isValid()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v0, 0x1

    .line 26
    if-ne v1, v0, :cond_2

    .line 27
    .line 28
    :cond_0
    return v2

    .line 29
    :cond_1
    invoke-virtual {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPlayback$start$1;->invoke()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    invoke-direct {p0, p2, p3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->failPlayback(J)V

    .line 39
    .line 40
    .line 41
    return v2
.end method

.method public static synthetic startPlayback$default(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;JZILjava/lang/Object;)Z
    .locals 1

    .line 0
    invoke-static {p5, p4}, LX/EYv;->A1V(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-direct {p0, p1, p2, p3, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startPlayback(LX/EZl;JZ)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method private final startPositionPolling(J)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0, v2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;

    .line 11
    .line 12
    invoke-direct {v0, p0, p1, p2, v2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 20
    .line 21
    return-void
.end method

.method private final stopInternal(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V
    .locals 3

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cancelPendingPlayback(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-interface {v0, v2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionPollJob:LX/Cbu;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->release()V

    .line 23
    .line 24
    .line 25
    :cond_1
    iput-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 26
    .line 27
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->releasePlayer()V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 31
    .line 32
    invoke-interface {v0, v2}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 36
    .line 37
    invoke-static {}, LX/002;->A0r()Ljava/lang/Integer;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 45
    .line 46
    if-ne v0, p0, :cond_2

    .line 47
    .line 48
    sput-object v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 49
    .line 50
    sget-object v1, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 51
    .line 52
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->stop(Landroid/content/Context;)V

    .line 55
    .line 56
    .line 57
    :cond_2
    return-void
.end method

.method public static synthetic stopInternal$default(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackEndReason;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p1, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->CANCELLED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 5
    .line 6
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->stopInternal(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private final syncMediaSession()V
    .locals 9

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 7
    .line 8
    if-eqz v2, :cond_1

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 15
    .line 16
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->updatePlaybackState(Lcom/facebook/aura/audio/HatchAudioPlaybackState;I)V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 28
    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 32
    .line 33
    .line 34
    move-result-object v8

    .line 35
    if-eqz v8, :cond_1

    .line 36
    .line 37
    sget-object v3, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 38
    .line 39
    iget-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->context:Landroid/content/Context;

    .line 40
    .line 41
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 42
    .line 43
    iget-object v5, v0, Lcom/facebook/aura/audio/HatchAudioItem;->title:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v6, v0, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v1, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 48
    .line 49
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 50
    .line 51
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v7

    .line 55
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->artworkBitmap:Landroid/graphics/Bitmap;

    .line 56
    .line 57
    invoke-virtual/range {v3 .. v9}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->updateNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)V

    .line 58
    .line 59
    .line 60
    :cond_1
    return-void
.end method

.method private final updateStatus(Lcom/facebook/aura/audio/AudioStatus;)V
    .locals 8

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 7
    .line 8
    if-eqz v2, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 11
    .line 12
    iget-object v3, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 13
    .line 14
    iget v5, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 15
    .line 16
    iget v6, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 17
    .line 18
    iget v7, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 19
    .line 20
    move-object v4, p1

    .line 21
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->copy(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->syncMediaSession()V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void
.end method


# virtual methods
.method public final cancelLiveSessionTakeover()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->liveSessionTakeoverJob:LX/Cbu;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    if-eqz v1, :cond_0

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->liveSessionTakeoverJob:LX/Cbu;

    .line 9
    .line 10
    return-void
.end method

.method public clearUserData()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 3
    .line 4
    .line 5
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->STOP:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->finishLastObservation(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    invoke-static {}, LX/EYt;->A0E()Landroid/os/Handler;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$clearUserData$1;

    .line 19
    .line 20
    invoke-direct {v0, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$clearUserData$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cache:Lcom/facebook/aura/audio/HatchAudioCache;

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchAudioCache;->cancelDownloads()V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cache:Lcom/facebook/aura/audio/HatchAudioCache;

    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchAudioCache;->clear()V

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    invoke-static {v0, v1}, LX/EPV;->A02(Ljava/util/concurrent/CancellationException;LX/1EL;)V

    .line 40
    .line 41
    .line 42
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->main:LX/DSR;

    .line 43
    .line 44
    invoke-static {v0}, LX/8mk;->A12(LX/BqG;)LX/EQC;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 49
    .line 50
    return-void
.end method

.method public final dismissMiniPlayer()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_dismissedMiniPlayerSourceId:LX/2J2;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 3
    .line 4
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioItem;->sourceMessageId:Ljava/lang/String;

    .line 17
    .line 18
    :goto_0
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    goto :goto_0
.end method

.method public final endLiveSessionThenPlay(Lkotlin/jvm/functions/Function0;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cancelLiveSessionTakeover()V

    .line 5
    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/livesession/api/LiveSessions;->INSTANCE:Lcom/facebook/aura/livesession/api/LiveSessions;

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Lcom/facebook/aura/livesession/api/LiveSessions;->forSession(LX/AHE;)Lcom/facebook/aura/livesession/api/LiveSession;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    if-nez v3, :cond_0

    .line 16
    .line 17
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    iput-boolean v2, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 26
    .line 27
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;

    .line 31
    .line 32
    invoke-direct {v0, v3, p1, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;-><init>(Lcom/facebook/aura/livesession/api/LiveSession;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0, v2}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->liveSessionTakeoverJob:LX/Cbu;

    .line 40
    .line 41
    return-void
.end method

.method public final getCanResumeWithinLiveSession()Z
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 11
    .line 12
    :goto_0
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PAUSED:Lcom/facebook/aura/audio/AudioStatus;

    .line 13
    .line 14
    if-ne v1, v0, :cond_1

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->isValid()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/4 v0, 0x1

    .line 25
    if-ne v1, v0, :cond_1

    .line 26
    .line 27
    return v0

    .line 28
    :cond_0
    const/4 v1, 0x0

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    const/4 v0, 0x0

    .line 31
    return v0
.end method

.method public final getDefaultPlaybackRate()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->defaultPlaybackRate:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDismissedMiniPlayerSourceId()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->dismissedMiniPlayerSourceId:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlaybackState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPositionMs()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->positionMs:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0

    .line 9
    :cond_0
    const/4 p0, 0x0

    .line 10
    return-object p0
.end method

.method public final isLiveSessionActive()Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/livesession/api/LiveSessions;->INSTANCE:Lcom/facebook/aura/livesession/api/LiveSessions;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/livesession/api/LiveSessions;->isActive(LX/AHE;)LX/2J3;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, LX/3Rq;->A1W(LX/2J3;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public final pause()V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 1
    .line 2
    if-eqz v4, :cond_0

    .line 3
    .line 4
    move-object v2, v4

    .line 5
    check-cast v2, LX/GnY;

    .line 6
    .line 7
    invoke-static {v2}, LX/GRc;->A05(LX/GnY;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 14
    .line 15
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 24
    .line 25
    :goto_0
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 26
    .line 27
    if-ne v1, v0, :cond_0

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-static {v2}, LX/GnY;->A0M(LX/GnY;)V

    .line 31
    .line 32
    .line 33
    const/4 v0, 0x1

    .line 34
    invoke-static {v2, v0, v1}, LX/GnY;->A0O(LX/GnY;IZ)V

    .line 35
    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PAUSED:Lcom/facebook/aura/audio/AudioStatus;

    .line 38
    .line 39
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->updateStatus(Lcom/facebook/aura/audio/AudioStatus;)V

    .line 40
    .line 41
    .line 42
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 43
    .line 44
    if-eqz v3, :cond_0

    .line 45
    .line 46
    invoke-interface {v4}, LX/GPY;->getCurrentPosition()J

    .line 47
    .line 48
    .line 49
    move-result-wide v1

    .line 50
    long-to-int v0, v1

    .line 51
    invoke-interface {v3, v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->onPaused(I)V

    .line 52
    .line 53
    .line 54
    :cond_0
    return-void

    .line 55
    :cond_1
    const/4 v1, 0x0

    .line 56
    goto :goto_0
.end method

.method public final play(Lcom/facebook/aura/audio/HatchAudioItem;)V
    .locals 17

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->CANCELLED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 7
    .line 8
    move-object/from16 v2, p0

    .line 9
    .line 10
    invoke-direct {v2, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->cancelPendingPlayback(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, v3, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/gateway/JarvisUtils;->INSTANCE:Lcom/facebook/aura/gateway/JarvisUtils;

    .line 22
    .line 23
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->userSession:LX/AHE;

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/JarvisUtils;->getSelectedAssistantName(LX/AHE;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v8

    .line 29
    const/16 p0, 0x1fef

    .line 30
    .line 31
    const/4 v4, 0x0

    .line 32
    move-object v5, v4

    .line 33
    move-object v6, v4

    .line 34
    move-object v7, v4

    .line 35
    move-object v9, v4

    .line 36
    move-object v10, v4

    .line 37
    move-object v11, v4

    .line 38
    move-object v12, v4

    .line 39
    move-object v13, v4

    .line 40
    move-object v14, v4

    .line 41
    move-object v15, v4

    .line 42
    move-object/from16 v16, v4

    .line 43
    .line 44
    move-object/from16 p1, v4

    .line 45
    .line 46
    invoke-static/range {v3 .. v18}, Lcom/facebook/aura/audio/HatchAudioItem;->copy$default(Lcom/facebook/aura/audio/HatchAudioItem;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/analytics/hatch/HatchAudioPlaybackEntryPoint;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/audio/HatchAudioItem;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    :cond_0
    invoke-direct {v2, v3}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->beginLoading(Lcom/facebook/aura/audio/HatchAudioItem;)J

    .line 51
    .line 52
    .line 53
    move-result-wide v6

    .line 54
    iget-object v1, v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->scope:LX/1EL;

    .line 55
    .line 56
    const/4 v8, 0x0

    .line 57
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$play$1;

    .line 58
    .line 59
    move-object v5, v3

    .line 60
    move-object v3, v0

    .line 61
    move-object v4, v2

    .line 62
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$play$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;JLX/2M4;)V

    .line 63
    .line 64
    .line 65
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iput-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionJob:LX/Cbu;

    .line 70
    .line 71
    return-void
.end method

.method public final requestPlay(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioItem;",
            "Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/AudioPlaybackRequestResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    sget-object v2, Lcom/facebook/aura/executors/AuraDispatchers;->main:LX/DSR;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlay$2;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, p2, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$requestPlay$2;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;LX/2M4;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p3, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final resume()V
    .locals 8

    .line 0
    move-object v3, p0

    .line 1
    iget-object v6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 2
    .line 3
    if-eqz v6, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 8
    .line 9
    .line 10
    move-result-wide v7

    .line 11
    iget-object v0, v3, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 12
    .line 13
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 18
    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    iget-object v1, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PAUSED:Lcom/facebook/aura/audio/AudioStatus;

    .line 24
    .line 25
    if-ne v1, v0, :cond_1

    .line 26
    .line 27
    iget-object v0, v3, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    iget-object v4, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 32
    .line 33
    iget v5, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 34
    .line 35
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->initMediaSession(Lcom/facebook/aura/audio/HatchAudioItem;ILX/EZl;J)V

    .line 36
    .line 37
    .line 38
    :cond_0
    iget-object v0, v3, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 39
    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    invoke-direct {v3, v6, v7, p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startPlayback(LX/EZl;JZ)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-nez v0, :cond_3

    .line 48
    .line 49
    :cond_1
    return-void

    .line 50
    :cond_2
    iget-object v0, v3, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 51
    .line 52
    if-eqz v0, :cond_1

    .line 53
    .line 54
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->requestAudioFocus()Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    const/4 v0, 0x1

    .line 59
    if-ne v1, v0, :cond_1

    .line 60
    .line 61
    check-cast v6, LX/GnY;

    .line 62
    .line 63
    invoke-static {v6}, LX/GnY;->A0M(LX/GnY;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v6, v0, v0}, LX/GnY;->A0O(LX/GnY;IZ)V

    .line 67
    .line 68
    .line 69
    :cond_3
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 70
    .line 71
    invoke-direct {v3, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->updateStatus(Lcom/facebook/aura/audio/AudioStatus;)V

    .line 72
    .line 73
    .line 74
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 75
    .line 76
    if-eq v0, v3, :cond_4

    .line 77
    .line 78
    iget-object v1, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 79
    .line 80
    iget v0, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 81
    .line 82
    invoke-direct {v3, v1, v0, v7, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startForegroundPlayback(Lcom/facebook/aura/audio/HatchAudioItem;IJ)V

    .line 83
    .line 84
    .line 85
    :cond_4
    invoke-direct {v3, v7, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startPositionPolling(J)V

    .line 86
    .line 87
    .line 88
    return-void
.end method

.method public final seekTo(I)V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 1
    .line 2
    if-eqz v4, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    iget v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 16
    .line 17
    invoke-static {p1, v1, v0}, LX/34j;->A05(III)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    int-to-long v1, v3

    .line 22
    check-cast v4, LX/GRc;

    .line 23
    .line 24
    invoke-interface {v4}, LX/GPY;->AEd()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-virtual {v4, v1, v2, v0}, LX/GRc;->A0T(JI)V

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 32
    .line 33
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->syncMediaSession()V

    .line 41
    .line 42
    .line 43
    :cond_0
    return-void
.end method

.method public final setPlaybackRate(F)V
    .locals 9

    .line 0
    move v7, p1

    .line 1
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->persistPlaybackRate(F)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_defaultPlaybackRate:LX/2J2;

    .line 5
    .line 6
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 18
    .line 19
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    check-cast v3, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 24
    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    const/high16 v1, 0x3f800000    # 1.0f

    .line 28
    .line 29
    new-instance v0, LX/EbE;

    .line 30
    .line 31
    invoke-direct {v0, p1, v1}, LX/EbE;-><init>(FF)V

    .line 32
    .line 33
    .line 34
    invoke-interface {v2, v0}, LX/GPY;->AeW(LX/EbE;)V

    .line 35
    .line 36
    .line 37
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 38
    .line 39
    iget-object v4, v3, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 40
    .line 41
    iget-object v5, v3, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 42
    .line 43
    iget v6, v3, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 44
    .line 45
    iget v8, v3, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->volume:F

    .line 46
    .line 47
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->copy(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->syncMediaSession()V

    .line 55
    .line 56
    .line 57
    :cond_0
    return-void
.end method

.method public final setVolume(F)V
    .locals 6

    .line 0
    const/4 v1, 0x0

    .line 1
    const/high16 v0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    invoke-static {p1, v1, v0}, LX/34j;->A04(FFF)F

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    iput p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 10
    .line 11
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    check-cast v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 16
    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-interface {v0, p1}, LX/GPY;->Afj(F)V

    .line 24
    .line 25
    .line 26
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 27
    .line 28
    iget-object v3, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 29
    .line 30
    iget-object v4, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 31
    .line 32
    iget v5, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->durationMs:I

    .line 33
    .line 34
    iget p0, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->playbackRate:F

    .line 35
    .line 36
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->copy(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    return-void
.end method

.method public final skipBackward()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    add-int/lit16 v0, v0, -0x3a98

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->seekTo(I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final skipForward()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    add-int/lit16 v0, v0, 0x3a98

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->seekTo(I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final stop()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->STOPPED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->stopInternal(Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
