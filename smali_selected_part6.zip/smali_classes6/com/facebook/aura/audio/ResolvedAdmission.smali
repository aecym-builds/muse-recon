.class public interface abstract Lcom/facebook/aura/audio/ResolvedAdmission;
.super Ljava/lang/Object;
.source ""
