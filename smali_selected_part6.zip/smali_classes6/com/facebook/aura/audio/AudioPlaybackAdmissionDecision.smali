.class public interface abstract Lcom/facebook/aura/audio/AudioPlaybackAdmissionDecision;
.super Ljava/lang/Object;
.source ""
