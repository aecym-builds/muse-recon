.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public cumulativeSeconds:D

.field public durationSeconds:Ljava/lang/Double;

.field public hasStarted:Z

.field public isFinished:Z

.field public isSeeking:Z

.field public nextInterval:D

.field public phase:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

.field public final playbackSessionId:Ljava/lang/String;

.field public previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 536870912
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object v0

    .line 536870916
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;-><init>(Ljava/lang/String;)V

    .line 536870917
    .line 536870918
    .line 536870919
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->playbackSessionId:Ljava/lang/String;

    .line 8
    .line 9
    const-wide/high16 v0, 0x403e000000000000L    # 30.0

    .line 10
    .line 11
    iput-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->nextInterval:D

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p2, 0x1

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p1

    .line 268435464
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;-><init>(Ljava/lang/String;)V

    .line 268435465
    .line 268435466
    .line 268435467
    return-void
.end method

.method private final accumulate(DLjava/lang/Double;)V
    .locals 12

    .line 0
    iget-object v7, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 1
    .line 2
    if-eqz v7, :cond_0

    .line 3
    .line 4
    iget-object v0, v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->position:Ljava/lang/Double;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 9
    .line 10
    .line 11
    move-result-wide v10

    .line 12
    invoke-static {p1, p2}, Ljava/lang/Math;->abs(D)D

    .line 13
    .line 14
    .line 15
    move-result-wide v1

    .line 16
    const-wide v8, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    cmpg-double v0, v1, v8

    .line 22
    .line 23
    if-gtz v0, :cond_0

    .line 24
    .line 25
    iget-boolean v0, v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->isAdvancing:Z

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    if-eqz p3, :cond_0

    .line 30
    .line 31
    iget-wide v3, v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->rate:D

    .line 32
    .line 33
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(D)D

    .line 34
    .line 35
    .line 36
    move-result-wide v1

    .line 37
    cmpg-double v0, v1, v8

    .line 38
    .line 39
    if-gtz v0, :cond_0

    .line 40
    .line 41
    const-wide/16 v5, 0x0

    .line 42
    .line 43
    cmpg-double v0, v3, v5

    .line 44
    .line 45
    if-lez v0, :cond_0

    .line 46
    .line 47
    iget-wide v0, v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->time:D

    .line 48
    .line 49
    sub-double/2addr p1, v0

    .line 50
    invoke-virtual {p3}, Ljava/lang/Number;->doubleValue()D

    .line 51
    .line 52
    .line 53
    move-result-wide v1

    .line 54
    sub-double/2addr v1, v10

    .line 55
    cmpg-double v0, p1, v5

    .line 56
    .line 57
    if-lez v0, :cond_0

    .line 58
    .line 59
    cmpg-double v0, v1, v5

    .line 60
    .line 61
    if-lez v0, :cond_0

    .line 62
    .line 63
    div-double/2addr v1, v3

    .line 64
    invoke-static {p1, p2, v1, v2}, Ljava/lang/Math;->min(DD)D

    .line 65
    .line 66
    .line 67
    move-result-wide v3

    .line 68
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(D)D

    .line 69
    .line 70
    .line 71
    move-result-wide v1

    .line 72
    cmpg-double v0, v1, v8

    .line 73
    .line 74
    if-gtz v0, :cond_0

    .line 75
    .line 76
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->cumulativeSeconds:D

    .line 77
    .line 78
    add-double/2addr v0, v3

    .line 79
    iput-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->cumulativeSeconds:D

    .line 80
    .line 81
    :cond_0
    return-void
.end method

.method private final appendIntervals(Ljava/util/List;Ljava/lang/Double;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;",
            ">;",
            "Ljava/lang/Double;",
            ")V"
        }
    .end annotation

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 1
    .line 2
    if-nez v0, :cond_1

    .line 3
    .line 4
    :cond_0
    return-void

    .line 5
    :cond_1
    :goto_0
    iget-wide v3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->cumulativeSeconds:D

    .line 6
    .line 7
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->nextInterval:D

    .line 8
    .line 9
    cmpl-double v0, v3, v1

    .line 10
    .line 11
    if-ltz v0, :cond_0

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->INTERVAL:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 14
    .line 15
    invoke-direct {p0, v0, p2}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->snapshot(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    iget-wide v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->nextInterval:D

    .line 23
    .line 24
    const-wide/high16 v0, 0x403e000000000000L    # 30.0

    .line 25
    .line 26
    add-double/2addr v2, v0

    .line 27
    iput-wide v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->nextInterval:D

    .line 28
    .line 29
    goto :goto_0
.end method

.method private final isAtEnd(Ljava/lang/Double;)Z
    .locals 5

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->durationSeconds:Ljava/lang/Double;

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 7
    .line 8
    .line 9
    move-result-wide v4

    .line 10
    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    .line 11
    .line 12
    .line 13
    move-result-wide v2

    .line 14
    cmpl-double v1, v2, v4

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    if-gez v1, :cond_1

    .line 18
    .line 19
    :cond_0
    const/4 v0, 0x0

    .line 20
    :cond_1
    return v0
.end method

.method private final snapshot(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;
    .locals 6

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->playbackSessionId:Ljava/lang/String;

    .line 1
    .line 2
    iget-wide v3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->cumulativeSeconds:D

    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->durationSeconds:Ljava/lang/Double;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 7
    .line 8
    move-object v2, p1

    .line 9
    move-object v5, p2

    .line 10
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;-><init>(Ljava/lang/String;Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;DLjava/lang/Double;Ljava/lang/Double;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method private final updateDuration(Ljava/lang/Double;)V
    .locals 7

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    .line 3
    .line 4
    .line 5
    move-result-wide v5

    .line 6
    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    .line 7
    .line 8
    .line 9
    move-result-wide v3

    .line 10
    const-wide v1, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    cmpg-double v0, v3, v1

    .line 16
    .line 17
    if-gtz v0, :cond_0

    .line 18
    .line 19
    const-wide/16 v1, 0x0

    .line 20
    .line 21
    cmpl-double v0, v5, v1

    .line 22
    .line 23
    if-lez v0, :cond_0

    .line 24
    .line 25
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->durationSeconds:Ljava/lang/Double;

    .line 26
    .line 27
    :cond_0
    return-void
.end method

.method private final validPosition(Ljava/lang/Double;)Ljava/lang/Double;
    .locals 7

    .line 0
    const/4 p0, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Number;->doubleValue()D

    .line 4
    .line 5
    .line 6
    move-result-wide v5

    .line 7
    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    .line 8
    .line 9
    .line 10
    move-result-wide v3

    .line 11
    const-wide v1, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    cmpg-double v0, v3, v1

    .line 17
    .line 18
    if-gtz v0, :cond_0

    .line 19
    .line 20
    const-wide/16 v1, 0x0

    .line 21
    .line 22
    cmpl-double v0, v5, v1

    .line 23
    .line 24
    if-ltz v0, :cond_0

    .line 25
    .line 26
    return-object p1

    .line 27
    :cond_0
    return-object p0
.end method


# virtual methods
.method public final beginSeek(Ljava/lang/Double;)V
    .locals 7

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-wide v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->time:D

    .line 12
    .line 13
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->validPosition(Ljava/lang/Double;)Ljava/lang/Double;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const-wide/16 v4, 0x0

    .line 18
    .line 19
    const/4 v6, 0x0

    .line 20
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 21
    .line 22
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;-><init>(DLjava/lang/Double;DZ)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 26
    .line 27
    :cond_0
    return-void
.end method

.method public final endSeek()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 2
    .line 3
    return-void
.end method

.method public final finish(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v2, LX/0wV;->A00:LX/0wV;

    .line 9
    .line 10
    return-object v2

    .line 11
    :cond_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->position:Ljava/lang/Double;

    .line 25
    .line 26
    :goto_0
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->snapshot(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    :cond_1
    const/4 v0, 0x1

    .line 34
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 35
    .line 36
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 37
    .line 38
    return-object v2

    .line 39
    :cond_2
    move-object v0, v1

    .line 40
    goto :goto_0
.end method

.method public final getHasStarted()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getPlaybackSessionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->playbackSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isFinished()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isSeeking()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 1
    .line 2
    return p0
.end method

.method public final record(DLjava/lang/Double;Ljava/lang/Double;DLcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;)Ljava/util/List;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(D",
            "Ljava/lang/Double;",
            "Ljava/lang/Double;",
            "D",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x4

    .line 1
    move-object/from16 v3, p7

    .line 2
    .line 3
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    move-wide v8, p1

    .line 11
    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    .line 12
    .line 13
    .line 14
    move-result-wide v1

    .line 15
    const-wide v6, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    cmpg-double v0, v1, v6

    .line 21
    .line 22
    if-gtz v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 25
    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    iget-wide v1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;->time:D

    .line 29
    .line 30
    cmpg-double v0, p1, v1

    .line 31
    .line 32
    if-gez v0, :cond_1

    .line 33
    .line 34
    :cond_0
    sget-object v2, LX/0wV;->A00:LX/0wV;

    .line 35
    .line 36
    return-object v2

    .line 37
    :cond_1
    move-object/from16 v0, p3

    .line 38
    .line 39
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->validPosition(Ljava/lang/Double;)Ljava/lang/Double;

    .line 40
    .line 41
    .line 42
    move-result-object v10

    .line 43
    move-object/from16 v0, p4

    .line 44
    .line 45
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->updateDuration(Ljava/lang/Double;)V

    .line 46
    .line 47
    .line 48
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PLAYING:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 49
    .line 50
    const/4 v5, 0x0

    .line 51
    const/4 v4, 0x1

    .line 52
    move-wide/from16 v11, p5

    .line 53
    .line 54
    if-ne v3, v0, :cond_2

    .line 55
    .line 56
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 57
    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    invoke-static {v11, v12}, Ljava/lang/Math;->abs(D)D

    .line 61
    .line 62
    .line 63
    move-result-wide v1

    .line 64
    cmpg-double v0, v1, v6

    .line 65
    .line 66
    if-gtz v0, :cond_2

    .line 67
    .line 68
    const-wide/16 v1, 0x0

    .line 69
    .line 70
    cmpl-double v0, p5, v1

    .line 71
    .line 72
    if-lez v0, :cond_2

    .line 73
    .line 74
    const/4 v13, 0x1

    .line 75
    if-nez v10, :cond_3

    .line 76
    .line 77
    :cond_2
    const/4 v13, 0x0

    .line 78
    :cond_3
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-eqz v13, :cond_4

    .line 83
    .line 84
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 85
    .line 86
    if-nez v0, :cond_4

    .line 87
    .line 88
    iput-boolean v4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 89
    .line 90
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->START:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 91
    .line 92
    invoke-direct {p0, v0, v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->snapshot(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    :cond_4
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 100
    .line 101
    if-nez v0, :cond_5

    .line 102
    .line 103
    invoke-direct {p0, v8, v9, v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->accumulate(DLjava/lang/Double;)V

    .line 104
    .line 105
    .line 106
    invoke-direct {p0, v2, v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->appendIntervals(Ljava/util/List;Ljava/lang/Double;)V

    .line 107
    .line 108
    .line 109
    :cond_5
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 110
    .line 111
    if-eqz v0, :cond_6

    .line 112
    .line 113
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PAUSED:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 114
    .line 115
    if-ne v3, v0, :cond_9

    .line 116
    .line 117
    :cond_6
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->phase:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 118
    .line 119
    if-eqz v1, :cond_7

    .line 120
    .line 121
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PAUSED:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 122
    .line 123
    if-ne v1, v0, :cond_8

    .line 124
    .line 125
    :cond_7
    const/4 v5, 0x1

    .line 126
    :cond_8
    iput-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->phase:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 127
    .line 128
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PAUSED:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 129
    .line 130
    if-ne v3, v0, :cond_9

    .line 131
    .line 132
    if-nez v5, :cond_9

    .line 133
    .line 134
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->hasStarted:Z

    .line 135
    .line 136
    if-eqz v0, :cond_9

    .line 137
    .line 138
    invoke-direct {p0, v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isAtEnd(Ljava/lang/Double;)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-nez v0, :cond_9

    .line 143
    .line 144
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->PAUSE:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 145
    .line 146
    invoke-direct {p0, v0, v10}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->snapshot(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;Ljava/lang/Double;)Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    :cond_9
    new-instance v7, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 154
    .line 155
    invoke-direct/range {v7 .. v13}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;-><init>(DLjava/lang/Double;DZ)V

    .line 156
    .line 157
    .line 158
    iput-object v7, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->previous:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Sample;

    .line 159
    .line 160
    return-object v2
.end method
