.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchAudioProgressLogger"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final isCurrentPlayer:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final listener:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;

.field public final metadata:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final player:LX/EZl;

.field public sampler:LX/Cbu;

.field public scope:LX/1EL;

.field public final tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->Companion:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/EZl;Lcom/facebook/aura/audio/HatchAudioItem;Lkotlin/jvm/functions/Function0;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/EZl;",
            "Lcom/facebook/aura/audio/HatchAudioItem;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/3Rs;->A1R(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 8
    .line 9
    iput-object p3, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->INSTANCE:Lcom/facebook/aura/audio/HatchAudioInteractionLogger;

    .line 12
    .line 13
    invoke-virtual {v0, p2}, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->chatPlaybackMetadata(Lcom/facebook/aura/audio/HatchAudioItem;)Ljava/util/Map;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v0, p2}, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->podcastIdMetadata(Lcom/facebook/aura/audio/HatchAudioItem;)Ljava/util/Map;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v1, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->metadata:Ljava/util/Map;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 29
    .line 30
    invoke-direct {v0, v1, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;-><init>(Ljava/lang/String;ILX/04f;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 34
    .line 35
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;

    .line 36
    .line 37
    invoke-direct {v0, p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->listener:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;

    .line 41
    .line 42
    return-void
.end method

.method public static final synthetic access$isCurrentPlayer$p(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$recordDiscontinuity(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;JJ)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->recordDiscontinuity(JJ)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$sample(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sample()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$updateSampler(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->updateSampler()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final emit(Ljava/util/List;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1
    .line 2
    .line 3
    move-result-object v7

    .line 4
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v6

    .line 14
    check-cast v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;

    .line 15
    .line 16
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->metadata:Ljava/util/Map;

    .line 17
    .line 18
    new-instance v4, LX/Imj;

    .line 19
    .line 20
    invoke-direct {v4}, LX/Imj;-><init>()V

    .line 21
    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->REASON:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iget-object v0, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->reason:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->getValue()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {v4, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CUMULATIVE_LISTENING_SECONDS:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 39
    .line 40
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    iget-wide v0, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->cumulativeListeningSeconds:D

    .line 45
    .line 46
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v4, v2, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    iget-object v0, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->positionSeconds:Ljava/lang/Double;

    .line 54
    .line 55
    if-eqz v0, :cond_0

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 58
    .line 59
    .line 60
    move-result-wide v2

    .line 61
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->POSITION_SECONDS:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 62
    .line 63
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-virtual {v4, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    :cond_0
    iget-object v0, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->durationSeconds:Ljava/lang/Double;

    .line 75
    .line 76
    if-eqz v0, :cond_1

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 79
    .line 80
    .line 81
    move-result-wide v2

    .line 82
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->DURATION_SECONDS:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 83
    .line 84
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-virtual {v4, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PLAYBACK_SESSION_ID:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 96
    .line 97
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    iget-object v0, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Snapshot;->playbackSessionId:Ljava/lang/String;

    .line 102
    .line 103
    invoke-virtual {v4, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    invoke-static {v4}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v5, v0}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->INSTANCE:Lcom/facebook/aura/audio/HatchAudioInteractionLogger;

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Lcom/facebook/aura/audio/HatchAudioInteractionLogger;->logPlaybackProgress(Ljava/util/Map;)V

    .line 117
    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    return-void
.end method

.method private final isOnPlayerLooper()Z
    .locals 2

    .line 0
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 5
    .line 6
    check-cast v0, LX/GnY;

    .line 7
    .line 8
    iget-object v0, v0, LX/GnY;->A0c:Landroid/os/Looper;

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    return v0

    .line 18
    :cond_0
    const-string v1, "HatchAudioProgressLogger"

    .line 19
    .line 20
    const-string v0, "Podcast progress logger called off the player looper"

    .line 21
    .line 22
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    return v0
.end method

.method private final declared-synchronized recordDiscontinuity(JJ)V
    .locals 5

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 2
    .line 3
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    invoke-static {v0}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isOnPlayerLooper()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    long-to-double v0, p1

    .line 22
    const-wide v3, 0x408f400000000000L    # 1000.0

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    div-double/2addr v0, v3

    .line 28
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->recordPlayer(D)V

    .line 29
    .line 30
    .line 31
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 32
    .line 33
    long-to-double v0, p3

    .line 34
    div-double/2addr v0, v3

    .line 35
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v2, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->beginSeek(Ljava/lang/Double;)V

    .line 40
    .line 41
    .line 42
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->samplePlayer()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    .line 44
    .line 45
    :cond_0
    monitor-exit p0

    .line 46
    return-void

    .line 47
    :catchall_0
    move-exception v0

    .line 48
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 49
    throw v0
.end method

.method private final recordPlayer(D)V
    .locals 13

    .line 0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    long-to-double v6, v0

    .line 5
    const-wide v0, 0x41cdcd6500000000L    # 1.0E9

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    div-double/2addr v6, v0

    .line 11
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 12
    .line 13
    invoke-interface {v0}, LX/GPY;->getDuration()J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 22
    .line 23
    .line 24
    move-result-wide v4

    .line 25
    const-wide/16 v1, 0x0

    .line 26
    .line 27
    const/4 v9, 0x0

    .line 28
    cmp-long v0, v4, v1

    .line 29
    .line 30
    if-lez v0, :cond_0

    .line 31
    .line 32
    long-to-double v2, v4

    .line 33
    const-wide v0, 0x408f400000000000L    # 1000.0

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    div-double/2addr v2, v0

    .line 39
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 40
    .line 41
    .line 42
    move-result-object v9

    .line 43
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 44
    .line 45
    check-cast v0, LX/GnY;

    .line 46
    .line 47
    invoke-static {v0}, LX/GRc;->A00(LX/GnY;)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    const/4 v0, 0x3

    .line 52
    if-ne v1, v0, :cond_1

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 55
    .line 56
    invoke-interface {v0}, LX/GPY;->isPlaying()Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    sget-object v12, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PLAYING:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 63
    .line 64
    :goto_0
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 65
    .line 66
    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 71
    .line 72
    check-cast v0, LX/GnY;

    .line 73
    .line 74
    invoke-static {v0}, LX/GRc;->A03(LX/GnY;)LX/Gni;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iget-object v0, v0, LX/Gni;->A05:LX/EbE;

    .line 79
    .line 80
    iget v0, v0, LX/EbE;->A01:F

    .line 81
    .line 82
    float-to-double v10, v0

    .line 83
    invoke-virtual/range {v5 .. v12}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->record(DLjava/lang/Double;Ljava/lang/Double;DLcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;)Ljava/util/List;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->emit(Ljava/util/List;)V

    .line 88
    .line 89
    .line 90
    return-void

    .line 91
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 92
    .line 93
    check-cast v0, LX/GnY;

    .line 94
    .line 95
    invoke-static {v0}, LX/GRc;->A05(LX/GnY;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-nez v0, :cond_2

    .line 100
    .line 101
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 102
    .line 103
    check-cast v0, LX/GnY;

    .line 104
    .line 105
    invoke-static {v0}, LX/GRc;->A00(LX/GnY;)I

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    const/4 v0, 0x4

    .line 110
    if-eq v1, v0, :cond_2

    .line 111
    .line 112
    sget-object v12, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->PAUSED:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_2
    sget-object v12, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;->BUFFERING:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Phase;

    .line 116
    .line 117
    goto :goto_0
.end method

.method private final declared-synchronized sample()V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 2
    .line 3
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    invoke-static {v0}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->samplePlayer()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    .line 17
    .line 18
    :cond_0
    monitor-exit p0

    .line 19
    return-void

    .line 20
    :catchall_0
    move-exception v0

    .line 21
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    throw v0
.end method

.method private final samplePlayer()V
    .locals 6

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isOnPlayerLooper()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 7
    .line 8
    invoke-interface {v0}, LX/GPY;->getCurrentPosition()J

    .line 9
    .line 10
    .line 11
    move-result-wide v2

    .line 12
    long-to-double v0, v2

    .line 13
    const-wide v4, 0x408f400000000000L    # 1000.0

    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    div-double/2addr v0, v4

    .line 19
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->recordPlayer(D)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 23
    .line 24
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 29
    .line 30
    check-cast v0, LX/GnY;

    .line 31
    .line 32
    invoke-static {v0}, LX/GRc;->A00(LX/GnY;)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    const/4 v0, 0x3

    .line 37
    if-ne v1, v0, :cond_0

    .line 38
    .line 39
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    iput-boolean v0, v1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isSeeking:Z

    .line 43
    .line 44
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 45
    .line 46
    invoke-interface {v0}, LX/GPY;->getCurrentPosition()J

    .line 47
    .line 48
    .line 49
    move-result-wide v2

    .line 50
    long-to-double v0, v2

    .line 51
    div-double/2addr v0, v4

    .line 52
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->recordPlayer(D)V

    .line 53
    .line 54
    .line 55
    :cond_0
    return-void
.end method

.method private final declared-synchronized updateSampler()V
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 2
    .line 3
    invoke-interface {v0}, LX/GPY;->isPlaying()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    const/4 v0, 0x0

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 12
    .line 13
    iget-boolean v1, v1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 14
    .line 15
    if-nez v1, :cond_1

    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 18
    .line 19
    invoke-static {v1}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;

    .line 26
    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    invoke-interface {v1}, LX/Cbu;->isActive()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-ne v1, v2, :cond_0

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->scope:LX/1EL;

    .line 37
    .line 38
    if-eqz v2, :cond_2

    .line 39
    .line 40
    new-instance v1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;

    .line 41
    .line 42
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    invoke-static {v1, v2}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    goto :goto_0

    .line 50
    :cond_1
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;

    .line 51
    .line 52
    if-eqz v1, :cond_2

    .line 53
    .line 54
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 55
    .line 56
    .line 57
    :cond_2
    :goto_0
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 58
    .line 59
    :goto_1
    monitor-exit p0

    .line 60
    return-void

    .line 61
    :catchall_0
    move-exception v0

    .line 62
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 63
    throw v0
.end method


# virtual methods
.method public final declared-synchronized detach()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 7
    .line 8
    .line 9
    :cond_0
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;

    .line 10
    .line 11
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isOnPlayerLooper()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->listener:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;

    .line 20
    .line 21
    invoke-interface {v1, v0}, LX/GPY;->AbJ(LX/GoY;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    .line 23
    .line 24
    :cond_1
    monitor-exit p0

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw v0
.end method

.method public final declared-synchronized finish(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 6
    .line 7
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->samplePlayer()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->finishLastObservation(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    .line 17
    :cond_0
    monitor-exit p0

    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception v0

    .line 20
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 21
    throw v0
.end method

.method public final declared-synchronized finishLastObservation(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 6
    .line 7
    iget-boolean v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->isFinished:Z

    .line 8
    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sampler:LX/Cbu;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->tracker:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;

    .line 20
    .line 21
    invoke-virtual {v0, p1}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker;->finish(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-direct {p0, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->emit(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    .line 27
    .line 28
    :cond_1
    monitor-exit p0

    .line 29
    return-void

    .line 30
    :catchall_0
    move-exception v0

    .line 31
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 32
    throw v0
.end method

.method public final start(LX/1EL;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isOnPlayerLooper()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->scope:LX/1EL;

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->player:LX/EZl;

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->listener:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$listener$1;

    .line 15
    .line 16
    check-cast v0, LX/GnY;

    .line 17
    .line 18
    iget-object v0, v0, LX/GnY;->A0j:LX/Gnf;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, v1}, LX/Gnf;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->sample()V

    .line 27
    .line 28
    .line 29
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->updateSampler()V

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void
.end method
