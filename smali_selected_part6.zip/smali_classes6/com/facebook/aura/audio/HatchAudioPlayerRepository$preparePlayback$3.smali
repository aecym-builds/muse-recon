.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentGeneration:J

.field public final synthetic $player:LX/EZl;

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->$player:LX/EZl;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->$currentGeneration:J

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->$player:LX/EZl;

    .line 3
    .line 4
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->$currentGeneration:J

    .line 8
    .line 9
    invoke-static {v3, v2, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$isCurrentPlayer(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;J)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$3;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
