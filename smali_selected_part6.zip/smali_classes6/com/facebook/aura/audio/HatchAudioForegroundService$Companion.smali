.class public final Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ensureChannel(Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->ensureChannel(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final buildNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)Landroid/app/Notification;
    .locals 5

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->ensureChannel(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    if-eqz p4, :cond_0

    .line 4
    .line 5
    const v3, 0x7f080212

    .line 6
    .line 7
    .line 8
    const v0, 0x7f120ece

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v0, "com.facebook.aura.audio.PAUSE"

    .line 16
    .line 17
    :goto_0
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->mediaActionIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    new-instance v0, LX/AeL;

    .line 22
    .line 23
    invoke-direct {v0, v1, v2, v3}, LX/AeL;-><init>(Landroid/app/PendingIntent;Ljava/lang/CharSequence;I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, LX/AeL;->A00()LX/AjO;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    const v3, 0x7f0800b6

    .line 31
    .line 32
    .line 33
    const v0, 0x7f12024f

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    const-string v0, "com.facebook.aura.audio.STOP"

    .line 41
    .line 42
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->mediaActionIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    new-instance v0, LX/AeL;

    .line 47
    .line 48
    invoke-direct {v0, v1, v2, v3}, LX/AeL;-><init>(Landroid/app/PendingIntent;Ljava/lang/CharSequence;I)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0}, LX/AeL;->A00()LX/AjO;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    const-string v0, "aura_audio_playback"

    .line 56
    .line 57
    new-instance v2, LX/Aji;

    .line 58
    .line 59
    invoke-direct {v2, p1, v0}, LX/Aji;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v2, p2}, LX/Aji;->A09(Ljava/lang/CharSequence;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2, p3}, LX/Aji;->A08(Ljava/lang/CharSequence;)V

    .line 66
    .line 67
    .line 68
    const v0, 0x7f08009d

    .line 69
    .line 70
    .line 71
    invoke-virtual {v2, v0}, LX/Aji;->A04(I)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v2, p6}, LX/Aji;->A06(Landroid/graphics/Bitmap;)V

    .line 75
    .line 76
    .line 77
    invoke-direct {p0, p1}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->launchAppIntent(Landroid/content/Context;)Landroid/app/PendingIntent;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    iput-object v0, v2, LX/Aji;->A09:Landroid/app/PendingIntent;

    .line 82
    .line 83
    const/4 p0, 0x1

    .line 84
    iget-object v1, v2, LX/Aji;->A07:Landroid/app/Notification;

    .line 85
    .line 86
    iget v0, v1, Landroid/app/Notification;->flags:I

    .line 87
    .line 88
    or-int/lit8 v0, v0, 0x2

    .line 89
    .line 90
    iput v0, v1, Landroid/app/Notification;->flags:I

    .line 91
    .line 92
    new-instance v1, LX/Ak3;

    .line 93
    .line 94
    invoke-direct {v1}, LX/Ak3;-><init>()V

    .line 95
    .line 96
    .line 97
    iput-object p5, v1, LX/Ak3;->A00:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 98
    .line 99
    const/4 v0, 0x0

    .line 100
    filled-new-array {v0, p0}, [I

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    iput-object v0, v1, LX/Ak3;->A01:[I

    .line 105
    .line 106
    invoke-virtual {v2, v1}, LX/Aji;->A07(LX/Ajp;)V

    .line 107
    .line 108
    .line 109
    iget-object v0, v2, LX/Aji;->A0N:Ljava/util/ArrayList;

    .line 110
    .line 111
    invoke-virtual {v0, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    iput-boolean p0, v2, LX/Aji;->A0U:Z

    .line 118
    .line 119
    invoke-virtual {v2}, LX/Aji;->A02()Landroid/app/Notification;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    return-object v0

    .line 127
    :cond_0
    const v3, 0x7f080213

    .line 128
    .line 129
    .line 130
    const v0, 0x7f120fdb

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    const-string v0, "com.facebook.aura.audio.PLAY"

    .line 138
    .line 139
    goto :goto_0
.end method

.method public static synthetic buildNotification$default(Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;ILjava/lang/Object;)Landroid/app/Notification;
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x20

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p6, 0x0

    .line 5
    :cond_0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->buildNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)Landroid/app/Notification;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method private final ensureChannel(Landroid/content/Context;)V
    .locals 4

    .line 0
    const-class v0, Landroid/app/NotificationManager;

    .line 1
    .line 2
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Landroid/app/NotificationManager;

    .line 7
    .line 8
    if-eqz p0, :cond_0

    .line 9
    .line 10
    const-string v3, "aura_audio_playback"

    .line 11
    .line 12
    invoke-virtual {p0, v3}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    const v0, 0x7f120246

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    const/4 v1, 0x2

    .line 26
    new-instance v0, Landroid/app/NotificationChannel;

    .line 27
    .line 28
    invoke-direct {v0, v3, v2, v1}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void
.end method

.method private final launchAppIntent(Landroid/content/Context;)Landroid/app/PendingIntent;
    .locals 2

    .line 0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    if-nez p0, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    return-object v0

    .line 16
    :cond_0
    const/4 v1, 0x0

    .line 17
    const/high16 v0, 0xc000000

    .line 18
    .line 19
    invoke-static {p1, v1, p0, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    return-object v0
.end method

.method private final mediaActionIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;
    .locals 2

    .line 0
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const-class v1, Lcom/facebook/aura/audio/HatchAudioForegroundService;

    .line 5
    .line 6
    new-instance v0, Landroid/content/Intent;

    .line 7
    .line 8
    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/high16 v0, 0xc000000

    .line 16
    .line 17
    invoke-static {p1, p0, v1, v0}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public static synthetic updateNotification$default(Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x20

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p6, 0x0

    .line 5
    :cond_0
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->updateNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final start(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string/jumbo p0, "title"

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 9
    .line 10
    .line 11
    const-string v2, "artist"

    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 15
    .line 16
    .line 17
    const-class v1, Lcom/facebook/aura/audio/HatchAudioForegroundService;

    .line 18
    .line 19
    new-instance v0, Landroid/content/Intent;

    .line 20
    .line 21
    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0, v2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 28
    .line 29
    .line 30
    :try_start_0
    invoke-virtual {p1, v0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Landroid/app/ForegroundServiceStartNotAllowedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 31
    .line 32
    .line 33
    :catch_0
    return-void
.end method

.method public final stop(Landroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-class p0, Lcom/facebook/aura/audio/HatchAudioForegroundService;

    .line 5
    .line 6
    new-instance v0, Landroid/content/Intent;

    .line 7
    .line 8
    invoke-direct {v0, p1, p0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final updateNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)V
    .locals 3

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x4

    .line 4
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    const-class v0, Landroid/app/NotificationManager;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    check-cast v2, Landroid/app/NotificationManager;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    const/16 v1, 0x232a

    .line 18
    .line 19
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->buildNotification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;)Landroid/app/Notification;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v2, v1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method
