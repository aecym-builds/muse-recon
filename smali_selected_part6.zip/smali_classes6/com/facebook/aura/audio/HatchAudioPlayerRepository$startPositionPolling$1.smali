.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlayerRepository$startPositionPolling$1"
    f = "HatchAudioPlayerRepository.kt"
    l = {
        0x27e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $forGeneration:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->$forGeneration:J

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->$forGeneration:J

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, v1, p0, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-eq v0, v2, :cond_0

    .line 8
    .line 9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    throw v0

    .line 14
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 22
    .line 23
    .line 24
    move-result-wide v6

    .line 25
    iget-wide v4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->$forGeneration:J

    .line 26
    .line 27
    cmp-long v0, v6, v4

    .line 28
    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 32
    .line 33
    iget-object v4, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->exoPlayer:LX/EZl;

    .line 34
    .line 35
    if-eqz v4, :cond_3

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 38
    .line 39
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 40
    .line 41
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    check-cast v6, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 46
    .line 47
    if-eqz v6, :cond_3

    .line 48
    .line 49
    iget-object v1, v6, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 50
    .line 51
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 52
    .line 53
    if-ne v1, v0, :cond_3

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 56
    .line 57
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 58
    .line 59
    invoke-interface {v4}, LX/GPY;->getCurrentPosition()J

    .line 60
    .line 61
    .line 62
    move-result-wide v4

    .line 63
    long-to-int v0, v4

    .line 64
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 72
    .line 73
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->mediaSessionManager:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 74
    .line 75
    if-eqz v1, :cond_2

    .line 76
    .line 77
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 78
    .line 79
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 80
    .line 81
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    invoke-virtual {v1, v6, v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->updatePlaybackState(Lcom/facebook/aura/audio/HatchAudioPlaybackState;I)V

    .line 90
    .line 91
    .line 92
    :cond_2
    const/4 v0, 0x0

    .line 93
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->L$0:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->L$1:Ljava/lang/Object;

    .line 96
    .line 97
    iput v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$startPositionPolling$1;->label:I

    .line 98
    .line 99
    const-wide/16 v0, 0x64

    .line 100
    .line 101
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    if-ne v0, v3, :cond_1

    .line 106
    .line 107
    return-object v3

    .line 108
    :cond_3
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 109
    .line 110
    return-object v3
.end method
