.class public final Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $wasPlaying:Z

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;Z)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;->$wasPlaying:Z

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onUnduck:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;->$wasPlaying:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 12
    .line 13
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPlay:Lkotlin/jvm/functions/Function0;

    .line 14
    .line 15
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method
