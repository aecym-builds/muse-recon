.class public final Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlaybackProgressLogger$updateSampler$1"
    f = "HatchAudioPlaybackProgressLogger.kt"
    l = {
        0x41
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v4, LX/1EL;

    .line 3
    .line 4
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->label:I

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    if-ne v0, v2, :cond_3

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 17
    .line 18
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->access$sample(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;)V

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-static {v4}, LX/EPV;->A04(LX/1EL;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 28
    .line 29
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->isCurrentPlayer:Lkotlin/jvm/functions/Function0;

    .line 30
    .line 31
    invoke-static {v0}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_2

    .line 36
    .line 37
    iput-object v4, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->L$0:Ljava/lang/Object;

    .line 38
    .line 39
    iput v2, p0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger$updateSampler$1;->label:I

    .line 40
    .line 41
    const-wide/16 v0, 0x3e8

    .line 42
    .line 43
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    if-ne v0, v3, :cond_0

    .line 48
    .line 49
    return-object v3

    .line 50
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_2
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 55
    .line 56
    return-object v3

    .line 57
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    throw v0
.end method
