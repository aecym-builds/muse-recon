.class public final Lcom/facebook/aura/audio/ResolvedAdmission$Pending;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/audio/ResolvedAdmission;


# static fields
.field public static final $stable:I


# instance fields
.field public final admission:Lcom/facebook/aura/audio/PendingAdmission;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;->$stable:I

    .line 1
    .line 2
    sput v0, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;->$stable:I

    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/audio/PendingAdmission;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;->admission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getAdmission()Lcom/facebook/aura/audio/PendingAdmission;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/ResolvedAdmission$Pending;->admission:Lcom/facebook/aura/audio/PendingAdmission;

    .line 1
    .line 2
    return-object p0
.end method
