.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $player:LX/EZl;

.field public final synthetic $runIfCurrent:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            "LX/EZl;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->$runIfCurrent:LX/JDM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->$player:LX/EZl;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->$runIfCurrent:LX/JDM;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9;->$player:LX/EZl;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;

    .line 7
    .line 8
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$9$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {v3, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    return-void
.end method
