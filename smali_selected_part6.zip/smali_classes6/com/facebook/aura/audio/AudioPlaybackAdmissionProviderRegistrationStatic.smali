.class public Lcom/facebook/aura/audio/AudioPlaybackAdmissionProviderRegistrationStatic;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getKeys()[I
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    new-array v0, v0, [I

    .line 2
    .line 3
    return-object v0
.end method

.method public static provider(I)Lcom/facebook/aura/audio/AudioPlaybackAdmissionProvider;
    .locals 0

    .line 0
    invoke-static {p0}, LX/009;->A0Z(I)Ljava/lang/IllegalArgumentException;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method
