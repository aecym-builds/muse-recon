.class public final synthetic Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroid/media/AudioManager;

.field public final synthetic f$1:Landroid/media/AudioManager$OnModeChangedListener;


# direct methods
.method public synthetic constructor <init>(Landroid/media/AudioManager;Landroid/media/AudioManager$OnModeChangedListener;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;->f$0:Landroid/media/AudioManager;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;->f$1:Landroid/media/AudioManager$OnModeChangedListener;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;->f$0:Landroid/media/AudioManager;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;->f$1:Landroid/media/AudioManager$OnModeChangedListener;

    .line 3
    .line 4
    invoke-static {v1, v0}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->invokeSuspend$lambda$1(Landroid/media/AudioManager;Landroid/media/AudioManager$OnModeChangedListener;)Lkotlin/Unit;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method
