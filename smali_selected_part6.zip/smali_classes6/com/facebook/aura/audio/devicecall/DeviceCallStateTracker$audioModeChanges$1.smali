.class public final Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/JmJ<",
        "-",
        "Ljava/lang/Integer;",
        ">;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.devicecall.DeviceCallStateTracker$audioModeChanges$1"
    f = "DeviceCallStateTracker.kt"
    l = {
        0x76
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $audioManager:Landroid/media/AudioManager;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/media/AudioManager;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/media/AudioManager;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->$audioManager:Landroid/media/AudioManager;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static final invokeSuspend$lambda$0(LX/JmJ;I)V
    .locals 1

    .line 0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {p0, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final invokeSuspend$lambda$1(Landroid/media/AudioManager;Landroid/media/AudioManager$OnModeChangedListener;)Lkotlin/Unit;
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroid/media/AudioManager;->removeOnModeChangedListener(Landroid/media/AudioManager$OnModeChangedListener;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 4
    .line 5
    return-object p0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->$audioManager:Landroid/media/AudioManager;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;-><init>(Landroid/media/AudioManager;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/JmJ;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JmJ<",
            "-",
            "Ljava/lang/Integer;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/JmJ;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->invoke(LX/JmJ;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v5, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v5, LX/JmJ;

    .line 3
    .line 4
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->label:I

    .line 7
    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    if-ne v0, v3, :cond_2

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    return-object v4

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    new-instance v2, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda0;

    .line 23
    .line 24
    invoke-direct {v2, v5}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda0;-><init>(LX/JmJ;)V

    .line 25
    .line 26
    .line 27
    iget-object v1, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->$audioManager:Landroid/media/AudioManager;

    .line 28
    .line 29
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->uiThreadExecutor$delegate:Lkotlin/Lazy;

    .line 30
    .line 31
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {v1, v0, v2}, Landroid/media/AudioManager;->addOnModeChangedListener(Ljava/util/concurrent/Executor;Landroid/media/AudioManager$OnModeChangedListener;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->$audioManager:Landroid/media/AudioManager;

    .line 39
    .line 40
    invoke-virtual {v0}, Landroid/media/AudioManager;->getMode()I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-interface {v5, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->$audioManager:Landroid/media/AudioManager;

    .line 52
    .line 53
    new-instance v1, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;

    .line 54
    .line 55
    invoke-direct {v1, v0, v2}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda1;-><init>(Landroid/media/AudioManager;Landroid/media/AudioManager$OnModeChangedListener;)V

    .line 56
    .line 57
    .line 58
    const/4 v0, 0x0

    .line 59
    iput-object v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->L$0:Ljava/lang/Object;

    .line 60
    .line 61
    iput-object v0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->L$1:Ljava/lang/Object;

    .line 62
    .line 63
    iput v3, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->label:I

    .line 64
    .line 65
    invoke-static {p0, v1, v5}, LX/BdO;->A00(LX/2M4;Lkotlin/jvm/functions/Function0;LX/JmJ;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-ne v0, v4, :cond_0

    .line 70
    .line 71
    return-object v4

    .line 72
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    throw v0
.end method
