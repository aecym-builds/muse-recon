.class public final synthetic Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/media/AudioManager$OnModeChangedListener;


# instance fields
.field public final synthetic f$0:LX/JmJ;


# direct methods
.method public synthetic constructor <init>(LX/JmJ;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda0;->f$0:LX/JmJ;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final onModeChanged(I)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1$$ExternalSyntheticLambda0;->f$0:LX/JmJ;

    .line 1
    .line 2
    invoke-static {p0, p1}, Lcom/facebook/aura/audio/devicecall/DeviceCallStateTracker$audioModeChanges$1;->invokeSuspend$lambda$0(LX/JmJ;I)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
