.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Long;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $runIfCurrent:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(LX/JDM;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;->$runIfCurrent:LX/JDM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-wide v0

    .line 268435460
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;->invoke(J)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(J)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;->$runIfCurrent:LX/JDM;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;

    .line 5
    .line 6
    invoke-direct {v0, v1, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;-><init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V

    .line 7
    .line 8
    .line 9
    invoke-interface {v2, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method
