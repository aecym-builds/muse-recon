.class public final Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;
.super LX/HkC;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    invoke-direct {p0}, LX/HkC;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onFastForward()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipForward:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onPause()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPause:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onPlay()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onPlay:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onRewind()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSkipBackward:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onSeekTo(J)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSeekTo:LX/JDM;

    .line 3
    .line 4
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onSetPlaybackSpeed(F)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onSetPlaybackSpeed:LX/JDM;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onStop()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$activate$session$1$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->onStop:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
