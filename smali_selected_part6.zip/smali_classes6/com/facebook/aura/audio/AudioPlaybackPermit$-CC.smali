.class public abstract synthetic Lcom/facebook/aura/audio/AudioPlaybackPermit$-CC;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static $default$awaitPauseRequest(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/audio/AudioPlaybackPermit$-CC;->awaitPauseRequest$suspendImpl(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static $default$getAudioUsage(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Ljava/lang/Integer;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public static $default$getContinuesAfterOwnerEnds(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public static $default$onEnded(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/AudioPlaybackEndReason;I)V
    .locals 0

    .line 0
    invoke-interface {p0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->release()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static $default$onPaused(Lcom/facebook/aura/audio/AudioPlaybackPermit;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public static $default$release(Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic access$awaitPauseRequest$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/audio/AudioPlaybackPermit$-CC;->awaitPauseRequest$suspendImpl(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static synthetic access$getAudioUsage$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Ljava/lang/Integer;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public static synthetic access$getContinuesAfterOwnerEnds$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public static synthetic access$onEnded$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/AudioPlaybackEndReason;I)V
    .locals 0

    .line 0
    invoke-interface {p0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->release()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic access$onPaused$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic access$release$jd(Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic awaitPauseRequest$suspendImpl(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/AudioPlaybackPermit;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p1

    .line 5
    check-cast v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-eq v0, v1, :cond_2

    .line 28
    .line 29
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    throw v0

    .line 34
    :cond_0
    new-instance v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;

    .line 35
    .line 36
    invoke-direct {v4, p0, p1}, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;LX/2M4;)V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    const/4 v0, 0x0

    .line 44
    iput-object v0, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    iput v1, v4, Lcom/facebook/aura/audio/AudioPlaybackPermit$awaitPauseRequest$1;->label:I

    .line 47
    .line 48
    invoke-static {v4}, LX/DSi;->A02(LX/2M4;)LX/2PB;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    if-ne v0, v2, :cond_3

    .line 53
    .line 54
    return-object v2

    .line 55
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_3
    new-instance v0, Lkotlin/KotlinNothingValueException;

    .line 59
    .line 60
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 61
    .line 62
    .line 63
    throw v0
.end method
