.class public final Lcom/facebook/aura/audio/HatchAudioForegroundService;
.super Landroid/app/Service;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final ACTION_INDEX_PLAY_PAUSE:I = 0x0

.field public static final ACTION_INDEX_STOP:I = 0x1

.field public static final ACTION_PAUSE:Ljava/lang/String; = "com.facebook.aura.audio.PAUSE"

.field public static final ACTION_PLAY:Ljava/lang/String; = "com.facebook.aura.audio.PLAY"

.field public static final ACTION_STOP:Ljava/lang/String; = "com.facebook.aura.audio.STOP"

.field public static final CHANNEL_ID:Ljava/lang/String; = "aura_audio_playback"

.field public static final Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

.field public static final EXTRA_ARTIST:Ljava/lang/String; = "artist"

.field public static final EXTRA_TITLE:Ljava/lang/String; = "title"

.field public static final NOTIFICATION_ID:I = 0x232a


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getPlayerRepository()Lcom/facebook/aura/audio/HatchAudioPlayerRepository;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method private final startForegroundPlaceholder()V
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 1
    .line 2
    invoke-static {v0, p0}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->access$ensureChannel(Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;Landroid/content/Context;)V

    .line 3
    .line 4
    .line 5
    const-string v0, "aura_audio_playback"

    .line 6
    .line 7
    new-instance v1, LX/Aji;

    .line 8
    .line 9
    invoke-direct {v1, p0, v0}, LX/Aji;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const v0, 0x7f08009d

    .line 13
    .line 14
    .line 15
    invoke-virtual {v1, v0}, LX/Aji;->A04(I)V

    .line 16
    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    iput-boolean v0, v1, LX/Aji;->A0U:Z

    .line 20
    .line 21
    invoke-virtual {v1}, LX/Aji;->A02()Landroid/app/Notification;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/16 v0, 0x232a

    .line 26
    .line 27
    invoke-virtual {p0, v0, v1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 13

    .line 0
    sget-object v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->activeInstance:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    const/4 v11, 0x0

    .line 3
    if-eqz v1, :cond_1

    .line 4
    .line 5
    invoke-virtual {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 6
    .line 7
    .line 8
    move-result-object v10

    .line 9
    iget-object v0, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackState:LX/2J3;

    .line 10
    .line 11
    if-eqz v0, :cond_2

    .line 12
    .line 13
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 18
    .line 19
    :goto_0
    const/4 v4, 0x2

    .line 20
    move-object v6, p0

    .line 21
    if-eqz v1, :cond_5

    .line 22
    .line 23
    if-eqz v10, :cond_5

    .line 24
    .line 25
    if-eqz v2, :cond_5

    .line 26
    .line 27
    sget-object v5, Lcom/facebook/aura/audio/HatchAudioForegroundService;->Companion:Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;

    .line 28
    .line 29
    iget-object v0, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 30
    .line 31
    iget-object v7, v0, Lcom/facebook/aura/audio/HatchAudioItem;->title:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v8, v0, Lcom/facebook/aura/audio/HatchAudioItem;->artist:Ljava/lang/String;

    .line 34
    .line 35
    iget-object v2, v2, Lcom/facebook/aura/audio/HatchAudioPlaybackState;->status:Lcom/facebook/aura/audio/AudioStatus;

    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 38
    .line 39
    invoke-static {v2, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v9

    .line 43
    const/16 v12, 0x20

    .line 44
    .line 45
    move-object p0, v11

    .line 46
    invoke-static/range {v5 .. v13}, Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;->buildNotification$default(Lcom/facebook/aura/audio/HatchAudioForegroundService$Companion;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZLandroid/support/v4/media/session/MediaSessionCompat$Token;Landroid/graphics/Bitmap;ILjava/lang/Object;)Landroid/app/Notification;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    const/16 v0, 0x232a

    .line 51
    .line 52
    invoke-virtual {v6, v0, v2}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 53
    .line 54
    .line 55
    if-eqz p1, :cond_0

    .line 56
    .line 57
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-eqz v3, :cond_0

    .line 62
    .line 63
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    const v0, -0x23fd5a52

    .line 68
    .line 69
    .line 70
    if-eq v2, v0, :cond_4

    .line 71
    .line 72
    const v0, -0x22314fa4

    .line 73
    .line 74
    .line 75
    if-eq v2, v0, :cond_3

    .line 76
    .line 77
    const v0, -0x222fd2d6

    .line 78
    .line 79
    .line 80
    if-ne v2, v0, :cond_6

    .line 81
    .line 82
    const-string v0, "com.facebook.aura.audio.STOP"

    .line 83
    .line 84
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_6

    .line 89
    .line 90
    invoke-virtual {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->stop()V

    .line 91
    .line 92
    .line 93
    :cond_0
    return v4

    .line 94
    :cond_1
    move-object v10, v11

    .line 95
    :cond_2
    move-object v2, v11

    .line 96
    goto :goto_0

    .line 97
    :cond_3
    const-string v0, "com.facebook.aura.audio.PLAY"

    .line 98
    .line 99
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_6

    .line 104
    .line 105
    invoke-virtual {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->resume()V

    .line 106
    .line 107
    .line 108
    return v4

    .line 109
    :cond_4
    const-string v0, "com.facebook.aura.audio.PAUSE"

    .line 110
    .line 111
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_6

    .line 116
    .line 117
    invoke-virtual {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->pause()V

    .line 118
    .line 119
    .line 120
    return v4

    .line 121
    :cond_5
    invoke-direct {p0}, Lcom/facebook/aura/audio/HatchAudioForegroundService;->startForegroundPlaceholder()V

    .line 122
    .line 123
    .line 124
    :cond_6
    invoke-virtual {v6}, Landroid/app/Service;->stopSelf()V

    .line 125
    .line 126
    .line 127
    return v4
.end method
