.class public interface abstract Lcom/facebook/aura/audio/AudioPlaybackAdmissionProviderRegistration;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract provider()Lcom/facebook/aura/audio/AudioPlaybackAdmissionProvider;
.end method
