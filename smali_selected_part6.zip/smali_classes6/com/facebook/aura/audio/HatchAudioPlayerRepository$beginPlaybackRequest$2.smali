.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlayerRepository$beginPlaybackRequest$2"
    f = "HatchAudioPlayerRepository.kt"
    l = {
        0xf8
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $currentGeneration:J

.field public final synthetic $currentTransitionGeneration:J

.field public final synthetic $permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JJLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/audio/AudioPlaybackPermit;",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository;",
            "JJ",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentTransitionGeneration:J

    .line 5
    .line 6
    iput-wide p5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentGeneration:J

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p7}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 3
    .line 4
    iget-wide v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentTransitionGeneration:J

    .line 5
    .line 6
    iget-wide v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentGeneration:J

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;

    .line 9
    .line 10
    move-object p0, p2

    .line 11
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JJLX/2M4;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->L$0:Ljava/lang/Object;

    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v1, LX/1EL;

    .line 3
    .line 4
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->label:I

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    if-eqz v0, :cond_3

    .line 10
    .line 11
    if-ne v0, v2, :cond_4

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->L$1:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, LX/Cbu;

    .line 16
    .line 17
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 25
    .line 26
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->transitionGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 29
    .line 30
    .line 31
    move-result-wide v3

    .line 32
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentTransitionGeneration:J

    .line 33
    .line 34
    cmp-long v0, v3, v1

    .line 35
    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 39
    .line 40
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 43
    .line 44
    .line 45
    move-result-wide v3

    .line 46
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentGeneration:J

    .line 47
    .line 48
    cmp-long v0, v3, v1

    .line 49
    .line 50
    if-nez v0, :cond_1

    .line 51
    .line 52
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 53
    .line 54
    invoke-interface {v0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->getContinuesAfterOwnerEnds()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 59
    .line 60
    if-eqz v0, :cond_2

    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 63
    .line 64
    invoke-static {v2, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$continueWithoutOwner(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackPermit;)V

    .line 65
    .line 66
    .line 67
    :cond_1
    :goto_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 68
    .line 69
    return-object v3

    .line 70
    :cond_2
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentGeneration:J

    .line 71
    .line 72
    invoke-static {v2, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$failPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 80
    .line 81
    iget-object v6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 82
    .line 83
    iget-wide v7, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentTransitionGeneration:J

    .line 84
    .line 85
    iget-wide v9, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$currentGeneration:J

    .line 86
    .line 87
    const/4 v11, 0x0

    .line 88
    new-instance v4, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2$pauseRequests$1;

    .line 89
    .line 90
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2$pauseRequests$1;-><init>(Lcom/facebook/aura/audio/AudioPlaybackPermit;Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JJLX/2M4;)V

    .line 91
    .line 92
    .line 93
    invoke-static {v4, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->$permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 98
    .line 99
    iput-object v11, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->L$0:Ljava/lang/Object;

    .line 100
    .line 101
    iput-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->L$1:Ljava/lang/Object;

    .line 102
    .line 103
    iput v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$beginPlaybackRequest$2;->label:I

    .line 104
    .line 105
    invoke-interface {v0, p0}, Lcom/facebook/aura/audio/AudioPlaybackPermit;->awaitInvalidation(LX/2M4;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    if-ne v0, v3, :cond_0

    .line 110
    .line 111
    return-object v3

    .line 112
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    throw v0
.end method
