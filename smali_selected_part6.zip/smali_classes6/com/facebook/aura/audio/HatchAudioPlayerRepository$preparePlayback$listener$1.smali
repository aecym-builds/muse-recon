.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/GoY;


# instance fields
.field public final synthetic $currentGeneration:J

.field public final synthetic $item:Lcom/facebook/aura/audio/HatchAudioItem;

.field public final synthetic $player:LX/EZl;

.field public final synthetic $rate:F

.field public started:Z

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;JLX/EZl;Lcom/facebook/aura/audio/HatchAudioItem;F)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 3
    .line 4
    iput-object p4, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$player:LX/EZl;

    .line 5
    .line 6
    iput-object p5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 7
    .line 8
    iput p6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$rate:F

    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public synthetic onAudioAttributesChanged(LX/GoR;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onAudioSessionIdChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onAvailableCommandsChanged(LX/Gi9;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onCues(LX/EuP;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onCues(Ljava/util/List;)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public synthetic onDeviceInfoChanged(LX/EaO;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onDeviceVolumeChanged(IZ)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onEvents(LX/GPY;LX/EbJ;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onIsLoadingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onIsPlayingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onLoadingChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMaxSeekToPreviousPositionChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMediaItemTransition(LX/GYI;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMediaMetadataChanged(LX/JYv;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onMetadata(LX/GeP;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayWhenReadyChanged(ZI)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaybackParametersChanged(LX/EbE;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onPlaybackStateChanged(I)V
    .locals 12

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->generation:Ljava/util/concurrent/atomic/AtomicLong;

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 5
    .line 6
    .line 7
    move-result-wide v3

    .line 8
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 9
    .line 10
    cmp-long v0, v3, v1

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    const/4 v0, 0x4

    .line 15
    if-ne p1, v0, :cond_2

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 18
    .line 19
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackProgressLogger:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;->COMPLETION:Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Lcom/facebook/aura/audio/HatchAudioPlaybackProgressLogger;->finish(Lcom/facebook/aura/audio/HatchAudioPlaybackProgressTracker$Reason;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 29
    .line 30
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$logPlaybackCompleted(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)V

    .line 31
    .line 32
    .line 33
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/audio/AudioPlaybackEndReason;->COMPLETED:Lcom/facebook/aura/audio/AudioPlaybackEndReason;

    .line 36
    .line 37
    invoke-static {v1, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$stopInternal(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/AudioPlaybackEndReason;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void

    .line 41
    :cond_2
    const/4 v0, 0x3

    .line 42
    if-ne p1, v0, :cond_1

    .line 43
    .line 44
    iget-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->started:Z

    .line 45
    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    const/4 v0, 0x1

    .line 49
    iput-boolean v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->started:Z

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$player:LX/EZl;

    .line 52
    .line 53
    invoke-interface {v0}, LX/GPY;->getDuration()J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    long-to-int v4, v0

    .line 58
    const/4 v9, 0x0

    .line 59
    if-ge v4, v9, :cond_3

    .line 60
    .line 61
    const/4 v4, 0x0

    .line 62
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 63
    .line 64
    iget-object v0, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->playbackPermit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 65
    .line 66
    if-nez v0, :cond_4

    .line 67
    .line 68
    invoke-static {v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$canStartWhenReady(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-nez v0, :cond_4

    .line 73
    .line 74
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 75
    .line 76
    iget-object v0, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 77
    .line 78
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 79
    .line 80
    sget-object v3, Lcom/facebook/aura/audio/AudioStatus;->PAUSED:Lcom/facebook/aura/audio/AudioStatus;

    .line 81
    .line 82
    iget v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$rate:F

    .line 83
    .line 84
    iget v6, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 85
    .line 86
    new-instance v1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 87
    .line 88
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;-><init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)V

    .line 89
    .line 90
    .line 91
    invoke-interface {v0, v1}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    return-void

    .line 95
    :cond_4
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 96
    .line 97
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 98
    .line 99
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$player:LX/EZl;

    .line 100
    .line 101
    invoke-static {v5}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    iget-wide v6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 105
    .line 106
    invoke-static/range {v2 .. v7}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$initMediaSession(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;ILX/EZl;J)V

    .line 107
    .line 108
    .line 109
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 110
    .line 111
    iget-object v6, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$player:LX/EZl;

    .line 112
    .line 113
    invoke-static {v6}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    iget-wide v7, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 117
    .line 118
    const/4 v10, 0x4

    .line 119
    const/4 v11, 0x0

    .line 120
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->startPlayback$default(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;LX/EZl;JZILjava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_1

    .line 125
    .line 126
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 127
    .line 128
    iget-object v1, v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_positionMs:LX/2J2;

    .line 129
    .line 130
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 138
    .line 139
    iget-object v0, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->_playbackState:LX/2J2;

    .line 140
    .line 141
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 142
    .line 143
    sget-object v3, Lcom/facebook/aura/audio/AudioStatus;->PLAYING:Lcom/facebook/aura/audio/AudioStatus;

    .line 144
    .line 145
    iget v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$rate:F

    .line 146
    .line 147
    iget v6, v1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->currentVolume:F

    .line 148
    .line 149
    new-instance v1, Lcom/facebook/aura/audio/HatchAudioPlaybackState;

    .line 150
    .line 151
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/audio/HatchAudioPlaybackState;-><init>(Lcom/facebook/aura/audio/HatchAudioItem;Lcom/facebook/aura/audio/AudioStatus;IFF)V

    .line 152
    .line 153
    .line 154
    invoke-interface {v0, v1}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 158
    .line 159
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$item:Lcom/facebook/aura/audio/HatchAudioItem;

    .line 160
    .line 161
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 162
    .line 163
    invoke-static {v3, v2, v4, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$startForegroundPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;Lcom/facebook/aura/audio/HatchAudioItem;IJ)V

    .line 164
    .line 165
    .line 166
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 167
    .line 168
    iget-wide v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 169
    .line 170
    invoke-static {v2, v0, v1}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$startPositionPolling(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V

    .line 171
    .line 172
    .line 173
    return-void
.end method

.method public synthetic onPlaybackSuppressionReasonChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .locals 6

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroidx/media3/common/PlaybackException;->A02()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    const-string v1, "HatchAudioPlayerRepository"

    .line 13
    .line 14
    const-string v0, "Audio playback error: %s"

    .line 15
    .line 16
    invoke-static {v1, v0, v2}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v5, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 20
    .line 21
    iget-object v0, v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->handoffRecoveryGeneration:Ljava/lang/Long;

    .line 22
    .line 23
    iget-wide v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$currentGeneration:J

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 28
    .line 29
    .line 30
    move-result-wide v1

    .line 31
    cmp-long v0, v1, v3

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    const/4 v0, 0x0

    .line 36
    iput-object v0, v5, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->handoffRecoveryGeneration:Ljava/lang/Long;

    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$preparePlayback$listener$1;->$player:LX/EZl;

    .line 39
    .line 40
    invoke-interface {v0}, LX/GPY;->prepare()V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_0
    invoke-static {v5, v3, v4}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->access$failPlayback(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public synthetic onPlayerErrorChanged(Landroidx/media3/common/PlaybackException;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlayerStateChanged(ZI)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPlaylistMetadataChanged(LX/JYv;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPositionDiscontinuity(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onPositionDiscontinuity(LX/EcN;LX/EcN;I)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public synthetic onRenderedFirstFrame()V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onRepeatModeChanged(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSeekBackIncrementChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSeekForwardIncrementChanged(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onShuffleModeEnabledChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSkipSilenceEnabledChanged(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onSurfaceSizeChanged(II)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTimelineChanged(Landroidx/media3/common/Timeline;I)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTrackSelectionParametersChanged(LX/GZK;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onTracksChanged(LX/GNt;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onVideoSizeChanged(LX/GNa;)V
    .locals 0

    .line 0
    return-void
.end method

.method public synthetic onVolumeChanged(F)V
    .locals 0

    .line 0
    return-void
.end method
