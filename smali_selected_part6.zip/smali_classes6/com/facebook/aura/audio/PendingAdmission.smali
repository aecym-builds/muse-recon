.class public final Lcom/facebook/aura/audio/PendingAdmission;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final key:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

.field public final permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;Lcom/facebook/aura/audio/AudioPlaybackPermit;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/audio/PendingAdmission;->key:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/audio/PendingAdmission;->permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getKey()Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/PendingAdmission;->key:Lcom/facebook/aura/audio/AudioPlaybackAdmissionRequest;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermit()Lcom/facebook/aura/audio/AudioPlaybackPermit;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/audio/PendingAdmission;->permit:Lcom/facebook/aura/audio/AudioPlaybackPermit;

    .line 1
    .line 2
    return-object p0
.end method
