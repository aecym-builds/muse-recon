.class public final Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/audio/AudioPlaybackRequestResult;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;->INSTANCE:Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 2

    .line 0
    const/4 v1, 0x1

    .line 1
    if-eq p0, p1, :cond_0

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/audio/AudioPlaybackRequestResult$Accepted;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    :cond_0
    return v1
.end method

.method public hashCode()I
    .locals 0

    .line 0
    const p0, 0x52c92312

    .line 1
    .line 2
    .line 3
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    const/16 p0, 0x29

    .line 1
    .line 2
    invoke-static {p0}, LX/000;->A00(I)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
