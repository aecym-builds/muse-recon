.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $pos:J

.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchAudioPlayerRepository;J)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;->$pos:J

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;->this$0:Lcom/facebook/aura/audio/HatchAudioPlayerRepository;

    .line 1
    .line 2
    iget-wide v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$initMediaSession$4$1;->$pos:J

    .line 3
    .line 4
    long-to-int v0, v1

    .line 5
    invoke-virtual {v3, v0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository;->seekTo(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
