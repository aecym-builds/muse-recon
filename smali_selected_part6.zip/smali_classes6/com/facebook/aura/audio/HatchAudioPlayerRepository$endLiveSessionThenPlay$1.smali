.class public final Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.audio.HatchAudioPlayerRepository$endLiveSessionThenPlay$1"
    f = "HatchAudioPlayerRepository.kt"
    l = {
        0x89
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $liveSession:Lcom/facebook/aura/livesession/api/LiveSession;

.field public final synthetic $play:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/livesession/api/LiveSession;Lkotlin/jvm/functions/Function0;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/livesession/api/LiveSession;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$liveSession:Lcom/facebook/aura/livesession/api/LiveSession;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$play:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$liveSession:Lcom/facebook/aura/livesession/api/LiveSession;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$play:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;-><init>(Lcom/facebook/aura/livesession/api/LiveSession;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-ne v0, v1, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$play:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    :cond_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    .line 25
    return-object v2

    .line 26
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->$liveSession:Lcom/facebook/aura/livesession/api/LiveSession;

    .line 30
    .line 31
    iput v1, p0, Lcom/facebook/aura/audio/HatchAudioPlayerRepository$endLiveSessionThenPlay$1;->label:I

    .line 32
    .line 33
    invoke-interface {v0, p0}, Lcom/facebook/aura/livesession/api/LiveSession;->endForAudioPlayback(LX/2M4;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-ne p1, v2, :cond_0

    .line 38
    .line 39
    return-object v2

    .line 40
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    throw v0
.end method
