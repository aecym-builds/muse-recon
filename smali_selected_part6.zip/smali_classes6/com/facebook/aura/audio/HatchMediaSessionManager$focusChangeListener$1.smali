.class public final Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/media/AudioManager$OnAudioFocusChangeListener;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final onAudioFocusChange(I)V
    .locals 3

    .line 0
    const/4 v0, -0x3

    .line 1
    if-eq p1, v0, :cond_2

    .line 2
    .line 3
    const/4 v0, -0x2

    .line 4
    if-eq p1, v0, :cond_1

    .line 5
    .line 6
    const/4 v0, -0x1

    .line 7
    if-eq p1, v0, :cond_3

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    if-ne p1, v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 13
    .line 14
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->access$markAudioFocusGranted(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 18
    .line 19
    iget-boolean v2, p1, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    iput-boolean v0, p1, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 23
    .line 24
    iget-object p0, p1, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 25
    .line 26
    new-instance v1, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;

    .line 27
    .line 28
    invoke-direct {v1, p1, v2}, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$4;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;Z)V

    .line 29
    .line 30
    .line 31
    :goto_0
    invoke-virtual {p0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void

    .line 35
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 36
    .line 37
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->access$markAudioFocusRevoked(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 41
    .line 42
    iget-object v0, v1, Lcom/facebook/aura/audio/HatchMediaSessionManager;->isPlaying:Lkotlin/jvm/functions/Function0;

    .line 43
    .line 44
    invoke-static {v0}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    iput-boolean v0, v1, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 51
    .line 52
    iget-object p0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 53
    .line 54
    new-instance v1, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$2;

    .line 55
    .line 56
    invoke-direct {v1, v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$2;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 57
    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 61
    .line 62
    iget-object p0, v0, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 63
    .line 64
    new-instance v1, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$3;

    .line 65
    .line 66
    invoke-direct {v1, v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$3;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 67
    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 71
    .line 72
    invoke-static {v0}, Lcom/facebook/aura/audio/HatchMediaSessionManager;->access$markAudioFocusRevoked(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 73
    .line 74
    .line 75
    iget-object v2, p0, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1;->this$0:Lcom/facebook/aura/audio/HatchMediaSessionManager;

    .line 76
    .line 77
    const/4 v0, 0x0

    .line 78
    iput-boolean v0, v2, Lcom/facebook/aura/audio/HatchMediaSessionManager;->wasPlayingBeforeFocusLoss:Z

    .line 79
    .line 80
    iget-object p0, v2, Lcom/facebook/aura/audio/HatchMediaSessionManager;->mainHandler:Landroid/os/Handler;

    .line 81
    .line 82
    new-instance v1, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$1;

    .line 83
    .line 84
    invoke-direct {v1, v2}, Lcom/facebook/aura/audio/HatchMediaSessionManager$focusChangeListener$1$1;-><init>(Lcom/facebook/aura/audio/HatchMediaSessionManager;)V

    .line 85
    .line 86
    .line 87
    :goto_1
    check-cast v1, Ljava/lang/Runnable;

    .line 88
    .line 89
    goto :goto_0
.end method
