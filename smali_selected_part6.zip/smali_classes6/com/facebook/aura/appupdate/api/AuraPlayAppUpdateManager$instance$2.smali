.class public final Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/B4N;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;->INSTANCE:Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static A00(Landroid/content/Context;)LX/B4N;
    .locals 3

    .line 0
    const-class v2, LX/GMx;

    .line 1
    .line 2
    monitor-enter v2

    .line 3
    :try_start_0
    sget-object v1, LX/GMx;->A00:LX/GMy;

    .line 4
    .line 5
    if-nez v1, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    move-object p0, v0

    .line 14
    :cond_0
    new-instance v0, LX/GMw;

    .line 15
    .line 16
    invoke-direct {v0, p0}, LX/GMw;-><init>(Landroid/content/Context;)V

    .line 17
    .line 18
    .line 19
    new-instance v1, LX/GMq;

    .line 20
    .line 21
    invoke-direct {v1, v0}, LX/GMq;-><init>(LX/GMw;)V

    .line 22
    .line 23
    .line 24
    sput-object v1, LX/GMx;->A00:LX/GMy;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    .line 26
    :cond_1
    monitor-exit v2

    .line 27
    check-cast v1, LX/GMq;

    .line 28
    .line 29
    iget-object v0, v1, LX/GMq;->A00:LX/GMo;

    .line 30
    .line 31
    invoke-interface {v0}, LX/GMo;->Ajj()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, LX/B4N;

    .line 36
    .line 37
    return-object v0

    .line 38
    :catchall_0
    move-exception v0

    .line 39
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 40
    throw v0
.end method


# virtual methods
.method public final invoke()LX/B4N;
    .locals 0

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;->A00(Landroid/content/Context;)LX/B4N;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    invoke-static {p0}, Lcom/facebook/aura/appupdate/api/AuraPlayAppUpdateManager$instance$2;->A00(Landroid/content/Context;)LX/B4N;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method
