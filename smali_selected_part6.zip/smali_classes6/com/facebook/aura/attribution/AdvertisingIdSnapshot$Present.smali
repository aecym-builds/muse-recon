.class public final Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;


# instance fields
.field public final id:Ljava/lang/String;

.field public final status:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 8
    .line 9
    const-string v0, "present"

    .line 10
    .line 11
    iput-object v0, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->status:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;)Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 5
    .line 6
    invoke-direct {p0, p1}, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    :cond_0
    return v2

    .line 21
    :cond_1
    return v3
.end method

.method public final getId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getStatus()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;->id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
