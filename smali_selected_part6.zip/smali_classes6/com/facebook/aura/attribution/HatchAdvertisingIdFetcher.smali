.class public final Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchAdvertisingIdFetcher"


# instance fields
.field public final context:Landroid/content/Context;

.field public final debugLogger:LX/ECM;

.field public final executor:Ljava/util/concurrent/Executor;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->Companion:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/Executor;LX/ECM;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->executor:Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->debugLogger:LX/ECM;

    .line 11
    .line 12
    return-void
.end method

.method private final fetchAdvertisingIdInfoSync(Lkotlin/jvm/functions/Function0;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)",
            "Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;"
        }
    .end annotation

    .line 0
    const-string v6, "advertising_id_failure"

    .line 1
    .line 2
    const/4 v5, 0x0

    .line 3
    :try_start_0
    move-object/from16 v2, p0

    .line 4
    .line 5
    sget-object v1, LX/I9a;->A00:LX/I9a;

    .line 6
    .line 7
    iget-object v0, v2, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->context:Landroid/content/Context;

    .line 8
    .line 9
    const v9, 0xbdfcb8

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1, v0, v9}, LX/FQl;->A01(Landroid/content/Context;I)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_b
    :try_end_0
    .catch Lcom/google/android/gms/common/GooglePlayServicesManifestException; {:try_start_0 .. :try_end_0} :catch_4

    .line 17
    .line 18
    :try_start_1
    iget-object v0, v2, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->context:Landroid/content/Context;

    .line 19
    .line 20
    const/4 v8, 0x1

    .line 21
    const-wide/16 v15, -0x1

    .line 22
    .line 23
    new-instance v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;

    .line 24
    .line 25
    invoke-direct {v3, v0}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;-><init>(Landroid/content/Context;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    .line 26
    .line 27
    .line 28
    :try_start_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 29
    .line 30
    .line 31
    move-result-wide v11

    .line 32
    const-string v10, "Calling this from your main thread can lead to deadlock"

    .line 33
    .line 34
    invoke-static {v10}, LX/FK0;->A05(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    monitor-enter v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    .line 38
    :try_start_3
    iget-boolean v0, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A02:Z

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    invoke-virtual {v3}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A00()V

    .line 43
    .line 44
    .line 45
    :cond_0
    iget-object v4, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A03:Landroid/content/Context;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_5

    .line 46
    .line 47
    :try_start_4
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 48
    .line 49
    .line 50
    move-result-object v7

    .line 51
    const-string v1, "com.android.vending"

    .line 52
    .line 53
    const/4 v0, 0x0

    .line 54
    invoke-virtual {v7, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_4
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    .line 55
    .line 56
    .line 57
    :try_start_5
    sget-object v0, LX/FQl;->A00:LX/FQl;

    .line 58
    .line 59
    invoke-virtual {v0, v4, v9}, LX/FQl;->A01(Landroid/content/Context;I)I

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_1

    .line 64
    .line 65
    const/4 v0, 0x2

    .line 66
    if-eq v1, v0, :cond_1

    .line 67
    .line 68
    goto/16 :goto_3

    .line 69
    .line 70
    :cond_1
    new-instance v9, LX/FXr;

    .line 71
    .line 72
    invoke-direct {v9}, LX/FXr;-><init>()V

    .line 73
    .line 74
    .line 75
    const-string v0, "com.google.android.gms.ads.identifier.service.START"

    .line 76
    .line 77
    invoke-static {v0}, LX/EYt;->A0C(Ljava/lang/String;)Landroid/content/Intent;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    const-string v0, "com.google.android.gms"

    .line 82
    .line 83
    invoke-virtual {v1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 84
    .line 85
    .line 86
    :try_start_6
    invoke-static {}, LX/FOI;->A00()LX/FOI;

    .line 87
    .line 88
    .line 89
    move-result-object v20

    .line 90
    invoke-static {v4}, LX/002;->A0y(Ljava/lang/Object;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v21

    .line 94
    move-object/from16 v18, v1

    .line 95
    .line 96
    move-object/from16 v19, v9

    .line 97
    .line 98
    move/from16 p0, v8

    .line 99
    .line 100
    move-object/from16 v17, v4

    .line 101
    .line 102
    invoke-static/range {v17 .. v22}, LX/FOI;->A01(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;LX/FOI;Ljava/lang/String;I)Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_9
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 107
    .line 108
    :try_start_7
    iput-object v9, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A00:LX/FXr;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .line 109
    .line 110
    :try_start_8
    sget-object v7, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 111
    .line 112
    const-wide/16 v0, 0x2710

    .line 113
    .line 114
    const-string v4, "BlockingServiceConnection.getServiceWithTimeout() called on main thread"

    .line 115
    .line 116
    invoke-static {v4}, LX/FK0;->A05(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    iget-boolean v4, v9, LX/FXr;->A00:Z

    .line 120
    .line 121
    if-nez v4, :cond_8

    .line 122
    .line 123
    iput-boolean v8, v9, LX/FXr;->A00:Z

    .line 124
    .line 125
    iget-object v4, v9, LX/FXr;->A01:Ljava/util/concurrent/BlockingQueue;

    .line 126
    .line 127
    invoke-interface {v4, v0, v1, v7}, Ljava/util/concurrent/BlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v4

    .line 131
    check-cast v4, Landroid/os/IBinder;

    .line 132
    .line 133
    if-eqz v4, :cond_7

    .line 134
    .line 135
    const-string v7, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService"

    .line 136
    .line 137
    invoke-interface {v4, v7}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    instance-of v0, v1, Lcom/google/android/gms/internal/ads_identifier/zzf;

    .line 142
    .line 143
    if-eqz v0, :cond_2

    .line 144
    .line 145
    check-cast v1, Lcom/google/android/gms/internal/ads_identifier/zzf;

    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_2
    new-instance v1, Lcom/google/android/gms/internal/ads_identifier/zzd;

    .line 149
    .line 150
    invoke-direct {v1, v4}, Lcom/google/android/gms/internal/ads_identifier/zzd;-><init>(Landroid/os/IBinder;)V
    :try_end_8
    .catch Ljava/lang/InterruptedException; {:try_start_8 .. :try_end_8} :catch_1
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 151
    .line 152
    .line 153
    :goto_0
    :try_start_9
    iput-object v1, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A01:Lcom/google/android/gms/internal/ads_identifier/zzf;

    .line 154
    .line 155
    iput-boolean v8, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A02:Z

    .line 156
    .line 157
    monitor-exit v3
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 158
    :try_start_a
    invoke-static {v10}, LX/FK0;->A05(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    monitor-enter v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    .line 162
    :try_start_b
    iget-boolean v0, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A02:Z

    .line 163
    .line 164
    if-nez v0, :cond_3

    .line 165
    .line 166
    iget-object v1, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A04:Ljava/lang/Object;

    .line 167
    .line 168
    monitor-enter v1
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    .line 169
    :try_start_c
    const-string v0, "AdvertisingIdClient is not connected."

    .line 170
    .line 171
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    throw v0

    .line 176
    :catchall_0
    move-exception v0

    .line 177
    monitor-exit v1

    .line 178
    goto/16 :goto_1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    .line 179
    .line 180
    :cond_3
    :try_start_d
    iget-object v0, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A00:LX/FXr;

    .line 181
    .line 182
    invoke-static {v0}, LX/FK0;->A02(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    iget-object v1, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A01:Lcom/google/android/gms/internal/ads_identifier/zzf;

    .line 186
    .line 187
    invoke-static {v1}, LX/FK0;->A02(Ljava/lang/Object;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    .line 188
    .line 189
    .line 190
    :try_start_e
    check-cast v1, Lcom/google/android/gms/internal/ads_identifier/zzd;

    .line 191
    .line 192
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    invoke-virtual {v0, v7}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v1, v0, v8}, Lcom/google/android/gms/internal/ads_identifier/zzd;->A00(Landroid/os/Parcel;I)Landroid/os/Parcel;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v9

    .line 207
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    .line 208
    .line 209
    .line 210
    iget-object v4, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A01:Lcom/google/android/gms/internal/ads_identifier/zzf;

    .line 211
    .line 212
    check-cast v4, Lcom/google/android/gms/internal/ads_identifier/zzd;

    .line 213
    .line 214
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v1, v8}, Landroid/os/Parcel;->writeInt(I)V

    .line 222
    .line 223
    .line 224
    const/4 v0, 0x2

    .line 225
    invoke-virtual {v4, v1, v0}, Lcom/google/android/gms/internal/ads_identifier/zzd;->A00(Landroid/os/Parcel;I)Landroid/os/Parcel;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_e .. :try_end_e} :catch_0
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    invoke-static {v0}, LX/003;->A1B(I)Z

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    :try_start_f
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 238
    .line 239
    .line 240
    new-instance v7, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    .line 241
    .line 242
    invoke-direct {v7, v9, v0}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;-><init>(Ljava/lang/String;Z)V
    :try_end_f
    .catch Landroid/os/RemoteException; {:try_start_f .. :try_end_f} :catch_0
    .catchall {:try_start_f .. :try_end_f} :catchall_2

    .line 243
    .line 244
    .line 245
    :try_start_10
    monitor-exit v3
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_2

    .line 246
    :try_start_11
    iget-object v1, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A04:Ljava/lang/Object;

    .line 247
    .line 248
    monitor-enter v1
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_6

    .line 249
    :try_start_12
    monitor-exit v1
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_1

    .line 250
    :try_start_13
    invoke-static {v11, v12}, LX/EYt;->A08(J)J

    .line 251
    .line 252
    .line 253
    move-result-wide v13

    .line 254
    invoke-static {}, Ljava/lang/Math;->random()D

    .line 255
    .line 256
    .line 257
    move-result-wide v11

    .line 258
    const-wide/16 v9, 0x0

    .line 259
    .line 260
    cmpl-double v0, v11, v9

    .line 261
    .line 262
    if-gtz v0, :cond_6

    .line 263
    .line 264
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    const-string v0, "app_context"

    .line 269
    .line 270
    const-string v1, "1"

    .line 271
    .line 272
    invoke-virtual {v4, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    iget-boolean v0, v7, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A01:Z

    .line 276
    .line 277
    if-eq v8, v0, :cond_4

    .line 278
    .line 279
    const-string v1, "0"

    .line 280
    .line 281
    :cond_4
    const-string v0, "limit_ad_tracking"

    .line 282
    .line 283
    invoke-virtual {v4, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    iget-object v0, v7, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A00:Ljava/lang/String;

    .line 287
    .line 288
    if-eqz v0, :cond_5

    .line 289
    .line 290
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 291
    .line 292
    .line 293
    move-result v0

    .line 294
    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    const-string v0, "ad_id_size"

    .line 299
    .line 300
    invoke-virtual {v4, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    :cond_5
    const-string/jumbo v1, "tag"

    .line 304
    .line 305
    .line 306
    const-string v0, "AdvertisingIdClient"

    .line 307
    .line 308
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 309
    .line 310
    .line 311
    const-string/jumbo v1, "time_spent"

    .line 312
    .line 313
    .line 314
    invoke-static {v13, v14}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    new-instance v0, LX/FSX;

    .line 322
    .line 323
    invoke-direct {v0, v4}, LX/FSX;-><init>(Ljava/util/Map;)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_6

    .line 327
    .line 328
    .line 329
    :cond_6
    :try_start_14
    invoke-virtual {v3}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A00()V

    .line 330
    .line 331
    .line 332
    return-object v7
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_3

    .line 333
    :catchall_1
    :try_start_15
    move-exception v0

    .line 334
    monitor-exit v1

    .line 335
    goto :goto_5
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_1

    .line 336
    :catch_0
    move-exception v4

    .line 337
    :try_start_16
    const-string v1, "AdvertisingIdClient"

    .line 338
    .line 339
    const-string v0, "GMS remote exception "

    .line 340
    .line 341
    invoke-static {v1, v0, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 342
    .line 343
    .line 344
    const-string v0, "Remote exception"

    .line 345
    .line 346
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 347
    .line 348
    .line 349
    move-result-object v0

    .line 350
    :goto_1
    throw v0

    .line 351
    :catchall_2
    move-exception v0

    .line 352
    monitor-exit v3

    .line 353
    goto :goto_5
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_2

    .line 354
    :cond_7
    :try_start_17
    const-string v0, "Timed out waiting for the service connection"

    .line 355
    .line 356
    new-instance v1, Ljava/util/concurrent/TimeoutException;

    .line 357
    .line 358
    invoke-direct {v1, v0}, Ljava/util/concurrent/TimeoutException;-><init>(Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    goto :goto_2

    .line 362
    :cond_8
    const-string v0, "Cannot call get on this connection more than once"

    .line 363
    .line 364
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    :goto_2
    throw v1
    :try_end_17
    .catch Ljava/lang/InterruptedException; {:try_start_17 .. :try_end_17} :catch_1
    .catchall {:try_start_17 .. :try_end_17} :catchall_3

    .line 369
    :catchall_3
    :try_start_18
    move-exception v0

    .line 370
    new-instance v1, Ljava/io/IOException;

    .line 371
    .line 372
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 373
    .line 374
    .line 375
    goto :goto_4

    .line 376
    :catch_1
    const-string v0, "Interrupted exception"

    .line 377
    .line 378
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 379
    .line 380
    .line 381
    move-result-object v1

    .line 382
    goto :goto_4

    .line 383
    :cond_9
    const-string v0, "Connection failure"

    .line 384
    .line 385
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 386
    .line 387
    .line 388
    move-result-object v1

    .line 389
    goto :goto_4

    .line 390
    :catchall_4
    move-exception v0

    .line 391
    new-instance v1, Ljava/io/IOException;

    .line 392
    .line 393
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 394
    .line 395
    .line 396
    goto :goto_4

    .line 397
    :catch_2
    new-instance v1, Lcom/google/android/gms/common/GooglePlayServicesNotAvailableException;

    .line 398
    .line 399
    invoke-direct {v1}, Lcom/google/android/gms/common/GooglePlayServicesNotAvailableException;-><init>()V

    .line 400
    .line 401
    .line 402
    goto :goto_4

    .line 403
    :goto_3
    const-string v0, "Google Play services not available"

    .line 404
    .line 405
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 406
    .line 407
    .line 408
    move-result-object v1

    .line 409
    :goto_4
    throw v1

    .line 410
    :catchall_5
    move-exception v0

    .line 411
    monitor-exit v3
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_5

    .line 412
    :goto_5
    :try_start_19
    throw v0
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_6

    .line 413
    :catchall_6
    move-exception v11

    .line 414
    :try_start_1a
    invoke-static {}, Ljava/lang/Math;->random()D

    .line 415
    .line 416
    .line 417
    move-result-wide v9

    .line 418
    const-wide/16 v7, 0x0

    .line 419
    .line 420
    cmpl-double v0, v9, v7

    .line 421
    .line 422
    if-gtz v0, :cond_a

    .line 423
    .line 424
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 425
    .line 426
    .line 427
    move-result-object v4

    .line 428
    const-string v1, "app_context"

    .line 429
    .line 430
    const-string v0, "1"

    .line 431
    .line 432
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    invoke-static {v11}, LX/002;->A0y(Ljava/lang/Object;)Ljava/lang/String;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    const-string v0, "error"

    .line 440
    .line 441
    invoke-virtual {v4, v0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 442
    .line 443
    .line 444
    const-string/jumbo v1, "tag"

    .line 445
    .line 446
    .line 447
    const-string v0, "AdvertisingIdClient"

    .line 448
    .line 449
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    const-string/jumbo v1, "time_spent"

    .line 453
    .line 454
    .line 455
    invoke-static/range {v15 .. v16}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object v0

    .line 459
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    new-instance v0, LX/FSX;

    .line 463
    .line 464
    invoke-direct {v0, v4}, LX/FSX;-><init>(Ljava/util/Map;)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 468
    .line 469
    .line 470
    :cond_a
    throw v11
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_7

    .line 471
    :catchall_7
    :try_start_1b
    move-exception v0

    .line 472
    invoke-virtual {v3}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->A00()V

    .line 473
    .line 474
    .line 475
    throw v0
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_3

    .line 476
    :catch_3
    move-exception v4

    .line 477
    iget-object v3, v2, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->debugLogger:LX/ECM;

    .line 478
    .line 479
    const-string v2, "Failed to fetch advertising id info"

    .line 480
    .line 481
    invoke-static {v6, v2, v4, v5}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 482
    .line 483
    .line 484
    move-result-object v1

    .line 485
    const-string v0, "error"

    .line 486
    .line 487
    invoke-static {v1, v0, v3}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 488
    .line 489
    .line 490
    const-string v0, "HatchAdvertisingIdFetcher"

    .line 491
    .line 492
    invoke-static {v0, v4, v2}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 493
    .line 494
    .line 495
    invoke-interface/range {p1 .. p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    return-object v5

    .line 499
    :cond_b
    return-object v5

    .line 500
    :catch_4
    move-exception v1

    .line 501
    iget-object v2, v2, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->debugLogger:LX/ECM;

    .line 502
    .line 503
    const-string v0, "Invalid Play services manifest version"

    .line 504
    .line 505
    invoke-static {v6, v0, v1, v5}, LX/ECM;->A00(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/List;)Ljava/lang/String;

    .line 506
    .line 507
    .line 508
    move-result-object v1

    .line 509
    const-string v0, "error"

    .line 510
    .line 511
    invoke-static {v1, v0, v2}, LX/ECM;->A01(Ljava/lang/String;Ljava/lang/String;LX/ECM;)V

    .line 512
    .line 513
    .line 514
    return-object v5
.end method

.method public static synthetic fetchAdvertisingIdInfoSync$default(Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p1, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfoSync$1;->INSTANCE:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfoSync$1;

    .line 5
    .line 6
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->fetchAdvertisingIdInfoSync(Lkotlin/jvm/functions/Function0;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method


# virtual methods
.method public final fetchAdvertisingIdInfo(LX/JDN;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDN<",
            "-",
            "Ljava/lang/Boolean;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->executor:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;-><init>(Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;LX/JDN;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final fetchAdvertisingIdSnapshotSync()Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;
    .locals 4

    .line 0
    new-instance v3, LX/0Rg;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdSnapshotSync$info$1;

    .line 6
    .line 7
    invoke-direct {v0, v3}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdSnapshotSync$info$1;-><init>(LX/0Rg;)V

    .line 8
    .line 9
    .line 10
    invoke-direct {p0, v0}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->fetchAdvertisingIdInfoSync(Lkotlin/jvm/functions/Function0;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    if-eqz v2, :cond_3

    .line 15
    .line 16
    iget-object v1, v2, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A00:Ljava/lang/String;

    .line 17
    .line 18
    :goto_0
    iget-boolean v0, v3, LX/0Rg;->element:Z

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Error;->INSTANCE:Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Error;

    .line 23
    .line 24
    :goto_1
    check-cast v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot;

    .line 25
    .line 26
    return-object v0

    .line 27
    :cond_0
    if-eqz v2, :cond_2

    .line 28
    .line 29
    iget-boolean v0, v2, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A01:Z

    .line 30
    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$OptedOut;->INSTANCE:Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$OptedOut;

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_1
    if-eqz v1, :cond_2

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    new-instance v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;

    .line 45
    .line 46
    invoke-direct {v0, v1}, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Present;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v0

    .line 50
    :cond_2
    sget-object v0, Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Unavailable;->INSTANCE:Lcom/facebook/aura/attribution/AdvertisingIdSnapshot$Unavailable;

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_3
    const/4 v1, 0x0

    .line 54
    goto :goto_0
.end method
