.class public final Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $callback:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Ljava/lang/Boolean;",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic this$0:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;LX/JDN;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;",
            "LX/JDN<",
            "-",
            "Ljava/lang/Boolean;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;->this$0:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;->$callback:LX/JDN;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;->this$0:Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v2, v1, v2}, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;->fetchAdvertisingIdInfoSync$default(Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    if-eqz v3, :cond_0

    .line 9
    .line 10
    iget-boolean v0, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A01:Z

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-object v2, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;->$callback:LX/JDN;

    .line 15
    .line 16
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    iget-object v0, v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->A00:Ljava/lang/String;

    .line 21
    .line 22
    invoke-interface {v2, v1, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/attribution/HatchAdvertisingIdFetcher$fetchAdvertisingIdInfo$1;->$callback:LX/JDN;

    .line 27
    .line 28
    invoke-static {}, LX/002;->A0i()Ljava/lang/Boolean;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-interface {v1, v0, v2}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    return-void
.end method
