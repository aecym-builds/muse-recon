.class public final Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.battery.AuraBatteryMetrics$init$1"
    f = "AuraBatteryMetrics.kt"
    l = {
        0x4e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $batterySessionInstance:LX/H34;

.field public final synthetic $metricsLogger:LX/H36;

.field public final synthetic $reporter:LX/H2d;

.field public final synthetic $sessionCollector:LX/H2c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/H2c<",
            "LX/H2U;",
            "LX/H2V;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $store:Lcom/facebook/aura/battery/AuraBatteryEventStore;

.field public label:I


# direct methods
.method public constructor <init>(LX/H2c;LX/H2d;LX/H36;Lcom/facebook/aura/battery/AuraBatteryEventStore;LX/H34;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/H2c<",
            "LX/H2U;",
            "LX/H2V;",
            ">;",
            "LX/H2d;",
            "LX/H36;",
            "Lcom/facebook/aura/battery/AuraBatteryEventStore;",
            "LX/H34;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$sessionCollector:LX/H2c;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$reporter:LX/H2d;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$metricsLogger:LX/H36;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$store:Lcom/facebook/aura/battery/AuraBatteryEventStore;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$batterySessionInstance:LX/H34;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$sessionCollector:LX/H2c;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$reporter:LX/H2d;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$metricsLogger:LX/H36;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$store:Lcom/facebook/aura/battery/AuraBatteryEventStore;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$batterySessionInstance:LX/H34;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;-><init>(LX/H2c;LX/H2d;LX/H36;Lcom/facebook/aura/battery/AuraBatteryEventStore;LX/H34;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v5, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v4

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    sget-object v6, Lcom/facebook/aura/battery/AuraBatteryMetrics;->INSTANCE:Lcom/facebook/aura/battery/AuraBatteryMetrics;

    .line 19
    .line 20
    iget-object v3, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$sessionCollector:LX/H2c;

    .line 21
    .line 22
    iget-object v2, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$reporter:LX/H2d;

    .line 23
    .line 24
    iget-object v1, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$metricsLogger:LX/H36;

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$store:Lcom/facebook/aura/battery/AuraBatteryEventStore;

    .line 27
    .line 28
    invoke-static {v6, v3, v2, v1, v0}, Lcom/facebook/aura/battery/AuraBatteryMetrics;->access$logPreviousSession(Lcom/facebook/aura/battery/AuraBatteryMetrics;LX/H2c;LX/H2d;LX/H36;Lcom/facebook/aura/battery/AuraBatteryEventStore;)V

    .line 29
    .line 30
    .line 31
    sget-object v2, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForegroundFlow:LX/2Lw;

    .line 32
    .line 33
    const/4 v1, 0x0

    .line 34
    new-instance v0, LX/EWQ;

    .line 35
    .line 36
    invoke-direct {v0, v2, v1}, LX/EWQ;-><init>(Ljava/lang/Object;I)V

    .line 37
    .line 38
    .line 39
    iget-object v7, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$sessionCollector:LX/H2c;

    .line 40
    .line 41
    iget-object v8, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$reporter:LX/H2d;

    .line 42
    .line 43
    iget-object v9, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$metricsLogger:LX/H36;

    .line 44
    .line 45
    iget-object v10, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$store:Lcom/facebook/aura/battery/AuraBatteryEventStore;

    .line 46
    .line 47
    iget-object v11, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->$batterySessionInstance:LX/H34;

    .line 48
    .line 49
    new-instance v6, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1$1;

    .line 50
    .line 51
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1$1;-><init>(LX/H2c;LX/H2d;LX/H36;Lcom/facebook/aura/battery/AuraBatteryEventStore;LX/H34;)V

    .line 52
    .line 53
    .line 54
    iput v5, p0, Lcom/facebook/aura/battery/AuraBatteryMetrics$init$1;->label:I

    .line 55
    .line 56
    invoke-virtual {v0, v6, p0}, LX/EWQ;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-ne v0, v4, :cond_0

    .line 61
    .line 62
    return-object v4

    .line 63
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method
