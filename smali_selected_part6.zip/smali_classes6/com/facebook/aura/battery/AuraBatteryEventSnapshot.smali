.class public final Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final appInstanceId:J

.field public final currentSequence:J

.field public final isAppInForeground:Z

.field public final metrics:LX/H2U;


# direct methods
.method public constructor <init>(LX/H2U;ZJJ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->metrics:LX/H2U;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->isAppInForeground:Z

    .line 10
    .line 11
    iput-wide p3, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->appInstanceId:J

    .line 12
    .line 13
    iput-wide p5, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->currentSequence:J

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final getAppInstanceId()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->appInstanceId:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getCurrentSequence()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->currentSequence:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getMetrics()LX/H2U;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->metrics:LX/H2U;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isAppInForeground()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/battery/AuraBatteryEventSnapshot;->isAppInForeground:Z

    .line 1
    .line 2
    return p0
.end method
