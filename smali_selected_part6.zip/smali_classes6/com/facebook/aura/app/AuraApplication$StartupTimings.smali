.class public final Lcom/facebook/aura/app/AuraApplication$StartupTimings;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public abcEnd:J

.field public final abcStart:J

.field public final exopackageEnd:J

.field public final exopackageStart:J

.field public final processStartTime:J


# direct methods
.method public constructor <init>(JJJJJ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->processStartTime:J

    .line 4
    .line 5
    iput-wide p3, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcStart:J

    .line 6
    .line 7
    iput-wide p5, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcEnd:J

    .line 8
    .line 9
    iput-wide p7, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageStart:J

    .line 10
    .line 11
    iput-wide p9, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageEnd:J

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(JJJJJILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p11, 0x4

    .line 268435457
    .line 268435458
    invoke-static {v0, p5, p6}, LX/EYw;->A0L(IJ)J

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-wide p5

    .line 268435462
    invoke-direct/range {p0 .. p10}, Lcom/facebook/aura/app/AuraApplication$StartupTimings;-><init>(JJJJJ)V

    .line 268435463
    .line 268435464
    .line 268435465
    return-void
.end method


# virtual methods
.method public final dump()V
    .locals 10

    .line 0
    sget-object v0, Lcom/facebook/aura/qpl/startup/HatchStartupQpl;->Companion:Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;

    .line 1
    .line 2
    iget-wide v1, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->processStartTime:J

    .line 3
    .line 4
    iget-wide v3, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcStart:J

    .line 5
    .line 6
    iget-wide v5, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcEnd:J

    .line 7
    .line 8
    iget-wide v7, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageStart:J

    .line 9
    .line 10
    iget-wide v9, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageEnd:J

    .line 11
    .line 12
    invoke-virtual/range {v0 .. v10}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPointsForAttachBaseContext(JJJJJ)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final getAbcEnd()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcEnd:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getAbcStart()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcStart:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getExopackageEnd()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageEnd:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getExopackageStart()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->exopackageStart:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getProcessStartTime()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->processStartTime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final setAbcEnd(J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/app/AuraApplication$StartupTimings;->abcEnd:J

    .line 1
    .line 2
    return-void
.end method
