.class public abstract Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final provideAnalytics2Logger()LX/H4A;
    .locals 2

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    new-instance v1, LX/H4B;

    .line 5
    .line 6
    invoke-direct {v1, v0}, LX/H4B;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    new-instance v0, LX/H4A;

    .line 10
    .line 11
    invoke-direct {v0, v1}, LX/H4A;-><init>(LX/H4B;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public static final provideAnalyticsConfig()LX/H66;
    .locals 1

    .line 0
    const-string v0, "AnalyticsConfig not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideAnalyticsLogger()LX/H5x;
    .locals 1

    .line 0
    const-string v0, "AnalyticsLogger not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideBackgroundExecution()LX/H5s;
    .locals 1

    .line 0
    const-string v0, "BackgroundExecution not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideDebugAndTestConfig()LX/Gzg;
    .locals 1

    .line 0
    const-string v0, "DebugAndTestConfig not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideFbSharedPreferences()Lcom/facebook/prefs/shared/FbSharedPreferences;
    .locals 1

    .line 0
    const-string v0, "FbSharedPreferences not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideLightweightQuickPerformanceLogger()Lcom/facebook/quicklog/LightweightQuickPerformanceLogger;
    .locals 1

    .line 0
    const-string v0, "LightweightQuickPerformanceLogger not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideLogger()LX/ES4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "*>;"
        }
    .end annotation

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideLogger$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideLogger$1;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method

.method public static final provideMobileConfigErrorReporter()Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideMobileConfigErrorReporter$1;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideMobileConfigErrorReporter$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideMobileConfigErrorReporter$1;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method

.method public static final provideQuicklogNameProvider()Lcom/facebook/aura/qpl/AuraQplNameProvider;
    .locals 1

    .line 0
    const-string v0, "QuicklogNameProvider not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideSessionScopedAnalytics2Logger()LX/H4A;
    .locals 2

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    new-instance v1, LX/H4B;

    .line 5
    .line 6
    invoke-direct {v1, v0}, LX/H4B;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    new-instance v0, LX/H4A;

    .line 10
    .line 11
    invoke-direct {v0, v1}, LX/H4A;-><init>(LX/H4B;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public static final provideSessionScopedLogger()LX/ES4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/ES4<",
            "*>;"
        }
    .end annotation

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideSessionScopedLogger$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/app/noopbindings/infra/NoOpInfraBindingsKt$provideSessionScopedLogger$1;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method
