.class public final Lcom/facebook/aura/app/AuraAppComponentFactory;
.super LX/Ftu;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/app/AuraAppComponentFactory$Companion;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/app/AuraAppComponentFactory$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/AuraAppComponentFactory;->Companion:Lcom/facebook/aura/app/AuraAppComponentFactory$Companion;

    .line 6
    .line 7
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    sput-wide v0, LX/Grc;->A01:J

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/AppComponentFactory;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public instantiateActivity(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    sget-object v2, Lcom/facebook/aura/perf/entrypathinstrumentation/HatchEntryPathInstrumentation;->instance:LX/FtJ;

    .line 5
    .line 6
    iget-object v0, v2, LX/FtJ;->A01:LX/Fdy;

    .line 7
    .line 8
    invoke-interface {v0, p2, p3, p1, v1}, LX/Fdy;->classify(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/ClassLoader;Z)LX/H76;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v0, v2, LX/FtJ;->A04:LX/H9P;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, LX/H76;->A00(LX/H9P;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-static {p3, v2, v0, p2}, LX/FtJ;->A02(Landroid/content/Intent;LX/FtJ;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p3, v2}, LX/FtJ;->A01(Landroid/content/Intent;LX/FtJ;)V

    .line 25
    .line 26
    .line 27
    iget-object v2, v2, LX/FtJ;->A04:LX/H9P;

    .line 28
    .line 29
    const-string v1, "intentFlags"

    .line 30
    .line 31
    sget-object v0, LX/FtJ;->A06:LX/HCA;

    .line 32
    .line 33
    invoke-static {p3, v0}, LX/FtJ;->A00(Landroid/content/Intent;Ljava/util/HashMap;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-interface {v2, v1, v0}, LX/H9P;->AQQ(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-super {p0, p1, p2, p3}, LX/Ftu;->instantiateActivity(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    return-object v0
.end method

.method public instantiateReceiver(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;
    .locals 4

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v3, Lcom/facebook/aura/perf/entrypathinstrumentation/HatchEntryPathInstrumentation;->instance:LX/FtJ;

    .line 4
    .line 5
    iget-object v2, v3, LX/FtJ;->A02:LX/Fdy;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-interface {v2, p2, p3, v1, v0}, LX/Fdy;->classify(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/ClassLoader;Z)LX/H76;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    iget-object v0, v3, LX/FtJ;->A04:LX/H9P;

    .line 16
    .line 17
    invoke-virtual {v1, v0}, LX/H76;->A00(LX/H9P;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    invoke-static {p3, v3}, LX/FtJ;->A01(Landroid/content/Intent;LX/FtJ;)V

    .line 21
    .line 22
    .line 23
    iget-object v2, v3, LX/FtJ;->A04:LX/H9P;

    .line 24
    .line 25
    const-string v1, "intentFlags"

    .line 26
    .line 27
    sget-object v0, LX/FtJ;->A07:LX/HCA;

    .line 28
    .line 29
    invoke-static {p3, v0}, LX/FtJ;->A00(Landroid/content/Intent;Ljava/util/HashMap;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-interface {v2, v1, v0}, LX/H9P;->AQQ(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    sget-object v0, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-static {p3, v3, v0, p2}, LX/FtJ;->A02(Landroid/content/Intent;LX/FtJ;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-super {p0, p1, p2, p3}, LX/Ftu;->instantiateReceiver(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public instantiateService(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;
    .locals 4

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v3, Lcom/facebook/aura/perf/entrypathinstrumentation/HatchEntryPathInstrumentation;->instance:LX/FtJ;

    .line 4
    .line 5
    iget-object v2, v3, LX/FtJ;->A03:LX/Fdy;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-interface {v2, p2, p3, v1, v0}, LX/Fdy;->classify(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/ClassLoader;Z)LX/H76;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    iget-object v0, v3, LX/FtJ;->A04:LX/H9P;

    .line 16
    .line 17
    invoke-virtual {v1, v0}, LX/H76;->A00(LX/H9P;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    invoke-static {p3, v3}, LX/FtJ;->A01(Landroid/content/Intent;LX/FtJ;)V

    .line 21
    .line 22
    .line 23
    sget-object v0, LX/FkO;->A01:Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-static {p3, v3, v0, p2}, LX/FtJ;->A02(Landroid/content/Intent;LX/FtJ;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-super {p0, p1, p2, p3}, LX/Ftu;->instantiateService(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method
