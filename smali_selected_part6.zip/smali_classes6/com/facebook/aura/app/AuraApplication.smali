.class public final Lcom/facebook/aura/app/AuraApplication;
.super Landroid/app/Application;
.source ""

# interfaces
.implements LX/H1k;


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/app/AuraApplication$Companion;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/app/AuraApplication$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/AuraApplication;->Companion:Lcom/facebook/aura/app/AuraApplication$Companion;

    .line 6
    .line 7
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    sput-wide v0, LX/Grc;->A02:J

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public attachBaseContext(Landroid/content/Context;)V
    .locals 19

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 7
    .line 8
    .line 9
    move-result-wide v13

    .line 10
    move-object/from16 v4, p0

    .line 11
    .line 12
    invoke-super {v4, v0}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    const-wide/16 v17, -0x1

    .line 16
    .line 17
    invoke-static {}, LX/Grc;->A00()J

    .line 18
    .line 19
    .line 20
    move-result-wide v11

    .line 21
    sget-object v0, LX/9Fw;->A00:Landroid/app/Application;

    .line 22
    .line 23
    invoke-static {v0, v4}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    sput-object p0, LX/9Fw;->A00:Landroid/app/Application;

    .line 30
    .line 31
    :try_start_0
    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    new-instance v0, LX/2lN;

    .line 38
    .line 39
    invoke-direct {v0, v4}, LX/2lN;-><init>(Landroid/app/Application;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    :catch_0
    move-object v0, v4

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move-object v0, v4

    .line 46
    :goto_0
    sput-object v0, LX/9Fw;->A01:Landroid/content/Context;

    .line 47
    .line 48
    :cond_1
    invoke-static {}, Landroid/app/ActivityThread;->currentActivityThread()Landroid/app/ActivityThread;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-static {v0}, LX/H1H;->A01(Landroid/app/ActivityThread;)V

    .line 53
    .line 54
    .line 55
    sget-boolean v0, LX/FnY;->A00:Z

    .line 56
    .line 57
    const-class v3, LX/FnY;

    .line 58
    .line 59
    monitor-enter v3

    .line 60
    :try_start_1
    sget-object v1, LX/Fif;->A01:LX/Fif;

    .line 61
    .line 62
    sget-object v0, LX/FnY;->A02:LX/FnZ;

    .line 63
    .line 64
    invoke-interface {v0}, LX/FnZ;->AHu()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    iput v0, v1, LX/Fif;->A00:I

    .line 69
    .line 70
    sput-object v1, LX/FnY;->A02:LX/FnZ;

    .line 71
    .line 72
    sget-object v0, LX/FnY;->A02:LX/FnZ;

    .line 73
    .line 74
    sput-object v0, LX/H2K;->A00:LX/FnZ;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 75
    .line 76
    monitor-exit v3

    .line 77
    const/4 v2, 0x4

    .line 78
    monitor-enter v3

    .line 79
    :try_start_2
    sget-boolean v0, LX/FnY;->A00:Z

    .line 80
    .line 81
    xor-int/lit8 v1, v0, 0x1

    .line 82
    .line 83
    const-string v0, "Log level has been frozen! You can\'t change it again."

    .line 84
    .line 85
    if-eqz v1, :cond_3

    .line 86
    .line 87
    sget-object v0, LX/FnY;->A02:LX/FnZ;

    .line 88
    .line 89
    invoke-interface {v0, v2}, LX/FnZ;->AeE(I)V

    .line 90
    .line 91
    .line 92
    sget-object v0, LX/FnY;->A01:Ljava/util/List;

    .line 93
    .line 94
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_2

    .line 103
    .line 104
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    invoke-static {v2}, Lcom/facebook/xplat/fbglog/FbGlog;->setLogLevel(I)V

    .line 108
    .line 109
    .line 110
    goto :goto_1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 111
    :cond_2
    monitor-exit v3

    .line 112
    monitor-enter v3

    .line 113
    const/4 v5, 0x1

    .line 114
    :try_start_3
    sput-boolean v5, LX/FnY;->A00:Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 115
    .line 116
    monitor-exit v3

    .line 117
    sget-object v10, Lcom/facebook/aura/qpl/startup/HatchStartupQpl;->Companion:Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;

    .line 118
    .line 119
    const-string/jumbo v0, "soloader_init_start"

    .line 120
    .line 121
    .line 122
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    :try_start_4
    invoke-static {v4, v6}, LX/Hva;->A06(Landroid/content/Context;I)V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    .line 126
    .line 127
    .line 128
    const-string/jumbo v0, "soloader_init_end"

    .line 129
    .line 130
    .line 131
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    sget-object v3, Lcom/facebook/perf/background/BackgroundStartupDetector;->Companion:LX/H1Y;

    .line 135
    .line 136
    move v7, v6

    .line 137
    move v8, v6

    .line 138
    move v9, v6

    .line 139
    invoke-virtual/range {v3 .. v9}, LX/H1Y;->A02(Landroid/app/Application;ZZZZZ)Lcom/facebook/perf/background/BackgroundStartupDetector;

    .line 140
    .line 141
    .line 142
    const-string v0, "lacrima_init_start"

    .line 143
    .line 144
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    sget-object v3, Lcom/facebook/aura/crashreporting/AuraLacrimaConfig;->INSTANCE:Lcom/facebook/aura/crashreporting/AuraLacrimaConfig;

    .line 148
    .line 149
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 150
    .line 151
    .line 152
    move-result-wide v5

    .line 153
    sget-object v7, Lcom/facebook/aura/app/AuraApplication$attachBaseContext$1;->INSTANCE:Lcom/facebook/aura/app/AuraApplication$attachBaseContext$1;

    .line 154
    .line 155
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 156
    .line 157
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getState()LX/2J3;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    new-instance v0, Lcom/facebook/aura/app/AuraApplication$attachBaseContext$$inlined$map$1;

    .line 162
    .line 163
    invoke-direct {v0, v1}, Lcom/facebook/aura/app/AuraApplication$attachBaseContext$$inlined$map$1;-><init>(LX/2Lw;)V

    .line 164
    .line 165
    .line 166
    move-object v8, v0

    .line 167
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/crashreporting/AuraLacrimaConfig;->earlyJavaInit(Landroid/app/Application;JLkotlin/jvm/functions/Function0;LX/2Lw;)V

    .line 168
    .line 169
    .line 170
    const-string v0, "lacrima_init_end"

    .line 171
    .line 172
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    const-string v0, "mc_init_start"

    .line 176
    .line 177
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    sget-object v0, Lcom/facebook/aura/mobileconfig/AuraMobileConfig;->INSTANCE:Lcom/facebook/aura/mobileconfig/AuraMobileConfig;

    .line 181
    .line 182
    invoke-virtual {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfig;->ensureInitialized()V

    .line 183
    .line 184
    .line 185
    const-string v0, "mc_init_end"

    .line 186
    .line 187
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    const-string/jumbo v0, "sessionless_mc_ready"

    .line 191
    .line 192
    .line 193
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    const-string v0, "graphql_init_start"

    .line 197
    .line 198
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    sget-object v0, Lcom/facebook/aura/graphql/AuraGraphQLExecutorFactory;->INSTANCE:Lcom/facebook/aura/graphql/AuraGraphQLExecutorFactory;

    .line 202
    .line 203
    invoke-virtual {v0}, Lcom/facebook/aura/graphql/AuraGraphQLExecutorFactory;->init()V

    .line 204
    .line 205
    .line 206
    const-string v0, "graphql_init_end"

    .line 207
    .line 208
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    const-string v0, "qpl_init_start"

    .line 212
    .line 213
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    sget-object v0, Lcom/facebook/aura/qpl/init/AuraQplStartup;->INSTANCE:Lcom/facebook/aura/qpl/init/AuraQplStartup;

    .line 217
    .line 218
    invoke-virtual {v0, v4}, Lcom/facebook/aura/qpl/init/AuraQplStartup;->init(Landroid/app/Application;)V

    .line 219
    .line 220
    .line 221
    const-string v0, "qpl_init_end"

    .line 222
    .line 223
    invoke-virtual {v10, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 227
    .line 228
    .line 229
    move-result-wide v15

    .line 230
    move-wide/from16 p0, v17

    .line 231
    .line 232
    invoke-virtual/range {v10 .. v20}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPointsForAttachBaseContext(JJJJJ)V

    .line 233
    .line 234
    .line 235
    return-void

    .line 236
    :catch_1
    move-exception v0

    .line 237
    invoke-static {v0}, LX/EYt;->A0h(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    throw v0

    .line 242
    :catchall_0
    move-exception v0

    .line 243
    :try_start_5
    monitor-exit v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 244
    throw v0

    .line 245
    :cond_3
    :try_start_6
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 250
    :catchall_1
    move-exception v0

    .line 251
    :try_start_7
    monitor-exit v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 252
    throw v0

    .line 253
    :catchall_2
    move-exception v0

    .line 254
    :try_start_8
    monitor-exit v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 255
    throw v0
.end method

.method public getWorkManagerConfiguration()LX/HoT;
    .locals 3

    .line 0
    sget-object p0, Lcom/facebook/aura/executors/AuraWorkerFactoryHolder;->workerFactory:LX/H2M;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/executors/AuraWorkManagerTaskExecutor;->INSTANCE:Lcom/facebook/aura/executors/AuraWorkManagerTaskExecutor;

    .line 7
    .line 8
    invoke-static {v2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 9
    .line 10
    .line 11
    sget-object v1, Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;->INSTANCE:Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;

    .line 12
    .line 13
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, LX/HoT;

    .line 17
    .line 18
    invoke-direct {v0, v1, p0, v2}, LX/HoT;-><init>(LX/0oe;LX/H2N;Ljava/util/concurrent/Executor;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public onCreate()V
    .locals 5

    .line 0
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    sput-boolean v0, LX/36M;->A00:Z

    .line 5
    .line 6
    sput-boolean v0, LX/ATP;->A02:Z

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/startup/AuraStartupMetricTracker;->instance:Lcom/facebook/aura/startup/AuraStartupMetricTracker;

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    invoke-virtual {v4, p0, v0}, Lcom/facebook/aura/startup/AuraStartupMetricTracker;->startColdStartImmediate(Landroid/app/Application;Z)V

    .line 12
    .line 13
    .line 14
    sget-object v2, Lcom/facebook/aura/qpl/startup/HatchStartupQpl;->Companion:Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;

    .line 15
    .line 16
    const-string v0, "app_on_create_start"

    .line 17
    .line 18
    invoke-virtual {v2, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/ui/adaptive/AuraOrientationPolicy;->INSTANCE:Lcom/facebook/aura/ui/adaptive/AuraOrientationPolicy;

    .line 22
    .line 23
    invoke-virtual {v0, p0}, Lcom/facebook/aura/ui/adaptive/AuraOrientationPolicy;->install(Landroid/app/Application;)V

    .line 24
    .line 25
    .line 26
    invoke-static {}, LX/003;->A0P()Landroid/os/Handler;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    new-instance v0, Lcom/facebook/aura/app/AuraApplication$onCreate$1;

    .line 31
    .line 32
    invoke-direct {v0, p0}, Lcom/facebook/aura/app/AuraApplication$onCreate$1;-><init>(Lcom/facebook/aura/app/AuraApplication;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, v0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    .line 36
    .line 37
    .line 38
    sget-object v1, Lcom/facebook/aura/startup/AuraStartupOrchestrator;->INSTANCE:Lcom/facebook/aura/startup/AuraStartupOrchestrator;

    .line 39
    .line 40
    sget-object v0, Lcom/facebook/aura/startup/appjob/ScopeFilter;->ALL_PROCESSES_ONLY:Lcom/facebook/aura/startup/appjob/ScopeFilter;

    .line 41
    .line 42
    invoke-virtual {v1, v0}, Lcom/facebook/aura/startup/AuraStartupOrchestrator;->start(Lcom/facebook/aura/startup/appjob/ScopeFilter;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v4, p0, v3}, LX/H7t;->onBackgroundStartupDetectorInstalled(Landroid/app/Application;Lkotlin/jvm/functions/Function0;)V

    .line 46
    .line 47
    .line 48
    const-string v0, "app_on_create_end"

    .line 49
    .line 50
    invoke-virtual {v2, v0}, Lcom/facebook/aura/qpl/startup/HatchStartupQpl$Companion;->markerPoint(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method
