.class public final Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;

    .line 1
    .line 2
    if-eqz v0, :cond_8

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_8

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->label:I

    .line 23
    .line 24
    const/4 v8, 0x1

    .line 25
    const-string v5, "HatchInAppReview"

    .line 26
    .line 27
    const/4 v4, 0x2

    .line 28
    const/4 v3, 0x0

    .line 29
    if-eqz v0, :cond_3

    .line 30
    .line 31
    if-eq v0, v8, :cond_5

    .line 32
    .line 33
    if-ne v0, v4, :cond_9

    .line 34
    .line 35
    iget-object p1, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->L$0:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 38
    .line 39
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_0
    check-cast v2, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;

    .line 43
    .line 44
    invoke-virtual {p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    instance-of v0, v2, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 49
    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    move-object v0, v2

    .line 53
    check-cast v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 54
    .line 55
    if-eqz v0, :cond_1

    .line 56
    .line 57
    iget-object v3, v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->reason:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 58
    .line 59
    :cond_1
    const-string v0, "Google Play in-app review request completed trigger=%s failureReason=%s"

    .line 60
    .line 61
    invoke-static {v1, v3, v5, v0}, LX/FnY;->A02(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 65
    .line 66
    invoke-virtual {v0, v2, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->logRequestResult(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)V

    .line 67
    .line 68
    .line 69
    :cond_2
    :goto_1
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 70
    .line 71
    return-object v7

    .line 72
    :cond_3
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 76
    .line 77
    invoke-virtual {v0, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->shouldRequestReview$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_2

    .line 82
    .line 83
    sget-object v2, LX/I9a;->A00:LX/I9a;

    .line 84
    .line 85
    iget-object v1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;->$context:Landroid/content/Context;

    .line 86
    .line 87
    const v0, 0xbdfcb8

    .line 88
    .line 89
    .line 90
    invoke-virtual {v2, v1, v0}, LX/FQl;->A01(Landroid/content/Context;I)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_4

    .line 95
    .line 96
    sget-object v2, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 97
    .line 98
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->PLAY_SERVICES_UNAVAILABLE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 99
    .line 100
    :goto_2
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 101
    .line 102
    invoke-direct {v0, v1, v3}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2, v0, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->logRequestResult(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)V

    .line 106
    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_4
    iput-object p1, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->L$0:Ljava/lang/Object;

    .line 110
    .line 111
    iput v8, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->label:I

    .line 112
    .line 113
    const-wide/16 v0, 0xbb8

    .line 114
    .line 115
    invoke-static {v0, v1, v6}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    if-ne v0, v7, :cond_6

    .line 120
    .line 121
    return-object v7

    .line 122
    :cond_5
    iget-object p1, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->L$0:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast p1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 125
    .line 126
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;->$context:Landroid/content/Context;

    .line 130
    .line 131
    invoke-static {v0}, Lcom/facebook/aura/utils/ContextUtilsKt;->findActivity(Landroid/content/Context;)Landroid/app/Activity;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    if-eqz v2, :cond_7

    .line 136
    .line 137
    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    if-nez v0, :cond_7

    .line 142
    .line 143
    invoke-virtual {v2}, Landroid/app/Activity;->isDestroyed()Z

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-nez v0, :cond_7

    .line 148
    .line 149
    const-string v1, "Requesting Google Play in-app review for trigger=%s"

    .line 150
    .line 151
    invoke-virtual {p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-static {v0, v5, v1}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewManager;

    .line 159
    .line 160
    iput-object p1, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->L$0:Ljava/lang/Object;

    .line 161
    .line 162
    iput-object v3, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->L$1:Ljava/lang/Object;

    .line 163
    .line 164
    iput v4, v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;->label:I

    .line 165
    .line 166
    invoke-virtual {v0, v2, p1, v6}, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestReview(Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v2

    .line 170
    if-ne v2, v7, :cond_0

    .line 171
    .line 172
    return-object v7

    .line 173
    :cond_7
    sget-object v2, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 174
    .line 175
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->ACTIVITY_GONE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 176
    .line 177
    goto :goto_2

    .line 178
    :cond_8
    new-instance v6, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;

    .line 179
    .line 180
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1$emit$1;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;LX/2M4;)V

    .line 181
    .line 182
    .line 183
    goto/16 :goto_0

    .line 184
    .line 185
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/appreview/HatchInAppReviewEffectKt$HatchInAppReviewEffect$1$1$1;->emit(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
