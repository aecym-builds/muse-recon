.class public final Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FWz;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/FWz;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;

.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reviewManager:LX/FYQ;

.field public final synthetic $trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;


# direct methods
.method public constructor <init>(LX/DT0;Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/FYQ;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;",
            "Landroid/app/Activity;",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "LX/FYQ;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$activity:Landroid/app/Activity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$reviewManager:LX/FYQ;

    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final onComplete(LX/FWb;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FWb<",
            "Lcom/google/android/play/core/review/ReviewInfo;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 5
    .line 6
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    invoke-virtual {p1}, LX/FWb;->A0C()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const-string v5, "HatchInAppReview"

    .line 17
    .line 18
    const/4 v4, 0x0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    invoke-virtual {p1}, LX/FWb;->A08()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$activity:Landroid/app/Activity;

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$activity:Landroid/app/Activity;

    .line 36
    .line 37
    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    :try_start_0
    const-string v1, "Calling launchReviewFlow for trigger=%s"

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 46
    .line 47
    invoke-virtual {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {v0, v5, v1}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 55
    .line 56
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 57
    .line 58
    invoke-virtual {v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->logLaunchAttempt(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)V

    .line 59
    .line 60
    .line 61
    iget-object v7, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$reviewManager:LX/FYQ;

    .line 62
    .line 63
    iget-object v6, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$activity:Landroid/app/Activity;

    .line 64
    .line 65
    invoke-virtual {p1}, LX/FWb;->A08()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    check-cast v2, Lcom/google/android/play/core/review/ReviewInfo;

    .line 70
    .line 71
    check-cast v7, LX/FYP;

    .line 72
    .line 73
    check-cast v2, Lcom/google/android/play/core/review/zza;

    .line 74
    .line 75
    iget-boolean v0, v2, Lcom/google/android/play/core/review/zza;->A01:Z

    .line 76
    .line 77
    if-eqz v0, :cond_0

    .line 78
    .line 79
    invoke-static {v4}, LX/FWa;->A01(Ljava/lang/Object;)LX/FWa;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    :goto_0
    iget-object v2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 84
    .line 85
    iget-object v1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 86
    .line 87
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;

    .line 88
    .line 89
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/DT0;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v3, v0}, LX/FWb;->A05(LX/FWz;)LX/FWa;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_0
    const-class v0, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;

    .line 101
    .line 102
    new-instance v3, Landroid/content/Intent;

    .line 103
    .line 104
    invoke-direct {v3, v6, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 105
    .line 106
    .line 107
    const-string v1, "confirmation_intent"

    .line 108
    .line 109
    iget-object v0, v2, Lcom/google/android/play/core/review/zza;->A00:Landroid/app/PendingIntent;

    .line 110
    .line 111
    invoke-virtual {v3, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 112
    .line 113
    .line 114
    invoke-static {v6}, LX/002;->A0R(Landroid/app/Activity;)Landroid/view/View;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-virtual {v0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    const-string/jumbo v0, "window_flags"

    .line 123
    .line 124
    .line 125
    invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 126
    .line 127
    .line 128
    new-instance v2, LX/FTy;

    .line 129
    .line 130
    invoke-direct {v2}, LX/FTy;-><init>()V

    .line 131
    .line 132
    .line 133
    iget-object v0, v7, LX/FYP;->A00:Landroid/os/Handler;

    .line 134
    .line 135
    new-instance v1, Lcom/google/android/play/core/review/zzc;

    .line 136
    .line 137
    invoke-direct {v1, v0, v2}, Lcom/google/android/play/core/review/zzc;-><init>(Landroid/os/Handler;LX/FTy;)V

    .line 138
    .line 139
    .line 140
    const-string/jumbo v0, "result_receiver"

    .line 141
    .line 142
    .line 143
    invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v6, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 147
    .line 148
    .line 149
    iget-object v3, v2, LX/FTy;->A00:LX/FWa;

    .line 150
    .line 151
    goto :goto_0

    .line 152
    :goto_1
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 153
    :catch_0
    move-exception v3

    .line 154
    const-string v0, "Unable to launch Google Play in-app review"

    .line 155
    .line 156
    invoke-static {v5, v0, v3}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 157
    .line 158
    .line 159
    iget-object v2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 160
    .line 161
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->LAUNCH_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 162
    .line 163
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 164
    .line 165
    invoke-direct {v0, v1, v3}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 166
    .line 167
    .line 168
    invoke-interface {v2, v4, v0}, LX/DT0;->Ac8(LX/JDM;Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    return-void

    .line 172
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 173
    .line 174
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->ACTIVITY_GONE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 175
    .line 176
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 177
    .line 178
    invoke-direct {v0, v1, v4}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 179
    .line 180
    .line 181
    invoke-interface {v2, v4, v0}, LX/DT0;->Ac8(LX/JDM;Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    return-void

    .line 185
    :cond_2
    invoke-virtual {p1}, LX/FWb;->A07()Ljava/lang/Exception;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    const-string v0, "Unable to request Google Play in-app review"

    .line 190
    .line 191
    invoke-static {v5, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 192
    .line 193
    .line 194
    iget-object v3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;->$continuation:LX/DT0;

    .line 195
    .line 196
    sget-object v2, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->REQUEST_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 197
    .line 198
    invoke-virtual {p1}, LX/FWb;->A07()Ljava/lang/Exception;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 203
    .line 204
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 205
    .line 206
    .line 207
    invoke-interface {v3, v4, v0}, LX/DT0;->Ac8(LX/JDM;Ljava/lang/Object;)V

    .line 208
    .line 209
    .line 210
    :cond_3
    return-void
.end method
