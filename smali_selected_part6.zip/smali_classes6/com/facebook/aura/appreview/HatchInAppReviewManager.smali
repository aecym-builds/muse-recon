.class public final Lcom/facebook/aura/appreview/HatchInAppReviewManager;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewManager;

.field public static final TAG:Ljava/lang/String; = "HatchInAppReview"

.field public static final requestInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewManager;

    .line 6
    .line 7
    invoke-static {}, LX/8mk;->A0s()Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$requestReviewFlow(Lcom/facebook/aura/appreview/HatchInAppReviewManager;Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestReviewFlow(Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final requestReviewFlow(Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p3}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v6

    .line 8
    invoke-virtual {v6}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    move-object v6, v0

    .line 15
    :cond_0
    new-instance v5, LX/FZ2;

    .line 16
    .line 17
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    const-string v3, "com.android.vending"

    .line 24
    .line 25
    const/4 v1, 0x0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 26
    :try_start_1
    invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0, v3, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-boolean v0, v0, Landroid/content/pm/ApplicationInfo;->enabled:Z

    .line 35
    .line 36
    if-eqz v0, :cond_5

    .line 37
    .line 38
    invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const/16 v0, 0x40

    .line 43
    .line 44
    invoke-virtual {v1, v3, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iget-object v8, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 49
    .line 50
    if-eqz v8, :cond_4
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    .line 51
    .line 52
    :try_start_2
    array-length v7, v8

    .line 53
    if-eqz v7, :cond_4

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    :goto_0
    aget-object v0, v8, v2

    .line 57
    .line 58
    invoke-virtual {v0}, Landroid/content/pm/Signature;->toByteArray()[B

    .line 59
    .line 60
    .line 61
    move-result-object v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 62
    :try_start_3
    invoke-static {}, LX/EYt;->A0t()Ljava/security/MessageDigest;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    goto :goto_1
    :try_end_3
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 67
    :catch_0
    :try_start_4
    const-string p0, ""

    .line 68
    .line 69
    goto :goto_2

    .line 70
    :goto_1
    invoke-static {v0, v1}, LX/EYy;->A0r(Ljava/security/MessageDigest;[B)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    :goto_2
    const-string v0, "8P1sW0EPJcslw7UzRsiXL64w-O50Ed-RBICtay1g24M"

    .line 75
    .line 76
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-nez v0, :cond_3

    .line 81
    .line 82
    sget-object v1, Landroid/os/Build;->TAGS:Ljava/lang/String;

    .line 83
    .line 84
    const-string v0, "dev-keys"

    .line 85
    .line 86
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-nez v0, :cond_1

    .line 91
    .line 92
    const-string/jumbo v0, "test-keys"

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_2

    .line 100
    .line 101
    :cond_1
    const-string v0, "GXWy8XF3vIml3_MfnmSmyuKBpT3B0dWbHRR_4cgq-gA"

    .line 102
    .line 103
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-nez v0, :cond_3

    .line 108
    .line 109
    :cond_2
    add-int/lit8 v2, v2, 0x1

    .line 110
    .line 111
    if-ge v2, v7, :cond_5

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_3
    const-string v0, "com.google.android.finsky.BIND_IN_APP_REVIEW_SERVICE"

    .line 115
    .line 116
    invoke-static {v0}, LX/EYt;->A0C(Ljava/lang/String;)Landroid/content/Intent;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    invoke-virtual {v0, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    sget-object v2, LX/FZ2;->A01:LX/FZ6;

    .line 125
    .line 126
    sget-object v1, LX/FZZ;->A00:LX/FZZ;

    .line 127
    .line 128
    new-instance v0, LX/FZ0;

    .line 129
    .line 130
    invoke-direct {v0, v6, v3, v2, v1}, LX/FZ0;-><init>(Landroid/content/Context;Landroid/content/Intent;LX/FZ6;LX/FZZ;)V

    .line 131
    .line 132
    .line 133
    iput-object v0, v5, LX/FZ2;->A00:LX/FZ0;

    .line 134
    .line 135
    goto :goto_3

    .line 136
    :cond_4
    sget-object v1, LX/FZL;->A00:LX/FZ6;

    .line 137
    .line 138
    const-string v3, "Phonesky package is not signed -- possibly self-built package. Could not verify."

    .line 139
    .line 140
    const/4 v0, 0x5

    .line 141
    const-string v2, "PlayCore"

    .line 142
    .line 143
    invoke-static {v2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-eqz v0, :cond_5

    .line 148
    .line 149
    iget-object v1, v1, LX/FZ6;->A00:Ljava/lang/String;

    .line 150
    .line 151
    const-string v0, " : "

    .line 152
    .line 153
    invoke-static {v1, v0, v3, v2}, LX/Gi8;->A1L(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    :catch_1
    :cond_5
    :goto_3
    new-instance v6, LX/FYP;

    .line 157
    .line 158
    invoke-direct {v6, v5}, LX/FYP;-><init>(LX/FZ2;)V

    .line 159
    .line 160
    .line 161
    iget-object v2, v6, LX/FYP;->A01:LX/FZ2;

    .line 162
    .line 163
    sget-object v5, LX/FZ2;->A01:LX/FZ6;

    .line 164
    .line 165
    const-string v0, "com.facebook.aura"

    .line 166
    .line 167
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    const-string v0, "requestInAppReview (%s)"

    .line 172
    .line 173
    invoke-virtual {v5, v0, v1}, LX/FZ6;->A00(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    iget-object v8, v2, LX/FZ2;->A00:LX/FZ0;

    .line 177
    .line 178
    if-nez v8, :cond_8

    .line 179
    .line 180
    const-string v3, "Play Store app is either not installed or not the official version"

    .line 181
    .line 182
    const/4 v0, 0x6

    .line 183
    const-string v2, "PlayCore"

    .line 184
    .line 185
    invoke-static {v2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    if-eqz v0, :cond_6

    .line 190
    .line 191
    iget-object v1, v5, LX/FZ6;->A00:Ljava/lang/String;

    .line 192
    .line 193
    const-string v0, " : "

    .line 194
    .line 195
    invoke-static {v1, v0, v3}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 200
    .line 201
    .line 202
    :cond_6
    const/4 v5, -0x1

    .line 203
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 204
    .line 205
    .line 206
    move-result-object v7

    .line 207
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 208
    .line 209
    .line 210
    move-result-object v8

    .line 211
    sget-object v1, LX/FYf;->A00:Ljava/util/Map;

    .line 212
    .line 213
    invoke-interface {v1, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    if-nez v0, :cond_7

    .line 218
    .line 219
    const-string v0, ""

    .line 220
    .line 221
    :goto_4
    filled-new-array {v8, v0}, [Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    const-string v0, "Review Error(%d): %s"

    .line 226
    .line 227
    invoke-static {v7, v0, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    new-instance v1, Lcom/google/android/gms/common/api/Status;

    .line 232
    .line 233
    invoke-direct {v1, v5, v0}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    .line 234
    .line 235
    .line 236
    new-instance v0, Lcom/google/android/play/core/review/ReviewException;

    .line 237
    .line 238
    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/ApiException;-><init>(Lcom/google/android/gms/common/api/Status;)V

    .line 239
    .line 240
    .line 241
    invoke-static {v0}, LX/FWa;->A00(Ljava/lang/Exception;)LX/FWa;

    .line 242
    .line 243
    .line 244
    move-result-object v7

    .line 245
    :goto_5
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;

    .line 246
    .line 247
    invoke-direct {v0, v4, p1, p2, v6}, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1;-><init>(LX/DT0;Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/FYQ;)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v7, v0}, LX/FWb;->A05(LX/FWz;)LX/FWa;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    goto :goto_7

    .line 258
    :cond_7
    invoke-static {v8, v1}, LX/602;->A0h(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v3

    .line 262
    sget-object v0, LX/FYf;->A01:Ljava/util/Map;

    .line 263
    .line 264
    invoke-static {v8, v0}, LX/602;->A0h(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    const-string v1, " (https://developer.android.com/reference/com/google/android/play/core/review/model/ReviewErrorCode.html#"

    .line 269
    .line 270
    const-string v0, ")"

    .line 271
    .line 272
    invoke-static {v3, v1, v2, v0}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    goto :goto_4

    .line 277
    :cond_8
    new-instance v1, LX/FTy;

    .line 278
    .line 279
    invoke-direct {v1}, LX/FTy;-><init>()V

    .line 280
    .line 281
    .line 282
    new-instance v5, LX/FYj;

    .line 283
    .line 284
    invoke-direct {v5, v1, v1, v2}, LX/FYj;-><init>(LX/FTy;LX/FTy;LX/FZ2;)V

    .line 285
    .line 286
    .line 287
    iget-object p0, v8, LX/FZ0;->A07:Ljava/lang/Object;

    .line 288
    .line 289
    monitor-enter p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 290
    :try_start_5
    iget-object v0, v8, LX/FZ0;->A0A:Ljava/util/Set;

    .line 291
    .line 292
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    iget-object v7, v1, LX/FTy;->A00:LX/FWa;

    .line 296
    .line 297
    new-instance v0, LX/FYn;

    .line 298
    .line 299
    invoke-direct {v0, v1, v8}, LX/FYn;-><init>(LX/FTy;LX/FZ0;)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v7, v0}, LX/FWb;->A05(LX/FWz;)LX/FWa;

    .line 303
    .line 304
    .line 305
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 306
    :try_start_6
    monitor-enter p0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    .line 307
    :try_start_7
    iget-object v0, v8, LX/FZ0;->A0B:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 308
    .line 309
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 310
    .line 311
    .line 312
    move-result v0

    .line 313
    if-lez v0, :cond_9

    .line 314
    .line 315
    iget-object v1, v8, LX/FZ0;->A06:LX/FZ6;

    .line 316
    .line 317
    const-string v3, "Already connected to the service."

    .line 318
    .line 319
    const/4 v0, 0x3

    .line 320
    const-string v2, "PlayCore"

    .line 321
    .line 322
    invoke-static {v2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 323
    .line 324
    .line 325
    move-result v0

    .line 326
    if-eqz v0, :cond_9

    .line 327
    .line 328
    iget-object v1, v1, LX/FZ6;->A00:Ljava/lang/String;

    .line 329
    .line 330
    const-string v0, " : "

    .line 331
    .line 332
    invoke-static {v1, v0, v3}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 333
    .line 334
    .line 335
    move-result-object v0

    .line 336
    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 337
    .line 338
    .line 339
    :cond_9
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 340
    :try_start_8
    iget-object v0, v5, LX/FYx;->A00:LX/FTy;

    .line 341
    .line 342
    new-instance v1, LX/FYz;

    .line 343
    .line 344
    invoke-direct {v1, v0, v5, v8}, LX/FYz;-><init>(LX/FTy;LX/FYx;LX/FZ0;)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v8}, LX/FZ0;->A01()Landroid/os/Handler;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 352
    .line 353
    .line 354
    goto :goto_5
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2

    .line 355
    :catchall_0
    move-exception v0

    .line 356
    :try_start_9
    monitor-exit p0

    .line 357
    goto :goto_6
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    .line 358
    :catchall_1
    move-exception v0

    .line 359
    :try_start_a
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    .line 360
    :goto_6
    :try_start_b
    throw v0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_2

    .line 361
    :catch_2
    move-exception v2

    .line 362
    const-string v1, "HatchInAppReview"

    .line 363
    .line 364
    const-string v0, "Unable to request Google Play in-app review"

    .line 365
    .line 366
    invoke-static {v1, v0, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 367
    .line 368
    .line 369
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->REQUEST_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 370
    .line 371
    new-instance v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 372
    .line 373
    invoke-direct {v1, v0, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 374
    .line 375
    .line 376
    const/4 v0, 0x0

    .line 377
    invoke-virtual {v4, v0, v1}, LX/DSD;->Ac8(LX/JDM;Ljava/lang/Object;)V

    .line 378
    .line 379
    .line 380
    :goto_7
    invoke-virtual {v4}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    move-result-object v0

    .line 384
    return-object v0
.end method


# virtual methods
.method public final requestReview(Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_1

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_0
    new-instance v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;

    .line 32
    .line 33
    invoke-direct {v5, p0, p3}, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewManager;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    throw v0

    .line 42
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 46
    .line 47
    invoke-virtual {v0, v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_3

    .line 52
    .line 53
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->IN_FLIGHT:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    new-instance v3, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 57
    .line 58
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 59
    .line 60
    .line 61
    return-object v3

    .line 62
    :cond_3
    const/4 v0, 0x0

    .line 63
    :try_start_0
    iput-object v0, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->L$0:Ljava/lang/Object;

    .line 64
    .line 65
    iput-object v0, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->L$1:Ljava/lang/Object;

    .line 66
    .line 67
    iput v1, v5, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReview$1;->label:I

    .line 68
    .line 69
    invoke-direct {p0, p1, p2, v5}, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestReviewFlow(Landroid/app/Activity;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/2M4;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    if-ne v4, v3, :cond_4

    .line 74
    .line 75
    return-object v3

    .line 76
    :goto_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_4
    check-cast v4, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 80
    .line 81
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 82
    .line 83
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 84
    .line 85
    .line 86
    return-object v4

    .line 87
    :catchall_0
    move-exception v1

    .line 88
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewManager;->requestInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 89
    .line 90
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 91
    .line 92
    .line 93
    throw v1
.end method
