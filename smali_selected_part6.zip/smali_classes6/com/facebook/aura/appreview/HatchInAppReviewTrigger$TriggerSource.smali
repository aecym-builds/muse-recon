.class public final enum Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

.field public static final enum CONVERSATION_MESSAGES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

.field public static final enum FEED_LIKES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

.field public static final enum GOAL_CREATION_REQUESTED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

.field public static final enum IDEA_CREATED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;


# instance fields
.field public final analyticsValue:Ljava/lang/String;

.field public final surface:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const-string v3, "conversation_messages"

    .line 1
    .line 2
    const-string v2, "chat"

    .line 3
    .line 4
    const-string v1, "CONVERSATION_MESSAGES"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-instance v7, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 8
    .line 9
    invoke-direct {v7, v1, v0, v3, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sput-object v7, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->CONVERSATION_MESSAGES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 13
    .line 14
    const-string v3, "feed_likes"

    .line 15
    .line 16
    const-string v2, "feed"

    .line 17
    .line 18
    const-string v1, "FEED_LIKES"

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    new-instance v6, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 22
    .line 23
    invoke-direct {v6, v1, v0, v3, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v6, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->FEED_LIKES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 27
    .line 28
    const-string v3, "idea_created"

    .line 29
    .line 30
    const-string v2, "ideas"

    .line 31
    .line 32
    const-string v1, "IDEA_CREATED"

    .line 33
    .line 34
    const/4 v0, 0x2

    .line 35
    new-instance v5, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 36
    .line 37
    invoke-direct {v5, v1, v0, v3, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sput-object v5, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->IDEA_CREATED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 41
    .line 42
    const-string v4, "goal_creation_requested"

    .line 43
    .line 44
    const-string v3, "goals"

    .line 45
    .line 46
    const-string v2, "GOAL_CREATION_REQUESTED"

    .line 47
    .line 48
    const/4 v1, 0x3

    .line 49
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 50
    .line 51
    invoke-direct {v0, v2, v1, v4, v3}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->GOAL_CREATION_REQUESTED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 55
    .line 56
    filled-new-array {v7, v6, v5, v0}, [Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->$VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 61
    .line 62
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->$ENTRIES:LX/0vk;

    .line 67
    .line 68
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->analyticsValue:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->surface:Ljava/lang/String;

    .line 6
    .line 7
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->$VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getAnalyticsValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->analyticsValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSurface()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->surface:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
