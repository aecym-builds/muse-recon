.class public final Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final cause:Ljava/lang/Throwable;

.field public final reason:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->reason:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->cause:Ljava/lang/Throwable;

    .line 268435466
    .line 268435467
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;ILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->cause:Ljava/lang/Throwable;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReason()Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->reason:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 1
    .line 2
    return-object p0
.end method
