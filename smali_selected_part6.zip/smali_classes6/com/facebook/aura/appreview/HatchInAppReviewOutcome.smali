.class public interface abstract Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;
.super Ljava/lang/Object;
.source ""
