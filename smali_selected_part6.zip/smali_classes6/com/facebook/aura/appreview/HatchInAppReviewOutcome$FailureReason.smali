.class public final enum Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

.field public static final enum ACTIVITY_GONE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

.field public static final enum IN_FLIGHT:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

.field public static final enum LAUNCH_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

.field public static final enum PLAY_SERVICES_UNAVAILABLE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

.field public static final enum REQUEST_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;


# instance fields
.field public final analyticsValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "play_services_unavailable"

    .line 2
    .line 3
    const-string v0, "PLAY_SERVICES_UNAVAILABLE"

    .line 4
    .line 5
    new-instance v7, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 6
    .line 7
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v7, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->PLAY_SERVICES_UNAVAILABLE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "activity_gone"

    .line 14
    .line 15
    const-string v0, "ACTIVITY_GONE"

    .line 16
    .line 17
    new-instance v6, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 18
    .line 19
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v6, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->ACTIVITY_GONE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "in_flight"

    .line 26
    .line 27
    const-string v0, "IN_FLIGHT"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->IN_FLIGHT:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string/jumbo v1, "request_failed"

    .line 38
    .line 39
    .line 40
    const-string v0, "REQUEST_FAILED"

    .line 41
    .line 42
    new-instance v4, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 43
    .line 44
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 45
    .line 46
    .line 47
    sput-object v4, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->REQUEST_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 48
    .line 49
    const/4 v3, 0x4

    .line 50
    const-string v2, "launch_failed"

    .line 51
    .line 52
    const-string v1, "LAUNCH_FAILED"

    .line 53
    .line 54
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 55
    .line 56
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 57
    .line 58
    .line 59
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->LAUNCH_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 60
    .line 61
    filled-new-array {v7, v6, v5, v4, v0}, [Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->$VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 66
    .line 67
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->$ENTRIES:LX/0vk;

    .line 72
    .line 73
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->analyticsValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->$VALUES:[Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getAnalyticsValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->analyticsValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
