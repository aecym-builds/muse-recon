.class public final Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FWz;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/FWz;"
    }
.end annotation


# instance fields
.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;LX/DT0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "LX/DT0<",
            "-",
            "Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$continuation:LX/DT0;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final onComplete(LX/FWb;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FWb<",
            "Ljava/lang/Void;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$trigger:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    invoke-virtual {p1}, LX/FWb;->A0C()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const-string v2, "HatchInAppReview"

    .line 19
    .line 20
    const-string v0, "In-app review flow completed for trigger=%s successful=%s"

    .line 21
    .line 22
    invoke-static {v3, v1, v2, v0}, LX/FnY;->A02(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 26
    .line 27
    invoke-virtual {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->recordLaunchAttempt$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$continuation:LX/DT0;

    .line 31
    .line 32
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {p1}, LX/FWb;->A0C()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    const/4 v4, 0x0

    .line 43
    if-eqz v0, :cond_1

    .line 44
    .line 45
    iget-object v3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$continuation:LX/DT0;

    .line 46
    .line 47
    sget-object v2, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Success;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Success;

    .line 48
    .line 49
    :goto_0
    invoke-interface {v3, v4, v2}, LX/DT0;->Ac8(LX/JDM;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void

    .line 53
    :cond_1
    invoke-virtual {p1}, LX/FWb;->A07()Ljava/lang/Exception;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    const-string v0, "Unable to launch Google Play in-app review"

    .line 58
    .line 59
    invoke-static {v2, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 60
    .line 61
    .line 62
    iget-object v3, p0, Lcom/facebook/aura/appreview/HatchInAppReviewManager$requestReviewFlow$2$1$1;->$continuation:LX/DT0;

    .line 63
    .line 64
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->LAUNCH_FAILED:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 65
    .line 66
    invoke-virtual {p1}, LX/FWb;->A07()Ljava/lang/Exception;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    new-instance v2, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 71
    .line 72
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;-><init>(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    goto :goto_0
.end method
