.class public final Lcom/facebook/aura/appreview/HatchInAppReviewLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final EVENT_NAME:Ljava/lang/String; = "in_app_review_request"

.field public static final INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

.field public static final KEY_ERROR_CODE:Ljava/lang/String; = "error_code"

.field public static final KEY_MS_SINCE_REPLY_FAILURE:Ljava/lang/String; = "ms_since_reply_failure"

.field public static final KEY_TRIGGER:Ljava/lang/String; = "trigger"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final log(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/util/Map;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;

    .line 1
    .line 2
    invoke-virtual {p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getSurface()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v5

    .line 6
    new-instance v2, LX/Imj;

    .line 7
    .line 8
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v2, p2}, LX/Imj;->putAll(Ljava/util/Map;)V

    .line 12
    .line 13
    .line 14
    const-string/jumbo v1, "trigger"

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lastReplyFailureElapsedMs:Ljava/lang/Long;

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 29
    .line 30
    .line 31
    move-result-wide v0

    .line 32
    invoke-static {v0, v1}, LX/EYt;->A08(J)J

    .line 33
    .line 34
    .line 35
    move-result-wide v0

    .line 36
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v0, "ms_since_reply_failure"

    .line 41
    .line 42
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    :cond_0
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const/4 v6, 0x0

    .line 50
    const-string v4, "in_app_review_request"

    .line 51
    .line 52
    move-object v7, v6

    .line 53
    move-object p0, v6

    .line 54
    move-object p2, v6

    .line 55
    invoke-virtual/range {v3 .. v10}, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->logEvent(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/analytics/hatch/HatchAppEventLoggingContext;)V

    .line 56
    .line 57
    .line 58
    return-void
.end method


# virtual methods
.method public final logLaunchAttempt(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "launch_attempted"

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->log(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/util/Map;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final logRequestResult(Lcom/facebook/aura/appreview/HatchInAppReviewOutcome;Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Success;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Success;

    .line 4
    .line 5
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 12
    .line 13
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const-string/jumbo v0, "success"

    .line 18
    .line 19
    .line 20
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :goto_0
    invoke-direct {p0, p2, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewLogger;->log(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/util/Map;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 29
    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    new-instance v2, LX/Imj;

    .line 33
    .line 34
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 35
    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 38
    .line 39
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    const-string v0, "failure"

    .line 44
    .line 45
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->FAILURE_REASON:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 49
    .line 50
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    check-cast p1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;

    .line 55
    .line 56
    iget-object v0, p1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->reason:Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;

    .line 57
    .line 58
    invoke-virtual {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$FailureReason;->getAnalyticsValue()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    iget-object v1, p1, Lcom/facebook/aura/appreview/HatchInAppReviewOutcome$Failure;->cause:Ljava/lang/Throwable;

    .line 66
    .line 67
    instance-of v0, v1, Lcom/google/android/play/core/review/ReviewException;

    .line 68
    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    check-cast v1, Lcom/google/android/gms/common/api/ApiException;

    .line 72
    .line 73
    if-eqz v1, :cond_1

    .line 74
    .line 75
    iget-object v0, v1, Lcom/google/android/gms/common/api/ApiException;->mStatus:Lcom/google/android/gms/common/api/Status;

    .line 76
    .line 77
    iget v0, v0, Lcom/google/android/gms/common/api/Status;->A00:I

    .line 78
    .line 79
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    const-string v0, "error_code"

    .line 84
    .line 85
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    :cond_1
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    goto :goto_0

    .line 93
    :cond_2
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    throw v0
.end method
