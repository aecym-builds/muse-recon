.class public final Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

.field public static final KEY_AGENT_MESSAGES:Ljava/lang/String; = "agent_messages"

.field public static final KEY_CREATED_GOALS:Ljava/lang/String; = "created_goals"

.field public static final KEY_CREATED_IDEAS:Ljava/lang/String; = "created_ideas"

.field public static final KEY_DAYS_APP_USED:Ljava/lang/String; = "days_app_used"

.field public static final KEY_FEED_LIKES:Ljava/lang/String; = "feed_likes"

.field public static final KEY_LAST_DAY_APP_USED:Ljava/lang/String; = "last_day_app_used"

.field public static final KEY_LAST_REVIEW_ATTEMPT_MS:Ljava/lang/String; = "last_review_attempt_ms"

.field public static final KEY_USER_MESSAGES:Ljava/lang/String; = "user_messages"

.field public static final MILLIS_PER_DAY:J = 0x5265c00L

.field public static final REPLY_FAILURE_BLOCK_MS:J = 0x36ee80L

.field public static final TAG:Ljava/lang/String; = "HatchInAppReview"

.field public static volatile lastReplyFailureElapsedMs:Ljava/lang/Long;

.field public static final lock:Ljava/lang/Object;

.field public static final mutableRequests:LX/5Lx;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/5Lx<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            ">;"
        }
    .end annotation
.end field

.field public static final requests:LX/2QV;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2QV<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 6
    .line 7
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 12
    .line 13
    const/16 v2, 0x8

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, LX/5NB;->A00(Ljava/lang/Integer;II)LX/Ddz;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    sput-object v2, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->mutableRequests:LX/5Lx;

    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    new-instance v0, LX/ETm;

    .line 26
    .line 27
    invoke-direct {v0, v1, v2}, LX/ETm;-><init>(LX/Cbu;LX/2QV;)V

    .line 28
    .line 29
    .line 30
    sput-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->requests:LX/2QV;

    .line 31
    .line 32
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final canRecord(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)Z
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->isCooldownActive()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 v1, 0x0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 8
    .line 9
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->isInAppReviewEnabled()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-direct {p0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->hasUsedAppEnoughDays()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    :cond_0
    return v1
.end method

.method private final hasRecentReplyFailure()Z
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lastReplyFailureElapsedMs:Ljava/lang/Long;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    invoke-static {v0, v1}, LX/EYt;->A08(J)J

    .line 10
    .line 11
    .line 12
    move-result-wide v3

    .line 13
    const-wide/32 v1, 0x36ee80

    .line 14
    .line 15
    .line 16
    cmp-long v0, v3, v1

    .line 17
    .line 18
    if-gez v0, :cond_0

    .line 19
    .line 20
    const/4 p0, 0x1

    .line 21
    :cond_0
    return p0
.end method

.method private final hasUsedAppEnoughDays()Z
    .locals 4

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    const-string v2, "days_app_used"

    .line 5
    .line 6
    const-wide/16 v0, 0x0

    .line 7
    .line 8
    invoke-interface {v3, v2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v3

    .line 12
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewMinAppDays()J

    .line 15
    .line 16
    .line 17
    move-result-wide v1

    .line 18
    cmp-long v0, v3, v1

    .line 19
    .line 20
    invoke-static {v0}, LX/003;->A1D(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    return v0
.end method

.method private final isCooldownActive()Z
    .locals 5

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const-string v0, "last_review_attempt_ms"

    .line 5
    .line 6
    const-wide/16 v3, 0x0

    .line 7
    .line 8
    invoke-interface {v1, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v1

    .line 12
    cmp-long v0, v1, v3

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 17
    .line 18
    .line 19
    move-result-wide v4

    .line 20
    sub-long/2addr v4, v1

    .line 21
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewCooldownMs()J

    .line 24
    .line 25
    .line 26
    move-result-wide v2

    .line 27
    cmp-long v1, v4, v2

    .line 28
    .line 29
    const/4 v0, 0x1

    .line 30
    if-ltz v1, :cond_1

    .line 31
    .line 32
    :cond_0
    const/4 v0, 0x0

    .line 33
    :cond_1
    return v0
.end method

.method private final record(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/lang/String;)V
    .locals 7

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    sget-object v6, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 4
    .line 5
    invoke-direct {v6, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->canRecord(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v5, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-direct {v6}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const-wide/16 v0, 0x0

    .line 17
    .line 18
    invoke-interface {v2, p2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 19
    .line 20
    .line 21
    move-result-wide v3

    .line 22
    const-wide/16 v0, 0x1

    .line 23
    .line 24
    add-long/2addr v3, v0

    .line 25
    invoke-interface {v2}, LX/BVu;->A9u()LX/Df3;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0, p2, v3, v4}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 33
    .line 34
    .line 35
    invoke-direct {v6, p1}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->thresholdFor(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)J

    .line 36
    .line 37
    .line 38
    move-result-wide v1

    .line 39
    cmp-long v0, v3, v1

    .line 40
    .line 41
    if-ltz v0, :cond_0

    .line 42
    .line 43
    const/4 v5, 0x1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    :cond_0
    monitor-exit p0

    .line 45
    if-eqz v5, :cond_1

    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->mutableRequests:LX/5Lx;

    .line 48
    .line 49
    invoke-interface {v0, p1}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    :cond_1
    return-void

    .line 53
    :catchall_0
    move-exception v0

    .line 54
    monitor-exit p0

    .line 55
    throw v0
.end method

.method private final recordConversationMessage(Ljava/lang/String;)V
    .locals 10

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    sget-object v5, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 4
    .line 5
    sget-object v6, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->CONVERSATION_MESSAGES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 6
    .line 7
    invoke-direct {v5, v6}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->canRecord(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-direct {v5}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 14
    .line 15
    .line 16
    move-result-object v9

    .line 17
    const-wide/16 v1, 0x0

    .line 18
    .line 19
    invoke-interface {v9, p1, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 20
    .line 21
    .line 22
    move-result-wide v3

    .line 23
    const-wide/16 v7, 0x1

    .line 24
    .line 25
    add-long/2addr v3, v7

    .line 26
    invoke-interface {v9}, LX/BVu;->A9u()LX/Df3;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0, p1, v3, v4}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 34
    .line 35
    .line 36
    invoke-direct {v5, v6}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->thresholdFor(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)J

    .line 37
    .line 38
    .line 39
    move-result-wide v7

    .line 40
    const-string/jumbo v0, "user_messages"

    .line 41
    .line 42
    .line 43
    invoke-interface {v9, v0, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 44
    .line 45
    .line 46
    move-result-wide v4

    .line 47
    const-string v0, "agent_messages"

    .line 48
    .line 49
    invoke-interface {v9, v0, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 50
    .line 51
    .line 52
    move-result-wide v2

    .line 53
    cmp-long v0, v4, v7

    .line 54
    .line 55
    if-ltz v0, :cond_0

    .line 56
    .line 57
    cmp-long v1, v2, v7

    .line 58
    .line 59
    const/4 v0, 0x1

    .line 60
    if-gez v1, :cond_1

    .line 61
    .line 62
    :cond_0
    const/4 v0, 0x0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 63
    :cond_1
    monitor-exit p0

    .line 64
    if-eqz v0, :cond_2

    .line 65
    .line 66
    const-string v0, "agent_messages"

    .line 67
    .line 68
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_2

    .line 73
    .line 74
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->mutableRequests:LX/5Lx;

    .line 75
    .line 76
    invoke-interface {v0, v6}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    :cond_2
    return-void

    .line 80
    :catchall_0
    move-exception v0

    .line 81
    monitor-exit p0

    .line 82
    throw v0
.end method

.method private final reviewPrefs()LX/BVu;
    .locals 2

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraUserPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraUserPrefs;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraUserPrefStore;->REVIEWS:Lcom/facebook/aura/common/prefs/AuraUserPrefStore;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->REVIEWS:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 5
    .line 6
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/common/prefs/AuraUserPrefs;->currentAccountOrDevice(Lcom/facebook/aura/common/prefs/AuraUserPrefStore;Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method private final thresholdFor(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)J
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eq p1, p0, :cond_3

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    if-eq p1, p0, :cond_2

    .line 9
    .line 10
    const/4 p0, 0x2

    .line 11
    if-eq p1, p0, :cond_1

    .line 12
    .line 13
    const/4 p0, 0x3

    .line 14
    if-ne p1, p0, :cond_0

    .line 15
    .line 16
    sget-object p0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 17
    .line 18
    invoke-virtual {p0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewGoalCount()J

    .line 19
    .line 20
    .line 21
    move-result-wide p0

    .line 22
    return-wide p0

    .line 23
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    throw p0

    .line 28
    :cond_1
    sget-object p0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 29
    .line 30
    invoke-virtual {p0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewIdeaCount()J

    .line 31
    .line 32
    .line 33
    move-result-wide p0

    .line 34
    return-wide p0

    .line 35
    :cond_2
    sget-object p0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 36
    .line 37
    invoke-virtual {p0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewFeedLikeCount()J

    .line 38
    .line 39
    .line 40
    move-result-wide p0

    .line 41
    return-wide p0

    .line 42
    :cond_3
    sget-object p0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 43
    .line 44
    invoke-virtual {p0}, Lcom/facebook/aura/utils/HatchUtil;->inAppReviewResponseCount()J

    .line 45
    .line 46
    .line 47
    move-result-wide p0

    .line 48
    return-wide p0
.end method


# virtual methods
.method public final getLastReplyFailureElapsedMs$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()Ljava/lang/Long;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lastReplyFailureElapsedMs:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRequests$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()LX/2QV;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2QV<",
            "Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->requests:LX/2QV;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onAppOpened()V
    .locals 9

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->isInAppReviewEnabled()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 12
    .line 13
    invoke-direct {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 14
    .line 15
    .line 16
    move-result-object v8

    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v5

    .line 21
    const-wide/32 v0, 0x5265c00

    .line 22
    .line 23
    .line 24
    div-long/2addr v5, v0

    .line 25
    const-string v7, "last_day_app_used"

    .line 26
    .line 27
    const-wide/16 v1, 0x0

    .line 28
    .line 29
    invoke-interface {v8, v7, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 30
    .line 31
    .line 32
    move-result-wide v3

    .line 33
    cmp-long v0, v3, v5

    .line 34
    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    const-string v0, "days_app_used"

    .line 38
    .line 39
    invoke-interface {v8, v0, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    const-string v4, "days_app_used"

    .line 44
    .line 45
    invoke-interface {v8, v4, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 46
    .line 47
    .line 48
    move-result-wide v2

    .line 49
    const-wide/16 v0, 0x1

    .line 50
    .line 51
    add-long/2addr v2, v0

    .line 52
    invoke-interface {v8}, LX/BVu;->A9u()LX/Df3;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-virtual {v0, v7, v5, v6}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0, v4, v2, v3}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0}, LX/Df3;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 63
    .line 64
    .line 65
    :cond_1
    :goto_0
    monitor-exit p0

    .line 66
    return-void

    .line 67
    :catchall_0
    move-exception v0

    .line 68
    monitor-exit p0

    .line 69
    throw v0
.end method

.method public final onFeedLiked$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->FEED_LIKES:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    const-string v0, "feed_likes"

    .line 3
    .line 4
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->record(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onGoalCreationRequested$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->GOAL_CREATION_REQUESTED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    const-string v0, "created_goals"

    .line 3
    .line 4
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->record(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onIdeaCreated$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->IDEA_CREATED:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;

    .line 1
    .line 2
    const-string v0, "created_ideas"

    .line 3
    .line 4
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->record(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onReplyFailed$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 0

    .line 0
    invoke-static {}, LX/602;->A0V()Ljava/lang/Long;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    sput-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lastReplyFailureElapsedMs:Ljava/lang/Long;

    .line 5
    .line 6
    return-void
.end method

.method public final onSuccessfulAgentResponse$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 1

    .line 0
    const-string v0, "agent_messages"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->recordConversationMessage(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onUserMessageSent$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 1

    .line 0
    const-string/jumbo v0, "user_messages"

    .line 1
    .line 2
    .line 3
    invoke-direct {p0, v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->recordConversationMessage(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final recordLaunchAttempt$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview()V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    sget-object v0, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 4
    .line 5
    invoke-direct {v0}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    const-string/jumbo v0, "user_messages"

    .line 14
    .line 15
    .line 16
    const-wide/16 v1, 0x0

    .line 17
    .line 18
    invoke-virtual {v3, v0, v1, v2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 19
    .line 20
    .line 21
    const-string v0, "agent_messages"

    .line 22
    .line 23
    invoke-virtual {v3, v0, v1, v2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 24
    .line 25
    .line 26
    const-string v0, "feed_likes"

    .line 27
    .line 28
    invoke-virtual {v3, v0, v1, v2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 29
    .line 30
    .line 31
    const-string v0, "created_ideas"

    .line 32
    .line 33
    invoke-virtual {v3, v0, v1, v2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 34
    .line 35
    .line 36
    const-string v0, "created_goals"

    .line 37
    .line 38
    invoke-virtual {v3, v0, v1, v2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 39
    .line 40
    .line 41
    const-string v2, "last_review_attempt_ms"

    .line 42
    .line 43
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 44
    .line 45
    .line 46
    move-result-wide v0

    .line 47
    invoke-virtual {v3, v2, v0, v1}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v3}, LX/Df3;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    .line 52
    .line 53
    monitor-exit p0

    .line 54
    return-void

    .line 55
    :catchall_0
    move-exception v0

    .line 56
    monitor-exit p0

    .line 57
    throw v0
.end method

.method public final shouldRequestReview$fbandroid_express_aura_java_com_facebook_aura_appreview_appreview(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)Z
    .locals 18

    .line 0
    const-string/jumbo v11, "user="

    .line 1
    .line 2
    .line 3
    const-string p0, "goals="

    .line 4
    .line 5
    const-string v17, "ideas="

    .line 6
    .line 7
    const-string v16, "likes="

    .line 8
    .line 9
    const/4 v14, 0x0

    .line 10
    move-object/from16 v2, p1

    .line 11
    .line 12
    invoke-static {v2, v14}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 13
    .line 14
    .line 15
    sget-object v15, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->lock:Ljava/lang/Object;

    .line 16
    .line 17
    monitor-enter v15

    .line 18
    :try_start_0
    sget-object v8, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->INSTANCE:Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;

    .line 19
    .line 20
    invoke-direct {v8}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->reviewPrefs()LX/BVu;

    .line 21
    .line 22
    .line 23
    move-result-object v10

    .line 24
    invoke-direct {v8, v2}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->thresholdFor(Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;)J

    .line 25
    .line 26
    .line 27
    move-result-wide v5

    .line 28
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 29
    .line 30
    .line 31
    move-result v7

    .line 32
    const/4 v1, 0x1

    .line 33
    const-wide/16 v3, 0x0

    .line 34
    .line 35
    if-eq v7, v14, :cond_3

    .line 36
    .line 37
    if-eq v7, v1, :cond_2

    .line 38
    .line 39
    const/4 v0, 0x2

    .line 40
    if-eq v7, v0, :cond_1

    .line 41
    .line 42
    const/4 v0, 0x3

    .line 43
    if-ne v7, v0, :cond_0

    .line 44
    .line 45
    const-string v0, "created_goals"

    .line 46
    .line 47
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 48
    .line 49
    .line 50
    move-result-wide v12

    .line 51
    cmp-long v0, v12, v5

    .line 52
    .line 53
    if-ltz v0, :cond_4

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    throw v0

    .line 61
    :cond_1
    const-string v0, "created_ideas"

    .line 62
    .line 63
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 64
    .line 65
    .line 66
    move-result-wide v12

    .line 67
    cmp-long v0, v12, v5

    .line 68
    .line 69
    if-ltz v0, :cond_4

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_2
    const-string v0, "feed_likes"

    .line 73
    .line 74
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 75
    .line 76
    .line 77
    move-result-wide v12

    .line 78
    cmp-long v0, v12, v5

    .line 79
    .line 80
    if-ltz v0, :cond_4

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    const-string/jumbo v0, "user_messages"

    .line 84
    .line 85
    .line 86
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 87
    .line 88
    .line 89
    move-result-wide v12

    .line 90
    cmp-long v0, v12, v5

    .line 91
    .line 92
    if-ltz v0, :cond_4

    .line 93
    .line 94
    const-string v0, "agent_messages"

    .line 95
    .line 96
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 97
    .line 98
    .line 99
    move-result-wide v12

    .line 100
    cmp-long v0, v12, v5

    .line 101
    .line 102
    if-ltz v0, :cond_4

    .line 103
    .line 104
    :goto_0
    const/4 v9, 0x1

    .line 105
    goto :goto_1

    .line 106
    :cond_4
    const/4 v9, 0x0

    .line 107
    :goto_1
    if-eq v7, v14, :cond_7

    .line 108
    .line 109
    if-eq v7, v1, :cond_6

    .line 110
    .line 111
    const/4 v0, 0x2

    .line 112
    if-eq v7, v0, :cond_5

    .line 113
    .line 114
    const-string v0, "created_goals"

    .line 115
    .line 116
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 117
    .line 118
    .line 119
    move-result-wide v3

    .line 120
    const-string v1, "/"

    .line 121
    .line 122
    invoke-static/range {p0 .. p0}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 127
    .line 128
    .line 129
    invoke-static {v1, v0, v5, v6}, LX/EYu;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;J)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v3

    .line 133
    goto :goto_2

    .line 134
    :cond_5
    const-string v0, "created_ideas"

    .line 135
    .line 136
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 137
    .line 138
    .line 139
    move-result-wide v3

    .line 140
    const-string v1, "/"

    .line 141
    .line 142
    invoke-static/range {v17 .. v17}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 147
    .line 148
    .line 149
    invoke-static {v1, v0, v5, v6}, LX/EYu;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;J)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    goto :goto_2

    .line 154
    :cond_6
    const-string v0, "feed_likes"

    .line 155
    .line 156
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 157
    .line 158
    .line 159
    move-result-wide v3

    .line 160
    const-string v1, "/"

    .line 161
    .line 162
    invoke-static/range {v16 .. v16}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    .line 169
    invoke-static {v1, v0, v5, v6}, LX/EYu;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;J)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v3

    .line 173
    goto :goto_2

    .line 174
    :cond_7
    const-string/jumbo v0, "user_messages"

    .line 175
    .line 176
    .line 177
    invoke-interface {v10, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 178
    .line 179
    .line 180
    move-result-wide v0

    .line 181
    const-string v7, "agent_messages"

    .line 182
    .line 183
    invoke-interface {v10, v7, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 184
    .line 185
    .line 186
    move-result-wide v3

    .line 187
    invoke-static {v11, v0, v1}, LX/002;->A17(Ljava/lang/String;J)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    move-result-object v7

    .line 191
    const-string v1, "/"

    .line 192
    .line 193
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 194
    .line 195
    .line 196
    invoke-virtual {v7, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    const-string v0, ",agent="

    .line 200
    .line 201
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v7, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    invoke-static {v1, v7, v5, v6}, LX/EYu;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;J)Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v3

    .line 211
    :goto_2
    if-nez v9, :cond_8

    .line 212
    .line 213
    const-string/jumbo v4, "threshold"

    .line 214
    .line 215
    .line 216
    goto :goto_3

    .line 217
    :cond_8
    invoke-direct {v8}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->isCooldownActive()Z

    .line 218
    .line 219
    .line 220
    move-result v0

    .line 221
    if-eqz v0, :cond_9

    .line 222
    .line 223
    const-string v4, "cooldown"

    .line 224
    .line 225
    :goto_3
    const-string v0, "none"

    .line 226
    .line 227
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 228
    .line 229
    .line 230
    move-result v0

    .line 231
    const-string v6, "HatchInAppReview"

    .line 232
    .line 233
    const-string v7, "Eligibility trigger=%s progress=%s blocker=%s eligible=%s"

    .line 234
    .line 235
    invoke-virtual {v2}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger$TriggerSource;->getAnalyticsValue()Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v2

    .line 239
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 240
    .line 241
    .line 242
    move-result-object v5

    .line 243
    invoke-static/range {v2 .. v7}, LX/FnY;->A00(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    goto :goto_4

    .line 247
    :cond_9
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 248
    .line 249
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->isInAppReviewEnabled()Z

    .line 250
    .line 251
    .line 252
    move-result v0

    .line 253
    if-nez v0, :cond_a

    .line 254
    .line 255
    const-string v4, "mobile_config"

    .line 256
    .line 257
    goto :goto_3

    .line 258
    :cond_a
    invoke-direct {v8}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->hasUsedAppEnoughDays()Z

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    if-nez v0, :cond_b

    .line 263
    .line 264
    const/16 v0, 0x16

    .line 265
    .line 266
    invoke-static {v0}, LX/IEZ;->A00(I)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    goto :goto_3

    .line 271
    :cond_b
    invoke-direct {v8}, Lcom/facebook/aura/appreview/HatchInAppReviewTrigger;->hasRecentReplyFailure()Z

    .line 272
    .line 273
    .line 274
    move-result v0

    .line 275
    if-eqz v0, :cond_c

    .line 276
    .line 277
    const-string v4, "recent_reply_failure"

    .line 278
    .line 279
    goto :goto_3

    .line 280
    :cond_c
    const-string v4, "none"

    .line 281
    .line 282
    goto :goto_3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 283
    :goto_4
    monitor-exit v15

    .line 284
    return v0

    .line 285
    :catchall_0
    move-exception v0

    .line 286
    monitor-exit v15

    .line 287
    throw v0
.end method
