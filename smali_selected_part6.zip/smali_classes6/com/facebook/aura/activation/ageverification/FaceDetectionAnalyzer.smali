.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/F6u;


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final detector:LX/FEe;

.field public initError:Ljava/lang/RuntimeException;

.field public final mainExecutor:Ljava/util/concurrent/Executor;

.field public final onFrame:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onUnavailable:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Exception;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public volatile unavailable:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/JDM;LX/JDM;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Exception;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onFrame:LX/JDM;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onUnavailable:LX/JDM;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->mainExecutor:Ljava/util/concurrent/Executor;

    .line 18
    .line 19
    :try_start_0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngineKt;->FACE_DETECTOR_OPTIONS:LX/FMC;

    .line 20
    .line 21
    const-string v2, "You must provide a valid FaceDetectorOptions."

    .line 22
    .line 23
    invoke-static {v3, v2}, LX/FK0;->A03(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-static {}, LX/Era;->A00()LX/Era;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const-class v0, LX/Er9;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, LX/Era;->A02(Ljava/lang/Class;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    check-cast v1, LX/Er9;

    .line 37
    .line 38
    invoke-static {v3, v2}, LX/FK0;->A03(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, v1, LX/Er9;->A01:LX/FT5;

    .line 42
    .line 43
    invoke-virtual {v0, v3}, LX/FGX;->A00(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    check-cast v2, LX/FTD;

    .line 48
    .line 49
    iget-object v1, v1, LX/Er9;->A00:LX/Er5;

    .line 50
    .line 51
    new-instance v0, LX/FTC;

    .line 52
    .line 53
    invoke-direct {v0, v1, v2}, LX/FTC;-><init>(LX/Er5;LX/FTD;)V

    .line 54
    .line 55
    .line 56
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 57
    :catch_0
    move-exception v0

    .line 58
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->initError:Ljava/lang/RuntimeException;

    .line 59
    .line 60
    const/4 v0, 0x0

    .line 61
    :goto_0
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->detector:LX/FEe;

    .line 62
    .line 63
    invoke-static {v0}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 68
    .line 69
    return-void
.end method

.method public static final synthetic access$getOnFrame$p(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onFrame:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getOnUnavailable$p(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onUnavailable:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUnavailable$p(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$setUnavailable$p(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 1
    .line 2
    return-void
.end method


# virtual methods
.method public analyze(LX/FBz;)V
    .locals 17

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v15, p1

    .line 2
    .line 3
    invoke-static {v15, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    invoke-interface {v15}, LX/FBz;->AGP()Landroid/media/Image;

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    move-object/from16 v13, p0

    .line 11
    .line 12
    iget-object v2, v13, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->detector:LX/FEe;

    .line 13
    .line 14
    iget-boolean v0, v13, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    if-eqz v2, :cond_6

    .line 19
    .line 20
    if-eqz v4, :cond_6

    .line 21
    .line 22
    invoke-interface {v15}, LX/FBz;->AGR()LX/FC9;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-interface {v0}, LX/FC9;->AJx()I

    .line 27
    .line 28
    .line 29
    move-result v10

    .line 30
    const/16 v0, 0x5a

    .line 31
    .line 32
    if-eq v10, v0, :cond_4

    .line 33
    .line 34
    const/16 v0, 0x10e

    .line 35
    .line 36
    if-eq v10, v0, :cond_4

    .line 37
    .line 38
    invoke-interface {v15}, LX/FBz;->getWidth()I

    .line 39
    .line 40
    .line 41
    move-result v16

    .line 42
    invoke-interface {v15}, LX/FBz;->getHeight()I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    :goto_0
    invoke-interface {v15}, LX/FBz;->AEM()Landroid/graphics/Rect;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    invoke-interface {v15}, LX/FBz;->AEM()Landroid/graphics/Rect;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    int-to-float v1, v0

    .line 67
    invoke-static {v15}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzerKt;->averageLuma(LX/FBz;)F

    .line 68
    .line 69
    .line 70
    move-result v14

    .line 71
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 72
    .line 73
    .line 74
    move-result-wide v11

    .line 75
    invoke-static {v10}, LX/FU8;->A00(I)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v4}, Landroid/media/Image;->getFormat()I

    .line 79
    .line 80
    .line 81
    move-result v3

    .line 82
    const/4 v6, 0x1

    .line 83
    const/16 v0, 0x100

    .line 84
    .line 85
    if-eq v3, v0, :cond_0

    .line 86
    .line 87
    invoke-virtual {v4}, Landroid/media/Image;->getFormat()I

    .line 88
    .line 89
    .line 90
    move-result v7

    .line 91
    const/16 v3, 0x23

    .line 92
    .line 93
    if-eq v7, v3, :cond_0

    .line 94
    .line 95
    const/4 v6, 0x0

    .line 96
    :cond_0
    const-string v3, "Only JPEG and YUV_420_888 are supported now"

    .line 97
    .line 98
    invoke-static {v6, v3}, LX/FK0;->A07(ZLjava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v4}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    .line 102
    .line 103
    .line 104
    move-result-object v7

    .line 105
    invoke-virtual {v4}, Landroid/media/Image;->getFormat()I

    .line 106
    .line 107
    .line 108
    move-result v3

    .line 109
    if-ne v3, v0, :cond_1

    .line 110
    .line 111
    invoke-virtual {v4}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    aget-object v3, v3, v5

    .line 116
    .line 117
    invoke-virtual {v3}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 118
    .line 119
    .line 120
    move-result-object v3

    .line 121
    invoke-virtual {v3}, Ljava/nio/Buffer;->limit()I

    .line 122
    .line 123
    .line 124
    move-result v9

    .line 125
    invoke-virtual {v4}, Landroid/media/Image;->getFormat()I

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    const/4 v6, 0x1

    .line 130
    invoke-static {v3, v0}, LX/003;->A1I(II)Z

    .line 131
    .line 132
    .line 133
    move-result v3

    .line 134
    const-string v0, "Only JPEG is supported now"

    .line 135
    .line 136
    invoke-static {v3, v0}, LX/FK0;->A07(ZLjava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v4}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    if-eqz v3, :cond_5

    .line 144
    .line 145
    array-length v0, v3

    .line 146
    if-ne v0, v6, :cond_5

    .line 147
    .line 148
    aget-object v0, v3, v5

    .line 149
    .line 150
    invoke-virtual {v0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 151
    .line 152
    .line 153
    move-result-object v6

    .line 154
    invoke-virtual {v6}, Ljava/nio/Buffer;->rewind()Ljava/nio/Buffer;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v6}, Ljava/nio/Buffer;->remaining()I

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    new-array v0, v3, [B

    .line 162
    .line 163
    invoke-virtual {v6, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    .line 164
    .line 165
    .line 166
    invoke-static {v0, v5, v3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 167
    .line 168
    .line 169
    move-result-object v6

    .line 170
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getWidth()I

    .line 171
    .line 172
    .line 173
    move-result v3

    .line 174
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getHeight()I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    invoke-static {v6, v10, v3, v0}, LX/FT2;->A00(Landroid/graphics/Bitmap;III)Landroid/graphics/Bitmap;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    new-instance v0, LX/FU8;

    .line 183
    .line 184
    invoke-direct {v0, v5, v3}, LX/FU8;-><init>(ILandroid/graphics/Bitmap;)V

    .line 185
    .line 186
    .line 187
    :goto_1
    invoke-virtual {v4}, Landroid/media/Image;->getFormat()I

    .line 188
    .line 189
    .line 190
    move-result v5

    .line 191
    invoke-virtual {v4}, Landroid/media/Image;->getHeight()I

    .line 192
    .line 193
    .line 194
    move-result v7

    .line 195
    invoke-virtual {v4}, Landroid/media/Image;->getWidth()I

    .line 196
    .line 197
    .line 198
    move-result v8

    .line 199
    const/4 v6, 0x5

    .line 200
    invoke-static/range {v5 .. v12}, LX/FU8;->A01(IIIIIIJ)V

    .line 201
    .line 202
    .line 203
    check-cast v2, LX/FTG;

    .line 204
    .line 205
    invoke-virtual {v2, v0}, LX/FTG;->A00(LX/FU8;)LX/FWa;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    iget-object v0, v13, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->mainExecutor:Ljava/util/concurrent/Executor;

    .line 210
    .line 211
    new-instance v12, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;

    .line 212
    .line 213
    move/from16 p1, v1

    .line 214
    .line 215
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;FLX/FBz;IIF)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v2, v12, v0}, LX/FWb;->A09(LX/FWz;Ljava/util/concurrent/Executor;)V

    .line 219
    .line 220
    .line 221
    return-void

    .line 222
    :cond_1
    array-length v6, v7

    .line 223
    const/4 v3, 0x0

    .line 224
    :goto_2
    if-ge v3, v6, :cond_3

    .line 225
    .line 226
    aget-object v8, v7, v3

    .line 227
    .line 228
    invoke-virtual {v8}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 229
    .line 230
    .line 231
    move-result-object v0

    .line 232
    if-eqz v0, :cond_2

    .line 233
    .line 234
    invoke-virtual {v8}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    invoke-virtual {v0}, Ljava/nio/Buffer;->rewind()Ljava/nio/Buffer;

    .line 239
    .line 240
    .line 241
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 242
    .line 243
    goto :goto_2

    .line 244
    :cond_3
    invoke-virtual {v4}, Landroid/media/Image;->getWidth()I

    .line 245
    .line 246
    .line 247
    move-result v6

    .line 248
    invoke-virtual {v4}, Landroid/media/Image;->getHeight()I

    .line 249
    .line 250
    .line 251
    move-result v3

    .line 252
    new-instance v0, LX/FU8;

    .line 253
    .line 254
    invoke-direct {v0, v4, v6, v3, v10}, LX/FU8;-><init>(Landroid/media/Image;III)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v4}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    .line 258
    .line 259
    .line 260
    move-result-object v3

    .line 261
    aget-object v3, v3, v5

    .line 262
    .line 263
    invoke-virtual {v3}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 264
    .line 265
    .line 266
    move-result-object v3

    .line 267
    invoke-virtual {v3}, Ljava/nio/Buffer;->limit()I

    .line 268
    .line 269
    .line 270
    move-result v3

    .line 271
    mul-int/lit8 v3, v3, 0x3

    .line 272
    .line 273
    div-int/lit8 v9, v3, 0x2

    .line 274
    .line 275
    goto :goto_1

    .line 276
    :cond_4
    invoke-interface {v15}, LX/FBz;->getHeight()I

    .line 277
    .line 278
    .line 279
    move-result v16

    .line 280
    invoke-interface {v15}, LX/FBz;->getWidth()I

    .line 281
    .line 282
    .line 283
    move-result p0

    .line 284
    goto/16 :goto_0

    .line 285
    .line 286
    :cond_5
    const-string v0, "Unexpected image format, JPEG should have exactly 1 image plane"

    .line 287
    .line 288
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    throw v0

    .line 293
    :cond_6
    invoke-interface {v15}, LX/FBz;->close()V

    .line 294
    .line 295
    .line 296
    return-void
.end method

.method public final close()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->detector:LX/FEe;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {v0}, LX/FEe;->close()V

    .line 8
    .line 9
    .line 10
    :cond_0
    return-void
.end method

.method public synthetic getDefaultTargetResolution()Landroid/util/Size;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public final getInitError()Ljava/lang/RuntimeException;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->initError:Ljava/lang/RuntimeException;

    .line 1
    .line 2
    return-object p0
.end method

.method public synthetic getTargetCoordinateSystem()I
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public synthetic updateTransform(Landroid/graphics/Matrix;)V
    .locals 0

    .line 0
    return-void
.end method
