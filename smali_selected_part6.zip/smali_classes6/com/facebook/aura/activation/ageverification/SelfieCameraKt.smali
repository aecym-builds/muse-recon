.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieCameraKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final SELFIE_VIDEO_BITRATE:I = 0x40000

.field public static final SELFIE_VIDEO_MAX_BYTES:J = 0x1400000L

.field public static final TAG:Ljava/lang/String; = "SelfieCamera"
