.class public abstract Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final LUMA_SAMPLE_STEP:I = 0x8


# direct methods
.method public static final synthetic access$averageLuma(LX/FBz;)F
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzerKt;->averageLuma(LX/FBz;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$normalized(LX/FM7;IIF)Lcom/facebook/aura/activation/ageverification/NormalizedFace;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzerKt;->normalized(LX/FM7;IIF)Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final averageLuma(LX/FBz;)F
    .locals 16

    .line 0
    invoke-interface/range {p0 .. p0}, LX/FBz;->AIq()[LX/BQp;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    const/4 v13, 0x0

    .line 5
    aget-object v1, v0, v13

    .line 6
    .line 7
    move-object v0, v1

    .line 8
    check-cast v0, LX/BQq;

    .line 9
    .line 10
    iget-object v0, v0, LX/BQq;->A00:Landroid/media/Image$Plane;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    .line 13
    .line 14
    .line 15
    move-result-object v12

    .line 16
    invoke-static {v12}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    check-cast v1, LX/BQq;

    .line 20
    .line 21
    iget-object v0, v1, LX/BQq;->A00:Landroid/media/Image$Plane;

    .line 22
    .line 23
    invoke-virtual {v0}, Landroid/media/Image$Plane;->getRowStride()I

    .line 24
    .line 25
    .line 26
    move-result v15

    .line 27
    invoke-virtual {v0}, Landroid/media/Image$Plane;->getPixelStride()I

    .line 28
    .line 29
    .line 30
    move-result v14

    .line 31
    invoke-interface/range {p0 .. p0}, LX/FBz;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v13, v0}, LX/34j;->A0D(II)LX/34l;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    const/16 v11, 0x8

    .line 40
    .line 41
    invoke-static {v0, v11}, LX/34j;->A0C(LX/A7z;I)LX/A7z;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iget v10, v0, LX/A7z;->A00:I

    .line 46
    .line 47
    iget v9, v0, LX/A7z;->A01:I

    .line 48
    .line 49
    iget v8, v0, LX/A7z;->A02:I

    .line 50
    .line 51
    const-wide/16 v3, 0x0

    .line 52
    .line 53
    if-lez v8, :cond_1

    .line 54
    .line 55
    if-le v10, v9, :cond_2

    .line 56
    .line 57
    :cond_0
    const/4 v1, 0x0

    .line 58
    return v1

    .line 59
    :cond_1
    if-gez v8, :cond_0

    .line 60
    .line 61
    if-gt v9, v10, :cond_0

    .line 62
    .line 63
    :cond_2
    const/4 v7, 0x0

    .line 64
    :goto_0
    invoke-interface/range {p0 .. p0}, LX/FBz;->getWidth()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v13, v0}, LX/34j;->A0D(II)LX/34l;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-static {v0, v11}, LX/34j;->A0C(LX/A7z;I)LX/A7z;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    iget v6, v0, LX/A7z;->A00:I

    .line 77
    .line 78
    iget v5, v0, LX/A7z;->A01:I

    .line 79
    .line 80
    iget v2, v0, LX/A7z;->A02:I

    .line 81
    .line 82
    if-lez v2, :cond_4

    .line 83
    .line 84
    if-le v6, v5, :cond_5

    .line 85
    .line 86
    :cond_3
    if-eq v10, v9, :cond_6

    .line 87
    .line 88
    add-int/2addr v10, v8

    .line 89
    goto :goto_0

    .line 90
    :cond_4
    if-gez v2, :cond_3

    .line 91
    .line 92
    if-gt v5, v6, :cond_3

    .line 93
    .line 94
    :cond_5
    :goto_1
    mul-int v1, v10, v15

    .line 95
    .line 96
    mul-int v0, v6, v14

    .line 97
    .line 98
    add-int/2addr v1, v0

    .line 99
    invoke-static {v12, v1}, LX/EYv;->A0H(Ljava/nio/ByteBuffer;I)I

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    int-to-long v0, v0

    .line 104
    add-long/2addr v3, v0

    .line 105
    add-int/lit8 v7, v7, 0x1

    .line 106
    .line 107
    if-eq v6, v5, :cond_3

    .line 108
    .line 109
    add-int/2addr v6, v2

    .line 110
    goto :goto_1

    .line 111
    :cond_6
    if-eqz v7, :cond_0

    .line 112
    .line 113
    long-to-float v1, v3

    .line 114
    int-to-float v0, v7

    .line 115
    div-float/2addr v1, v0

    .line 116
    const/high16 v0, 0x437f0000    # 255.0f

    .line 117
    .line 118
    div-float/2addr v1, v0

    .line 119
    return v1
.end method

.method public static final normalized(LX/FM7;IIF)Lcom/facebook/aura/activation/ageverification/NormalizedFace;
    .locals 7

    .line 0
    int-to-float v3, p1

    .line 1
    sub-float/2addr v3, p3

    .line 2
    const/high16 v0, 0x40000000    # 2.0f

    .line 3
    .line 4
    div-float/2addr v3, v0

    .line 5
    int-to-float v2, p2

    .line 6
    sub-float/2addr v2, p3

    .line 7
    div-float/2addr v2, v0

    .line 8
    iget-object v1, p0, LX/FM7;->A03:Landroid/graphics/Rect;

    .line 9
    .line 10
    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterX()F

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    sub-float/2addr v0, v3

    .line 15
    div-float/2addr v0, p3

    .line 16
    const/high16 v3, 0x3f800000    # 1.0f

    .line 17
    .line 18
    sub-float/2addr v3, v0

    .line 19
    invoke-virtual {v1}, Landroid/graphics/Rect;->exactCenterY()F

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    sub-float/2addr v4, v2

    .line 24
    div-float/2addr v4, p3

    .line 25
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    int-to-float v5, v0

    .line 30
    div-float/2addr v5, p3

    .line 31
    iget v0, p0, LX/FM7;->A02:F

    .line 32
    .line 33
    neg-float v6, v0

    .line 34
    iget p0, p0, LX/FM7;->A01:F

    .line 35
    .line 36
    new-instance v2, Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 37
    .line 38
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/activation/ageverification/NormalizedFace;-><init>(FFFFF)V

    .line 39
    .line 40
    .line 41
    return-object v2
.end method
