.class public final Lcom/facebook/aura/activation/ageverification/IdCamera;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final analysis:LX/F6g;

.field public final analysisExecutor:Ljava/util/concurrent/Executor;

.field public final capture:LX/F6f;

.field public final context:Landroid/content/Context;

.field public final preview:LX/F5Q;

.field public provider:LX/F7T;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 8

    .line 0
    const/4 v6, 0x0

    .line 1
    invoke-static {p1, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->context:Landroid/content/Context;

    .line 8
    .line 9
    new-instance v0, LX/F5d;

    .line 10
    .line 11
    invoke-direct {v0}, LX/F5d;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, LX/F5d;->A00()LX/F5Q;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->preview:LX/F5Q;

    .line 19
    .line 20
    new-instance v7, LX/F5x;

    .line 21
    .line 22
    invoke-direct {v7}, LX/F5x;-><init>()V

    .line 23
    .line 24
    .line 25
    iget-object v2, v7, LX/F5x;->A00:LX/F6v;

    .line 26
    .line 27
    sget-object v0, LX/F6e;->A05:LX/F3d;

    .line 28
    .line 29
    invoke-static {v0, v2, v6}, LX/EYv;->A1A(LX/F3d;LX/F6v;I)V

    .line 30
    .line 31
    .line 32
    sget-object v5, LX/F6d;->A00:LX/F6d;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->MAX_CAPTURE_SIZE:Landroid/util/Size;

    .line 35
    .line 36
    const/4 v4, 0x3

    .line 37
    new-instance v1, LX/F4t;

    .line 38
    .line 39
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v0, v1, LX/F4t;->A01:Landroid/util/Size;

    .line 43
    .line 44
    iput v4, v1, LX/F4t;->A00:I

    .line 45
    .line 46
    new-instance v0, LX/F6H;

    .line 47
    .line 48
    invoke-direct {v0, v5, v1, v6}, LX/F6H;-><init>(LX/F6d;LX/F4t;I)V

    .line 49
    .line 50
    .line 51
    sget-object v3, LX/F4u;->A05:LX/F3d;

    .line 52
    .line 53
    invoke-virtual {v2, v3, v0}, LX/F6v;->ANq(LX/F3d;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v7}, LX/F5x;->A00()LX/F6f;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 61
    .line 62
    new-instance v2, LX/F5s;

    .line 63
    .line 64
    invoke-direct {v2}, LX/F5s;-><init>()V

    .line 65
    .line 66
    .line 67
    const/16 v1, 0x4b0

    .line 68
    .line 69
    const/16 v0, 0x384

    .line 70
    .line 71
    invoke-static {v1, v0}, LX/EYu;->A0I(II)Landroid/util/Size;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    new-instance v0, LX/F4t;

    .line 76
    .line 77
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 78
    .line 79
    .line 80
    iput-object v1, v0, LX/F4t;->A01:Landroid/util/Size;

    .line 81
    .line 82
    iput v4, v0, LX/F4t;->A00:I

    .line 83
    .line 84
    new-instance v1, LX/F6H;

    .line 85
    .line 86
    invoke-direct {v1, v5, v0, v6}, LX/F6H;-><init>(LX/F6d;LX/F4t;I)V

    .line 87
    .line 88
    .line 89
    iget-object v0, v2, LX/F5s;->A00:LX/F6v;

    .line 90
    .line 91
    invoke-virtual {v0, v3, v1}, LX/F6v;->ANq(LX/F3d;Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    invoke-static {v0}, LX/F6w;->A02(LX/F6K;)LX/F6w;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    new-instance v1, LX/F6h;

    .line 99
    .line 100
    invoke-direct {v1, v0}, LX/F6h;-><init>(LX/F6w;)V

    .line 101
    .line 102
    .line 103
    invoke-static {v1}, LX/F4v;->A00(LX/F4u;)V

    .line 104
    .line 105
    .line 106
    new-instance v0, LX/F6g;

    .line 107
    .line 108
    invoke-direct {v0, v1}, LX/F6g;-><init>(LX/F6h;)V

    .line 109
    .line 110
    .line 111
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 112
    .line 113
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 114
    .line 115
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->createSerialExecutor()Ljava/util/concurrent/Executor;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysisExecutor:Ljava/util/concurrent/Executor;

    .line 120
    .line 121
    return-void
.end method

.method public static final synthetic access$analyze(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/F6u;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdCamera;->analyze(LX/F6u;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getCapture$p(Lcom/facebook/aura/activation/ageverification/IdCamera;)LX/F6f;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 1
    .line 2
    return-object p0
.end method

.method private final analyze(LX/F6u;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/F6u;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-eq v0, v2, :cond_2

    .line 28
    .line 29
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    throw v0

    .line 34
    :cond_0
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;

    .line 35
    .line 36
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/2M4;)V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysisExecutor:Ljava/util/concurrent/Executor;

    .line 46
    .line 47
    invoke-virtual {v1, p1, v0}, LX/F6g;->A0Z(LX/F6u;Ljava/util/concurrent/Executor;)V

    .line 48
    .line 49
    .line 50
    const/4 v0, 0x0

    .line 51
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->L$0:Ljava/lang/Object;

    .line 52
    .line 53
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$analyze$1;->label:I

    .line 54
    .line 55
    invoke-static {v4}, LX/DSi;->A02(LX/2M4;)LX/2PB;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-ne v0, v3, :cond_3

    .line 60
    .line 61
    return-object v3

    .line 62
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_3
    new-instance v0, Lkotlin/KotlinNothingValueException;

    .line 66
    .line 67
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 68
    .line 69
    .line 70
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    :catchall_0
    move-exception v1

    .line 72
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 73
    .line 74
    invoke-virtual {v0}, LX/F6g;->A0Y()V

    .line 75
    .line 76
    .line 77
    throw v1
.end method


# virtual methods
.method public final bind(LX/FCr;LX/07p;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FCr;",
            "LX/07p;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v3, p3

    .line 5
    check-cast v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->label:I

    .line 23
    .line 24
    const/4 v8, 0x1

    .line 25
    if-eqz v0, :cond_4

    .line 26
    .line 27
    if-ne v0, v8, :cond_7

    .line 28
    .line 29
    iget-object p2, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->L$1:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p2, LX/07p;

    .line 32
    .line 33
    iget-object p1, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->L$0:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p1, LX/FCr;

    .line 36
    .line 37
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    check-cast v5, LX/F7T;

    .line 41
    .line 42
    iput-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->provider:LX/F7T;

    .line 43
    .line 44
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    const/4 v9, 0x0

    .line 49
    if-eqz v0, :cond_3

    .line 50
    .line 51
    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    .line 52
    .line 53
    .line 54
    move-result v7

    .line 55
    :goto_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 56
    .line 57
    invoke-virtual {v0, v7}, LX/F6f;->A0Y(I)V

    .line 58
    .line 59
    .line 60
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 61
    .line 62
    invoke-virtual {v2, v7}, LX/F5a;->A0W(I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_2

    .line 67
    .line 68
    invoke-virtual {v2}, LX/F5a;->A0C()LX/F61;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    if-eqz v0, :cond_2

    .line 73
    .line 74
    iget-object v1, v2, LX/F6g;->A04:LX/FBW;

    .line 75
    .line 76
    invoke-virtual {v2, v0, v9}, LX/F5a;->A0A(LX/F61;Z)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    iput v0, v1, LX/FBW;->A0F:I

    .line 81
    .line 82
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->preview:LX/F5Q;

    .line 83
    .line 84
    invoke-static {}, LX/Edd;->A00()V

    .line 85
    .line 86
    .line 87
    iget-object v0, p1, LX/FCr;->A09:LX/F5V;

    .line 88
    .line 89
    invoke-virtual {v1, v0}, LX/F5Q;->A0Y(LX/F5V;)V

    .line 90
    .line 91
    .line 92
    const/4 v10, 0x3

    .line 93
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->preview:LX/F5Q;

    .line 94
    .line 95
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 96
    .line 97
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 98
    .line 99
    filled-new-array {v2, v1, v0}, [LX/F5a;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    invoke-virtual {v5, v0}, LX/F7T;->A05([LX/F5a;)V

    .line 104
    .line 105
    .line 106
    sget-object v6, LX/F40;->A01:LX/F40;

    .line 107
    .line 108
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 113
    .line 114
    .line 115
    move-result-object v3

    .line 116
    const/4 v1, 0x4

    .line 117
    new-instance v0, Landroid/util/Rational;

    .line 118
    .line 119
    invoke-direct {v0, v10, v1}, Landroid/util/Rational;-><init>(II)V

    .line 120
    .line 121
    .line 122
    new-instance v2, LX/F6Q;

    .line 123
    .line 124
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 125
    .line 126
    .line 127
    iput v8, v2, LX/F6Q;->A02:I

    .line 128
    .line 129
    iput-object v0, v2, LX/F6Q;->A03:Landroid/util/Rational;

    .line 130
    .line 131
    iput v7, v2, LX/F6Q;->A01:I

    .line 132
    .line 133
    iput v9, v2, LX/F6Q;->A00:I

    .line 134
    .line 135
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->preview:LX/F5Q;

    .line 136
    .line 137
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 141
    .line 142
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 143
    .line 144
    .line 145
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 146
    .line 147
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    invoke-virtual {v4}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    xor-int/lit8 v1, v0, 0x1

    .line 155
    .line 156
    const-string v0, "UseCase must not be empty."

    .line 157
    .line 158
    invoke-static {v1, v0}, LX/0ov;->A04(ZLjava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    if-eqz v0, :cond_6

    .line 170
    .line 171
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    const-string v0, "getTargets"

    .line 175
    .line 176
    invoke-static {v0}, LX/001;->A0s(Ljava/lang/String;)Ljava/lang/NullPointerException;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    throw v0

    .line 181
    :cond_3
    const/4 v7, 0x0

    .line 182
    goto :goto_1

    .line 183
    :cond_4
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->provider:LX/F7T;

    .line 187
    .line 188
    if-nez v5, :cond_1

    .line 189
    .line 190
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->context:Landroid/content/Context;

    .line 191
    .line 192
    iput-object p1, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->L$0:Ljava/lang/Object;

    .line 193
    .line 194
    iput-object p2, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->L$1:Ljava/lang/Object;

    .line 195
    .line 196
    iput v8, v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;->label:I

    .line 197
    .line 198
    invoke-static {v0, v3}, Lcom/facebook/aura/activation/ageverification/CameraProviderKt;->awaitCameraProvider(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v5

    .line 202
    if-ne v5, v1, :cond_0

    .line 203
    .line 204
    return-object v1

    .line 205
    :cond_5
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;

    .line 206
    .line 207
    invoke-direct {v3, p0, p3}, Lcom/facebook/aura/activation/ageverification/IdCamera$bind$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/2M4;)V

    .line 208
    .line 209
    .line 210
    goto/16 :goto_0

    .line 211
    .line 212
    :cond_6
    new-instance v0, LX/F7a;

    .line 213
    .line 214
    invoke-direct {v0, v2, v4, v3}, LX/F7a;-><init>(LX/F6Q;Ljava/util/List;Ljava/util/List;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v5, v6, v0, p2}, LX/F7T;->A04(LX/F40;LX/F7a;LX/07p;)V

    .line 218
    .line 219
    .line 220
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 221
    .line 222
    return-object v0

    .line 223
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    throw v0
.end method

.method public final detectCardEdges(Lkotlin/jvm/functions/Function0;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;

    .line 3
    .line 4
    invoke-direct {v0, v1, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;LX/JDM;)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, v0, p3}, Lcom/facebook/aura/activation/ageverification/IdCamera;->analyze(LX/F6u;LX/2M4;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 12
    .line 13
    if-eq v1, v0, :cond_0

    .line 14
    .line 15
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    :cond_0
    return-object v1
.end method

.method public final detectPortrait(LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    const/4 v2, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-eq v0, v2, :cond_3

    .line 29
    .line 30
    if-ne v0, v5, :cond_1

    .line 31
    .line 32
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->L$1:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_0
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;

    .line 38
    .line 39
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/2M4;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :goto_1
    :try_start_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0

    .line 52
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    sget-object v1, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 56
    .line 57
    const-string v0, "mlkit_face_detection"

    .line 58
    .line 59
    invoke-virtual {v1, v0}, Lcom/facebook/aura/appmodules/AuraAppModules;->isInstalled(Ljava/lang/String;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_6

    .line 64
    .line 65
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 66
    .line 67
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->context:Landroid/content/Context;

    .line 68
    .line 69
    iput-object p1, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->L$0:Ljava/lang/Object;

    .line 70
    .line 71
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->label:I

    .line 72
    .line 73
    invoke-virtual {v1, v0, v4}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->awaitMode(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    if-ne v1, v3, :cond_4

    .line 78
    .line 79
    return-object v3

    .line 80
    :cond_3
    iget-object p1, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->L$0:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast p1, LX/JDM;

    .line 83
    .line 84
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    :cond_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieMode;->GUIDED:Lcom/facebook/aura/activation/ageverification/SelfieMode;

    .line 88
    .line 89
    if-ne v1, v0, :cond_6

    .line 90
    .line 91
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->context:Landroid/content/Context;

    .line 92
    .line 93
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;

    .line 94
    .line 95
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;-><init>(LX/JDM;)V

    .line 96
    .line 97
    .line 98
    new-instance v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 99
    .line 100
    invoke-direct {v2, v1, p1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;-><init>(Landroid/content/Context;LX/JDM;LX/JDM;)V

    .line 101
    .line 102
    .line 103
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->initError:Ljava/lang/RuntimeException;

    .line 104
    .line 105
    if-nez v0, :cond_6

    .line 106
    .line 107
    const/4 v0, 0x0

    .line 108
    :try_start_1
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->L$0:Ljava/lang/Object;

    .line 109
    .line 110
    iput-object v2, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->L$1:Ljava/lang/Object;

    .line 111
    .line 112
    iput v5, v4, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$1;->label:I

    .line 113
    .line 114
    invoke-direct {p0, v2, v4}, Lcom/facebook/aura/activation/ageverification/IdCamera;->analyze(LX/F6u;LX/2M4;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    if-ne v0, v3, :cond_5

    .line 119
    .line 120
    return-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 121
    :catchall_0
    move-exception v0

    .line 122
    invoke-virtual {v2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->close()V

    .line 123
    .line 124
    .line 125
    throw v0

    .line 126
    :cond_5
    :goto_2
    invoke-virtual {v2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->close()V

    .line 127
    .line 128
    .line 129
    :cond_6
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 130
    .line 131
    return-object v3
.end method

.method public final takeVisiblePhoto(LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p1}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->backgroundThreadExecutor$delegate:Lkotlin/Lazy;

    .line 7
    .line 8
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;

    .line 13
    .line 14
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;-><init>(LX/DT0;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v0, v1}, LX/F6f;->A0a(Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;Ljava/util/concurrent/Executor;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method

.method public final unbind()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->provider:LX/F7T;

    .line 1
    .line 2
    if-eqz v3, :cond_0

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->preview:LX/F5Q;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->capture:LX/F6f;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 9
    .line 10
    filled-new-array {v2, v1, v0}, [LX/F5a;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v3, v0}, LX/F7T;->A05([LX/F5a;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera;->analysis:LX/F6g;

    .line 18
    .line 19
    invoke-virtual {v0}, LX/F6g;->A0Y()V

    .line 20
    .line 21
    .line 22
    return-void
.end method
