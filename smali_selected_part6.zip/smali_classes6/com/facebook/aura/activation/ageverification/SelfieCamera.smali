.class public final Lcom/facebook/aura/activation/ageverification/SelfieCamera;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public activeRecording:LX/FDD;

.field public final analysis:LX/F6g;

.field public final analysisExecutor:Ljava/util/concurrent/Executor;

.field public final context:Landroid/content/Context;

.field public final executor:Ljava/util/concurrent/Executor;

.field public final preview:LX/F5Q;

.field public provider:LX/F7T;

.field public final videoCapture:LX/F4x;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/F4x<",
            "LX/FD8;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 10

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->context:Landroid/content/Context;

    .line 8
    .line 9
    invoke-virtual {p1}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->executor:Ljava/util/concurrent/Executor;

    .line 17
    .line 18
    new-instance v0, LX/F5d;

    .line 19
    .line 20
    invoke-direct {v0}, LX/F5d;-><init>()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, LX/F5d;->A00()LX/F5Q;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->preview:LX/F5Q;

    .line 28
    .line 29
    sget-object v7, LX/FD8;->A0q:LX/FF0;

    .line 30
    .line 31
    const/4 v5, -0x1

    .line 32
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v9

    .line 36
    sget-object v3, LX/FDc;->A00:Landroid/util/Range;

    .line 37
    .line 38
    sget-object v2, LX/FDc;->A01:Landroid/util/Range;

    .line 39
    .line 40
    const-string v1, ""

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_0

    .line 47
    .line 48
    new-instance v8, LX/FDP;

    .line 49
    .line 50
    invoke-direct {v8, v3, v2, v5}, LX/FDP;-><init>(Landroid/util/Range;Landroid/util/Range;I)V

    .line 51
    .line 52
    .line 53
    sget-object v2, LX/F2F;->A02:LX/F2G;

    .line 54
    .line 55
    sget-object v1, LX/F2F;->A01:Landroid/util/Range;

    .line 56
    .line 57
    sget-object v0, LX/F2F;->A00:Landroid/util/Range;

    .line 58
    .line 59
    invoke-static {v0, v1, v2, v9}, LX/F4a;->A00(Landroid/util/Range;Landroid/util/Range;LX/F2G;Ljava/lang/Integer;)LX/F4R;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    sget-object v3, LX/F29;->A05:LX/F29;

    .line 64
    .line 65
    const/4 v5, 0x3

    .line 66
    new-instance v2, LX/EdD;

    .line 67
    .line 68
    invoke-direct {v2, v3, v5}, LX/EdD;-><init>(LX/F29;I)V

    .line 69
    .line 70
    .line 71
    const-string v0, "quality cannot be null"

    .line 72
    .line 73
    invoke-static {v3, v0}, LX/0ov;->A01(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    sget-object v0, LX/F29;->A08:Ljava/util/Set;

    .line 77
    .line 78
    invoke-interface {v0, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    const-string v0, "Invalid quality: "

    .line 83
    .line 84
    invoke-static {v0, v3}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v1, v0}, LX/0ov;->A04(ZLjava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    new-instance v3, LX/F2G;

    .line 96
    .line 97
    invoke-direct {v3, v2, v0}, LX/F2G;-><init>(LX/F2D;Ljava/util/List;)V

    .line 98
    .line 99
    .line 100
    iget-object v2, v6, LX/F4R;->A02:Landroid/util/Range;

    .line 101
    .line 102
    iget-object v1, v6, LX/F4R;->A01:Landroid/util/Range;

    .line 103
    .line 104
    iget v0, v6, LX/F4R;->A00:I

    .line 105
    .line 106
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v1, v2, v3, v0}, LX/F4a;->A00(Landroid/util/Range;Landroid/util/Range;LX/F2G;Ljava/lang/Integer;)LX/F4R;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    iget-object v6, v0, LX/F4R;->A03:LX/F2G;

    .line 115
    .line 116
    iget-object v3, v0, LX/F4R;->A02:Landroid/util/Range;

    .line 117
    .line 118
    iget v0, v0, LX/F4R;->A00:I

    .line 119
    .line 120
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    const/high16 v0, 0x40000

    .line 125
    .line 126
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    new-instance v0, Landroid/util/Range;

    .line 131
    .line 132
    invoke-direct {v0, v1, v1}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    .line 133
    .line 134
    .line 135
    invoke-static {v0, v3, v6, v2}, LX/F4a;->A00(Landroid/util/Range;Landroid/util/Range;LX/F2G;Ljava/lang/Integer;)LX/F4R;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v8, v0, v9}, LX/F9N;->A00(LX/FDc;LX/F2F;Ljava/lang/Integer;)LX/F8j;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    new-instance v2, LX/FD8;

    .line 144
    .line 145
    invoke-direct {v2, v0, v7, v7}, LX/FD8;-><init>(LX/F4Z;LX/FF0;LX/FF0;)V

    .line 146
    .line 147
    .line 148
    sget-object v0, LX/F4x;->$redex_init_class:LX/F4x;

    .line 149
    .line 150
    invoke-static {}, LX/F6v;->A00()LX/F6v;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    sget-object v0, LX/F5f;->A03:LX/F3d;

    .line 155
    .line 156
    invoke-virtual {v1, v0, v2}, LX/F6v;->ANq(LX/F3d;Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    new-instance v0, LX/F5e;

    .line 160
    .line 161
    invoke-direct {v0, v1}, LX/F5e;-><init>(LX/F6v;)V

    .line 162
    .line 163
    .line 164
    iget-object v0, v0, LX/F5e;->A00:LX/F6v;

    .line 165
    .line 166
    invoke-static {v0}, LX/F6w;->A02(LX/F6K;)LX/F6w;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    new-instance v1, LX/F5f;

    .line 171
    .line 172
    invoke-direct {v1, v0}, LX/F5f;-><init>(LX/F6w;)V

    .line 173
    .line 174
    .line 175
    new-instance v0, LX/F4x;

    .line 176
    .line 177
    invoke-direct {v0, v1}, LX/F4x;-><init>(LX/F5f;)V

    .line 178
    .line 179
    .line 180
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 181
    .line 182
    new-instance v0, LX/F5s;

    .line 183
    .line 184
    invoke-direct {v0}, LX/F5s;-><init>()V

    .line 185
    .line 186
    .line 187
    iget-object v3, v0, LX/F5s;->A00:LX/F6v;

    .line 188
    .line 189
    sget-object v0, LX/F6h;->A01:LX/F3d;

    .line 190
    .line 191
    invoke-static {v0, v3, v4}, LX/EYv;->A1A(LX/F3d;LX/F6v;I)V

    .line 192
    .line 193
    .line 194
    sget-object v2, LX/F6d;->A00:LX/F6d;

    .line 195
    .line 196
    const/16 v1, 0x4b0

    .line 197
    .line 198
    const/16 v0, 0x384

    .line 199
    .line 200
    invoke-static {v1, v0}, LX/EYu;->A0I(II)Landroid/util/Size;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    new-instance v0, LX/F4t;

    .line 205
    .line 206
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 207
    .line 208
    .line 209
    iput-object v1, v0, LX/F4t;->A01:Landroid/util/Size;

    .line 210
    .line 211
    iput v5, v0, LX/F4t;->A00:I

    .line 212
    .line 213
    new-instance v1, LX/F6H;

    .line 214
    .line 215
    invoke-direct {v1, v2, v0, v4}, LX/F6H;-><init>(LX/F6d;LX/F4t;I)V

    .line 216
    .line 217
    .line 218
    sget-object v0, LX/F4u;->A05:LX/F3d;

    .line 219
    .line 220
    invoke-virtual {v3, v0, v1}, LX/F6v;->ANq(LX/F3d;Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    invoke-static {v3}, LX/F6w;->A02(LX/F6K;)LX/F6w;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    new-instance v1, LX/F6h;

    .line 228
    .line 229
    invoke-direct {v1, v0}, LX/F6h;-><init>(LX/F6w;)V

    .line 230
    .line 231
    .line 232
    invoke-static {v1}, LX/F4v;->A00(LX/F4u;)V

    .line 233
    .line 234
    .line 235
    new-instance v0, LX/F6g;

    .line 236
    .line 237
    invoke-direct {v0, v1}, LX/F6g;-><init>(LX/F6h;)V

    .line 238
    .line 239
    .line 240
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 241
    .line 242
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 243
    .line 244
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->createSerialExecutor()Ljava/util/concurrent/Executor;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysisExecutor:Ljava/util/concurrent/Executor;

    .line 249
    .line 250
    return-void

    .line 251
    :cond_0
    const-string v0, "Missing required properties:"

    .line 252
    .line 253
    invoke-static {v0, v1}, LX/007;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    throw v0
.end method

.method private final useCases(LX/F6Q;LX/F6g;)LX/F7a;
    .locals 4

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->preview:LX/F5Q;

    .line 9
    .line 10
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 14
    .line 15
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    invoke-virtual {v3, p2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    xor-int/lit8 v1, v0, 0x1

    .line 26
    .line 27
    const-string v0, "UseCase must not be empty."

    .line 28
    .line 29
    invoke-static {v1, v0}, LX/0ov;->A04(ZLjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    const-string v0, "getTargets"

    .line 46
    .line 47
    invoke-static {v0}, LX/001;->A0s(Ljava/lang/String;)Ljava/lang/NullPointerException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0

    .line 52
    :cond_0
    new-instance v0, LX/F7a;

    .line 53
    .line 54
    invoke-direct {v0, p1, v3, v2}, LX/F7a;-><init>(LX/F6Q;Ljava/util/List;Ljava/util/List;)V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method


# virtual methods
.method public final bind(LX/FCr;LX/07p;LX/F6u;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FCr;",
            "LX/07p;",
            "LX/F6u;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p4, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;

    .line 1
    .line 2
    if-eqz v0, :cond_6

    .line 3
    .line 4
    move-object v5, p4

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_6

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_5

    .line 26
    .line 27
    if-ne v0, v3, :cond_7

    .line 28
    .line 29
    iget-object p3, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$2:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p3, LX/F6u;

    .line 32
    .line 33
    iget-object p2, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$1:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p2, LX/07p;

    .line 36
    .line 37
    iget-object p1, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$0:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p1, LX/FCr;

    .line 40
    .line 41
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    check-cast v4, LX/F7T;

    .line 45
    .line 46
    iput-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->provider:LX/F7T;

    .line 47
    .line 48
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    const/4 v6, 0x0

    .line 53
    if-eqz v0, :cond_4

    .line 54
    .line 55
    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    :goto_1
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 60
    .line 61
    invoke-virtual {v1, v5}, LX/F5a;->A0W(I)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_2

    .line 66
    .line 67
    invoke-static {v1}, LX/F4x;->A06(LX/F4x;)V

    .line 68
    .line 69
    .line 70
    :cond_2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 71
    .line 72
    invoke-virtual {v2, v5}, LX/F5a;->A0W(I)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_3

    .line 77
    .line 78
    invoke-virtual {v2}, LX/F5a;->A0C()LX/F61;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    iget-object v1, v2, LX/F6g;->A04:LX/FBW;

    .line 85
    .line 86
    invoke-virtual {v2, v0, v6}, LX/F5a;->A0A(LX/F61;Z)I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    iput v0, v1, LX/FBW;->A0F:I

    .line 91
    .line 92
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->preview:LX/F5Q;

    .line 93
    .line 94
    invoke-static {}, LX/Edd;->A00()V

    .line 95
    .line 96
    .line 97
    iget-object v0, p1, LX/FCr;->A09:LX/F5V;

    .line 98
    .line 99
    invoke-virtual {v1, v0}, LX/F5Q;->A0Y(LX/F5V;)V

    .line 100
    .line 101
    .line 102
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 103
    .line 104
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysisExecutor:Ljava/util/concurrent/Executor;

    .line 105
    .line 106
    invoke-virtual {v1, p3, v0}, LX/F6g;->A0Z(LX/F6u;Ljava/util/concurrent/Executor;)V

    .line 107
    .line 108
    .line 109
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->preview:LX/F5Q;

    .line 110
    .line 111
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 112
    .line 113
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 114
    .line 115
    filled-new-array {v2, v1, v0}, [LX/F5a;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-virtual {v4, v0}, LX/F7T;->A05([LX/F5a;)V

    .line 120
    .line 121
    .line 122
    new-instance v0, Landroid/util/Rational;

    .line 123
    .line 124
    invoke-direct {v0, v3, v3}, Landroid/util/Rational;-><init>(II)V

    .line 125
    .line 126
    .line 127
    new-instance v2, LX/F6Q;

    .line 128
    .line 129
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 130
    .line 131
    .line 132
    iput v3, v2, LX/F6Q;->A02:I

    .line 133
    .line 134
    iput-object v0, v2, LX/F6Q;->A03:Landroid/util/Rational;

    .line 135
    .line 136
    iput v5, v2, LX/F6Q;->A01:I

    .line 137
    .line 138
    iput v6, v2, LX/F6Q;->A00:I

    .line 139
    .line 140
    goto :goto_2

    .line 141
    :cond_4
    const/4 v5, 0x0

    .line 142
    goto :goto_1

    .line 143
    :cond_5
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->provider:LX/F7T;

    .line 147
    .line 148
    if-nez v4, :cond_1

    .line 149
    .line 150
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->context:Landroid/content/Context;

    .line 151
    .line 152
    iput-object p1, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$0:Ljava/lang/Object;

    .line 153
    .line 154
    iput-object p2, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$1:Ljava/lang/Object;

    .line 155
    .line 156
    iput-object p3, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->L$2:Ljava/lang/Object;

    .line 157
    .line 158
    iput v3, v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;->label:I

    .line 159
    .line 160
    invoke-static {v0, v5}, Lcom/facebook/aura/activation/ageverification/CameraProviderKt;->awaitCameraProvider(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    if-ne v4, v1, :cond_0

    .line 165
    .line 166
    return-object v1

    .line 167
    :cond_6
    new-instance v5, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;

    .line 168
    .line 169
    invoke-direct {v5, p0, p4}, Lcom/facebook/aura/activation/ageverification/SelfieCamera$bind$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieCamera;LX/2M4;)V

    .line 170
    .line 171
    .line 172
    goto/16 :goto_0

    .line 173
    .line 174
    :goto_2
    :try_start_0
    sget-object v1, LX/F40;->A02:LX/F40;

    .line 175
    .line 176
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 177
    .line 178
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->useCases(LX/F6Q;LX/F6g;)LX/F7a;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    invoke-virtual {v4, v1, v0, p2}, LX/F7T;->A04(LX/F40;LX/F7a;LX/07p;)V

    .line 183
    .line 184
    .line 185
    goto :goto_3
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 186
    :catch_0
    move-exception v2

    .line 187
    const-string v1, "Face analysis is not supported with video on this camera"

    .line 188
    .line 189
    const-string v0, "SelfieCamera"

    .line 190
    .line 191
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 192
    .line 193
    .line 194
    const/4 v3, 0x0

    .line 195
    :goto_3
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    return-object v1

    .line 200
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    throw v0
.end method

.method public final record(Ljava/io/File;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v8, p2

    .line 1
    .line 2
    const-string v21, "Recording finished with error "

    .line 3
    .line 4
    move-object/from16 v3, p3

    .line 5
    .line 6
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;

    .line 7
    .line 8
    move-object/from16 v11, p0

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    move-object v12, v3

    .line 13
    check-cast v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;

    .line 14
    .line 15
    iget v2, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->label:I

    .line 16
    .line 17
    const/high16 v1, -0x80000000

    .line 18
    .line 19
    and-int v0, v2, v1

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    sub-int/2addr v2, v1

    .line 24
    iput v2, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v4, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v20, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v1, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->label:I

    .line 31
    .line 32
    const/16 v19, 0x2

    .line 33
    .line 34
    const/4 v13, 0x1

    .line 35
    const/4 v10, 0x0

    .line 36
    if-eqz v1, :cond_3

    .line 37
    .line 38
    if-eq v1, v13, :cond_2

    .line 39
    .line 40
    move/from16 v0, v19

    .line 41
    .line 42
    if-ne v1, v0, :cond_1

    .line 43
    .line 44
    iget-object v1, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$4:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v1, LX/FDD;

    .line 47
    .line 48
    goto/16 :goto_8

    .line 49
    .line 50
    :cond_0
    new-instance v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;

    .line 51
    .line 52
    invoke-direct {v12, v11, v3}, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieCamera;LX/2M4;)V

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    throw v2

    .line 61
    :cond_2
    iget-object v1, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$4:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v1, LX/FDD;

    .line 64
    .line 65
    iget-object v9, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$3:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v9, LX/EQR;

    .line 68
    .line 69
    iget-object v8, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 72
    .line 73
    :try_start_0
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    goto/16 :goto_7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 77
    .line 78
    :cond_3
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    new-instance v7, LX/DRG;

    .line 82
    .line 83
    invoke-direct {v7, v10}, LX/DRG;-><init>(LX/Cbu;)V

    .line 84
    .line 85
    .line 86
    new-instance v9, LX/DRG;

    .line 87
    .line 88
    invoke-direct {v9, v10}, LX/DRG;-><init>(LX/Cbu;)V

    .line 89
    .line 90
    .line 91
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 92
    .line 93
    invoke-virtual {v0}, LX/F4x;->A0Y()LX/F53;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    check-cast v6, LX/FD8;

    .line 98
    .line 99
    iget-object v2, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->context:Landroid/content/Context;

    .line 100
    .line 101
    const-string v0, "File can\'t be null."

    .line 102
    .line 103
    move-object/from16 v3, p1

    .line 104
    .line 105
    invoke-static {v3, v0}, LX/0ov;->A01(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    if-eqz p1, :cond_13

    .line 109
    .line 110
    const-string v1, ""

    .line 111
    .line 112
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_12

    .line 117
    .line 118
    new-instance v1, LX/FDX;

    .line 119
    .line 120
    invoke-direct {v1, v3}, LX/FDX;-><init>(Ljava/io/File;)V

    .line 121
    .line 122
    .line 123
    new-instance v18, LX/FDi;

    .line 124
    .line 125
    move-object/from16 v0, v18

    .line 126
    .line 127
    invoke-direct {v0, v1}, LX/FDi;-><init>(LX/FEo;)V

    .line 128
    .line 129
    .line 130
    invoke-static {v2}, LX/FFa;->A00(Landroid/content/Context;)Landroid/content/Context;

    .line 131
    .line 132
    .line 133
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->executor:Ljava/util/concurrent/Executor;

    .line 134
    .line 135
    move-object/from16 p1, v0

    .line 136
    .line 137
    new-instance v17, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;

    .line 138
    .line 139
    move-object/from16 v0, v17

    .line 140
    .line 141
    invoke-direct {v0, v7, v9}, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;-><init>(LX/BcL;LX/BcL;)V

    .line 142
    .line 143
    .line 144
    const-string v1, "Listener Executor can\'t be null."

    .line 145
    .line 146
    move-object/from16 v0, p1

    .line 147
    .line 148
    invoke-static {v0, v1}, LX/0ov;->A01(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    iget-object v14, v6, LX/FD8;->A0g:Ljava/lang/Object;

    .line 152
    .line 153
    monitor-enter v14

    .line 154
    :try_start_1
    iget-wide v3, v6, LX/FD8;->A05:J

    .line 155
    .line 156
    const-wide/16 v0, 0x1

    .line 157
    .line 158
    add-long/2addr v3, v0

    .line 159
    iput-wide v3, v6, LX/FD8;->A05:J

    .line 160
    .line 161
    iget-object v2, v6, LX/FD8;->A0M:LX/FDL;

    .line 162
    .line 163
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 164
    .line 165
    .line 166
    move-result v0

    .line 167
    const/4 v1, 0x0

    .line 168
    const/4 v5, 0x0

    .line 169
    packed-switch v0, :pswitch_data_0

    .line 170
    .line 171
    .line 172
    goto :goto_3

    .line 173
    :pswitch_0
    iget-object v1, v6, LX/FD8;->A0K:LX/FDA;

    .line 174
    .line 175
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    goto :goto_1

    .line 179
    :pswitch_1
    iget-object v1, v6, LX/FD8;->A0I:LX/FDA;

    .line 180
    .line 181
    :goto_1
    move-object v2, v10

    .line 182
    goto/16 :goto_4

    .line 183
    .line 184
    :pswitch_2
    sget-object v16, LX/FDL;->A03:LX/FDL;

    .line 185
    .line 186
    move-object/from16 v0, v16

    .line 187
    .line 188
    if-ne v2, v0, :cond_6

    .line 189
    .line 190
    iget-object v0, v6, LX/FD8;->A0I:LX/FDA;

    .line 191
    .line 192
    if-nez v0, :cond_4

    .line 193
    .line 194
    iget-object v0, v6, LX/FD8;->A0K:LX/FDA;

    .line 195
    .line 196
    const/4 v2, 0x1

    .line 197
    if-eqz v0, :cond_5

    .line 198
    .line 199
    :cond_4
    const/4 v2, 0x0

    .line 200
    :cond_5
    const-string v0, "Expected recorder to be idle but a recording is either pending or in progress."

    .line 201
    .line 202
    invoke-static {v2, v0}, LX/0ov;->A05(ZLjava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 203
    .line 204
    .line 205
    :cond_6
    :try_start_2
    new-instance v2, LX/FDM;

    .line 206
    .line 207
    move-object/from16 p0, v17

    .line 208
    .line 209
    move-wide/from16 p2, v3

    .line 210
    .line 211
    move-object/from16 v22, v2

    .line 212
    .line 213
    move-object/from16 v23, v18

    .line 214
    .line 215
    invoke-direct/range {v22 .. v27}, LX/FDM;-><init>(LX/FE0;LX/0oe;Ljava/util/concurrent/Executor;J)V

    .line 216
    .line 217
    .line 218
    iget-object v0, v2, LX/FDA;->A02:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 219
    .line 220
    invoke-virtual {v0, v13}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 221
    .line 222
    .line 223
    move-result v0

    .line 224
    if-nez v0, :cond_9

    .line 225
    .line 226
    iget-object v0, v2, LX/FDM;->A01:LX/FE0;

    .line 227
    .line 228
    move-object/from16 v22, v0

    .line 229
    .line 230
    iget-object v15, v2, LX/FDA;->A01:LX/FDt;

    .line 231
    .line 232
    const-string v0, "finalizeRecording"

    .line 233
    .line 234
    iget-object v15, v15, LX/FDt;->A00:LX/FDy;

    .line 235
    .line 236
    invoke-interface {v15, v0}, LX/FDy;->AXo(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    new-instance v0, LX/FDw;

    .line 240
    .line 241
    move-object/from16 v15, v22

    .line 242
    .line 243
    invoke-direct {v0, v15}, LX/FDw;-><init>(LX/FE0;)V

    .line 244
    .line 245
    .line 246
    iget-object v15, v2, LX/FDA;->A05:Ljava/util/concurrent/atomic/AtomicReference;

    .line 247
    .line 248
    invoke-virtual {v15, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 249
    .line 250
    .line 251
    iput-object v2, v6, LX/FD8;->A0K:LX/FDA;

    .line 252
    .line 253
    iget-object v2, v6, LX/FD8;->A0M:LX/FDL;

    .line 254
    .line 255
    move-object/from16 v0, v16

    .line 256
    .line 257
    if-ne v2, v0, :cond_7

    .line 258
    .line 259
    sget-object v0, LX/FDL;->A06:LX/FDL;

    .line 260
    .line 261
    invoke-static {v0, v6}, LX/FD8;->A0D(LX/FDL;LX/FD8;)V

    .line 262
    .line 263
    .line 264
    iget-object v2, v6, LX/FD8;->A0j:Ljava/util/concurrent/Executor;

    .line 265
    .line 266
    new-instance v0, LX/FDJ;

    .line 267
    .line 268
    invoke-direct {v0, v6}, LX/FDJ;-><init>(LX/FD8;)V

    .line 269
    .line 270
    .line 271
    :goto_2
    invoke-interface {v2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 272
    .line 273
    .line 274
    goto :goto_3

    .line 275
    :cond_7
    sget-object v0, LX/FDL;->A02:LX/FDL;

    .line 276
    .line 277
    if-ne v2, v0, :cond_8

    .line 278
    .line 279
    sget-object v0, LX/FDL;->A06:LX/FDL;

    .line 280
    .line 281
    invoke-static {v0, v6}, LX/FD8;->A0D(LX/FDL;LX/FD8;)V

    .line 282
    .line 283
    .line 284
    iget-object v2, v6, LX/FD8;->A0j:Ljava/util/concurrent/Executor;

    .line 285
    .line 286
    new-instance v0, LX/FDa;

    .line 287
    .line 288
    invoke-direct {v0, v6}, LX/FDa;-><init>(LX/FD8;)V

    .line 289
    .line 290
    .line 291
    goto :goto_2

    .line 292
    :cond_8
    sget-object v0, LX/FDL;->A06:LX/FDL;

    .line 293
    .line 294
    invoke-static {v0, v6}, LX/FD8;->A0D(LX/FDL;LX/FD8;)V

    .line 295
    .line 296
    .line 297
    :goto_3
    move-object v2, v10

    .line 298
    goto :goto_4

    .line 299
    :cond_9
    const-string v0, "Recording "

    .line 300
    .line 301
    invoke-static {v2, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 302
    .line 303
    .line 304
    move-result-object v2

    .line 305
    const-string v0, " has already been initialized"

    .line 306
    .line 307
    invoke-static {v0, v2}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    invoke-static {v0}, LX/EYt;->A0U(Ljava/lang/Object;)Ljava/lang/AssertionError;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    throw v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 316
    :catch_0
    move-exception v2

    .line 317
    const/4 v5, 0x5

    .line 318
    :goto_4
    :try_start_3
    monitor-exit v14

    .line 319
    if-nez v1, :cond_11

    .line 320
    .line 321
    if-eqz v5, :cond_a
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 322
    .line 323
    const-string v1, "Recorder"

    .line 324
    .line 325
    const-string v0, "Recording was started when the Recorder had encountered error "

    .line 326
    .line 327
    invoke-static {v0, v2}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    invoke-static {v1, v0}, LX/FCF;->A02(Ljava/lang/String;Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    new-instance v0, LX/FDM;

    .line 335
    .line 336
    move-object/from16 p0, v17

    .line 337
    .line 338
    move-wide/from16 p2, v3

    .line 339
    .line 340
    move-object/from16 v22, v0

    .line 341
    .line 342
    move-object/from16 v23, v18

    .line 343
    .line 344
    invoke-direct/range {v22 .. v27}, LX/FDM;-><init>(LX/FE0;LX/0oe;Ljava/util/concurrent/Executor;J)V

    .line 345
    .line 346
    .line 347
    invoke-static {v0, v2, v5}, LX/FD8;->A0B(LX/FDA;Ljava/lang/Throwable;I)V

    .line 348
    .line 349
    .line 350
    new-instance v1, LX/FDD;

    .line 351
    .line 352
    move-object/from16 p0, v6

    .line 353
    .line 354
    move-wide/from16 p1, v3

    .line 355
    .line 356
    move/from16 p3, v13

    .line 357
    .line 358
    move-object/from16 v22, v1

    .line 359
    .line 360
    invoke-direct/range {v22 .. v27}, LX/FDD;-><init>(LX/FE0;LX/FD8;JZ)V

    .line 361
    .line 362
    .line 363
    :goto_5
    iput-object v1, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 364
    .line 365
    goto :goto_6

    .line 366
    :cond_a
    const/16 p3, 0x0

    .line 367
    .line 368
    new-instance v1, LX/FDD;

    .line 369
    .line 370
    move-object/from16 p0, v6

    .line 371
    .line 372
    move-wide/from16 p1, v3

    .line 373
    .line 374
    move-object/from16 v22, v1

    .line 375
    .line 376
    move-object/from16 v23, v18

    .line 377
    .line 378
    invoke-direct/range {v22 .. v27}, LX/FDD;-><init>(LX/FE0;LX/FD8;JZ)V

    .line 379
    .line 380
    .line 381
    goto :goto_5

    .line 382
    :goto_6
    :try_start_4
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$0:Ljava/lang/Object;

    .line 383
    .line 384
    iput-object v8, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$1:Ljava/lang/Object;

    .line 385
    .line 386
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$2:Ljava/lang/Object;

    .line 387
    .line 388
    iput-object v9, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$3:Ljava/lang/Object;

    .line 389
    .line 390
    iput-object v1, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$4:Ljava/lang/Object;

    .line 391
    .line 392
    iput v13, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->label:I

    .line 393
    .line 394
    invoke-virtual {v7, v12}, LX/DRW;->A0E(LX/2M4;)Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v2

    .line 398
    move-object/from16 v0, v20

    .line 399
    .line 400
    if-ne v2, v0, :cond_b

    .line 401
    .line 402
    return-object v20

    .line 403
    :cond_b
    :goto_7
    invoke-interface {v9}, LX/Cbu;->AOO()Z

    .line 404
    .line 405
    .line 406
    move-result v0

    .line 407
    if-nez v0, :cond_c

    .line 408
    .line 409
    invoke-interface {v8}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    :cond_c
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$0:Ljava/lang/Object;

    .line 413
    .line 414
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$1:Ljava/lang/Object;

    .line 415
    .line 416
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$2:Ljava/lang/Object;

    .line 417
    .line 418
    iput-object v10, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$3:Ljava/lang/Object;

    .line 419
    .line 420
    iput-object v1, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->L$4:Ljava/lang/Object;

    .line 421
    .line 422
    move/from16 v0, v19

    .line 423
    .line 424
    iput v0, v12, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$1;->label:I

    .line 425
    .line 426
    invoke-static {v9, v12}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object v4

    .line 430
    move-object/from16 v0, v20

    .line 431
    .line 432
    if-ne v4, v0, :cond_d

    .line 433
    .line 434
    return-object v20
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 435
    :goto_8
    :try_start_5
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    :cond_d
    check-cast v4, LX/FDf;

    .line 439
    .line 440
    iget v2, v4, LX/FDf;->A00:I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 441
    .line 442
    invoke-static {v2}, LX/003;->A1B(I)Z

    .line 443
    .line 444
    .line 445
    move-result v0

    .line 446
    if-nez v0, :cond_f

    .line 447
    .line 448
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 449
    .line 450
    if-ne v0, v1, :cond_e

    .line 451
    .line 452
    iput-object v10, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 453
    .line 454
    :cond_e
    invoke-virtual {v1}, LX/FDD;->close()V

    .line 455
    .line 456
    .line 457
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 458
    .line 459
    return-object v0

    .line 460
    :cond_f
    :try_start_6
    move-object/from16 v0, v21

    .line 461
    .line 462
    invoke-static {v0, v2}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object v3

    .line 466
    iget-object v2, v4, LX/FDf;->A01:Ljava/lang/Throwable;

    .line 467
    .line 468
    new-instance v0, Ljava/io/IOException;

    .line 469
    .line 470
    invoke-direct {v0, v3, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 471
    .line 472
    .line 473
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 474
    :catchall_0
    move-exception v2

    .line 475
    goto :goto_9

    .line 476
    :catchall_1
    move-exception v2

    .line 477
    :goto_9
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 478
    .line 479
    if-ne v0, v1, :cond_10

    .line 480
    .line 481
    iput-object v10, v11, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 482
    .line 483
    :cond_10
    invoke-virtual {v1}, LX/FDD;->close()V

    .line 484
    .line 485
    .line 486
    throw v2

    .line 487
    :cond_11
    const-string v0, "A recording is already in progress. Previous recordings must be stopped before a new recording can be started."

    .line 488
    .line 489
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 490
    .line 491
    .line 492
    move-result-object v2

    .line 493
    throw v2

    .line 494
    :catchall_2
    move-exception v2

    .line 495
    :try_start_7
    monitor-exit v14
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 496
    throw v2

    .line 497
    :cond_12
    const-string v0, "Missing required properties:"

    .line 498
    .line 499
    invoke-static {v0, v1}, LX/007;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 500
    .line 501
    .line 502
    move-result-object v2

    .line 503
    throw v2

    .line 504
    :cond_13
    const-string v0, "Null file"

    .line 505
    .line 506
    invoke-static {v0}, LX/001;->A0s(Ljava/lang/String;)Ljava/lang/NullPointerException;

    .line 507
    .line 508
    .line 509
    move-result-object v2

    .line 510
    throw v2

    .line 511
    nop

    .line 512
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_2
        :pswitch_2
        :pswitch_2
    .end packed-switch
.end method

.method public final stop()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->activeRecording:LX/FDD;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, LX/FDD;->close()V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method public final unbind()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->provider:LX/F7T;

    .line 1
    .line 2
    if-eqz v3, :cond_0

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->preview:LX/F5Q;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->videoCapture:LX/F4x;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 9
    .line 10
    filled-new-array {v2, v1, v0}, [LX/F5a;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v3, v0}, LX/F7T;->A05([LX/F5a;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera;->analysis:LX/F6g;

    .line 18
    .line 19
    invoke-virtual {v0}, LX/F6g;->A0Y()V

    .line 20
    .line 21
    .line 22
    return-void
.end method
