.class public abstract Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssetsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ASSETS_DIR:Ljava/lang/String; = "assets/"

.field public static final ENGINE_MODEL_ASSET:Ljava/lang/String; = "models_bundled/fssd_25_8bit_v2.tflite"

.field public static final EXTRACTED_DIR:Ljava/lang/String; = "engine-assets"

.field public static final MODELS_DIR:Ljava/lang/String; = "models_bundled"

.field public static final TAG:Ljava/lang/String; = "FaceDetectionModelAssets"

.field public static final UNPACKER_NAME:Ljava/lang/String; = "MlKitFaceDetectionModels"
