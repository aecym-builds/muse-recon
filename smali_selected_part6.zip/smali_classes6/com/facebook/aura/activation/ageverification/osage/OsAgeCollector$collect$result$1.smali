.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "LX/FjS;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.osage.OsAgeCollector$collect$result$1"
    f = "OsAgeCollector.kt"
    l = {
        0x33,
        0x33
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $service:LX/EQR;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EQR<",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(LX/EQR;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/EQR<",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->$service:LX/EQR;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->$service:LX/EQR;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;-><init>(LX/EQR;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/FjS;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->$service:LX/EQR;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;

    .line 3
    .line 4
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;-><init>(LX/EQR;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-eq v0, v1, :cond_2

    .line 9
    .line 10
    if-ne v0, v2, :cond_4

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-object p1

    .line 16
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->$service:LX/EQR;

    .line 20
    .line 21
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->label:I

    .line 22
    .line 23
    invoke-static {v0, p0}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    if-ne p1, v3, :cond_3

    .line 28
    .line 29
    return-object v3

    .line 30
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_3
    check-cast p1, Lcom/facebook/androidage/AndroidAgeRangeService;

    .line 34
    .line 35
    iput v2, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;->label:I

    .line 36
    .line 37
    invoke-virtual {p1, p0}, Lcom/facebook/androidage/AndroidAgeRangeService;->A01(LX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    if-ne p1, v3, :cond_0

    .line 42
    .line 43
    return-object v3

    .line 44
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0
.end method
