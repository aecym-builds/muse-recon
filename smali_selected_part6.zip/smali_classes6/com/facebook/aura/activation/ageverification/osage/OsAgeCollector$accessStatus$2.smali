.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/FjM;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.osage.OsAgeCollector$accessStatus$2"
    f = "OsAgeCollector.kt"
    l = {
        0x4a,
        0x4b
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $host:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $service:LX/EQR;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EQR<",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            ">;"
        }
    .end annotation
.end field

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/EQR<",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroid/app/Activity;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$service:LX/EQR;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$host:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$service:LX/EQR;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$host:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;-><init>(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/FjM;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->label:I

    .line 3
    .line 4
    const/4 v4, 0x2

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-eq v0, v1, :cond_2

    .line 9
    .line 10
    if-ne v0, v4, :cond_4

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-object p1

    .line 16
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$service:LX/EQR;

    .line 20
    .line 21
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->label:I

    .line 22
    .line 23
    invoke-static {v0, p0}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    if-ne p1, v5, :cond_3

    .line 28
    .line 29
    return-object v5

    .line 30
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_3
    check-cast p1, Lcom/facebook/androidage/AndroidAgeRangeService;

    .line 34
    .line 35
    sget-object v3, Lcom/facebook/aura/executors/AuraDispatchers;->main:LX/DSR;

    .line 36
    .line 37
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->$host:Lkotlin/jvm/functions/Function0;

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;

    .line 41
    .line 42
    invoke-direct {v0, v2, p1, v1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/androidage/AndroidAgeRangeService;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->L$0:Ljava/lang/Object;

    .line 46
    .line 47
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;->label:I

    .line 48
    .line 49
    invoke-static {p0, v3, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-ne p1, v5, :cond_0

    .line 54
    .line 55
    return-object v5

    .line 56
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    throw v0
.end method
