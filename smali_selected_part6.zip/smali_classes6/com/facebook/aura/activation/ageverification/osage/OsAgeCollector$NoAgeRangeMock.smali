.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getMockAgeLowerBound()J
    .locals 1

    .line 0
    const-wide/16 v0, -0x1

    .line 1
    .line 2
    return-wide v0
.end method

.method public getMockAgeRangeType()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method

.method public getMockAgeUpperBound()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public isMockEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
