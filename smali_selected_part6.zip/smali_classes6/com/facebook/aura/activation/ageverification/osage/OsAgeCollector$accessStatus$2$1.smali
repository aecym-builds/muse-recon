.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/FjM;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.osage.OsAgeCollector$accessStatus$2$1"
    f = "OsAgeCollector.kt"
    l = {
        0x4d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $host:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $ready:Lcom/facebook/androidage/AndroidAgeRangeService;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/androidage/AndroidAgeRangeService;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroid/app/Activity;",
            ">;",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$host:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$ready:Lcom/facebook/androidage/AndroidAgeRangeService;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$host:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$ready:Lcom/facebook/androidage/AndroidAgeRangeService;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/androidage/AndroidAgeRangeService;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/FjM;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    if-ne v0, v3, :cond_3

    .line 9
    .line 10
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    instance-of v0, p1, LX/FjR;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    check-cast p1, LX/FjR;

    .line 18
    .line 19
    if-eqz p1, :cond_1

    .line 20
    .line 21
    iget-object v2, p1, LX/FjR;->A00:LX/FjM;

    .line 22
    .line 23
    :cond_1
    return-object v2

    .line 24
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$host:Lkotlin/jvm/functions/Function0;

    .line 28
    .line 29
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Landroid/app/Activity;

    .line 34
    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 38
    .line 39
    invoke-static {v0, v1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->access$canHostPrompt(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;Landroid/app/Activity;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_1

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->$ready:Lcom/facebook/androidage/AndroidAgeRangeService;

    .line 46
    .line 47
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->L$0:Ljava/lang/Object;

    .line 48
    .line 49
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2$1;->label:I

    .line 50
    .line 51
    invoke-virtual {v0, v1, p0}, Lcom/facebook/androidage/AndroidAgeRangeService;->A00(Landroid/app/Activity;LX/2M4;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    if-ne p1, v4, :cond_0

    .line 56
    .line 57
    return-object v4

    .line 58
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    throw v0
.end method
