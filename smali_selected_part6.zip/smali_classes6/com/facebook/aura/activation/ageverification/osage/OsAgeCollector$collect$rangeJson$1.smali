.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/lang/String;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.osage.OsAgeCollector$collect$rangeJson$1"
    f = "OsAgeCollector.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $response:LX/Fjc;

.field public label:I


# direct methods
.method public constructor <init>(LX/Fjc;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Fjc;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->$response:LX/Fjc;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->$response:LX/Fjc;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;-><init>(LX/Fjc;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->$response:LX/Fjc;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;-><init>(LX/Fjc;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;->$response:LX/Fjc;

    .line 10
    .line 11
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->access$toRangeJson(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/Fjc;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0

    .line 16
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    throw v0
.end method
