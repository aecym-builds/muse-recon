.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;
.super LX/Btl;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "LX/Btl;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.osage.OsAgeCollector"
    f = "OsAgeCollector.kt"
    l = {
        0x3f
    }
    m = "awaitWithin"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->this$0:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->this$0:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    const-wide/16 v2, 0x0

    .line 13
    .line 14
    move-object v4, v1

    .line 15
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->access$awaitWithin(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/1EL;JLX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
