.class public final Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;


# static fields
.field public static final ACCESS_TIMEOUT_MS:J = 0xea60L

.field public static final FETCH_TIMEOUT_MS:J = 0xbb8L

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$accessStatus(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->accessStatus(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$awaitWithin(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/1EL;JLX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->awaitWithin(LX/1EL;JLX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$canHostPrompt(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;Landroid/app/Activity;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->canHostPrompt(Landroid/app/Activity;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$toRangeJson(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/Fjc;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->toRangeJson(LX/Fjc;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final accessStatus(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/EQR<",
            "Lcom/facebook/androidage/AndroidAgeRangeService;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroid/app/Activity;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/FjM;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    new-instance p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;

    .line 2
    .line 3
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$accessStatus$2;-><init>(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 4
    .line 5
    .line 6
    const-wide/32 v0, 0xea60

    .line 7
    .line 8
    .line 9
    invoke-static {p3, p0, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method private final awaitWithin(LX/1EL;JLX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LX/1EL;",
            "J",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p5

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object p0, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v4, :cond_1

    .line 29
    .line 30
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->L$2:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, LX/Cbu;

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_0
    new-instance v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;

    .line 36
    .line 37
    invoke-direct {v5, p0, p5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;-><init>(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/2M4;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :goto_1
    :try_start_0
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    goto :goto_3

    .line 47
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0

    .line 52
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    new-instance v1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$work$1;

    .line 60
    .line 61
    invoke-direct {v1, p4, v3}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$work$1;-><init>(LX/JDM;LX/2M4;)V

    .line 62
    .line 63
    .line 64
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 65
    .line 66
    invoke-static {v0, v2, v1, p1}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    :try_start_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$2;

    .line 71
    .line 72
    invoke-direct {v0, v1, v3}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$2;-><init>(LX/EQR;LX/2M4;)V

    .line 73
    .line 74
    .line 75
    iput-object v3, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->L$0:Ljava/lang/Object;

    .line 76
    .line 77
    iput-object v3, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->L$1:Ljava/lang/Object;

    .line 78
    .line 79
    iput-object v1, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->L$2:Ljava/lang/Object;

    .line 80
    .line 81
    iput-wide p2, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->J$0:J

    .line 82
    .line 83
    iput v4, v5, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$awaitWithin$1;->label:I

    .line 84
    .line 85
    invoke-static {v5, v0, p2, p3}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    if-ne v0, p0, :cond_3

    .line 90
    .line 91
    return-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 92
    :cond_3
    :goto_2
    invoke-interface {v1, v3}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 93
    .line 94
    .line 95
    return-object v0

    .line 96
    :catchall_1
    move-exception v0

    .line 97
    :goto_3
    invoke-interface {v1, v3}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 98
    .line 99
    .line 100
    throw v0
.end method

.method private final canHostPrompt(Landroid/app/Activity;)Z
    .locals 0

    .line 0
    invoke-virtual {p1}, Landroid/app/Activity;->isFinishing()Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    if-nez p0, :cond_0

    .line 5
    .line 6
    instance-of p0, p1, LX/07p;

    .line 7
    .line 8
    if-eqz p0, :cond_0

    .line 9
    .line 10
    check-cast p1, LX/07p;

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    invoke-interface {p1}, LX/07p;->getLifecycle()LX/AaB;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    if-eqz p0, :cond_0

    .line 19
    .line 20
    check-cast p0, LX/E0b;

    .line 21
    .line 22
    iget-object p1, p0, LX/E0b;->A01:LX/15h;

    .line 23
    .line 24
    sget-object p0, LX/15h;->A05:LX/15h;

    .line 25
    .line 26
    invoke-virtual {p1, p0}, LX/15h;->A00(LX/15h;)Z

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    const/4 p0, 0x1

    .line 31
    if-ne p1, p0, :cond_0

    .line 32
    .line 33
    return p0

    .line 34
    :cond_0
    const/4 p0, 0x0

    .line 35
    return p0
.end method

.method private final toRangeJson(LX/Fjc;)Ljava/lang/String;
    .locals 8

    .line 0
    iget-object v5, p1, LX/Fjc;->A00:Ljava/lang/Integer;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    if-nez v5, :cond_0

    .line 4
    .line 5
    iget-object v0, p1, LX/Fjc;->A02:Ljava/lang/Integer;

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_0
    iget-object v3, p1, LX/Fjc;->A06:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, LX/Fjc;->A01:Ljava/lang/Integer;

    .line 13
    .line 14
    invoke-static {v0}, LX/Fjh;->A00(Ljava/lang/Integer;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {v0}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    iget-object v6, p1, LX/Fjc;->A02:Ljava/lang/Integer;

    .line 23
    .line 24
    iget-object v7, p1, LX/Fjc;->A04:Ljava/lang/Long;

    .line 25
    .line 26
    iget-object v0, p1, LX/Fjc;->A03:Ljava/lang/Integer;

    .line 27
    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    const-string p0, "approved"

    .line 38
    .line 39
    :cond_1
    :goto_0
    new-instance v2, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;

    .line 40
    .line 41
    invoke-direct/range {v2 .. v8}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sget-object v1, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;

    .line 47
    .line 48
    invoke-virtual {v1, v2, v0}, LX/Dcb;->A02(Ljava/lang/Object;LX/DZE;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0

    .line 53
    :pswitch_0
    const-string/jumbo p0, "unspecified"

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :pswitch_1
    const-string p0, "declined"

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :pswitch_2
    const-string p0, "pending"

    .line 61
    .line 62
    goto :goto_0

    .line 63
    nop

    .line 64
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public collect(LX/1EL;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroid/app/Activity;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v3, p3

    .line 1
    move-object v11, p1

    .line 2
    instance-of v0, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;

    .line 3
    .line 4
    move-object v10, p0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    move-object p3, v3

    .line 8
    check-cast p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;

    .line 9
    .line 10
    iget v2, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 11
    .line 12
    const/high16 v1, -0x80000000

    .line 13
    .line 14
    and-int v0, v2, v1

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    sub-int/2addr v2, v1

    .line 19
    iput v2, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 20
    .line 21
    :goto_0
    iget-object v1, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->result:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 24
    .line 25
    iget v0, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 26
    .line 27
    const/4 v6, 0x3

    .line 28
    const/4 v8, 0x2

    .line 29
    const/4 v3, 0x1

    .line 30
    const/4 v5, 0x0

    .line 31
    if-eqz v0, :cond_4

    .line 32
    .line 33
    if-eq v0, v3, :cond_3

    .line 34
    .line 35
    if-eq v0, v8, :cond_2

    .line 36
    .line 37
    if-ne v0, v6, :cond_1

    .line 38
    .line 39
    iget-object v3, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$4:Ljava/lang/Object;

    .line 40
    .line 41
    iget-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v4, LX/Cbu;

    .line 44
    .line 45
    goto/16 :goto_3

    .line 46
    .line 47
    :cond_0
    new-instance p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;

    .line 48
    .line 49
    invoke-direct {p3, p0, v3}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;-><init>(Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;LX/2M4;)V

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    throw v0

    .line 58
    :cond_2
    iget-object v3, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$4:Ljava/lang/Object;

    .line 59
    .line 60
    iget-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v4, LX/Cbu;

    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_3
    iget-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v4, LX/EQR;

    .line 68
    .line 69
    iget-object v11, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$0:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v11, LX/1EL;

    .line 72
    .line 73
    :try_start_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 77
    :cond_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    check-cast v0, Landroid/content/Context;

    .line 85
    .line 86
    if-eqz v0, :cond_b

    .line 87
    .line 88
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-eqz v0, :cond_b

    .line 93
    .line 94
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    new-instance v1, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$service$1;

    .line 99
    .line 100
    invoke-direct {v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$service$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 101
    .line 102
    .line 103
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 104
    .line 105
    invoke-static {v0, v2, v1, p1}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    :try_start_1
    iput-object p1, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$0:Ljava/lang/Object;

    .line 110
    .line 111
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$1:Ljava/lang/Object;

    .line 112
    .line 113
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$2:Ljava/lang/Object;

    .line 114
    .line 115
    iput-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 116
    .line 117
    iput v3, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 118
    .line 119
    invoke-direct {p0, v4, p2, p3}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->accessStatus(LX/EQR;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    if-ne v1, v7, :cond_5

    .line 124
    .line 125
    return-object v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 126
    :cond_5
    :goto_1
    :try_start_2
    move-object v3, v1

    .line 127
    check-cast v3, LX/FjM;

    .line 128
    .line 129
    if-eqz v3, :cond_6

    .line 130
    .line 131
    sget-object v0, LX/FjM;->A03:LX/FjM;

    .line 132
    .line 133
    if-eq v3, v0, :cond_6

    .line 134
    .line 135
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;

    .line 136
    .line 137
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 138
    .line 139
    .line 140
    invoke-interface {v4, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 141
    .line 142
    .line 143
    return-object v0

    .line 144
    :cond_6
    :try_start_3
    new-instance p2, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;

    .line 145
    .line 146
    invoke-direct {p2, v4, v5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$result$1;-><init>(LX/EQR;LX/2M4;)V

    .line 147
    .line 148
    .line 149
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$0:Ljava/lang/Object;

    .line 150
    .line 151
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$1:Ljava/lang/Object;

    .line 152
    .line 153
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$2:Ljava/lang/Object;

    .line 154
    .line 155
    iput-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 156
    .line 157
    iput-object v3, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$4:Ljava/lang/Object;

    .line 158
    .line 159
    iput v8, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 160
    .line 161
    const-wide/16 p0, 0xbb8

    .line 162
    .line 163
    invoke-direct/range {v10 .. v15}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector;->awaitWithin(LX/1EL;JLX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    if-ne v1, v7, :cond_7

    .line 168
    .line 169
    return-object v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 170
    :goto_2
    :try_start_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_7
    check-cast v1, LX/FjS;

    .line 174
    .line 175
    instance-of v0, v1, LX/FjP;

    .line 176
    .line 177
    if-eqz v0, :cond_a

    .line 178
    .line 179
    check-cast v1, LX/FjP;

    .line 180
    .line 181
    if-eqz v1, :cond_a

    .line 182
    .line 183
    iget-object v2, v1, LX/FjP;->A00:LX/Fjc;

    .line 184
    .line 185
    if-eqz v2, :cond_a

    .line 186
    .line 187
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 188
    .line 189
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->default()LX/BqD;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;

    .line 194
    .line 195
    invoke-direct {v0, v2, v5}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$rangeJson$1;-><init>(LX/Fjc;LX/2M4;)V

    .line 196
    .line 197
    .line 198
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$0:Ljava/lang/Object;

    .line 199
    .line 200
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$1:Ljava/lang/Object;

    .line 201
    .line 202
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$2:Ljava/lang/Object;

    .line 203
    .line 204
    iput-object v4, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$3:Ljava/lang/Object;

    .line 205
    .line 206
    iput-object v3, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$4:Ljava/lang/Object;

    .line 207
    .line 208
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$5:Ljava/lang/Object;

    .line 209
    .line 210
    iput-object v5, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->L$6:Ljava/lang/Object;

    .line 211
    .line 212
    iput v6, p3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$collect$1;->label:I

    .line 213
    .line 214
    invoke-static {p3, v1, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    if-ne v1, v7, :cond_8

    .line 219
    .line 220
    return-object v7

    .line 221
    :goto_3
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    :cond_8
    check-cast v1, Ljava/lang/String;

    .line 225
    .line 226
    if-nez v1, :cond_9

    .line 227
    .line 228
    goto :goto_4

    .line 229
    :cond_9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;

    .line 230
    .line 231
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;-><init>(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    goto :goto_5

    .line 235
    :goto_4
    if-nez v3, :cond_9

    .line 236
    .line 237
    move-object v0, v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 238
    :goto_5
    invoke-interface {v4, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 239
    .line 240
    .line 241
    return-object v0

    .line 242
    :cond_a
    invoke-interface {v4, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 243
    .line 244
    .line 245
    return-object v5

    .line 246
    :catchall_0
    move-exception v0

    .line 247
    goto :goto_6

    .line 248
    :catchall_1
    move-exception v0

    .line 249
    goto :goto_6

    .line 250
    :catchall_2
    move-exception v0

    .line 251
    :goto_6
    invoke-interface {v4, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 252
    .line 253
    .line 254
    throw v0

    .line 255
    :cond_b
    return-object v5
.end method
