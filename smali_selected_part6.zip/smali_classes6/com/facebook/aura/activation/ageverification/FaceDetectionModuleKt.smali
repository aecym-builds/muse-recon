.class public abstract Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FACE_DETECTION_MODULE:Ljava/lang/String; = "mlkit_face_detection"

.field public static final MODULE_WAIT_MS:J = 0x1d4c0L
