.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final load(Landroid/content/Context;)Z
    .locals 5

    .line 0
    const-string v3, "face_detector_v2_jni"

    .line 1
    .line 2
    const-string v4, "FaceDetectionEngine"

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    :try_start_0
    const-string v1, "com.google.mlkit.vision.face.bundled.internal.ThickFaceDetectorCreator"

    .line 10
    .line 11
    const-class v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v1, v2, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {v3}, LX/Hva;->loadLibrary(Ljava/lang/String;)Z

    .line 21
    .line 22
    .line 23
    invoke-static {v3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 24
    .line 25
    .line 26
    :try_start_1
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v0}, LX/Era;->A01(Landroid/content/Context;)V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0

    .line 31
    .line 32
    .line 33
    :catch_0
    :try_start_2
    sget-object v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngineKt;->FACE_DETECTOR_OPTIONS:LX/FMC;

    .line 34
    .line 35
    const-string v2, "You must provide a valid FaceDetectorOptions."

    .line 36
    .line 37
    invoke-static {v3, v2}, LX/FK0;->A03(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-static {}, LX/Era;->A00()LX/Era;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const-class v0, LX/Er9;

    .line 45
    .line 46
    invoke-virtual {v1, v0}, LX/Era;->A02(Ljava/lang/Class;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    check-cast v1, LX/Er9;

    .line 51
    .line 52
    invoke-static {v3, v2}, LX/FK0;->A03(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    iget-object v0, v1, LX/Er9;->A01:LX/FT5;

    .line 56
    .line 57
    invoke-virtual {v0, v3}, LX/FGX;->A00(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    check-cast v2, LX/FTD;

    .line 62
    .line 63
    iget-object v1, v1, LX/Er9;->A00:LX/Er5;

    .line 64
    .line 65
    new-instance v0, LX/FTC;

    .line 66
    .line 67
    invoke-direct {v0, v1, v2}, LX/FTC;-><init>(LX/Er5;LX/FTD;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0}, LX/FTG;->close()V

    .line 71
    .line 72
    .line 73
    const-string v0, "Bundled face engine loaded"

    .line 74
    .line 75
    invoke-static {v4, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    const/4 p0, 0x1

    .line 79
    return p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 80
    :catchall_0
    move-exception v1

    .line 81
    const-string v0, "Failed to create the face detector"

    .line 82
    .line 83
    invoke-static {v4, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 84
    .line 85
    .line 86
    return p0

    .line 87
    :catchall_1
    move-exception v1

    .line 88
    const-string v0, "Failed to load the bundled engine"

    .line 89
    .line 90
    invoke-static {v4, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 91
    .line 92
    .line 93
    return v2
.end method
