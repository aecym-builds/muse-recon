.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$UnpackedAssetsProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/content/res/loader/AssetsProvider;


# instance fields
.field public final root:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$UnpackedAssetsProvider;->root:Ljava/io/File;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public loadAssetFd(Ljava/lang/String;I)Landroid/content/res/AssetFileDescriptor;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$UnpackedAssetsProvider;->root:Ljava/io/File;

    .line 7
    .line 8
    invoke-static {v1, v0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->access$findAsset(Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    const/4 v1, 0x0

    .line 13
    if-nez v2, :cond_0

    .line 14
    .line 15
    return-object v1

    .line 16
    :cond_0
    :try_start_0
    const/high16 v0, 0x10000000

    .line 17
    .line 18
    invoke-static {v2, v0}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    const-wide/16 v4, 0x0

    .line 23
    .line 24
    const-wide/16 p1, -0x1

    .line 25
    .line 26
    new-instance v2, Landroid/content/res/AssetFileDescriptor;

    .line 27
    .line 28
    invoke-direct/range {v2 .. v7}, Landroid/content/res/AssetFileDescriptor;-><init>(Landroid/os/ParcelFileDescriptor;JJ)V

    .line 29
    .line 30
    .line 31
    return-object v2
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    :catch_0
    return-object v1
.end method
