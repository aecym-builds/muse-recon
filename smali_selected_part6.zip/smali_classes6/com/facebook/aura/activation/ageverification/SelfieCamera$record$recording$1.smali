.class public final Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0oe;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/0oe;"
    }
.end annotation


# instance fields
.field public final synthetic $finalized:LX/BcL;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/BcL<",
            "LX/FDf;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $started:LX/BcL;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/BcL<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/BcL;LX/BcL;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/BcL<",
            "Lkotlin/Unit;",
            ">;",
            "LX/BcL<",
            "LX/FDf;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->$started:LX/BcL;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->$finalized:LX/BcL;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final accept(LX/FDp;)V
    .locals 2

    .line 0
    instance-of v0, p1, LX/FEq;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->$started:LX/BcL;

    .line 5
    .line 6
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void

    .line 12
    :cond_1
    instance-of v0, p1, LX/FDf;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->$started:LX/BcL;

    .line 17
    .line 18
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->$finalized:LX/BcL;

    .line 24
    .line 25
    invoke-static {v0, p1}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p1, LX/FDp;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieCamera$record$recording$1;->accept(LX/FDp;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method
