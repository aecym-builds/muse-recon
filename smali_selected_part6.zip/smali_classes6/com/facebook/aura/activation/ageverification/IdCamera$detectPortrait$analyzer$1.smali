.class public final Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Exception;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onFrame:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;->$onFrame:LX/JDM;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/lang/Exception;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;->invoke(Ljava/lang/Exception;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(Ljava/lang/Exception;)V
    .locals 0

    .line 268435456
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$detectPortrait$analyzer$1;->$onFrame:LX/JDM;

    .line 268435457
    .line 268435458
    const/4 p0, 0x0

    .line 268435459
    invoke-interface {p1, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435460
    .line 268435461
    .line 268435462
    return-void
.end method
