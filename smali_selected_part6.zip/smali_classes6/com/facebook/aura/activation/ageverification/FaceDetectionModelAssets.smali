.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;

.field public static volatile installed:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$findAsset(Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->findAsset(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final addToAssets(Landroid/content/Context;Ljava/io/File;)V
    .locals 2

    .line 0
    new-instance p0, Landroid/content/res/loader/ResourcesLoader;

    .line 1
    .line 2
    invoke-direct {p0}, Landroid/content/res/loader/ResourcesLoader;-><init>()V

    .line 3
    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$UnpackedAssetsProvider;

    .line 6
    .line 7
    invoke-direct {v0, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$UnpackedAssetsProvider;-><init>(Ljava/io/File;)V

    .line 8
    .line 9
    .line 10
    check-cast v0, Landroid/content/res/loader/AssetsProvider;

    .line 11
    .line 12
    invoke-static {v0}, Landroid/content/res/loader/ResourcesProvider;->empty(Landroid/content/res/loader/AssetsProvider;)Landroid/content/res/loader/ResourcesProvider;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {p0, v0}, Landroid/content/res/loader/ResourcesLoader;->addProvider(Landroid/content/res/loader/ResourcesProvider;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    filled-new-array {p0}, [Landroid/content/res/loader/ResourcesLoader;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->addLoaders([Landroid/content/res/loader/ResourcesLoader;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method private final findAsset(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    .locals 4

    .line 0
    const-string v0, "assets/"

    .line 1
    .line 2
    invoke-static {v0, p2}, LX/AdT;->A0P(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {p1, v0}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/io/File;->isFile()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v2, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    return-object p0

    .line 41
    :cond_0
    return-object v3
.end method

.method private final hasEngineModels(Landroid/content/Context;)Z
    .locals 0

    .line 0
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    const-string p0, "models_bundled/fssd_25_8bit_v2.tflite"

    .line 5
    .line 6
    invoke-virtual {p1, p0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    return p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    :catch_0
    const/4 p0, 0x0

    .line 16
    return p0
.end method

.method private final declared-synchronized install(Landroid/content/Context;)Z
    .locals 8

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-boolean v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->installed:Z

    .line 2
    .line 3
    const/4 v7, 0x1

    .line 4
    if-nez v0, :cond_3

    .line 5
    .line 6
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    .line 8
    const/16 v0, 0x1e

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    if-lt v1, v0, :cond_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    .line 13
    :try_start_1
    sget-object v2, LX/H0E;->A05:LX/H0h;

    .line 14
    .line 15
    sget-object v0, LX/H0F;->A01:LX/H0v;

    .line 16
    .line 17
    invoke-static {p1, v0}, LX/H0v;->A00(Landroid/content/Context;LX/H0v;)LX/H0F;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-static {p1}, LX/H17;->A00(Landroid/content/Context;)LX/H0N;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v2, p1, v0, v1}, LX/H0h;->A00(Landroid/content/Context;LX/H0N;LX/H0p;)LX/H0E;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    const-string v2, "mlkit_face_detection"

    .line 30
    .line 31
    iget-object v5, v3, LX/H0E;->A00:Landroid/content/Context;

    .line 32
    .line 33
    invoke-static {v5, v2}, LX/H0V;->A00(Landroid/content/Context;Ljava/lang/String;)LX/H0x;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iget-object v4, v0, LX/H0x;->A01:Ljava/io/File;

    .line 38
    .line 39
    if-nez v4, :cond_0

    .line 40
    .line 41
    invoke-static {v5}, LX/GGX;->A00(Landroid/content/Context;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    invoke-static {v2}, LX/Ehs;->A01(Ljava/lang/String;)LX/Ege;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    sget-object v1, LX/Ege;->A03:LX/Ege;

    .line 52
    .line 53
    if-ne v0, v1, :cond_2

    .line 54
    .line 55
    invoke-static {v2}, LX/Ehs;->A01(Ljava/lang/String;)LX/Ege;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-ne v0, v1, :cond_1

    .line 60
    .line 61
    sget-object v0, LX/H0I;->A04:LX/H18;

    .line 62
    .line 63
    invoke-virtual {v0}, LX/H18;->A00()LX/H0I;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    iget-object v1, v0, LX/H0I;->A00:LX/GGU;

    .line 68
    .line 69
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 70
    .line 71
    invoke-static {v1, v0, v2}, LX/GGU;->A01(LX/GGU;Ljava/lang/Integer;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    if-eqz v0, :cond_1

    .line 76
    .line 77
    iget-object v0, v3, LX/H0E;->A01:LX/H0N;

    .line 78
    .line 79
    invoke-virtual {v0, v5, v2}, LX/H0N;->A02(Landroid/content/Context;Ljava/lang/String;)LX/H13;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    iget-object v4, v0, LX/H13;->A01:Ljava/io/File;

    .line 84
    .line 85
    if-eqz v4, :cond_2

    .line 86
    .line 87
    :cond_0
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_2

    .line 92
    .line 93
    iget-object v0, v3, LX/H0E;->A01:LX/H0N;

    .line 94
    .line 95
    invoke-virtual {v0, v2}, LX/H0N;->A01(Ljava/lang/String;)LX/Gzr;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    const-string v0, "engine-assets"

    .line 100
    .line 101
    invoke-static {v1, v0}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    const-string v0, "models_bundled"

    .line 106
    .line 107
    invoke-static {v1, v0}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    invoke-direct {p0, p1, v4, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->unpackModels(Landroid/content/Context;Ljava/io/File;Ljava/io/File;)V

    .line 112
    .line 113
    .line 114
    invoke-direct {p0, p1, v1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->addToAssets(Landroid/content/Context;Ljava/io/File;)V

    .line 115
    .line 116
    .line 117
    sput-boolean v7, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->installed:Z

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_1
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    const-string v1, "VoltronModuleManager"

    .line 125
    .line 126
    const-string v0, "Hash not found for module %s"

    .line 127
    .line 128
    invoke-static {v1, v0, v2}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    goto :goto_0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 132
    :catch_0
    move-exception v2

    .line 133
    :try_start_2
    const-string v1, "FaceDetectionModelAssets"

    .line 134
    .line 135
    const-string v0, "Failed to install the models from mlkit_face_detection"

    .line 136
    .line 137
    invoke-static {v1, v0, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 138
    .line 139
    .line 140
    goto :goto_1

    .line 141
    :catch_1
    move-exception v2

    .line 142
    const-string v1, "FaceDetectionModelAssets"

    .line 143
    .line 144
    const-string v0, "Failed to install the models from mlkit_face_detection"

    .line 145
    .line 146
    invoke-static {v1, v0, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 147
    .line 148
    .line 149
    goto :goto_1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 150
    :cond_2
    :goto_0
    monitor-exit p0

    .line 151
    return v6

    .line 152
    :goto_1
    const/4 v7, 0x0

    .line 153
    :cond_3
    :goto_2
    monitor-exit p0

    .line 154
    return v7

    .line 155
    :catchall_0
    move-exception v0

    .line 156
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 157
    throw v0
.end method

.method private final modelNames(Ljava/io/File;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const-string p0, "assets/mlkit_face_detection/models_bundled/"

    .line 1
    .line 2
    new-instance v3, Ljava/util/zip/ZipFile;

    .line 3
    .line 4
    invoke-direct {v3, p1}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V

    .line 5
    .line 6
    .line 7
    :try_start_0
    invoke-virtual {v3}, Ljava/util/zip/ZipFile;->entries()Ljava/util/Enumeration;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    new-instance v0, LX/GpM;

    .line 15
    .line 16
    invoke-direct {v0, v1}, LX/GpM;-><init>(Ljava/util/Enumeration;)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, LX/B85;->A0B(Ljava/util/Iterator;)LX/14K;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$1;

    .line 24
    .line 25
    invoke-static {v2, v0}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v1, LX/As9;

    .line 29
    .line 30
    invoke-direct {v1, v0, v2}, LX/As9;-><init>(LX/JDM;LX/0Xf;)V

    .line 31
    .line 32
    .line 33
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$2;

    .line 34
    .line 35
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$2;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-static {v0, v1}, LX/B84;->A05(LX/JDM;LX/0Xf;)LX/0Xg;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$3;

    .line 43
    .line 44
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$3;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v2, v0}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    new-instance v1, LX/As9;

    .line 51
    .line 52
    invoke-direct {v1, v0, v2}, LX/As9;-><init>(LX/JDM;LX/0Xf;)V

    .line 53
    .line 54
    .line 55
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$4;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets$modelNames$1$4;

    .line 56
    .line 57
    invoke-static {v0, v1}, LX/B84;->A05(LX/JDM;LX/0Xf;)LX/0Xg;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-static {v0}, LX/B84;->A04(LX/0Xf;)Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 65
    invoke-virtual {v3}, Ljava/util/zip/ZipFile;->close()V

    .line 66
    .line 67
    .line 68
    return-object v0

    .line 69
    :catchall_0
    move-exception v1

    .line 70
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 71
    :catchall_1
    move-exception v0

    .line 72
    invoke-static {v3, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    throw v0
.end method

.method private final unpackModels(Landroid/content/Context;Ljava/io/File;Ljava/io/File;)V
    .locals 22

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    move-object/from16 v6, p2

    .line 3
    .line 4
    invoke-direct {v0, v6}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->modelNames(Ljava/io/File;)Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_18

    .line 13
    .line 14
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    sget-object v4, LX/H0A;->A06:Ljava/util/concurrent/Executor;

    .line 19
    .line 20
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-static {v3}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    const-string v0, "models_bundled/"

    .line 35
    .line 36
    invoke-static {v0, v2}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    new-instance v0, LX/H08;

    .line 41
    .line 42
    invoke-direct {v0, v6, v1, v2}, LX/H08;-><init>(Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    move-object/from16 v3, p3

    .line 50
    .line 51
    invoke-static {v3}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    const/4 v2, 0x0

    .line 55
    :goto_1
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->size()I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-ge v2, v0, :cond_1

    .line 60
    .line 61
    invoke-virtual {v5, v2}, Ljava/util/AbstractList;->get(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    check-cast v1, LX/H09;

    .line 66
    .line 67
    iget-object v0, v1, LX/H09;->A01:Ljava/lang/String;

    .line 68
    .line 69
    invoke-static {v3, v0}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    iput-object v0, v1, LX/H09;->A00:Ljava/io/File;

    .line 74
    .line 75
    add-int/lit8 v2, v2, 0x1

    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_1
    new-instance v6, LX/H0A;

    .line 79
    .line 80
    move-object/from16 v0, p1

    .line 81
    .line 82
    invoke-direct {v6, v0, v3, v5, v4}, LX/H0A;-><init>(Landroid/content/Context;Ljava/io/File;Ljava/util/ArrayList;Ljava/util/concurrent/Executor;)V

    .line 83
    .line 84
    .line 85
    :try_start_0
    const-string v0, "AppUnpacker.lock"

    .line 86
    .line 87
    const-wide v1, 0x80000000L

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    invoke-static {v1, v2, v0}, Lcom/facebook/systrace/Systrace;->A04(JLjava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_5

    .line 93
    .line 94
    .line 95
    :try_start_1
    sget-object v5, LX/H0A;->A05:LX/H0X;

    .line 96
    .line 97
    const-string v4, "MlKitFaceDetectionModels"

    .line 98
    .line 99
    monitor-enter v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_8

    .line 100
    :try_start_2
    iget-object v7, v5, LX/H0X;->A00:Ljava/util/Map;

    .line 101
    .line 102
    invoke-interface {v7, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    check-cast v3, LX/H14;

    .line 107
    .line 108
    if-nez v3, :cond_2

    .line 109
    .line 110
    new-instance v3, LX/H14;

    .line 111
    .line 112
    invoke-direct {v3}, LX/H14;-><init>()V

    .line 113
    .line 114
    .line 115
    iget-object v0, v3, LX/H14;->A01:Ljava/util/concurrent/Semaphore;

    .line 116
    .line 117
    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->acquire()V

    .line 118
    .line 119
    .line 120
    invoke-interface {v7, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    monitor-exit v5

    .line 124
    goto :goto_2

    .line 125
    :cond_2
    iget v0, v3, LX/H14;->A00:I

    .line 126
    .line 127
    add-int/lit8 v0, v0, 0x1

    .line 128
    .line 129
    iput v0, v3, LX/H14;->A00:I

    .line 130
    .line 131
    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_7

    .line 132
    :try_start_3
    iget-object v0, v3, LX/H14;->A01:Ljava/util/concurrent/Semaphore;

    .line 133
    .line 134
    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_4
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_8

    .line 135
    .line 136
    .line 137
    :goto_2
    :try_start_4
    iget-object v0, v6, LX/H0A;->A00:LX/FpX;

    .line 138
    .line 139
    if-nez v0, :cond_17

    .line 140
    .line 141
    iget-object v0, v6, LX/H0A;->A01:Landroid/content/Context;

    .line 142
    .line 143
    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    if-eqz v3, :cond_3

    .line 148
    .line 149
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    if-nez v0, :cond_4

    .line 154
    .line 155
    :cond_3
    const-string v0, "/data/local/tmp"

    .line 156
    .line 157
    invoke-static {v0}, LX/EYt;->A0N(Ljava/lang/String;)Ljava/io/File;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    :cond_4
    const-string v0, ".lock"

    .line 162
    .line 163
    invoke-static {v4, v0, v3}, LX/8mk;->A0S(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    if-nez v0, :cond_5

    .line 172
    .line 173
    invoke-virtual {v3}, Ljava/io/File;->createNewFile()Z

    .line 174
    .line 175
    .line 176
    :cond_5
    new-instance v0, LX/FpX;

    .line 177
    .line 178
    invoke-direct {v0, v3}, LX/FpX;-><init>(Ljava/io/File;)V

    .line 179
    .line 180
    .line 181
    iput-object v0, v6, LX/H0A;->A00:LX/FpX;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_6

    .line 182
    .line 183
    :try_start_5
    invoke-static {v1, v2}, Lcom/facebook/systrace/Systrace;->A03(J)V

    .line 184
    .line 185
    .line 186
    const-string v0, "AppUnpacker.unpack()"

    .line 187
    .line 188
    invoke-static {v1, v2, v0}, Lcom/facebook/systrace/Systrace;->A04(JLjava/lang/String;)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_5

    .line 189
    .line 190
    .line 191
    :try_start_6
    const-string p0, " exists: "

    .line 192
    .line 193
    const/16 v21, 0x4000

    .line 194
    .line 195
    move/from16 v0, v21

    .line 196
    .line 197
    new-array v0, v0, [B

    .line 198
    .line 199
    move-object/from16 p3, v0

    .line 200
    .line 201
    iget-object v0, v6, LX/H0A;->A02:Ljava/io/File;

    .line 202
    .line 203
    move-object/from16 p2, v0

    .line 204
    .line 205
    const-string v3, ".unpacked"

    .line 206
    .line 207
    invoke-static {v0, v3}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 208
    .line 209
    .line 210
    move-result-object v3

    .line 211
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->exists()Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    const/4 v7, 0x0

    .line 216
    if-eqz v0, :cond_6

    .line 217
    .line 218
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    .line 219
    .line 220
    .line 221
    move-result v0

    .line 222
    const/4 v3, 0x0

    .line 223
    if-nez v0, :cond_7

    .line 224
    .line 225
    :cond_6
    const/4 v3, 0x1

    .line 226
    :cond_7
    :goto_3
    iget-object v4, v6, LX/H0A;->A04:[LX/H09;

    .line 227
    .line 228
    array-length v0, v4

    .line 229
    move/from16 p1, v0

    .line 230
    .line 231
    if-ge v7, v0, :cond_8

    .line 232
    .line 233
    if-nez v3, :cond_9

    .line 234
    .line 235
    aget-object v0, v4, v7

    .line 236
    .line 237
    iget-object v0, v0, LX/H09;->A00:Ljava/io/File;

    .line 238
    .line 239
    invoke-static {v0}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    xor-int/lit8 v3, v0, 0x1

    .line 247
    .line 248
    add-int/lit8 v7, v7, 0x1

    .line 249
    .line 250
    goto :goto_3

    .line 251
    :cond_8
    if-nez v3, :cond_9

    .line 252
    .line 253
    const/4 v0, 0x4

    .line 254
    goto/16 :goto_f
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    .line 255
    .line 256
    :cond_9
    :try_start_7
    invoke-static/range {p2 .. p2}, LX/H0A;->A00(Ljava/io/File;)V

    .line 257
    .line 258
    .line 259
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->mkdirs()Z

    .line 260
    .line 261
    .line 262
    move-result v0

    .line 263
    if-nez v0, :cond_a

    .line 264
    .line 265
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->isDirectory()Z

    .line 266
    .line 267
    .line 268
    move-result v0

    .line 269
    if-nez v0, :cond_a

    .line 270
    .line 271
    const-wide/16 v7, 0x64
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 272
    .line 273
    :try_start_8
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V

    .line 274
    .line 275
    .line 276
    goto/16 :goto_d
    :try_end_8
    .catch Ljava/lang/InterruptedException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 277
    .line 278
    :catch_0
    :try_start_9
    move-exception v4

    .line 279
    invoke-static {}, LX/EYt;->A1G()V

    .line 280
    .line 281
    .line 282
    const-string v3, "Interrupted while retrying directory creation"

    .line 283
    .line 284
    new-instance v0, Ljava/io/IOException;

    .line 285
    .line 286
    invoke-direct {v0, v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 287
    .line 288
    .line 289
    goto/16 :goto_e
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 290
    .line 291
    :cond_a
    :try_start_a
    const-string v8, "AppUnpacker"

    .line 292
    .line 293
    const/4 v7, 0x0

    .line 294
    const/16 v20, 0x1

    .line 295
    .line 296
    const/4 v13, 0x0

    .line 297
    const/4 v3, 0x0

    .line 298
    :goto_4
    move/from16 v0, p1

    .line 299
    .line 300
    if-ge v13, v0, :cond_15
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    .line 301
    .line 302
    :try_start_b
    aget-object v12, v4, v13
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 303
    .line 304
    :try_start_c
    const-string v19, " at "

    .line 305
    .line 306
    const-string v18, ", unpacker failed to unpack "

    .line 307
    .line 308
    const-string v17, ", "

    .line 309
    .line 310
    move-object v14, v12

    .line 311
    check-cast v14, LX/H08;

    .line 312
    .line 313
    iget-object v0, v14, LX/H08;->A00:Ljava/io/File;

    .line 314
    .line 315
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 316
    .line 317
    .line 318
    move-result v9

    .line 319
    if-eqz v9, :cond_f

    .line 320
    .line 321
    new-instance v10, Ljava/util/zip/ZipFile;

    .line 322
    .line 323
    invoke-direct {v10, v0}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V

    .line 324
    .line 325
    .line 326
    iget-object v11, v14, LX/H08;->A01:Ljava/lang/String;

    .line 327
    .line 328
    invoke-virtual {v10, v11}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    .line 329
    .line 330
    .line 331
    move-result-object v9

    .line 332
    if-eqz v9, :cond_e

    .line 333
    .line 334
    invoke-virtual {v10, v9}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    .line 335
    .line 336
    .line 337
    move-result-object v9

    .line 338
    if-eqz v9, :cond_d

    .line 339
    .line 340
    new-instance v11, LX/Fo9;

    .line 341
    .line 342
    invoke-direct {v11, v14, v9, v10}, LX/Fo9;-><init>(LX/H08;Ljava/io/InputStream;Ljava/util/zip/ZipFile;)V
    :try_end_c
    .catch Ljava/io/FileNotFoundException; {:try_start_c .. :try_end_c} :catch_3
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 343
    .line 344
    .line 345
    :try_start_d
    iget-object v0, v12, LX/H09;->A00:Ljava/io/File;

    .line 346
    .line 347
    invoke-static {v0}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    invoke-static {v0}, LX/EYt;->A0P(Ljava/io/File;)Ljava/io/FileOutputStream;

    .line 351
    .line 352
    .line 353
    move-result-object v16

    .line 354
    const v14, 0x7fffffff

    .line 355
    .line 356
    .line 357
    const/4 v10, 0x0

    .line 358
    :goto_5
    sub-int v9, v14, v10
    :try_end_d
    .catch Ljava/io/FileNotFoundException; {:try_start_d .. :try_end_d} :catch_1
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    .line 359
    .line 360
    :try_start_e
    move/from16 v0, v21

    .line 361
    .line 362
    invoke-static {v9, v0}, Ljava/lang/Math;->min(II)I

    .line 363
    .line 364
    .line 365
    move-result v9

    .line 366
    move-object/from16 v0, p3

    .line 367
    .line 368
    invoke-virtual {v11, v0, v7, v9}, Ljava/io/InputStream;->read([BII)I

    .line 369
    .line 370
    .line 371
    move-result v15

    .line 372
    const/4 v0, -0x1

    .line 373
    if-eq v15, v0, :cond_b

    .line 374
    .line 375
    move-object/from16 v9, v16

    .line 376
    .line 377
    move-object/from16 v0, p3

    .line 378
    .line 379
    invoke-virtual {v9, v0, v7, v15}, Ljava/io/OutputStream;->write([BII)V

    .line 380
    .line 381
    .line 382
    add-int/2addr v10, v15

    .line 383
    if-ge v10, v14, :cond_b

    .line 384
    .line 385
    goto :goto_5
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    .line 386
    :cond_b
    :try_start_f
    invoke-virtual/range {v16 .. v16}, Ljava/io/OutputStream;->close()V
    :try_end_f
    .catch Ljava/io/FileNotFoundException; {:try_start_f .. :try_end_f} :catch_1
    .catchall {:try_start_f .. :try_end_f} :catchall_2

    .line 387
    .line 388
    .line 389
    :try_start_10
    invoke-virtual {v11}, Ljava/io/InputStream;->close()V

    .line 390
    .line 391
    .line 392
    goto/16 :goto_c
    :try_end_10
    .catch Ljava/io/FileNotFoundException; {:try_start_10 .. :try_end_10} :catch_3
    .catchall {:try_start_10 .. :try_end_10} :catchall_4

    .line 393
    .line 394
    :catchall_0
    move-exception v9

    .line 395
    :try_start_11
    invoke-virtual/range {v16 .. v16}, Ljava/io/OutputStream;->close()V

    .line 396
    .line 397
    .line 398
    goto :goto_6
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_1

    .line 399
    :catchall_1
    move-exception v0

    .line 400
    :try_start_12
    invoke-static {v9, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 401
    .line 402
    .line 403
    :goto_6
    throw v9
    :try_end_12
    .catch Ljava/io/FileNotFoundException; {:try_start_12 .. :try_end_12} :catch_1
    .catchall {:try_start_12 .. :try_end_12} :catchall_2

    .line 404
    :catch_1
    move-exception v16

    .line 405
    :try_start_13
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v10

    .line 409
    invoke-static {v10}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 410
    .line 411
    .line 412
    invoke-static {v12}, LX/I8A;->A00(Ljava/lang/Object;)Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v9

    .line 416
    move-object/from16 v0, v17

    .line 417
    .line 418
    invoke-static {v0, v9}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v13

    .line 422
    iget-object v15, v12, LX/H09;->A02:Ljava/lang/String;

    .line 423
    .line 424
    const-string v14, " to "

    .line 425
    .line 426
    iget-object v9, v12, LX/H09;->A01:Ljava/lang/String;

    .line 427
    .line 428
    move-object/from16 v0, v18

    .line 429
    .line 430
    invoke-static {v0, v15, v14, v9}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object v14

    .line 434
    iget-object v0, v12, LX/H09;->A00:Ljava/io/File;

    .line 435
    .line 436
    if-eqz v0, :cond_c

    .line 437
    .line 438
    invoke-virtual {v0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 439
    .line 440
    .line 441
    move-result-object v9

    .line 442
    move-object/from16 v0, v19

    .line 443
    .line 444
    invoke-static {v0, v9}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object v0

    .line 448
    :goto_7
    invoke-static {v10, v13, v14, v0}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v12

    .line 452
    const-string v10, ", stack: "

    .line 453
    .line 454
    invoke-static/range {v16 .. v16}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 455
    .line 456
    .line 457
    move-result-object v9

    .line 458
    const-string v0, " end of stack.\n"

    .line 459
    .line 460
    invoke-static {v12, v10, v9, v0}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 461
    .line 462
    .line 463
    move-result-object v0

    .line 464
    invoke-static {v8, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 465
    .line 466
    .line 467
    new-instance v0, Ljava/io/FileNotFoundException;

    .line 468
    .line 469
    invoke-direct {v0, v12}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    throw v0

    .line 473
    :cond_c
    const-string v0, " with no destination file"

    .line 474
    .line 475
    goto :goto_7
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_2

    .line 476
    :catchall_2
    move-exception v9

    .line 477
    :try_start_14
    invoke-virtual {v11}, Ljava/io/InputStream;->close()V

    .line 478
    .line 479
    .line 480
    goto :goto_8
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_3

    .line 481
    :cond_d
    :try_start_15
    const-string v10, "Failed to get input stream for "

    .line 482
    .line 483
    const-string v9, " from Voltron module "

    .line 484
    .line 485
    invoke-virtual {v0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 486
    .line 487
    .line 488
    move-result-object v0

    .line 489
    invoke-static {v10, v11, v9, v0}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 490
    .line 491
    .line 492
    move-result-object v0

    .line 493
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 494
    .line 495
    .line 496
    move-result-object v9

    .line 497
    goto :goto_8
    :try_end_15
    .catch Ljava/io/FileNotFoundException; {:try_start_15 .. :try_end_15} :catch_3
    .catchall {:try_start_15 .. :try_end_15} :catchall_4

    .line 498
    :cond_e
    :try_start_16
    invoke-virtual {v10}, Ljava/util/zip/ZipFile;->close()V
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_16} :catch_2
    .catch Ljava/io/FileNotFoundException; {:try_start_16 .. :try_end_16} :catch_3
    .catchall {:try_start_16 .. :try_end_16} :catchall_4

    .line 499
    .line 500
    .line 501
    :catch_2
    :try_start_17
    const-string v9, " was not found in Voltron module "

    .line 502
    .line 503
    invoke-virtual {v0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v0

    .line 507
    invoke-static {v11, v9, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v0

    .line 511
    new-instance v9, Ljava/io/FileNotFoundException;

    .line 512
    .line 513
    invoke-direct {v9, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 514
    .line 515
    .line 516
    goto :goto_8

    .line 517
    :cond_f
    const-string v9, "Voltron module does not exist: "

    .line 518
    .line 519
    invoke-virtual {v0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 520
    .line 521
    .line 522
    move-result-object v0

    .line 523
    invoke-static {v9, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    new-instance v9, Ljava/io/FileNotFoundException;

    .line 528
    .line 529
    invoke-direct {v9, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 530
    .line 531
    .line 532
    goto :goto_8

    .line 533
    :catchall_3
    move-exception v0

    .line 534
    invoke-static {v9, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 535
    .line 536
    .line 537
    :goto_8
    throw v9
    :try_end_17
    .catch Ljava/io/FileNotFoundException; {:try_start_17 .. :try_end_17} :catch_3
    .catchall {:try_start_17 .. :try_end_17} :catchall_4

    .line 538
    :catch_3
    move-exception v14

    .line 539
    :try_start_18
    invoke-virtual {v14}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 540
    .line 541
    .line 542
    move-result-object v0

    .line 543
    invoke-static {v0}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 544
    .line 545
    .line 546
    invoke-static {v0}, LX/001;->A0y(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 547
    .line 548
    .line 549
    move-result-object v10

    .line 550
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 551
    .line 552
    .line 553
    move-result-object v9

    .line 554
    const-string v0, ", directory path: "

    .line 555
    .line 556
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 557
    .line 558
    .line 559
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object v0

    .line 563
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 564
    .line 565
    .line 566
    move-object/from16 v0, p0

    .line 567
    .line 568
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->exists()Z

    .line 572
    .line 573
    .line 574
    move-result v0

    .line 575
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 576
    .line 577
    .line 578
    const-string v0, ", retry count: "

    .line 579
    .line 580
    invoke-static {v0, v9, v3}, LX/008;->A12(Ljava/lang/String;Ljava/lang/StringBuilder;I)Ljava/lang/String;

    .line 581
    .line 582
    .line 583
    move-result-object v0

    .line 584
    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 585
    .line 586
    .line 587
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 588
    .line 589
    .line 590
    move-result-object v13

    .line 591
    :goto_9
    if-eqz v13, :cond_12

    .line 592
    .line 593
    invoke-virtual {v13}, Ljava/io/File;->exists()Z

    .line 594
    .line 595
    .line 596
    move-result v12

    .line 597
    const-string v11, ", parent directory path: "

    .line 598
    .line 599
    invoke-virtual {v13}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 600
    .line 601
    .line 602
    move-result-object v9

    .line 603
    move-object/from16 v0, p0

    .line 604
    .line 605
    invoke-static {v11, v9, v0, v12}, LX/Gi8;->A16(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    .line 606
    .line 607
    .line 608
    move-result-object v0

    .line 609
    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 610
    .line 611
    .line 612
    if-eqz v12, :cond_10

    .line 613
    .line 614
    goto :goto_a

    .line 615
    :cond_10
    invoke-virtual {v13}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 616
    .line 617
    .line 618
    move-result-object v13

    .line 619
    goto :goto_9

    .line 620
    :goto_a
    invoke-virtual {v13}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 621
    .line 622
    .line 623
    move-result-object v13

    .line 624
    if-eqz v13, :cond_11

    .line 625
    .line 626
    array-length v12, v13

    .line 627
    const/4 v11, 0x0

    .line 628
    :goto_b
    if-ge v11, v12, :cond_12

    .line 629
    .line 630
    aget-object v0, v13, v11

    .line 631
    .line 632
    const-string v9, "File in parent directory after: %s"

    .line 633
    .line 634
    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object v0

    .line 638
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v0

    .line 642
    invoke-static {v8, v9, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 643
    .line 644
    .line 645
    add-int/lit8 v11, v11, 0x1

    .line 646
    .line 647
    goto :goto_b

    .line 648
    :cond_11
    const-string v0, "The folder is empty"

    .line 649
    .line 650
    invoke-static {v8, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    :cond_12
    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 654
    .line 655
    .line 656
    move-result-object v11

    .line 657
    const-string v10, ", stack: "

    .line 658
    .line 659
    invoke-static {v14}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v9

    .line 663
    const-string v0, " end of stack.\n"

    .line 664
    .line 665
    invoke-static {v11, v10, v9, v0}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 666
    .line 667
    .line 668
    move-result-object v0

    .line 669
    invoke-static {v8, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 670
    .line 671
    .line 672
    move/from16 v0, v20

    .line 673
    .line 674
    if-eq v3, v0, :cond_14

    .line 675
    .line 676
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->mkdirs()Z

    .line 677
    .line 678
    .line 679
    move-result v0

    .line 680
    if-nez v0, :cond_13

    .line 681
    .line 682
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->isDirectory()Z

    .line 683
    .line 684
    .line 685
    move-result v0

    .line 686
    if-nez v0, :cond_13

    .line 687
    .line 688
    new-instance v0, Ljava/io/FileNotFoundException;

    .line 689
    .line 690
    invoke-direct {v0, v11}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 691
    .line 692
    .line 693
    goto :goto_e

    .line 694
    :cond_13
    const/4 v3, 0x1

    .line 695
    const/4 v13, -0x1

    .line 696
    :goto_c
    add-int/lit8 v13, v13, 0x1

    .line 697
    .line 698
    goto/16 :goto_4

    .line 699
    .line 700
    :cond_14
    new-instance v0, Ljava/io/FileNotFoundException;

    .line 701
    .line 702
    invoke-direct {v0, v11}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 703
    .line 704
    .line 705
    goto :goto_e

    .line 706
    :goto_d
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->mkdirs()Z

    .line 707
    .line 708
    .line 709
    move-result v0

    .line 710
    if-nez v0, :cond_a

    .line 711
    .line 712
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->isDirectory()Z

    .line 713
    .line 714
    .line 715
    move-result v0

    .line 716
    if-nez v0, :cond_a

    .line 717
    .line 718
    const-string v0, "Could not create the destination directory"

    .line 719
    .line 720
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 721
    .line 722
    .line 723
    move-result-object v0

    .line 724
    :goto_e
    throw v0

    .line 725
    :cond_15
    iget-object v3, v6, LX/H0A;->A03:Ljava/util/concurrent/Executor;

    .line 726
    .line 727
    new-instance v0, LX/H0d;

    .line 728
    .line 729
    invoke-direct {v0, v6}, LX/H0d;-><init>(LX/H0A;)V

    .line 730
    .line 731
    .line 732
    invoke-interface {v3, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 733
    .line 734
    .line 735
    const/4 v0, 0x1
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_4

    .line 736
    :goto_f
    :try_start_19
    invoke-static {v1, v2}, Lcom/facebook/systrace/Systrace;->A03(J)V

    .line 737
    .line 738
    .line 739
    and-int/lit8 v0, v0, 0x1

    .line 740
    .line 741
    if-nez v0, :cond_16

    .line 742
    .line 743
    iget-object v0, v6, LX/H0A;->A00:LX/FpX;

    .line 744
    .line 745
    invoke-static {v0}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 746
    .line 747
    .line 748
    invoke-virtual {v0}, LX/FpX;->close()V

    .line 749
    .line 750
    .line 751
    const/4 v0, 0x0

    .line 752
    iput-object v0, v6, LX/H0A;->A00:LX/FpX;

    .line 753
    .line 754
    invoke-virtual {v5}, LX/H0X;->A01()V

    .line 755
    .line 756
    .line 757
    :cond_16
    return-void
    :try_end_19
    .catch Ljava/io/IOException; {:try_start_19 .. :try_end_19} :catch_5
    .catch Ljava/lang/InterruptedException; {:try_start_19 .. :try_end_19} :catch_5

    .line 758
    :catchall_4
    :try_start_1a
    move-exception v0

    .line 759
    invoke-static/range {p2 .. p2}, LX/H0A;->A00(Ljava/io/File;)V

    .line 760
    .line 761
    .line 762
    throw v0
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_5

    .line 763
    :catchall_5
    move-exception v3

    .line 764
    goto :goto_11

    .line 765
    :cond_17
    :try_start_1b
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    throw v0
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_6

    .line 770
    :catchall_6
    move-exception v0

    .line 771
    :try_start_1c
    invoke-virtual {v5}, LX/H0X;->A01()V

    .line 772
    .line 773
    .line 774
    goto :goto_10
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_8

    .line 775
    :catchall_7
    move-exception v0

    .line 776
    :try_start_1d
    monitor-exit v5

    .line 777
    goto :goto_10
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_7

    .line 778
    :catch_4
    :try_start_1e
    move-exception v0

    .line 779
    invoke-static {v5}, LX/H0X;->A00(LX/H0X;)V

    .line 780
    .line 781
    .line 782
    :goto_10
    throw v0
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_8

    .line 783
    :catchall_8
    :try_start_1f
    move-exception v3

    .line 784
    invoke-static {v1, v2}, Lcom/facebook/systrace/Systrace;->A03(J)V

    .line 785
    .line 786
    .line 787
    goto :goto_12

    .line 788
    :goto_11
    invoke-static {v1, v2}, Lcom/facebook/systrace/Systrace;->A03(J)V

    .line 789
    .line 790
    .line 791
    iget-object v0, v6, LX/H0A;->A00:LX/FpX;

    .line 792
    .line 793
    invoke-static {v0}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 794
    .line 795
    .line 796
    invoke-virtual {v0}, LX/FpX;->close()V

    .line 797
    .line 798
    .line 799
    const/4 v0, 0x0

    .line 800
    iput-object v0, v6, LX/H0A;->A00:LX/FpX;

    .line 801
    .line 802
    invoke-virtual {v5}, LX/H0X;->A01()V

    .line 803
    .line 804
    .line 805
    :goto_12
    throw v3
    :try_end_1f
    .catch Ljava/io/IOException; {:try_start_1f .. :try_end_1f} :catch_5
    .catch Ljava/lang/InterruptedException; {:try_start_1f .. :try_end_1f} :catch_5

    .line 806
    :catch_5
    move-exception v0

    .line 807
    invoke-static {v0}, LX/EYt;->A0h(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    .line 808
    .line 809
    .line 810
    move-result-object v0

    .line 811
    throw v0

    .line 812
    :cond_18
    const-string v0, "No models in mlkit_face_detection"

    .line 813
    .line 814
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 815
    .line 816
    .line 817
    move-result-object v0

    .line 818
    throw v0
.end method


# virtual methods
.method public final ensureAvailable(Landroid/content/Context;)Z
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->hasEngineModels(Landroid/content/Context;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->install(Landroid/content/Context;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->hasEngineModels(Landroid/content/Context;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :cond_0
    const/4 v1, 0x1

    .line 23
    :cond_1
    return v1
.end method
