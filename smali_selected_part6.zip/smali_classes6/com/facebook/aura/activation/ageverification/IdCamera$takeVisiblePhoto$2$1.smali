.class public final Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final synthetic $result:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public constructor <init>(LX/DT0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-",
            "Landroid/graphics/Bitmap;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onCaptureProcessProgressed(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public onCaptureStarted()V
    .locals 0

    .line 0
    return-void
.end method

.method public onCaptureSuccess(LX/FBz;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    invoke-static {p1}, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->toUprightVisibleBitmap(LX/FBz;)Landroid/graphics/Bitmap;

    .line 5
    .line 6
    .line 7
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    invoke-interface {p1}, LX/FBz;->close()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 12
    .line 13
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 20
    .line 21
    invoke-interface {v0, v1}, LX/2M4;->resumeWith(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :catch_0
    move-exception v1

    .line 30
    :try_start_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 31
    .line 32
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/EYw;->A1K(Ljava/lang/Throwable;LX/2M4;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 41
    .line 42
    .line 43
    :cond_1
    invoke-interface {p1}, LX/FBz;->close()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :catchall_0
    move-exception v0

    .line 48
    invoke-interface {p1}, LX/FBz;->close()V

    .line 49
    .line 50
    .line 51
    throw v0
.end method

.method public onError(Landroidx/camera/core/ImageCaptureException;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 5
    .line 6
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCamera$takeVisiblePhoto$2$1;->$result:LX/DT0;

    .line 13
    .line 14
    invoke-static {p1, v0}, LX/EYw;->A1K(Ljava/lang/Throwable;LX/2M4;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public onPostviewBitmapAvailable(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 0
    return-void
.end method
