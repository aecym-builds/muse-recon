.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FWz;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/FWz;"
    }
.end annotation


# instance fields
.field public final synthetic $image:LX/FBz;

.field public final synthetic $luma:F

.field public final synthetic $side:F

.field public final synthetic $uprightHeight:I

.field public final synthetic $uprightWidth:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;FLX/FBz;IIF)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$luma:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$image:LX/FBz;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$uprightWidth:I

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$uprightHeight:I

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$side:F

    .line 11
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final onComplete(LX/FWb;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FWb<",
            "Ljava/util/List<",
            "LX/FM7;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v3, LX/0Rg;

    .line 5
    .line 6
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 10
    .line 11
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 12
    .line 13
    if-nez v0, :cond_3

    .line 14
    .line 15
    move-object v0, p1

    .line 16
    check-cast v0, LX/FWa;

    .line 17
    .line 18
    iget-boolean v0, v0, LX/FWa;->A05:Z

    .line 19
    .line 20
    if-nez v0, :cond_3

    .line 21
    .line 22
    invoke-virtual {p1}, LX/FWb;->A0C()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-virtual {p1}, LX/FWb;->A08()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v8

    .line 32
    check-cast v8, Ljava/util/List;

    .line 33
    .line 34
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 35
    .line 36
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onFrame:LX/JDM;

    .line 37
    .line 38
    invoke-static {v8}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iget v7, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$uprightWidth:I

    .line 42
    .line 43
    iget v5, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$uprightHeight:I

    .line 44
    .line 45
    iget v2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$side:F

    .line 46
    .line 47
    invoke-static {v8}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_1

    .line 60
    .line 61
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    check-cast v0, LX/FM7;

    .line 66
    .line 67
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    invoke-static {v0, v7, v5, v2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzerKt;->normalized(LX/FM7;IIF)Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 79
    .line 80
    const/4 v0, 0x1

    .line 81
    iput-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->unavailable:Z

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;

    .line 84
    .line 85
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer;->onUnavailable:LX/JDM;

    .line 86
    .line 87
    invoke-virtual {p1}, LX/FWb;->A07()Ljava/lang/Exception;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    if-nez v0, :cond_2

    .line 92
    .line 93
    const-string v0, "Face detection failed"

    .line 94
    .line 95
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    goto :goto_1

    .line 100
    :cond_1
    iget v2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$luma:F

    .line 101
    .line 102
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$image:LX/FBz;

    .line 103
    .line 104
    new-instance v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;

    .line 105
    .line 106
    invoke-direct {v1, v8, v0, v3}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;-><init>(Ljava/util/List;LX/FBz;LX/0Rg;)V

    .line 107
    .line 108
    .line 109
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceFrame;

    .line 110
    .line 111
    invoke-direct {v0, v4, v2, v1}, Lcom/facebook/aura/activation/ageverification/FaceFrame;-><init>(Ljava/util/List;FLX/JDM;)V

    .line 112
    .line 113
    .line 114
    :cond_2
    :goto_1
    invoke-interface {v6, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 115
    .line 116
    .line 117
    :cond_3
    iget-boolean v0, v3, LX/0Rg;->element:Z

    .line 118
    .line 119
    if-nez v0, :cond_4

    .line 120
    .line 121
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$image:LX/FBz;

    .line 122
    .line 123
    invoke-interface {v0}, LX/FBz;->close()V

    .line 124
    .line 125
    .line 126
    :cond_4
    return-void

    .line 127
    :catchall_0
    move-exception v1

    .line 128
    iget-boolean v0, v3, LX/0Rg;->element:Z

    .line 129
    .line 130
    if-nez v0, :cond_5

    .line 131
    .line 132
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1;->$image:LX/FBz;

    .line 133
    .line 134
    invoke-interface {v0}, LX/FBz;->close()V

    .line 135
    .line 136
    .line 137
    :cond_5
    throw v1
.end method
