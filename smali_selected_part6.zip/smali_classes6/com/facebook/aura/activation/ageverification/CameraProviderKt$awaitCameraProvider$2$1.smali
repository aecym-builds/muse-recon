.class public final Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $future:Lcom/google/common/util/concurrent/ListenableFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/util/concurrent/ListenableFuture<",
            "LX/F7T;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $result:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "LX/F7T;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DT0;Lcom/google/common/util/concurrent/ListenableFuture;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-",
            "LX/F7T;",
            ">;",
            "Lcom/google/common/util/concurrent/ListenableFuture<",
            "LX/F7T;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$result:LX/DT0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$future:Lcom/google/common/util/concurrent/ListenableFuture;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$result:LX/DT0;

    .line 1
    .line 2
    invoke-interface {v0}, LX/DT0;->isActive()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$result:LX/DT0;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$future:Lcom/google/common/util/concurrent/ListenableFuture;

    .line 11
    .line 12
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v1, v0}, LX/2M4;->resumeWith(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 20
    :catch_0
    move-exception v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;->$result:LX/DT0;

    .line 22
    .line 23
    invoke-static {v1, v0}, LX/EYw;->A1K(Ljava/lang/Throwable;LX/2M4;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method
