.class public abstract Lcom/facebook/aura/activation/ageverification/CameraProviderKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final awaitCameraProvider(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "LX/F7T;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p1}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {p0}, LX/F7T;->A00(Landroid/content/Context;)LX/F2c;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    new-instance v1, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;

    .line 9
    .line 10
    invoke-direct {v1, v3, v2}, Lcom/facebook/aura/activation/ageverification/CameraProviderKt$awaitCameraProvider$2$1;-><init>(LX/DT0;Lcom/google/common/util/concurrent/ListenableFuture;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v2, v1, v0}, LX/F2a;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v3}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method
