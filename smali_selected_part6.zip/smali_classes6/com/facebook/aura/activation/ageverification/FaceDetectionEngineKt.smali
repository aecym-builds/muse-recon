.class public abstract Lcom/facebook/aura/activation/ageverification/FaceDetectionEngineKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final BUNDLED_ENGINE_CLASS:Ljava/lang/String; = "com.google.mlkit.vision.face.bundled.internal.ThickFaceDetectorCreator"

.field public static final FACE_DETECTOR_OPTIONS:LX/FMC;

.field public static final TAG:Ljava/lang/String; = "FaceDetectionEngine"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, LX/FMC;

    .line 1
    .line 2
    invoke-direct {v0}, LX/FMC;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngineKt;->FACE_DETECTOR_OPTIONS:LX/FMC;

    .line 6
    .line 7
    return-void
.end method

.method public static final getFACE_DETECTOR_OPTIONS()LX/FMC;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngineKt;->FACE_DETECTOR_OPTIONS:LX/FMC;

    .line 1
    .line 2
    return-object v0
.end method
