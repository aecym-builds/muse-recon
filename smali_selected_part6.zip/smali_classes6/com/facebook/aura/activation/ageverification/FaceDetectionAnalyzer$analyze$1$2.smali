.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Float;",
        "Lcom/facebook/aura/activation/ageverification/FaceSnapshot;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $faces:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/FM7;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $handedOff:LX/0Rg;

.field public final synthetic $image:LX/FBz;


# direct methods
.method public constructor <init>(Ljava/util/List;LX/FBz;LX/0Rg;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LX/FM7;",
            ">;",
            "LX/FBz;",
            "LX/0Rg;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$faces:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$image:LX/FBz;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$handedOff:LX/0Rg;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(F)Lcom/facebook/aura/activation/ageverification/FaceSnapshot;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$faces:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    invoke-static {v0}, LX/B89;->A0Y(Ljava/util/List;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LX/FM7;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$image:LX/FBz;

    .line 14
    .line 15
    iget-object v0, v0, LX/FM7;->A03:Landroid/graphics/Rect;

    .line 16
    .line 17
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v1, v0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieSnapshotKt;->faceSnapshot(LX/FBz;Landroid/graphics/Rect;F)Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    if-eqz v2, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->$handedOff:LX/0Rg;

    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    iput-boolean v0, v1, LX/0Rg;->element:Z

    .line 30
    .line 31
    return-object v2

    .line 32
    :cond_0
    const/4 v2, 0x0

    .line 33
    return-object v2
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A04(Ljava/lang/Object;)F

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionAnalyzer$analyze$1$2;->invoke(F)Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    return-object v0
.end method
