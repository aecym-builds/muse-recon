.class public final Lcom/facebook/aura/analytics/AnalyticsUploadHold$hold$expiry$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $owner:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/AnalyticsUploadHold$hold$expiry$1;->$owner:Ljava/lang/Object;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/AnalyticsUploadHold;->INSTANCE:Lcom/facebook/aura/analytics/AnalyticsUploadHold;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/analytics/AnalyticsUploadHold$hold$expiry$1;->$owner:Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {v1, v0, p0}, Lcom/facebook/aura/analytics/AnalyticsUploadHold;->access$expire(Lcom/facebook/aura/analytics/AnalyticsUploadHold;Ljava/lang/Object;Ljava/lang/Runnable;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
