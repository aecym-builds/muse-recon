.class public final Lcom/facebook/aura/analytics/hatch/HatchSessionId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchSessionId;

.field public static final fallback:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchSessionId;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSessionId;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchSessionId;

    .line 6
    .line 7
    invoke-static {}, LX/EYt;->A0k()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchSessionId;->fallback:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;->getExistingInstance()Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    instance-of v0, p0, LX/H3L;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->provideSessionId()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSessionId;->fallback:Ljava/lang/String;

    .line 20
    .line 21
    return-object v0
.end method
