.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

.field public static final KEY_APP_MANAGER_ENTRY_CONTEXT_READ:Ljava/lang/String; = "hatch_install_referrer_app_manager_entry_context_read"

.field public static final KEY_ERROR_COMMITTED:Ljava/lang/String; = "hatch_install_referrer_error_committed"

.field public static final KEY_PROCESSED:Ljava/lang/String; = "hatch_install_referrer_processed"

.field public static final OXYGEN_INSTALLER_PACKAGES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLAY_STORE_PACKAGE:Ljava/lang/String; = "com.android.vending"

.field public static final TAG:Ljava/lang/String; = "HatchInstallReferrerLogger"

.field public static final appManagerEntryContextReadStarted:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    const-string v3, "com.facebook.appmanager"

    .line 9
    .line 10
    const-string v2, "com.facebook.appmanager.dev"

    .line 11
    .line 12
    const-string v1, "com.facebook.system"

    .line 13
    .line 14
    const-string v0, "com.facebook.system.dev"

    .line 15
    .line 16
    filled-new-array {v3, v2, v1, v0}, [Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->OXYGEN_INSTALLER_PACKAGES:Ljava/util/Set;

    .line 25
    .line 26
    invoke-static {v4}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->appManagerEntryContextReadStarted:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 31
    .line 32
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$buildAppManagerReferrer(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;LX/I22;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->buildAppManagerReferrer(LX/I22;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$endConnectionSafely(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;LX/HfZ;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->endConnectionSafely(LX/HfZ;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$isInstallReferrerProcessed(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)Z
    .locals 1

    .line 0
    const-string v0, "hatch_install_referrer_processed"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->readFlag(Ljava/lang/String;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public static final synthetic access$log(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->log(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logInstall(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logInstall(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logResolvedInstall(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logResolvedInstall(Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$markProcessed(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->markProcessed(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$maybeCaptureAppManagerEntryContext(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->maybeCaptureAppManagerEntryContext(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$onReferrerResponseOk(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;LX/HfZ;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->onReferrerResponseOk(Landroid/content/Context;LX/HfZ;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final buildAppManagerReferrer(LX/I22;)Ljava/lang/String;
    .locals 3

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    :try_start_0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 5
    .line 6
    iget-object v0, p1, LX/I22;->A06:LX/IAX;

    .line 7
    .line 8
    invoke-virtual {v2, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->utmParams(LX/IAX;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0, p0}, LX/12R;->A09(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 13
    .line 14
    .line 15
    const-string v1, "installation_method_type"

    .line 16
    .line 17
    iget-object v0, p1, LX/I22;->A07:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    :cond_0
    const-string v1, "installation_uuid"

    .line 29
    .line 30
    iget-object v0, p1, LX/I22;->A01:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    :catch_0
    move-exception v0

    .line 43
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    :cond_1
    :goto_0
    const-string v0, "&"

    .line 47
    .line 48
    invoke-static {v0, p0}, LX/602;->A0e(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method private final endConnectionSafely(LX/HfZ;)V
    .locals 2

    .line 0
    :try_start_0
    check-cast p1, LX/HfG;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    iput v0, p1, LX/HfG;->A00:I

    .line 4
    .line 5
    iget-object v0, p1, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const-string v0, "Unbinding from service."

    .line 11
    .line 12
    invoke-static {v0}, LX/HfM;->A00(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p1, LX/HfG;->A03:Landroid/content/Context;

    .line 16
    .line 17
    iget-object v0, p1, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    .line 20
    .line 21
    .line 22
    iput-object p0, p1, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 23
    .line 24
    :cond_0
    iput-object p0, p1, LX/HfG;->A02:Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService;

    .line 25
    .line 26
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    :catch_0
    move-exception v0

    .line 28
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method private final getPrefs()LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->INSTALL_REFERRER:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method private final getSignOutClearedPrefs()LX/BVu;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final isInstallReferrerErrorCommitted(Landroid/content/Context;)Z
    .locals 1

    .line 0
    const-string v0, "hatch_install_referrer_error_committed"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->readFlag(Ljava/lang/String;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method private final isInstallReferrerProcessed(Landroid/content/Context;)Z
    .locals 1

    .line 0
    const-string v0, "hatch_install_referrer_processed"

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->readFlag(Ljava/lang/String;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method private final log(Landroid/content/Context;)V
    .locals 18

    .line 0
    const-string v5, "HatchInstallReferrerLogger"

    .line 1
    .line 2
    const/4 v15, 0x0

    .line 3
    move-object/from16 v4, p0

    .line 4
    .line 5
    move-object/from16 v3, p1

    .line 6
    .line 7
    if-eqz p1, :cond_8

    .line 8
    .line 9
    :try_start_0
    new-instance v7, LX/HfG;

    .line 10
    .line 11
    invoke-direct {v7, v3}, LX/HfG;-><init>(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 12
    .line 13
    .line 14
    const/4 v6, 0x0

    .line 15
    invoke-static {v6}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 16
    .line 17
    .line 18
    move-result-object v8

    .line 19
    :try_start_1
    new-instance v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;

    .line 20
    .line 21
    invoke-direct {v2, v8, v3, v7}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroid/content/Context;LX/HfZ;)V

    .line 22
    .line 23
    .line 24
    iget v12, v7, LX/HfG;->A00:I

    .line 25
    .line 26
    const/4 v0, 0x2

    .line 27
    if-ne v12, v0, :cond_0

    .line 28
    .line 29
    iget-object v0, v7, LX/HfG;->A02:Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService;

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    iget-object v1, v7, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 34
    .line 35
    const/4 v0, 0x1

    .line 36
    if-nez v1, :cond_1

    .line 37
    .line 38
    :cond_0
    const/4 v0, 0x0

    .line 39
    :cond_1
    const-string v9, "InstallReferrerClient"

    .line 40
    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    const-string v0, "Service connection is valid. No need to re-initialize."

    .line 44
    .line 45
    invoke-static {v0}, LX/HfM;->A00(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2, v6}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->onInstallReferrerSetupFinished(I)V

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    :cond_2
    const/4 v11, 0x3

    .line 53
    const/4 v10, 0x1

    .line 54
    if-ne v12, v11, :cond_3

    .line 55
    .line 56
    const-string v0, "Client was already closed and can\'t be reused. Please create another instance."

    .line 57
    .line 58
    invoke-static {v9, v0}, LX/EYu;->A1M(Ljava/lang/String;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    goto/16 :goto_0

    .line 62
    .line 63
    :cond_3
    const-string v0, "Starting install referrer service setup."

    .line 64
    .line 65
    invoke-static {v0}, LX/HfM;->A00(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    new-instance v0, LX/Hf4;

    .line 69
    .line 70
    invoke-direct {v0, v7, v2}, LX/Hf4;-><init>(LX/HfG;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;)V

    .line 71
    .line 72
    .line 73
    iput-object v0, v7, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 74
    .line 75
    const-string v0, "com.google.android.finsky.BIND_GET_INSTALL_REFERRER_SERVICE"

    .line 76
    .line 77
    invoke-static {v0}, LX/EYt;->A0C(Ljava/lang/String;)Landroid/content/Intent;

    .line 78
    .line 79
    .line 80
    move-result-object v13

    .line 81
    const-string v1, "com.google.android.finsky.externalreferrer.GetInstallReferrerService"

    .line 82
    .line 83
    const-string v14, "com.android.vending"

    .line 84
    .line 85
    new-instance v0, Landroid/content/ComponentName;

    .line 86
    .line 87
    invoke-direct {v0, v14, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v13, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 91
    .line 92
    .line 93
    iget-object v12, v7, LX/HfG;->A03:Landroid/content/Context;

    .line 94
    .line 95
    invoke-virtual {v12}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-virtual {v0, v13, v6}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    const/4 v11, 0x2

    .line 104
    if-eqz v1, :cond_5

    .line 105
    .line 106
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-nez v0, :cond_5

    .line 111
    .line 112
    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    check-cast v0, Landroid/content/pm/ResolveInfo;

    .line 117
    .line 118
    iget-object v1, v0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    .line 119
    .line 120
    if-eqz v1, :cond_5

    .line 121
    .line 122
    iget-object v0, v1, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 123
    .line 124
    iget-object v1, v1, Landroid/content/pm/PackageItemInfo;->name:Ljava/lang/String;

    .line 125
    .line 126
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    if-eqz v0, :cond_6

    .line 131
    .line 132
    if-eqz v1, :cond_6

    .line 133
    .line 134
    invoke-virtual {v12}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 135
    .line 136
    .line 137
    move-result-object v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 138
    :try_start_2
    const/16 v0, 0x80

    .line 139
    .line 140
    invoke-virtual {v1, v14, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    iget v1, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 145
    .line 146
    const v0, 0x4d17ab4

    .line 147
    .line 148
    .line 149
    if-lt v1, v0, :cond_6
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 150
    .line 151
    :try_start_3
    new-instance v1, Landroid/content/Intent;

    .line 152
    .line 153
    invoke-direct {v1, v13}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    .line 154
    .line 155
    .line 156
    iget-object v0, v7, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 157
    .line 158
    invoke-virtual {v12, v1, v0, v10}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    if-eqz v0, :cond_4

    .line 163
    .line 164
    const-string v0, "Service was bonded successfully."

    .line 165
    .line 166
    invoke-static {v0}, LX/HfM;->A00(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    return-void

    .line 170
    :cond_4
    const-string v0, "Connection to service is blocked."

    .line 171
    .line 172
    invoke-static {v9, v0}, LX/EYu;->A1M(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    iput v6, v7, LX/HfG;->A00:I

    .line 176
    .line 177
    invoke-virtual {v2, v10}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->onInstallReferrerSetupFinished(I)V

    .line 178
    .line 179
    .line 180
    return-void

    .line 181
    :cond_5
    iput v6, v7, LX/HfG;->A00:I

    .line 182
    .line 183
    const-string v0, "Install Referrer service unavailable on device."

    .line 184
    .line 185
    invoke-static {v0}, LX/HfM;->A00(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    goto :goto_0

    .line 189
    :catch_0
    :cond_6
    const-string v0, "Play Store missing or incompatible. Version 8.3.73 or later required."

    .line 190
    .line 191
    invoke-static {v9, v0}, LX/EYu;->A1M(Ljava/lang/String;Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    iput v6, v7, LX/HfG;->A00:I

    .line 195
    .line 196
    :goto_0
    invoke-virtual {v2, v11}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->onInstallReferrerSetupFinished(I)V

    .line 197
    .line 198
    .line 199
    return-void
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 200
    :catch_1
    move-exception v2

    .line 201
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    const-string/jumbo v0, "startConnection failed: "

    .line 206
    .line 207
    .line 208
    invoke-static {v0, v1, v5, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 209
    .line 210
    .line 211
    const/4 v0, 0x1

    .line 212
    invoke-virtual {v8, v6, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    if-eqz v0, :cond_7

    .line 217
    .line 218
    invoke-direct {v4, v7}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->endConnectionSafely(LX/HfZ;)V

    .line 219
    .line 220
    .line 221
    const-string p0, "START_CONNECTION_FAILED"

    .line 222
    .line 223
    new-instance v14, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 224
    .line 225
    move-object/from16 v16, v15

    .line 226
    .line 227
    move-object/from16 v17, v15

    .line 228
    .line 229
    move/from16 p1, v6

    .line 230
    .line 231
    invoke-direct/range {v14 .. v19}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 232
    .line 233
    .line 234
    invoke-direct {v4, v3, v14}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logResolvedInstall(Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 235
    .line 236
    .line 237
    :cond_7
    return-void

    .line 238
    :cond_8
    :try_start_4
    const-string v0, "Please provide a valid Context."

    .line 239
    .line 240
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 245
    :catch_2
    move-exception v2

    .line 246
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v1

    .line 250
    const-string v0, "Failed to build Google Play referrer client: "

    .line 251
    .line 252
    invoke-static {v0, v1, v5, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 253
    .line 254
    .line 255
    const-string p0, "START_CONNECTION_FAILED"

    .line 256
    .line 257
    const/16 p1, 0x0

    .line 258
    .line 259
    new-instance v14, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 260
    .line 261
    move-object/from16 v16, v15

    .line 262
    .line 263
    move-object/from16 v17, v15

    .line 264
    .line 265
    invoke-direct/range {v14 .. v19}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 266
    .line 267
    .line 268
    invoke-direct {v4, v3, v14}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logResolvedInstall(Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 269
    .line 270
    .line 271
    return-void
.end method

.method private final logInstall(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;)V
    .locals 4

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    sget-object v1, LX/EXf;->A02:LX/EXf;

    .line 7
    .line 8
    const-string v0, "hatch_install_events"

    .line 9
    .line 10
    invoke-interface {v2, v0, v1}, LX/ES4;->acquireEvent(Ljava/lang/String;Ljava/lang/Object;)LX/I2T;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v0, "hatch_install_referrer_error_committed"

    .line 15
    .line 16
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->readFlag(Ljava/lang/String;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    if-nez p5, :cond_2

    .line 23
    .line 24
    :cond_0
    invoke-interface {v2}, LX/I2T;->isSampled()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-static {}, LX/EYt;->A0j()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->parseUtmParams(Ljava/lang/String;)[Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    const-string v0, "app_scoped_device_id"

    .line 39
    .line 40
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    const-string v0, "family_device_id"

    .line 44
    .line 45
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    const-string v0, "referrer"

    .line 49
    .line 50
    invoke-interface {v2, v0, p2}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const-string v0, "error"

    .line 54
    .line 55
    invoke-interface {v2, v0, p5}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    const-string v0, "referrer_click_timestamp_seconds"

    .line 59
    .line 60
    invoke-interface {v2, v0, p4}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 61
    .line 62
    .line 63
    const-string v0, "install_begin_click_timestamp_seconds"

    .line 64
    .line 65
    invoke-interface {v2, v0, p3}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 66
    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    aget-object v1, v3, v0

    .line 70
    .line 71
    const-string/jumbo v0, "utm_source"

    .line 72
    .line 73
    .line 74
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const/4 v0, 0x1

    .line 78
    aget-object v1, v3, v0

    .line 79
    .line 80
    const-string/jumbo v0, "utm_medium"

    .line 81
    .line 82
    .line 83
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    const/4 v0, 0x2

    .line 87
    aget-object v1, v3, v0

    .line 88
    .line 89
    const-string/jumbo v0, "utm_campaign"

    .line 90
    .line 91
    .line 92
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    const/4 v0, 0x3

    .line 96
    aget-object v1, v3, v0

    .line 97
    .line 98
    const-string/jumbo v0, "utm_content"

    .line 99
    .line 100
    .line 101
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    const-string v0, "installer"

    .line 105
    .line 106
    invoke-interface {v2, p6, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-interface {v2}, LX/I2T;->AQ5()V

    .line 110
    .line 111
    .line 112
    :cond_1
    if-nez p5, :cond_2

    .line 113
    .line 114
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->markProcessed(Landroid/content/Context;)V

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    :cond_2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 119
    .line 120
    invoke-direct {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->markErrorCommitted(Landroid/content/Context;)V

    .line 121
    .line 122
    .line 123
    return-void
.end method

.method public static synthetic logInstall$default(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p7, 0x2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x4

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p7, 0x8

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p7, 0x10

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    move-object p5, v1

    .line 21
    :cond_3
    and-int/lit8 v0, p7, 0x20

    .line 22
    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    move-object p6, v1

    .line 26
    :cond_4
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logInstall(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method private final logResolvedInstall(Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V
    .locals 2

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->resolveInstaller(Landroid/content/Context;)LX/Eg4;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, v1, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;-><init>(Landroid/content/Context;LX/Eg4;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->queryAppManagerReferrer(Landroid/content/Context;LX/JDM;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private final markErrorCommitted(Landroid/content/Context;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->INSTALL_REFERRER:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p0, "hatch_install_referrer_error_committed"

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-virtual {p1, p0, v0}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, LX/Df3;->apply()V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method private final markProcessed(Landroid/content/Context;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->INSTALL_REFERRER:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p0, "hatch_install_referrer_processed"

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-virtual {p1, p0, v0}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, LX/Df3;->apply()V

    .line 19
    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->clear()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final maybeCaptureAppManagerEntryContext(Landroid/content/Context;)V
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->appManagerEntryContextReadStarted:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    const/4 v4, 0x1

    .line 4
    invoke-virtual {v0, p0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    sget-object v3, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 11
    .line 12
    sget-object v2, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->INSTALL_REFERRER:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 13
    .line 14
    invoke-virtual {v3, v2}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const-string v1, "hatch_install_referrer_app_manager_entry_context_read"

    .line 19
    .line 20
    invoke-interface {v0, v1, p0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    invoke-virtual {v3, v2}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v0, v1, v4}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0}, LX/Df3;->A09()Z

    .line 38
    .line 39
    .line 40
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$1;

    .line 45
    .line 46
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$1;-><init>()V

    .line 47
    .line 48
    .line 49
    new-instance v4, LX/I8n;

    .line 50
    .line 51
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-nez v0, :cond_1

    .line 63
    .line 64
    new-instance v1, LX/HfQ;

    .line 65
    .line 66
    invoke-direct {v1}, LX/HfQ;-><init>()V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    if-nez v0, :cond_0

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    goto :goto_0

    .line 77
    :cond_0
    new-instance v3, LX/Hfa;

    .line 78
    .line 79
    invoke-direct {v3, p1, v0}, LX/Hfa;-><init>(Landroid/content/Context;Landroid/content/pm/PackageManager;)V

    .line 80
    .line 81
    .line 82
    :goto_0
    new-instance v2, LX/Hf9;

    .line 83
    .line 84
    invoke-direct {v2, p1, v1, v4, p0}, LX/Hf9;-><init>(Landroid/content/Context;LX/HfX;LX/I8n;LX/HfV;)V

    .line 85
    .line 86
    .line 87
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$2;

    .line 88
    .line 89
    invoke-direct {v1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$2;-><init>()V

    .line 90
    .line 91
    .line 92
    sget-object v0, LX/FkO;->A01:Ljava/lang/Integer;

    .line 93
    .line 94
    invoke-static {v1, v2, v3, v0}, LX/Hf8;->A00(LX/HfO;LX/Hf9;LX/Hfa;Ljava/lang/Integer;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_1
    sget-object v2, Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;->INTERNAL_UNRECOVERABLE:Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;

    .line 99
    .line 100
    const-string v1, "packageName cannot be empty"

    .line 101
    .line 102
    new-instance v0, Lcom/facebook/oxygen/sdk/app/installapi/contract/OxInstallSdkException;

    .line 103
    .line 104
    invoke-direct {v0, v2, v1}, Lcom/facebook/oxygen/sdk/app/installapi/contract/OxInstallSdkException;-><init>(Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    throw v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 108
    :catch_0
    move-exception v0

    .line 109
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    :cond_2
    return-void
.end method

.method private final onReferrerResponseOk(Landroid/content/Context;LX/HfZ;)V
    .locals 10

    .line 0
    const-string v3, "HatchInstallReferrerLogger"

    .line 1
    .line 2
    const-string v2, "Failed to read Google Play referrer: "

    .line 3
    .line 4
    :try_start_0
    move-object v5, p2

    .line 5
    check-cast v5, LX/HfG;

    .line 6
    .line 7
    iget v1, v5, LX/HfG;->A00:I

    .line 8
    .line 9
    const/4 v0, 0x2

    .line 10
    if-ne v1, v0, :cond_2

    .line 11
    .line 12
    iget-object v0, v5, LX/HfG;->A02:Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService;

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object v0, v5, LX/HfG;->A01:Landroid/content/ServiceConnection;

    .line 17
    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-static {}, LX/001;->A0O()Landroid/os/Bundle;

    .line 21
    .line 22
    .line 23
    move-result-object v8

    .line 24
    iget-object v0, v5, LX/HfG;->A03:Landroid/content/Context;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const-string v0, "package_name"

    .line 31
    .line 32
    invoke-virtual {v8, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 33
    .line 34
    .line 35
    :try_start_1
    iget-object v4, v5, LX/HfG;->A02:Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService;

    .line 36
    .line 37
    check-cast v4, Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService$Stub$Proxy;

    .line 38
    .line 39
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 44
    .line 45
    .line 46
    move-result-object v6
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 47
    :try_start_2
    const-string v0, "com.google.android.finsky.externalreferrer.IGetInstallReferrerService"

    .line 48
    .line 49
    invoke-virtual {v7, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    const/4 v1, 0x1

    .line 53
    const/4 v9, 0x0

    .line 54
    invoke-virtual {v7, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v8, v7, v9}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    .line 58
    .line 59
    .line 60
    iget-object v0, v4, Lcom/google/android/finsky/externalreferrer/IGetInstallReferrerService$Stub$Proxy;->A00:Landroid/os/IBinder;

    .line 61
    .line 62
    invoke-interface {v0, v1, v7, v6, v9}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 63
    .line 64
    .line 65
    invoke-virtual {v6}, Landroid/os/Parcel;->readException()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v6}, Landroid/os/Parcel;->readInt()I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 75
    .line 76
    invoke-interface {v0, v6}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    check-cast v4, Landroid/os/Bundle;

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_0
    const/4 v4, 0x0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 84
    :goto_0
    :try_start_3
    invoke-virtual {v6}, Landroid/os/Parcel;->recycle()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v7}, Landroid/os/Parcel;->recycle()V
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 88
    .line 89
    .line 90
    :try_start_4
    const-string v0, "install_referrer"

    .line 91
    .line 92
    invoke-virtual {v4, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    const-string v0, "install_begin_timestamp_seconds"

    .line 97
    .line 98
    invoke-virtual {v4, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 99
    .line 100
    .line 101
    move-result-wide v0

    .line 102
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    const-string v0, "referrer_click_timestamp_seconds"

    .line 107
    .line 108
    invoke-virtual {v4, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 109
    .line 110
    .line 111
    move-result-wide v0

    .line 112
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 113
    .line 114
    .line 115
    move-result-object v7

    .line 116
    if-eqz v5, :cond_1

    .line 117
    .line 118
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_1

    .line 123
    .line 124
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

    .line 125
    .line 126
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 127
    .line 128
    .line 129
    move-result-wide v0

    .line 130
    invoke-virtual {v4, v5, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromReferrer(Ljava/lang/String;J)V

    .line 131
    .line 132
    .line 133
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;

    .line 134
    .line 135
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 136
    .line 137
    .line 138
    move-result-wide v0

    .line 139
    invoke-virtual {v4, v5, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->captureFromReferrer(Ljava/lang/String;J)V

    .line 140
    .line 141
    .line 142
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;

    .line 143
    .line 144
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 145
    .line 146
    const-string v0, "entry_context_token"

    .line 147
    .line 148
    invoke-virtual {v4, v5, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->without(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    const-string v0, "invite_code"

    .line 153
    .line 154
    invoke-virtual {v4, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->without(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v5

    .line 158
    const/4 v8, 0x0

    .line 159
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 160
    .line 161
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 162
    .line 163
    .line 164
    goto :goto_2
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 165
    :catchall_0
    :try_start_5
    move-exception v0

    .line 166
    invoke-virtual {v6}, Landroid/os/Parcel;->recycle()V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v7}, Landroid/os/Parcel;->recycle()V

    .line 170
    .line 171
    .line 172
    throw v0
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_5 .. :try_end_5} :catch_0
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 173
    :cond_2
    :try_start_6
    const-string v0, "Service not connected. Please start a connection before using the service."

    .line 174
    .line 175
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 176
    .line 177
    .line 178
    move-result-object v4

    .line 179
    goto :goto_1

    .line 180
    :catch_0
    move-exception v4

    .line 181
    const-string v1, "InstallReferrerClient"

    .line 182
    .line 183
    const-string v0, "RemoteException getting install referrer information"

    .line 184
    .line 185
    invoke-static {v1, v0}, LX/EYu;->A1M(Ljava/lang/String;Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    const/4 v0, 0x0

    .line 189
    iput v0, v5, LX/HfG;->A00:I

    .line 190
    .line 191
    :goto_1
    throw v4
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 192
    :catch_1
    move-exception v1

    .line 193
    :try_start_7
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-static {v2, v0, v3, v1}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 198
    .line 199
    .line 200
    invoke-static {v1}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v8

    .line 204
    const/4 v5, 0x0

    .line 205
    const/4 v9, 0x1

    .line 206
    new-instance v4, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 207
    .line 208
    move-object v6, v5

    .line 209
    move-object v7, v5

    .line 210
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 211
    .line 212
    .line 213
    :goto_2
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->endConnectionSafely(LX/HfZ;)V

    .line 214
    .line 215
    .line 216
    invoke-direct {p0, p1, v4}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logResolvedInstall(Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 217
    .line 218
    .line 219
    return-void

    .line 220
    :catchall_1
    move-exception v0

    .line 221
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->endConnectionSafely(LX/HfZ;)V

    .line 222
    .line 223
    .line 224
    throw v0
.end method

.method private final parseUtmParams(Ljava/lang/String;)[Ljava/lang/String;
    .locals 8

    .line 0
    const/4 v1, 0x4

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    const/4 v6, 0x1

    .line 10
    const-string v0, "&"

    .line 11
    .line 12
    const/4 v5, 0x0

    .line 13
    invoke-static {p1, v0}, LX/AdT;->A0h(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {v1}, LX/0BR;->A00(Ljava/lang/Iterable;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 22
    .line 23
    invoke-direct {v4, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 24
    .line 25
    .line 26
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    const/4 v2, 0x2

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    check-cast v1, Ljava/lang/String;

    .line 42
    .line 43
    const-string v0, "="

    .line 44
    .line 45
    filled-new-array {v0}, [Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v1, v0, v2}, LX/AdT;->A0k(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-interface {p0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    if-ne v0, v2, :cond_0

    .line 62
    .line 63
    :try_start_0
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    check-cast v1, Ljava/lang/String;

    .line 68
    .line 69
    const-string v0, "UTF-8"

    .line 70
    .line 71
    invoke-static {v1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 76
    :cond_0
    const-string v0, ""

    .line 77
    .line 78
    new-instance v2, LX/IBK;

    .line 79
    .line 80
    invoke-direct {v2, v7, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    goto :goto_2

    .line 84
    :catch_0
    move-exception v3

    .line 85
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    const-string v1, "HatchInstallReferrerLogger"

    .line 94
    .line 95
    const-string v0, "Failed to URL-decode referrer param: %s"

    .line 96
    .line 97
    invoke-static {v1, v0, v3, v2}, LX/FnY;->A0D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    :goto_1
    new-instance v2, LX/IBK;

    .line 105
    .line 106
    invoke-direct {v2, v7, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    :goto_2
    iget-object v1, v2, LX/IBK;->first:Ljava/lang/Object;

    .line 110
    .line 111
    iget-object v0, v2, LX/IBK;->second:Ljava/lang/Object;

    .line 112
    .line 113
    invoke-virtual {v4, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_1
    const-string/jumbo v0, "utm_source"

    .line 118
    .line 119
    .line 120
    invoke-static {v0, v4}, LX/EYt;->A0m(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    const-string/jumbo v0, "utm_medium"

    .line 125
    .line 126
    .line 127
    invoke-static {v0, v4}, LX/EYt;->A0m(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v2

    .line 131
    const-string/jumbo v0, "utm_campaign"

    .line 132
    .line 133
    .line 134
    invoke-static {v0, v4}, LX/EYt;->A0m(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    const-string/jumbo v0, "utm_content"

    .line 139
    .line 140
    .line 141
    invoke-static {v0, v4}, LX/EYt;->A0m(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    filled-new-array {v3, v2, v1, v0}, [Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    return-object v0

    .line 150
    :cond_2
    new-array v0, v1, [Ljava/lang/String;

    .line 151
    .line 152
    return-object v0
.end method

.method private final queryAppManagerReferrer(Landroid/content/Context;LX/JDM;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/8mk;->A0s()Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    new-instance v5, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$deliver$1;

    .line 5
    .line 6
    invoke-direct {v5, v0, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$deliver$1;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;LX/JDM;)V

    .line 7
    .line 8
    .line 9
    const/4 v6, 0x0

    .line 10
    :try_start_0
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$1;

    .line 11
    .line 12
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$1;-><init>()V

    .line 13
    .line 14
    .line 15
    new-instance v4, LX/I8n;

    .line 16
    .line 17
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    new-instance v1, LX/HfQ;

    .line 31
    .line 32
    invoke-direct {v1}, LX/HfQ;-><init>()V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v0, :cond_0

    .line 40
    .line 41
    const/4 v3, 0x0

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    new-instance v3, LX/Hfa;

    .line 44
    .line 45
    invoke-direct {v3, p1, v0}, LX/Hfa;-><init>(Landroid/content/Context;Landroid/content/pm/PackageManager;)V

    .line 46
    .line 47
    .line 48
    :goto_0
    new-instance v2, LX/Hf9;

    .line 49
    .line 50
    invoke-direct {v2, p1, v1, v4, p0}, LX/Hf9;-><init>(Landroid/content/Context;LX/HfX;LX/I8n;LX/HfV;)V

    .line 51
    .line 52
    .line 53
    new-instance v1, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;

    .line 54
    .line 55
    invoke-direct {v1, v5}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;-><init>(LX/JDM;)V

    .line 56
    .line 57
    .line 58
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 59
    .line 60
    invoke-static {v1, v2, v3, v0}, LX/Hf8;->A00(LX/HfO;LX/Hf9;LX/Hfa;Ljava/lang/Integer;)V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :cond_1
    sget-object v2, Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;->INTERNAL_UNRECOVERABLE:Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;

    .line 65
    .line 66
    const-string v1, "packageName cannot be empty"

    .line 67
    .line 68
    new-instance v0, Lcom/facebook/oxygen/sdk/app/installapi/contract/OxInstallSdkException;

    .line 69
    .line 70
    invoke-direct {v0, v2, v1}, Lcom/facebook/oxygen/sdk/app/installapi/contract/OxInstallSdkException;-><init>(Lcom/facebook/oxygen/sdk/app/installapi/contract/common/ErrorType;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    throw v0
    :try_end_0
    .catch Lcom/facebook/oxygen/sdk/app/installapi/contract/OxInstallSdkException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 74
    :catch_0
    move-exception v0

    .line 75
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v5, v6}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$deliver$1;->invoke(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    return-void
.end method

.method private final readFlag(Ljava/lang/String;)Z
    .locals 3

    .line 0
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->INSTALL_REFERRER:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-interface {p0, p1, v2}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x1

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-interface {v0, p1, v2}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    return v2

    .line 27
    :cond_0
    invoke-interface {p0}, LX/BVu;->A9u()LX/Df3;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0, p1, v1}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0}, LX/Df3;->apply()V

    .line 35
    .line 36
    .line 37
    :cond_1
    return v1
.end method

.method private final resolveInstaller(Landroid/content/Context;)LX/Eg4;
    .locals 3

    .line 0
    const/4 p0, 0x0

    .line 1
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v0, 0x1e

    .line 8
    .line 9
    if-lt v1, v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v2, v0}, Landroid/content/pm/PackageManager;->getInstallSourceInfo(Ljava/lang/String;)Landroid/content/pm/InstallSourceInfo;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0}, Landroid/content/pm/InstallSourceInfo;->getInstallingPackageName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    :goto_0
    const-string v0, "com.android.vending"

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    sget-object v0, LX/Eg4;->A01:LX/Eg4;

    .line 32
    .line 33
    return-object v0

    .line 34
    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v2, v0}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->OXYGEN_INSTALLER_PACKAGES:Ljava/util/Set;

    .line 44
    .line 45
    invoke-static {v0, v1}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_2

    .line 50
    .line 51
    sget-object v0, LX/Eg4;->A02:LX/Eg4;

    .line 52
    .line 53
    return-object v0

    .line 54
    :cond_2
    return-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 55
    :catch_0
    move-exception v0

    .line 56
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    return-object p0
.end method


# virtual methods
.method public final maybeLog(Landroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->backgroundThreadExecutor$delegate:Lkotlin/Lazy;

    .line 5
    .line 6
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;-><init>(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
