.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final APP_MANAGER_SENTINEL_PREFIX:Ljava/lang/String; = "appmanager_"

.field public static final HAS_CUSTOM_DATA_PARAM:Ljava/lang/String; = "has_custom_data"

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

.field public static final TAG:Ljava/lang/String; = "HatchInstallReferrerParams"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final isRealValue(Ljava/lang/String;)Z
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-lez v0, :cond_0

    .line 8
    .line 9
    const-string v0, "appmanager_"

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    :cond_0
    return p0
.end method


# virtual methods
.method public final decodedValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz p1, :cond_2

    .line 6
    .line 7
    new-array v2, v0, [C

    .line 8
    .line 9
    const/16 v1, 0x26

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    aput-char v1, v2, v0

    .line 13
    .line 14
    invoke-static {p1, v2}, LX/AdT;->A0j(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    const/16 v2, 0x3d

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    move-object v0, v1

    .line 37
    check-cast v0, Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v0, v0, v2}, LX/AdT;->A0W(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    :goto_0
    check-cast v1, Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v1, :cond_2

    .line 52
    .line 53
    const-string v0, ""

    .line 54
    .line 55
    invoke-static {v1, v0, v2}, LX/AdT;->A0U(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_2

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_1
    move-object v1, p0

    .line 63
    goto :goto_0

    .line 64
    :goto_1
    :try_start_0
    sget-object v0, LX/Fbu;->A05:Ljava/nio/charset/Charset;

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-static {v1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    invoke-static {v0}, LX/AdT;->A0K(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    :catch_0
    move-exception v3

    .line 87
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    const-string v1, "HatchInstallReferrerParams"

    .line 92
    .line 93
    const-string v0, "Rejecting malformed install referrer param: %s"

    .line 94
    .line 95
    invoke-static {v1, v0, v3, v2}, LX/FnY;->A0D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_2
    return-object p0
.end method

.method public final encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz p2, :cond_0

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 8
    .line 9
    invoke-direct {v0, p2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->isRealValue(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object v0, LX/Fbu;->A05:Ljava/nio/charset/Charset;

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {p2, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    const-string v0, "="

    .line 26
    .line 27
    invoke-static {p1, v0, p0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    :cond_0
    return-object p0
.end method

.method public final utmParams(LX/IAX;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/IAX;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string/jumbo v1, "utm_source"

    .line 5
    .line 6
    .line 7
    iget-object v0, p1, LX/IAX;->A04:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v5

    .line 13
    const-string/jumbo v1, "utm_medium"

    .line 14
    .line 15
    .line 16
    iget-object v0, p1, LX/IAX;->A03:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    const-string/jumbo v1, "utm_campaign"

    .line 23
    .line 24
    .line 25
    iget-object v0, p1, LX/IAX;->A00:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    const-string/jumbo v1, "utm_content"

    .line 32
    .line 33
    .line 34
    iget-object v0, p1, LX/IAX;->A01:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->encodedParam(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 41
    .line 42
    iget-object v0, p1, LX/IAX;->A02:Ljava/lang/String;

    .line 43
    .line 44
    invoke-direct {v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->isRealValue(Ljava/lang/String;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    const-string v0, "has_custom_data=1"

    .line 51
    .line 52
    :goto_0
    filled-new-array {v5, v4, v3, v2, v0}, [Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    return-object v0

    .line 61
    :cond_0
    const/4 v0, 0x0

    .line 62
    goto :goto_0
.end method

.method public final without(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz p1, :cond_2

    .line 6
    .line 7
    new-array v2, v0, [C

    .line 8
    .line 9
    const/16 v1, 0x26

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    aput-char v1, v2, v0

    .line 13
    .line 14
    invoke-static {p1, v2}, LX/AdT;->A0j(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    move-object v1, v2

    .line 39
    check-cast v1, Ljava/lang/String;

    .line 40
    .line 41
    const/16 v0, 0x3d

    .line 42
    .line 43
    invoke-static {v1, v1, v0}, LX/AdT;->A0W(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_0

    .line 52
    .line 53
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_1
    const-string v0, "&"

    .line 58
    .line 59
    invoke-static {v0, v4, p0}, LX/3Rq;->A1A(Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    return-object v0

    .line 64
    :cond_2
    return-object p0
.end method
