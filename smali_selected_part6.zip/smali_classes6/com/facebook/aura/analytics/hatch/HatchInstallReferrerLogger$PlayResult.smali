.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final error:Ljava/lang/String;

.field public final installBeginTimestampSeconds:Ljava/lang/Long;

.field public final referrer:Ljava/lang/String;

.field public final referrerClickTimestampSeconds:Ljava/lang/Long;

.field public final retryable:Z


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 0
    const/4 v1, 0x0

    .line 1
    const/4 v5, 0x1

    .line 2
    move-object v0, p0

    .line 3
    move-object v2, v1

    .line 4
    move-object v3, v1

    .line 5
    move-object v4, v1

    .line 6
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V
    .locals 0

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrer:Ljava/lang/String;

    .line 536870916
    .line 536870917
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->installBeginTimestampSeconds:Ljava/lang/Long;

    .line 536870918
    .line 536870919
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrerClickTimestampSeconds:Ljava/lang/Long;

    .line 536870920
    .line 536870921
    iput-object p4, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->error:Ljava/lang/String;

    .line 536870922
    .line 536870923
    iput-boolean p5, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->retryable:Z

    .line 536870924
    .line 536870925
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;ZILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p6, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 268435478
    .line 268435479
    if-eqz v0, :cond_4

    .line 268435480
    .line 268435481
    const/4 p5, 0x1

    .line 268435482
    :cond_4
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 268435483
    .line 268435484
    .line 268435485
    return-void
.end method


# virtual methods
.method public final getError()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->error:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHasAnswer()Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrer:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    :cond_0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->error:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    if-nez p0, :cond_2

    .line 14
    .line 15
    :cond_1
    const/4 v0, 0x1

    .line 16
    :cond_2
    return v0
.end method

.method public final getInstallBeginTimestampSeconds()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->installBeginTimestampSeconds:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReferrer()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrer:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReferrerClickTimestampSeconds()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrerClickTimestampSeconds:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRetryable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->retryable:Z

    .line 1
    .line 2
    return p0
.end method
