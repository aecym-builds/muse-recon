.class public abstract Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLoggerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final KEY_LAST_LOGGED_MS:Ljava/lang/String; = "last_logged_ms"

.field public static final PREFS_NAME:Ljava/lang/String; = "hatch_device_info_report"

.field public static final REPORT_INTERVAL_MS:J = 0x2932e00L


# direct methods
.method public static final synthetic access$getREPORT_INTERVAL_MS$p()J
    .locals 2

    .line 0
    sget-wide v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLoggerKt;->REPORT_INTERVAL_MS:J

    .line 1
    .line 2
    return-wide v0
.end method
