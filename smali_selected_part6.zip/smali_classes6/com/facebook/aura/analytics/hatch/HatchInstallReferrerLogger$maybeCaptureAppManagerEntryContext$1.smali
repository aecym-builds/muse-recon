.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/HfV;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public softReport(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public softReport(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    return-void
.end method

.method public softReport(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    .line 536870912
    return-void
.end method
