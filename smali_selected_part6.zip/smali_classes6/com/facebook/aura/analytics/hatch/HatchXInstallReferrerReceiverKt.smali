.class public abstract Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final isXInstallReferrerHandoffEnabled$delegate:LX/1zE;

.field public static final trustedSenders:LX/Fc4;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    const-string v2, "isXInstallReferrerHandoffEnabled"

    .line 2
    .line 3
    const-string v1, "isXInstallReferrerHandoffEnabled()Z"

    .line 4
    .line 5
    const-class v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;

    .line 6
    .line 7
    invoke-static {v0, v2, v1, v3}, LX/602;->A1a(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)[LX/Dqa;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->$$delegatedProperties:[LX/Dqa;

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/analytics/hatch/MC$hatch_android_sessionless;->enable_x_install_referrer_handoff:LX/0d8;

    .line 14
    .line 15
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->isXInstallReferrerHandoffEnabled$delegate:LX/1zE;

    .line 20
    .line 21
    sget-object v1, LX/JaU;->A0p:Ljava/util/Set;

    .line 22
    .line 23
    sget-object v0, LX/I5i;->A00:Ljava/util/Set;

    .line 24
    .line 25
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_0

    .line 42
    .line 43
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v3, v0, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    new-instance v0, LX/Fc4;

    .line 56
    .line 57
    invoke-direct {v0, v1}, LX/Fc4;-><init>(Ljava/util/Map;)V

    .line 58
    .line 59
    .line 60
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->trustedSenders:LX/Fc4;

    .line 61
    .line 62
    return-void
.end method

.method public static final synthetic access$getTrustedSenders$p()LX/Fc4;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->trustedSenders:LX/Fc4;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$isXInstallReferrerHandoffEnabled()Z
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->isXInstallReferrerHandoffEnabled()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    return v0
.end method

.method public static final isXInstallReferrerHandoffEnabled()Z
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->isXInstallReferrerHandoffEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-static {v2, v1, v0}, LX/3Rs;->A1U(LX/1zE;[LX/Dqa;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method
