.class public final Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final ENTRY_CONTEXT_TOKEN_PARAM:Ljava/lang/String; = "entry_context_token"

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

.field public static final KEY_ATTEMPTS:Ljava/lang/String; = "hatch_deferred_deeplink_attempts"

.field public static final KEY_CAPTURED_AT_MS:Ljava/lang/String; = "hatch_deferred_deeplink_captured_at_ms"

.field public static final KEY_TOKEN:Ljava/lang/String; = "hatch_deferred_deeplink_token"

.field public static final MAX_ATTEMPTS:I = 0x3

.field public static final MAX_TOKEN_BYTES:I = 0x1000

.field public static final TAG:Ljava/lang/String; = "HatchDeferredDeeplinkStore"

.field public static final TOKEN_LIFETIME_MS:J = 0x240c8400L


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic captureFromAppManagerCustomData$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;Ljava/lang/String;JILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p2

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromAppManagerCustomData(Ljava/lang/String;J)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static synthetic captureFromReferrer$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;Ljava/lang/String;JILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p2

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromReferrer(Ljava/lang/String;J)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static synthetic captureFromUri$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;Landroid/net/Uri;JILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p2

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromUri(Landroid/net/Uri;J)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method private final clearStoredHandoff()V
    .locals 1

    .line 0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "hatch_deferred_deeplink_token"

    .line 9
    .line 10
    invoke-virtual {p0, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v0, "hatch_deferred_deeplink_captured_at_ms"

    .line 14
    .line 15
    invoke-virtual {p0, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const-string v0, "hatch_deferred_deeplink_attempts"

    .line 19
    .line 20
    invoke-virtual {p0, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, LX/Df3;->A09()Z

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public static synthetic getPendingToken$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;JILjava/lang/Object;)Ljava/lang/String;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p1

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->getPendingToken(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method private final getPrefs()LX/BVu;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final storeToken(Ljava/lang/String;J)V
    .locals 1

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-static {p1}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    array-length p0, v0

    .line 13
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const/16 v0, 0x1000

    .line 20
    .line 21
    if-gt p0, v0, :cond_0

    .line 22
    .line 23
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    const-string v0, "hatch_deferred_deeplink_token"

    .line 32
    .line 33
    invoke-virtual {p0, v0, p1}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "hatch_deferred_deeplink_captured_at_ms"

    .line 37
    .line 38
    invoke-virtual {p0, v0, p2, p3}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 39
    .line 40
    .line 41
    const-string v0, "hatch_deferred_deeplink_attempts"

    .line 42
    .line 43
    invoke-virtual {p0, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0}, LX/Df3;->A09()Z

    .line 47
    .line 48
    .line 49
    :cond_0
    return-void
.end method


# virtual methods
.method public final declared-synchronized captureFromAppManagerCustomData(Ljava/lang/String;J)V
    .locals 5

    .line 0
    monitor-enter p0

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    :try_start_0
    invoke-static {p1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_3

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    new-array v2, v0, [C

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    const/16 v0, 0x26

    .line 14
    .line 15
    aput-char v0, v2, v1

    .line 16
    .line 17
    invoke-static {p1, v2}, LX/AdT;->A0j(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    :cond_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    const/16 v3, 0x3d

    .line 30
    .line 31
    const/4 v2, 0x0

    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    move-object v0, v2

    .line 39
    check-cast v0, Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v0, v0, v3}, LX/AdT;->A0W(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const-string v0, "entry_context_token"

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_0

    .line 52
    .line 53
    :cond_1
    check-cast v2, Ljava/lang/String;

    .line 54
    .line 55
    if-eqz v2, :cond_2

    .line 56
    .line 57
    const-string v0, ""

    .line 58
    .line 59
    invoke-static {v2, v0, v3}, LX/AdT;->A0U(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    if-eqz v1, :cond_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 64
    .line 65
    :try_start_1
    sget-object v0, LX/Fbu;->A05:Ljava/nio/charset/Charset;

    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-static {v1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    goto :goto_0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 76
    :catch_0
    move-exception v2

    .line 77
    :try_start_2
    const-string v1, "HatchDeferredDeeplinkStore"

    .line 78
    .line 79
    const-string v0, "Rejecting malformed App Manager entry-context token"

    .line 80
    .line 81
    invoke-static {v1, v2, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_2
    :goto_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->storeToken(Ljava/lang/String;J)V

    .line 86
    .line 87
    .line 88
    goto :goto_1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 89
    :catchall_0
    move-exception v0

    .line 90
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 91
    throw v0

    .line 92
    :cond_3
    :goto_1
    monitor-exit p0

    .line 93
    return-void
.end method

.method public final declared-synchronized captureFromReferrer(Ljava/lang/String;J)V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 2
    .line 3
    const-string v0, "entry_context_token"

    .line 4
    .line 5
    invoke-virtual {v1, p1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->decodedValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-direct {p0, v0, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->storeToken(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    .line 13
    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    throw v0
.end method

.method public final declared-synchronized captureFromUri(Landroid/net/Uri;J)V
    .locals 4

    .line 0
    monitor-enter p0

    .line 1
    const/4 v3, 0x0

    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    :try_start_0
    const-string v0, "entry_context_token"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    :catch_0
    move-exception v2

    .line 12
    :try_start_1
    const-string v1, "HatchDeferredDeeplinkStore"

    .line 13
    .line 14
    const-string v0, "Rejecting opaque entry-context deeplink"

    .line 15
    .line 16
    invoke-static {v1, v2, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    :goto_0
    invoke-direct {p0, v3, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->storeToken(Ljava/lang/String;J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    .line 21
    .line 22
    monitor-exit p0

    .line 23
    return-void

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 26
    throw v0
.end method

.method public final declared-synchronized clearIfMatches(Ljava/lang/String;)Z
    .locals 4

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v3, 0x0

    .line 2
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    const-string v1, "hatch_deferred_deeplink_token"

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-interface {v2, v1, v0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    monitor-exit p0

    .line 23
    return v3

    .line 24
    :cond_0
    :try_start_1
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->clearStoredHandoff()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 25
    .line 26
    .line 27
    monitor-exit p0

    .line 28
    const/4 v3, 0x1

    .line 29
    return v3

    .line 30
    :catchall_0
    move-exception v0

    .line 31
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 32
    throw v0
.end method

.method public final declared-synchronized getPendingToken(J)Ljava/lang/String;
    .locals 9

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 2
    .line 3
    .line 4
    move-result-object v8

    .line 5
    const-string v0, "hatch_deferred_deeplink_token"

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    invoke-interface {v8, v0, v5}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    if-eqz v4, :cond_2

    .line 13
    .line 14
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-gtz v0, :cond_0

    .line 19
    .line 20
    move-object v4, v5

    .line 21
    :cond_0
    if-eqz v4, :cond_2

    .line 22
    .line 23
    const-string v0, "hatch_deferred_deeplink_captured_at_ms"

    .line 24
    .line 25
    const-wide/16 v1, 0x0

    .line 26
    .line 27
    invoke-interface {v8, v0, v1, v2}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 28
    .line 29
    .line 30
    move-result-wide v6

    .line 31
    const-string v3, "hatch_deferred_deeplink_attempts"

    .line 32
    .line 33
    const/4 v0, 0x0

    .line 34
    invoke-interface {v8, v3, v0}, LX/BVu;->getInt(Ljava/lang/String;I)I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    cmp-long v0, v6, v1

    .line 39
    .line 40
    if-lez v0, :cond_1

    .line 41
    .line 42
    cmp-long v0, p1, v6

    .line 43
    .line 44
    if-ltz v0, :cond_1

    .line 45
    .line 46
    sub-long/2addr p1, v6

    .line 47
    const-wide/32 v1, 0x240c8400

    .line 48
    .line 49
    .line 50
    cmp-long v0, p1, v1

    .line 51
    .line 52
    if-gtz v0, :cond_1

    .line 53
    .line 54
    const/4 v0, 0x3

    .line 55
    if-ge v3, v0, :cond_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 56
    .line 57
    monitor-exit p0

    .line 58
    return-object v4

    .line 59
    :cond_1
    :try_start_1
    invoke-virtual {p0, v4}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->clearIfMatches(Ljava/lang/String;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 60
    .line 61
    .line 62
    monitor-exit p0

    .line 63
    return-object v5

    .line 64
    :cond_2
    monitor-exit p0

    .line 65
    return-object v5

    .line 66
    :catchall_0
    move-exception v0

    .line 67
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 68
    throw v0
.end method

.method public final hasEntryContextToken(Landroid/net/Uri;)Z
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    :try_start_0
    const-string v0, "entry_context_token"

    .line 4
    .line 5
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    :catch_0
    return p0

    .line 13
    :goto_0
    const/4 p0, 0x1

    .line 14
    :cond_0
    return p0
.end method

.method public final declared-synchronized recordAttemptIfMatches(Ljava/lang/String;)Z
    .locals 6

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v5, 0x0

    .line 2
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    const-string v1, "hatch_deferred_deeplink_token"

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-interface {v4, v1, v0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    const-string v3, "hatch_deferred_deeplink_attempts"

    .line 23
    .line 24
    invoke-interface {v4, v3, v5}, LX/BVu;->getInt(Ljava/lang/String;I)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    const/4 v2, 0x1

    .line 29
    add-int/lit8 v1, v0, 0x1

    .line 30
    .line 31
    const/4 v0, 0x3

    .line 32
    if-lt v1, v0, :cond_0

    .line 33
    .line 34
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->clearStoredHandoff()V

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    invoke-interface {v4}, LX/BVu;->A9u()LX/Df3;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {v0, v3, v1}, LX/Df3;->AZA(Ljava/lang/String;I)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0}, LX/Df3;->A09()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    .line 47
    .line 48
    monitor-exit p0

    .line 49
    return v2

    .line 50
    :cond_1
    :goto_0
    monitor-exit p0

    .line 51
    return v5

    .line 52
    :catchall_0
    move-exception v0

    .line 53
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 54
    throw v0
.end method

.method public final withoutEntryContextToken(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 4

    .line 0
    if-eqz p1, :cond_3

    .line 1
    .line 2
    invoke-virtual {p1}, Landroid/net/Uri;->getEncodedQuery()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    if-eqz v3, :cond_3

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    new-array v2, v0, [C

    .line 10
    .line 11
    const/16 v1, 0x26

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    aput-char v1, v2, v0

    .line 15
    .line 16
    invoke-static {v3, v2}, LX/AdT;->A0j(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    const/4 v2, 0x0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    move-object v1, v2

    .line 40
    check-cast v1, Ljava/lang/String;

    .line 41
    .line 42
    const/16 v0, 0x3d

    .line 43
    .line 44
    invoke-static {v1, v1, v0}, LX/AdT;->A0W(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v0}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const-string v0, "entry_context_token"

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_0

    .line 59
    .line 60
    invoke-virtual {p0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    const-string v0, "&"

    .line 65
    .line 66
    invoke-static {v0, p0, v2}, LX/3Rq;->A1A(Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_2

    .line 75
    .line 76
    move-object v2, v1

    .line 77
    :cond_2
    invoke-virtual {p1}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0, v2}, Landroid/net/Uri$Builder;->encodedQuery(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    :cond_3
    return-object p1
.end method

.method public final withoutEntryContextToken(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 268435456
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 268435457
    .line 268435458
    const-string v0, "entry_context_token"

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->without(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    return-object v0
.end method
