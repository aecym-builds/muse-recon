.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeCaptureAppManagerEntryContext$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/HfO;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onError(LX/Hf7;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onReferrerReceived(LX/I22;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

    .line 5
    .line 6
    iget-object v0, p1, LX/I22;->A06:LX/IAX;

    .line 7
    .line 8
    iget-object p1, v0, LX/IAX;->A02:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromAppManagerCustomData(Ljava/lang/String;J)V

    .line 15
    .line 16
    .line 17
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;

    .line 18
    .line 19
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 20
    .line 21
    .line 22
    move-result-wide v0

    .line 23
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->captureFromReferrer(Ljava/lang/String;J)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
