.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final synthetic $client:LX/HfZ;

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $responded:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroid/content/Context;LX/HfZ;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$responded:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$client:LX/HfZ;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public onInstallReferrerServiceDisconnected()V
    .locals 0

    .line 0
    return-void
.end method

.method public onInstallReferrerSetupFinished(I)V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$responded:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-static {v0}, LX/8mk;->A1a(Ljava/util/concurrent/atomic/AtomicBoolean;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->backgroundThreadExecutor$delegate:Lkotlin/Lazy;

    .line 9
    .line 10
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    iget-object v2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$context:Landroid/content/Context;

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1;->$client:LX/HfZ;

    .line 17
    .line 18
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;

    .line 19
    .line 20
    invoke-direct {v0, p1, v2, v1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;-><init>(ILandroid/content/Context;LX/HfZ;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {v3, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method
