.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $installer:LX/Eg4;

.field public final synthetic $play:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/Eg4;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$installer:LX/Eg4;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$play:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->invoke(Ljava/lang/String;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 13

    .line 0
    const/4 v3, 0x0

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_3

    .line 8
    .line 9
    move-object v2, p1

    .line 10
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 11
    .line 12
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$context:Landroid/content/Context;

    .line 13
    .line 14
    iget-object v6, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$installer:LX/Eg4;

    .line 15
    .line 16
    if-nez v6, :cond_1

    .line 17
    .line 18
    sget-object v6, LX/Eg4;->A02:LX/Eg4;

    .line 19
    .line 20
    :cond_1
    const/16 v7, 0x1c

    .line 21
    .line 22
    move-object v4, v3

    .line 23
    move-object v5, v3

    .line 24
    move-object v8, v3

    .line 25
    invoke-static/range {v0 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logInstall$default(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;ILjava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    :cond_2
    return-void

    .line 29
    :cond_3
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 30
    .line 31
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->getPendingReferrer(J)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    if-nez p1, :cond_0

    .line 40
    .line 41
    if-nez v2, :cond_0

    .line 42
    .line 43
    iget-object v2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$play:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 44
    .line 45
    invoke-virtual {v2}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->getHasAnswer()Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 50
    .line 51
    iget-object v5, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$context:Landroid/content/Context;

    .line 52
    .line 53
    if-eqz v0, :cond_5

    .line 54
    .line 55
    iget-object v1, v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrer:Ljava/lang/String;

    .line 56
    .line 57
    if-eqz v1, :cond_4

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_4

    .line 64
    .line 65
    move-object v3, v1

    .line 66
    :cond_4
    iget-object v7, v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->installBeginTimestampSeconds:Ljava/lang/Long;

    .line 67
    .line 68
    iget-object v8, v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->referrerClickTimestampSeconds:Ljava/lang/Long;

    .line 69
    .line 70
    iget-object v9, v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->error:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v10, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$installer:LX/Eg4;

    .line 73
    .line 74
    move-object v6, v3

    .line 75
    invoke-static/range {v4 .. v10}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$logInstall(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_5
    iget-object v9, v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->error:Ljava/lang/String;

    .line 80
    .line 81
    iget-object v10, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$installer:LX/Eg4;

    .line 82
    .line 83
    const/16 v11, 0xe

    .line 84
    .line 85
    move-object v6, v3

    .line 86
    move-object v7, v3

    .line 87
    move-object v8, v3

    .line 88
    move-object v12, v3

    .line 89
    invoke-static/range {v4 .. v12}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->logInstall$default(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;LX/Eg4;ILjava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$play:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 93
    .line 94
    iget-boolean v0, v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;->retryable:Z

    .line 95
    .line 96
    if-nez v0, :cond_2

    .line 97
    .line 98
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$logResolvedInstall$1;->$context:Landroid/content/Context;

    .line 99
    .line 100
    invoke-static {v4, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$markProcessed(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V

    .line 101
    .line 102
    .line 103
    return-void
.end method
