.class public final Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    const/4 p0, 0x0

    .line 1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->access$maybeLog(Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 7
    .line 8
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 16
    .line 17
    .line 18
    throw v1
.end method
