.class public final Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/lifecycle/AppBackgroundedListener;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;

.field public static final inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static volatile nextBackgroundCheckElapsedMs:J


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;

    .line 6
    .line 7
    invoke-static {}, LX/8mk;->A0s()Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getInFlight$p()Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$maybeLog(Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->maybeLog()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final logDeviceInfo()V
    .locals 4

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    const/4 v3, 0x0

    .line 7
    const-string v2, "device_info"

    .line 8
    .line 9
    sget-object v1, LX/FkO;->A00:Ljava/lang/Integer;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {p0, v1, v3, v2, v0}, LX/H4A;->A01(LX/H4A;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Z)LX/H49;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2}, LX/H49;->A0A()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    const-string v1, "os_type"

    .line 26
    .line 27
    const-string v0, "Android"

    .line 28
    .line 29
    invoke-virtual {v2, v1, v0}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const-string v1, "os_ver"

    .line 33
    .line 34
    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {v2, v1, v0}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const-string v1, "device_type"

    .line 40
    .line 41
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v2, v1, v0}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    const-string v1, "brand"

    .line 47
    .line 48
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {v2, v1, v0}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const-string v1, "manufacturer"

    .line 54
    .line 55
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 56
    .line 57
    invoke-virtual {v2, v1, v0}, LX/H49;->A09(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    const-string v3, "CpuInfoHelper"

    .line 61
    .line 62
    const/4 v1, -0x1

    .line 63
    :try_start_0
    const-string v0, "/sys/devices/system/cpu/possible"

    .line 64
    .line 65
    invoke-static {v0}, LX/Fdd;->A00(Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-ne v0, v1, :cond_0

    .line 70
    .line 71
    const-string v0, "/sys/devices/system/cpu/present"

    .line 72
    .line 73
    invoke-static {v0}, LX/Fdd;->A00(Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    :cond_0
    if-ne v0, v1, :cond_2

    .line 78
    .line 79
    const-string v0, "/sys/devices/system/cpu/"

    .line 80
    .line 81
    invoke-static {v0}, LX/EYt;->A0N(Ljava/lang/String;)Ljava/io/File;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    sget-object v0, LX/Fdd;->A00:Ljava/io/FileFilter;

    .line 86
    .line 87
    invoke-virtual {v1, v0}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    if-eqz v0, :cond_1

    .line 92
    .line 93
    array-length v0, v0

    .line 94
    goto :goto_1

    .line 95
    :cond_1
    invoke-static {}, LX/006;->A0p()Ljava/lang/IllegalStateException;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    throw v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    .line 100
    :catch_0
    move-exception v0

    .line 101
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    const-string v0, "Null pointer exception while reading CPU core information"

    .line 106
    .line 107
    goto :goto_0

    .line 108
    :catch_1
    move-exception v0

    .line 109
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    const-string v0, "Security exception while reading CPU core information"

    .line 114
    .line 115
    :goto_0
    invoke-static {v3, v0, v1}, LX/I1w;->A00(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    const/4 v0, -0x1

    .line 119
    :cond_2
    :goto_1
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    const-string v0, "reliable_core_count"

    .line 124
    .line 125
    invoke-virtual {v2, v0, v1}, LX/H49;->A08(Ljava/lang/String;Ljava/lang/Number;)V

    .line 126
    .line 127
    .line 128
    invoke-static {}, LX/EYu;->A01()I

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    const-string/jumbo v0, "unreliable_core_count"

    .line 137
    .line 138
    .line 139
    invoke-virtual {v2, v0, v1}, LX/H49;->A08(Ljava/lang/String;Ljava/lang/Number;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v2}, LX/H49;->A05()V

    .line 143
    .line 144
    .line 145
    :cond_3
    return-void
.end method

.method private final maybeLog()V
    .locals 12

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const-class v0, Landroid/os/UserManager;

    .line 5
    .line 6
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Landroid/os/UserManager;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/os/UserManager;->isUserUnlocked()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    const-string v0, "hatch_device_info_report"

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/EYt;->A0D(Landroid/content/Context;Ljava/lang/String;)Landroid/content/SharedPreferences;

    .line 21
    .line 22
    .line 23
    move-result-object v9

    .line 24
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 25
    .line 26
    .line 27
    move-result-wide v4

    .line 28
    const-string v8, "last_logged_ms"

    .line 29
    .line 30
    const-wide/16 v1, 0x0

    .line 31
    .line 32
    invoke-interface {v9, v8, v1, v2}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    .line 33
    .line 34
    .line 35
    move-result-wide v10

    .line 36
    sub-long v6, v4, v10

    .line 37
    .line 38
    cmp-long v0, v1, v6

    .line 39
    .line 40
    if-gtz v0, :cond_1

    .line 41
    .line 42
    sget-wide v2, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLoggerKt;->REPORT_INTERVAL_MS:J

    .line 43
    .line 44
    cmp-long v0, v6, v2

    .line 45
    .line 46
    if-gez v0, :cond_1

    .line 47
    .line 48
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 49
    .line 50
    .line 51
    move-result-wide v0

    .line 52
    add-long/2addr v0, v2

    .line 53
    sub-long/2addr v0, v6

    .line 54
    sput-wide v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->nextBackgroundCheckElapsedMs:J

    .line 55
    .line 56
    :cond_0
    return-void

    .line 57
    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 58
    .line 59
    .line 60
    move-result-wide v2

    .line 61
    sget-wide v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLoggerKt;->REPORT_INTERVAL_MS:J

    .line 62
    .line 63
    add-long/2addr v2, v0

    .line 64
    sput-wide v2, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->nextBackgroundCheckElapsedMs:J

    .line 65
    .line 66
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->logDeviceInfo()V

    .line 67
    .line 68
    .line 69
    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-interface {v0, v8, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 78
    .line 79
    .line 80
    return-void
.end method

.method private final requestLog()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->inFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-static {v0}, LX/8mk;->A1a(Ljava/util/concurrent/atomic/AtomicBoolean;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger$requestLog$1;

    .line 13
    .line 14
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method


# virtual methods
.method public onAppBackgrounded()V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->requestLog()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public final onBackgroundAnalyticsEvent()V
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForeground()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 9
    .line 10
    .line 11
    move-result-wide v3

    .line 12
    sget-wide v1, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->nextBackgroundCheckElapsedMs:J

    .line 13
    .line 14
    cmp-long v0, v3, v1

    .line 15
    .line 16
    if-ltz v0, :cond_0

    .line 17
    .line 18
    invoke-direct {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeviceInfoLogger;->requestLog()V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void
.end method
