.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;

    .line 1
    .line 2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->restorePending(J)V

    .line 7
    .line 8
    .line 9
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;->$context:Landroid/content/Context;

    .line 12
    .line 13
    invoke-static {v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$maybeCaptureAppManagerEntryContext(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;->$context:Landroid/content/Context;

    .line 17
    .line 18
    invoke-static {v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$isInstallReferrerProcessed(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->clear()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$maybeLog$1;->$context:Landroid/content/Context;

    .line 31
    .line 32
    invoke-static {v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$log(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method
