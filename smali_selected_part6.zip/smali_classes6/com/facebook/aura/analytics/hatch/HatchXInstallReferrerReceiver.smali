.class public final Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;
.super Lcom/facebook/secure/receiver/FamilyStaticBroadcastReceiver;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchXInstallReferrerReceiver"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final isEnabled:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;->Companion:Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 268435456
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver$1;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver$1;

    .line 268435457
    .line 268435458
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiverKt;->trustedSenders:LX/Fc4;

    .line 5
    .line 6
    invoke-direct {p0, v0}, Lcom/facebook/secure/receiver/FamilyStaticBroadcastReceiver;-><init>(LX/Fc4;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;->isEnabled:Lkotlin/jvm/functions/Function0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public doReceive(Landroid/content/Context;Landroid/content/Intent;LX/I8N;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p2}, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;->handleHandoff$fbandroid_express_aura_java_com_facebook_aura_analytics_hatch_hatch(Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public getAsyncExecutor()Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/executors/AuraExecutors;->backgroundThreadExecutor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public final handleHandoff$fbandroid_express_aura_java_com_facebook_aura_analytics_hatch_hatch(Landroid/content/Intent;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchXInstallReferrerReceiver;->isEnabled:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    invoke-static {v0}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const-string/jumbo v0, "utm"

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, LX/IAX;->A00(Landroid/os/Bundle;)LX/IAX;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 24
    .line 25
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->capture(LX/IAX;J)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p1, LX/IAX;->A02:Ljava/lang/String;

    .line 33
    .line 34
    if-eqz p1, :cond_0

    .line 35
    .line 36
    invoke-static {p1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;

    .line 43
    .line 44
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredDeeplinkStore;->captureFromAppManagerCustomData(Ljava/lang/String;J)V

    .line 49
    .line 50
    .line 51
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;

    .line 52
    .line 53
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/aura/analytics/hatch/HatchDeferredInviteCodeStore;->captureFromReferrer(Ljava/lang/String;J)V

    .line 58
    .line 59
    .line 60
    :cond_0
    return-void
.end method

.method public shouldProcessAsync()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method
