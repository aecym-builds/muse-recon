.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/HfO;


# instance fields
.field public final synthetic $deliver:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;->$deliver:LX/JDM;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onError(LX/Hf7;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;->$deliver:LX/JDM;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onReferrerReceived(LX/I22;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$queryAppManagerReferrer$2;->$deliver:LX/JDM;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$buildAppManagerReferrer(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;LX/I22;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-void
.end method
