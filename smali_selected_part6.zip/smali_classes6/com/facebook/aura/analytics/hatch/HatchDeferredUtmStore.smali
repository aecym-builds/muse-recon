.class public final Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

.field public static final KEY_CAPTURED_AT_MS:Ljava/lang/String; = "hatch_deferred_utm_captured_at_ms"

.field public static final KEY_REFERRER:Ljava/lang/String; = "hatch_deferred_utm_referrer"

.field public static final MAX_REFERRER_BYTES:I = 0x1000

.field public static final REFERRER_LIFETIME_MS:J = 0x240c8400L


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic capture$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;LX/IAX;JILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p2

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->capture(LX/IAX;J)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static synthetic getPendingReferrer$default(Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;JILjava/lang/Object;)Ljava/lang/String;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide p1

    .line 8
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->getPendingReferrer(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method private final getPrefs()LX/BVu;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method


# virtual methods
.method public final declared-synchronized capture(LX/IAX;J)V
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerParams;->utmParams(LX/IAX;)Ljava/util/List;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v0, "&"

    .line 12
    .line 13
    invoke-static {v0, v1}, LX/602;->A0e(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-static {v2}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    array-length v1, v0

    .line 28
    const/16 v0, 0x1000

    .line 29
    .line 30
    if-gt v1, v0, :cond_0

    .line 31
    .line 32
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v0, "hatch_deferred_utm_referrer"

    .line 41
    .line 42
    invoke-virtual {v1, v0, v2}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    const-string v0, "hatch_deferred_utm_captured_at_ms"

    .line 46
    .line 47
    invoke-virtual {v1, v0, p2, p3}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v1}, LX/Df3;->A09()Z

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_0
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 55
    .line 56
    .line 57
    :goto_0
    monitor-exit p0

    .line 58
    return-void

    .line 59
    :catchall_0
    move-exception v0

    .line 60
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 61
    throw v0
.end method

.method public final declared-synchronized clear()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v0, "hatch_deferred_utm_referrer"

    .line 10
    .line 11
    invoke-virtual {v1, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "hatch_deferred_utm_captured_at_ms"

    .line 15
    .line 16
    invoke-virtual {v1, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v1}, LX/Df3;->A09()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    .line 21
    .line 22
    monitor-exit p0

    .line 23
    return-void

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    throw v0
.end method

.method public final declared-synchronized getPendingReferrer(J)Ljava/lang/String;
    .locals 7

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    invoke-static {}, LX/EYu;->A0R()LX/BVu;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    const-string v0, "hatch_deferred_utm_referrer"

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    invoke-interface {v1, v0, v6}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v5

    .line 12
    if-eqz v5, :cond_2

    .line 13
    .line 14
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-gtz v0, :cond_0

    .line 19
    .line 20
    move-object v5, v6

    .line 21
    :cond_0
    if-eqz v5, :cond_2

    .line 22
    .line 23
    const-string v0, "hatch_deferred_utm_captured_at_ms"

    .line 24
    .line 25
    const-wide/16 v3, 0x0

    .line 26
    .line 27
    invoke-interface {v1, v0, v3, v4}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 28
    .line 29
    .line 30
    move-result-wide v1

    .line 31
    cmp-long v0, v1, v3

    .line 32
    .line 33
    if-lez v0, :cond_1

    .line 34
    .line 35
    cmp-long v0, p1, v1

    .line 36
    .line 37
    if-ltz v0, :cond_1

    .line 38
    .line 39
    sub-long/2addr p1, v1

    .line 40
    const-wide/32 v1, 0x240c8400

    .line 41
    .line 42
    .line 43
    cmp-long v0, p1, v1

    .line 44
    .line 45
    if-gtz v0, :cond_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    .line 47
    monitor-exit p0

    .line 48
    return-object v5

    .line 49
    :cond_1
    :try_start_1
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/hatch/HatchDeferredUtmStore;->clear()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 50
    .line 51
    .line 52
    monitor-exit p0

    .line 53
    return-object v6

    .line 54
    :cond_2
    monitor-exit p0

    .line 55
    return-object v6

    .line 56
    :catchall_0
    move-exception v0

    .line 57
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 58
    throw v0
.end method
