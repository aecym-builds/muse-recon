.class public final Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $client:LX/HfZ;

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $responseCode:I


# direct methods
.method public constructor <init>(ILandroid/content/Context;LX/HfZ;)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$responseCode:I

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$client:LX/HfZ;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 0
    iget v4, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$responseCode:I

    .line 1
    .line 2
    if-eqz v4, :cond_1

    .line 3
    .line 4
    const/4 v3, 0x2

    .line 5
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$client:LX/HfZ;

    .line 8
    .line 9
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-static {v2, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$endConnectionSafely(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;LX/HfZ;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$context:Landroid/content/Context;

    .line 16
    .line 17
    if-eq v4, v3, :cond_0

    .line 18
    .line 19
    const/16 v0, 0x17

    .line 20
    .line 21
    const/4 v4, 0x0

    .line 22
    const-string v7, "SERVICE_CURRENTLY_UNAVAILABLE"

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, v0, 0x10

    .line 25
    .line 26
    invoke-static {v0}, LX/003;->A1B(I)Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    new-instance v3, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;

    .line 31
    .line 32
    move-object v5, v4

    .line 33
    move-object v6, v4

    .line 34
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;-><init>(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    invoke-static {v2, v1, v3}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$logResolvedInstall(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$PlayResult;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_0
    const/4 v0, 0x7

    .line 42
    const/4 v4, 0x0

    .line 43
    const-string v7, "FEATURE_NOT_SUPPORTED"

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;

    .line 47
    .line 48
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$context:Landroid/content/Context;

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger$log$1$onInstallReferrerSetupFinished$1;->$client:LX/HfZ;

    .line 51
    .line 52
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;->access$onReferrerResponseOk(Lcom/facebook/aura/analytics/hatch/HatchInstallReferrerLogger;Landroid/content/Context;LX/HfZ;)V

    .line 56
    .line 57
    .line 58
    return-void
.end method
