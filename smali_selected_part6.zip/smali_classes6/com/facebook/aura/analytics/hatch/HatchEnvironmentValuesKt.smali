.class public abstract Lcom/facebook/aura/analytics/hatch/HatchEnvironmentValuesKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final hatchAppStateValue()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForeground()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const-string v0, "foreground"

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_0
    const-string v0, "background"

    .line 12
    .line 13
    return-object v0
.end method

.method public static final hatchNetworkTypeValue()Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/network/state/AuraNetworkMonitor;->state:LX/2J3;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    check-cast v1, Lcom/facebook/aura/network/state/AuraNetworkState;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/network/state/AuraNetworkState$Unknown;->INSTANCE:Lcom/facebook/aura/network/state/AuraNetworkState$Unknown;

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const-string/jumbo v0, "unknown"

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :cond_0
    sget-object v0, Lcom/facebook/aura/network/state/AuraNetworkState$Offline;->INSTANCE:Lcom/facebook/aura/network/state/AuraNetworkState$Offline;

    .line 21
    .line 22
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    const-string v0, "offline"

    .line 29
    .line 30
    return-object v0

    .line 31
    :cond_1
    instance-of v0, v1, Lcom/facebook/aura/network/state/AuraNetworkState$Online;

    .line 32
    .line 33
    if-eqz v0, :cond_5

    .line 34
    .line 35
    check-cast v1, Lcom/facebook/aura/network/state/AuraNetworkState$Online;

    .line 36
    .line 37
    iget-object v0, v1, Lcom/facebook/aura/network/state/AuraNetworkState$Online;->transport:Lcom/facebook/aura/network/state/Transport;

    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    const/4 v0, 0x0

    .line 44
    if-eq v1, v0, :cond_4

    .line 45
    .line 46
    const/4 v0, 0x1

    .line 47
    if-eq v1, v0, :cond_3

    .line 48
    .line 49
    const/4 v0, 0x2

    .line 50
    if-eq v1, v0, :cond_2

    .line 51
    .line 52
    const/4 v0, 0x3

    .line 53
    if-eq v1, v0, :cond_2

    .line 54
    .line 55
    const/4 v0, 0x4

    .line 56
    if-eq v1, v0, :cond_2

    .line 57
    .line 58
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    throw v0

    .line 63
    :cond_2
    const-string v0, "other"

    .line 64
    .line 65
    return-object v0

    .line 66
    :cond_3
    const-string v0, "cellular"

    .line 67
    .line 68
    return-object v0

    .line 69
    :cond_4
    const-string/jumbo v0, "wifi"

    .line 70
    .line 71
    .line 72
    return-object v0

    .line 73
    :cond_5
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    throw v0
.end method
