.class public final Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H9b;


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;

.field public static final TAG:Ljava/lang/String; = "AuraXNativeHolderProvider"


# instance fields
.field public final analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "LX/H4A;",
            ">;"
        }
    .end annotation
.end field

.field public final xAnalyticsAdapter:Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->Companion:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "LX/H4A;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;->Companion:LX/HxK;

    .line 10
    .line 11
    new-instance v1, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;

    .line 12
    .line 13
    invoke-direct {v1, p0}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;-><init>(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;

    .line 17
    .line 18
    invoke-direct {v0, v1}, Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;-><init>(Lcom/facebook/xanalytics/XAnalyticsAdapter;)V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->xAnalyticsAdapter:Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;

    .line 22
    .line 23
    return-void
.end method

.method public static final synthetic access$getAnalytics2LoggerProvider$p(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    return-object p0
.end method


# virtual methods
.method public getXAnalyticsNative()Lcom/facebook/xanalytics/XAnalyticsHolder;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->xAnalyticsAdapter:Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;

    .line 1
    .line 2
    return-object p0
.end method
