.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/H4A;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/H4A;
    .locals 1

    .line 0
    const-string v0, "MetaAnalyticsInstance"

    .line 1
    .line 2
    invoke-static {v0}, LX/I6a;->A00(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    :try_start_0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;

    .line 6
    .line 7
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    iget-object p0, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 11
    .line 12
    new-instance v0, LX/H4A;

    .line 13
    .line 14
    invoke-direct {v0, p0}, LX/H4A;-><init>(LX/H4B;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    .line 17
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 18
    .line 19
    .line 20
    return-object v0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 23
    .line 24
    .line 25
    throw v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsInstance$instanceLazy$1;->invoke()LX/H4A;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
