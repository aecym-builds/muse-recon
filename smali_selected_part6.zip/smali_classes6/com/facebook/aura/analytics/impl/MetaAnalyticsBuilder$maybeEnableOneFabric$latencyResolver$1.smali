.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final synthetic $microBatchUploadLatencyParamsProvider:LX/FiZ;


# direct methods
.method public constructor <init>(LX/FiZ;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;->$microBatchUploadLatencyParamsProvider:LX/FiZ;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public static final resolveLatency$lambda$0(Lkotlin/Lazy;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/lang/Boolean;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method


# virtual methods
.method public resolveLatency(J)J
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1$resolveLatency$ffdbProvider$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1$resolveLatency$ffdbProvider$1;

    .line 1
    .line 2
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1$resolveLatency$isFfdbEnabled$2;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1$resolveLatency$isFfdbEnabled$2;-><init>(Lkotlin/Lazy;)V

    .line 9
    .line 10
    .line 11
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;->resolveLatency$lambda$0(Lkotlin/Lazy;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    const-wide/16 v0, 0x0

    .line 22
    .line 23
    return-wide v0

    .line 24
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;->$microBatchUploadLatencyParamsProvider:LX/FiZ;

    .line 25
    .line 26
    invoke-virtual {v0, p1, p2}, LX/FiZ;->A00(J)LX/FiV;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget-wide v0, v0, LX/FiV;->A01:J

    .line 31
    .line 32
    return-wide v0
.end method
