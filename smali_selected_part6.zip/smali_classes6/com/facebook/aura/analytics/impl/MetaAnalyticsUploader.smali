.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FiE;


# instance fields
.field public final callerClassName:Ljava/lang/String;

.field public final endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 9
    .line 10
    invoke-static {p0}, LX/002;->A0y(Ljava/lang/Object;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->callerClassName:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method

.method private final buildRequest(LX/Fpl;)Lcom/facebook/aura/network/transport/HatchHttpRequest;
    .locals 20

    .line 0
    move-object/from16 v6, p0

    .line 1
    .line 2
    move-object/from16 v0, p1

    .line 3
    .line 4
    invoke-direct {v6, v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->serializeAndGzip(LX/Fpl;)[B

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    const/4 v7, 0x4

    .line 9
    sget-object v0, Lcom/facebook/aura/network/AuraUserAgent;->fullUserAgent:Lkotlin/Lazy;

    .line 10
    .line 11
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const-string v0, "User-Agent"

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    const-string v1, "fb_api_req_friendly_name"

    .line 22
    .line 23
    const-string/jumbo v0, "sendAnalyticsLog"

    .line 24
    .line 25
    .line 26
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    const/16 v17, 0x1

    .line 31
    .line 32
    const-string v1, "fb_api_caller_class"

    .line 33
    .line 34
    iget-object v0, v6, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->callerClassName:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    const-string v1, "Content-Encoding"

    .line 41
    .line 42
    const-string v0, "gzip"

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    filled-new-array {v5, v3, v2, v0}, [LX/IBK;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-static {v0, v7}, LX/EYu;->A0u([LX/IBK;I)Ljava/util/LinkedHashMap;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    sget-object v5, Lcom/facebook/aura/network/transport/HatchHttpRequest;->Companion:Lcom/facebook/aura/network/transport/HatchHttpRequest$Companion;

    .line 57
    .line 58
    invoke-direct {v6}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->endpointUrl()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    const-string v0, "application/x-www-form-urlencoded"

    .line 63
    .line 64
    new-instance v7, Lcom/facebook/aura/network/transport/HatchRequestBody$Bytes;

    .line 65
    .line 66
    invoke-direct {v7, v4, v0}, Lcom/facebook/aura/network/transport/HatchRequestBody$Bytes;-><init>([BLjava/lang/String;)V

    .line 67
    .line 68
    .line 69
    const/4 v9, 0x0

    .line 70
    sget-object v12, Lcom/facebook/aura/network/transport/HatchRequestCategory;->API:Lcom/facebook/aura/network/transport/HatchRequestCategory;

    .line 71
    .line 72
    sget-object v13, Lcom/facebook/aura/network/transport/HatchRequestPurpose;->FETCH:Lcom/facebook/aura/network/transport/HatchRequestPurpose;

    .line 73
    .line 74
    const/4 v15, 0x0

    .line 75
    sget-object v18, Lcom/facebook/aura/network/transport/HatchResponseBodyPolicy;->DEFAULT:Lcom/facebook/aura/network/transport/HatchResponseBodyPolicy;

    .line 76
    .line 77
    move-object v10, v9

    .line 78
    move-object v11, v9

    .line 79
    move-object v14, v9

    .line 80
    move/from16 v16, v15

    .line 81
    .line 82
    move-object/from16 v19, v9

    .line 83
    .line 84
    move/from16 p0, v15

    .line 85
    .line 86
    move/from16 p1, v17

    .line 87
    .line 88
    invoke-virtual/range {v5 .. v21}, Lcom/facebook/aura/network/transport/HatchHttpRequest$Companion;->post(Ljava/lang/String;Lcom/facebook/aura/network/transport/HatchRequestBody;Ljava/util/Map;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/network/transport/HatchRequestCategory;Lcom/facebook/aura/network/transport/HatchRequestPurpose;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;ZZZLcom/facebook/aura/network/transport/HatchResponseBodyPolicy;Lcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZZ)Lcom/facebook/aura/network/transport/HatchHttpRequest;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    return-object v0
.end method

.method private final endpointUrl()Ljava/lang/String;
    .locals 3

    .line 0
    new-instance v1, Landroid/net/Uri$Builder;

    .line 1
    .line 2
    invoke-direct {v1}, Landroid/net/Uri$Builder;-><init>()V

    .line 3
    .line 4
    .line 5
    const-string v0, "https"

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    iget-object v1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 12
    .line 13
    const-string v0, "graph"

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;->facebookAuthority(Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v2, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "/logging_client_events"

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, LX/006;->A15(Ljava/lang/Object;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    return-object v0
.end method

.method private final serializeAndGzip(LX/Fpl;)[B
    .locals 5

    .line 0
    invoke-interface {p1}, LX/Fpl;->AFS()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    const/4 v0, 0x0

    .line 5
    if-ge v1, v0, :cond_0

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    :cond_0
    new-instance v4, Ljava/io/ByteArrayOutputStream;

    .line 9
    .line 10
    invoke-direct {v4, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 11
    .line 12
    .line 13
    new-instance v3, Ljava/util/zip/GZIPOutputStream;

    .line 14
    .line 15
    invoke-direct {v3, v4}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    new-instance p0, Lcom/facebook/aura/analytics/impl/FormEncoder;

    .line 19
    .line 20
    invoke-direct {p0, v3}, Lcom/facebook/aura/analytics/impl/FormEncoder;-><init>(Ljava/io/OutputStream;)V

    .line 21
    .line 22
    .line 23
    const-string v1, "access_token"

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploaderKt;->FALCO_CLIENT_TOKEN:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string v1, "format"

    .line 31
    .line 32
    const-string v0, "json"

    .line 33
    .line 34
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, "compressed"

    .line 38
    .line 39
    const-string v0, "0"

    .line 40
    .line 41
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1}, LX/Fpl;->AOt()Z

    .line 45
    .line 46
    .line 47
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 48
    const-string v2, "1"

    .line 49
    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    :try_start_1
    const-string v0, "multi_batch"

    .line 53
    .line 54
    invoke-virtual {p0, v0, v2}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    :cond_1
    invoke-interface {p1}, LX/Fpl;->getFFDBToken()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-lez v0, :cond_2

    .line 66
    .line 67
    const-string v0, "ffdb_token"

    .line 68
    .line 69
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    invoke-interface {p1}, LX/Fpl;->Ag3()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_3

    .line 77
    .line 78
    const-string/jumbo v0, "request_debug_config"

    .line 79
    .line 80
    .line 81
    invoke-virtual {p0, v0, v2}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    :cond_3
    const-string v1, "message"

    .line 85
    .line 86
    const/4 v0, 0x0

    .line 87
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FormEncoder;->write(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    new-instance v1, LX/FqL;

    .line 91
    .line 92
    invoke-direct {v1, v3, v0}, LX/FqL;-><init>(Ljava/io/OutputStream;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    new-instance v0, LX/Fqs;

    .line 96
    .line 97
    invoke-direct {v0, v1}, LX/Fqs;-><init>(Ljava/io/Writer;)V

    .line 98
    .line 99
    .line 100
    invoke-interface {p1, v0}, LX/Fpl;->AjN(Ljava/io/Writer;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0}, Ljava/io/Writer;->flush()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 104
    .line 105
    .line 106
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    return-object v0

    .line 117
    :catchall_0
    move-exception v1

    .line 118
    :try_start_2
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 119
    :catchall_1
    move-exception v0

    .line 120
    invoke-static {v3, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 121
    .line 122
    .line 123
    throw v0
.end method


# virtual methods
.method public upload(LX/FiG;LX/FiY;LX/Fi7;)V
    .locals 5

    .line 0
    const-string v4, "MetaAnalyticsUploader"

    .line 1
    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p1, LX/FiG;->A00:LX/Fpl;

    .line 6
    .line 7
    :try_start_0
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;->buildRequest(LX/Fpl;)Lcom/facebook/aura/network/transport/HatchHttpRequest;

    .line 8
    .line 9
    .line 10
    move-result-object v2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4

    .line 11
    :try_start_1
    const/4 v0, 0x0

    .line 12
    new-instance v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader$upload$response$1;

    .line 13
    .line 14
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader$upload$response$1;-><init>(Lcom/facebook/aura/network/transport/HatchHttpRequest;LX/2M4;)V

    .line 15
    .line 16
    .line 17
    sget-object v0, LX/39s;->A00:LX/39s;

    .line 18
    .line 19
    invoke-static {v0, v1}, LX/DRR;->A00(LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lcom/facebook/aura/network/transport/HatchHttpResponse;

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/network/transport/HatchHttpResponse;->body()Lcom/facebook/aura/network/transport/HatchHttpResponseBody;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    if-nez v3, :cond_1

    .line 30
    .line 31
    iget-object v0, v0, Lcom/facebook/aura/network/transport/HatchHttpResponse;->errorMessage:Ljava/lang/String;

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    const-string v0, "no response body"

    .line 36
    .line 37
    :cond_0
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {p2, v0}, LX/FiY;->ATT(Ljava/io/IOException;)V

    .line 42
    .line 43
    .line 44
    return-void
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_2

    .line 45
    :cond_1
    :try_start_2
    iget v2, v0, Lcom/facebook/aura/network/transport/HatchHttpResponse;->statusCode:I

    .line 46
    .line 47
    iget-object p0, v3, Lcom/facebook/aura/network/transport/HatchHttpResponseBody;->stream:Ljava/io/InputStream;

    .line 48
    .line 49
    move-object p1, p2

    .line 50
    check-cast p1, LX/Fpk;

    .line 51
    .line 52
    const-string v1, "Unexpected HTTP code "

    .line 53
    .line 54
    const/16 v0, 0xc8

    .line 55
    .line 56
    if-ne v2, v0, :cond_3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 57
    .line 58
    :try_start_3
    iget-object v1, p1, LX/Fpk;->A03:Lcom/facebook/flexiblesampling/SamplingPolicyConfig;

    .line 59
    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    iget-object v0, p1, LX/Fpk;->A02:LX/FiI;

    .line 63
    .line 64
    invoke-interface {v1, p0, v0}, Lcom/facebook/flexiblesampling/SamplingPolicyConfig;->updatePolicyFromServer(Ljava/io/InputStream;LX/FiI;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    iget-object v1, p1, LX/Fpk;->A00:LX/Fpo;

    .line 68
    .line 69
    invoke-interface {v1}, LX/Fpl;->AQK()V

    .line 70
    .line 71
    .line 72
    iget-object v0, p1, LX/Fpk;->A01:LX/Fpq;

    .line 73
    .line 74
    invoke-interface {v0}, LX/Fpq;->onSuccess()V

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_3
    invoke-static {v1, v2}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    new-instance v0, Lcom/facebook/analytics2/logger/legacy/uploader/UploadProcessor$HttpResponseException;

    .line 83
    .line 84
    invoke-direct {v0, v2, v1}, Lcom/facebook/analytics2/logger/legacy/uploader/UploadProcessor$HttpResponseException;-><init>(ILjava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw v0
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 88
    :catch_0
    move-exception v1

    .line 89
    :try_start_4
    iget-object v0, p1, LX/Fpk;->A01:LX/Fpq;

    .line 90
    .line 91
    invoke-interface {v0, v1}, LX/Fpq;->ATT(Ljava/io/IOException;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 92
    .line 93
    .line 94
    :try_start_5
    iget-object v1, p1, LX/Fpk;->A00:LX/Fpo;

    .line 95
    .line 96
    :goto_0
    invoke-interface {v1}, LX/Fpo;->ANH()Z

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    if-eqz v0, :cond_4

    .line 101
    .line 102
    invoke-interface {v1}, LX/Fpo;->unlock()V

    .line 103
    .line 104
    .line 105
    :cond_4
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :catchall_0
    move-exception v2

    .line 110
    iget-object v1, p1, LX/Fpk;->A00:LX/Fpo;

    .line 111
    .line 112
    invoke-interface {v1}, LX/Fpo;->ANH()Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_5

    .line 117
    .line 118
    invoke-interface {v1}, LX/Fpo;->unlock()V

    .line 119
    .line 120
    .line 121
    :cond_5
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 122
    .line 123
    .line 124
    throw v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 125
    :catchall_1
    move-exception v1

    .line 126
    :try_start_6
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 127
    :catchall_2
    move-exception v0

    .line 128
    :try_start_7
    invoke-static {v3, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 129
    .line 130
    .line 131
    throw v0
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_3
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_7 .. :try_end_7} :catch_2

    .line 132
    :catch_1
    move-exception v3

    .line 133
    invoke-static {v3}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    const-string v0, "Unexpected upload error: %s"

    .line 142
    .line 143
    invoke-static {v4, v0, v3, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    const-string v0, "Unexpected upload error: "

    .line 147
    .line 148
    invoke-static {v0, v2}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    new-instance v0, Ljava/io/IOException;

    .line 153
    .line 154
    invoke-direct {v0, v1, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 155
    .line 156
    .line 157
    goto :goto_1

    .line 158
    :catch_2
    move-exception v2

    .line 159
    const-string v1, "Upload OOM"

    .line 160
    .line 161
    invoke-static {v4, v2, v1}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    new-instance v0, Ljava/io/IOException;

    .line 165
    .line 166
    invoke-direct {v0, v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 167
    .line 168
    .line 169
    :goto_1
    invoke-interface {p2, v0}, LX/FiY;->ATT(Ljava/io/IOException;)V

    .line 170
    .line 171
    .line 172
    return-void

    .line 173
    :catch_3
    move-exception v0

    .line 174
    invoke-interface {p2, v0}, LX/FiY;->ATT(Ljava/io/IOException;)V

    .line 175
    .line 176
    .line 177
    return-void

    .line 178
    :catch_4
    move-exception v2

    .line 179
    invoke-static {v2}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    const-string v0, "Failed to build request: %s"

    .line 188
    .line 189
    invoke-static {v4, v0, v2, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    invoke-interface {p2, v2}, LX/FiY;->ATT(Ljava/io/IOException;)V

    .line 193
    .line 194
    .line 195
    return-void
.end method
