.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H4w;


# instance fields
.field public final synthetic $healthCounterLogger$delegate:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "LX/H5M;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/Lazy;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Lazy<",
            "+",
            "LX/H5M;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$1;->$healthCounterLogger$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public get()LX/H5M;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$1;->$healthCounterLogger$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/H5M;

    .line 7
    .line 8
    return-object p0
.end method

.method public isHealthCounterEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public isOneFabricEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method
