.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$qplConfigHandlerProvider$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H6C;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getQPLConfigDirective(Lcom/facebook/logginginfra/falco/PrincipalSubject;)Lcom/facebook/logginginfra/falco/GetQPLConfigDirective;
    .locals 2

    .line 0
    const/4 p1, 0x3

    .line 1
    new-array v1, p1, [Ljava/lang/Object;

    .line 2
    .line 3
    new-array p0, p1, [Ljava/lang/Object;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-static {v1, v0, p0, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 7
    .line 8
    .line 9
    new-instance v1, Lcom/facebook/logginginfra/falco/GetQPLConfigDirective;

    .line 10
    .line 11
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    const-string v0, "com.facebook.logginginfra.falco.GetQPLConfigDirective"

    .line 15
    .line 16
    iput-object v0, v1, Lcom/facebook/hyperthrift/HyperThriftBase;->A00:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p0, v1, Lcom/facebook/hyperthrift/HyperThriftBase;->A01:[Ljava/lang/Object;

    .line 19
    .line 20
    return-object v1
.end method

.method public handleConfig(Lcom/facebook/logginginfra/falco/SetQPLConfigDirective;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
