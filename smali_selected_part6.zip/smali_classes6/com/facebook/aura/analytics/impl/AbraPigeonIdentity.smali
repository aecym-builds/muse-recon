.class public final Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;
.super LX/H5X;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity$Companion;


# instance fields
.field public final abraUserId:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;->Companion:Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object v1, p1

    .line 1
    move-object v5, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v4

    .line 6
    const/4 v3, 0x0

    .line 7
    move-object v0, p0

    .line 8
    move-object v2, p1

    .line 9
    invoke-direct/range {v0 .. v5}, LX/H5X;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;->abraUserId:Ljava/lang/String;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public addFieldsToIdentityDescriptor(LX/H5Y;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-boolean v0, p1, LX/H5Y;->A0A:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;->abraUserId:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p1, LX/H5Y;->A04:Ljava/lang/Long;

    .line 17
    .line 18
    invoke-virtual {p0}, LX/H5X;->getAtClaim()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    iget-object v0, p1, LX/H5Y;->A08:Ljava/util/Set;

    .line 25
    .line 26
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method public attachBatchLevelFields(LX/GFv;LX/GFw;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string/jumbo v1, "uid"

    .line 5
    .line 6
    .line 7
    const-string v0, "0"

    .line 8
    .line 9
    invoke-static {p1, v0, v1}, LX/GFv;->A01(LX/GFv;Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v1, "app_uid"

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;->abraUserId:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {p1, v0, v1}, LX/GFv;->A01(LX/GFv;Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final getAbraUserId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;->abraUserId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
