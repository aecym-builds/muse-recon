.class public final Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/H4A;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/H4A;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    sget-object p0, Lcom/facebook/aura/analytics/AuraAnalytics;->INSTANCE:Lcom/facebook/aura/analytics/AuraAnalytics;

    .line 268435457
    .line 268435458
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/AuraAnalytics;->getInstance()LX/H4A;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
