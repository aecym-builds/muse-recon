.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/H5M;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $isDebugBuild$delegate:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $isFfdbEnabled$delegate:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $oneFabricEventHandler:LX/H5U;

.field public final synthetic this$0:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;LX/H5U;Lkotlin/Lazy;Lkotlin/Lazy;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;",
            "LX/H5U;",
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->this$0:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$oneFabricEventHandler:LX/H5U;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$isFfdbEnabled$delegate:Lkotlin/Lazy;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$isDebugBuild$delegate:Lkotlin/Lazy;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke()LX/H5M;
    .locals 21

    .line 0
    const/4 v14, 0x1

    .line 1
    sget-object v13, LX/H5Z;->A08:LX/H65;

    .line 2
    .line 3
    invoke-static {}, LX/EYt;->A0B()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v8

    .line 7
    sget-object v1, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 8
    .line 9
    const-string v0, "HCFlushExecutor"

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    invoke-virtual {v1, v0, v4}, Lcom/facebook/aura/executors/AuraExecutors;->newSingleThreadScheduledExecutor(Ljava/lang/String;Lcom/facebook/aura/executors/NameAndPriorityThreadFactory$ThreadInstanceCreator;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 13
    .line 14
    .line 15
    move-result-object v15

    .line 16
    move-object/from16 v3, p0

    .line 17
    .line 18
    iget-object v0, v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->this$0:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;

    .line 19
    .line 20
    invoke-static {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->access$createFFA2UploadConfiguration(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;)LX/H5k;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    iget-object v0, v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->this$0:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;

    .line 25
    .line 26
    invoke-static {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->access$getBaseFilePath(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v12

    .line 30
    new-instance v11, LX/H68;

    .line 31
    .line 32
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    const-string v0, "a2_hc_logger"

    .line 36
    .line 37
    invoke-static {v0}, LX/EYu;->A0G(Ljava/lang/String;)Landroid/os/Looper;

    .line 38
    .line 39
    .line 40
    move-result-object v9

    .line 41
    invoke-static {v9}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$isFfdbEnabled$delegate:Lkotlin/Lazy;

    .line 45
    .line 46
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v10

    .line 54
    const/4 v7, 0x0

    .line 55
    new-instance v2, LX/H5u;

    .line 56
    .line 57
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    iget-object v1, v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$oneFabricEventHandler:LX/H5U;

    .line 61
    .line 62
    iget-object v0, v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->$isDebugBuild$delegate:Lkotlin/Lazy;

    .line 63
    .line 64
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    monitor-enter v13

    .line 73
    :try_start_0
    invoke-static {v8, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 74
    .line 75
    .line 76
    sget-object v3, LX/H5Z;->A01:LX/H5Z;

    .line 77
    .line 78
    if-nez v3, :cond_5

    .line 79
    .line 80
    new-instance v3, LX/H5Z;

    .line 81
    .line 82
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 83
    .line 84
    .line 85
    sput-object v11, LX/H5Z;->A05:LX/H68;

    .line 86
    .line 87
    sput-object v2, LX/H5Z;->A03:LX/H5u;

    .line 88
    .line 89
    iput-object v1, v3, LX/H5Z;->A00:LX/H4o;

    .line 90
    .line 91
    sput-boolean v10, LX/H5Z;->A07:Z

    .line 92
    .line 93
    sput-boolean v6, LX/H5Z;->A06:Z

    .line 94
    .line 95
    const/16 v0, 0x8

    .line 96
    .line 97
    invoke-static {v3, v0}, LX/HV1;->A01(Ljava/lang/Object;I)LX/HV1;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    const/4 v0, 0x5

    .line 102
    new-instance v1, LX/HUv;

    .line 103
    .line 104
    invoke-direct {v1, v3, v0}, LX/HUv;-><init>(Ljava/lang/Object;I)V

    .line 105
    .line 106
    .line 107
    new-instance v0, LX/H5a;

    .line 108
    .line 109
    invoke-direct {v0, v9, v1, v2}, LX/H5a;-><init>(Landroid/os/Looper;Lkotlin/jvm/functions/Function0;LX/JDM;)V

    .line 110
    .line 111
    .line 112
    sput-object v0, LX/H5Z;->A04:LX/H5a;

    .line 113
    .line 114
    sget-object v1, LX/H5Z;->A03:LX/H5u;

    .line 115
    .line 116
    if-nez v1, :cond_0

    .line 117
    .line 118
    const-string/jumbo v0, "samplingConfig"

    .line 119
    .line 120
    .line 121
    invoke-static {v0}, LX/I1c;->A0i(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 122
    .line 123
    .line 124
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    goto :goto_1

    .line 129
    :cond_0
    :try_start_1
    new-instance v0, LX/H5p;

    .line 130
    .line 131
    invoke-direct {v0, v1}, LX/H5p;-><init>(LX/H5u;)V

    .line 132
    .line 133
    .line 134
    sput-object v0, LX/H5Z;->A02:LX/H5p;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 135
    .line 136
    :try_start_2
    iget-object v0, v3, LX/H5Z;->A00:LX/H4o;

    .line 137
    .line 138
    if-nez v0, :cond_2

    .line 139
    .line 140
    invoke-virtual {v8}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    invoke-static {v0, v7}, LX/Hva;->A06(Landroid/content/Context;I)V

    .line 145
    .line 146
    .line 147
    const-string v0, "4331325740476680"

    .line 148
    .line 149
    invoke-static {v0}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setAppId(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    const-string v0, "18.0.0.8.161"

    .line 153
    .line 154
    invoke-static {v0}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setAppVersion(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    iget-object v0, v5, LX/H5k;->A00:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {v0}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setClientToken(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    iget-object v0, v5, LX/H5k;->A01:Ljava/lang/String;

    .line 163
    .line 164
    invoke-static {v0}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setUserAgent(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    invoke-static {v12}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setBaseFilePath(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    iget-object v2, v5, LX/H5k;->A02:LX/0RE;

    .line 171
    .line 172
    sget-boolean v0, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sIsInitialized:Z

    .line 173
    .line 174
    const-class v1, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;

    .line 175
    .line 176
    monitor-enter v1
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 177
    :try_start_3
    sget-boolean v0, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sIsInitialized:Z

    .line 178
    .line 179
    if-nez v0, :cond_1

    .line 180
    .line 181
    sput-object v4, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sHyperThrift:LX/HAi;

    .line 182
    .line 183
    sput-object v4, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sQPLConfigHandlerProvider:LX/0RE;

    .line 184
    .line 185
    sput-object v2, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sTigonServiceHolderProvider:LX/0RE;

    .line 186
    .line 187
    sput-object v4, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sUploader:Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;

    .line 188
    .line 189
    sput-object v4, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sUploadCallback:LX/FqK;

    .line 190
    .line 191
    sput-object v4, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sContext:Landroid/content/Context;

    .line 192
    .line 193
    invoke-static {}, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->initNative()V

    .line 194
    .line 195
    .line 196
    sput-boolean v14, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->sIsInitialized:Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 197
    .line 198
    :cond_1
    :try_start_4
    monitor-exit v1

    .line 199
    goto :goto_0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 200
    :catchall_0
    move-exception v0

    .line 201
    :try_start_5
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 202
    :catchall_1
    move-exception v0

    .line 203
    :try_start_6
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 204
    :catchall_2
    move-exception v0

    .line 205
    :try_start_7
    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 206
    :try_start_8
    throw v0

    .line 207
    :cond_2
    :goto_0
    if-eqz v10, :cond_3

    .line 208
    .line 209
    new-instance v0, LX/H5h;

    .line 210
    .line 211
    invoke-direct {v0, v3}, LX/H5h;-><init>(LX/H5Z;)V

    .line 212
    .line 213
    .line 214
    sget-object p0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 215
    .line 216
    const-wide/16 v17, 0x0

    .line 217
    .line 218
    const-wide/16 v19, 0x3e8

    .line 219
    .line 220
    move-object/from16 v16, v0

    .line 221
    .line 222
    invoke-interface/range {v15 .. v21}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 223
    .line 224
    .line 225
    :cond_3
    if-eqz v6, :cond_4

    .line 226
    .line 227
    invoke-static {}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->enableEventListeners()V

    .line 228
    .line 229
    .line 230
    invoke-static {v14}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setOneFabricHCEnabled(Z)V

    .line 231
    .line 232
    .line 233
    invoke-static {v14}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setEnableInternalDebugLogging(Z)V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 234
    .line 235
    .line 236
    :cond_4
    :try_start_9
    sput-object v3, LX/H5Z;->A01:LX/H5Z;

    .line 237
    .line 238
    goto :goto_2

    .line 239
    :catch_0
    move-exception v1

    .line 240
    const-string v0, "SoLoader.init() failed"

    .line 241
    .line 242
    invoke-static {v0, v1}, LX/EYt;->A0g(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    :goto_1
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 247
    :cond_5
    :goto_2
    monitor-exit v13

    .line 248
    return-object v3

    .line 249
    :catchall_3
    move-exception v0

    .line 250
    :try_start_a
    monitor-exit v13
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .line 251
    throw v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;->invoke()LX/H5M;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
