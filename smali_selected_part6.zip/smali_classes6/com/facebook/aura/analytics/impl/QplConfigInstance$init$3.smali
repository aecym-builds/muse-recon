.class public final Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0RE;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/0RE;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final get()LX/H9k;
    .locals 0

    .line 0
    new-instance p0, LX/H9Y;

    .line 1
    .line 2
    invoke-direct {p0}, LX/H9Y;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    .line 268435456
    new-instance p0, LX/H9Y;

    .line 268435457
    .line 268435458
    invoke-direct {p0}, LX/H9Y;-><init>()V

    .line 268435459
    .line 268435460
    .line 268435461
    return-object p0
.end method
