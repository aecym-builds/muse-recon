.class public final Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final analyticsBatchInfoSize:I

.field public final eventLatencyOverride:Ljava/lang/String;

.field public final highBackMaxDelayMsBatch:J

.field public final highBackMaxDelayMsSingle:J

.field public final highBackMinDelayMsBatch:J

.field public final highBackMinDelayMsSingle:J

.field public final highForeMaxDelayMsBatch:J

.field public final highForeMaxDelayMsSingle:J

.field public final highForeMinDelayMsBatch:J

.field public final highForeMinDelayMsSingle:J

.field public final inMemoryUploadDelay:J

.field public final latencyWindowMultiplier:J

.field public final microBatchEnabled:Z

.field public final multiBatchPayloadSize:I

.field public final realTimeExemptLatency:J

.field public final regularBackMaxDelayMsBatch:J

.field public final regularBackMaxDelayMsSingle:J

.field public final regularBackMinDelayMsBatch:J

.field public final regularBackMinDelayMsSingle:J

.field public final regularExemptLatency:J

.field public final regularForeMaxDelayMsBatch:J

.field public final regularForeMaxDelayMsSingle:J

.field public final regularForeMinDelayMsBatch:J

.field public final regularForeMinDelayMsSingle:J

.field public final regularUploadDelay:I

.field public final shouldNotifyOnBatchReady:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    iput-boolean v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->microBatchEnabled:Z

    .line 5
    .line 6
    iput-boolean v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->shouldNotifyOnBatchReady:Z

    .line 7
    .line 8
    const/16 v0, 0x4e20

    .line 9
    .line 10
    iput v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->multiBatchPayloadSize:I

    .line 11
    .line 12
    const/16 v0, 0x3c

    .line 13
    .line 14
    iput v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->analyticsBatchInfoSize:I

    .line 15
    .line 16
    const/16 v0, 0x12c

    .line 17
    .line 18
    iput v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularUploadDelay:I

    .line 19
    .line 20
    const-wide/32 v2, 0x493e0

    .line 21
    .line 22
    .line 23
    iput-wide v2, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularExemptLatency:J

    .line 24
    .line 25
    const-wide/16 v0, 0x1

    .line 26
    .line 27
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->latencyWindowMultiplier:J

    .line 28
    .line 29
    const-wide/32 v0, 0xea60

    .line 30
    .line 31
    .line 32
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->inMemoryUploadDelay:J

    .line 33
    .line 34
    const-string/jumbo v0, "{}"

    .line 35
    .line 36
    .line 37
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->eventLatencyOverride:Ljava/lang/String;

    .line 38
    .line 39
    const-wide/32 v0, 0x249f0

    .line 40
    .line 41
    .line 42
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsBatch:J

    .line 43
    .line 44
    iput-wide v2, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsBatch:J

    .line 45
    .line 46
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsSingle:J

    .line 47
    .line 48
    iput-wide v2, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsSingle:J

    .line 49
    .line 50
    iput-wide v2, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsBatch:J

    .line 51
    .line 52
    const-wide/32 v0, 0xdbba0

    .line 53
    .line 54
    .line 55
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsBatch:J

    .line 56
    .line 57
    iput-wide v2, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsSingle:J

    .line 58
    .line 59
    iput-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsSingle:J

    .line 60
    .line 61
    return-void
.end method


# virtual methods
.method public final getAnalyticsBatchInfoSize()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->analyticsBatchInfoSize:I

    .line 1
    .line 2
    return p0
.end method

.method public final getEnableCC()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public final getEnableFailOpenSampling()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public final getEnableOneFabricCleanupIdentities()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public final getEnablePlatformUploads()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public final getEnablePlatformUploadsHC()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public final getEventLatencyOverride()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->eventLatencyOverride:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHighBackMaxDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highBackMaxDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighBackMaxDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highBackMaxDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighBackMinDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highBackMinDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighBackMinDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highBackMinDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighForeMaxDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highForeMaxDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighForeMaxDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highForeMaxDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighForeMinDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highForeMinDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getHighForeMinDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->highForeMinDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getInMemoryUploadDelay()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->inMemoryUploadDelay:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getLatencyWindowMultiplier()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->latencyWindowMultiplier:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getMicroBatchEnabled()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->microBatchEnabled:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getMultiBatchPayloadSize()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->multiBatchPayloadSize:I

    .line 1
    .line 2
    return p0
.end method

.method public final getRealTimeExemptLatency()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->realTimeExemptLatency:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularBackMaxDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularBackMaxDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularBackMinDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularBackMinDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularExemptLatency()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularExemptLatency:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularForeMaxDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularForeMaxDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularForeMinDelayMsBatch()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsBatch:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularForeMinDelayMsSingle()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsSingle:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getRegularUploadDelay()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularUploadDelay:I

    .line 1
    .line 2
    return p0
.end method

.method public final getShouldNotifyOnBatchReady()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->shouldNotifyOnBatchReady:Z

    .line 1
    .line 2
    return p0
.end method
