.class public final Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/tigon/AuraTigonXAnalyticsProvider;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl;->INSTANCE:Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public provide()Lcom/facebook/xanalytics/XAnalyticsHolder;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/AuraTigonXAnalyticsProviderImpl$provide$1;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 3
    .line 4
    invoke-direct {v0, p0}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->xAnalyticsAdapter:Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;

    .line 8
    .line 9
    return-object v0
.end method
