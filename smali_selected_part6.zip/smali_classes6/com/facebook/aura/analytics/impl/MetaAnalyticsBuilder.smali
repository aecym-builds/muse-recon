.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$Companion;

.field public static final FALCO_CLIENT_TOKEN:Ljava/lang/String;

.field public static final TAG:Ljava/lang/String; = "MetaAnalyticsBuilder"

.field public static configValueInstance:LX/H5r;

.field public static uploadConfigInstance:LX/H5k;


# instance fields
.field public final analyticsEventListener:LX/H5v;

.field public final appInfoProvider:Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

.field public final builder:LX/H4B;

.field public final consentStateProvider:LX/H3K;

.field public final deviceInfoProvider:LX/H6G;

.field public final modeStateProvider:LX/H5t;

.field public final sessionIdGenerator:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$Companion;

    .line 6
    .line 7
    const-string v0, "330bd45681a06ad240322862d206c0be"

    .line 8
    .line 9
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->FALCO_CLIENT_TOKEN:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>()V
    .locals 9

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v8, Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

    .line 4
    .line 5
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v8, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->appInfoProvider:Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

    .line 9
    .line 10
    const v0, 0x10028

    .line 11
    .line 12
    .line 13
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics;

    .line 18
    .line 19
    iget-object v7, v0, Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics;->provider:LX/H6G;

    .line 20
    .line 21
    iput-object v7, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->deviceInfoProvider:LX/H6G;

    .line 22
    .line 23
    new-instance v5, Lcom/facebook/aura/analytics/impl/UserConsentStateProvider;

    .line 24
    .line 25
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v5, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->consentStateProvider:LX/H3K;

    .line 29
    .line 30
    new-instance v0, Lcom/facebook/aura/analytics/impl/HatchModeStateProvider;

    .line 31
    .line 32
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->modeStateProvider:LX/H5t;

    .line 36
    .line 37
    sget-object v2, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    const/4 v0, 0x1

    .line 41
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;->getInstance(ZZ)Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    iput-object v4, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->sessionIdGenerator:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 46
    .line 47
    new-instance v3, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$analyticsEventListener$1;

    .line 48
    .line 49
    invoke-direct {v3}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$analyticsEventListener$1;-><init>()V

    .line 50
    .line 51
    .line 52
    iput-object v3, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->analyticsEventListener:LX/H5v;

    .line 53
    .line 54
    invoke-static {}, LX/EYt;->A0B()Landroid/content/Context;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    new-instance v2, LX/H4B;

    .line 59
    .line 60
    invoke-direct {v2, v0}, LX/H4B;-><init>(Landroid/content/Context;)V

    .line 61
    .line 62
    .line 63
    iput-object v2, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 64
    .line 65
    invoke-static {}, LX/Fna;->A03()Z

    .line 66
    .line 67
    .line 68
    move-result v6

    .line 69
    const v0, 0x10027

    .line 70
    .line 71
    .line 72
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory;

    .line 77
    .line 78
    iput-object v8, v2, LX/H4B;->A0A:Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

    .line 79
    .line 80
    iput-object v7, v2, LX/H4B;->A0D:LX/H6G;

    .line 81
    .line 82
    const v0, 0x10024

    .line 83
    .line 84
    .line 85
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    check-cast v0, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;

    .line 90
    .line 91
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;->instance:LX/FiW;

    .line 92
    .line 93
    iput-object v0, v2, LX/H4B;->A06:LX/FiW;

    .line 94
    .line 95
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;

    .line 96
    .line 97
    iput-object v0, v2, LX/H4B;->A03:LX/B9T;

    .line 98
    .line 99
    if-nez v6, :cond_1

    .line 100
    .line 101
    invoke-virtual {v1}, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory;->createPrimaryPigeonSamplingPolicy()LX/H4b;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    :goto_0
    iput-object v0, v2, LX/H4B;->A0C:LX/H5D;

    .line 106
    .line 107
    const v0, 0x10029

    .line 108
    .line 109
    .line 110
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    const-class v0, Lcom/facebook/aura/analytics/impl/AuraSamplingPolicyConfig;

    .line 114
    .line 115
    iput-object v0, v2, LX/H4B;->A0E:Ljava/lang/Class;

    .line 116
    .line 117
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaPrivacyContextProvider;

    .line 118
    .line 119
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 120
    .line 121
    .line 122
    iput-object v0, v2, LX/H4B;->A0B:Lcom/facebook/aura/analytics/impl/MetaPrivacyContextProvider;

    .line 123
    .line 124
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;

    .line 125
    .line 126
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;-><init>()V

    .line 127
    .line 128
    .line 129
    iput-object v0, v2, LX/H4B;->A07:LX/H4S;

    .line 130
    .line 131
    const-class v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsUploader;

    .line 132
    .line 133
    iput-object v0, v2, LX/H4B;->A0F:Ljava/lang/Class;

    .line 134
    .line 135
    iput-object v5, v2, LX/H4B;->A02:LX/H3K;

    .line 136
    .line 137
    iput-object v3, v2, LX/H4B;->A04:LX/H5v;

    .line 138
    .line 139
    if-eqz v4, :cond_0

    .line 140
    .line 141
    iput-object v4, v2, LX/H4B;->A05:LX/H3L;

    .line 142
    .line 143
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$ffdbProvider$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$ffdbProvider$1;

    .line 144
    .line 145
    iput-object v0, v2, LX/H4B;->A0H:LX/0RE;

    .line 146
    .line 147
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->maybeSetRegularPriorityUploadSchedulerParamsProvider()V

    .line 148
    .line 149
    .line 150
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->maybeSetHighPriorityUploadSchedulerParamsProvider()V

    .line 151
    .line 152
    .line 153
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->maybeEnableOneFabric()LX/H5U;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->createHealthCounterLoggerProvider(LX/H5U;)LX/H4w;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    iput-object v0, v2, LX/H4B;->A01:LX/H4w;

    .line 162
    .line 163
    return-void

    .line 164
    :cond_1
    new-instance v0, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory$createE2ESamplingPolicy$1;

    .line 165
    .line 166
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory$createE2ESamplingPolicy$1;-><init>()V

    .line 167
    .line 168
    .line 169
    goto :goto_0
.end method

.method public static final synthetic access$createFFA2UploadConfiguration(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;)LX/H5k;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->createFFA2UploadConfiguration()LX/H5k;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$createHealthCounterLoggerProvider$lambda$0(Lkotlin/Lazy;)Z
    .locals 0

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final synthetic access$createHealthCounterLoggerProvider$lambda$1(Lkotlin/Lazy;)Z
    .locals 0

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final synthetic access$createHealthCounterLoggerProvider$lambda$2(Lkotlin/Lazy;)LX/H5M;
    .locals 0

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/H5M;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$getBaseFilePath(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->getBaseFilePath()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final createFFA2UploadConfiguration()LX/H5k;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->uploadConfigInstance:LX/H5k;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->FALCO_CLIENT_TOKEN:Ljava/lang/String;

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/network/AuraUserAgent;->INSTANCE:Lcom/facebook/aura/network/AuraUserAgent;

    .line 7
    .line 8
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v1, v0}, Lcom/facebook/aura/network/AuraUserAgent;->instanceWithoutWaiting(Ljava/util/concurrent/Executor;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    sget-object v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createFFA2UploadConfiguration$uploadConfigNonNull$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createFFA2UploadConfiguration$uploadConfigNonNull$1;

    .line 17
    .line 18
    new-instance v0, LX/H5k;

    .line 19
    .line 20
    invoke-direct {v0, p0, v2, v1}, LX/H5k;-><init>(Ljava/lang/String;Ljava/lang/String;LX/0RE;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->uploadConfigInstance:LX/H5k;

    .line 24
    .line 25
    return-object v0
.end method

.method private final createFFConfigValues()LX/H5r;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->configValueInstance:LX/H5r;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const v0, 0x10026

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->getBaseFilePath()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    new-instance v0, LX/H5r;

    .line 18
    .line 19
    invoke-direct {v0, p0}, LX/H5r;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->configValueInstance:LX/H5r;

    .line 23
    .line 24
    return-object v0
.end method

.method private final createHealthCounterLoggerProvider(LX/H5U;)LX/H4w;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$ffdbProvider$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$ffdbProvider$1;

    .line 1
    .line 2
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$isFfdbEnabled$2;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$isFfdbEnabled$2;-><init>(Lkotlin/Lazy;)V

    .line 9
    .line 10
    .line 11
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$isDebugBuild$2;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$isDebugBuild$2;

    .line 16
    .line 17
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;

    .line 22
    .line 23
    invoke-direct {v0, p0, p1, v2, v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$healthCounterLogger$2;-><init>(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;LX/H5U;Lkotlin/Lazy;Lkotlin/Lazy;)V

    .line 24
    .line 25
    .line 26
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$1;

    .line 31
    .line 32
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$createHealthCounterLoggerProvider$1;-><init>(Lkotlin/Lazy;)V

    .line 33
    .line 34
    .line 35
    return-object v0
.end method

.method public static synthetic createHealthCounterLoggerProvider$default(Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;LX/H5U;ILjava/lang/Object;)LX/H4w;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->createHealthCounterLoggerProvider(LX/H5U;)LX/H4w;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final createHealthCounterLoggerProvider$lambda$0(Lkotlin/Lazy;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final createHealthCounterLoggerProvider$lambda$1(Lkotlin/Lazy;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Lazy<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public static final createHealthCounterLoggerProvider$lambda$2(Lkotlin/Lazy;)LX/H5M;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Lazy<",
            "+",
            "LX/H5M;",
            ">;)",
            "LX/H5M;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/H5M;

    .line 5
    .line 6
    return-object p0
.end method

.method private final getBaseFilePath()Ljava/lang/String;
    .locals 2

    .line 0
    invoke-static {}, LX/EYt;->A0B()Landroid/content/Context;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "fflogger"

    .line 5
    .line 6
    sget-object v0, LX/H57;->A00:LX/9jP;

    .line 7
    .line 8
    invoke-static {p0, v0}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget v0, v0, LX/9jO;->A00:I

    .line 12
    .line 13
    invoke-static {p0, v0}, LX/H1t;->A00(Landroid/content/Context;I)Ljava/io/File;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, LX/EYt;->A0M(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-object v0
.end method

.method public static synthetic getDeviceInfoProvider$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method private final maybeEnableOneFabric()LX/H5U;
    .locals 19

    .line 0
    invoke-static {}, LX/EYt;->A0j()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v11

    .line 4
    sget-object v10, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$identitiesDescriptor$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$identitiesDescriptor$1;

    .line 5
    .line 6
    const-string v0, "4331325740476680"

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 9
    .line 10
    .line 11
    move-result-wide v17

    .line 12
    const-string v13, "18.0.0.8.161"

    .line 13
    .line 14
    invoke-static {}, Lcom/facebook/common/build/BuildConstants;->A01()I

    .line 15
    .line 16
    .line 17
    move-result v15

    .line 18
    move-object/from16 v0, p0

    .line 19
    .line 20
    iget-object v9, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->consentStateProvider:LX/H3K;

    .line 21
    .line 22
    iget-object v8, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->modeStateProvider:LX/H5t;

    .line 23
    .line 24
    const-string v12, ""

    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    new-instance v7, LX/H5Y;

    .line 28
    .line 29
    move-object v14, v12

    .line 30
    move/from16 v16, v1

    .line 31
    .line 32
    invoke-direct/range {v7 .. v18}, LX/H5Y;-><init>(LX/H5t;LX/H3K;Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$identitiesDescriptor$1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIJ)V

    .line 33
    .line 34
    .line 35
    iput-boolean v1, v7, LX/H5Y;->A0A:Z

    .line 36
    .line 37
    const v1, 0x10024

    .line 38
    .line 39
    .line 40
    invoke-static {v1}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v1, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;

    .line 45
    .line 46
    iget-object v9, v1, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;->instance:LX/FiW;

    .line 47
    .line 48
    new-instance v10, Lcom/facebook/aura/analytics/impl/RegularPriUploadSchedulerParamsProvider;

    .line 49
    .line 50
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    new-instance v11, Lcom/facebook/aura/analytics/impl/HighPriUploadSchedulerParamsProvider;

    .line 54
    .line 55
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 56
    .line 57
    .line 58
    const v4, 0x10026

    .line 59
    .line 60
    .line 61
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    iget-wide v12, v1, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->realTimeExemptLatency:J

    .line 66
    .line 67
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    iget-wide v14, v1, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularExemptLatency:J

    .line 72
    .line 73
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    iget-wide v1, v1, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->latencyWindowMultiplier:J

    .line 78
    .line 79
    new-instance v8, LX/FiZ;

    .line 80
    .line 81
    move-wide/from16 v16, v1

    .line 82
    .line 83
    invoke-direct/range {v8 .. v17}, LX/FiZ;-><init>(LX/FiW;LX/Fia;LX/Fia;JJJ)V

    .line 84
    .line 85
    .line 86
    new-instance v9, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;

    .line 87
    .line 88
    invoke-direct {v9, v8}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;-><init>(LX/FiZ;)V

    .line 89
    .line 90
    .line 91
    const-string v1, "one-fabric-event-handler"

    .line 92
    .line 93
    new-instance v3, Landroid/os/HandlerThread;

    .line 94
    .line 95
    invoke-direct {v3, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 99
    .line 100
    .line 101
    sget-object v2, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 102
    .line 103
    invoke-virtual {v2}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    new-instance v8, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;

    .line 108
    .line 109
    invoke-direct {v8, v1}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;-><init>(Landroid/content/Context;)V

    .line 110
    .line 111
    .line 112
    new-instance v10, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$startupStatusProvider$1;

    .line 113
    .line 114
    invoke-direct {v10}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$startupStatusProvider$1;-><init>()V

    .line 115
    .line 116
    .line 117
    invoke-static {}, LX/Fna;->A03()Z

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    if-nez v1, :cond_3

    .line 122
    .line 123
    new-instance v14, LX/H5c;

    .line 124
    .line 125
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 126
    .line 127
    .line 128
    :goto_0
    check-cast v14, LX/H5O;

    .line 129
    .line 130
    if-nez v1, :cond_2

    .line 131
    .line 132
    sget-object v18, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$qplConfigHandlerProvider$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$qplConfigHandlerProvider$1;

    .line 133
    .line 134
    :goto_1
    check-cast v18, LX/0RE;

    .line 135
    .line 136
    invoke-virtual {v2}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    invoke-static {}, LX/H4i;->A00()LX/HAi;

    .line 141
    .line 142
    .line 143
    move-result-object v15

    .line 144
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->createFFA2UploadConfiguration()LX/H5k;

    .line 145
    .line 146
    .line 147
    move-result-object v12

    .line 148
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->createFFConfigValues()LX/H5r;

    .line 149
    .line 150
    .line 151
    move-result-object v13

    .line 152
    new-instance v11, LX/H68;

    .line 153
    .line 154
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v3}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 158
    .line 159
    .line 160
    move-result-object v6

    .line 161
    invoke-static {v6}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    sget-object v17, Ljava/util/Collections;->EMPTY_SET:Ljava/util/Set;

    .line 165
    .line 166
    invoke-static/range {v17 .. v17}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    invoke-static {v4}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    invoke-static {v4}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    invoke-static {v4}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    new-instance v2, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 179
    .line 180
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 181
    .line 182
    .line 183
    const-string v1, "graph"

    .line 184
    .line 185
    invoke-virtual {v2, v1}, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;->facebookAuthority(Ljava/lang/String;)Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v16

    .line 189
    new-instance v4, LX/H5U;

    .line 190
    .line 191
    invoke-direct/range {v4 .. v18}, LX/H5U;-><init>(Landroid/content/Context;Landroid/os/Looper;LX/H5Y;Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$latencyResolver$1;Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$startupStatusProvider$1;LX/H68;LX/H5k;LX/H5r;LX/H5O;LX/HAi;Ljava/lang/String;Ljava/util/Set;LX/0RE;)V

    .line 192
    .line 193
    .line 194
    sget-object v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;

    .line 195
    .line 196
    invoke-virtual {v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;->provideBootstrappedPigeonIdentity()LX/H5X;

    .line 197
    .line 198
    .line 199
    move-result-object v3

    .line 200
    const-string v2, "MetaAnalyticsBuilder"

    .line 201
    .line 202
    if-eqz v3, :cond_1

    .line 203
    .line 204
    invoke-virtual {v3, v7}, LX/H5X;->addFieldsToIdentityDescriptor(LX/H5Y;)V

    .line 205
    .line 206
    .line 207
    :goto_2
    iget-object v1, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->sessionIdGenerator:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 208
    .line 209
    if-eqz v1, :cond_0

    .line 210
    .line 211
    invoke-virtual {v1}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->provideSessionId()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    new-instance v1, LX/H3G;

    .line 216
    .line 217
    invoke-direct {v1, v3, v2}, LX/H3G;-><init>(LX/H5X;Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v4, v1}, LX/H5U;->Agf(LX/H3G;)V

    .line 221
    .line 222
    .line 223
    :cond_0
    iget-object v1, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->analyticsEventListener:LX/H5v;

    .line 224
    .line 225
    iput-object v1, v4, LX/H5U;->A0J:LX/H5v;

    .line 226
    .line 227
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 228
    .line 229
    iput-object v4, v0, LX/H4B;->A00:LX/H4o;

    .line 230
    .line 231
    sget-object v2, Lcom/facebook/aura/analytics/AnalyticsUploadHold;->INSTANCE:Lcom/facebook/aura/analytics/AnalyticsUploadHold;

    .line 232
    .line 233
    new-instance v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$1;

    .line 234
    .line 235
    invoke-direct {v1, v4}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$1;-><init>(Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$2;

    .line 239
    .line 240
    invoke-direct {v0, v4}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$2;-><init>(Ljava/lang/Object;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/analytics/AnalyticsUploadHold;->attach(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 244
    .line 245
    .line 246
    return-object v4

    .line 247
    :cond_1
    const-string v1, "Failed to bootstrap Pigeon Identity"

    .line 248
    .line 249
    invoke-static {v2, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    goto :goto_2

    .line 253
    :cond_2
    sget-object v18, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$qplConfigHandlerProvider$2;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$qplConfigHandlerProvider$2;

    .line 254
    .line 255
    goto :goto_1

    .line 256
    :cond_3
    new-instance v14, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$samplingPolicy$1;

    .line 257
    .line 258
    invoke-direct {v14}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$samplingPolicy$1;-><init>()V

    .line 259
    .line 260
    .line 261
    goto/16 :goto_0
.end method

.method private final maybeSetHighPriorityUploadSchedulerParamsProvider()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/impl/HighPriUploadSchedulerParamsProvider;

    .line 3
    .line 4
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object v0, p0, LX/H4B;->A08:LX/Fia;

    .line 8
    .line 9
    return-void
.end method

.method private final maybeSetRegularPriorityUploadSchedulerParamsProvider()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/analytics/impl/RegularPriUploadSchedulerParamsProvider;

    .line 3
    .line 4
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object v0, p0, LX/H4B;->A09:LX/Fia;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final build()LX/H4A;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder;->builder:LX/H4B;

    .line 1
    .line 2
    new-instance v0, LX/H4A;

    .line 3
    .line 4
    invoke-direct {v0, p0}, LX/H4A;-><init>(LX/H4B;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method
