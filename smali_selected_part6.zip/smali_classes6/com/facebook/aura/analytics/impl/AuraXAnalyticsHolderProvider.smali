.class public final Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;

.field public static final holder:Lcom/facebook/xanalytics/XAnalyticsHolder;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;->INSTANCE:Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider$holder$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider$holder$1;

    .line 8
    .line 9
    new-instance v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->xAnalyticsAdapter:Lcom/facebook/xanalytics/XAnalyticsAdapterHolder;

    .line 15
    .line 16
    sput-object v0, Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;->holder:Lcom/facebook/xanalytics/XAnalyticsHolder;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getHolder()Lcom/facebook/xanalytics/XAnalyticsHolder;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/impl/AuraXAnalyticsHolderProvider;->holder:Lcom/facebook/xanalytics/XAnalyticsHolder;

    .line 1
    .line 2
    return-object p0
.end method
