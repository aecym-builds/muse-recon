.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$analyticsEventListener$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H5v;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onEventReceived()V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    filled-new-array {v1}, [I

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    aget v0, v0, v1

    .line 6
    .line 7
    :try_start_0
    invoke-static {v0}, LX/Apn;->A0X(I)V

    .line 8
    .line 9
    .line 10
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    :catch_0
    move-exception p0

    .line 12
    const-string v1, "Analytics event listener failed"

    .line 13
    .line 14
    const-string v0, "MetaAnalyticsBuilder"

    .line 15
    .line 16
    invoke-static {v0, v1, p0}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public onEventsWritten(I)V
    .locals 0

    .line 0
    return-void
.end method
