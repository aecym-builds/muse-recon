.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/B9U;
.implements LX/H3L;


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;

.field public static final SESSION_ID_PREFIX:Ljava/lang/String; = "UFS"

.field public static instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;


# instance fields
.field public appState:LX/H3N;

.field public processId:Ljava/lang/String;

.field public sequenceId:I

.field public final updateSessionIdOnBgFg:Z

.field public final updateSessionIdOnUserChange:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->Companion:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(ZZ)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-boolean p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->updateSessionIdOnUserChange:Z

    .line 268435460
    .line 268435461
    iput-boolean p2, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->updateSessionIdOnBgFg:Z

    .line 268435462
    .line 268435463
    invoke-static {}, LX/FuL;->A00()Ljava/lang/String;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object v0

    .line 268435467
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->processId:Ljava/lang/String;

    .line 268435468
    .line 268435469
    sget-object v0, LX/H3N;->A02:LX/H3N;

    .line 268435470
    .line 268435471
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->appState:LX/H3N;

    .line 268435472
    .line 268435473
    return-void
.end method

.method public synthetic constructor <init>(ZZLX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;-><init>(ZZ)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getInstance$cp()Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getSESSION_ID_PREFIX$cp()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->SESSION_ID_PREFIX:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$setInstance$cp(Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;)V
    .locals 0

    .line 0
    sput-object p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 1
    .line 2
    return-void
.end method

.method public static synthetic getProcessId$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic getSequenceId$annotations()V
    .locals 0

    .line 0
    return-void
.end method


# virtual methods
.method public synthetic clientModeStateChanged()V
    .locals 0

    .line 0
    return-void
.end method

.method public final getProcessId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->processId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSequenceId()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 1
    .line 2
    return p0
.end method

.method public declared-synchronized onBackground()V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->updateSessionIdOnBgFg:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 6
    .line 7
    add-int/lit8 v0, v0, 0x1

    .line 8
    .line 9
    iput v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 10
    .line 11
    sget-object v0, LX/H3N;->A01:LX/H3N;

    .line 12
    .line 13
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->appState:LX/H3N;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    :cond_0
    monitor-exit p0

    .line 16
    return-void

    .line 17
    :catchall_0
    move-exception v0

    .line 18
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 19
    throw v0
.end method

.method public declared-synchronized onForeground()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->updateSessionIdOnBgFg:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->appState:LX/H3N;

    .line 6
    .line 7
    sget-object v1, LX/H3N;->A02:LX/H3N;

    .line 8
    .line 9
    if-eq v0, v1, :cond_0

    .line 10
    .line 11
    iget v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 12
    .line 13
    add-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    iput v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 16
    .line 17
    iput-object v1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->appState:LX/H3N;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    .line 19
    :cond_0
    monitor-exit p0

    .line 20
    return-void

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 23
    throw v0
.end method

.method public declared-synchronized provideSessionId()Ljava/lang/String;
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->SESSION_ID_PREFIX:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    .line 9
    .line 10
    const-string v1, "-"

    .line 11
    .line 12
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->processId:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->appState:LX/H3N;

    .line 24
    .line 25
    iget-object v0, v0, LX/H3N;->mValue:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    iget v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 34
    .line 35
    invoke-static {v2, v0}, LX/002;->A12(Ljava/lang/StringBuilder;I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    monitor-exit p0

    .line 40
    return-object v0

    .line 41
    :catchall_0
    move-exception v0

    .line 42
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 43
    throw v0
.end method

.method public final setProcessId(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->processId:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method public final setSequenceId(I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 1
    .line 2
    return-void
.end method

.method public userConsentChanged()V
    .locals 0

    .line 0
    return-void
.end method

.method public declared-synchronized userLogin(LX/H5X;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->updateSessionIdOnUserChange:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I

    .line 6
    .line 7
    add-int/lit8 v0, v0, 0x1

    .line 8
    .line 9
    iput v0, p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->sequenceId:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    :cond_0
    monitor-exit p0

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 15
    throw v0
.end method

.method public userLogout()V
    .locals 0

    .line 0
    return-void
.end method
