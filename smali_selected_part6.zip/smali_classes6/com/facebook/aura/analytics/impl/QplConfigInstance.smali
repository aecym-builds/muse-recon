.class public final Lcom/facebook/aura/analytics/impl/QplConfigInstance;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public backingInstance:LX/H7E;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getInstance()LX/H7E;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance;->backingInstance:LX/H7E;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    return-object p0

    .line 5
    :cond_0
    invoke-static {}, LX/006;->A0p()Ljava/lang/IllegalStateException;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    throw p0
.end method

.method public final getServerSamplingPolicyUpdater()Ljava/lang/Class;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "+",
            "Lcom/facebook/flexiblesampling/QPLSupportedSamplingPolicyConfig;",
            ">;"
        }
    .end annotation

    .line 0
    const-class p0, Lcom/facebook/aura/analytics/impl/AuraSamplingPolicyConfig;

    .line 1
    .line 2
    return-object p0
.end method

.method public final init(Landroid/content/Context;)V
    .locals 15

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object/from16 v3, p1

    .line 2
    .line 3
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance;->backingInstance:LX/H7E;

    .line 7
    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    new-instance v2, LX/H5E;

    .line 11
    .line 12
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    const v0, 0x10020

    .line 16
    .line 17
    .line 18
    invoke-static {v0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lcom/facebook/quicklog/QuickPerformanceLoggerGKs;

    .line 23
    .line 24
    invoke-interface {v1}, Lcom/facebook/quicklog/QuickPerformanceLoggerGKs;->isAppIdBasedConfigWithSamplingFallbackEnabled()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-interface {v1}, Lcom/facebook/quicklog/QuickPerformanceLoggerGKs;->isSamplingFallbackEnabled()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    sget-object v0, LX/I61;->A01:Lkotlin/Lazy;

    .line 37
    .line 38
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_0

    .line 47
    .line 48
    new-instance v6, LX/I61;

    .line 49
    .line 50
    invoke-direct {v6}, LX/I61;-><init>()V

    .line 51
    .line 52
    .line 53
    :goto_0
    new-instance v5, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;

    .line 54
    .line 55
    invoke-direct {v5}, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;-><init>()V

    .line 56
    .line 57
    .line 58
    new-instance v9, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;

    .line 59
    .line 60
    invoke-direct {v9, v3}, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;-><init>(Landroid/content/Context;)V

    .line 61
    .line 62
    .line 63
    sget-object v10, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$3;

    .line 64
    .line 65
    sget-object v11, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$4;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$4;

    .line 66
    .line 67
    sget-object v12, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$5;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$5;

    .line 68
    .line 69
    sget-object v13, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$6;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$6;

    .line 70
    .line 71
    new-instance v14, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$7;

    .line 72
    .line 73
    invoke-direct {v14, v2}, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$7;-><init>(LX/H5E;)V

    .line 74
    .line 75
    .line 76
    sget-object v2, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$8;->INSTANCE:Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$8;

    .line 77
    .line 78
    new-instance v7, LX/H64;

    .line 79
    .line 80
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 81
    .line 82
    .line 83
    new-instance v8, Ljava/util/Random;

    .line 84
    .line 85
    invoke-direct {v8}, Ljava/util/Random;-><init>()V

    .line 86
    .line 87
    .line 88
    sget-object v3, Lcom/facebook/common/time/AwakeTimeSinceBootClock;->INSTANCE:Lcom/facebook/common/time/AwakeTimeSinceBootClock;

    .line 89
    .line 90
    invoke-static {}, LX/H4i;->A00()LX/HAi;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    new-instance v1, LX/H7E;

    .line 95
    .line 96
    invoke-direct/range {v1 .. v14}, LX/H7E;-><init>(Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$8;Lcom/facebook/common/time/AwakeTimeSinceBootClock;LX/HAi;LX/H5s;LX/I61;LX/H6N;Ljava/util/Random;LX/0RE;LX/0RE;LX/0RE;LX/0RE;LX/0RE;LX/0RE;)V

    .line 97
    .line 98
    .line 99
    sget-object v0, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->INSTANCE:Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->setFFLoggerQplConfig(LX/H7E;)V

    .line 102
    .line 103
    .line 104
    iput-object v1, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance;->backingInstance:LX/H7E;

    .line 105
    .line 106
    return-void

    .line 107
    :cond_0
    const/4 v6, 0x0

    .line 108
    goto :goto_0

    .line 109
    :cond_1
    const-string v0, "init called multiple times"

    .line 110
    .line 111
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    throw v0
.end method
