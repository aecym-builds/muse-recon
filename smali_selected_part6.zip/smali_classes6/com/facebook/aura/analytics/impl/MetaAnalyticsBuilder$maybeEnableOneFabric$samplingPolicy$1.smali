.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$samplingPolicy$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H5O;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public shouldLog(Ljava/lang/String;LX/H5Y;)LX/H4c;
    .locals 0

    .line 0
    invoke-static {}, LX/H4c;->A00()LX/H4c;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
