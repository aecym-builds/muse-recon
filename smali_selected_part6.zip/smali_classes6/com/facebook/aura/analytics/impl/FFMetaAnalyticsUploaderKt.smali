.class public abstract Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploaderKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONTENT_ENCODING_HEADER:Ljava/lang/String; = "Content-Encoding"

.field public static final CONTENT_TYPE_HEADER:Ljava/lang/String; = "Content-Type"

.field public static final DEIDENTIFIED_HEADER:Ljava/lang/String; = "X-FB-Falco-Deidentified"

.field public static final DEIDENTIFIED_HEADER_VALUE:Ljava/lang/String; = "1"

.field public static final FALCO_CLIENT_TOKEN:Ljava/lang/String; = "4331325740476680|330bd45681a06ad240322862d206c0be"

.field public static final FB_API_CALLER_CLASS_HEADER:Ljava/lang/String; = "fb_api_caller_class"

.field public static final FB_API_REQ_FRIENDLY_NAME_HEADER:Ljava/lang/String; = "fb_api_req_friendly_name"

.field public static final GZIP_ENCODING:Ljava/lang/String; = "gzip"

.field public static final TAG:Ljava/lang/String; = "FFMetaAnalyticsUploader"

.field public static final USER_AGENT_HEADER:Ljava/lang/String; = "User-Agent"


# direct methods
.method public static final synthetic access$getFALCO_CLIENT_TOKEN$p()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploaderKt;->FALCO_CLIENT_TOKEN:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method
