.class public final Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$processJson(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;Ljava/lang/String;Ljava/lang/String;LX/H49;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;->processJson(Ljava/lang/String;Ljava/lang/String;LX/H49;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final processJson(Ljava/lang/String;Ljava/lang/String;LX/H49;)V
    .locals 5

    .line 0
    const-string v3, "AuraXNativeHolderProvider"

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    :try_start_0
    const-string v0, "UTF8"

    .line 4
    .line 5
    invoke-static {v0}, LX/I1c;->A0Q(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, LX/EYt;->A0K([B)Ljava/io/ByteArrayInputStream;

    .line 14
    .line 15
    .line 16
    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/AssertionError; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :try_start_1
    new-instance v0, Ljava/io/InputStreamReader;

    .line 18
    .line 19
    invoke-direct {v0, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 20
    .line 21
    .line 22
    new-instance v4, Landroid/util/JsonReader;

    .line 23
    .line 24
    invoke-direct {v4, v0}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 25
    .line 26
    .line 27
    :try_start_2
    invoke-virtual {p3}, LX/H49;->A04()LX/GFv;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v4}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    sget-object v0, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 42
    .line 43
    if-ne v1, v0, :cond_0

    .line 44
    .line 45
    invoke-virtual {v4}, Landroid/util/JsonReader;->beginObject()V

    .line 46
    .line 47
    .line 48
    sget-object v0, LX/GFq;->A00:LX/GFq;

    .line 49
    .line 50
    invoke-static {v4, v2, v0}, LX/GFq;->A01(Landroid/util/JsonReader;LX/GFv;LX/GFq;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 51
    .line 52
    .line 53
    :cond_0
    :try_start_3
    invoke-virtual {v4}, Landroid/util/JsonReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 54
    .line 55
    .line 56
    :try_start_4
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 57
    .line 58
    .line 59
    return-void
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/AssertionError; {:try_start_4 .. :try_end_4} :catch_0

    .line 60
    :catchall_0
    move-exception v1

    .line 61
    :try_start_5
    throw v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 62
    :catchall_1
    move-exception v0

    .line 63
    :try_start_6
    invoke-static {v4, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 64
    .line 65
    .line 66
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 67
    :catchall_2
    move-exception v1

    .line 68
    :try_start_7
    throw v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 69
    :catchall_3
    move-exception v0

    .line 70
    :try_start_8
    invoke-static {p0, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    throw v0
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_1
    .catch Ljava/lang/AssertionError; {:try_start_8 .. :try_end_8} :catch_0

    .line 74
    :catch_0
    move-exception v2

    .line 75
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    const-string v0, "AssertionError from JsonReader.peek() for : %s "

    .line 80
    .line 81
    invoke-static {v3, v0, v2, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    throw v2

    .line 85
    :catch_1
    move-exception v2

    .line 86
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    const-string v0, "IOException from processJson : %s "

    .line 91
    .line 92
    invoke-static {v3, v0, v2, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    return-void
.end method
