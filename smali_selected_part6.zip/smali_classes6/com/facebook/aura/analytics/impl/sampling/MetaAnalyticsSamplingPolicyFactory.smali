.class public final Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final createE2ESamplingPolicy()LX/H5D;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory$createE2ESamplingPolicy$1;

    .line 1
    .line 2
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/sampling/MetaAnalyticsSamplingPolicyFactory$createE2ESamplingPolicy$1;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public final createPrimaryPigeonSamplingPolicy()LX/H4b;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ANALYTICS_SAMPLING_POLICY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    new-instance v0, LX/H4b;

    .line 9
    .line 10
    invoke-direct {v0, p0}, LX/H4b;-><init>(LX/BVu;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final getSamplingPolicyPrefs()LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ANALYTICS_SAMPLING_POLICY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method
