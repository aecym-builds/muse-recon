.class public final Lcom/facebook/aura/analytics/impl/sampling/MetaPrefsSamplingConfigAccessor;
.super LX/I7t;
.source ""


# direct methods
.method public constructor <init>(LX/BVu;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/I7t;-><init>(LX/BVu;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public getCheckSum()Ljava/lang/String;
    .locals 3

    .line 0
    const-string v2, "_checksum"

    .line 1
    .line 2
    const-string v1, ""

    .line 3
    .line 4
    iget-object v0, p0, LX/I7t;->lightSharedPreferences:LX/BVu;

    .line 5
    .line 6
    invoke-interface {v0, v2, v1}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method
