.class public final synthetic Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$2;
.super LX/DVE;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 6

    .line 0
    const-class v3, LX/H5U;

    .line 1
    .line 2
    const-string v5, "onResume()V"

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    const-string v4, "onResume"

    .line 6
    .line 7
    move-object v0, p0

    .line 8
    move-object v2, p1

    .line 9
    move p0, v1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 1

    .line 0
    iget-object v0, p0, LX/DqR;->receiver:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v0, LX/H5U;

    .line 3
    .line 4
    invoke-virtual {v0}, LX/H5U;->A00()V

    .line 5
    .line 6
    .line 7
    iget-object p0, v0, LX/H5U;->A00:LX/H4s;

    .line 8
    .line 9
    if-nez p0, :cond_0

    .line 10
    .line 11
    const-string v0, "eventQueue"

    .line 12
    .line 13
    invoke-static {v0}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    throw v0

    .line 21
    :cond_0
    check-cast p0, LX/H5T;

    .line 22
    .line 23
    iget v0, p0, LX/H5T;->A05:I

    .line 24
    .line 25
    invoke-static {p0, v0}, LX/EYt;->A1K(Landroid/os/Handler;I)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
