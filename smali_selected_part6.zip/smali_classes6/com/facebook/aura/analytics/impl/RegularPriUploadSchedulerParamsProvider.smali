.class public final Lcom/facebook/aura/analytics/impl/RegularPriUploadSchedulerParamsProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/Fia;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getBackgroundParams()LX/FiU;
    .locals 8

    .line 0
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v1, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsSingle:J

    .line 5
    .line 6
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-wide v3, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsSingle:J

    .line 11
    .line 12
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-wide v5, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMinDelayMsBatch:J

    .line 17
    .line 18
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-wide v7, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularBackMaxDelayMsBatch:J

    .line 23
    .line 24
    new-instance v0, LX/FiU;

    .line 25
    .line 26
    invoke-direct/range {v0 .. v8}, LX/FiU;-><init>(JJJJ)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method

.method public getForegroundParams()LX/FiU;
    .locals 8

    .line 0
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v1, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsSingle:J

    .line 5
    .line 6
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-wide v3, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsSingle:J

    .line 11
    .line 12
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-wide v5, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMinDelayMsBatch:J

    .line 17
    .line 18
    invoke-static {}, LX/EYt;->A0H()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-wide v7, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularForeMaxDelayMsBatch:J

    .line 23
    .line 24
    new-instance v0, LX/FiU;

    .line 25
    .line 26
    invoke-direct/range {v0 .. v8}, LX/FiU;-><init>(JJJJ)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method
