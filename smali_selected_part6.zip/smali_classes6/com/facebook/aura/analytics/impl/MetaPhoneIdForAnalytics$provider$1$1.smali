.class public final Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H6G;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaPhoneIdForAnalytics$provider$1$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {}, LX/EYt;->A0j()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
