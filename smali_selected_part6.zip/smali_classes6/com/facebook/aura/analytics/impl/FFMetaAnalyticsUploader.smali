.class public final Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final callerClassName:Ljava/lang/String;

.field public final endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 9
    .line 10
    invoke-static {p0}, LX/002;->A0y(Ljava/lang/Object;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->callerClassName:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method

.method private final buildNestParts([B)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/network/transport/HatchMultipartPart;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    const-string/jumbo v1, "thrift_protocol"

    .line 5
    .line 6
    .line 7
    const-string v0, "compact"

    .line 8
    .line 9
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->stringPart(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    const-string v1, "cmethod"

    .line 17
    .line 18
    const-string v0, "gzip"

    .line 19
    .line 20
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->stringPart(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    const-string v3, "message"

    .line 28
    .line 29
    const-string v2, "application/octet-stream"

    .line 30
    .line 31
    const-string v1, "cmsg"

    .line 32
    .line 33
    new-instance v0, Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 34
    .line 35
    invoke-direct {v0, v1, v3, v2, p1}, Lcom/facebook/aura/network/transport/HatchMultipartPart;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    const-string v1, "access_token"

    .line 42
    .line 43
    sget-object v0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploaderKt;->FALCO_CLIENT_TOKEN:Ljava/lang/String;

    .line 44
    .line 45
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->stringPart(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    invoke-static {v4}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    return-object v0
.end method

.method private final buildRequest([BZZ)Lcom/facebook/aura/network/transport/HatchHttpRequest;
    .locals 15

    .line 0
    const/4 v4, 0x3

    .line 1
    sget-object v0, Lcom/facebook/aura/network/AuraUserAgent;->fullUserAgent:Lkotlin/Lazy;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const-string v0, "User-Agent"

    .line 8
    .line 9
    invoke-static {v0, v1}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    const/4 v12, 0x0

    .line 14
    const-string v1, "fb_api_req_friendly_name"

    .line 15
    .line 16
    const-string/jumbo v0, "sendAnalyticsLog"

    .line 17
    .line 18
    .line 19
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v14, 0x1

    .line 24
    const-string v1, "fb_api_caller_class"

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->callerClassName:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    filled-new-array {v3, v2, v0}, [LX/IBK;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0, v4}, LX/EYu;->A0u([LX/IBK;I)Ljava/util/LinkedHashMap;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    if-eqz p3, :cond_0

    .line 41
    .line 42
    const-string v1, "X-FB-Falco-Deidentified"

    .line 43
    .line 44
    const-string v0, "1"

    .line 45
    .line 46
    invoke-virtual {v5, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_0
    sget-object v2, Lcom/facebook/aura/network/transport/HatchHttpRequest;->Companion:Lcom/facebook/aura/network/transport/HatchHttpRequest$Companion;

    .line 50
    .line 51
    move-object/from16 v1, p1

    .line 52
    .line 53
    if-eqz p2, :cond_1

    .line 54
    .line 55
    invoke-direct {p0, v14}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->endpointUrl(Z)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    const-string v0, "application/json"

    .line 60
    .line 61
    new-instance v4, Lcom/facebook/aura/network/transport/HatchRequestBody$Bytes;

    .line 62
    .line 63
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/network/transport/HatchRequestBody$Bytes;-><init>([BLjava/lang/String;)V

    .line 64
    .line 65
    .line 66
    const-string v1, "Content-Encoding"

    .line 67
    .line 68
    const-string v0, "gzip"

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-static {v5, v0}, LX/1HA;->A0F(Ljava/util/Map;LX/IBK;)Ljava/util/Map;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    const/4 v6, 0x0

    .line 79
    :goto_0
    sget-object v9, Lcom/facebook/aura/network/transport/HatchRequestCategory;->API:Lcom/facebook/aura/network/transport/HatchRequestCategory;

    .line 80
    .line 81
    sget-object v10, Lcom/facebook/aura/network/transport/HatchRequestPurpose;->FETCH:Lcom/facebook/aura/network/transport/HatchRequestPurpose;

    .line 82
    .line 83
    sget-object p0, Lcom/facebook/aura/network/transport/HatchResponseBodyPolicy;->DEFAULT:Lcom/facebook/aura/network/transport/HatchResponseBodyPolicy;

    .line 84
    .line 85
    move-object v7, v6

    .line 86
    move-object v8, v6

    .line 87
    move-object v11, v6

    .line 88
    move v13, v12

    .line 89
    move-object/from16 p1, v6

    .line 90
    .line 91
    move/from16 p2, v12

    .line 92
    .line 93
    move/from16 p3, v14

    .line 94
    .line 95
    invoke-virtual/range {v2 .. v18}, Lcom/facebook/aura/network/transport/HatchHttpRequest$Companion;->post(Ljava/lang/String;Lcom/facebook/aura/network/transport/HatchRequestBody;Ljava/util/Map;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/network/transport/HatchRequestCategory;Lcom/facebook/aura/network/transport/HatchRequestPurpose;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;ZZZLcom/facebook/aura/network/transport/HatchResponseBodyPolicy;Lcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZZ)Lcom/facebook/aura/network/transport/HatchHttpRequest;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    return-object v0

    .line 100
    :cond_1
    invoke-direct {p0, v12}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->endpointUrl(Z)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    invoke-direct {p0, v1}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->buildNestParts([B)Ljava/util/List;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    const/4 v6, 0x0

    .line 109
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 110
    .line 111
    new-instance v4, Lcom/facebook/aura/network/transport/HatchRequestBody$Multipart;

    .line 112
    .line 113
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/network/transport/HatchRequestBody$Multipart;-><init>(Ljava/util/List;Ljava/util/List;)V

    .line 114
    .line 115
    .line 116
    goto :goto_0
.end method

.method private final endpointUrl(Z)Ljava/lang/String;
    .locals 4

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    const-string v3, "/pigeon_health_metrics"

    .line 3
    .line 4
    :goto_0
    new-instance v1, Landroid/net/Uri$Builder;

    .line 5
    .line 6
    invoke-direct {v1}, Landroid/net/Uri$Builder;-><init>()V

    .line 7
    .line 8
    .line 9
    const-string v0, "https"

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget-object v1, p0, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->endpointSelector:Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;

    .line 16
    .line 17
    const-string v0, "graph"

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Lcom/facebook/aura/network/endpoint/AuraAnalyticsEndpointSelector;->facebookAuthority(Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v2, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0, v3}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-static {v0}, LX/006;->A15(Ljava/lang/Object;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    return-object v0

    .line 40
    :cond_0
    const-string v3, "/pigeon_nest"

    .line 41
    .line 42
    goto :goto_0
.end method

.method private final stringPart(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;
    .locals 3

    .line 0
    invoke-static {p2}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const/4 v2, 0x0

    .line 5
    const-string/jumbo v1, "text/plain"

    .line 6
    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 9
    .line 10
    invoke-direct {v0, p1, v2, v1, p0}, Lcom/facebook/aura/network/transport/HatchMultipartPart;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method


# virtual methods
.method public doUpload([BLX/FqK;Z)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->doUpload([BLX/FqK;ZZ)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public doUpload([BLX/FqK;ZZ)V
    .locals 6

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v5

    .line 268435460
    invoke-direct {p0, p1, p3, p4}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader;->buildRequest([BZZ)Lcom/facebook/aura/network/transport/HatchHttpRequest;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v2

    .line 268435464
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object v4

    .line 268435468
    const-string v3, "FFMetaAnalyticsUploader"

    .line 268435469
    .line 268435470
    :try_start_0
    const/4 v0, 0x0

    .line 268435471
    new-instance v1, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader$doUpload$response$1;

    .line 268435472
    .line 268435473
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/analytics/impl/FFMetaAnalyticsUploader$doUpload$response$1;-><init>(Lcom/facebook/aura/network/transport/HatchHttpRequest;LX/2M4;)V

    .line 268435474
    .line 268435475
    .line 268435476
    sget-object v0, LX/39s;->A00:LX/39s;

    .line 268435477
    .line 268435478
    invoke-static {v0, v1}, LX/DRR;->A00(LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 268435479
    .line 268435480
    .line 268435481
    move-result-object v0

    .line 268435482
    check-cast v0, Lcom/facebook/aura/network/transport/HatchHttpResponse;

    .line 268435483
    .line 268435484
    invoke-virtual {v0}, Lcom/facebook/aura/network/transport/HatchHttpResponse;->body()Lcom/facebook/aura/network/transport/HatchHttpResponseBody;

    .line 268435485
    .line 268435486
    .line 268435487
    move-result-object v2

    .line 268435488
    iget-boolean v0, v0, Lcom/facebook/aura/network/transport/HatchHttpResponse;->isSuccessful:Z

    .line 268435489
    .line 268435490
    if-eqz v0, :cond_2

    .line 268435491
    .line 268435492
    if-eqz v2, :cond_2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .line 268435493
    .line 268435494
    :try_start_1
    iget-object v1, v2, Lcom/facebook/aura/network/transport/HatchHttpResponseBody;->stream:Ljava/io/InputStream;

    .line 268435495
    .line 268435496
    move-object v0, p2

    .line 268435497
    check-cast v0, LX/FqH;

    .line 268435498
    .line 268435499
    if-nez p3, :cond_1

    .line 268435500
    .line 268435501
    iget-object v0, v0, LX/FqH;->A00:LX/H5U;

    .line 268435502
    .line 268435503
    iget-object v0, v0, LX/H5U;->A00:LX/H4s;

    .line 268435504
    .line 268435505
    if-nez v0, :cond_0

    .line 268435506
    .line 268435507
    const-string v0, "eventQueue"

    .line 268435508
    .line 268435509
    invoke-static {v0}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 268435510
    .line 268435511
    .line 268435512
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435513
    .line 268435514
    .line 268435515
    move-result-object v0

    .line 268435516
    throw v0

    .line 268435517
    :cond_0
    check-cast v0, LX/H5T;

    .line 268435518
    .line 268435519
    iget-object v0, v0, LX/H5T;->A0D:Ljava/lang/Object;

    .line 268435520
    .line 268435521
    monitor-enter v0

    .line 268435522
    monitor-exit v0

    .line 268435523
    :cond_1
    invoke-static {v5, v1, p3}, Lcom/facebook/falco/sampling/FFSamplingBridgeJava;->onUploadComplete(ZLjava/io/InputStream;Z)V

    .line 268435524
    .line 268435525
    .line 268435526
    return-void
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 268435527
    :catchall_0
    move-exception v1

    .line 268435528
    :try_start_2
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 268435529
    :catchall_1
    move-exception v0

    .line 268435530
    :try_start_3
    invoke-static {v2, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 268435531
    .line 268435532
    .line 268435533
    throw v0

    .line 268435534
    :cond_2
    invoke-interface {p2, p3}, LX/FqK;->ATV(Z)V

    .line 268435535
    .line 268435536
    .line 268435537
    return-void
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_0

    .line 268435538
    :catch_0
    move-exception v2

    .line 268435539
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 268435540
    .line 268435541
    .line 268435542
    move-result-object v1

    .line 268435543
    const-string v0, "Upload OOM: isHC=%b"

    .line 268435544
    .line 268435545
    invoke-static {v3, v0, v2, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 268435546
    .line 268435547
    .line 268435548
    invoke-interface {p2, p3}, LX/FqK;->ATV(Z)V

    .line 268435549
    .line 268435550
    .line 268435551
    return-void

    .line 268435552
    :catch_1
    move-exception v2

    .line 268435553
    invoke-static {v2}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 268435554
    .line 268435555
    .line 268435556
    move-result-object v0

    .line 268435557
    filled-new-array {v0, v4}, [Ljava/lang/Object;

    .line 268435558
    .line 268435559
    .line 268435560
    move-result-object v1

    .line 268435561
    const-string v0, "Unexpected upload error: %s isHC=%b"

    .line 268435562
    .line 268435563
    goto :goto_0

    .line 268435564
    :catch_2
    move-exception v2

    .line 268435565
    invoke-static {v2}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 268435566
    .line 268435567
    .line 268435568
    move-result-object v0

    .line 268435569
    filled-new-array {v0, v4}, [Ljava/lang/Object;

    .line 268435570
    .line 268435571
    .line 268435572
    move-result-object v1

    .line 268435573
    const-string v0, "Upload IOException: %s isHC=%b"

    .line 268435574
    .line 268435575
    :goto_0
    invoke-static {v3, v0, v2, v1}, LX/FnY;->A0C(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 268435576
    .line 268435577
    .line 268435578
    invoke-interface {p2, p3}, LX/FqK;->ATV(Z)V

    .line 268435579
    .line 268435580
    .line 268435581
    return-void
.end method
