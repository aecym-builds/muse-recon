.class public final Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$7$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H6M;


# instance fields
.field public final synthetic $consentStateProvider:LX/H5E;


# direct methods
.method public constructor <init>(LX/H5E;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$7$1;->$consentStateProvider:LX/H5E;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public getConsentState()J
    .locals 1

    .line 0
    sget-object v0, LX/H5E;->A00:LX/H3M;

    .line 1
    .line 2
    iget-wide v0, v0, LX/H3M;->A00:J

    .line 3
    .line 4
    return-wide v0
.end method
