.class public final Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H5s;


# instance fields
.field public final executor:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const-string v0, "AuraQPLExecutor"

    .line 7
    .line 8
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/executors/AuraExecutors;->newSingleThreadScheduledExecutor(Ljava/lang/String;Lcom/facebook/aura/executors/NameAndPriorityThreadFactory$ThreadInstanceCreator;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public execute(Ljava/lang/Runnable;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 1
    .line 2
    invoke-interface {p0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final getExecutor()Ljava/util/concurrent/ScheduledExecutorService;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 1
    .line 2
    return-object p0
.end method

.method public schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Z
    .locals 0

    .line 0
    invoke-static {p1, p4}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$1;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 4
    .line 5
    invoke-interface {p0, p1, p2, p3, p4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 6
    .line 7
    .line 8
    const/4 p0, 0x1

    .line 9
    return p0
.end method
