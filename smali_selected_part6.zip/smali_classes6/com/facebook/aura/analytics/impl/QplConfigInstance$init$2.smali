.class public final Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0RE;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/0RE;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final get()LX/I9s;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v0, LX/I9s;

    .line 3
    .line 4
    invoke-direct {v0, p0}, LX/I9s;-><init>(Landroid/content/Context;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 1

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/QplConfigInstance$init$2;->$context:Landroid/content/Context;

    .line 268435457
    .line 268435458
    new-instance v0, LX/I9s;

    .line 268435459
    .line 268435460
    invoke-direct {v0, p0}, LX/I9s;-><init>(Landroid/content/Context;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object v0
.end method
