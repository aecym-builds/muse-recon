.class public final Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/xanalytics/XAnalyticsAdapter;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;->this$0:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public cleanup()V
    .locals 0

    .line 0
    return-void
.end method

.method public flush()V
    .locals 0

    .line 0
    return-void
.end method

.method public getStructureSamplingConfig(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method

.method public logCounter(Ljava/lang/String;D)V
    .locals 0

    .line 268435456
    return-void
.end method

.method public logCounter(Ljava/lang/String;DLjava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public logEvent(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZD)V
    .locals 4

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;->this$0:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;

    .line 6
    .line 7
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, LX/H4A;

    .line 12
    .line 13
    invoke-virtual {v0, p1, p4}, LX/H4A;->A04(Ljava/lang/String;Z)LX/H49;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    invoke-virtual {p0}, LX/H49;->A0A()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    const-wide/16 v2, 0x10

    .line 24
    .line 25
    iget-wide v0, p0, LX/H49;->A03:J

    .line 26
    .line 27
    or-long/2addr v2, v0

    .line 28
    iput-wide v2, p0, LX/H49;->A03:J

    .line 29
    .line 30
    sget-object v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->Companion:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;

    .line 31
    .line 32
    invoke-static {v0, p1, p2, p0}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;->access$processJson(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;Ljava/lang/String;Ljava/lang/String;LX/H49;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, LX/H49;->A05()V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
.end method

.method public logEventBypassSampling(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;->this$0:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, LX/H4A;

    .line 13
    .line 14
    invoke-virtual {v0, p1, v1}, LX/H4A;->A04(Ljava/lang/String;Z)LX/H49;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    const-wide/16 v2, 0x10

    .line 19
    .line 20
    iget-wide v0, p0, LX/H49;->A03:J

    .line 21
    .line 22
    or-long/2addr v2, v0

    .line 23
    iput-wide v2, p0, LX/H49;->A03:J

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->Companion:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;

    .line 26
    .line 27
    invoke-static {v0, p1, p2, p0}, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;->access$processJson(Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$Companion;Ljava/lang/String;Ljava/lang/String;LX/H49;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0}, LX/H49;->A05()V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public shouldLog(Ljava/lang/String;)Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider$xAnalyticsAdapter$1;->this$0:Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/AuraXNativeHolderProvider;->analytics2LoggerProvider:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, LX/H4A;

    .line 13
    .line 14
    iget-object v0, v0, LX/H4A;->A02:LX/H4o;

    .line 15
    .line 16
    invoke-interface {v0, p1}, LX/H4o;->shouldLog(Ljava/lang/String;)LX/H4c;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget p1, v0, LX/H4c;->A00:I

    .line 21
    .line 22
    if-ltz p1, :cond_1

    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    sget-object v0, LX/H4c;->A06:Ljava/util/Random;

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    const/4 p0, 0x1

    .line 36
    :cond_0
    return p0

    .line 37
    :cond_1
    const-string v0, "Not sure how to proceed with negative sampling rate "

    .line 38
    .line 39
    invoke-static {v0, p1}, LX/007;->A0r(Ljava/lang/String;I)Ljava/lang/IllegalArgumentException;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    throw v0
.end method
