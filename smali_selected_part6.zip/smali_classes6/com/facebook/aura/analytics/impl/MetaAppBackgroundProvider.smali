.class public final Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final instance:LX/FiW;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v0, "MetaAppBackgroundProvider"

    .line 4
    .line 5
    invoke-static {v0}, LX/I6a;->A00(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider$instance$1$1;->INSTANCE:Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider$instance$1$1;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    .line 10
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;->instance:LX/FiW;

    .line 14
    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 18
    .line 19
    .line 20
    throw v0
.end method


# virtual methods
.method public final getInstance()LX/FiW;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/impl/MetaAppBackgroundProvider;->instance:LX/FiW;

    .line 1
    .line 2
    return-object p0
.end method
