.class public final Lcom/facebook/aura/analytics/impl/HatchModeStateProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H5t;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getModeState()J
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSession()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p0, :cond_1

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/impl/HatchModeAttribution;->isCvm:LX/2J3;

    .line 9
    .line 10
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-static {}, LX/002;->A0j()Ljava/lang/Boolean;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->Companion:Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;

    .line 25
    .line 26
    invoke-virtual {v0, p0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->isConfidentialVmForAnalyticsMode()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    :cond_0
    sget-object v0, LX/FkO;->A01:Ljava/lang/Integer;

    .line 37
    .line 38
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    const-wide/16 v0, 0x1

    .line 45
    .line 46
    return-wide v0

    .line 47
    :cond_1
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    const-wide/16 v0, 0x0

    .line 51
    .line 52
    return-wide v0
.end method
