.class public final Lcom/facebook/aura/analytics/impl/MetaPrivacyContextProvider;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public provide(Lcom/facebook/logginginfra/falco/PrivacyContext;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/logginginfra/falco/PrivacyContext;
    .locals 3

    .line 0
    const/16 v0, 0x30

    .line 1
    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-eqz p1, :cond_1

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-virtual {p1, v2}, Lcom/facebook/hyperthrift/HyperThriftBase;->A00(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    new-instance v1, LX/H9s;

    .line 16
    .line 17
    invoke-direct {v1, p1}, Lcom/facebook/hyperthrift/HyperThriftBase$Builder;-><init>(Lcom/facebook/hyperthrift/HyperThriftBase;)V

    .line 18
    .line 19
    .line 20
    :goto_0
    iget-object v0, v1, Lcom/facebook/hyperthrift/HyperThriftBase$Builder;->A00:[Ljava/lang/Object;

    .line 21
    .line 22
    aput-object p0, v0, v2

    .line 23
    .line 24
    iget-object p0, v1, Lcom/facebook/hyperthrift/HyperThriftBase$Builder;->A00:[Ljava/lang/Object;

    .line 25
    .line 26
    array-length v2, p0

    .line 27
    new-array v1, v2, [Ljava/lang/Object;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-static {p0, v0, v1, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 31
    .line 32
    .line 33
    new-instance p1, Lcom/facebook/logginginfra/falco/PrivacyContext;

    .line 34
    .line 35
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    const-string v0, "com.facebook.logginginfra.falco.PrivacyContext"

    .line 39
    .line 40
    iput-object v0, p1, Lcom/facebook/hyperthrift/HyperThriftBase;->A00:Ljava/lang/String;

    .line 41
    .line 42
    iput-object v1, p1, Lcom/facebook/hyperthrift/HyperThriftBase;->A01:[Ljava/lang/Object;

    .line 43
    .line 44
    :cond_0
    return-object p1

    .line 45
    :cond_1
    new-instance v1, LX/H9s;

    .line 46
    .line 47
    invoke-direct {v1}, Lcom/facebook/hyperthrift/HyperThriftBase$Builder;-><init>()V

    .line 48
    .line 49
    .line 50
    const/4 v2, 0x1

    .line 51
    goto :goto_0
.end method
