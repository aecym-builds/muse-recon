.class public final Lcom/facebook/aura/analytics/impl/UserConsentStateProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H3K;
.implements LX/H6M;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getConsentState()J
    .locals 1

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/analytics/impl/UserConsentStateProvider;->getUserConsentState()LX/H3M;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v0, v0, LX/H3M;->A00:J

    .line 5
    .line 6
    return-wide v0
.end method

.method public getUserConsentState()LX/H3M;
    .locals 4

    .line 0
    new-instance p0, LX/H3M;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    iget-wide v2, p0, LX/H3M;->A00:J

    .line 6
    .line 7
    const-wide/16 v0, 0x10

    .line 8
    .line 9
    or-long/2addr v2, v0

    .line 10
    iput-wide v2, p0, LX/H3M;->A00:J

    .line 11
    .line 12
    const-wide/16 v0, 0x20

    .line 13
    .line 14
    or-long/2addr v2, v0

    .line 15
    iput-wide v2, p0, LX/H3M;->A00:J

    .line 16
    .line 17
    return-object p0
.end method
