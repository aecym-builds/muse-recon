.class public final Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H4S;


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider$Companion;

.field public static final HIGH_PRI_KEY:Ljava/lang/String; = "realtime_event_latencies"

.field public static final NORMAL_PRI_KEY:Ljava/lang/String; = "non_realtime_event_latencies"

.field public static final TAG:Ljava/lang/String; = "MetaMicroBatchConfigProvider"


# instance fields
.field public eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

.field public eventLatencyOverrideStr:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->Companion:Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v0, ""

    .line 4
    .line 5
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverrideStr:Ljava/lang/String;

    .line 6
    .line 7
    sget-object v1, LX/0Xj;->A00:LX/0Xj;

    .line 8
    .line 9
    new-instance v0, Lkotlinx/serialization/json/JsonObject;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lkotlinx/serialization/json/JsonObject;-><init>(Ljava/util/Map;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

    .line 15
    .line 16
    return-void
.end method

.method private final deserializeEventLatencyOverrides(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverrideStr:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

    .line 9
    .line 10
    return-object v1

    .line 11
    :cond_0
    invoke-static {p1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    sget-object v0, LX/0Xj;->A00:LX/0Xj;

    .line 18
    .line 19
    new-instance v1, Lkotlinx/serialization/json/JsonObject;

    .line 20
    .line 21
    invoke-direct {v1, v0}, Lkotlinx/serialization/json/JsonObject;-><init>(Ljava/util/Map;)V

    .line 22
    .line 23
    .line 24
    return-object v1

    .line 25
    :cond_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 26
    .line 27
    invoke-virtual {v0, p1}, LX/Dcb;->A04(Ljava/lang/String;)Lkotlinx/serialization/json/JsonElement;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->asJsonObjectOrNull(Lkotlinx/serialization/json/JsonElement;)Lkotlinx/serialization/json/JsonObject;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    if-nez v1, :cond_2

    .line 36
    .line 37
    iget-object v1, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

    .line 38
    .line 39
    return-object v1

    .line 40
    :cond_2
    iput-object p1, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverrideStr:Ljava/lang/String;

    .line 41
    .line 42
    iput-object v1, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

    .line 43
    .line 44
    return-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    :catch_0
    move-exception v2

    .line 46
    const-string v0, "json exception when fetching latency overrides: "

    .line 47
    .line 48
    invoke-static {v0, p1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const-string v0, "MetaMicroBatchConfigProvider"

    .line 53
    .line 54
    invoke-static {v0, v1, v2}, LX/FnY;->A0B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 55
    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->eventLatencyOverride:Lkotlinx/serialization/json/JsonObject;

    .line 58
    .line 59
    return-object v0
.end method

.method private final fetchLatencyOverride(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)J
    .locals 4

    .line 0
    invoke-virtual {p2, p1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    check-cast v0, Lkotlinx/serialization/json/JsonElement;

    .line 5
    .line 6
    invoke-static {v0}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->asJsonPrimitiveOrNull(Lkotlinx/serialization/json/JsonElement;)Lkotlinx/serialization/json/JsonPrimitive;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const-wide/16 v3, -0x1

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-static {v0}, LX/Dcc;->A03(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    const-string/jumbo v0, "value is not long for eventName: "

    .line 21
    .line 22
    .line 23
    invoke-static {v0, p1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    const/4 v1, 0x0

    .line 28
    const-string v0, "MetaMicroBatchConfigProvider"

    .line 29
    .line 30
    invoke-static {v0, v2, v1}, LX/FnY;->A0B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-wide v3

    .line 34
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 35
    .line 36
    .line 37
    move-result-wide v3

    .line 38
    return-wide v3
.end method

.method private final getBaseLatencyOverride(Ljava/lang/String;Ljava/lang/String;)J
    .locals 1

    .line 0
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->deserializeEventLatencyOverrides(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->fetchLatencyOverride(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    return-wide v0
.end method

.method private final getHighPriLatencyOverride(Ljava/lang/String;Ljava/lang/String;)J
    .locals 3

    .line 0
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->deserializeEventLatencyOverrides(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const-string v1, "realtime_event_latencies"

    .line 5
    .line 6
    invoke-static {v2, v1}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->has(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-static {v2, v1}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->optJsonObject(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    const-string/jumbo v2, "value is not json object for realtime_event_latencies"

    .line 19
    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    const-string v0, "MetaMicroBatchConfigProvider"

    .line 23
    .line 24
    invoke-static {v0, v2, v1}, LX/FnY;->A0B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    const-wide/16 v0, -0x1

    .line 28
    .line 29
    return-wide v0

    .line 30
    :cond_1
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->fetchLatencyOverride(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)J

    .line 31
    .line 32
    .line 33
    move-result-wide v0

    .line 34
    return-wide v0
.end method

.method private final getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;
    .locals 0

    .line 0
    const p0, 0x10026

    .line 1
    .line 2
    .line 3
    invoke-static {p0}, LX/Iod;->A00(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 8
    .line 9
    return-object p0
.end method

.method private final getNormalPriLatencyOverride(Ljava/lang/String;Ljava/lang/String;)J
    .locals 3

    .line 0
    invoke-direct {p0, p2}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->deserializeEventLatencyOverrides(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const-string v1, "non_realtime_event_latencies"

    .line 5
    .line 6
    invoke-static {v2, v1}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->has(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-static {v2, v1}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->optJsonObject(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    const-string/jumbo v2, "value is not json object for non_realtime_event_latencies"

    .line 19
    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    const-string v0, "MetaMicroBatchConfigProvider"

    .line 23
    .line 24
    invoke-static {v0, v2, v1}, LX/FnY;->A0B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    const-wide/16 v0, -0x1

    .line 28
    .line 29
    return-wide v0

    .line 30
    :cond_1
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->fetchLatencyOverride(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)J

    .line 31
    .line 32
    .line 33
    move-result-wide v0

    .line 34
    return-wide v0
.end method


# virtual methods
.method public analyticsBatchInfoSize()I
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->analyticsBatchInfoSize:I

    .line 5
    .line 6
    return p0
.end method

.method public getBatchMaxLatencyMode()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public getEventLatencyOverride(Ljava/lang/String;)J
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->eventLatencyOverride:Ljava/lang/String;

    .line 9
    .line 10
    invoke-direct {p0, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->deserializeEventLatencyOverrides(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->fetchLatencyOverride(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)J

    .line 15
    .line 16
    .line 17
    move-result-wide v0

    .line 18
    return-wide v0
.end method

.method public getHandlerThread()Landroid/os/HandlerThread;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public getHighPriEventLatencyOverride(Ljava/lang/String;)J
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->eventLatencyOverride:Ljava/lang/String;

    .line 9
    .line 10
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getHighPriLatencyOverride(Ljava/lang/String;Ljava/lang/String;)J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    return-wide v0
.end method

.method public getHighPriUploadSchedulerParamsProvider()LX/Fia;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/analytics/impl/HighPriUploadSchedulerParamsProvider;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public getInMemoryUploadDelay()J
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->inMemoryUploadDelay:J

    .line 5
    .line 6
    return-wide v0
.end method

.method public getLatencyWindowMultiplier()J
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->latencyWindowMultiplier:J

    .line 5
    .line 6
    return-wide v0
.end method

.method public getNormalPriEventLatencyOverride(Ljava/lang/String;)J
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iget-object v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->eventLatencyOverride:Ljava/lang/String;

    .line 9
    .line 10
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getNormalPriLatencyOverride(Ljava/lang/String;Ljava/lang/String;)J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    return-wide v0
.end method

.method public getNormalPriUploadSchedulerParamsProvider()LX/Fia;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/analytics/impl/RegularPriUploadSchedulerParamsProvider;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public getRealTimeExemptLatency()J
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->realTimeExemptLatency:J

    .line 5
    .line 6
    return-wide v0
.end method

.method public getRegularExemptLatency()J
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-wide v0, v0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularExemptLatency:J

    .line 5
    .line 6
    return-wide v0
.end method

.method public getUploadScheduler()LX/Fdc;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public isCatchUpSchedulingEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public isExemptFromChangesInDefaultLatency(Ljava/lang/String;Z)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public isExemptFromMicroBatching(Ljava/lang/String;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public isMicroBatchingEnabled()Z
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->microBatchEnabled:Z

    .line 5
    .line 6
    return p0
.end method

.method public isUploadInProcess()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public multiBatchPayloadSize()I
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->multiBatchPayloadSize:I

    .line 5
    .line 6
    return p0
.end method

.method public provideExecutor()Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public regularUploadDelay()I
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->regularUploadDelay:I

    .line 5
    .line 6
    return p0
.end method

.method public shouldNotifyOnBatchReady()Z
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/impl/MetaMicroBatchConfigProvider;->getMetaAnalyticsMC()Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget-boolean p0, p0, Lcom/facebook/aura/analytics/impl/config/MetaAnalyticsMC;->shouldNotifyOnBatchReady:Z

    .line 5
    .line 6
    return p0
.end method

.method public useExecutor()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public useInMemoryFallback()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method
