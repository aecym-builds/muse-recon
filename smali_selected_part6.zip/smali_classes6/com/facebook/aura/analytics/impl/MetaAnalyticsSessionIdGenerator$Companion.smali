.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic getSESSION_ID_PREFIX$annotations()V
    .locals 0

    .line 0
    return-void
.end method


# virtual methods
.method public final declared-synchronized getExistingInstance()Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    monitor-exit p0

    .line 4
    return-object v0

    .line 5
    :catchall_0
    move-exception v0

    .line 6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    throw v0
.end method

.method public final declared-synchronized getInstance(ZZ)Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 6
    .line 7
    invoke-direct {v1, p1, p2}, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;-><init>(ZZ)V

    .line 8
    .line 9
    .line 10
    sput-object v1, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionManager;

    .line 13
    .line 14
    invoke-virtual {v0, v1}, LX/B9T;->registerCallback(LX/B9U;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->instance:Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    .line 19
    monitor-exit p0

    .line 20
    return-object v0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 23
    throw v0
.end method

.method public final getSESSION_ID_PREFIX()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/impl/MetaAnalyticsSessionIdGenerator;->SESSION_ID_PREFIX:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
