.class public final Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final createIdentity(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/impl/AbraPigeonIdentity;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method
