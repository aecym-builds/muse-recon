.class public final Lcom/facebook/aura/analytics/impl/AuraSamplingPolicyConfig;
.super Lcom/facebook/flexiblesampling/QPLSupportedSamplingPolicyConfig;
.source ""


# instance fields
.field public final appInfoProvider:Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, p1, v0}, Lcom/facebook/flexiblesampling/QPLSupportedSamplingPolicyConfig;-><init>(Landroid/content/Context;LX/GFy;)V

    .line 6
    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lcom/facebook/aura/analytics/impl/AuraSamplingPolicyConfig;->appInfoProvider:Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public getSharedPrefsFactory()LX/BAl;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraPrefsStorage;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraPrefsStorage;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/common/prefs/AuraPrefsStorage;->getFactory()LX/BAl;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method public provideAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "4331325740476680"

    .line 1
    .line 2
    return-object p0
.end method

.method public provideAppVersion()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "18.0.0.8.161"

    .line 1
    .line 2
    return-object p0
.end method

.method public provideAppVersionCode()I
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/common/build/BuildConstants;->A01()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public provideLoggedInUserId()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0h()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
