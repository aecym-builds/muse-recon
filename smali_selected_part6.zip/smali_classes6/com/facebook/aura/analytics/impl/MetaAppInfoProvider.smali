.class public final Lcom/facebook/aura/analytics/impl/MetaAppInfoProvider;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "4331325740476680"

    .line 1
    .line 2
    return-object p0
.end method

.method public getAppVersion()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "18.0.0.8.161"

    .line 1
    .line 2
    return-object p0
.end method

.method public getAppVersionCode()I
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/common/build/BuildConstants;->A01()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method
