.class public final Lcom/facebook/aura/analytics/impl/MetaAnalyticsBuilder$maybeEnableOneFabric$startupStatusProvider$1;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public isAppStarting()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
