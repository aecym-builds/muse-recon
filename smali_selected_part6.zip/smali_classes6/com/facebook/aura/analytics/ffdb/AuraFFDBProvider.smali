.class public final Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FiI;


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider$Companion;

.field public static final FFDB_TOKEN_PREF_KEY:Ljava/lang/String; = "ffdb_token"


# instance fields
.field public ffdbToken:Ljava/lang/String;

.field public final prefs:LX/BVu;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->Companion:Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->FFDB:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    iput-object v2, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->prefs:LX/BVu;

    .line 12
    .line 13
    const-string v1, ""

    .line 14
    .line 15
    iput-object v1, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->ffdbToken:Ljava/lang/String;

    .line 16
    .line 17
    const-string v0, "ffdb_token"

    .line 18
    .line 19
    invoke-interface {v2, v0, v1}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    move-object v1, v0

    .line 26
    :cond_0
    iput-object v1, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->ffdbToken:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setFFDBToken(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public getDebugUserId()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method

.method public getFFDBToken()Ljava/lang/String;
    .locals 3

    .line 0
    invoke-static {}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->getFFDBToken()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    iget-object v1, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->ffdbToken:Ljava/lang/String;

    .line 5
    .line 6
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-lez v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iput-object v2, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->ffdbToken:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->prefs:LX/BVu;

    .line 24
    .line 25
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const-string v0, "ffdb_token"

    .line 30
    .line 31
    invoke-virtual {v1, v0, v2}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1}, LX/Df3;->apply()V

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    return-object v2
.end method

.method public getShouldRequestDebugConfig()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public setDebugUserId(Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public setFFDBToken(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->ffdbToken:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/analytics/ffdb/AuraFFDBProvider;->prefs:LX/BVu;

    .line 7
    .line 8
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    const-string v0, "ffdb_token"

    .line 13
    .line 14
    invoke-virtual {p0, v0, p1}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, LX/Df3;->apply()V

    .line 18
    .line 19
    .line 20
    invoke-static {p1}, Lcom/facebook/falco/fabric/FFSingletonJNILogger;->setFFDBToken(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public setShouldRequestDebugConfig(Z)V
    .locals 0

    .line 0
    return-void
.end method
