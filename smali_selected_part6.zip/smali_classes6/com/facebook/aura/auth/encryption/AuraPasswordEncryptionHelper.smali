.class public final Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final GRAPH_TIER:Ljava/lang/String; = "ar-genai"

.field public static final INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;

.field public static final controller$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;->INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->controller$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getController()LX/GIU;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->controller$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/GIU;

    .line 7
    .line 8
    return-object p0
.end method


# virtual methods
.method public final awaitEncryptedPasswordWithoutRawFallback(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const/4 v1, 0x0

    .line 5
    new-instance v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2;

    .line 6
    .line 7
    invoke-direct {v0, p1, v1}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2;-><init>(Ljava/lang/String;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    invoke-static {p2, p0, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public final getEncryptedPassword(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->controller$delegate:Lkotlin/Lazy;

    .line 5
    .line 6
    invoke-static {v0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, LX/GIU;

    .line 11
    .line 12
    invoke-static {p1, v0}, LX/GIU;->A01(Ljava/lang/String;LX/GIU;)LX/GJ4;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-object v0, v0, LX/GJ4;->A01:Ljava/lang/String;

    .line 17
    .line 18
    return-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    const-string p0, "AuraPasswordEncryptionHelper"

    .line 21
    .line 22
    const-string v0, "password encryption failed"

    .line 23
    .line 24
    invoke-static {p0, v0, p1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 25
    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    return-object v0
.end method

.method public final getEncryptedPasswordWithoutRawFallback(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->controller$delegate:Lkotlin/Lazy;

    .line 6
    .line 7
    invoke-static {v0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, LX/GIU;

    .line 12
    .line 13
    invoke-static {p1, v0}, LX/GIU;->A01(Ljava/lang/String;LX/GIU;)LX/GJ4;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    iget-object v2, v1, LX/GJ4;->A01:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    iget v0, v1, LX/GJ4;->A00:I

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    iget-object v0, v1, LX/GJ4;->A02:Llibraries/passwordencryption/model/PasswordEncryptionException;

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget-object v1, v0, Llibraries/passwordencryption/model/PasswordEncryptionException;->exceptionType:LX/I2V;

    .line 30
    .line 31
    :goto_0
    sget-object v0, LX/I2V;->A03:LX/I2V;

    .line 32
    .line 33
    if-eq v1, v0, :cond_1

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_0
    move-object v1, p0

    .line 37
    goto :goto_0

    .line 38
    :goto_1
    return-object v2

    .line 39
    :cond_1
    return-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 40
    :catchall_0
    move-exception v2

    .line 41
    const-string v1, "AuraPasswordEncryptionHelper"

    .line 42
    .line 43
    const-string v0, "password encryption failed"

    .line 44
    .line 45
    invoke-static {v1, v0, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 46
    .line 47
    .line 48
    return-object p0
.end method

.method public final prefetchKey()V
    .locals 2

    .line 0
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->controller$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {v0}, LX/I1c;->A0L(Lkotlin/Lazy;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, LX/GIU;

    .line 7
    .line 8
    invoke-virtual {v0}, LX/GIU;->A02()V

    .line 9
    .line 10
    .line 11
    return-void
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    :catchall_0
    move-exception p0

    .line 13
    const-string v1, "AuraPasswordEncryptionHelper"

    .line 14
    .line 15
    const-string v0, "password encryption key prefetch failed"

    .line 16
    .line 17
    invoke-static {v1, v0, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
