.class public abstract Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelperKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ENCRYPTION_KEY_RETRY_INTERVAL_MS:J = 0xfaL

.field public static final ENCRYPTION_KEY_WAIT_MS:J = 0x1388L

.field public static final RAW_PASSWORD_VERSION:I = 0x0

.field public static final TAG:Ljava/lang/String; = "AuraPasswordEncryptionHelper"
