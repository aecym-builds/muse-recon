.class public final Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/GIU;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;->INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/GIU;
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/common/prefs/HatchPrefsStore;->INSTANCE:Lcom/facebook/aura/common/prefs/HatchPrefsStore;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/common/prefs/HatchPrefsStore;->authPrefs()LX/BVu;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    sget-object v0, Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;->INSTANCE:Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/network/tigon/crudonet/TigonCrudoNet;->requestFactory()LX/GIr;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-static {v3}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object v2, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2$frlRequestFactory$1;->INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2$frlRequestFactory$1;

    .line 16
    .line 17
    new-instance v1, Lcom/facebook/aura/network/endpoint/AuraEndpointSelector;

    .line 18
    .line 19
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    new-instance v0, LX/GIo;

    .line 23
    .line 24
    invoke-direct {v0, v3, v2, v1}, LX/GIo;-><init>(LX/GIr;LX/GJM;LX/FrH;)V

    .line 25
    .line 26
    .line 27
    new-instance v1, LX/GJG;

    .line 28
    .line 29
    invoke-direct {v1, v0}, LX/GJG;-><init>(LX/GIo;)V

    .line 30
    .line 31
    .line 32
    new-instance p0, LX/GGH;

    .line 33
    .line 34
    invoke-direct {p0, v4}, LX/GGH;-><init>(LX/BVu;)V

    .line 35
    .line 36
    .line 37
    invoke-static {}, LX/EYt;->A0j()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    new-instance v4, LX/GJA;

    .line 42
    .line 43
    invoke-direct {v4, v1, v0}, LX/GJA;-><init>(LX/GJG;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sget-object v3, LX/FkO;->A00:Ljava/lang/Integer;

    .line 47
    .line 48
    const/4 v2, 0x1

    .line 49
    sget-object v0, LX/GIU;->A07:LX/GIU;

    .line 50
    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    const-class v1, LX/GIU;

    .line 54
    .line 55
    monitor-enter v1

    .line 56
    :try_start_0
    sget-object v0, LX/GIU;->A07:LX/GIU;

    .line 57
    .line 58
    if-nez v0, :cond_0

    .line 59
    .line 60
    new-instance v0, LX/GIU;

    .line 61
    .line 62
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 63
    .line 64
    .line 65
    iput-object p0, v0, LX/GIU;->A01:LX/GGH;

    .line 66
    .line 67
    iput-object v4, v0, LX/GIU;->A00:LX/GJA;

    .line 68
    .line 69
    iput-object v3, v0, LX/GIU;->A02:Ljava/lang/Integer;

    .line 70
    .line 71
    iput-boolean v2, v0, LX/GIU;->A03:Z

    .line 72
    .line 73
    sput-object v0, LX/GIU;->A07:LX/GIU;

    .line 74
    .line 75
    sget-object v0, LX/GIU;->A07:LX/GIU;

    .line 76
    .line 77
    invoke-virtual {v0}, LX/GIU;->A02()V

    .line 78
    .line 79
    .line 80
    :cond_0
    monitor-exit v1

    .line 81
    goto :goto_0

    .line 82
    :catchall_0
    move-exception v0

    .line 83
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 84
    throw v0

    .line 85
    :cond_1
    :goto_0
    sget-object v0, LX/GIU;->A07:LX/GIU;

    .line 86
    .line 87
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$controller$2;->invoke()LX/GIU;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
