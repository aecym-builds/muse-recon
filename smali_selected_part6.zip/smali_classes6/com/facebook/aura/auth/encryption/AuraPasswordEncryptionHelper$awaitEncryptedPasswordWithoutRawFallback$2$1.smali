.class public final Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/lang/String;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.encryption.AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1"
    f = "AuraPasswordEncryptionHelper.kt"
    l = {
        0x67
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $rawPassword:Ljava/lang/String;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->$rawPassword:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->$rawPassword:Ljava/lang/String;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;-><init>(Ljava/lang/String;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->$rawPassword:Ljava/lang/String;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;-><init>(Ljava/lang/String;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-eq v0, v2, :cond_0

    .line 8
    .line 9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    throw v0

    .line 14
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    sget-object v1, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->INSTANCE:Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->$rawPassword:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->getEncryptedPasswordWithoutRawFallback(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    if-nez v0, :cond_2

    .line 26
    .line 27
    invoke-virtual {v1}, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper;->prefetchKey()V

    .line 28
    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    iput-object v0, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->L$0:Ljava/lang/Object;

    .line 32
    .line 33
    iput v2, p0, Lcom/facebook/aura/auth/encryption/AuraPasswordEncryptionHelper$awaitEncryptedPasswordWithoutRawFallback$2$1;->label:I

    .line 34
    .line 35
    const-wide/16 v0, 0xfa

    .line 36
    .line 37
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-ne v0, v3, :cond_1

    .line 42
    .line 43
    return-object v3

    .line 44
    :cond_2
    return-object v0
.end method
