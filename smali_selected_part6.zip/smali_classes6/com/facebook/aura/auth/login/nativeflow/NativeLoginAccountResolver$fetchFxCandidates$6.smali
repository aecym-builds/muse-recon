.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchFxCandidates$6"
    f = "NativeLoginAccountResolver.kt"
    l = {
        0x13e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $legacyItems:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/JDM;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->$legacyItems:LX/JDM;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->$legacyItems:LX/JDM;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;

    .line 3
    .line 4
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;-><init>(LX/JDM;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->$legacyItems:LX/JDM;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;

    .line 3
    .line 4
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;-><init>(LX/JDM;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_2

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->L$0:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast p1, Ljava/util/List;

    .line 17
    .line 18
    invoke-static {v1, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->access$legacyCandidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;)Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0

    .line 23
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 27
    .line 28
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->$legacyItems:LX/JDM;

    .line 29
    .line 30
    iput-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->L$0:Ljava/lang/Object;

    .line 31
    .line 32
    iput v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;->label:I

    .line 33
    .line 34
    invoke-interface {v0, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    if-ne p1, v3, :cond_0

    .line 39
    .line 40
    return-object v3

    .line 41
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0
.end method
