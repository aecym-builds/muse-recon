.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

.field public static activeRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

.field public static final attestationMutex:LX/3Hh;

.field public static final currentRotation:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "LX/IBK<",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "Lcom/google/common/util/concurrent/ListenableFuture<",
            "LX/FkW;",
            ">;>;>;"
        }
    .end annotation
.end field

.field public static final operations$delegate:Lkotlin/Lazy;

.field public static queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

.field public static final rotationMutex:LX/3Hh;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->operations$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-static {v0}, LX/EYt;->A1C(Ljava/lang/Object;)Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    new-instance v0, LX/DSP;

    .line 23
    .line 24
    invoke-direct {v0}, LX/DSP;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 28
    .line 29
    new-instance v0, LX/DSP;

    .line 30
    .line 31
    invoke-direct {v0}, LX/DSP;-><init>()V

    .line 32
    .line 33
    .line 34
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->attestationMutex:LX/3Hh;

    .line 35
    .line 36
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$activateRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->activateRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$attestOrReport(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->attestOrReport(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$awaitResult(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/google/common/util/concurrent/ListenableFuture;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->awaitResult(Lcom/google/common/util/concurrent/ListenableFuture;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$finishRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->finishRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getAttestationMutex$p()LX/3Hh;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->attestationMutex:LX/3Hh;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rotationFor(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationFor(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final activateRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v2, 0x0

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 37
    .line 38
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;

    .line 43
    .line 44
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 57
    .line 58
    iput-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->L$1:Ljava/lang/Object;

    .line 61
    .line 62
    iput v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$activateRequest$1;->label:I

    .line 63
    .line 64
    invoke-interface {v1, v2, v5}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-ne v0, v3, :cond_3

    .line 69
    .line 70
    return-object v3

    .line 71
    :cond_3
    :goto_1
    :try_start_0
    sput-object p1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->activeRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 72
    .line 73
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 74
    .line 75
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    sput-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 82
    .line 83
    :cond_4
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 84
    .line 85
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    return-object v3

    .line 89
    :catchall_0
    move-exception v0

    .line 90
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    throw v0
.end method

.method private final attestOrReport(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p3

    .line 1
    .line 2
    move-object/from16 v6, p2

    .line 3
    .line 4
    instance-of v0, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;

    .line 5
    .line 6
    if-eqz v0, :cond_8

    .line 7
    .line 8
    move-object v5, v3

    .line 9
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;

    .line 10
    .line 11
    iget v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_8

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v8, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 27
    .line 28
    const/4 v3, 0x3

    .line 29
    const/4 v7, 0x2

    .line 30
    const/4 v0, 0x1

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    if-eq v1, v0, :cond_3

    .line 34
    .line 35
    if-eq v1, v7, :cond_6

    .line 36
    .line 37
    if-ne v1, v3, :cond_9

    .line 38
    .line 39
    iget-object v6, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$4:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v6, LX/FkX;

    .line 42
    .line 43
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$3:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v1, Ljava/lang/String;

    .line 46
    .line 47
    iget-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$2:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v2, LX/FkW;

    .line 50
    .line 51
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_0
    iget-object v2, v2, LX/FkW;->A02:Ljava/util/List;

    .line 55
    .line 56
    iget-object v0, v6, LX/FkX;->A00:Ljava/util/List;

    .line 57
    .line 58
    invoke-static {v0, v2}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    iget-object v3, v6, LX/FkX;->A01:[B

    .line 63
    .line 64
    if-nez v3, :cond_1

    .line 65
    .line 66
    const-string v0, "PROOF_FAILED"

    .line 67
    .line 68
    :goto_1
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->codes(Ljava/util/List;Ljava/lang/String;)Ljava/util/List;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    sget-object v0, Lcom/facebook/aura/json/AttestationProofFormatter;->INSTANCE:Lcom/facebook/aura/json/AttestationProofFormatter;

    .line 73
    .line 74
    invoke-virtual {v0, v3, v2}, Lcom/facebook/aura/json/AttestationProofFormatter;->format([BLjava/util/List;)Lcom/facebook/aura/json/AttestationProofFields;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iget-object v3, v0, Lcom/facebook/aura/json/AttestationProofFields;->proof:Ljava/lang/String;

    .line 79
    .line 80
    iget-object v2, v0, Lcom/facebook/aura/json/AttestationProofFields;->errors:Ljava/util/List;

    .line 81
    .line 82
    const/4 v0, 0x0

    .line 83
    new-instance v4, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 84
    .line 85
    invoke-direct {v4, v1, v3, v2, v0}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    return-object v4

    .line 89
    :cond_1
    const/4 v0, 0x0

    .line 90
    goto :goto_1

    .line 91
    :cond_2
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    iput-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$0:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v6, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$1:Ljava/lang/Object;

    .line 97
    .line 98
    iput v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 99
    .line 100
    invoke-direct {p0, p1, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationFor(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v8

    .line 104
    if-ne v8, v4, :cond_4

    .line 105
    .line 106
    return-object v4

    .line 107
    :cond_3
    iget-object v6, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$1:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast v6, Ljava/lang/String;

    .line 110
    .line 111
    iget-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$0:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 114
    .line 115
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :cond_4
    move-object v2, v8

    .line 119
    check-cast v2, LX/FkW;

    .line 120
    .line 121
    iget-object v1, v2, LX/FkW;->A00:Ljava/lang/String;

    .line 122
    .line 123
    if-nez v1, :cond_5

    .line 124
    .line 125
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->$childSerializers:[Lkotlin/Lazy;

    .line 126
    .line 127
    iget-object v1, v2, LX/FkW;->A02:Ljava/util/List;

    .line 128
    .line 129
    const-string v0, "KEY_ROTATION_FAILED"

    .line 130
    .line 131
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->codes(Ljava/util/List;Ljava/lang/String;)Ljava/util/List;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    const/4 v0, 0x0

    .line 136
    new-instance v4, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 137
    .line 138
    invoke-direct {v4, v0, v0, v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    return-object v4

    .line 142
    :cond_5
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->operations$delegate:Lkotlin/Lazy;

    .line 143
    .line 144
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v9

    .line 148
    check-cast v9, LX/FGJ;

    .line 149
    .line 150
    const-string/jumbo v0, "w6CmevIyM/PL6Q5uUDw="

    .line 151
    .line 152
    .line 153
    new-instance v10, LX/FaC;

    .line 154
    .line 155
    invoke-direct {v10, v0}, LX/FaC;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    iget-object v12, v2, LX/FkW;->A01:Ljava/lang/String;

    .line 159
    .line 160
    invoke-static {v6}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 161
    .line 162
    .line 163
    move-result-object v11

    .line 164
    sget-object v6, LX/FGJ;->A02:Ljava/lang/Integer;

    .line 165
    .line 166
    const/4 v13, 0x0

    .line 167
    new-instance v8, LX/GtT;

    .line 168
    .line 169
    invoke-direct/range {v8 .. v13}, LX/GtT;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;I)V

    .line 170
    .line 171
    .line 172
    const/16 v0, 0x11

    .line 173
    .line 174
    invoke-static {v0}, LX/Hur;->A00(I)LX/Hur;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-static {v9, v6, v8, v0}, LX/FGJ;->A00(LX/FGJ;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;LX/JDM;)LX/FGG;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    iput-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$0:Ljava/lang/Object;

    .line 183
    .line 184
    const/4 v0, 0x0

    .line 185
    iput-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$1:Ljava/lang/Object;

    .line 186
    .line 187
    iput-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$2:Ljava/lang/Object;

    .line 188
    .line 189
    iput-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$3:Ljava/lang/Object;

    .line 190
    .line 191
    iput v7, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 192
    .line 193
    invoke-direct {p0, v6, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->awaitResult(Lcom/google/common/util/concurrent/ListenableFuture;LX/2M4;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v8

    .line 197
    if-ne v8, v4, :cond_7

    .line 198
    .line 199
    return-object v4

    .line 200
    :cond_6
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$3:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast v1, Ljava/lang/String;

    .line 203
    .line 204
    iget-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$2:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast v2, LX/FkW;

    .line 207
    .line 208
    iget-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$0:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 211
    .line 212
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    :cond_7
    move-object v6, v8

    .line 216
    check-cast v6, LX/FkX;

    .line 217
    .line 218
    iget-object v0, v6, LX/FkX;->A01:[B

    .line 219
    .line 220
    if-nez v0, :cond_0

    .line 221
    .line 222
    const/4 v0, 0x0

    .line 223
    iput-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$0:Ljava/lang/Object;

    .line 224
    .line 225
    iput-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$1:Ljava/lang/Object;

    .line 226
    .line 227
    iput-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$2:Ljava/lang/Object;

    .line 228
    .line 229
    iput-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$3:Ljava/lang/Object;

    .line 230
    .line 231
    iput-object v6, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->L$4:Ljava/lang/Object;

    .line 232
    .line 233
    iput v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;->label:I

    .line 234
    .line 235
    invoke-direct {p0, p1, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    if-ne v0, v4, :cond_0

    .line 240
    .line 241
    return-object v4

    .line 242
    :cond_8
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;

    .line 243
    .line 244
    invoke-direct {v5, p0, v3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attestOrReport$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 245
    .line 246
    .line 247
    goto/16 :goto_0

    .line 248
    .line 249
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    throw v0
.end method

.method private final awaitResult(Lcom/google/common/util/concurrent/ListenableFuture;LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/util/concurrent/ListenableFuture<",
            "TT;>;",
            "LX/2M4<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p2}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;

    .line 5
    .line 6
    invoke-direct {v1, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;-><init>(LX/DT0;)V

    .line 7
    .line 8
    .line 9
    sget-object v0, LX/I9m;->A01:LX/I9m;

    .line 10
    .line 11
    invoke-static {v1, p1, v0}, LX/F0M;->A01(LX/I3Q;Lcom/google/common/util/concurrent/ListenableFuture;Ljava/util/concurrent/Executor;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method

.method private final codes(Ljava/util/List;Ljava/lang/String;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LX/FkP;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p2}, LX/B8B;->A15(Ljava/lang/Object;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p1}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, LX/FkP;

    .line 23
    .line 24
    iget-object v0, v0, LX/FkP;->A04:Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-static {v0}, LX/Fkf;->A00(Ljava/lang/Integer;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    invoke-static {v2, p0}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {v0}, LX/B89;->A0f(Ljava/lang/Iterable;)Ljava/util/List;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const/16 v0, 0x8

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0
.end method

.method public static synthetic codes$default(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Ljava/util/List;Ljava/lang/String;ILjava/lang/Object;)Ljava/util/List;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->codes(Ljava/util/List;Ljava/lang/String;)Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method private final finishRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v2, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;

    .line 41
    .line 42
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    throw v0

    .line 51
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 55
    .line 56
    iput-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v0, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$finishRequest$1;->label:I

    .line 61
    .line 62
    invoke-interface {v2, v3, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-ne v0, v4, :cond_3

    .line 67
    .line 68
    return-object v4

    .line 69
    :cond_3
    :goto_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->activeRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 70
    .line 71
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_4

    .line 76
    .line 77
    sput-object v3, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->activeRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 78
    .line 79
    :cond_4
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 80
    .line 81
    sput-object v3, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 82
    .line 83
    if-eqz v1, :cond_5

    .line 84
    .line 85
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 86
    .line 87
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, LX/IBK;

    .line 92
    .line 93
    if-eqz v0, :cond_6

    .line 94
    .line 95
    iget-object v0, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 98
    .line 99
    :goto_2
    invoke-static {v0, v1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-nez v0, :cond_5

    .line 104
    .line 105
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 106
    .line 107
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->startRotationLocked(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)V

    .line 108
    .line 109
    .line 110
    :cond_5
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 111
    .line 112
    goto :goto_3

    .line 113
    :cond_6
    move-object v0, v3

    .line 114
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 115
    :goto_3
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    return-object v4

    .line 119
    :catchall_0
    move-exception v0

    .line 120
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    throw v0
.end method

.method private final getOperations()LX/FGJ;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->operations$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/FGJ;

    .line 7
    .line 8
    return-object p0
.end method

.method private final inputError(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)Ljava/lang/String;
    .locals 2

    .line 0
    iget-object p0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;->challenge:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/16 v1, 0x80

    .line 7
    .line 8
    if-gt v0, v1, :cond_1

    .line 9
    .line 10
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;->challenge:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    array-length v0, v0

    .line 23
    if-gt v0, v1, :cond_1

    .line 24
    .line 25
    iget-object v1, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;->keyAlias:Ljava/lang/String;

    .line 26
    .line 27
    const-string/jumbo v0, "w6CmevIyM/PL6Q5uUDw="

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    const-string v0, "INVALID_KEY_ALIAS"

    .line 37
    .line 38
    return-object v0

    .line 39
    :cond_0
    const/4 v0, 0x0

    .line 40
    return-object v0

    .line 41
    :cond_1
    const/16 v0, 0x20

    .line 42
    .line 43
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    return-object v0
.end method

.method private final restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v2, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 37
    .line 38
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;

    .line 43
    .line 44
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 57
    .line 58
    iput-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->L$1:Ljava/lang/Object;

    .line 61
    .line 62
    iput v0, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$restartRotation$1;->label:I

    .line 63
    .line 64
    invoke-interface {v2, v3, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-ne v0, v4, :cond_3

    .line 69
    .line 70
    return-object v4

    .line 71
    :cond_3
    :goto_1
    :try_start_0
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 72
    .line 73
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    check-cast v0, LX/IBK;

    .line 78
    .line 79
    if-eqz v0, :cond_5

    .line 80
    .line 81
    iget-object v0, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 84
    .line 85
    :goto_2
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_4

    .line 90
    .line 91
    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 95
    .line 96
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->startRotationLocked(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)V

    .line 97
    .line 98
    .line 99
    :cond_4
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 100
    .line 101
    goto :goto_3

    .line 102
    :cond_5
    move-object v0, v3

    .line 103
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 104
    :goto_3
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    return-object v4

    .line 108
    :catchall_0
    move-exception v0

    .line 109
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    throw v0
.end method

.method private final rotationFor(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "LX/FkW;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;

    .line 1
    .line 2
    if-eqz v0, :cond_7

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_7

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v10, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 23
    .line 24
    const/4 v8, 0x4

    .line 25
    const/4 v6, 0x3

    .line 26
    const/4 v9, 0x2

    .line 27
    const/4 v0, 0x1

    .line 28
    const/4 v3, 0x0

    .line 29
    if-eqz v1, :cond_3

    .line 30
    .line 31
    if-eq v1, v0, :cond_2

    .line 32
    .line 33
    if-eq v1, v9, :cond_1

    .line 34
    .line 35
    if-eq v1, v6, :cond_9

    .line 36
    .line 37
    if-ne v1, v8, :cond_8

    .line 38
    .line 39
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$2:Ljava/lang/Object;

    .line 40
    .line 41
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    return-object v1

    .line 45
    :cond_1
    iget-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 48
    .line 49
    goto :goto_3

    .line 50
    :cond_2
    iget-object v7, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$1:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v7, LX/3Hh;

    .line 53
    .line 54
    iget-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 57
    .line 58
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_3
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    sget-object v7, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 66
    .line 67
    iput-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput-object v7, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    iput v0, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 72
    .line 73
    invoke-interface {v7, v3, v5}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-ne v0, v4, :cond_4

    .line 78
    .line 79
    return-object v4

    .line 80
    :cond_4
    :goto_1
    :try_start_0
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 81
    .line 82
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    check-cast v1, LX/IBK;

    .line 87
    .line 88
    if-eqz v1, :cond_5

    .line 89
    .line 90
    iget-object v0, v1, LX/IBK;->first:Ljava/lang/Object;

    .line 91
    .line 92
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_5

    .line 97
    .line 98
    goto :goto_2

    .line 99
    :cond_5
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 100
    .line 101
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->startRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)LX/IBK;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    invoke-virtual {v2, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 106
    .line 107
    .line 108
    :goto_2
    invoke-interface {v7, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :try_start_1
    iget-object v0, v1, LX/IBK;->second:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v0, Lcom/google/common/util/concurrent/ListenableFuture;

    .line 114
    .line 115
    iput-object p1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 116
    .line 117
    iput-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$1:Ljava/lang/Object;

    .line 118
    .line 119
    iput v9, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 120
    .line 121
    invoke-direct {p0, v0, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->awaitResult(Lcom/google/common/util/concurrent/ListenableFuture;LX/2M4;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v10

    .line 125
    if-ne v10, v4, :cond_6

    .line 126
    .line 127
    goto :goto_4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 128
    :goto_3
    :try_start_2
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    :cond_6
    move-object v1, v10

    .line 132
    check-cast v1, LX/FkW;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 133
    .line 134
    iget-object v0, v1, LX/FkW;->A00:Ljava/lang/String;

    .line 135
    .line 136
    if-nez v0, :cond_0

    .line 137
    .line 138
    iput-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 139
    .line 140
    iput-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$1:Ljava/lang/Object;

    .line 141
    .line 142
    iput-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$2:Ljava/lang/Object;

    .line 143
    .line 144
    iput v8, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 145
    .line 146
    invoke-direct {p0, p1, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    if-ne v0, v4, :cond_0

    .line 151
    .line 152
    return-object v4

    .line 153
    :cond_7
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;

    .line 154
    .line 155
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 156
    .line 157
    .line 158
    goto/16 :goto_0

    .line 159
    .line 160
    :cond_8
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    throw v2

    .line 165
    :goto_4
    return-object v4

    .line 166
    :catch_0
    move-exception v2

    .line 167
    goto :goto_5

    .line 168
    :catch_1
    move-exception v2

    .line 169
    :goto_5
    instance-of v0, v2, Ljava/util/concurrent/CancellationException;

    .line 170
    .line 171
    if-nez v0, :cond_a

    .line 172
    .line 173
    const-string v1, "HatchRegistrationAttestor"

    .line 174
    .line 175
    const-string v0, "Registration attestation key rotation failed"

    .line 176
    .line 177
    invoke-static {v1, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    iput-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$0:Ljava/lang/Object;

    .line 181
    .line 182
    iput-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$1:Ljava/lang/Object;

    .line 183
    .line 184
    iput-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$2:Ljava/lang/Object;

    .line 185
    .line 186
    iput v6, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->label:I

    .line 187
    .line 188
    invoke-direct {p0, p1, v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->restartRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    if-ne v0, v4, :cond_a

    .line 193
    .line 194
    return-object v4

    .line 195
    :cond_9
    iget-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$rotationFor$1;->L$2:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v2, Ljava/lang/Throwable;

    .line 198
    .line 199
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    :cond_a
    throw v2

    .line 203
    :catchall_0
    move-exception v0

    .line 204
    invoke-interface {v7, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    throw v0
.end method

.method private final startRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)LX/IBK;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            ")",
            "LX/IBK<",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "Lcom/google/common/util/concurrent/ListenableFuture<",
            "LX/FkW;",
            ">;>;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->operations$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    check-cast v3, LX/FGJ;

    .line 7
    .line 8
    const-string/jumbo v0, "w6CmevIyM/PL6Q5uUDw="

    .line 9
    .line 10
    .line 11
    new-instance v4, LX/FaC;

    .line 12
    .line 13
    invoke-direct {v4, v0}, LX/FaC;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;->challenge:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 19
    .line 20
    .line 21
    move-result-object v6

    .line 22
    sget-object v0, Lcom/google/common/collect/RegularImmutableSet;->A05:Lcom/google/common/collect/RegularImmutableSet;

    .line 23
    .line 24
    new-instance v5, LX/Fkb;

    .line 25
    .line 26
    invoke-direct {v5, v0}, LX/Fkb;-><init>(Lcom/google/common/collect/ImmutableSet;)V

    .line 27
    .line 28
    .line 29
    sget-object v1, LX/FGJ;->A03:Ljava/lang/Integer;

    .line 30
    .line 31
    const/4 p0, 0x0

    .line 32
    new-instance v2, LX/H5y;

    .line 33
    .line 34
    invoke-direct/range {v2 .. v7}, LX/H5y;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 35
    .line 36
    .line 37
    const/16 v0, 0x12

    .line 38
    .line 39
    invoke-static {v0}, LX/Hur;->A00(I)LX/Hur;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v3, v1, v2, v0}, LX/FGJ;->A00(LX/FGJ;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;LX/JDM;)LX/FGG;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-static {p1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    return-object v0
.end method

.method private final startRotationLocked(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)V
    .locals 2

    .line 0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->startRotation(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)LX/IBK;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    :catch_0
    const-string v1, "HatchRegistrationAttestor"

    .line 11
    .line 12
    const-string v0, "Failed to start registration attestation key rotation"

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final attest(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p3

    .line 5
    check-cast v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v0, :cond_7

    .line 29
    .line 30
    iget-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->L$0:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 33
    .line 34
    goto :goto_2

    .line 35
    :cond_0
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;

    .line 36
    .line 37
    invoke-direct {v6, p0, p3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->inputError(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    if-eqz v1, :cond_5

    .line 49
    .line 50
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->$childSerializers:[Lkotlin/Lazy;

    .line 51
    .line 52
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 57
    .line 58
    invoke-direct {v5, v3, v3, v0, v3}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :cond_2
    :goto_1
    iget-object v4, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;->requestId:Ljava/lang/String;

    .line 62
    .line 63
    if-eqz v4, :cond_3

    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    const/16 v0, 0x40

    .line 70
    .line 71
    if-le v1, v0, :cond_4

    .line 72
    .line 73
    :cond_3
    move-object v4, v3

    .line 74
    :cond_4
    iget-object v3, v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->evidence:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->proof:Ljava/lang/String;

    .line 77
    .line 78
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->errors:Ljava/util/List;

    .line 79
    .line 80
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 81
    .line 82
    invoke-direct {v0, v3, v2, v1, v4}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    return-object v0

    .line 86
    :cond_5
    :try_start_0
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;

    .line 87
    .line 88
    invoke-direct {v2, p1, p2, v3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)V

    .line 89
    .line 90
    .line 91
    iput-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->L$0:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v3, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->L$1:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v3, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->L$2:Ljava/lang/Object;

    .line 96
    .line 97
    iput v0, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$1;->label:I

    .line 98
    .line 99
    const-wide/16 v0, 0xbb8

    .line 100
    .line 101
    invoke-static {v6, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    if-ne v5, v4, :cond_6

    .line 106
    .line 107
    goto :goto_3

    .line 108
    :goto_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :cond_6
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 112
    .line 113
    if-nez v5, :cond_2

    .line 114
    .line 115
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->$childSerializers:[Lkotlin/Lazy;

    .line 116
    .line 117
    const-string v0, "OPERATION_TIMED_OUT"

    .line 118
    .line 119
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 124
    .line 125
    invoke-direct {v5, v3, v3, v0, v3}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 129
    :catch_0
    move-exception v1

    .line 130
    instance-of v0, v1, Ljava/util/concurrent/CancellationException;

    .line 131
    .line 132
    if-nez v0, :cond_8

    .line 133
    .line 134
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;->$childSerializers:[Lkotlin/Lazy;

    .line 135
    .line 136
    const-string v0, "UNEXPECTED_EXCEPTION"

    .line 137
    .line 138
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;

    .line 143
    .line 144
    invoke-direct {v5, v3, v3, v0, v3}, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :goto_3
    return-object v4

    .line 149
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    :cond_8
    throw v1
.end method

.method public final begin(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    const/4 v1, 0x0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v3, :cond_1

    .line 29
    .line 30
    iget-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v2, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 37
    .line 38
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;

    .line 43
    .line 44
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->inputError(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 63
    .line 64
    return-object v0

    .line 65
    :cond_3
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->rotationMutex:LX/3Hh;

    .line 66
    .line 67
    iput-object p1, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput-object v2, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    iput v3, v6, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$begin$1;->label:I

    .line 72
    .line 73
    invoke-interface {v2, v1, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-ne v0, v4, :cond_4

    .line 78
    .line 79
    return-object v4

    .line 80
    :cond_4
    :goto_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->currentRotation:Ljava/util/concurrent/atomic/AtomicReference;

    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    check-cast v0, LX/IBK;

    .line 87
    .line 88
    if-eqz v0, :cond_5

    .line 89
    .line 90
    iget-object v0, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 91
    .line 92
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 93
    .line 94
    :goto_2
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_6

    .line 99
    .line 100
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 101
    .line 102
    goto :goto_3

    .line 103
    :cond_5
    move-object v0, v1

    .line 104
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 105
    :goto_3
    invoke-interface {v2, v1}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    return-object v0

    .line 109
    :cond_6
    :try_start_1
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->activeRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 110
    .line 111
    if-eqz v0, :cond_7

    .line 112
    .line 113
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-nez v0, :cond_7

    .line 118
    .line 119
    sput-object p1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->queuedRequest:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 120
    .line 121
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 122
    .line 123
    invoke-interface {v2, v1}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    return-object v0

    .line 127
    :cond_7
    :try_start_2
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 128
    .line 129
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->startRotationLocked(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;)V

    .line 130
    .line 131
    .line 132
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 133
    .line 134
    invoke-interface {v2, v1}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    return-object v0

    .line 138
    :catchall_0
    move-exception v0

    .line 139
    invoke-interface {v2, v1}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    throw v0
.end method
