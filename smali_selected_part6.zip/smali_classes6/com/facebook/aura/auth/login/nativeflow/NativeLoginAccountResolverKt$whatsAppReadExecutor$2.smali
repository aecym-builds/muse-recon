.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/util/concurrent/Executor;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/executors/AuraExecutors;->CORE_POOL_SIZE:I

    .line 1
    .line 2
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;

    .line 7
    .line 8
    invoke-direct {v0, p0}, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;-><init>(Ljava/util/concurrent/Executor;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke()Ljava/util/concurrent/Executor;
    .locals 1

    .line 268435456
    sget v0, Lcom/facebook/aura/executors/AuraExecutors;->CORE_POOL_SIZE:I

    .line 268435457
    .line 268435458
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    new-instance v0, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;

    .line 268435463
    .line 268435464
    invoke-direct {v0, p0}, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;-><init>(Ljava/util/concurrent/Executor;)V

    .line 268435465
    .line 268435466
    .line 268435467
    return-object v0
.end method
