.class public final Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2We;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/2We;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    check-cast p1, LX/BAR;

    .line 7
    .line 8
    iget-object p0, p1, LX/BAR;->A01:Ljava/util/regex/Matcher;

    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public final invoke(LX/2We;)Ljava/lang/String;
    .locals 0

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    check-cast p1, LX/BAR;

    .line 268435461
    .line 268435462
    iget-object p0, p1, LX/BAR;->A01:Ljava/util/regex/Matcher;

    .line 268435463
    .line 268435464
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-object p0
.end method
