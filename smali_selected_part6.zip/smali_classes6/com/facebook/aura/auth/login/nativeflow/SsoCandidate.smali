.class public final Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;
.super LX/07H;
.source ""


# instance fields
.field public final accessToken:Ljava/lang/String;

.field public final isActive:Z

.field public final isMessenger:Z

.field public final isThreads:Z

.field public final sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

.field public final userId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V
    .locals 0

    .line 268435456
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435460
    .line 268435461
    .line 268435462
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 268435463
    .line 268435464
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 268435465
    .line 268435466
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 268435467
    .line 268435468
    iput-boolean p4, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 268435469
    .line 268435470
    iput-boolean p5, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 268435471
    .line 268435472
    iput-boolean p6, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 268435473
    .line 268435474
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x10

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p5, 0x0

    .line 5
    :cond_0
    and-int/lit8 v0, p7, 0x20

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    const/4 p6, 0x0

    .line 10
    :cond_1
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZILjava/lang/Object;)Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;
    .locals 7

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move v4, p4

    .line 4
    move v5, p5

    .line 5
    move v6, p6

    .line 6
    and-int/lit8 v0, p7, 0x1

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 11
    .line 12
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 17
    .line 18
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 19
    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 23
    .line 24
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 25
    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    iget-boolean v4, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 29
    .line 30
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 31
    .line 32
    if-eqz v0, :cond_4

    .line 33
    .line 34
    iget-boolean v5, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 35
    .line 36
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 37
    .line 38
    if-eqz v0, :cond_5

    .line 39
    .line 40
    iget-boolean v6, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 41
    .line 42
    :cond_5
    invoke-static {v1, v2, v3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 46
    .line 47
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 48
    .line 49
    .line 50
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component6()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-boolean v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 37
    .line 38
    iget-boolean v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-boolean v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 43
    .line 44
    iget-boolean v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 45
    .line 46
    if-ne v1, v0, :cond_0

    .line 47
    .line 48
    iget-boolean v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 49
    .line 50
    iget-boolean v0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 51
    .line 52
    if-eq v1, v0, :cond_1

    .line 53
    .line 54
    :cond_0
    return v2

    .line 55
    :cond_1
    return v3
.end method

.method public final getAccessToken()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSourceApp()Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUserId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-boolean v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-boolean v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 31
    .line 32
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    return v0
.end method

.method public final isActive()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isMessenger()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isThreads()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
