.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FB_LEGACY_SSO_SOURCES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field

.field public static final IG_LEGACY_SSO_SOURCES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field

.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

.field public static final LEGACY_CONTENT_PROVIDER_SSO_SOURCES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field

.field public static final THREADS_E2E_TOKEN_TYPE:Ljava/lang/String; = "barcelona"

.field public static final threadsActiveReadDispatcher$delegate:Lkotlin/Lazy;

.field public static final threadsInactiveReadDispatcher$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 6
    .line 7
    sget-object v3, LX/Fyo;->A05:LX/Fyo;

    .line 8
    .line 9
    sget-object v2, LX/Fyo;->A06:LX/Fyo;

    .line 10
    .line 11
    sget-object v1, LX/Fyo;->A08:LX/Fyo;

    .line 12
    .line 13
    sget-object v0, LX/Fyo;->A0G:LX/Fyo;

    .line 14
    .line 15
    filled-new-array {v3, v2, v1, v0}, [LX/Fyo;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    sput-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->FB_LEGACY_SSO_SOURCES:Ljava/util/Set;

    .line 24
    .line 25
    sget-object v1, LX/Fyo;->A0D:LX/Fyo;

    .line 26
    .line 27
    sget-object v0, LX/Fyo;->A0E:LX/Fyo;

    .line 28
    .line 29
    filled-new-array {v1, v0}, [LX/Fyo;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->IG_LEGACY_SSO_SOURCES:Ljava/util/Set;

    .line 38
    .line 39
    invoke-static {v0, v2}, LX/163;->A00(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    sget-object v1, LX/Fyo;->A0J:LX/Fyo;

    .line 44
    .line 45
    sget-object v0, LX/Fyo;->A0K:LX/Fyo;

    .line 46
    .line 47
    filled-new-array {v1, v0}, [LX/Fyo;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v0, v2}, LX/163;->A00(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->LEGACY_CONTENT_PROVIDER_SSO_SOURCES:Ljava/util/Set;

    .line 60
    .line 61
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsActiveReadDispatcher$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsActiveReadDispatcher$2;

    .line 62
    .line 63
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsActiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 68
    .line 69
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;

    .line 70
    .line 71
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsInactiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 76
    .line 77
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$fetchFxAccounts(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxAccounts(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$fetchFxCandidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxCandidates(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$fetchLinkingCandidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchLinkingCandidates(Landroid/content/Context;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$fetchV2Credentials(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchV2Credentials(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$fetchWhatsAppAccount(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchWhatsAppAccount(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getFB_LEGACY_SSO_SOURCES$p()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->FB_LEGACY_SSO_SOURCES:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getIG_LEGACY_SSO_SOURCES$p()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->IG_LEGACY_SSO_SOURCES:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getThreadsActiveReadDispatcher(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;)LX/DSG;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsActiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/DSG;

    .line 7
    .line 8
    return-object p0
.end method

.method public static final synthetic access$getThreadsInactiveReadDispatcher(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;)LX/DSG;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsInactiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/DSG;

    .line 7
    .line 8
    return-object p0
.end method

.method public static final synthetic access$legacyCandidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;)Ljava/util/List;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->legacyCandidates(Ljava/util/List;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$readWhatsAppAccount(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->readWhatsAppAccount(Landroid/content/Context;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$resolveSsoCandidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->resolveSsoCandidates(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$v2Candidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;)Ljava/util/List;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->v2Candidates(Ljava/util/List;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final fetchFxAccounts(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "+",
            "LX/FyX;",
            ">;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "LX/Ddn<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v4, p0

    .line 1
    instance-of v0, p4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p4

    .line 6
    check-cast p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    if-ne v0, v1, :cond_3

    .line 29
    .line 30
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->L$3:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 33
    .line 34
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    check-cast v3, Ljava/util/List;

    .line 38
    .line 39
    invoke-direct {v4, v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->merge(Ljava/util/List;)LX/Ddn;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    return-object v0

    .line 44
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->L$0:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->L$1:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->L$2:Ljava/lang/Object;

    .line 53
    .line 54
    iput-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->L$3:Ljava/lang/Object;

    .line 55
    .line 56
    iput v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;->label:I

    .line 57
    .line 58
    new-instance v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;

    .line 59
    .line 60
    move-object v5, p1

    .line 61
    move-object v7, p3

    .line 62
    invoke-direct {v8, p1, p3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;-><init>(Landroid/content/Context;Ljava/lang/String;LX/2M4;)V

    .line 63
    .line 64
    .line 65
    move-object v6, p2

    .line 66
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxCandidates(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    if-ne v3, v2, :cond_0

    .line 71
    .line 72
    return-object v2

    .line 73
    :cond_2
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;

    .line 74
    .line 75
    invoke-direct {p0, v4, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxAccounts$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V

    .line 76
    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    throw v0
.end method

.method public static synthetic fetchFxAccounts$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    and-int/lit8 v0, p5, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v1, LX/FyX;->A01:Ljava/util/Set;

    .line 5
    .line 6
    sget-object v0, LX/FyX;->A03:Ljava/util/Set;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/163;->A00(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    sget-object v0, LX/FyX;->A0D:LX/FyX;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/163;->A01(Ljava/lang/Object;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    const-string p3, "hatch_native_login"

    .line 23
    .line 24
    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxAccounts(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0
.end method

.method private final fetchFxCandidates(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "+",
            "LX/FyX;",
            ">;",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/Fna;->A03()Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$3;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$3;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    move-object v2, p0

    .line 10
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->e2eCandidates$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(ZLkotlin/jvm/functions/Function0;)Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    sget-object v4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$4;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$4;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;

    .line 18
    .line 19
    invoke-direct {p0, p1, p2, p3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;-><init>(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)V

    .line 20
    .line 21
    .line 22
    new-instance p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;

    .line 23
    .line 24
    invoke-direct {p1, p4, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$6;-><init>(LX/JDM;LX/2M4;)V

    .line 25
    .line 26
    .line 27
    move-object p2, p5

    .line 28
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->resolveSsoCandidates(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method

.method public static synthetic fetchFxCandidates$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    new-instance p4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;

    .line 6
    .line 7
    invoke-direct {p4, p1, p3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;-><init>(Landroid/content/Context;Ljava/lang/String;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxCandidates(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method private final fetchLegacyItems(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;LX/JDM;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "+",
            "LX/Fyo;",
            ">;",
            "Ljava/util/List<",
            "+",
            "LX/Fyo;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/Fym;",
            "+",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;)",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p1, LX/Fyr;

    .line 1
    .line 2
    invoke-direct {p1}, LX/Fyr;-><init>()V

    .line 3
    .line 4
    .line 5
    new-instance p0, Lcom/facebook/aura/auth/sso/accesslibrary/AuraAccessLibraryLogger;

    .line 6
    .line 7
    invoke-direct {p0}, LX/FyD;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p0, p1, LX/Fyr;->A04:LX/FyD;

    .line 11
    .line 12
    new-instance p0, LX/Fym;

    .line 13
    .line 14
    invoke-direct {p0, p1}, LX/Fym;-><init>(LX/Fyr;)V

    .line 15
    .line 16
    .line 17
    :try_start_0
    invoke-interface {p5, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    check-cast p0, Ljava/util/List;

    .line 22
    .line 23
    return-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 24
    :catch_0
    move-exception p2

    .line 25
    const-string p1, "SSO v1 account fetch failed"

    .line 26
    .line 27
    const-string p0, "NativeLoginAccountResolver"

    .line 28
    .line 29
    invoke-static {p0, p2, p1}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sget-object p0, LX/0wV;->A00:LX/0wV;

    .line 33
    .line 34
    return-object p0
.end method

.method public static synthetic fetchLegacyItems$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;LX/JDM;ILjava/lang/Object;)Ljava/util/List;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->LEGACY_CONTENT_PROVIDER_SSO_SOURCES:Ljava/util/Set;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    sget-object p4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->LEGACY_ACCOUNT_SWITCHER_SSO_SOURCES:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    new-instance p5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;

    .line 17
    .line 18
    invoke-direct {p5, p1, p3, p2, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;-><init>(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;Ljava/util/List;)V

    .line 19
    .line 20
    .line 21
    :cond_2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchLegacyItems(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;LX/JDM;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0
.end method

.method private final fetchLinkingCandidates(Landroid/content/Context;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, 0x0

    .line 6
    move-object v3, p1

    .line 7
    if-eq v2, v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    if-eq v2, v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    if-ne v2, v0, :cond_2

    .line 14
    .line 15
    sget-object v4, LX/FyX;->A04:Ljava/util/Set;

    .line 16
    .line 17
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4;

    .line 18
    .line 19
    invoke-direct {v6, p1, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 20
    .line 21
    .line 22
    :goto_0
    const-string v5, "hatch_native_linking"

    .line 23
    .line 24
    move-object v2, p0

    .line 25
    move-object p0, p3

    .line 26
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxCandidates(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0

    .line 31
    :cond_0
    sget-object v4, LX/FyX;->A01:Ljava/util/Set;

    .line 32
    .line 33
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$2;

    .line 34
    .line 35
    invoke-direct {v6, p1, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$2;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    sget-object v4, LX/FyX;->A03:Ljava/util/Set;

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$3;

    .line 42
    .line 43
    invoke-direct {v6, p1, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$3;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 44
    .line 45
    .line 46
    :goto_1
    check-cast v6, LX/JDM;

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_2
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    throw v0
.end method

.method private final fetchV2Credentials(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "+",
            "LX/FyX;",
            ">;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fwj;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v8, p4

    .line 5
    check-cast v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;

    .line 6
    .line 7
    iget v2, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v2, :cond_1

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_0
    new-instance v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;

    .line 31
    .line 32
    invoke-direct {v8, p0, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    throw v0

    .line 41
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :try_start_0
    sget-object v4, LX/FxA;->A05:LX/FxA;

    .line 45
    .line 46
    sget-object v1, LX/FyZ;->A03:LX/FyZ;

    .line 47
    .line 48
    sget-object v0, LX/FyZ;->A04:LX/FyZ;

    .line 49
    .line 50
    filled-new-array {v1, v0}, [LX/FyZ;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const/4 v0, 0x0

    .line 59
    new-instance p0, LX/Eio;

    .line 60
    .line 61
    invoke-direct {p0, v1, v0}, LX/Eio;-><init>(Ljava/util/Set;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    iput-object v0, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->L$0:Ljava/lang/Object;

    .line 65
    .line 66
    iput-object v0, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->L$1:Ljava/lang/Object;

    .line 67
    .line 68
    iput-object v0, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->L$2:Ljava/lang/Object;

    .line 69
    .line 70
    iput v2, v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchV2Credentials$1;->label:I

    .line 71
    .line 72
    move-object v5, p1

    .line 73
    move-object v7, p2

    .line 74
    move-object v6, p3

    .line 75
    invoke-virtual/range {v4 .. v9}, LX/FxA;->A03(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;LX/2M4;LX/Eio;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    if-ne v1, v3, :cond_3

    .line 80
    .line 81
    return-object v3

    .line 82
    :goto_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :cond_3
    check-cast v1, LX/I5d;

    .line 86
    .line 87
    iget-object v3, v1, LX/I5d;->A01:Ljava/util/List;

    .line 88
    .line 89
    return-object v3
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 90
    :catch_0
    move-exception v2

    .line 91
    const-string v1, "SSO account fetch failed"

    .line 92
    .line 93
    const-string v0, "NativeLoginAccountResolver"

    .line 94
    .line 95
    invoke-static {v0, v2, v1}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 99
    .line 100
    return-object v0

    .line 101
    :catch_1
    move-exception v0

    .line 102
    throw v0
.end method

.method private final fetchWhatsAppAccount(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;

    .line 1
    .line 2
    if-eqz v0, :cond_4

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_4

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object p0, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x1

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    if-ne v1, v5, :cond_5

    .line 28
    .line 29
    iget-object v4, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->L$1:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v4, LX/Cbu;

    .line 32
    .line 33
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    invoke-interface {v4}, LX/Cbu;->AOO()Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-nez v1, :cond_1

    .line 41
    .line 42
    const-string v2, "NativeLoginAccountResolver"

    .line 43
    .line 44
    const-string v1, "WhatsApp auth bundle read timed out"

    .line 45
    .line 46
    invoke-static {v2, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    :cond_1
    return-object v0

    .line 50
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-static {}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->isWhatsAppSsoEnabled()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    const/4 v3, 0x0

    .line 58
    if-nez v0, :cond_3

    .line 59
    .line 60
    return-object v3

    .line 61
    :cond_3
    new-instance v4, LX/DRG;

    .line 62
    .line 63
    invoke-direct {v4, v3}, LX/DRG;-><init>(LX/Cbu;)V

    .line 64
    .line 65
    .line 66
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->whatsAppReadExecutor$delegate:Lkotlin/Lazy;

    .line 67
    .line 68
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;

    .line 73
    .line 74
    invoke-direct {v0, v4, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;-><init>(LX/BcL;Landroid/content/Context;)V

    .line 75
    .line 76
    .line 77
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 78
    .line 79
    .line 80
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$account$1;

    .line 81
    .line 82
    invoke-direct {v2, v4, v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$account$1;-><init>(LX/BcL;LX/2M4;)V

    .line 83
    .line 84
    .line 85
    iput-object v3, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->L$0:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v4, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->L$1:Ljava/lang/Object;

    .line 88
    .line 89
    iput v5, v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;->label:I

    .line 90
    .line 91
    const-wide/16 v0, 0x6d6

    .line 92
    .line 93
    invoke-static {v6, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    if-ne v0, p0, :cond_0

    .line 98
    .line 99
    return-object p0

    .line 100
    :cond_4
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;

    .line 101
    .line 102
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V

    .line 103
    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0
.end method

.method private final getLinkingApp(Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;)Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;
    .locals 0

    .line 0
    iget-boolean p0, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->THREADS:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p1, p1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 8
    .line 9
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->FACEBOOK:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 10
    .line 11
    if-ne p1, p0, :cond_1

    .line 12
    .line 13
    sget-object p0, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->FACEBOOK:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_1
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->INSTAGRAM:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 17
    .line 18
    if-ne p1, p0, :cond_2

    .line 19
    .line 20
    sget-object p0, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->INSTAGRAM:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_2
    const/4 p0, 0x0

    .line 24
    return-object p0
.end method

.method private final getThreadsActiveReadDispatcher()LX/DSG;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsActiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/DSG;

    .line 7
    .line 8
    return-object p0
.end method

.method private final getThreadsInactiveReadDispatcher()LX/DSG;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsInactiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/DSG;

    .line 7
    .line 8
    return-object p0
.end method

.method private final legacyCandidates(Ljava/util/List;)Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_4

    .line 13
    .line 14
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, LX/Fz3;

    .line 19
    .line 20
    iget-object v2, v1, LX/Fz3;->A05:LX/Fyp;

    .line 21
    .line 22
    invoke-static {v2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->toSsoSourceApp(LX/Fyp;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    if-eqz v7, :cond_0

    .line 27
    .line 28
    iget-object v8, v1, LX/Fz3;->A02:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v8}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    iget-object v6, v1, LX/Fz3;->A03:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v1, v1, LX/Fz3;->A06:LX/FzB;

    .line 39
    .line 40
    sget-object v0, LX/FzB;->A02:LX/FzB;

    .line 41
    .line 42
    const/4 p0, 0x1

    .line 43
    const/4 p1, 0x0

    .line 44
    const/4 v9, 0x0

    .line 45
    if-ne v1, v0, :cond_1

    .line 46
    .line 47
    const/4 v9, 0x1

    .line 48
    :cond_1
    sget-object v0, LX/Fyp;->A0G:LX/Fyp;

    .line 49
    .line 50
    if-eq v2, v0, :cond_2

    .line 51
    .line 52
    const/4 p0, 0x0

    .line 53
    :cond_2
    sget-object v0, LX/Fyp;->A0M:LX/Fyp;

    .line 54
    .line 55
    if-ne v2, v0, :cond_3

    .line 56
    .line 57
    const/4 p1, 0x1

    .line 58
    :cond_3
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 59
    .line 60
    invoke-direct/range {v5 .. v11}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v3, v5}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_4
    return-object v3
.end method

.method private final merge(Ljava/util/List;)LX/Ddn;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;)",
            "LX/Ddn<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$1;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$1;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$2;

    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$3;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$3;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$4;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$merge$4;

    .line 7
    .line 8
    filled-new-array {v3, v2, v1, v0}, [LX/JDM;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    const/4 v1, 0x6

    .line 13
    new-instance v0, LX/3Qz;

    .line 14
    .line 15
    invoke-direct {v0, v2, v1}, LX/3Qz;-><init>(Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    invoke-static {p1, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    move-object v0, v3

    .line 45
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 46
    .line 47
    iget-object v2, v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 48
    .line 49
    iget-object v1, v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 50
    .line 51
    new-instance v0, LX/IBK;

    .line 52
    .line 53
    invoke-direct {v0, v2, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_0

    .line 61
    .line 62
    invoke-virtual {p1, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-static {p1}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_2

    .line 79
    .line 80
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 85
    .line 86
    iget-object v3, v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 87
    .line 88
    iget-object v2, v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 89
    .line 90
    iget-object v1, v0, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 91
    .line 92
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;

    .line 93
    .line 94
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_2
    invoke-static {p0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    return-object v0
.end method

.method public static synthetic pickerRows$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;Ljava/util/List;ILjava/util/Set;Ljava/util/Map;ILjava/lang/Object;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p4, LX/0wX;->A00:LX/0wX;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x10

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    sget-object p5, LX/0Xj;->A00:LX/0Xj;

    .line 11
    .line 12
    :cond_1
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->pickerRows(Ljava/util/List;Ljava/util/List;ILjava/util/Set;Ljava/util/Map;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method

.method private final readWhatsAppAccount(Landroid/content/Context;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;
    .locals 13

    .line 0
    const-string v2, "NativeLoginAccountResolver"

    .line 1
    .line 2
    const-string v3, "WhatsApp auth bundle not served: "

    .line 3
    .line 4
    const/4 v11, 0x0

    .line 5
    :try_start_0
    sget-object v0, LX/Fce;->A00:LX/FcY;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    .line 9
    .line 10
    .line 11
    :try_start_1
    const-string v0, "content://com.whatsapp.accesslibraryprovider.credentials.FamilyAppsCredentialsProvider"

    .line 12
    .line 13
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 14
    .line 15
    .line 16
    move-result-object v10

    .line 17
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v0, "com.whatsapp.accesslibraryprovider.credentials.FamilyAppsCredentialsProvider"

    .line 22
    .line 23
    invoke-virtual {v1, v0, v4}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 30
    .line 31
    :goto_0
    new-instance v4, LX/FzV;

    .line 32
    .line 33
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 34
    .line 35
    .line 36
    goto/16 :goto_8

    .line 37
    .line 38
    :cond_0
    iget-object v1, v0, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 39
    .line 40
    const-string v0, "com.whatsapp"

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_3

    .line 47
    .line 48
    invoke-static {v10}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    sget-object v6, LX/Fce;->A00:LX/FcY;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    .line 52
    .line 53
    :try_start_2
    invoke-virtual {v10}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    invoke-virtual {v10}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    const/4 v1, 0x0

    .line 62
    if-nez v5, :cond_2

    .line 63
    .line 64
    invoke-virtual {v10}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    :cond_1
    :goto_1
    invoke-static {p1, v1, v6}, LX/FcY;->A01(Landroid/content/Context;LX/Fbs;LX/FcY;)V

    .line 68
    .line 69
    .line 70
    goto :goto_2

    .line 71
    :cond_2
    if-eqz v4, :cond_1

    .line 72
    .line 73
    const-string v0, "content"

    .line 74
    .line 75
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_1

    .line 80
    .line 81
    invoke-static {p1, v5}, LX/Fbs;->A02(Landroid/content/Context;Ljava/lang/String;)LX/Fbs;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    goto :goto_1
    :try_end_2
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    .line 86
    :catch_0
    :cond_3
    :try_start_3
    const-string v0, "WhatsApp credentials provider failed verification"

    .line 87
    .line 88
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    sget-object v0, LX/FkO;->A01:Ljava/lang/Integer;

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :goto_2
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 95
    .line 96
    .line 97
    move-result-object v9

    .line 98
    const-string v12, "account_credentials"

    .line 99
    .line 100
    move-object p0, v11

    .line 101
    move-object p1, v11

    .line 102
    invoke-virtual/range {v9 .. v14}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 103
    .line 104
    .line 105
    move-result-object v8

    .line 106
    if-nez v8, :cond_4
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 107
    .line 108
    :try_start_4
    sget-object v0, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 109
    .line 110
    new-instance v4, LX/FzV;

    .line 111
    .line 112
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 113
    .line 114
    .line 115
    goto/16 :goto_8

    .line 116
    .line 117
    :cond_4
    invoke-interface {v8}, Landroid/database/Cursor;->getExtras()Landroid/os/Bundle;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    const-string/jumbo v0, "wire_version"

    .line 122
    .line 123
    .line 124
    const/4 v5, -0x1

    .line 125
    invoke-virtual {v6, v0, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    const/4 v0, 0x1

    .line 130
    if-eq v1, v0, :cond_5

    .line 131
    .line 132
    sget-object v0, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 133
    .line 134
    new-instance v4, LX/FzV;

    .line 135
    .line 136
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 137
    .line 138
    .line 139
    goto/16 :goto_7

    .line 140
    .line 141
    :cond_5
    const-string/jumbo v0, "response_code"

    .line 142
    .line 143
    .line 144
    invoke-virtual {v6, v0, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    sget-object v0, Lcom/whatsapp/accountlinking/ipc/api/models/ResponseCode;->A03:Lcom/whatsapp/accountlinking/ipc/api/models/ResponseCode;

    .line 149
    .line 150
    iget v0, v0, Lcom/whatsapp/accountlinking/ipc/api/models/ResponseCode;->code:I

    .line 151
    .line 152
    if-eq v1, v0, :cond_b

    .line 153
    .line 154
    const-string v0, "error_code"

    .line 155
    .line 156
    invoke-virtual {v6, v0, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 157
    .line 158
    .line 159
    move-result v4

    .line 160
    const-string v0, "error_sub_code"

    .line 161
    .line 162
    invoke-virtual {v6, v0, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    sget-object v0, LX/DYk;->A05:LX/DYk;

    .line 167
    .line 168
    iget v0, v0, LX/DYk;->code:I

    .line 169
    .line 170
    if-ne v4, v0, :cond_7

    .line 171
    .line 172
    sget-object v1, LX/FkO;->A0W:Ljava/lang/Integer;

    .line 173
    .line 174
    :goto_3
    sget-object v0, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 175
    .line 176
    if-ne v1, v0, :cond_6

    .line 177
    .line 178
    new-instance v4, LX/FzW;

    .line 179
    .line 180
    invoke-direct {v4, v1}, LX/FzW;-><init>(Ljava/lang/Integer;)V

    .line 181
    .line 182
    .line 183
    :goto_4
    check-cast v4, LX/Fzn;

    .line 184
    .line 185
    goto/16 :goto_7

    .line 186
    .line 187
    :cond_6
    new-instance v4, LX/FzV;

    .line 188
    .line 189
    invoke-direct {v4, v1}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 190
    .line 191
    .line 192
    goto :goto_4

    .line 193
    :cond_7
    sget-object v0, Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;->A03:Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;

    .line 194
    .line 195
    iget v0, v0, Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;->code:I

    .line 196
    .line 197
    if-ne v1, v0, :cond_8

    .line 198
    .line 199
    sget-object v1, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 200
    .line 201
    goto :goto_3

    .line 202
    :cond_8
    sget-object v0, Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;->A02:Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;

    .line 203
    .line 204
    iget v0, v0, Lcom/whatsapp/accountlinking/ipc/api/models/ErrorSubCode;->code:I

    .line 205
    .line 206
    if-ne v1, v0, :cond_9

    .line 207
    .line 208
    sget-object v1, LX/FkO;->A0K:Ljava/lang/Integer;

    .line 209
    .line 210
    goto :goto_3

    .line 211
    :cond_9
    sget-object v0, LX/DYk;->A02:LX/DYk;

    .line 212
    .line 213
    iget v0, v0, LX/DYk;->code:I

    .line 214
    .line 215
    if-ne v4, v0, :cond_a

    .line 216
    .line 217
    sget-object v1, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 218
    .line 219
    goto :goto_3

    .line 220
    :cond_a
    sget-object v1, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 221
    .line 222
    goto :goto_3

    .line 223
    :cond_b
    invoke-interface {v8}, Landroid/database/Cursor;->moveToFirst()Z

    .line 224
    .line 225
    .line 226
    move-result v0

    .line 227
    if-nez v0, :cond_c

    .line 228
    .line 229
    sget-object v0, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 230
    .line 231
    new-instance v4, LX/FzV;

    .line 232
    .line 233
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 234
    .line 235
    .line 236
    goto :goto_7

    .line 237
    :cond_c
    const-string/jumbo v0, "restricted_token"

    .line 238
    .line 239
    .line 240
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v10

    .line 248
    const-string v0, "expiration_ts"

    .line 249
    .line 250
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 255
    .line 256
    .line 257
    move-result-wide v4

    .line 258
    const-string v0, "data_bundle"

    .line 259
    .line 260
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 261
    .line 262
    .line 263
    move-result v0

    .line 264
    if-ltz v0, :cond_d

    .line 265
    .line 266
    invoke-interface {v8, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v9

    .line 270
    goto :goto_5

    .line 271
    :cond_d
    const/4 v9, 0x0

    .line 272
    :goto_5
    if-eqz v10, :cond_f

    .line 273
    .line 274
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_f

    .line 279
    .line 280
    if-eqz v9, :cond_f

    .line 281
    .line 282
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 283
    .line 284
    .line 285
    move-result v0

    .line 286
    if-eqz v0, :cond_f

    .line 287
    .line 288
    const-wide/16 v6, 0x0

    .line 289
    .line 290
    cmp-long v0, v4, v6

    .line 291
    .line 292
    if-lez v0, :cond_e

    .line 293
    .line 294
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 295
    .line 296
    .line 297
    move-result-wide v6

    .line 298
    cmp-long v0, v6, v4

    .line 299
    .line 300
    if-gez v0, :cond_e

    .line 301
    .line 302
    new-instance v1, LX/Fzc;

    .line 303
    .line 304
    invoke-direct {v1, v10, v9, v4, v5}, LX/Fzc;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    .line 305
    .line 306
    .line 307
    new-instance v0, LX/Ez0;

    .line 308
    .line 309
    invoke-direct {v0, v1}, LX/Ez0;-><init>(Ljava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    new-instance v4, LX/FzT;

    .line 313
    .line 314
    invoke-direct {v4, v0}, LX/FzT;-><init>(LX/Ez0;)V

    .line 315
    .line 316
    .line 317
    goto :goto_7

    .line 318
    :cond_e
    sget-object v0, LX/FkO;->A0T:Ljava/lang/Integer;

    .line 319
    .line 320
    goto :goto_6

    .line 321
    :cond_f
    sget-object v0, LX/FkO;->A0P:Ljava/lang/Integer;

    .line 322
    .line 323
    :goto_6
    new-instance v4, LX/FzV;

    .line 324
    .line 325
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 326
    .line 327
    .line 328
    :goto_7
    :try_start_5
    invoke-interface {v8}, Landroid/database/Cursor;->close()V

    .line 329
    .line 330
    .line 331
    goto :goto_8
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    .line 332
    :catchall_0
    move-exception v1

    .line 333
    :try_start_6
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 334
    :catchall_1
    :try_start_7
    move-exception v0

    .line 335
    invoke-static {v8, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 336
    .line 337
    .line 338
    throw v0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    .line 339
    :catch_1
    move-exception v1

    .line 340
    :try_start_8
    const-string v0, "WhatsApp credentials provider read failed"

    .line 341
    .line 342
    invoke-static {v2, v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 343
    .line 344
    .line 345
    sget-object v0, LX/FkO;->A0c:Ljava/lang/Integer;

    .line 346
    .line 347
    new-instance v4, LX/FzV;

    .line 348
    .line 349
    invoke-direct {v4, v0}, LX/FzV;-><init>(Ljava/lang/Integer;)V

    .line 350
    .line 351
    .line 352
    :goto_8
    instance-of v1, v4, LX/FzT;

    .line 353
    .line 354
    if-eqz v1, :cond_10

    .line 355
    .line 356
    goto :goto_9

    .line 357
    :cond_10
    instance-of v0, v4, LX/FzV;

    .line 358
    .line 359
    if-eqz v0, :cond_11

    .line 360
    .line 361
    move-object v0, v4

    .line 362
    check-cast v0, LX/FzV;

    .line 363
    .line 364
    iget-object v0, v0, LX/FzV;->A00:Ljava/lang/Integer;

    .line 365
    .line 366
    invoke-static {v0}, LX/I63;->A00(Ljava/lang/Integer;)Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v0

    .line 370
    goto :goto_a

    .line 371
    :cond_11
    instance-of v0, v4, LX/FzW;

    .line 372
    .line 373
    if-eqz v0, :cond_14

    .line 374
    .line 375
    move-object v0, v4

    .line 376
    check-cast v0, LX/FzW;

    .line 377
    .line 378
    iget-object v0, v0, LX/FzW;->A00:Ljava/lang/Integer;

    .line 379
    .line 380
    invoke-static {v0}, LX/I63;->A00(Ljava/lang/Integer;)Ljava/lang/String;

    .line 381
    .line 382
    .line 383
    move-result-object v0

    .line 384
    goto :goto_a

    .line 385
    :goto_9
    move-object v0, v11

    .line 386
    :goto_a
    if-nez v1, :cond_12

    .line 387
    .line 388
    invoke-static {v3, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    invoke-static {v2, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 393
    .line 394
    .line 395
    return-object v11
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    .line 396
    :cond_12
    :try_start_9
    new-instance v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;

    .line 397
    .line 398
    invoke-direct {v3, v4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;-><init>(LX/Fzn;)V

    .line 399
    .line 400
    .line 401
    const/4 v0, 0x2

    .line 402
    sget-object v1, LX/Fzi;->A00:Ljava/lang/ThreadLocal;

    .line 403
    .line 404
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    invoke-virtual {v1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    :try_end_9
    .catch LX/Fzk; {:try_start_9 .. :try_end_9} :catch_2
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_3

    .line 409
    .line 410
    .line 411
    :try_start_a
    invoke-virtual {v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;->invoke()Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    move-result-object v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 415
    :try_start_b
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 416
    .line 417
    .line 418
    check-cast v0, LX/Fzc;

    .line 419
    .line 420
    if-eqz v0, :cond_13
    :try_end_b
    .catch LX/Fzk; {:try_start_b .. :try_end_b} :catch_2
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_3

    .line 421
    .line 422
    :try_start_c
    iget-object v4, v0, LX/Fzc;->A00:Ljava/lang/String;

    .line 423
    .line 424
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 425
    .line 426
    .line 427
    move-result v0

    .line 428
    if-nez v0, :cond_13

    .line 429
    .line 430
    const-string/jumbo v3, "whatsapp"

    .line 431
    .line 432
    .line 433
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->WHATSAPP:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 434
    .line 435
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;

    .line 436
    .line 437
    invoke-direct {v0, v3, v1, v4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;)V

    .line 438
    .line 439
    .line 440
    return-object v0

    .line 441
    :cond_13
    const-string v0, "WhatsApp auth bundle not served: blank_token"

    .line 442
    .line 443
    invoke-static {v2, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    return-object v11
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_3

    .line 447
    :catchall_2
    :try_start_d
    move-exception v0

    .line 448
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 449
    .line 450
    .line 451
    throw v0
    :try_end_d
    .catch LX/Fzk; {:try_start_d .. :try_end_d} :catch_2
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_3

    .line 452
    :catch_2
    move-exception v1

    .line 453
    :try_start_e
    const-string v0, "WhatsApp auth bundle not served: policy_refused"

    .line 454
    .line 455
    invoke-static {v2, v1, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 456
    .line 457
    .line 458
    return-object v11

    .line 459
    :cond_14
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 460
    .line 461
    .line 462
    move-result-object v0

    .line 463
    throw v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_3

    .line 464
    :catch_3
    move-exception v1

    .line 465
    const-string v0, "WhatsApp auth bundle read failed"

    .line 466
    .line 467
    invoke-static {v2, v1, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    return-object v11
.end method

.method private final resolveSsoCandidates(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    if-nez p1, :cond_1

    .line 1
    .line 2
    invoke-static {p2}, LX/003;->A1a(Lkotlin/jvm/functions/Function0;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    invoke-interface {p3, p5}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :cond_0
    invoke-interface {p4, p5}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :cond_1
    return-object p1
.end method

.method private final v2Candidates(Ljava/util/List;)Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LX/Fwj;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_3

    .line 13
    .line 14
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, LX/Fwj;

    .line 19
    .line 20
    iget-object v2, v1, LX/Fwj;->A03:LX/FyX;

    .line 21
    .line 22
    invoke-static {v2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->toSsoSourceApp(LX/FyX;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    if-eqz v7, :cond_0

    .line 27
    .line 28
    iget-object v8, v1, LX/Fwj;->A01:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v8}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    iget-object v6, v1, LX/Fwj;->A02:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v1, v1, LX/Fwj;->A04:LX/FyZ;

    .line 39
    .line 40
    sget-object v0, LX/FyZ;->A03:LX/FyZ;

    .line 41
    .line 42
    const/4 p0, 0x1

    .line 43
    const/4 p1, 0x0

    .line 44
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v9

    .line 48
    sget-object v0, LX/FyX;->A0C:LX/FyX;

    .line 49
    .line 50
    if-eq v2, v0, :cond_1

    .line 51
    .line 52
    const/4 p0, 0x0

    .line 53
    :cond_1
    sget-object v0, LX/FyX;->A0F:LX/FyX;

    .line 54
    .line 55
    if-ne v2, v0, :cond_2

    .line 56
    .line 57
    const/4 p1, 0x1

    .line 58
    :cond_2
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 59
    .line 60
    invoke-direct/range {v5 .. v11}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v3, v5}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_3
    return-object v3
.end method


# virtual methods
.method public final e2eCandidates$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(ZLkotlin/jvm/functions/Function0;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v3, 0x0

    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/String;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    :try_start_0
    invoke-virtual {p0, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->parseE2ECandidates$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(Ljava/lang/String;)Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    return-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    :catch_0
    move-exception v2

    .line 27
    const-string v1, "E2E token parse failed; falling back to production readers"

    .line 28
    .line 29
    const-string v0, "NativeLoginAccountResolver"

    .line 30
    .line 31
    invoke-static {v0, v2, v1}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return-object v3

    .line 35
    :cond_0
    return-object v3
.end method

.method public final fetchLinkingCredentials(Landroid/content/Context;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLinkingCredential;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;

    .line 1
    .line 2
    if-eqz v0, :cond_a

    .line 3
    .line 4
    move-object v3, p3

    .line 5
    check-cast v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_a

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    if-eqz v0, :cond_8

    .line 26
    .line 27
    if-ne v0, v1, :cond_b

    .line 28
    .line 29
    iget-object p2, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->L$1:Ljava/lang/Object;

    .line 30
    .line 31
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    check-cast v2, Ljava/lang/Iterable;

    .line 35
    .line 36
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    :cond_1
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    move-object v1, v2

    .line 55
    check-cast v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 56
    .line 57
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 58
    .line 59
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->getLinkingApp(Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;)Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    if-ne v0, p2, :cond_1

    .line 64
    .line 65
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$$inlined$sortedBy$1;

    .line 70
    .line 71
    invoke-direct {v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$$inlined$sortedBy$1;-><init>()V

    .line 72
    .line 73
    .line 74
    invoke-static {v4, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 87
    .line 88
    .line 89
    move-result-object v4

    .line 90
    :cond_3
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_4

    .line 95
    .line 96
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    move-object v2, v3

    .line 101
    check-cast v2, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 102
    .line 103
    iget-boolean v0, v2, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 104
    .line 105
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    iget-object v0, v2, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 110
    .line 111
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_3

    .line 120
    .line 121
    invoke-virtual {v5, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_4
    const/16 v0, 0xa

    .line 126
    .line 127
    invoke-static {v5, v0}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 136
    .line 137
    .line 138
    move-result-object p0

    .line 139
    :goto_3
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-eqz v0, :cond_9

    .line 144
    .line 145
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    check-cast v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 150
    .line 151
    iget-object v4, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->userId:Ljava/lang/String;

    .line 152
    .line 153
    iget-boolean v0, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isMessenger:Z

    .line 154
    .line 155
    if-eqz v0, :cond_6

    .line 156
    .line 157
    const-string v3, "messenger"

    .line 158
    .line 159
    :goto_4
    iget-boolean v0, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isActive:Z

    .line 160
    .line 161
    if-eqz v0, :cond_5

    .line 162
    .line 163
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->ACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 164
    .line 165
    :goto_5
    iget-object v1, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->accessToken:Ljava/lang/String;

    .line 166
    .line 167
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLinkingCredential;

    .line 168
    .line 169
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLinkingCredential;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    goto :goto_3

    .line 176
    :cond_5
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->INACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 177
    .line 178
    goto :goto_5

    .line 179
    :cond_6
    iget-boolean v0, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->isThreads:Z

    .line 180
    .line 181
    if-eqz v0, :cond_7

    .line 182
    .line 183
    const-string/jumbo v3, "threads"

    .line 184
    .line 185
    .line 186
    goto :goto_4

    .line 187
    :cond_7
    iget-object v0, v1, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;->sourceApp:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 188
    .line 189
    invoke-virtual {v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->getWireValue()Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    goto :goto_4

    .line 194
    :cond_8
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    const/4 v0, 0x0

    .line 198
    iput-object v0, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->L$0:Ljava/lang/Object;

    .line 199
    .line 200
    iput-object p2, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->L$1:Ljava/lang/Object;

    .line 201
    .line 202
    iput v1, v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;->label:I

    .line 203
    .line 204
    invoke-direct {p0, p1, p2, v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchLinkingCandidates(Landroid/content/Context;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    if-ne v2, v5, :cond_0

    .line 209
    .line 210
    :cond_9
    return-object v5

    .line 211
    :cond_a
    new-instance v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;

    .line 212
    .line 213
    invoke-direct {v3, p0, p3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCredentials$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V

    .line 214
    .line 215
    .line 216
    goto/16 :goto_0

    .line 217
    .line 218
    :cond_b
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    throw v0
.end method

.method public final fetchSsoAccounts(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "LX/Ddn<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;

    .line 2
    .line 3
    invoke-direct {v0, p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 4
    .line 5
    .line 6
    invoke-static {v0, p2}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final parseE2ECandidates$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(Ljava/lang/String;)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p1}, LX/FnH;->A01(Ljava/lang/String;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    :cond_0
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, LX/FxU;

    .line 23
    .line 24
    iget-object v4, v1, LX/FxU;->A02:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const-string v3, "barcelona"

    .line 31
    .line 32
    const-string v5, "messenger"

    .line 33
    .line 34
    sparse-switch v0, :sswitch_data_0

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :sswitch_0
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    goto :goto_1

    .line 43
    :sswitch_1
    const-string v0, "facebook"

    .line 44
    .line 45
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    goto :goto_2

    .line 50
    :sswitch_2
    const-string v0, "instagram"

    .line 51
    .line 52
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    :goto_1
    if-eqz v0, :cond_0

    .line 57
    .line 58
    sget-object v9, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->INSTAGRAM:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 59
    .line 60
    goto :goto_3

    .line 61
    :sswitch_3
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    :goto_2
    if-eqz v0, :cond_0

    .line 66
    .line 67
    sget-object v9, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->FACEBOOK:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 68
    .line 69
    :goto_3
    iget-object v8, v1, LX/FxU;->A03:Ljava/lang/String;

    .line 70
    .line 71
    if-eqz v8, :cond_0

    .line 72
    .line 73
    invoke-static {v8}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-nez v0, :cond_0

    .line 78
    .line 79
    iget-object v10, v1, LX/FxU;->A00:Ljava/lang/String;

    .line 80
    .line 81
    if-eqz v10, :cond_0

    .line 82
    .line 83
    invoke-static {v10}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-nez v0, :cond_0

    .line 88
    .line 89
    iget-object v1, v1, LX/FxU;->A01:Ljava/lang/String;

    .line 90
    .line 91
    if-eqz v1, :cond_1

    .line 92
    .line 93
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->ACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 94
    .line 95
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-nez v0, :cond_1

    .line 100
    .line 101
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->INACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 102
    .line 103
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_0

    .line 108
    .line 109
    const/4 v11, 0x0

    .line 110
    :goto_4
    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result p0

    .line 114
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    new-instance v7, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;

    .line 119
    .line 120
    invoke-direct/range {v7 .. v13}, Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;Ljava/lang/String;ZZZ)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v2, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_1
    const/4 v11, 0x1

    .line 128
    goto :goto_4

    .line 129
    :cond_2
    return-object v2

    .line 130
    :sswitch_data_0
    .sparse-switch
        -0x559944ed -> :sswitch_3
        0x1b907b2 -> :sswitch_2
        0x1da19ac6 -> :sswitch_1
        0x5bbcb3ab -> :sswitch_0
    .end sparse-switch
.end method

.method public final pickerRows(Ljava/util/List;Ljava/util/List;ILjava/util/Set;Ljava/util/Map;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;",
            ">;",
            "Ljava/util/List<",
            "+TS;>;I",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchMuseProfile;",
            ">;)",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows<",
            "TS;>;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    invoke-static {p2, p4, p5, v4}, LX/005;->A11(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    move-object v0, v1

    .line 27
    check-cast v0, Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;

    .line 28
    .line 29
    iget-object v0, v0, Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;->savedAccountId:Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-interface {p4, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-ne v0, v4, :cond_0

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    :cond_2
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_4

    .line 61
    .line 62
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    move-object v1, v2

    .line 67
    check-cast v1, Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;

    .line 68
    .line 69
    iget-object v0, v1, Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;->metaAccountId:Ljava/lang/String;

    .line 70
    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    iget-object v0, v1, Lcom/facebook/aura/auth/login/credentials/AuraRememberedAccount;->abraUserId:Ljava/lang/String;

    .line 74
    .line 75
    :cond_3
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_4
    invoke-static {v4, p3}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    sub-int/2addr p3, v0

    .line 94
    if-ge p3, p0, :cond_5

    .line 95
    .line 96
    const/4 p3, 0x0

    .line 97
    :cond_5
    invoke-static {p2, p3}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows;

    .line 102
    .line 103
    invoke-direct {v0, v2, v1, p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginPickerRows;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/Map;)V

    .line 104
    .line 105
    .line 106
    return-object v0
.end method

.method public final resolveSsoAccounts$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/Ddn<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v4, p0

    .line 1
    instance-of v0, p5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p5

    .line 6
    check-cast p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    if-ne v0, v1, :cond_3

    .line 29
    .line 30
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$4:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 33
    .line 34
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    check-cast v3, Ljava/util/List;

    .line 38
    .line 39
    invoke-direct {v4, v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->merge(Ljava/util/List;)LX/Ddn;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    return-object v0

    .line 44
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$0:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$1:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$2:Ljava/lang/Object;

    .line 53
    .line 54
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$3:Ljava/lang/Object;

    .line 55
    .line 56
    iput-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->L$4:Ljava/lang/Object;

    .line 57
    .line 58
    iput v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 59
    .line 60
    move-object v5, p1

    .line 61
    move-object v6, p2

    .line 62
    move-object v7, p3

    .line 63
    move-object v8, p4

    .line 64
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->resolveSsoCandidates(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    if-ne v3, v2, :cond_0

    .line 69
    .line 70
    return-object v2

    .line 71
    :cond_2
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;

    .line 72
    .line 73
    invoke-direct {p0, v4, p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    throw v0
.end method
