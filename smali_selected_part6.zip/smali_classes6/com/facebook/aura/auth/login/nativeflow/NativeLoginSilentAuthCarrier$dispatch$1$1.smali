.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $config:LX/GGu;

.field public final synthetic $hops:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic $network:LX/GGt;

.field public final synthetic $params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

.field public final synthetic $release:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

.field public final synthetic $this_runCatching:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;",
            "LX/GGt;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;",
            "LX/GGu;",
            "Ljava/util/concurrent/atomic/AtomicInteger;",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$this_runCatching:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$network:LX/GGt;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$release:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$config:LX/GGu;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 13
    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$this_runCatching:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$network:LX/GGt;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$release:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 7
    .line 8
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$config:LX/GGu;

    .line 9
    .line 10
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 11
    .line 12
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 13
    .line 14
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->access$runAndRelease(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
