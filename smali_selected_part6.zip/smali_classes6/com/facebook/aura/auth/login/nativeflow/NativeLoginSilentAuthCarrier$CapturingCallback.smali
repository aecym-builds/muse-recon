.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public volatile failure:LX/Hrg;

.field public volatile success:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getFailure()LX/Hrg;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->failure:LX/Hrg;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSuccess()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->success:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public onConnectionLog(Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onFailure(LX/Hrg;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->failure:LX/Hrg;

    .line 5
    .line 6
    return-void
.end method

.method public onSuccess(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->success:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method public final setFailure(LX/Hrg;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->failure:LX/Hrg;

    .line 1
    .line 2
    return-void
.end method

.method public final setSuccess(Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$CapturingCallback;->success:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method
