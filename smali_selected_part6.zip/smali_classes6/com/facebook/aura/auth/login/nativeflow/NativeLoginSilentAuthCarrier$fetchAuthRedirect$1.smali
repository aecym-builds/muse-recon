.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Ljava/lang/Integer;",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $hops:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic $settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    check-cast p2, Ljava/lang/String;

    .line 268435461
    .line 268435462
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->invoke(ILjava/lang/String;)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(ILjava/lang/String;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 1
    .line 2
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->isActive()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    const-string/jumbo v0, "silent auth deadline passed"

    .line 15
    .line 16
    .line 17
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    throw v0
.end method
