.class public final Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/JmJ<",
        "-",
        "Landroid/content/Intent;",
        ">;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.SmsOtpUserConsent$consentIntents$1"
    f = "SmsOtpUserConsent.kt"
    l = {
        0x5c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/JmJ;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JmJ<",
            "-",
            "Landroid/content/Intent;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/JmJ;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->invoke(LX/JmJ;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    iget-object v8, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v8, LX/JmJ;

    .line 3
    .line 4
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->label:I

    .line 7
    .line 8
    const/4 v6, 0x1

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    if-ne v0, v6, :cond_2

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    return-object v7

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;

    .line 23
    .line 24
    invoke-direct {v5, v8}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;-><init>(LX/JmJ;)V

    .line 25
    .line 26
    .line 27
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->$context:Landroid/content/Context;

    .line 28
    .line 29
    const-string v0, "com.google.android.gms.auth.api.phone.SMS_RETRIEVED"

    .line 30
    .line 31
    new-instance v3, Landroid/content/IntentFilter;

    .line 32
    .line 33
    invoke-direct {v3, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    const/4 v1, 0x2

    .line 38
    const-string v0, "com.google.android.gms.auth.api.phone.permission.SEND"

    .line 39
    .line 40
    invoke-static {v5, v4, v3, v0, v1}, LX/IBg;->A05(Landroid/content/BroadcastReceiver;Landroid/content/Context;Landroid/content/IntentFilter;Ljava/lang/String;I)V

    .line 41
    .line 42
    .line 43
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->$context:Landroid/content/Context;

    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;

    .line 46
    .line 47
    invoke-direct {v0, v8, v1, v5}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;-><init>(LX/JmJ;Landroid/content/Context;Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;)V

    .line 48
    .line 49
    .line 50
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->L$0:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->L$1:Ljava/lang/Object;

    .line 53
    .line 54
    iput v6, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;->label:I

    .line 55
    .line 56
    invoke-static {p0, v0, v8}, LX/BdO;->A00(LX/2M4;Lkotlin/jvm/functions/Function0;LX/JmJ;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-ne v0, v7, :cond_0

    .line 61
    .line 62
    return-object v7

    .line 63
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method
