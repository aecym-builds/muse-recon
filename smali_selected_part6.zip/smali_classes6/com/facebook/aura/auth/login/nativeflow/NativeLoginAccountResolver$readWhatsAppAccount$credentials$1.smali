.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/Fzc;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $result:LX/Fzn;


# direct methods
.method public constructor <init>(LX/Fzn;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;->$result:LX/Fzn;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()LX/Fzc;
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;->$result:LX/Fzn;

    .line 1
    .line 2
    check-cast v0, LX/FzT;

    .line 3
    .line 4
    iget-object p0, v0, LX/FzT;->A00:LX/Ez0;

    .line 5
    .line 6
    const-string v3, "HATCH_SSO_WA_AUTH_BUNDLE"

    .line 7
    .line 8
    sget-object v0, LX/Fzi;->A00:Ljava/lang/ThreadLocal;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    check-cast v2, Ljava/lang/Number;

    .line 15
    .line 16
    const/4 v1, 0x2

    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ne v0, v1, :cond_1

    .line 24
    .line 25
    sget-object v0, LX/JWD;->A00:Ljava/util/Map;

    .line 26
    .line 27
    invoke-static {v0, v1}, LX/EYt;->A0f(Ljava/util/Map;I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, LX/Jle;

    .line 32
    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    iget-object v0, v0, LX/Jle;->A00:Ljava/util/Set;

    .line 36
    .line 37
    invoke-interface {v0, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    const/4 v0, 0x1

    .line 42
    if-ne v1, v0, :cond_0

    .line 43
    .line 44
    iget-object v0, p0, LX/Ez0;->A00:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, LX/Fzc;

    .line 47
    .line 48
    return-object v0

    .line 49
    :cond_0
    const-string v0, "Purpose policy does not allow data to be extracted for purpose "

    .line 50
    .line 51
    invoke-static {v0, v3}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-string v0, "PurposeEnforcementViolation: "

    .line 56
    .line 57
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    new-instance v0, LX/Fzk;

    .line 62
    .line 63
    invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    throw v0

    .line 67
    :cond_1
    const-string v0, "Invalid policyId ="

    .line 68
    .line 69
    invoke-static {v2, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    const-string v0, ". All calls to unwrapSensitiveValueFor() should be enclosed within PolicyZone enclosure and specified with the same policyid that this object was wrapped with"

    .line 74
    .line 75
    invoke-static {v0, v1}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    const-string v0, "PurposeEnforcementViolation: "

    .line 80
    .line 81
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    new-instance v0, LX/Fzk;

    .line 86
    .line 87
    invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    throw v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$readWhatsAppAccount$credentials$1;->invoke()LX/Fzc;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
