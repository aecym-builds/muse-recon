.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/GGt;",
        "Lkotlin/jvm/functions/Function0<",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $config:LX/GGu;

.field public final synthetic $hops:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic $params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

.field public final synthetic $settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

.field public final synthetic this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$config:LX/GGu;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/GGt;

    .line 268435457
    .line 268435458
    check-cast p2, Lkotlin/jvm/functions/Function0;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->invoke(LX/GGt;Lkotlin/jvm/functions/Function0;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object p0
.end method

.method public final invoke(LX/GGt;Lkotlin/jvm/functions/Function0;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/GGt;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 6
    .line 7
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 8
    .line 9
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$config:LX/GGu;

    .line 10
    .line 11
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 12
    .line 13
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 14
    .line 15
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->access$dispatch(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
