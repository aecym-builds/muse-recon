.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.HatchRegistrationAttestor$attest$result$1$1$1"
    f = "HatchRegistrationAttestor.kt"
    l = {
        0x61
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v3

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 21
    .line 22
    iput v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;->label:I

    .line 23
    .line 24
    invoke-static {v1, v0, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->access$finishRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    if-ne v0, v3, :cond_0

    .line 29
    .line 30
    return-object v3

    .line 31
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    throw v0
.end method
