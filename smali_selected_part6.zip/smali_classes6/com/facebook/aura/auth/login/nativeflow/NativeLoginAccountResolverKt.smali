.class public abstract Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final ACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

.field public static final INACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

.field public static final LEGACY_ACCOUNT_SWITCHER_SSO_SOURCES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field

.field public static final LINKING_LOG_LOCATION:Ljava/lang/String; = "hatch_native_linking"

.field public static final LOG_LOCATION:Ljava/lang/String; = "hatch_native_login"

.field public static final MAX_LINKING_CREDENTIALS:I = 0xa

.field public static final MESSENGER_SOURCE_APP:Ljava/lang/String; = "messenger"

.field public static final TAG:Ljava/lang/String; = "NativeLoginAccountResolver"

.field public static final THREADS_SOURCE_APP:Ljava/lang/String; = "threads"

.field public static final WHATSAPP_AUTH_BUNDLE_FETCH_TIMEOUT_MS:J = 0x6d6L

.field public static final WHATSAPP_USER_ID:Ljava/lang/String; = "whatsapp"

.field public static final XAPP_E2E_TOKENS_KEY:Ljava/lang/String; = "xapp.e2e.tokens"

.field public static final isWhatsAppSsoEnabled$delegate:LX/1zE;

.field public static final whatsAppReadExecutor$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    const-string v2, "isWhatsAppSsoEnabled"

    .line 2
    .line 3
    const-string v1, "isWhatsAppSsoEnabled()Z"

    .line 4
    .line 5
    const-class v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;

    .line 6
    .line 7
    invoke-static {v0, v2, v1, v3}, LX/602;->A1a(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)[LX/Dqa;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->$$delegatedProperties:[LX/Dqa;

    .line 12
    .line 13
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 14
    .line 15
    invoke-static {v1}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    const-string v0, "ACTIVE_ACCOUNT"

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->ACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 25
    .line 26
    const-string v0, "INACTIVE_LOGGED_IN_ACCOUNTS"

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->INACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$whatsAppReadExecutor$2;

    .line 35
    .line 36
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->whatsAppReadExecutor$delegate:Lkotlin/Lazy;

    .line 41
    .line 42
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;->enable:LX/0d8;

    .line 43
    .line 44
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->isWhatsAppSsoEnabled$delegate:LX/1zE;

    .line 49
    .line 50
    sget-object v0, LX/Fyo;->A0D:LX/Fyo;

    .line 51
    .line 52
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->LEGACY_ACCOUNT_SWITCHER_SSO_SOURCES:Ljava/util/List;

    .line 57
    .line 58
    return-void
.end method

.method public static final synthetic access$getACTIVE_CREDENTIAL_SOURCE$p()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->ACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getINACTIVE_CREDENTIAL_SOURCE$p()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->INACTIVE_CREDENTIAL_SOURCE:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getLEGACY_ACCOUNT_SWITCHER_SSO_SOURCES$p()Ljava/util/List;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->LEGACY_ACCOUNT_SWITCHER_SSO_SOURCES:Ljava/util/List;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getWhatsAppReadExecutor()Ljava/util/concurrent/Executor;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->whatsAppReadExecutor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
.end method

.method public static final synthetic access$isWhatsAppSsoEnabled()Z
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->isWhatsAppSsoEnabled()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    return v0
.end method

.method public static final synthetic access$toSsoSourceApp(LX/FyX;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->toSsoSourceApp(LX/FyX;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$toSsoSourceApp(LX/Fyp;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 0

    .line 268435456
    invoke-static {p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->toSsoSourceApp(LX/Fyp;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public static final getWhatsAppReadExecutor()Ljava/util/concurrent/Executor;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->whatsAppReadExecutor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
.end method

.method public static final isWhatsAppSsoEnabled()Z
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->isWhatsAppSsoEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-static {v2, v1, v0}, LX/3Rs;->A1U(LX/1zE;[LX/Dqa;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public static final toSsoSourceApp(LX/FyX;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 1

    .line 0
    sget-object v0, LX/FyX;->A01:Ljava/util/Set;

    .line 1
    .line 2
    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->FACEBOOK:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_0
    sget-object v0, LX/FyX;->A03:Ljava/util/Set;

    .line 12
    .line 13
    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_2

    .line 18
    .line 19
    sget-object v0, LX/FyX;->A0F:LX/FyX;

    .line 20
    .line 21
    if-eq p0, v0, :cond_2

    .line 22
    .line 23
    sget-object v0, LX/FyX;->A0D:LX/FyX;

    .line 24
    .line 25
    if-ne p0, v0, :cond_1

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->META:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 28
    .line 29
    return-object v0

    .line 30
    :cond_1
    const/4 v0, 0x0

    .line 31
    return-object v0

    .line 32
    :cond_2
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->INSTAGRAM:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 33
    .line 34
    return-object v0
.end method

.method public static final toSsoSourceApp(LX/Fyp;)Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p0

    .line 268435460
    packed-switch p0, :pswitch_data_0

    .line 268435461
    .line 268435462
    .line 268435463
    :pswitch_0
    const/4 p0, 0x0

    .line 268435464
    return-object p0

    .line 268435465
    :pswitch_1
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->FACEBOOK:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 268435466
    .line 268435467
    return-object p0

    .line 268435468
    :pswitch_2
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->INSTAGRAM:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 268435469
    .line 268435470
    return-object p0

    .line 268435471
    :pswitch_3
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;->META:Lcom/facebook/aura/auth/login/nativeflow/HatchSsoSourceApp;

    .line 268435472
    .line 268435473
    return-object p0

    .line 268435474
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_3
        :pswitch_3
    .end packed-switch
.end method
