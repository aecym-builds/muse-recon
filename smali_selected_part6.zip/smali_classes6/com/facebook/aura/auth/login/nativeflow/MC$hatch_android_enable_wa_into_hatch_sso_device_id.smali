.class public final Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x22d78

.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;

.field public static final __CONFIG__:I = 0x241

.field public static final enable:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;

    .line 6
    .line 7
    const-wide v0, 0x4102410000016aL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/MC$hatch_android_enable_wa_into_hatch_sso_device_id;->enable:LX/0d8;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
