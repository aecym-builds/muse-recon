.class public final Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final consentIntents(Landroid/content/Context;)LX/2Lw;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "LX/2Lw<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;

    .line 6
    .line 7
    invoke-direct {v0, p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v0}, LX/5NL;->A00(LX/JDN;)LX/5NK;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public final extractCodes(Ljava/lang/String;I)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-static {p1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const-string p0, "(?<!\\d)\\d{"

    .line 9
    .line 10
    const-string/jumbo v0, "}(?!\\d)"

    .line 11
    .line 12
    .line 13
    invoke-static {p0, p2, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, LX/602;->A13(Ljava/lang/String;)LX/BAQ;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {p1, v0}, LX/BAQ;->A00(Ljava/lang/CharSequence;LX/BAQ;)LX/15l;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$extractCodes$1;

    .line 26
    .line 27
    invoke-static {p1, p0}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    new-instance v0, LX/As9;

    .line 31
    .line 32
    invoke-direct {v0, p0, p1}, LX/As9;-><init>(LX/JDM;LX/0Xf;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0}, LX/B84;->A04(LX/0Xf;)Ljava/util/List;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    return-object v0

    .line 40
    :cond_0
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 41
    .line 42
    return-object v0
.end method

.method public final startListening(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object p0, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v4, :cond_1

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_0
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;

    .line 31
    .line 32
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent;LX/2M4;)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :goto_1
    :try_start_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_2
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    throw v0

    .line 45
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_1
    sget-object v3, LX/IBE;->A00:LX/FPT;

    .line 49
    .line 50
    sget-object v1, LX/IBE;->A01:LX/FQa;

    .line 51
    .line 52
    const-string v0, "SmsRetriever.API"

    .line 53
    .line 54
    new-instance v2, LX/FPa;

    .line 55
    .line 56
    invoke-direct {v2, v3, v1, v0}, LX/FPa;-><init>(LX/FPT;LX/FQa;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    sget-object v1, LX/I8y;->A00:LX/I96;

    .line 60
    .line 61
    sget-object v0, LX/I56;->A02:LX/I56;

    .line 62
    .line 63
    new-instance v3, LX/IBE;

    .line 64
    .line 65
    invoke-direct {v3, p1, v1, v2, v0}, LX/FPM;-><init>(Landroid/content/Context;LX/I8y;LX/FPa;LX/I56;)V

    .line 66
    .line 67
    .line 68
    const/4 v2, 0x0

    .line 69
    invoke-static {}, LX/FPb;->A00()LX/FPc;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    new-instance v0, LX/FRx;

    .line 74
    .line 75
    invoke-direct {v0, v3}, LX/FRx;-><init>(LX/IBE;)V

    .line 76
    .line 77
    .line 78
    iput-object v0, v1, LX/FPc;->A01:LX/FQf;

    .line 79
    .line 80
    sget-object v0, LX/I5g;->A03:Lcom/google/android/gms/common/Feature;

    .line 81
    .line 82
    filled-new-array {v0}, [Lcom/google/android/gms/common/Feature;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iput-object v0, v1, LX/FPc;->A03:[Lcom/google/android/gms/common/Feature;

    .line 87
    .line 88
    const/16 v0, 0x620

    .line 89
    .line 90
    invoke-static {v3, v1, v0, v4}, LX/FPM;->A01(LX/FPM;LX/FPc;II)LX/FWa;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    iput-object v2, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->L$0:Ljava/lang/Object;

    .line 95
    .line 96
    iput v4, v5, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$startListening$1;->label:I

    .line 97
    .line 98
    invoke-static {v0, v5}, LX/FNT;->A00(LX/FWb;LX/2M4;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    if-ne v0, p0, :cond_3

    .line 103
    .line 104
    return-object p0
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 105
    :catch_0
    const/4 v4, 0x0

    .line 106
    :cond_3
    :goto_2
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    return-object p0

    .line 111
    :catch_1
    move-exception v0

    .line 112
    throw v0
.end method
