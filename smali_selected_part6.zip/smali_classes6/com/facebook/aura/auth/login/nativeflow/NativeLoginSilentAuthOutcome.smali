.class public final enum Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum AIRPLANE_MODE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum CAUGHT:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum DEADLINE_EXPIRED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum EMPTY_LOCATION:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum MOBILE_DATA_DISABLED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum NO_CONNECTIVITY_SERVICES:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum NO_NETWORK:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

.field public static final enum UNEXPECTED_RESPONSE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;


# instance fields
.field public final failureWireValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 12

    .line 0
    const/4 v2, 0x0

    .line 1
    const/4 v1, 0x0

    .line 2
    const-string v0, "CAUGHT"

    .line 3
    .line 4
    new-instance v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 5
    .line 6
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CAUGHT:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    const-string v1, "no_network"

    .line 13
    .line 14
    const-string v0, "NO_NETWORK"

    .line 15
    .line 16
    new-instance v4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 17
    .line 18
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 19
    .line 20
    .line 21
    sput-object v4, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->NO_NETWORK:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 22
    .line 23
    const/4 v2, 0x2

    .line 24
    const-string v1, "mobile_data_disabled"

    .line 25
    .line 26
    const-string v0, "MOBILE_DATA_DISABLED"

    .line 27
    .line 28
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 29
    .line 30
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 31
    .line 32
    .line 33
    sput-object v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->MOBILE_DATA_DISABLED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 34
    .line 35
    const/4 v2, 0x3

    .line 36
    const-string v1, "airplane_mode"

    .line 37
    .line 38
    const-string v0, "AIRPLANE_MODE"

    .line 39
    .line 40
    new-instance v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 41
    .line 42
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 43
    .line 44
    .line 45
    sput-object v6, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->AIRPLANE_MODE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 46
    .line 47
    const/4 v2, 0x4

    .line 48
    const-string v1, "no_connectivity_services"

    .line 49
    .line 50
    const-string v0, "NO_CONNECTIVITY_SERVICES"

    .line 51
    .line 52
    new-instance v7, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 53
    .line 54
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 55
    .line 56
    .line 57
    sput-object v7, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->NO_CONNECTIVITY_SERVICES:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 58
    .line 59
    const/4 v2, 0x5

    .line 60
    const-string v1, "empty_location"

    .line 61
    .line 62
    const-string v0, "EMPTY_LOCATION"

    .line 63
    .line 64
    new-instance v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 65
    .line 66
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 67
    .line 68
    .line 69
    sput-object v8, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->EMPTY_LOCATION:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 70
    .line 71
    const/4 v2, 0x6

    .line 72
    const-string/jumbo v1, "unexpected_response"

    .line 73
    .line 74
    .line 75
    const-string v0, "UNEXPECTED_RESPONSE"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->UNEXPECTED_RESPONSE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 83
    .line 84
    const/4 v2, 0x7

    .line 85
    const-string v1, "carrier_error"

    .line 86
    .line 87
    const-string v0, "CARRIER_ERROR"

    .line 88
    .line 89
    new-instance v10, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 90
    .line 91
    invoke-direct {v10, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    sput-object v10, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 95
    .line 96
    const/16 v2, 0x8

    .line 97
    .line 98
    const-string v1, "deadline_expired"

    .line 99
    .line 100
    const-string v0, "DEADLINE_EXPIRED"

    .line 101
    .line 102
    new-instance v11, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 103
    .line 104
    invoke-direct {v11, v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sput-object v11, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->DEADLINE_EXPIRED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 108
    .line 109
    filled-new-array/range {v3 .. v11}, [Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->$VALUES:[Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 114
    .line 115
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->$ENTRIES:LX/0vk;

    .line 120
    .line 121
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->failureWireValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->$VALUES:[Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getFailureWireValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->failureWireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
