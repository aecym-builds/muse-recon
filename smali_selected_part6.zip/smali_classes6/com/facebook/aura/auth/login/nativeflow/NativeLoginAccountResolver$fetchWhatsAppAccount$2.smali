.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $read:LX/BcL;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/BcL<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/BcL;Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/BcL<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;->$read:LX/BcL;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;->$context:Landroid/content/Context;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;->$read:LX/BcL;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchWhatsAppAccount$2;->$context:Landroid/content/Context;

    .line 5
    .line 6
    invoke-static {v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->access$readWhatsAppAccount(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v2, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
