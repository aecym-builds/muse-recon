.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $config:LX/GGu;

.field public final synthetic $hops:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic $params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

.field public final synthetic $settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

.field public final synthetic this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGu;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Ljava/util/concurrent/atomic/AtomicInteger;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$config:LX/GGu;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$config:LX/GGu;

    .line 5
    .line 6
    new-instance v3, LX/GGo;

    .line 7
    .line 8
    invoke-direct {v3, v0}, LX/GGo;-><init>(LX/GGu;)V

    .line 9
    .line 10
    .line 11
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$params:Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;

    .line 12
    .line 13
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$config:LX/GGu;

    .line 14
    .line 15
    iget-object v6, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$hops:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 16
    .line 17
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$run$2$1;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 18
    .line 19
    invoke-static/range {v2 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->access$runGuarded(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->settle(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
