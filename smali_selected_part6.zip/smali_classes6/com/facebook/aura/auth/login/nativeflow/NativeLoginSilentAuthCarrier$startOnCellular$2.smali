.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/Hrg;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

.field public final synthetic this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/Hrg;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;->invoke(LX/Hrg;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/Hrg;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;->$settler:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->access$outcomeOf(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/Hrg;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    const/4 v1, 0x0

    .line 13
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 14
    .line 15
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->settle(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method
