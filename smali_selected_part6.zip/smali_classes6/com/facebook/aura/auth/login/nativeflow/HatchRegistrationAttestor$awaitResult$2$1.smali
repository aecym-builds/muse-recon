.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/I3Q;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/I3Q<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DT0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-TT;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;->$continuation:LX/DT0;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onFailure(Ljava/lang/Throwable;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;->$continuation:LX/DT0;

    .line 5
    .line 6
    invoke-static {p1, v0}, LX/EYw;->A1K(Ljava/lang/Throwable;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$awaitResult$2$1;->$continuation:LX/DT0;

    .line 1
    .line 2
    invoke-interface {p0, p1}, LX/2M4;->resumeWith(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
