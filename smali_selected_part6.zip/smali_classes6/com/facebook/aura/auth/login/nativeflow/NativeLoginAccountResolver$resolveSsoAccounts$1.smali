.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver"
    f = "NativeLoginAccountResolver.kt"
    l = {
        0x147
    }
    m = "resolveSsoAccounts$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api"
    v = 0x2
.end annotation


# instance fields
.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$resolveSsoAccounts$1;->this$0:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    move-object v2, v1

    .line 13
    move-object v3, v1

    .line 14
    move-object v4, v1

    .line 15
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->resolveSsoAccounts$fbandroid_express_aura_java_com_facebook_aura_auth_login_nativeflow_api_api(Ljava/util/List;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
