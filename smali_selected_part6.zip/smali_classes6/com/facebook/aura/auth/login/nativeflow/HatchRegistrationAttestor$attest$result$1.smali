.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.HatchRegistrationAttestor$attest$result$1"
    f = "HatchRegistrationAttestor.kt"
    l = {
        0xfa,
        0x5d,
        0x5f,
        0x61,
        0x61
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $redeemedHandle:Ljava/lang/String;

.field public final synthetic $request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$redeemedHandle:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$redeemedHandle:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 3
    .line 4
    const/4 v7, 0x5

    .line 5
    const/4 v6, 0x4

    .line 6
    const/4 v9, 0x3

    .line 7
    const/4 v8, 0x2

    .line 8
    const/4 v0, 0x1

    .line 9
    const/4 v3, 0x0

    .line 10
    if-eqz v1, :cond_5

    .line 11
    .line 12
    if-eq v1, v0, :cond_4

    .line 13
    .line 14
    if-eq v1, v8, :cond_3

    .line 15
    .line 16
    if-eq v1, v9, :cond_2

    .line 17
    .line 18
    if-eq v1, v6, :cond_1

    .line 19
    .line 20
    if-eq v1, v7, :cond_0

    .line 21
    .line 22
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    throw v0

    .line 27
    :cond_0
    iget-object v6, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v6, Ljava/lang/Throwable;

    .line 30
    .line 31
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v2, LX/3Hh;

    .line 34
    .line 35
    goto/16 :goto_8

    .line 36
    .line 37
    :cond_1
    iget-object v4, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 38
    .line 39
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v2, LX/3Hh;

    .line 42
    .line 43
    :try_start_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    goto/16 :goto_6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 47
    .line 48
    :cond_2
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 51
    .line 52
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, LX/3Hh;

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v1, Ljava/lang/String;

    .line 60
    .line 61
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 64
    .line 65
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v2, LX/3Hh;

    .line 68
    .line 69
    :try_start_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    goto :goto_1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 73
    :cond_4
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 74
    .line 75
    check-cast v1, Ljava/lang/String;

    .line 76
    .line 77
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 80
    .line 81
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v2, LX/3Hh;

    .line 84
    .line 85
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->attestationMutex:LX/3Hh;

    .line 93
    .line 94
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$request:Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;

    .line 95
    .line 96
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->$redeemedHandle:Ljava/lang/String;

    .line 97
    .line 98
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 103
    .line 104
    iput v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 105
    .line 106
    invoke-interface {v2, v3, p0}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    if-ne v0, v4, :cond_7

    .line 111
    .line 112
    :cond_6
    return-object v4

    .line 113
    :cond_7
    :goto_0
    :try_start_2
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 114
    .line 115
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 116
    .line 117
    iput-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 118
    .line 119
    iput-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 120
    .line 121
    iput v8, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 122
    .line 123
    invoke-static {v0, v5, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->access$activateRequest(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    if-ne v0, v4, :cond_8

    .line 128
    .line 129
    goto :goto_3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 130
    :cond_8
    :goto_1
    :try_start_3
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;

    .line 131
    .line 132
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 133
    .line 134
    iput-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 135
    .line 136
    iput-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 137
    .line 138
    iput v9, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 139
    .line 140
    invoke-static {v0, v5, v1, p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;->access$attestOrReport(Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor;Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    if-ne p1, v4, :cond_9

    .line 145
    .line 146
    goto :goto_4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 147
    :goto_2
    :try_start_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_9
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/AuthRegistrationAttestationJson;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 151
    .line 152
    :try_start_5
    sget-object v1, LX/Cl6;->A00:LX/Cl6;

    .line 153
    .line 154
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;

    .line 155
    .line 156
    invoke-direct {v0, v5, v3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)V

    .line 157
    .line 158
    .line 159
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 160
    .line 161
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 162
    .line 163
    iput v6, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 164
    .line 165
    invoke-static {p0, v1, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    if-eq v0, v4, :cond_6

    .line 170
    .line 171
    goto :goto_5

    .line 172
    :goto_3
    return-object v4

    .line 173
    :goto_4
    return-object v4

    .line 174
    :goto_5
    move-object v4, p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 175
    :goto_6
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    return-object v4

    .line 179
    :catchall_0
    move-exception v6

    .line 180
    goto :goto_7

    .line 181
    :catchall_1
    move-exception v6

    .line 182
    :goto_7
    :try_start_6
    sget-object v1, LX/Cl6;->A00:LX/Cl6;

    .line 183
    .line 184
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;

    .line 185
    .line 186
    invoke-direct {v0, v5, v3}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1$1$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/HatchAttestationRequest;LX/2M4;)V

    .line 187
    .line 188
    .line 189
    iput-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$0:Ljava/lang/Object;

    .line 190
    .line 191
    iput-object v6, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$1:Ljava/lang/Object;

    .line 192
    .line 193
    iput-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->L$2:Ljava/lang/Object;

    .line 194
    .line 195
    iput v7, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$attest$result$1;->label:I

    .line 196
    .line 197
    invoke-static {p0, v1, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    if-ne v0, v4, :cond_a

    .line 202
    .line 203
    return-object v4
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 204
    :goto_8
    :try_start_7
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_a
    throw v6
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 208
    :catchall_2
    move-exception v0

    .line 209
    goto :goto_9

    .line 210
    :catchall_3
    move-exception v0

    .line 211
    goto :goto_9

    .line 212
    :catchall_4
    move-exception v0

    .line 213
    :goto_9
    invoke-interface {v2, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    throw v0
.end method
