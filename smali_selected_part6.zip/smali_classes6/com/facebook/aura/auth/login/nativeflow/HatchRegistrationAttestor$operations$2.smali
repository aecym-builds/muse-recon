.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/FGJ;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/FGJ;
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 1
    .line 2
    const-string v0, "HatchRegistrationAttestationOperations"

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/executors/AuraExecutors;->newSingleThreadExecutor(Ljava/lang/String;)Ljava/util/concurrent/ExecutorService;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    new-instance v3, LX/FkV;

    .line 9
    .line 10
    invoke-direct {v3}, LX/FkV;-><init>()V

    .line 11
    .line 12
    .line 13
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1;

    .line 14
    .line 15
    invoke-direct {v2, v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1;-><init>(Ljava/util/concurrent/ExecutorService;)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    const-string v0, "HatchRegistrationAttestationTimeout"

    .line 20
    .line 21
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/executors/AuraExecutors;->newSingleThreadScheduledExecutor(Ljava/lang/String;Lcom/facebook/aura/executors/NameAndPriorityThreadFactory$ThreadInstanceCreator;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LX/FGK;

    .line 26
    .line 27
    invoke-direct {v1, v2, v0}, LX/FGK;-><init>(Ljava/util/concurrent/Executor;Ljava/util/concurrent/ScheduledExecutorService;)V

    .line 28
    .line 29
    .line 30
    new-instance v0, LX/FGJ;

    .line 31
    .line 32
    invoke-direct {v0, v1, v3}, LX/FGJ;-><init>(LX/FGK;LX/FkV;)V

    .line 33
    .line 34
    .line 35
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2;->invoke()LX/FGJ;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
