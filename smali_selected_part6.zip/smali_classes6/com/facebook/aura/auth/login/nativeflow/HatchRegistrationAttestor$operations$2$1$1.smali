.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $command:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1;->$command:Ljava/lang/Runnable;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/json/AttestationKeystoreGate;->INSTANCE:Lcom/facebook/aura/json/AttestationKeystoreGate;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1;->$command:Ljava/lang/Runnable;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;

    .line 5
    .line 6
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;-><init>(Ljava/lang/Runnable;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {v2, v0}, Lcom/facebook/aura/json/AttestationKeystoreGate;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method
