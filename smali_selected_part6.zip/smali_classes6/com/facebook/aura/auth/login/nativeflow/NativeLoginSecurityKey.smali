.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final DEVELOPER_CHALLENGE_BYTES:I = 0x27

.field public static final DEVELOPER_CREDENTIAL_ID_BYTES:I = 0x20

.field public static final DEVELOPER_RP_ID:Ljava/lang/String; = "facebook.com"

.field public static final DEVELOPER_SECURITY_KEY:Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;

.field public static final FAILURE_FIDO:Ljava/lang/String; = "fido_error"

.field public static final FAILURE_LAUNCH:Ljava/lang/String; = "launch_failed"

.field public static final FAILURE_NO_ALLOWED_CREDENTIAL:Ljava/lang/String; = "no_allowed_credential"

.field public static final FAILURE_NO_RESULT:Ljava/lang/String; = "no_result"

.field public static final FAILURE_PROMPT_UNAVAILABLE:Ljava/lang/String; = "prompt_unavailable"

.field public static final FAILURE_UNREADABLE:Ljava/lang/String; = "unreadable_result"

.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethodType;->SECURITY_KEY:Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethodType;

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const-string v1, "developer_security_key"

    .line 11
    .line 12
    const-string v3, ""

    .line 13
    .line 14
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;

    .line 15
    .line 16
    move-object v5, v4

    .line 17
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethodType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->DEVELOPER_SECURITY_KEY:Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final fromCredential([B)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;
    .locals 4

    .line 0
    :try_start_0
    sget-object v0, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 1
    .line 2
    invoke-static {v0, p1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelableSerializer;->A00(Landroid/os/Parcelable$Creator;[B)Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;

    .line 7
    .line 8
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    :catchall_0
    move-exception v0

    .line 10
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    :goto_0
    instance-of v1, v2, LX/2PH;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    move-object v2, v0

    .line 20
    :cond_0
    check-cast v2, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;

    .line 21
    .line 22
    const-string/jumbo v3, "unreadable_result"

    .line 23
    .line 24
    .line 25
    if-eqz v2, :cond_4

    .line 26
    .line 27
    iget-object v1, v2, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;->A02:Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorAttestationResponse;

    .line 28
    .line 29
    if-nez v1, :cond_1

    .line 30
    .line 31
    iget-object v1, v2, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;->A01:Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorAssertionResponse;

    .line 32
    .line 33
    if-nez v1, :cond_1

    .line 34
    .line 35
    iget-object v1, v2, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;->A03:Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;

    .line 36
    .line 37
    if-nez v1, :cond_1

    .line 38
    .line 39
    const/16 v0, 0x27

    .line 40
    .line 41
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    throw v0

    .line 50
    :cond_1
    instance-of v0, v1, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorAssertionResponse;

    .line 51
    .line 52
    if-eqz v0, :cond_3

    .line 53
    .line 54
    :try_start_1
    invoke-virtual {v2}, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredential;->A05()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v0}, Lcom/facebook/aura/auth/login/nativeflow/HatchPasskeyW3cKt;->base64UrlPasskeyResponse(Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Asserted;

    .line 66
    .line 67
    invoke-direct {v2, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Asserted;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    goto :goto_1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 71
    :catchall_1
    move-exception v0

    .line 72
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    :goto_1
    const/4 v0, 0x0

    .line 77
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 78
    .line 79
    invoke-direct {v1, v3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 80
    .line 81
    .line 82
    instance-of v0, v2, LX/2PH;

    .line 83
    .line 84
    if-eqz v0, :cond_2

    .line 85
    .line 86
    move-object v2, v1

    .line 87
    :cond_2
    check-cast v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;

    .line 88
    .line 89
    return-object v2

    .line 90
    :cond_3
    instance-of v0, v1, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;

    .line 91
    .line 92
    if-eqz v0, :cond_4

    .line 93
    .line 94
    check-cast v1, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;

    .line 95
    .line 96
    invoke-direct {p0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->fromError(Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    return-object v2

    .line 101
    :cond_4
    const/4 v0, 0x0

    .line 102
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 103
    .line 104
    invoke-direct {v2, v3, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 105
    .line 106
    .line 107
    return-object v2
.end method

.method private final fromError(Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyKt;->CANCEL_ERRORS:Ljava/util/Set;

    .line 1
    .line 2
    iget-object p1, p1, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;->A00:Lcom/google/android/gms/fido/fido2/api/common/ErrorCode;

    .line 3
    .line 4
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Cancelled;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Cancelled;

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string v1, "NativeLoginSecurityKey"

    .line 18
    .line 19
    const-string/jumbo v0, "security key prompt failed: %s"

    .line 20
    .line 21
    .line 22
    invoke-static {v1, v0, p0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget v0, p1, Lcom/google/android/gms/fido/fido2/api/common/ErrorCode;->zzb:I

    .line 26
    .line 27
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v0, "fido_error"

    .line 32
    .line 33
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 34
    .line 35
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 36
    .line 37
    .line 38
    return-object p0
.end method

.method private final randomBase64Url(I)Ljava/lang/String;
    .locals 0

    .line 0
    new-array p1, p1, [B

    .line 1
    .line 2
    new-instance p0, Ljava/security/SecureRandom;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/security/SecureRandom;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, Ljava/util/Random;->nextBytes([B)V

    .line 8
    .line 9
    .line 10
    invoke-static {p1}, LX/EYv;->A0u([B)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method private final toDescriptor(Ljava/lang/String;)Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;
    .locals 2

    .line 0
    :try_start_0
    const/16 v0, 0xa

    .line 1
    .line 2
    invoke-static {p1, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    :goto_0
    instance-of v0, p1, LX/2PH;

    .line 13
    .line 14
    const/4 p0, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    move-object p1, p0

    .line 18
    :cond_0
    check-cast p1, [B

    .line 19
    .line 20
    if-eqz p1, :cond_1

    .line 21
    .line 22
    array-length v0, p1

    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    sget-object v0, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 26
    .line 27
    sget-object v0, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialType;->A01:Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialType;

    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    new-instance v0, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;

    .line 34
    .line 35
    invoke-direct {v0, v1, p1, p0}, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;-><init>(Ljava/lang/String;[BLjava/util/List;)V

    .line 36
    .line 37
    .line 38
    return-object v0

    .line 39
    :cond_1
    return-object p0
.end method

.method private final toRequestOptions(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;)Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialRequestOptions;
    .locals 15

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    iget-object v0, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 3
    .line 4
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 5
    .line 6
    .line 7
    move-result-object v13

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-static {v2}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 23
    .line 24
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->toDescriptor(Ljava/lang/String;)Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-virtual {v13, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    invoke-interface {v13}, Ljava/util/List;->isEmpty()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_2

    .line 39
    .line 40
    const/4 v4, 0x0

    .line 41
    iget-object v10, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v10}, LX/FK0;->A02(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iget-object v0, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v0}, LX/EYt;->A1W(Ljava/lang/String;)[B

    .line 49
    .line 50
    .line 51
    move-result-object v14

    .line 52
    invoke-virtual {p0, v3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->promptTimeoutMs(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;)J

    .line 53
    .line 54
    .line 55
    move-result-wide v0

    .line 56
    long-to-double v2, v0

    .line 57
    const-wide v0, 0x408f400000000000L    # 1000.0

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    div-double/2addr v2, v0

    .line 63
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 64
    .line 65
    .line 66
    move-result-object v7

    .line 67
    new-instance v3, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialRequestOptions;

    .line 68
    .line 69
    move-object v5, v4

    .line 70
    move-object v6, v4

    .line 71
    move-object v8, v4

    .line 72
    move-object v9, v4

    .line 73
    move-object v11, v4

    .line 74
    move-object v12, v4

    .line 75
    invoke-direct/range {v3 .. v14}, Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialRequestOptions;-><init>(Landroid/os/ResultReceiver;Lcom/google/android/gms/fido/fido2/api/common/AuthenticationExtensions;Lcom/google/android/gms/fido/fido2/api/common/TokenBinding;Ljava/lang/Double;Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;[B)V

    .line 76
    .line 77
    .line 78
    return-object v3

    .line 79
    :cond_2
    const-string v0, "no usable credential id"

    .line 80
    .line 81
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    throw v0
.end method


# virtual methods
.method public final developerOptions()Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;
    .locals 5

    .line 0
    const/16 v0, 0x27

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->randomBase64Url(I)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const/16 v0, 0x20

    .line 7
    .line 8
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->randomBase64Url(I)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    const-wide/32 v4, 0xea60

    .line 17
    .line 18
    .line 19
    const-string v2, "facebook.com"

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;

    .line 22
    .line 23
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;J)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public final hasAllowedCredential(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;)Z
    .locals 3

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 5
    .line 6
    instance-of v0, v1, Ljava/util/Collection;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return p0

    .line 17
    :cond_1
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-static {v2}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->toDescriptor(Ljava/lang/String;)Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialDescriptor;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    const/4 p0, 0x1

    .line 40
    return p0
.end method

.method public final isDeveloperFactor(Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;)Z
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/network/sandbox/HatchDeveloperOverrides;->ATOD_TOKEN_KEY:Ljava/lang/String;

    .line 5
    .line 6
    return p0
.end method

.method public final promptTimeoutMs(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;)J
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-wide v3, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 5
    .line 6
    const-wide/16 v1, 0x0

    .line 7
    .line 8
    cmp-long v0, v3, v1

    .line 9
    .line 10
    if-lez v0, :cond_0

    .line 11
    .line 12
    const-wide/16 v5, 0x2710

    .line 13
    .line 14
    const-wide/32 p0, 0x1d4c0

    .line 15
    .line 16
    .line 17
    invoke-static/range {v3 .. v8}, LX/34j;->A07(JJJ)J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    return-wide v0

    .line 22
    :cond_0
    const-wide/32 v0, 0xea60

    .line 23
    .line 24
    .line 25
    return-wide v0
.end method

.method public final resultFrom(ILandroid/content/Intent;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;
    .locals 3

    .line 0
    const/4 p0, 0x0

    .line 1
    if-eqz p2, :cond_3

    .line 2
    .line 3
    const-string v0, "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION"

    .line 4
    .line 5
    invoke-virtual {p2, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v0, 0x1

    .line 10
    if-ne v1, v0, :cond_0

    .line 11
    .line 12
    const-string v0, "launch_failed"

    .line 13
    .line 14
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 15
    .line 16
    invoke-direct {v2, v0, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 17
    .line 18
    .line 19
    return-object v2

    .line 20
    :cond_0
    const-string v0, "FIDO2_CREDENTIAL_EXTRA"

    .line 21
    .line 22
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getByteArrayExtra(Ljava/lang/String;)[B

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 29
    .line 30
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->fromCredential([B)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    return-object v2

    .line 35
    :cond_1
    const-string v0, "FIDO2_ERROR_EXTRA"

    .line 36
    .line 37
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getByteArrayExtra(Ljava/lang/String;)[B

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    if-eqz v2, :cond_3

    .line 42
    .line 43
    sget-object v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;

    .line 44
    .line 45
    :try_start_0
    sget-object v0, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 46
    .line 47
    invoke-static {v0, v2}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelableSerializer;->A00(Landroid/os/Parcelable$Creator;[B)Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;

    .line 52
    .line 53
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-direct {v1, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->fromError(Lcom/google/android/gms/fido/fido2/api/common/AuthenticatorErrorResponse;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 61
    :catchall_0
    move-exception v0

    .line 62
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    :goto_0
    const-string/jumbo v0, "unreadable_result"

    .line 67
    .line 68
    .line 69
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 70
    .line 71
    invoke-direct {v1, v0, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 72
    .line 73
    .line 74
    instance-of v0, v2, LX/2PH;

    .line 75
    .line 76
    if-eqz v0, :cond_2

    .line 77
    .line 78
    move-object v2, v1

    .line 79
    :cond_2
    check-cast v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult;

    .line 80
    .line 81
    return-object v2

    .line 82
    :cond_3
    if-nez p1, :cond_4

    .line 83
    .line 84
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Cancelled;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Cancelled;

    .line 85
    .line 86
    return-object v2

    .line 87
    :cond_4
    const-string v0, "no_result"

    .line 88
    .line 89
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;

    .line 90
    .line 91
    invoke-direct {v2, v0, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKeyResult$Failed;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 92
    .line 93
    .line 94
    return-object v2
.end method

.method public final signIntent(Landroid/content/Context;Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;",
            "LX/2M4<",
            "-",
            "Landroid/app/PendingIntent;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    if-ne v1, v4, :cond_3

    .line 28
    .line 29
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    invoke-static {v0}, LX/I1c;->A0d(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-object v0

    .line 36
    :cond_1
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    sget-object v8, LX/I3I;->A00:LX/FPa;

    .line 40
    .line 41
    sget-object v7, LX/I8y;->A00:LX/I96;

    .line 42
    .line 43
    new-instance v2, LX/IAr;

    .line 44
    .line 45
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 46
    .line 47
    .line 48
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v0, LX/I56;

    .line 53
    .line 54
    invoke-direct {v0, v1, v2}, LX/I56;-><init>(Landroid/os/Looper;LX/IAz;)V

    .line 55
    .line 56
    .line 57
    new-instance v3, LX/I3I;

    .line 58
    .line 59
    invoke-direct {v3, p1, v7, v8, v0}, LX/FPM;-><init>(Landroid/content/Context;LX/I8y;LX/FPa;LX/I56;)V

    .line 60
    .line 61
    .line 62
    invoke-direct {p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;->toRequestOptions(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;)Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialRequestOptions;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    invoke-static {}, LX/FPb;->A00()LX/FPc;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    new-instance v0, LX/FNE;

    .line 71
    .line 72
    invoke-direct {v0, v3, v2}, LX/FNE;-><init>(LX/I3I;Lcom/google/android/gms/fido/fido2/api/common/PublicKeyCredentialRequestOptions;)V

    .line 73
    .line 74
    .line 75
    iput-object v0, v1, LX/FPc;->A01:LX/FQf;

    .line 76
    .line 77
    const/16 v0, 0x1520

    .line 78
    .line 79
    iput v0, v1, LX/FPc;->A00:I

    .line 80
    .line 81
    invoke-virtual {v1}, LX/FPc;->A00()LX/FPb;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    const/4 v0, 0x0

    .line 86
    invoke-static {v3, v1, v0}, LX/FPM;->A02(LX/FPM;LX/FPb;I)LX/FWa;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    const/4 v0, 0x0

    .line 91
    iput-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->L$0:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v0, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->L$1:Ljava/lang/Object;

    .line 94
    .line 95
    iput v4, v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;->label:I

    .line 96
    .line 97
    invoke-static {v1, v5}, LX/FNT;->A00(LX/FWb;LX/2M4;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    if-ne v0, v6, :cond_0

    .line 102
    .line 103
    return-object v6

    .line 104
    :cond_2
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;

    .line 105
    .line 106
    invoke-direct {v5, p0, p3}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey$signIntent$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSecurityKey;LX/2M4;)V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    throw v0
.end method

.method public final withDeveloperOverride(Ljava/util/List;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchTwoFactorMethod;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/network/sandbox/HatchDeveloperOverrides;->ATOD_TOKEN_KEY:Ljava/lang/String;

    .line 5
    .line 6
    return-object p1
.end method
