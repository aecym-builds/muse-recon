.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/Fym;",
        "Ljava/util/List<",
        "+",
        "LX/Fz3;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $logLocation:Ljava/lang/String;

.field public final synthetic $sources:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $switcherSources:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/Fyo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "+",
            "LX/Fyo;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "+",
            "LX/Fyo;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$sources:Ljava/util/Set;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$logLocation:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$switcherSources:Ljava/util/List;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/Fym;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->invoke(LX/Fym;)Ljava/util/List;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invoke(LX/Fym;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Fym;",
            ")",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$sources:Ljava/util/Set;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$logLocation:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {p1, v2, v0, v1}, LX/Fym;->A0E(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)Ljava/util/ArrayList;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$context:Landroid/content/Context;

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$switcherSources:Ljava/util/List;

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLegacyItems$1;->$logLocation:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v3, v2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-static {}, LX/EYt;->A0k()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {p1, v3, v0, v1, v2}, LX/Fym;->A07(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/util/ArrayList;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0, v4}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    return-object v0
.end method
