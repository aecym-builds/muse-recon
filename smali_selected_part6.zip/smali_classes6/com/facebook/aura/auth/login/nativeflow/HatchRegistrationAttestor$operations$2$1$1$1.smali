.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $command:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;->$command:Ljava/lang/Runnable;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;->invoke()V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 4
    .line 5
    return-object p0
.end method

.method public final invoke()V
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1$1;->$command:Ljava/lang/Runnable;

    .line 268435457
    .line 268435458
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method
