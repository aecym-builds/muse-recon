.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "LX/Fz3;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchFxCandidates$2"
    f = "NativeLoginAccountResolver.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $logLocation:Ljava/lang/String;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$logLocation:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$logLocation:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;-><init>(Landroid/content/Context;Ljava/lang/String;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1}, LX/DrA;->create(LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$context:Landroid/content/Context;

    .line 10
    .line 11
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$2;->$logLocation:Ljava/lang/String;

    .line 12
    .line 13
    const/16 p0, 0x1c

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    move-object v4, v3

    .line 17
    move-object v5, v3

    .line 18
    move-object p1, v3

    .line 19
    invoke-static/range {v0 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchLegacyItems$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;LX/JDM;ILjava/lang/Object;)Ljava/util/List;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    return-object v0

    .line 24
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    throw v0
.end method
