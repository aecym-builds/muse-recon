.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;
.super LX/07H;
.source ""


# instance fields
.field public final allowCredentials:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final challenge:Ljava/lang/String;

.field public final rpId:Ljava/lang/String;

.field public final timeoutMs:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;J)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;J)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 11
    .line 12
    iput-wide p4, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 13
    .line 14
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;JILjava/lang/Object;)Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;
    .locals 6

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-wide v4, p4

    .line 4
    and-int/lit8 v0, p6, 0x1

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 9
    .line 10
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 15
    .line 16
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 17
    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 21
    .line 22
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 23
    .line 24
    if-eqz v0, :cond_3

    .line 25
    .line 26
    iget-wide v4, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 27
    .line 28
    :cond_3
    invoke-static {v1, v2, v3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;

    .line 32
    .line 33
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;J)V

    .line 34
    .line 35
    .line 36
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;J)Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;J)",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;J)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-wide v3, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 41
    .line 42
    iget-wide v1, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 43
    .line 44
    cmp-long v0, v3, v1

    .line 45
    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    :cond_0
    return v5

    .line 49
    :cond_1
    return v6
.end method

.method public final getAllowCredentials()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChallenge()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRpId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTimeoutMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->challenge:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->rpId:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->allowCredentials:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iget-wide v0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchSecurityKeyOptions;->timeoutMs:J

    .line 19
    .line 20
    invoke-static {v0, v1, v2}, LX/8mk;->A01(JI)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
