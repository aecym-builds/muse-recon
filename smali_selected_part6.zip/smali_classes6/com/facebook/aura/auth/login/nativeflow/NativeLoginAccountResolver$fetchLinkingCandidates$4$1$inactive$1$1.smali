.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/Fym;",
        "Ljava/util/List<",
        "+",
        "LX/Fz3;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/Fym;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1$1;->invoke(LX/Fym;)Ljava/util/List;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invoke(LX/Fym;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Fym;",
            ")",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1$1;->$context:Landroid/content/Context;

    .line 6
    .line 7
    sget-object p1, LX/Fyo;->A0M:LX/Fyo;

    .line 8
    .line 9
    sget-object p0, LX/Fyp;->A0M:LX/Fyp;

    .line 10
    .line 11
    const-string v4, "hatch_native_linking"

    .line 12
    .line 13
    invoke-static {v2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    invoke-static {}, LX/EYt;->A0k()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    invoke-virtual/range {v1 .. v6}, LX/Fym;->A0B(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;LX/Fyp;LX/Fyo;)Ljava/util/ArrayList;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method
