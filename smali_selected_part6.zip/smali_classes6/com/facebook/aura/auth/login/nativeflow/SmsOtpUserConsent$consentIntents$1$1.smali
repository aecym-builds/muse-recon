.class public final Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$this$callbackFlow:LX/JmJ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JmJ<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $receiver:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;


# direct methods
.method public constructor <init>(LX/JmJ;Landroid/content/Context;Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JmJ<",
            "-",
            "Landroid/content/Intent;",
            ">;",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->$$this$callbackFlow:LX/JmJ;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->$receiver:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$1;->$receiver:Lcom/facebook/aura/auth/login/nativeflow/SmsOtpUserConsent$consentIntents$1$receiver$1;

    .line 3
    .line 4
    :try_start_0
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 5
    .line 6
    .line 7
    return-void
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    :catchall_0
    move-exception v0

    .line 9
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 10
    .line 11
    .line 12
    return-void
.end method
