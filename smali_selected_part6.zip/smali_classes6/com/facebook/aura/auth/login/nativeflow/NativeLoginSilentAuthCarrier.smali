.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final context:Landroid/content/Context;

.field public final executor:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/Executor;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->executor:Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    return-void
.end method

.method public static final synthetic access$dispatch(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->dispatch(LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getExecutor$p(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;)Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->executor:Ljava/util/concurrent/Executor;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$networkConfigFor(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Z)LX/GGu;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->networkConfigFor(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Z)LX/GGu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$outcomeOf(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/Hrg;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->outcomeOf(LX/Hrg;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$runAndRelease(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->runAndRelease(LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$runGuarded(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->runGuarded(LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$startOnCellular(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->startOnCellular(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final dispatch(LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/GGt;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;",
            "LX/GGu;",
            "Ljava/util/concurrent/atomic/AtomicInteger;",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;",
            ")V"
        }
    .end annotation

    .line 0
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->executor:Ljava/util/concurrent/Executor;

    .line 1
    .line 2
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;

    .line 3
    .line 4
    invoke-direct/range {v1 .. v8}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$dispatch$1$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 8
    .line 9
    .line 10
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 11
    .line 12
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :goto_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 31
    .line 32
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p6, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->settle(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
.end method

.method private final fetchAuthRedirect(LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;
    .locals 19

    .line 0
    move-object/from16 v8, p3

    .line 1
    .line 2
    move-object/from16 v2, p5

    .line 3
    .line 4
    invoke-virtual {v2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->isActive()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/16 v18, 0x0

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->DEADLINE_EXPIRED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 13
    .line 14
    :goto_0
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 15
    .line 16
    move-object/from16 v0, v18

    .line 17
    .line 18
    invoke-direct {v1, v2, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    const/4 v4, 0x0

    .line 24
    move-object/from16 v0, p0

    .line 25
    .line 26
    iget-object v0, v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->context:Landroid/content/Context;

    .line 27
    .line 28
    move-object/from16 v3, p2

    .line 29
    .line 30
    iget-object v6, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;->authUrl:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v3, v3, Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;->redirectRegex:Ljava/lang/String;

    .line 33
    .line 34
    new-instance v11, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;

    .line 35
    .line 36
    move-object/from16 v5, p4

    .line 37
    .line 38
    invoke-direct {v11, v5, v2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;-><init>(Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 39
    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    invoke-static {v0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 43
    .line 44
    .line 45
    invoke-static {v6, v3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    const/4 v0, 0x5

    .line 49
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 50
    .line 51
    .line 52
    const-string v5, "SilentAuthRequestCellular"

    .line 53
    .line 54
    move-object/from16 v12, p1

    .line 55
    .line 56
    invoke-static {v12, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 57
    .line 58
    .line 59
    :try_start_0
    const-string v17, "execute: redirect catch Failure, reason="

    .line 60
    .line 61
    const-string v2, "SilentAuthRequestRedirectLocation"

    .line 62
    .line 63
    check-cast v8, LX/GGq;

    .line 64
    .line 65
    iget-boolean v10, v8, LX/GGq;->A04:Z

    .line 66
    .line 67
    invoke-static {v3}, LX/602;->A13(Ljava/lang/String;)LX/BAQ;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    new-instance v0, Ljava/net/URL;

    .line 72
    .line 73
    invoke-direct {v0, v6}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    .line 74
    .line 75
    .line 76
    :try_start_1
    const-string v8, "RedirectCatchingHttpRequestImpl"

    .line 77
    .line 78
    invoke-interface {v12, v0}, LX/GGt;->AXq(Ljava/net/URL;)LX/GGn;

    .line 79
    .line 80
    .line 81
    move-result-object v13

    .line 82
    iget-object v0, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 83
    .line 84
    invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0}, Ljava/net/URLConnection;->connect()V

    .line 91
    .line 92
    .line 93
    const/4 v3, 0x0

    .line 94
    :goto_1
    add-int/lit8 v0, v3, 0x1

    .line 95
    .line 96
    const/16 v14, 0xa

    .line 97
    .line 98
    if-gt v0, v14, :cond_1

    .line 99
    .line 100
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 101
    .line 102
    .line 103
    move-result-object v6

    .line 104
    iget-object v0, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {v0}, LX/006;->A15(Ljava/lang/Object;)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-virtual {v11, v6, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$fetchAuthRedirect$1;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    :cond_1
    iget-object v0, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 121
    .line 122
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    div-int/lit8 v6, v0, 0x64

    .line 127
    .line 128
    const/4 v0, 0x3

    .line 129
    if-ne v6, v0, :cond_3

    .line 130
    .line 131
    if-ge v3, v14, :cond_3

    .line 132
    .line 133
    iget-object v14, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 134
    .line 135
    const-string v15, "Location"

    .line 136
    .line 137
    invoke-virtual {v14, v15}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v6

    .line 141
    invoke-static {v6}, LX/I1c;->A05(Ljava/lang/String;)I

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-nez v0, :cond_2

    .line 146
    .line 147
    invoke-static {v15}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-virtual {v14, v0}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v6

    .line 155
    invoke-static {v6}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    :cond_2
    if-eqz v10, :cond_5

    .line 159
    .line 160
    iget-object v15, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 161
    .line 162
    invoke-virtual {v15}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 163
    .line 164
    .line 165
    const-string v14, "SilentAuthHttpURLConnectionImpl"
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 166
    .line 167
    :try_start_2
    invoke-virtual {v15}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 168
    .line 169
    .line 170
    move-result-object v13

    .line 171
    goto :goto_2
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 172
    :catch_0
    :try_start_3
    invoke-virtual {v15}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    .line 173
    .line 174
    .line 175
    move-result-object v13

    .line 176
    :goto_2
    if-eqz v13, :cond_6
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 177
    .line 178
    :try_start_4
    invoke-static {v13}, LX/IAy;->A01(Ljava/io/InputStream;)[B
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 179
    .line 180
    .line 181
    :try_start_5
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V

    .line 182
    .line 183
    .line 184
    goto :goto_5
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 185
    :catchall_0
    move-exception v0

    .line 186
    :try_start_6
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 187
    :catchall_1
    move-exception v16

    .line 188
    :try_start_7
    invoke-static {v13, v0}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 189
    .line 190
    .line 191
    throw v16
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 192
    :catch_1
    :try_start_8
    move-exception v0

    .line 193
    invoke-static {v0}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v13

    .line 197
    const-string v0, "drainAndReturnToPool: drain failed, hard-closing; ex="

    .line 198
    .line 199
    invoke-static {v0, v13, v14}, LX/602;->A1I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    goto :goto_4

    .line 203
    :cond_3
    iget-object v9, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 204
    .line 205
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 206
    .line 207
    .line 208
    move-result v10

    .line 209
    const-string v6, "fetchRedirectLocation: UnexpectedResponse, attempts="

    .line 210
    .line 211
    const-string v0, " responseCode="

    .line 212
    .line 213
    invoke-static {v6, v0, v3, v10}, LX/Gi8;->A0l(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    invoke-static {v8, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v9}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 221
    .line 222
    .line 223
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v9}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    invoke-static {v0}, LX/EYu;->A0V(Ljava/io/InputStream;)Ljava/io/BufferedReader;

    .line 231
    .line 232
    .line 233
    move-result-object v6

    .line 234
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 235
    .line 236
    .line 237
    move-result-object v3

    .line 238
    :goto_3
    invoke-virtual {v6}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    if-eqz v0, :cond_4

    .line 243
    .line 244
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 245
    .line 246
    .line 247
    goto :goto_3

    .line 248
    :cond_4
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v8

    .line 252
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 253
    .line 254
    .line 255
    move-result v6

    .line 256
    invoke-static {v8, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 257
    .line 258
    .line 259
    const-string/jumbo v3, "unexpected_response_"

    .line 260
    .line 261
    .line 262
    const-string v0, "__"

    .line 263
    .line 264
    invoke-static {v3, v0, v8, v6}, LX/Gi8;->A0o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v3

    .line 268
    new-instance v0, LX/Hrr;

    .line 269
    .line 270
    invoke-direct {v0, v3}, LX/Hrg;-><init>(Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    goto :goto_6

    .line 274
    :cond_5
    iget-object v15, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 275
    .line 276
    invoke-virtual {v15}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 277
    .line 278
    .line 279
    :goto_4
    invoke-virtual {v15}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 280
    .line 281
    .line 282
    :cond_6
    :goto_5
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 283
    .line 284
    .line 285
    move-result v0

    .line 286
    if-nez v0, :cond_7

    .line 287
    .line 288
    const-string v0, "fetchRedirectLocation: EmptyLocation at attempt="

    .line 289
    .line 290
    invoke-static {v0, v3}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v0

    .line 294
    invoke-static {v8, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    sget-object v0, LX/HrU;->A00:LX/HrU;

    .line 298
    .line 299
    :goto_6
    new-instance v3, LX/HrR;

    .line 300
    .line 301
    invoke-direct {v3, v0}, LX/HrR;-><init>(LX/Hrg;)V

    .line 302
    .line 303
    .line 304
    :goto_7
    instance-of v0, v3, LX/HrS;

    .line 305
    .line 306
    if-eqz v0, :cond_9

    .line 307
    .line 308
    check-cast v3, LX/HrS;

    .line 309
    .line 310
    iget-object v0, v3, LX/HrS;->A00:Ljava/lang/String;

    .line 311
    .line 312
    invoke-static {v0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 313
    .line 314
    .line 315
    goto :goto_8

    .line 316
    :cond_7
    invoke-virtual {v9, v6}, LX/BAQ;->A07(Ljava/lang/CharSequence;)Z

    .line 317
    .line 318
    .line 319
    move-result v0

    .line 320
    if-eqz v0, :cond_8

    .line 321
    .line 322
    new-instance v3, LX/HrS;

    .line 323
    .line 324
    invoke-direct {v3, v6}, LX/HrS;-><init>(Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    goto :goto_7

    .line 328
    :cond_8
    new-instance v0, Ljava/net/URL;

    .line 329
    .line 330
    invoke-direct {v0, v6}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 331
    .line 332
    .line 333
    invoke-interface {v12, v0}, LX/GGt;->AXq(Ljava/net/URL;)LX/GGn;

    .line 334
    .line 335
    .line 336
    move-result-object v13

    .line 337
    iget-object v0, v13, LX/GGn;->A00:Ljava/net/HttpURLConnection;

    .line 338
    .line 339
    invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {v0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 343
    .line 344
    .line 345
    invoke-virtual {v0}, Ljava/net/URLConnection;->connect()V

    .line 346
    .line 347
    .line 348
    add-int/lit8 v3, v3, 0x1

    .line 349
    .line 350
    goto/16 :goto_1

    .line 351
    .line 352
    :goto_8
    move-object v4, v0

    .line 353
    goto :goto_b

    .line 354
    :cond_9
    instance-of v0, v3, LX/HrR;

    .line 355
    .line 356
    if-eqz v0, :cond_b

    .line 357
    .line 358
    check-cast v3, LX/HrR;

    .line 359
    .line 360
    iget-object v1, v3, LX/HrR;->A00:LX/Hrg;

    .line 361
    .line 362
    instance-of v0, v1, LX/Hrq;

    .line 363
    .line 364
    if-eqz v0, :cond_a

    .line 365
    .line 366
    const-string v3, "error"

    .line 367
    .line 368
    :goto_9
    move-object/from16 v0, v17

    .line 369
    .line 370
    invoke-static {v0, v3, v2}, LX/602;->A1I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 371
    .line 372
    .line 373
    goto :goto_b

    .line 374
    :cond_a
    instance-of v0, v1, LX/Hrr;

    .line 375
    .line 376
    if-eqz v0, :cond_c

    .line 377
    .line 378
    const-string/jumbo v3, "unexpected_response"

    .line 379
    .line 380
    .line 381
    goto :goto_9

    .line 382
    :cond_b
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 383
    .line 384
    .line 385
    move-result-object v0

    .line 386
    goto :goto_a

    .line 387
    :cond_c
    sget-object v0, LX/HrU;->A00:LX/HrU;

    .line 388
    .line 389
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 390
    .line 391
    .line 392
    move-result v0

    .line 393
    if-nez v0, :cond_d

    .line 394
    .line 395
    sget-object v0, LX/HrX;->A00:LX/HrX;

    .line 396
    .line 397
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 398
    .line 399
    .line 400
    move-result v0

    .line 401
    if-nez v0, :cond_d

    .line 402
    .line 403
    sget-object v0, LX/HrV;->A00:LX/HrV;

    .line 404
    .line 405
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 406
    .line 407
    .line 408
    move-result v0

    .line 409
    if-nez v0, :cond_d

    .line 410
    .line 411
    sget-object v0, LX/HrT;->A00:LX/HrT;

    .line 412
    .line 413
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 414
    .line 415
    .line 416
    move-result v0

    .line 417
    if-nez v0, :cond_d

    .line 418
    .line 419
    sget-object v0, LX/HrW;->A00:LX/HrW;

    .line 420
    .line 421
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 422
    .line 423
    .line 424
    move-result v0

    .line 425
    if-nez v0, :cond_d

    .line 426
    .line 427
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 428
    .line 429
    .line 430
    move-result-object v0

    .line 431
    :goto_a
    throw v0

    .line 432
    :cond_d
    iget-object v3, v1, LX/Hrg;->A00:Ljava/lang/String;

    .line 433
    .line 434
    goto :goto_9
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 435
    :goto_b
    :try_start_9
    invoke-static {}, LX/EYt;->A1E()Lorg/json/JSONObject;

    .line 436
    .line 437
    .line 438
    move-result-object v0

    .line 439
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 440
    .line 441
    .line 442
    move-result-object v0

    .line 443
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 444
    .line 445
    .line 446
    goto :goto_d
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_9 .. :try_end_9} :catch_2
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4

    .line 447
    :catchall_2
    move-exception v1

    .line 448
    :try_start_a
    invoke-static {}, LX/EYt;->A1E()Lorg/json/JSONObject;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 453
    .line 454
    .line 455
    move-result-object v0

    .line 456
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 457
    .line 458
    .line 459
    throw v1
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_a .. :try_end_a} :catch_2
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_4

    .line 460
    :catch_2
    move-exception v2

    .line 461
    invoke-static {v2}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object v1

    .line 465
    const-string v0, "executeOnNetwork: SocketTimeoutException, ex="

    .line 466
    .line 467
    goto :goto_c

    .line 468
    :catch_3
    move-exception v2

    .line 469
    invoke-static {v2}, LX/002;->A0x(Ljava/lang/Object;)Ljava/lang/String;

    .line 470
    .line 471
    .line 472
    move-result-object v1

    .line 473
    const-string v0, "executeOnNetwork: IOException, ex="

    .line 474
    .line 475
    :goto_c
    invoke-static {v0, v1, v5}, LX/602;->A1I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 476
    .line 477
    .line 478
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 479
    .line 480
    .line 481
    move-result-object v0

    .line 482
    if-nez v0, :cond_e

    .line 483
    .line 484
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 485
    .line 486
    .line 487
    move-result-object v0

    .line 488
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    :cond_e
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    new-instance v1, LX/Hrq;

    .line 497
    .line 498
    invoke-direct {v1, v0}, LX/Hrg;-><init>(Ljava/lang/String;)V

    .line 499
    .line 500
    .line 501
    goto :goto_d

    .line 502
    :catch_4
    move-exception v3

    .line 503
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 504
    .line 505
    .line 506
    move-result-object v2

    .line 507
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v1

    .line 511
    const-string v0, "executeOnNetwork: unexpected exception, ex="

    .line 512
    .line 513
    invoke-static {v0, v1, v5}, LX/602;->A1J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 517
    .line 518
    .line 519
    move-result-object v0

    .line 520
    if-nez v0, :cond_f

    .line 521
    .line 522
    invoke-static {v2}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 523
    .line 524
    .line 525
    move-result-object v0

    .line 526
    :cond_f
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 527
    .line 528
    .line 529
    move-result-object v0

    .line 530
    new-instance v1, LX/Hrq;

    .line 531
    .line 532
    invoke-direct {v1, v0}, LX/Hrg;-><init>(Ljava/lang/String;)V

    .line 533
    .line 534
    .line 535
    :goto_d
    if-eqz v4, :cond_10

    .line 536
    .line 537
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CAUGHT:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 538
    .line 539
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 540
    .line 541
    invoke-direct {v1, v0, v4}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;Ljava/lang/String;)V

    .line 542
    .line 543
    .line 544
    return-object v1

    .line 545
    :cond_10
    if-eqz v1, :cond_11

    .line 546
    .line 547
    move-object/from16 v0, p0

    .line 548
    .line 549
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->outcomeOf(LX/Hrg;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 550
    .line 551
    .line 552
    move-result-object v2

    .line 553
    goto/16 :goto_0

    .line 554
    .line 555
    :cond_11
    sget-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 556
    .line 557
    goto/16 :goto_0
.end method

.method private final networkConfigFor(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Z)LX/GGu;
    .locals 5

    .line 0
    xor-int/lit8 p0, p2, 0x1

    .line 1
    .line 2
    iget v2, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;->connectTimeoutMs:I

    .line 3
    .line 4
    iget v3, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;->readTimeoutMs:I

    .line 5
    .line 6
    iget v4, p1, Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;->networkAcquisitionTimeoutMs:I

    .line 7
    .line 8
    sget-object v1, LX/0Xj;->A00:LX/0Xj;

    .line 9
    .line 10
    new-instance v0, LX/GGq;

    .line 11
    .line 12
    move p1, p0

    .line 13
    invoke-direct/range {v0 .. v6}, LX/GGq;-><init>(Ljava/util/Map;IIIZZ)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method private final outcomeOf(LX/Hrg;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;
    .locals 0

    .line 0
    sget-object p0, LX/HrU;->A00:LX/HrU;

    .line 1
    .line 2
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->EMPTY_LOCATION:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_0
    sget-object p0, LX/HrX;->A00:LX/HrX;

    .line 12
    .line 13
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-eqz p0, :cond_1

    .line 18
    .line 19
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->NO_NETWORK:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_1
    sget-object p0, LX/HrV;->A00:LX/HrV;

    .line 23
    .line 24
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    if-eqz p0, :cond_2

    .line 29
    .line 30
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->MOBILE_DATA_DISABLED:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 31
    .line 32
    return-object p0

    .line 33
    :cond_2
    sget-object p0, LX/HrT;->A00:LX/HrT;

    .line 34
    .line 35
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    if-eqz p0, :cond_3

    .line 40
    .line 41
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->AIRPLANE_MODE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 42
    .line 43
    return-object p0

    .line 44
    :cond_3
    sget-object p0, LX/HrW;->A00:LX/HrW;

    .line 45
    .line 46
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    if-eqz p0, :cond_4

    .line 51
    .line 52
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->NO_CONNECTIVITY_SERVICES:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 53
    .line 54
    return-object p0

    .line 55
    :cond_4
    instance-of p0, p1, LX/Hrq;

    .line 56
    .line 57
    if-eqz p0, :cond_5

    .line 58
    .line 59
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 60
    .line 61
    return-object p0

    .line 62
    :cond_5
    instance-of p0, p1, LX/Hrr;

    .line 63
    .line 64
    if-eqz p0, :cond_6

    .line 65
    .line 66
    sget-object p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->UNEXPECTED_RESPONSE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 67
    .line 68
    return-object p0

    .line 69
    :cond_6
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    throw p0
.end method

.method private final runAndRelease(LX/GGt;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/GGt;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;",
            "LX/GGu;",
            "Ljava/util/concurrent/atomic/AtomicInteger;",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;",
            ")V"
        }
    .end annotation

    .line 0
    :try_start_0
    move-object v0, p0

    .line 1
    move-object v1, p1

    .line 2
    move-object v2, p3

    .line 3
    move-object v3, p4

    .line 4
    move-object p0, p5

    .line 5
    move-object p1, p6

    .line 6
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->runGuarded(LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {p6, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;->settle(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    .line 13
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :catchall_0
    move-exception v0

    .line 18
    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    throw v0
.end method

.method private final runGuarded(LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;
    .locals 0

    .line 0
    :try_start_0
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->fetchAuthRedirect(LX/GGt;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 1
    .line 2
    .line 3
    move-result-object p2

    .line 4
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    :catchall_0
    move-exception p0

    .line 6
    invoke-static {p0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    :goto_0
    invoke-static {p2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    invoke-static {p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthKt;->failureKind(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p2

    .line 24
    const/16 p0, 0x25

    .line 25
    .line 26
    invoke-static {p0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    const-string/jumbo p0, "silent auth carrier request failed: %s"

    .line 31
    .line 32
    .line 33
    invoke-static {p1, p0, p2}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    sget-object p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;->CARRIER_ERROR:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;

    .line 37
    .line 38
    const/4 p0, 0x0

    .line 39
    new-instance p2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 40
    .line 41
    invoke-direct {p2, p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthOutcome;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    check-cast p2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;

    .line 45
    .line 46
    return-object p2
.end method

.method private final startOnCellular(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v1, LX/Hps;

    .line 3
    .line 4
    invoke-direct {v1, v0, p2}, LX/Hps;-><init>(Landroid/content/Context;LX/GGu;)V

    .line 5
    .line 6
    .line 7
    new-instance v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;

    .line 8
    .line 9
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$1;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 10
    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;

    .line 13
    .line 14
    invoke-direct {v0, p4, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$startOnCellular$2;-><init>(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v1, v2, v0}, LX/Hps;->A00(LX/JDN;LX/JDM;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final run(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Ljava/util/concurrent/atomic/AtomicInteger;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;",
            "Ljava/util/concurrent/atomic/AtomicInteger;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthAttempt;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p3}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    new-instance v1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;

    .line 5
    .line 6
    invoke-direct {v1, v2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;-><init>(LX/DT0;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->networkConfigFor(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;Z)LX/GGu;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-direct {p0, p1, v0, p2, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier;->startOnCellular(Lcom/facebook/aura/auth/login/nativeflow/HatchSilentAuthParams;LX/GGu;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSilentAuthCarrier$Settler;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v2}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method
