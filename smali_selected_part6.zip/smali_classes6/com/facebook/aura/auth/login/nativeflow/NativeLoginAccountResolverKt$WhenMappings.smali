.class public abstract synthetic Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    invoke-static {}, LX/Fyp;->values()[LX/Fyp;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v2, v0, [I

    .line 6
    .line 7
    :try_start_0
    const/4 v1, 0x0

    .line 8
    const/4 v0, 0x1

    .line 9
    aput v0, v2, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    :catch_0
    :try_start_1
    const/4 v1, 0x1

    .line 12
    const/4 v0, 0x2

    .line 13
    aput v0, v2, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 14
    .line 15
    :catch_1
    :try_start_2
    const/4 v1, 0x2

    .line 16
    const/4 v0, 0x3

    .line 17
    aput v0, v2, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 18
    .line 19
    :catch_2
    :try_start_3
    const/16 v1, 0xa

    .line 20
    .line 21
    const/4 v0, 0x4

    .line 22
    aput v0, v2, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 23
    .line 24
    :catch_3
    :try_start_4
    const/4 v0, 0x5

    .line 25
    aput v0, v2, v0
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 26
    .line 27
    :catch_4
    :try_start_5
    const/4 v1, 0x7

    .line 28
    const/4 v0, 0x6

    .line 29
    aput v0, v2, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 30
    .line 31
    :catch_5
    :try_start_6
    const/16 v1, 0x8

    .line 32
    .line 33
    const/4 v0, 0x7

    .line 34
    aput v0, v2, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 35
    .line 36
    :catch_6
    :try_start_7
    const/16 v1, 0xd

    .line 37
    .line 38
    const/16 v0, 0x8

    .line 39
    .line 40
    aput v0, v2, v1
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 41
    .line 42
    :catch_7
    :try_start_8
    const/16 v1, 0xe

    .line 43
    .line 44
    const/16 v0, 0x9

    .line 45
    .line 46
    aput v0, v2, v1
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 47
    .line 48
    :catch_8
    sput-object v2, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolverKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 49
    .line 50
    return-void
.end method
