.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchFxCandidates$5"
    f = "NativeLoginAccountResolver.kt"
    l = {
        0x13c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $logLocation:Ljava/lang/String;

.field public final synthetic $v2Sources:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/FyX;",
            ">;"
        }
    .end annotation
.end field

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "+",
            "LX/FyX;",
            ">;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$v2Sources:Ljava/util/Set;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$logLocation:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$v2Sources:Ljava/util/Set;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$logLocation:Ljava/lang/String;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;-><init>(Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/login/nativeflow/SsoCandidate;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1}, LX/DrA;->create(LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v4, :cond_2

    .line 8
    .line 9
    iget-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->L$0:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast p1, Ljava/util/List;

    .line 17
    .line 18
    invoke-static {v3, p1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->access$v2Candidates(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Ljava/util/List;)Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0

    .line 23
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    sget-object v3, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 27
    .line 28
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$context:Landroid/content/Context;

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$v2Sources:Ljava/util/Set;

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->$logLocation:Ljava/lang/String;

    .line 33
    .line 34
    iput-object v3, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    iput v4, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchFxCandidates$5;->label:I

    .line 37
    .line 38
    invoke-static {v3, v2, v1, v0, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->access$fetchV2Credentials(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-ne p1, v5, :cond_0

    .line 43
    .line 44
    return-object v5

    .line 45
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    throw v0
.end method
