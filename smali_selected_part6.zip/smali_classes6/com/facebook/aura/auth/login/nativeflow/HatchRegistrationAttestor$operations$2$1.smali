.class public final Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/concurrent/Executor;


# instance fields
.field public final synthetic $worker:Ljava/util/concurrent/ExecutorService;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/ExecutorService;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1;->$worker:Ljava/util/concurrent/ExecutorService;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1;->$worker:Ljava/util/concurrent/ExecutorService;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestor$operations$2$1$1;-><init>(Ljava/lang/Runnable;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
