.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/DSG;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/DSG;
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/executors/AuraExecutors;->CORE_POOL_SIZE:I

    .line 1
    .line 2
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    new-instance p0, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;

    .line 7
    .line 8
    invoke-direct {p0, v0}, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;-><init>(Ljava/util/concurrent/Executor;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, LX/DT9;

    .line 12
    .line 13
    invoke-direct {v0, p0}, LX/DT9;-><init>(Ljava/util/concurrent/Executor;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$threadsInactiveReadDispatcher$2;->invoke()LX/DSG;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
