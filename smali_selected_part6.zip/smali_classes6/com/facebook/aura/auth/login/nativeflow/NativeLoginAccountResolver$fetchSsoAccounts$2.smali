.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchSsoAccounts$2"
    f = "NativeLoginAccountResolver.kt"
    l = {
        0xba,
        0xbd
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/Ddn<",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginSsoAccount;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    move-object v9, p0

    .line 1
    iget-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$0:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v5, LX/1EL;

    .line 4
    .line 5
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 6
    .line 7
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->label:I

    .line 8
    .line 9
    const/4 v3, 0x2

    .line 10
    const/4 v2, 0x1

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    if-eq v0, v2, :cond_2

    .line 14
    .line 15
    if-ne v0, v3, :cond_4

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$3:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Ljava/util/Collection;

    .line 20
    .line 21
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-static {p1}, LX/B8B;->A15(Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0, v2}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    return-object v4

    .line 37
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->$context:Landroid/content/Context;

    .line 41
    .line 42
    const/4 v7, 0x0

    .line 43
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2$whatsApp$1;

    .line 44
    .line 45
    invoke-direct {v0, v1, v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2$whatsApp$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 46
    .line 47
    .line 48
    invoke-static {v0, v5}, LX/3Rp;->A14(LX/JDN;LX/1EL;)LX/ERe;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sget-object v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 53
    .line 54
    iget-object v6, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->$context:Landroid/content/Context;

    .line 55
    .line 56
    iput-object v7, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v2, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->label:I

    .line 61
    .line 62
    const/4 p0, 0x6

    .line 63
    move-object v8, v7

    .line 64
    move-object p1, v7

    .line 65
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchFxAccounts$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/util/Set;Ljava/lang/String;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    if-ne p1, v4, :cond_3

    .line 70
    .line 71
    return-object v4

    .line 72
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$1:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v1, LX/EQR;

    .line 75
    .line 76
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_3
    move-object v2, p1

    .line 80
    check-cast v2, Ljava/util/Collection;

    .line 81
    .line 82
    const/4 v0, 0x0

    .line 83
    iput-object v0, v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$0:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v0, v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$1:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v0, v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$2:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v2, v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->L$3:Ljava/lang/Object;

    .line 90
    .line 91
    iput v3, v9, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchSsoAccounts$2;->label:I

    .line 92
    .line 93
    invoke-static {v1, v9}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    if-ne p1, v4, :cond_0

    .line 98
    .line 99
    return-object v4

    .line 100
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    throw v0
.end method
