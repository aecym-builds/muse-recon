.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "LX/Fz3;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1"
    f = "NativeLoginAccountResolver.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->INSTANCE:Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;->$context:Landroid/content/Context;

    .line 10
    .line 11
    new-instance v5, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1$1;

    .line 12
    .line 13
    invoke-direct {v5, v1}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1$1;-><init>(Landroid/content/Context;)V

    .line 14
    .line 15
    .line 16
    const/16 p0, 0xc

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    const-string v2, "hatch_native_linking"

    .line 20
    .line 21
    move-object v4, v3

    .line 22
    move-object p1, v3

    .line 23
    invoke-static/range {v0 .. v7}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->fetchLegacyItems$default(Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;LX/JDM;ILjava/lang/Object;)Ljava/util/List;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    return-object v0

    .line 28
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    throw v0
.end method
