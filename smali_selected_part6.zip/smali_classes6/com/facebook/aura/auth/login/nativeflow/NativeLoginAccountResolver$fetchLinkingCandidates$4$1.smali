.class public final Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "LX/Fz3;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.auth.login.nativeflow.NativeLoginAccountResolver$fetchLinkingCandidates$4$1"
    f = "NativeLoginAccountResolver.kt"
    l = {
        0x11a,
        0x11a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/Fz3;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v9, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v9, LX/1EL;

    .line 3
    .line 4
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->label:I

    .line 7
    .line 8
    const/4 v8, 0x2

    .line 9
    const/4 v6, 0x1

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    if-eq v0, v6, :cond_2

    .line 13
    .line 14
    if-ne v0, v8, :cond_4

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$3:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v1, Ljava/util/Collection;

    .line 19
    .line 20
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :goto_0
    check-cast p1, Ljava/lang/Iterable;

    .line 24
    .line 25
    invoke-static {p1, v1}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0

    .line 30
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsActiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 34
    .line 35
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, LX/ESt;

    .line 40
    .line 41
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->$context:Landroid/content/Context;

    .line 42
    .line 43
    const/4 v5, 0x0

    .line 44
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;

    .line 45
    .line 46
    invoke-direct {v0, v1, v5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$active$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 47
    .line 48
    .line 49
    sget-object v4, LX/FkO;->A00:Ljava/lang/Integer;

    .line 50
    .line 51
    invoke-static {v4, v2, v0, v9}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    sget-object v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver;->threadsInactiveReadDispatcher$delegate:Lkotlin/Lazy;

    .line 56
    .line 57
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    check-cast v2, LX/ESt;

    .line 62
    .line 63
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->$context:Landroid/content/Context;

    .line 64
    .line 65
    new-instance v0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1;

    .line 66
    .line 67
    invoke-direct {v0, v1, v5}, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1$inactive$1;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 68
    .line 69
    .line 70
    invoke-static {v4, v2, v0, v9}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    iput-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$0:Ljava/lang/Object;

    .line 75
    .line 76
    iput-object v5, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$1:Ljava/lang/Object;

    .line 77
    .line 78
    iput-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$2:Ljava/lang/Object;

    .line 79
    .line 80
    iput v6, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->label:I

    .line 81
    .line 82
    invoke-virtual {v3, p0}, LX/DRW;->A0E(LX/2M4;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    if-ne p1, v7, :cond_3

    .line 87
    .line 88
    :cond_1
    return-object v7

    .line 89
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$2:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v1, LX/EQR;

    .line 92
    .line 93
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    :cond_3
    check-cast p1, Ljava/util/Collection;

    .line 97
    .line 98
    const/4 v0, 0x0

    .line 99
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$0:Ljava/lang/Object;

    .line 100
    .line 101
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$1:Ljava/lang/Object;

    .line 102
    .line 103
    iput-object v0, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$2:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object p1, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->L$3:Ljava/lang/Object;

    .line 106
    .line 107
    iput v8, p0, Lcom/facebook/aura/auth/login/nativeflow/NativeLoginAccountResolver$fetchLinkingCandidates$4$1;->label:I

    .line 108
    .line 109
    invoke-static {v1, p0}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    if-eq v0, v7, :cond_1

    .line 114
    .line 115
    move-object v1, p1

    .line 116
    move-object p1, v0

    .line 117
    goto :goto_0

    .line 118
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    throw v0
.end method
