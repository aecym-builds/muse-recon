.class public abstract Lcom/facebook/aura/auth/login/nativeflow/HatchRegistrationAttestorKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final HATCH_REGISTRATION_KEY_ALIAS:Ljava/lang/String; = "w6CmevIyM/PL6Q5uUDw="

.field public static final INVALID_KEY_ALIAS:Ljava/lang/String; = "INVALID_KEY_ALIAS"

.field public static final OPERATION_TIMEOUT_MILLIS:J = 0x2710L

.field public static final SUBMIT_BUDGET_MILLIS:J = 0xbb8L

.field public static final TAG:Ljava/lang/String; = "HatchRegistrationAttestor"

.field public static final UNEXPECTED_FAILURE:Ljava/lang/String; = "UNEXPECTED_EXCEPTION"
