.class public final Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x1ca77

.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;

.field public static final __CONFIG__:I = 0x208

.field public static final enable_deeplink_security_checks:LX/0d8;

.field public static final enable_usdid_token_manager:LX/0d8;

.field public static final enable_x_install_referrer_handoff:LX/0d8;

.field public static final noise_shared_ingress_host:LX/0d8;

.field public static final onboarding_vm_connection_wait_timeout_ms:LX/0d8;

.field public static final override_access_policy_map:LX/0d8;

.field public static final should_fallback_to_bloks_login:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;

    .line 6
    .line 7
    const-wide v0, 0x2041020800040104L

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->enable_deeplink_security_checks:LX/0d8;

    .line 17
    .line 18
    const-wide v0, 0x410208000c0106L

    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->enable_usdid_token_manager:LX/0d8;

    .line 28
    .line 29
    const-wide v0, 0x2041020800080105L

    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->enable_x_install_referrer_handoff:LX/0d8;

    .line 39
    .line 40
    const-wide v0, 0x430208000a002dL

    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->noise_shared_ingress_host:LX/0d8;

    .line 50
    .line 51
    const-wide v0, 0x420208000b0a85L

    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->onboarding_vm_connection_wait_timeout_ms:LX/0d8;

    .line 61
    .line 62
    const-wide v0, 0x430208000d002eL

    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->override_access_policy_map:LX/0d8;

    .line 72
    .line 73
    const-wide v0, 0x41020800030103L

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->should_fallback_to_bloks_login:LX/0d8;

    .line 83
    .line 84
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
