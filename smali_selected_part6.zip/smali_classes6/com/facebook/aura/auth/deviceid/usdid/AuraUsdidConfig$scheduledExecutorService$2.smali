.class public final Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/util/concurrent/ScheduledExecutorService;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;->INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;->invoke()Ljava/util/concurrent/ScheduledExecutorService;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final invoke()Ljava/util/concurrent/ScheduledExecutorService;
    .locals 2

    .line 0
    sget-object p0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    const-string/jumbo v0, "usdid"

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/executors/AuraExecutors;->newSingleThreadScheduledExecutor(Ljava/lang/String;Lcom/facebook/aura/executors/NameAndPriorityThreadFactory$ThreadInstanceCreator;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method
