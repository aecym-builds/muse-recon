.class public final Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;
.super LX/Fjx;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final crossSignHandler:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Landroid/os/Handler;",
            ">;"
        }
    .end annotation
.end field

.field public final enableTokenManager$delegate:LX/1zE;

.field public final headerDomainAllowlist:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final scheduledExecutorService$delegate:Lkotlin/Lazy;

.field public final tag:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "enableTokenManager"

    .line 1
    .line 2
    const-string v1, "getEnableTokenManager()Z"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/auth/deviceid/usdid/MC$hatch_android_sessionless;->enable_usdid_token_manager:LX/0d8;

    .line 4
    .line 5
    sget-object v1, LX/HAC;->A06:LX/HAC;

    .line 6
    .line 7
    invoke-static {v1}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v2, v1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    new-instance v0, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt$auraMobileConfigBooleanWithOptions$1;

    .line 14
    .line 15
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt$auraMobileConfigBooleanWithOptions$1;-><init>(LX/0d8;LX/HAC;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->enableTokenManager$delegate:LX/1zE;

    .line 19
    .line 20
    sget-object v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;->INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$scheduledExecutorService$2;

    .line 21
    .line 22
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->scheduledExecutorService$delegate:Lkotlin/Lazy;

    .line 27
    .line 28
    sget-object v1, LX/FkO;->A00:Ljava/lang/Integer;

    .line 29
    .line 30
    sget-object v0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$crossSignHandler$1;->INSTANCE:Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig$crossSignHandler$1;

    .line 31
    .line 32
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->crossSignHandler:Lkotlin/Lazy;

    .line 37
    .line 38
    const-string v0, "AuraUsdidJWSManager"

    .line 39
    .line 40
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->tag:Ljava/lang/String;

    .line 41
    .line 42
    sget-object v0, LX/0wX;->A00:LX/0wX;

    .line 43
    .line 44
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->headerDomainAllowlist:Ljava/util/Set;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public getAppContext()Landroid/content/Context;
    .locals 0

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public getCrossSignHandler()Lkotlin/Lazy;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/Lazy<",
            "Landroid/os/Handler;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->crossSignHandler:Lkotlin/Lazy;

    .line 1
    .line 2
    return-object p0
.end method

.method public getEnableTokenManager()Z
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->enableTokenManager$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    aget-object v0, v1, v0

    .line 6
    .line 7
    invoke-interface {v2, p0, v0}, LX/1zE;->getValue(Ljava/lang/Object;LX/Dqa;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0
.end method

.method public getHeaderDomainAllowlist()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->headerDomainAllowlist:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public getOriginApp()LX/Fzr;
    .locals 0

    .line 0
    sget-object p0, LX/Fzr;->A03:LX/Fzr;

    .line 1
    .line 2
    return-object p0
.end method

.method public getScheduledExecutorService()Ljava/util/concurrent/ScheduledExecutorService;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->scheduledExecutorService$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Ljava/util/concurrent/ScheduledExecutorService;

    .line 7
    .line 8
    return-object p0
.end method

.method public getTag()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/usdid/AuraUsdidConfig;->tag:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
