.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/HhW;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

.field public static final KEY_FULLY_SYNCED:Ljava/lang/String; = "family_device_id_fully_synced"

.field public static final KEY_ID:Ljava/lang/String; = "family_device_id"

.field public static final KEY_LAST_SYNC_MS:Ljava/lang/String; = "family_device_id_last_sync_ms"

.field public static final KEY_LAST_SYNC_WAS_RETRY:Ljava/lang/String; = "family_device_id_last_sync_was_retry"

.field public static final KEY_ORIGIN:Ljava/lang/String; = "family_device_id_origin"

.field public static final KEY_SYNCED:Ljava/lang/String; = "family_device_id_synced"

.field public static final KEY_TIMESTAMP:Ljava/lang/String; = "family_device_id_timestamp"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getPrefs()LX/BVu;
    .locals 0

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method


# virtual methods
.method public final getLastSyncMs()J
    .locals 3

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v2, "family_device_id_last_sync_ms"

    .line 5
    .line 6
    const-wide/16 v0, 0x0

    .line 7
    .line 8
    invoke-interface {p0, v2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    return-wide v0
.end method

.method public getPhoneId()Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;->DEVICE_IDENTIFIERS:Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePermanentPrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v1, "family_device_id"

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-interface {p0, v1, v0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public getPhoneIdOrigin()Ljava/lang/String;
    .locals 2

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "family_device_id_origin"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-interface {p0, v1, v0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method public getPhoneIdTimestamp()J
    .locals 3

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v2, "family_device_id_timestamp"

    .line 5
    .line 6
    const-wide/16 v0, 0x0

    .line 7
    .line 8
    invoke-interface {p0, v2, v0, v1}, LX/BVu;->getLong(Ljava/lang/String;J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    return-wide v0
.end method

.method public final isFullySynced()Z
    .locals 2

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "family_device_id_fully_synced"

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-interface {p0, v1, v0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public isPhoneIdSynced()Z
    .locals 2

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "family_device_id_synced"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-interface {p0, v1, v0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public final setPartiallySynced()V
    .locals 2

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v1, "family_device_id_fully_synced"

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p0, v1, v0}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, LX/Df3;->apply()V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public setPhoneId(Ljava/lang/String;JLjava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    const-string v0, "family_device_id"

    .line 13
    .line 14
    invoke-virtual {p0, v0, p1}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const-string v0, "family_device_id_timestamp"

    .line 18
    .line 19
    invoke-virtual {p0, v0, p2, p3}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 20
    .line 21
    .line 22
    const-string v0, "family_device_id_origin"

    .line 23
    .line 24
    if-eqz p4, :cond_0

    .line 25
    .line 26
    invoke-virtual {p0, v0, p4}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    invoke-virtual {p0}, LX/Df3;->A09()Z

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-virtual {p0, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0
.end method

.method public setPhoneIdSynced(Z)V
    .locals 1

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "family_device_id_synced"

    .line 9
    .line 10
    invoke-virtual {p0, v0, p1}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, LX/Df3;->A09()Z

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final setSyncCompleted(JZZ)V
    .locals 1

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "family_device_id_last_sync_ms"

    .line 9
    .line 10
    invoke-virtual {p0, v0, p1, p2}, LX/Df3;->AZB(Ljava/lang/String;J)V

    .line 11
    .line 12
    .line 13
    const-string v0, "family_device_id_fully_synced"

    .line 14
    .line 15
    invoke-virtual {p0, v0, p3}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 16
    .line 17
    .line 18
    const-string v0, "family_device_id_last_sync_was_retry"

    .line 19
    .line 20
    invoke-virtual {p0, v0, p4}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, LX/Df3;->A09()Z

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final wasLastSyncRetry()Z
    .locals 2

    .line 0
    invoke-static {}, LX/EYw;->A0Z()LX/BVu;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v1, "family_device_id_last_sync_was_retry"

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-interface {p0, v1, v0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method
