.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $pass:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;->$pass:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;->$pass:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;

    .line 3
    .line 4
    invoke-static {v1, v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->access$markPartiallySynced(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
