.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/Hhd;


# static fields
.field public static final Companion:Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter$Companion;

.field public static final TAG:Ljava/lang/String; = "AuraCorePeerFailureStatsReporter"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final onCorePeerFailure:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;->Companion:Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;->onCorePeerFailure:Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    return-void
.end method

.method private final isFinalCorePeerFailure(LX/HhN;)Z
    .locals 1

    .line 0
    iget-object p0, p1, LX/HhN;->A06:Ljava/lang/String;

    .line 1
    .line 2
    const-string v0, "broadcasts"

    .line 3
    .line 4
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object p0, p1, LX/HhS;->A01:Ljava/lang/Integer;

    .line 11
    .line 12
    sget-object v0, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 13
    .line 14
    if-eq p0, v0, :cond_0

    .line 15
    .line 16
    sget-object v0, LX/FkO;->A0T:Ljava/lang/Integer;

    .line 17
    .line 18
    if-eq p0, v0, :cond_0

    .line 19
    .line 20
    sget-object v0, LX/FkO;->A0W:Ljava/lang/Integer;

    .line 21
    .line 22
    if-eq p0, v0, :cond_0

    .line 23
    .line 24
    sget-object p0, LX/I3C;->A00:Ljava/util/List;

    .line 25
    .line 26
    iget-object v0, p1, LX/HhS;->A03:Ljava/lang/String;

    .line 27
    .line 28
    invoke-interface {p0, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    const/4 p0, 0x1

    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    :cond_0
    const/4 p0, 0x0

    .line 36
    :cond_1
    return p0
.end method


# virtual methods
.method public report(LX/HhS;)V
    .locals 3

    .line 0
    :try_start_0
    instance-of v0, p1, LX/HhN;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v0, p1

    .line 5
    check-cast v0, LX/HhN;

    .line 6
    .line 7
    invoke-direct {p0, v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;->isFinalCorePeerFailure(LX/HhN;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;->onCorePeerFailure:Lkotlin/jvm/functions/Function0;

    .line 14
    .line 15
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    :goto_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    if-eqz p0, :cond_1

    .line 31
    .line 32
    sget-object v2, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 33
    .line 34
    const-string v1, "AuraCorePeerFailureStatsReporter"

    .line 35
    .line 36
    const-string v0, "Failed to record a core failure"

    .line 37
    .line 38
    invoke-virtual {v2, v1, v0, p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->report(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 39
    .line 40
    .line 41
    :cond_1
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;->report(LX/HhS;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method
