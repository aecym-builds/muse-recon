.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/HMD;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;)V
    .locals 8

    .line 536870912
    const/4 v0, 0x1

    .line 536870913
    move-object v2, p2

    .line 536870914
    move-object v3, p3

    .line 536870915
    move-object v4, p4

    .line 536870916
    invoke-static {p2, p3, p4, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 536870917
    .line 536870918
    .line 536870919
    const/4 v7, 0x0

    .line 536870920
    const/4 v5, 0x0

    .line 536870921
    move-object v0, p0

    .line 536870922
    move-object v1, p1

    .line 536870923
    move-object v6, v5

    .line 536870924
    move-object p0, v5

    .line 536870925
    invoke-virtual/range {v0 .. v8}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;->onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    .line 536870926
    .line 536870927
    .line 536870928
    return-void
.end method

.method public onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 2

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getDeviceInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "phoneid_update"

    .line 11
    .line 12
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-interface {p0}, LX/I2T;->isSampled()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_5

    .line 21
    .line 22
    iget-object v1, p4, LX/Efj;->mType:Ljava/lang/String;

    .line 23
    .line 24
    const-string/jumbo v0, "type"

    .line 25
    .line 26
    .line 27
    invoke-interface {p0, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string v1, ""

    .line 31
    .line 32
    const-string v0, "e_counter_channel"

    .line 33
    .line 34
    invoke-interface {p0, v0, v1}, LX/I2T;->A3i(Ljava/lang/String;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iget-object v1, p2, LX/Fle;->A01:Ljava/lang/String;

    .line 38
    .line 39
    const-string v0, "new_id"

    .line 40
    .line 41
    invoke-interface {p0, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-wide v0, p2, LX/Fle;->A00:J

    .line 45
    .line 46
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    const-string v0, "new_ts"

    .line 51
    .line 52
    invoke-interface {p0, v0, v1}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 53
    .line 54
    .line 55
    if-eqz p1, :cond_0

    .line 56
    .line 57
    iget-object v1, p1, LX/Fle;->A01:Ljava/lang/String;

    .line 58
    .line 59
    const-string v0, "old_id"

    .line 60
    .line 61
    invoke-interface {p0, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    iget-wide v0, p1, LX/Fle;->A00:J

    .line 65
    .line 66
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    const-string v0, "old_ts"

    .line 71
    .line 72
    invoke-interface {p0, v0, v1}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 73
    .line 74
    .line 75
    :cond_0
    if-eqz p3, :cond_1

    .line 76
    .line 77
    const-string/jumbo v0, "src_pkg"

    .line 78
    .line 79
    .line 80
    invoke-interface {p0, v0, p3}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    :cond_1
    if-eqz p5, :cond_2

    .line 84
    .line 85
    const-string v0, "entry_point"

    .line 86
    .line 87
    invoke-interface {p0, v0, p5}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    invoke-static {p7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    const-string v0, "has_phone_id_synced"

    .line 95
    .line 96
    invoke-interface {p0, v0, v1}, LX/I2T;->A3P(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 97
    .line 98
    .line 99
    :cond_2
    if-eqz p6, :cond_3

    .line 100
    .line 101
    const-string/jumbo v0, "sync_session_id"

    .line 102
    .line 103
    .line 104
    invoke-interface {p0, v0, p6}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    :cond_3
    if-eqz p8, :cond_4

    .line 108
    .line 109
    const-string v0, "ordered_pkgs_to_inquire"

    .line 110
    .line 111
    invoke-interface {p0, v0, p8}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    :cond_4
    invoke-interface {p0}, LX/I2T;->AQ5()V

    .line 115
    .line 116
    .line 117
    :cond_5
    return-void
.end method

.method public synthetic onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;JJ)V
    .locals 0

    .line 268435456
    invoke-virtual/range {p0 .. p8}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;->onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method
