.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;
.super LX/HhP;
.source ""


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, LX/HhP;-><init>(LX/HhW;Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public isContextLoggingEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public setPhoneId(LX/Fle;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1}, LX/HhP;->setPhoneId(LX/Fle;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    invoke-static {p0, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
