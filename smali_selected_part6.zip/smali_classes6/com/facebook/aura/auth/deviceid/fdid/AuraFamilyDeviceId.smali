.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FAILED_PASS_HOLD_OFF_MS:J

.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

.field public static final LOCAL_GENERATION_ENTRYPOINT:Ljava/lang/String; = "LOCAL_DEVICE_ID_GENERATION"

.field public static final PARTIALLY_SYNCED_INTERVAL_MS:J

.field public static final SYNC_ENTRYPOINT:Ljava/lang/String; = "aura_startup"

.field public static final WAIT_BUDGET_MS:J = 0x7d0L

.field public static final failedPassElapsedMs:Ljava/util/concurrent/atomic/AtomicLong;

.field public static final lastRecordedPassId:Ljava/util/concurrent/atomic/AtomicLong;

.field public static final passIdCounter:Ljava/util/concurrent/atomic/AtomicLong;

.field public static final ready:LX/BcL;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/BcL<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public static final recordLock:Ljava/lang/Object;

.field public static final store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

.field public static final syncInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final unscheduledPassStarted:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final waitBudgetStartMs:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;

    .line 6
    .line 7
    const-wide/32 v0, 0x1499700

    .line 8
    .line 9
    .line 10
    sput-wide v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->PARTIALLY_SYNCED_INTERVAL_MS:J

    .line 11
    .line 12
    sput-wide v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->FAILED_PASS_HOLD_OFF_MS:J

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    new-instance v0, LX/DRG;

    .line 16
    .line 17
    invoke-direct {v0, v1}, LX/DRG;-><init>(LX/Cbu;)V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 21
    .line 22
    const-wide/16 v2, 0x0

    .line 23
    .line 24
    invoke-static {v2, v3}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->waitBudgetStartMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-static {v1}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->syncInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 36
    .line 37
    invoke-static {v2, v3}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->passIdCounter:Ljava/util/concurrent/atomic/AtomicLong;

    .line 42
    .line 43
    invoke-static {v2, v3}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->lastRecordedPassId:Ljava/util/concurrent/atomic/AtomicLong;

    .line 48
    .line 49
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->recordLock:Ljava/lang/Object;

    .line 54
    .line 55
    invoke-static {v2, v3}, LX/EYt;->A1A(J)Ljava/util/concurrent/atomic/AtomicLong;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->failedPassElapsedMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 60
    .line 61
    invoke-static {v1}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->unscheduledPassStarted:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 66
    .line 67
    sget-object v2, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 68
    .line 69
    const-string v1, "4331325740476680"

    .line 70
    .line 71
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 72
    .line 73
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;-><init>(Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 77
    .line 78
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getReady$p()LX/BcL;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$markPartiallySynced(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->markPartiallySynced(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final createIfNoAppAnswered()LX/Fle;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    iget-object v0, p0, LX/HhP;->storage:LX/HhW;

    .line 4
    .line 5
    invoke-interface {v0}, LX/HhW;->isPhoneIdSynced()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, LX/HhP;->getPhoneId()LX/Fle;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    sget-object v0, LX/Fle;->A03:LX/Fle;

    .line 18
    .line 19
    invoke-virtual {p0, v0}, LX/HhP;->setPhoneId(LX/Fle;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, LX/HhP;->getPhoneId()LX/Fle;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v0, 0x0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    :goto_0
    monitor-exit p0

    .line 29
    return-object v0

    .line 30
    :catchall_0
    move-exception v0

    .line 31
    monitor-exit p0

    .line 32
    throw v0
.end method

.method private final isPassDue(Ljava/lang/Long;)Z
    .locals 2

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->unscheduledPassStarted:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 3
    .line 4
    invoke-static {v0}, LX/8mk;->A1a(Ljava/util/concurrent/atomic/AtomicBoolean;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0

    .line 9
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->isSyncDue(J)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0
.end method

.method private final isRetryDue()Z
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->isFullySynced()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->wasLastSyncRetry()Z

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    const/4 v0, 0x1

    .line 13
    if-eqz p0, :cond_1

    .line 14
    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :cond_1
    return v0
.end method

.method private final markPartiallySynced(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V
    .locals 5

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 4
    .line 5
    .line 6
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->recordLock:Ljava/lang/Object;

    .line 7
    .line 8
    monitor-enter p0

    .line 9
    :try_start_0
    iget-wide v3, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->id:J

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->lastRecordedPassId:Ljava/util/concurrent/atomic/AtomicLong;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 14
    .line 15
    .line 16
    move-result-wide v1

    .line 17
    cmp-long v0, v3, v1

    .line 18
    .line 19
    if-ltz v0, :cond_0

    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 22
    .line 23
    invoke-virtual {v1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->isFullySynced()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {v1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->setPartiallySynced()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    .line 31
    .line 32
    :cond_0
    monitor-exit p0

    .line 33
    return-void

    .line 34
    :catchall_0
    move-exception v0

    .line 35
    monitor-exit p0

    .line 36
    throw v0
.end method

.method private final recordCompletedPass(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;JZ)V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->recordLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    sget-object v3, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 4
    .line 5
    iget-object v0, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    xor-int/lit8 v0, v0, 0x1

    .line 12
    .line 13
    invoke-virtual {v3, p2, p3, v0, p4}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->setSyncCompleted(JZZ)V

    .line 14
    .line 15
    .line 16
    sget-object v2, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->lastRecordedPassId:Ljava/util/concurrent/atomic/AtomicLong;

    .line 17
    .line 18
    iget-wide v0, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->id:J

    .line 19
    .line 20
    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-virtual {v3}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->setPartiallySynced()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    .line 33
    .line 34
    :cond_0
    monitor-exit p0

    .line 35
    return-void

    .line 36
    :catchall_0
    move-exception v0

    .line 37
    monitor-exit p0

    .line 38
    throw v0
.end method

.method private final startWaitBudget()V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->waitBudgetStartMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    const-wide/16 v2, 0x0

    .line 3
    .line 4
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    invoke-virtual {p0, v2, v3, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static synthetic sync$default(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;Landroid/content/Context;Ljava/lang/Long;Ljava/lang/String;ILjava/lang/Object;)Z
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const-string p3, "aura_startup"

    .line 5
    .line 6
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->sync(Landroid/content/Context;Ljava/lang/Long;Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0
.end method


# virtual methods
.method public final awaitFamilyDeviceId(LX/2M4;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v8, p1

    .line 5
    check-cast v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;

    .line 6
    .line 7
    iget v2, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->label:I

    .line 23
    .line 24
    const/4 v9, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v9, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v7

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 39
    .line 40
    invoke-interface {v0}, LX/Cbu;->AOO()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-nez v0, :cond_0

    .line 45
    .line 46
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->get()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    if-nez v0, :cond_0

    .line 51
    .line 52
    invoke-direct {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->startWaitBudget()V

    .line 53
    .line 54
    .line 55
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 56
    .line 57
    .line 58
    move-result-wide v5

    .line 59
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->waitBudgetStartMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 62
    .line 63
    .line 64
    move-result-wide v0

    .line 65
    sub-long/2addr v5, v0

    .line 66
    const-wide/16 v3, 0x7d0

    .line 67
    .line 68
    sub-long/2addr v3, v5

    .line 69
    const-wide/16 v1, 0x0

    .line 70
    .line 71
    cmp-long v0, v3, v1

    .line 72
    .line 73
    if-lez v0, :cond_0

    .line 74
    .line 75
    const/4 v1, 0x0

    .line 76
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$2;

    .line 77
    .line 78
    invoke-direct {v0, v1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$2;-><init>(LX/2M4;)V

    .line 79
    .line 80
    .line 81
    iput-wide v3, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->J$0:J

    .line 82
    .line 83
    iput v9, v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;->label:I

    .line 84
    .line 85
    invoke-static {v8, v0, v3, v4}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    if-ne v0, v7, :cond_0

    .line 90
    .line 91
    return-object v7

    .line 92
    :cond_2
    new-instance v8, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;

    .line 93
    .line 94
    invoke-direct {v8, p0, p1}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$awaitFamilyDeviceId$1;-><init>(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;LX/2M4;)V

    .line 95
    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    throw v0
.end method

.method public final get()Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 1
    .line 2
    invoke-virtual {v0}, LX/HhP;->getPhoneId()LX/Fle;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const/4 p0, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v1, v0, LX/Fle;->A01:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-lez v0, :cond_0

    .line 18
    .line 19
    return-object v1

    .line 20
    :cond_0
    return-object p0
.end method

.method public final getSyncedPhoneId$fbandroid_express_aura_java_com_facebook_aura_auth_deviceid_fdid_fdid()LX/Fle;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 1
    .line 2
    iget-object v0, p0, LX/HhP;->storage:LX/HhW;

    .line 3
    .line 4
    invoke-interface {v0}, LX/HhW;->isPhoneIdSynced()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, LX/HhP;->getPhoneId()LX/Fle;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    return-object v0
.end method

.method public final isSyncDue(J)Z
    .locals 10

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->failedPassElapsedMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 3
    .line 4
    .line 5
    move-result-wide v1

    .line 6
    const/4 v9, 0x0

    .line 7
    const-wide/16 v7, 0x0

    .line 8
    .line 9
    cmp-long v0, v1, v7

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-static {v1, v2}, LX/EYt;->A08(J)J

    .line 14
    .line 15
    .line 16
    move-result-wide v3

    .line 17
    sget-wide v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->FAILED_PASS_HOLD_OFF_MS:J

    .line 18
    .line 19
    cmp-long v0, v3, v1

    .line 20
    .line 21
    if-gez v0, :cond_1

    .line 22
    .line 23
    :cond_0
    return v9

    .line 24
    :cond_1
    invoke-virtual {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->get()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 v6, 0x1

    .line 29
    if-eqz v0, :cond_3

    .line 30
    .line 31
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 32
    .line 33
    .line 34
    move-result-wide v4

    .line 35
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;

    .line 36
    .line 37
    invoke-virtual {v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFdidStorage;->getLastSyncMs()J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    cmp-long v0, v2, v7

    .line 42
    .line 43
    if-lez v0, :cond_3

    .line 44
    .line 45
    cmp-long v0, v4, v2

    .line 46
    .line 47
    if-ltz v0, :cond_3

    .line 48
    .line 49
    invoke-direct {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->isRetryDue()Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    sget-wide v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->PARTIALLY_SYNCED_INTERVAL_MS:J

    .line 56
    .line 57
    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 58
    .line 59
    .line 60
    move-result-wide p1

    .line 61
    :cond_2
    sub-long/2addr v4, v2

    .line 62
    cmp-long v0, v4, p1

    .line 63
    .line 64
    if-ltz v0, :cond_0

    .line 65
    .line 66
    :cond_3
    return v6
.end method

.method public final skipSync()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 1
    .line 2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 3
    .line 4
    invoke-static {p0, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final sync(Landroid/content/Context;Ljava/lang/Long;Ljava/lang/String;)Z
    .locals 38

    .line 0
    const/4 v2, 0x0

    .line 1
    move-object/from16 v37, p1

    .line 2
    .line 3
    move-object/from16 v3, p3

    .line 4
    .line 5
    move-object/from16 v0, v37

    .line 6
    .line 7
    invoke-static {v0, v2, v3}, LX/003;->A0x(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    sget-object v24, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->syncInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 11
    .line 12
    const/4 v14, 0x1

    .line 13
    move-object/from16 v0, v24

    .line 14
    .line 15
    invoke-virtual {v0, v2, v14}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1d

    .line 20
    .line 21
    :try_start_0
    move-object/from16 v25, p2

    .line 22
    .line 23
    move-object/from16 v1, p0

    .line 24
    .line 25
    move-object/from16 v0, v25

    .line 26
    .line 27
    invoke-direct {v1, v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->isPassDue(Ljava/lang/Long;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 32
    .line 33
    move-object/from16 v0, v24

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 36
    .line 37
    .line 38
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 39
    .line 40
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 41
    .line 42
    invoke-static {v1, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return v2

    .line 46
    :cond_0
    :try_start_1
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->passIdCounter:Ljava/util/concurrent/atomic/AtomicLong;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 49
    .line 50
    .line 51
    move-result-wide v4

    .line 52
    new-instance v23, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;

    .line 53
    .line 54
    move-object/from16 v0, v23

    .line 55
    .line 56
    invoke-direct {v0, v4, v5}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;-><init>(J)V

    .line 57
    .line 58
    .line 59
    invoke-direct/range {p0 .. p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->startWaitBudget()V

    .line 60
    .line 61
    .line 62
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 63
    .line 64
    .line 65
    move-result-wide v16

    .line 66
    invoke-direct/range {p0 .. p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->isRetryDue()Z

    .line 67
    .line 68
    .line 69
    move-result v22

    .line 70
    invoke-static/range {v37 .. v37}, LX/602;->A02(Landroid/content/Context;)Landroid/content/Context;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    sget-object v21, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->store:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$store$1;

    .line 75
    .line 76
    sget-object v11, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$1;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$1;

    .line 77
    .line 78
    sget-object v26, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;

    .line 79
    .line 80
    if-eqz p2, :cond_2

    .line 81
    .line 82
    new-instance v4, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;

    .line 83
    .line 84
    invoke-direct {v4, v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$sync$createdId$2;-><init>(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;)V

    .line 85
    .line 86
    .line 87
    new-instance v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;

    .line 88
    .line 89
    invoke-direct {v1, v4}, Lcom/facebook/aura/auth/deviceid/fdid/AuraCorePeerFailureStatsReporter;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 90
    .line 91
    .line 92
    :goto_0
    sget-object v6, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 93
    .line 94
    const/16 v20, 0x0

    .line 95
    .line 96
    new-instance v0, LX/HhR;

    .line 97
    .line 98
    move-object v4, v0

    .line 99
    move-object/from16 v7, v26

    .line 100
    .line 101
    move-object v8, v1

    .line 102
    move-object/from16 v9, v21

    .line 103
    .line 104
    move-object v10, v3

    .line 105
    invoke-direct/range {v4 .. v11}, LX/HhR;-><init>(Landroid/content/Context;Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;LX/HMD;LX/Hhd;LX/HhP;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 106
    .line 107
    .line 108
    iget-object v1, v0, LX/HhR;->A04:Ljava/lang/String;

    .line 109
    .line 110
    iget-object v5, v0, LX/HhR;->A00:LX/HhI;

    .line 111
    .line 112
    iget-object v0, v5, LX/HhI;->A09:LX/HhP;

    .line 113
    .line 114
    move-object/from16 v36, v0

    .line 115
    .line 116
    iput-object v1, v5, LX/HhI;->A00:Ljava/lang/String;

    .line 117
    .line 118
    invoke-static {}, LX/EYt;->A0k()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    iput-object v0, v5, LX/HhI;->A02:Ljava/lang/String;

    .line 123
    .line 124
    iget-object v0, v5, LX/HhI;->A08:LX/HhV;

    .line 125
    .line 126
    iget-object v0, v0, LX/HhV;->A00:LX/HhR;

    .line 127
    .line 128
    iget-object v15, v0, LX/HhR;->A03:LX/HhP;

    .line 129
    .line 130
    iget-object v0, v15, LX/HhP;->storage:LX/HhW;

    .line 131
    .line 132
    invoke-interface {v0}, LX/HhW;->isPhoneIdSynced()Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    iput-boolean v0, v5, LX/HhI;->A03:Z

    .line 137
    .line 138
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 139
    .line 140
    .line 141
    const-string v9, "PhoneIdRequester"

    .line 142
    .line 143
    const-string v0, "calling inferIdsWithTracking"

    .line 144
    .line 145
    invoke-static {v9, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    iget-object v0, v5, LX/HhI;->A04:Landroid/content/Context;

    .line 153
    .line 154
    move-object/from16 v35, v0

    .line 155
    .line 156
    invoke-virtual/range {v35 .. v35}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-virtual/range {v35 .. v35}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v4

    .line 168
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 169
    .line 170
    .line 171
    move-result-object v8

    .line 172
    :cond_1
    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    if-eqz v0, :cond_3

    .line 177
    .line 178
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    check-cast v6, Landroid/content/pm/PackageInfo;

    .line 183
    .line 184
    iget-object v7, v6, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    .line 185
    .line 186
    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    if-nez v0, :cond_1

    .line 191
    .line 192
    sget-object v3, LX/Jal;->A02:Ljava/util/Set;

    .line 193
    .line 194
    sget-object v0, LX/Flb;->A01:LX/Fc4;

    .line 195
    .line 196
    invoke-interface {v3, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    move-result v0

    .line 200
    if-eqz v0, :cond_1

    .line 201
    .line 202
    move-object/from16 v0, v35

    .line 203
    .line 204
    invoke-static {v0, v7}, LX/Flb;->A00(Landroid/content/Context;Ljava/lang/String;)Z

    .line 205
    .line 206
    .line 207
    move-result v0

    .line 208
    if-eqz v0, :cond_1

    .line 209
    .line 210
    iget-object v0, v6, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    .line 211
    .line 212
    invoke-virtual {v1, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    goto :goto_1

    .line 216
    :cond_2
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;

    .line 217
    .line 218
    goto :goto_0

    .line 219
    :cond_3
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    if-nez v0, :cond_4

    .line 224
    .line 225
    const-string v0, ", "

    .line 226
    .line 227
    invoke-static {v0, v1}, LX/F1L;->A00(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    iput-object v0, v5, LX/HhI;->A01:Ljava/lang/String;

    .line 232
    .line 233
    :cond_4
    invoke-virtual/range {v36 .. v36}, LX/HhP;->getPhoneId()LX/Fle;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    .line 237
    .line 238
    .line 239
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 240
    .line 241
    .line 242
    move-result-object v19

    .line 243
    const/4 v8, 0x0

    .line 244
    :goto_2
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    .line 245
    .line 246
    .line 247
    move-result v0

    .line 248
    if-eqz v0, :cond_19

    .line 249
    .line 250
    invoke-static/range {v19 .. v19}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v4

    .line 254
    const-string v10, ".provider.phoneid"

    .line 255
    .line 256
    const-string v0, "empty Cursor object from package "

    .line 257
    .line 258
    const-string v7, "content provider package name conflict. Expected:"

    .line 259
    .line 260
    const-string v1, "content://"

    .line 261
    .line 262
    iget-object v3, v5, LX/HhI;->A00:Ljava/lang/String;

    .line 263
    .line 264
    if-eqz v3, :cond_5

    .line 265
    .line 266
    iget-object v3, v5, LX/HhI;->A02:Ljava/lang/String;

    .line 267
    .line 268
    if-eqz v3, :cond_5

    .line 269
    .line 270
    invoke-virtual/range {v36 .. v36}, LX/HhP;->getPhoneId()LX/Fle;

    .line 271
    .line 272
    .line 273
    move-result-object v28

    .line 274
    iget-object v13, v5, LX/HhI;->A00:Ljava/lang/String;

    .line 275
    .line 276
    iget-object v12, v5, LX/HhI;->A02:Ljava/lang/String;

    .line 277
    .line 278
    iget-boolean v11, v5, LX/HhI;->A03:Z

    .line 279
    .line 280
    iget-object v6, v5, LX/HhI;->A01:Ljava/lang/String;

    .line 281
    .line 282
    const-string v30, "contentproviders"

    .line 283
    .line 284
    new-instance v3, LX/HhN;

    .line 285
    .line 286
    move-object/from16 v27, v3

    .line 287
    .line 288
    move-object/from16 v29, v4

    .line 289
    .line 290
    move-object/from16 v31, v13

    .line 291
    .line 292
    move-object/from16 v32, v12

    .line 293
    .line 294
    move-object/from16 v33, v6

    .line 295
    .line 296
    move/from16 v34, v11

    .line 297
    .line 298
    invoke-direct/range {v27 .. v34}, LX/HhN;-><init>(LX/Fle;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 299
    .line 300
    .line 301
    goto :goto_3

    .line 302
    :cond_5
    invoke-virtual/range {v36 .. v36}, LX/HhP;->getPhoneId()LX/Fle;

    .line 303
    .line 304
    .line 305
    move-result-object v11

    .line 306
    const-string v6, "contentproviders"

    .line 307
    .line 308
    new-instance v3, LX/HhN;

    .line 309
    .line 310
    invoke-direct {v3, v11, v4, v6}, LX/HhN;-><init>(LX/Fle;Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    :goto_3
    if-ltz v8, :cond_6

    .line 314
    .line 315
    iput v8, v3, LX/HhN;->A00:I

    .line 316
    .line 317
    :cond_6
    new-instance v6, LX/HhQ;

    .line 318
    .line 319
    invoke-direct {v6, v4}, LX/HhS;-><init>(Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    invoke-static {v4, v10}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v10

    .line 326
    invoke-virtual/range {v35 .. v35}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 327
    .line 328
    .line 329
    move-result-object v12

    .line 330
    const/4 v13, 0x0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 331
    :try_start_2
    invoke-virtual/range {v35 .. v35}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 332
    .line 333
    .line 334
    move-result-object v11

    .line 335
    if-eqz v11, :cond_12

    .line 336
    .line 337
    invoke-virtual {v11, v10, v2}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    .line 338
    .line 339
    .line 340
    move-result-object v11

    .line 341
    if-nez v11, :cond_7

    .line 342
    .line 343
    move-object/from16 v27, v13

    .line 344
    .line 345
    goto :goto_4

    .line 346
    :cond_7
    invoke-static {v12, v10}, LX/ANR;->A00(Landroid/content/ContentResolver;Ljava/lang/String;)Landroid/content/ContentProviderClient;

    .line 347
    .line 348
    .line 349
    move-result-object v27

    .line 350
    if-nez v27, :cond_8
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 351
    .line 352
    :try_start_3
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 353
    .line 354
    goto :goto_5

    .line 355
    :goto_4
    sget-object v0, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 356
    .line 357
    :goto_5
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 358
    .line 359
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 360
    .line 361
    .line 362
    move-result-wide v0

    .line 363
    iput-wide v0, v3, LX/HhS;->A00:J

    .line 364
    .line 365
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 366
    .line 367
    .line 368
    move-result-wide v0

    .line 369
    iput-wide v0, v6, LX/HhS;->A00:J

    .line 370
    .line 371
    goto/16 :goto_e

    .line 372
    .line 373
    :cond_8
    iget-object v11, v11, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 374
    .line 375
    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 376
    .line 377
    .line 378
    move-result v12

    .line 379
    if-eqz v12, :cond_10

    .line 380
    .line 381
    move-object/from16 v7, v35

    .line 382
    .line 383
    invoke-static {v7, v4}, LX/Flb;->A00(Landroid/content/Context;Ljava/lang/String;)Z

    .line 384
    .line 385
    .line 386
    move-result v7

    .line 387
    if-eqz v7, :cond_f

    .line 388
    .line 389
    invoke-static {v1, v10}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 390
    .line 391
    .line 392
    move-result-object v1

    .line 393
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 394
    .line 395
    .line 396
    move-result-object v28

    .line 397
    move-object/from16 v29, v13

    .line 398
    .line 399
    move-object/from16 v30, v13

    .line 400
    .line 401
    move-object/from16 v31, v13

    .line 402
    .line 403
    move-object/from16 v32, v13

    .line 404
    .line 405
    invoke-virtual/range {v27 .. v32}, Landroid/content/ContentProviderClient;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 406
    .line 407
    .line 408
    move-result-object v7

    .line 409
    if-eqz v7, :cond_11

    .line 410
    .line 411
    invoke-interface {v7}, Landroid/database/Cursor;->moveToFirst()Z

    .line 412
    .line 413
    .line 414
    move-result v1

    .line 415
    if-eqz v1, :cond_11

    .line 416
    .line 417
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 418
    .line 419
    .line 420
    move-result-wide v0

    .line 421
    iput-wide v0, v3, LX/HhS;->A00:J

    .line 422
    .line 423
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 424
    .line 425
    .line 426
    move-result-wide v0

    .line 427
    iput-wide v0, v6, LX/HhS;->A00:J

    .line 428
    .line 429
    const-string v0, "COL_PHONE_ID"

    .line 430
    .line 431
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 432
    .line 433
    .line 434
    move-result v10

    .line 435
    const-string v0, "COL_TIMESTAMP"

    .line 436
    .line 437
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 438
    .line 439
    .line 440
    move-result v1

    .line 441
    const-string v0, "COL_ORIGIN"

    .line 442
    .line 443
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 444
    .line 445
    .line 446
    move-result v0

    .line 447
    if-ltz v10, :cond_b

    .line 448
    .line 449
    if-ltz v1, :cond_b

    .line 450
    .line 451
    invoke-interface {v7, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 452
    .line 453
    .line 454
    move-result-object v12

    .line 455
    invoke-interface {v7, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object v1

    .line 459
    if-ltz v0, :cond_9

    .line 460
    .line 461
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object v10

    .line 465
    goto :goto_6

    .line 466
    :cond_9
    move-object v10, v13

    .line 467
    :goto_6
    if-eqz v12, :cond_a

    .line 468
    .line 469
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 470
    .line 471
    .line 472
    move-result v0

    .line 473
    if-lez v0, :cond_a

    .line 474
    .line 475
    if-eqz v1, :cond_a

    .line 476
    .line 477
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 478
    .line 479
    .line 480
    move-result v0

    .line 481
    if-lez v0, :cond_a

    .line 482
    .line 483
    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 484
    .line 485
    .line 486
    move-result-wide v0

    .line 487
    new-instance v11, LX/Fle;

    .line 488
    .line 489
    invoke-direct {v11, v12, v0, v1, v10}, LX/Fle;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 490
    .line 491
    .line 492
    iput-object v11, v3, LX/HhN;->A01:LX/Fle;

    .line 493
    .line 494
    iget-object v0, v5, LX/HhI;->A06:LX/HhO;

    .line 495
    .line 496
    invoke-virtual {v0, v3}, LX/HhO;->A00(LX/HhN;)V

    .line 497
    .line 498
    .line 499
    goto :goto_8

    .line 500
    :cond_a
    sget-object v0, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 501
    .line 502
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 503
    .line 504
    sget-object v0, LX/FkO;->A0P:Ljava/lang/Integer;

    .line 505
    .line 506
    iput-object v0, v3, LX/HhS;->A01:Ljava/lang/Integer;

    .line 507
    .line 508
    goto :goto_7

    .line 509
    :cond_b
    sget-object v0, LX/FkO;->A0W:Ljava/lang/Integer;

    .line 510
    .line 511
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 512
    .line 513
    sget-object v0, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 514
    .line 515
    iput-object v0, v3, LX/HhS;->A01:Ljava/lang/Integer;

    .line 516
    .line 517
    :goto_7
    move-object v11, v13
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 518
    :goto_8
    :try_start_4
    const-string v0, "COL_SFDID"

    .line 519
    .line 520
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 521
    .line 522
    .line 523
    move-result v12

    .line 524
    const-string v0, "COL_SFDID_CREATION_TS"

    .line 525
    .line 526
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 527
    .line 528
    .line 529
    move-result v10

    .line 530
    const-string v0, "COL_SFDID_GP"

    .line 531
    .line 532
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 533
    .line 534
    .line 535
    move-result v1

    .line 536
    const-string v0, "COL_SFDID_GA"

    .line 537
    .line 538
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 539
    .line 540
    .line 541
    move-result v0

    .line 542
    if-ltz v12, :cond_c

    .line 543
    .line 544
    if-ltz v10, :cond_c

    .line 545
    .line 546
    if-ltz v1, :cond_c

    .line 547
    .line 548
    if-ltz v0, :cond_c

    .line 549
    .line 550
    invoke-interface {v7, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 551
    .line 552
    .line 553
    move-result-object v18

    .line 554
    invoke-interface {v7, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 555
    .line 556
    .line 557
    move-result-object v10

    .line 558
    invoke-interface {v7, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v13

    .line 562
    invoke-interface {v7, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 563
    .line 564
    .line 565
    move-result-object v12

    .line 566
    if-eqz v18, :cond_e

    .line 567
    .line 568
    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->length()I

    .line 569
    .line 570
    .line 571
    move-result v0

    .line 572
    if-eqz v0, :cond_e

    .line 573
    .line 574
    if-eqz v10, :cond_e

    .line 575
    .line 576
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 577
    .line 578
    .line 579
    move-result v0

    .line 580
    if-eqz v0, :cond_e

    .line 581
    .line 582
    if-eqz v13, :cond_e

    .line 583
    .line 584
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    .line 585
    .line 586
    .line 587
    move-result v0

    .line 588
    if-eqz v0, :cond_e

    .line 589
    .line 590
    if-eqz v12, :cond_e

    .line 591
    .line 592
    goto :goto_9

    .line 593
    :cond_c
    sget-object v0, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 594
    .line 595
    goto :goto_a

    .line 596
    :goto_9
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 597
    .line 598
    .line 599
    move-result v0

    .line 600
    if-eqz v0, :cond_e

    .line 601
    .line 602
    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 603
    .line 604
    .line 605
    move-result-wide v0

    .line 606
    new-instance v10, LX/Hhc;

    .line 607
    .line 608
    invoke-direct {v10, v0, v1, v13, v12}, LX/Hhc;-><init>(JLjava/lang/String;Ljava/lang/String;)V

    .line 609
    .line 610
    .line 611
    iput-object v10, v6, LX/HhQ;->A00:LX/Hhc;

    .line 612
    .line 613
    sget-object v0, LX/FkO;->A0Y:Ljava/lang/Integer;

    .line 614
    .line 615
    :goto_a
    iput-object v0, v6, LX/HhS;->A01:Ljava/lang/Integer;

    .line 616
    .line 617
    invoke-interface {v7}, Landroid/database/Cursor;->moveToNext()Z

    .line 618
    .line 619
    .line 620
    move-result v0

    .line 621
    if-eqz v0, :cond_d

    .line 622
    .line 623
    iget-object v10, v5, LX/HhI;->A05:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 624
    .line 625
    if-eqz v10, :cond_d

    .line 626
    .line 627
    const-string v1, "Multiple records in cursor"

    .line 628
    .line 629
    move-object/from16 v0, v20

    .line 630
    .line 631
    invoke-virtual {v10, v9, v1, v0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->report(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 632
    .line 633
    .line 634
    :cond_d
    invoke-interface {v7}, Landroid/database/Cursor;->close()V

    .line 635
    .line 636
    .line 637
    goto :goto_b

    .line 638
    :cond_e
    sget-object v0, LX/FkO;->A0P:Ljava/lang/Integer;

    .line 639
    .line 640
    goto :goto_a

    .line 641
    :goto_b
    move-object v13, v11

    .line 642
    goto :goto_f
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 643
    :catch_0
    move-exception v7

    .line 644
    move-object v13, v11

    .line 645
    goto :goto_d

    .line 646
    :cond_f
    :try_start_5
    sget-object v0, LX/FkO;->A0P:Ljava/lang/Integer;

    .line 647
    .line 648
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 649
    .line 650
    const-string v0, "app signature mismatch"

    .line 651
    .line 652
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 653
    .line 654
    .line 655
    move-result-object v0

    .line 656
    goto :goto_c

    .line 657
    :cond_10
    sget-object v0, LX/FkO;->A0K:Ljava/lang/Integer;

    .line 658
    .line 659
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 660
    .line 661
    const-string v0, " Found:"

    .line 662
    .line 663
    invoke-static {v7, v4, v0, v11}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 664
    .line 665
    .line 666
    move-result-object v0

    .line 667
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 668
    .line 669
    .line 670
    move-result-object v0

    .line 671
    goto :goto_c

    .line 672
    :cond_11
    sget-object v1, LX/FkO;->A0T:Ljava/lang/Integer;

    .line 673
    .line 674
    iput-object v1, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 675
    .line 676
    invoke-static {v0, v4}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 677
    .line 678
    .line 679
    move-result-object v0

    .line 680
    :goto_c
    throw v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 681
    :catch_1
    move-exception v7

    .line 682
    goto :goto_d

    .line 683
    :cond_12
    :try_start_6
    sget-object v0, LX/FkO;->A01:Ljava/lang/Integer;

    .line 684
    .line 685
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 686
    .line 687
    const-string v0, "PackageManager is null"

    .line 688
    .line 689
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 690
    .line 691
    .line 692
    move-result-object v0

    .line 693
    throw v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 694
    :catch_2
    move-exception v7

    .line 695
    move-object/from16 v27, v13

    .line 696
    .line 697
    :goto_d
    :try_start_7
    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 698
    .line 699
    .line 700
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 701
    .line 702
    .line 703
    move-result-wide v0

    .line 704
    iput-wide v0, v3, LX/HhS;->A00:J

    .line 705
    .line 706
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 707
    .line 708
    .line 709
    move-result-wide v0

    .line 710
    iput-wide v0, v6, LX/HhS;->A00:J

    .line 711
    .line 712
    iget-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 713
    .line 714
    if-nez v0, :cond_13

    .line 715
    .line 716
    sget-object v0, LX/FkO;->A0Z:Ljava/lang/Integer;

    .line 717
    .line 718
    iput-object v0, v3, LX/HhN;->A02:Ljava/lang/Integer;

    .line 719
    .line 720
    :cond_13
    iget-object v1, v5, LX/HhI;->A05:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 721
    .line 722
    if-eqz v1, :cond_14

    .line 723
    .line 724
    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 725
    .line 726
    .line 727
    move-result-object v0

    .line 728
    invoke-virtual {v1, v9, v0, v7}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->report(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 729
    .line 730
    .line 731
    :cond_14
    :goto_e
    if-eqz v27, :cond_15
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 732
    .line 733
    :goto_f
    :try_start_8
    invoke-virtual/range {v27 .. v27}, Landroid/content/ContentProviderClient;->release()Z

    .line 734
    .line 735
    .line 736
    :cond_15
    iget-object v0, v5, LX/HhI;->A07:LX/Hhd;

    .line 737
    .line 738
    if-eqz v0, :cond_16

    .line 739
    .line 740
    invoke-interface {v0, v3}, LX/Hhd;->report(LX/HhS;)V

    .line 741
    .line 742
    .line 743
    invoke-interface {v0, v6}, LX/Hhd;->report(LX/HhS;)V

    .line 744
    .line 745
    .line 746
    :cond_16
    if-eqz v13, :cond_17

    .line 747
    .line 748
    iget-object v0, v15, LX/HhP;->storage:LX/HhW;

    .line 749
    .line 750
    invoke-interface {v0, v14}, LX/HhW;->setPhoneIdSynced(Z)V

    .line 751
    .line 752
    .line 753
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 754
    .line 755
    .line 756
    goto :goto_10

    .line 757
    :cond_17
    invoke-static {v5, v4}, LX/HhI;->A00(LX/HhI;Ljava/lang/String;)V

    .line 758
    .line 759
    .line 760
    :goto_10
    add-int/lit8 v8, v8, 0x1

    .line 761
    .line 762
    goto/16 :goto_2
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 763
    .line 764
    :catchall_0
    move-exception v0

    .line 765
    goto :goto_11

    .line 766
    :catchall_1
    move-exception v0

    .line 767
    if-eqz v27, :cond_18

    .line 768
    .line 769
    :try_start_9
    invoke-virtual/range {v27 .. v27}, Landroid/content/ContentProviderClient;->release()Z

    .line 770
    .line 771
    .line 772
    :cond_18
    :goto_11
    throw v0

    .line 773
    :cond_19
    iget-object v0, v15, LX/HhP;->storage:LX/HhW;

    .line 774
    .line 775
    invoke-interface {v0, v14}, LX/HhW;->setPhoneIdSynced(Z)V

    .line 776
    .line 777
    .line 778
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 779
    .line 780
    .line 781
    if-eqz p2, :cond_1a

    .line 782
    .line 783
    move-wide/from16 v3, v16

    .line 784
    .line 785
    move/from16 v5, v22

    .line 786
    .line 787
    move-object/from16 v1, p0

    .line 788
    .line 789
    move-object/from16 v0, v23

    .line 790
    .line 791
    invoke-direct {v1, v0, v3, v4, v5}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->recordCompletedPass(Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;JZ)V

    .line 792
    .line 793
    .line 794
    :cond_1a
    invoke-direct/range {p0 .. p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->createIfNoAppAnswered()LX/Fle;

    .line 795
    .line 796
    .line 797
    move-result-object v28
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_3
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 798
    move-object/from16 v0, v24

    .line 799
    .line 800
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 801
    .line 802
    .line 803
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 804
    .line 805
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 806
    .line 807
    invoke-static {v1, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 808
    .line 809
    .line 810
    if-eqz v28, :cond_1b

    .line 811
    .line 812
    :try_start_a
    invoke-virtual/range {v37 .. v37}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 813
    .line 814
    .line 815
    move-result-object v29

    .line 816
    sget-object v30, LX/Efj;->A02:LX/Efj;

    .line 817
    .line 818
    const-string v31, "LOCAL_DEVICE_ID_GENERATION"

    .line 819
    .line 820
    invoke-static {}, LX/EYt;->A0k()Ljava/lang/String;

    .line 821
    .line 822
    .line 823
    move-result-object v32

    .line 824
    move-object/from16 v0, v21

    .line 825
    .line 826
    iget-object v0, v0, LX/HhP;->storage:LX/HhW;

    .line 827
    .line 828
    invoke-interface {v0}, LX/HhW;->isPhoneIdSynced()Z

    .line 829
    .line 830
    .line 831
    move-result v33

    .line 832
    move-object/from16 v27, v20

    .line 833
    .line 834
    move-object/from16 v34, v20

    .line 835
    .line 836
    invoke-virtual/range {v26 .. v34}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdUpdatedCallback;->onUpdated(LX/Fle;LX/Fle;Ljava/lang/String;LX/Efj;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    .line 837
    .line 838
    .line 839
    return v14
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 840
    :catchall_2
    move-exception v0

    .line 841
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 842
    .line 843
    .line 844
    :cond_1b
    return v14

    .line 845
    :catch_3
    move-exception v4

    .line 846
    if-eqz p2, :cond_1c

    .line 847
    .line 848
    :try_start_b
    sget-object v3, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->failedPassElapsedMs:Ljava/util/concurrent/atomic/AtomicLong;

    .line 849
    .line 850
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 851
    .line 852
    .line 853
    move-result-wide v0

    .line 854
    invoke-virtual {v3, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    .line 855
    .line 856
    .line 857
    :cond_1c
    throw v4
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    .line 858
    :catchall_3
    move-exception v3

    .line 859
    sget-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->syncInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 860
    .line 861
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 862
    .line 863
    .line 864
    sget-object v1, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId;->ready:LX/BcL;

    .line 865
    .line 866
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 867
    .line 868
    invoke-static {v1, v0}, LX/8mk;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 869
    .line 870
    .line 871
    throw v3

    .line 872
    :cond_1d
    return v2
.end method
