.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

.field public static final TAG:Ljava/lang/String; = "AuraPhoneIdSoftErrorReporter"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final isConfidentialAnalyticsMode()Z
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->INSTANCE:Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/store/AuraPersistedSessionBinding;->persistedSession()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    if-nez p0, :cond_0

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    return v0

    .line 10
    :cond_0
    sget-object v0, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->Companion:Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;

    .line 11
    .line 12
    invoke-virtual {v0, p0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->isConfidentialVmForAnalyticsMode()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0
.end method


# virtual methods
.method public report(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 8

    .line 0
    const-string v7, "category"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const-string v0, ": "

    .line 7
    .line 8
    invoke-static {p1, v0, p2}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v2, "AuraPhoneIdSoftErrorReporter"

    .line 13
    .line 14
    invoke-static {v2, v0, p3}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 15
    .line 16
    .line 17
    :try_start_0
    sget-object v0, Lcom/facebook/aura/mme/AuraUnexpectedEventReporterProvider;->INSTANCE:Lcom/facebook/aura/mme/AuraUnexpectedEventReporterProvider;

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/aura/mme/AuraUnexpectedEventReporterProvider;->get()LX/Fva;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    if-eqz v5, :cond_2

    .line 24
    .line 25
    invoke-direct {p0}, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSoftErrorReporter;->isConfidentialAnalyticsMode()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_2

    .line 30
    .line 31
    const-string v0, "Multiple records in cursor"

    .line 32
    .line 33
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    const-string v6, "multiple_records"

    .line 40
    .line 41
    :goto_0
    const-string v4, "fdid_sync_soft_error"

    .line 42
    .line 43
    const v3, 0x25b435e7

    .line 44
    .line 45
    .line 46
    check-cast v5, LX/FvX;

    .line 47
    .line 48
    const/4 v1, 0x1

    .line 49
    iget-object v0, v5, LX/FvX;->A01:Ljava/util/Random;

    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/util/Random;->nextInt()I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    rem-int/2addr v0, v1

    .line 56
    goto :goto_1

    .line 57
    :cond_0
    const-string v6, "exception"

    .line 58
    .line 59
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 60
    :goto_1
    invoke-static {v0}, LX/003;->A1B(I)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    :try_start_1
    iget-object v0, v5, LX/FvX;->A00:Lcom/facebook/quicklog/LightweightQuickPerformanceLogger;

    .line 65
    .line 66
    new-instance v5, LX/FvT;

    .line 67
    .line 68
    invoke-direct {v5, v0, v4, v3, v1}, LX/FvT;-><init>(Lcom/facebook/quicklog/LightweightQuickPerformanceLogger;Ljava/lang/String;IZ)V

    .line 69
    .line 70
    .line 71
    iget-object v4, v5, LX/FvT;->A01:Lcom/facebook/quicklog/EventBuilder;

    .line 72
    .line 73
    invoke-interface {v4, v7, p1}, Lcom/facebook/quicklog/EventBuilder;->annotate(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/quicklog/EventBuilder;

    .line 74
    .line 75
    .line 76
    const-string/jumbo v0, "type"

    .line 77
    .line 78
    .line 79
    invoke-interface {v4, v0, v6}, Lcom/facebook/quicklog/EventBuilder;->annotate(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/quicklog/EventBuilder;

    .line 80
    .line 81
    .line 82
    const-string v3, "UI_UE_KEY_CAUSE_STACKTRACE"

    .line 83
    .line 84
    invoke-interface {v4}, Lcom/facebook/quicklog/EventBuilder;->isSampled()Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_1

    .line 89
    .line 90
    iget-boolean v0, v5, LX/FvT;->A02:Z

    .line 91
    .line 92
    if-nez v0, :cond_1

    .line 93
    .line 94
    invoke-static {}, LX/Fna;->A03()Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-nez v0, :cond_1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 99
    .line 100
    :try_start_2
    invoke-static {p3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    const/16 v0, 0x7d0

    .line 108
    .line 109
    invoke-static {v1, v0}, LX/Ftp;->A00(Ljava/lang/String;I)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-interface {v4, v3, v0}, Lcom/facebook/quicklog/EventBuilder;->annotate(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/quicklog/EventBuilder;

    .line 114
    .line 115
    .line 116
    goto :goto_2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 117
    :catch_0
    :try_start_3
    move-exception v0

    .line 118
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    const-string v0, "Cause stack trace collection failed: "

    .line 123
    .line 124
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-interface {v4, v3, v0}, Lcom/facebook/quicklog/EventBuilder;->annotate(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/quicklog/EventBuilder;

    .line 129
    .line 130
    .line 131
    :cond_1
    :goto_2
    invoke-virtual {v5}, LX/FvT;->A01()V

    .line 132
    .line 133
    .line 134
    :cond_2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 135
    .line 136
    goto :goto_3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 137
    :catchall_0
    move-exception v0

    .line 138
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    :goto_3
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    if-eqz v1, :cond_3

    .line 147
    .line 148
    const-string v0, "Failed to report a soft error"

    .line 149
    .line 150
    invoke-static {v2, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 151
    .line 152
    .line 153
    :cond_3
    return-void
.end method
