.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final id:J

.field public final sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(J)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->id:J

    .line 4
    .line 5
    invoke-static {}, LX/8mk;->A0s()Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getId()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->id:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getSawCoreFailure()Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/fdid/AuraFamilyDeviceId$SyncPass;->sawCoreFailure:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    return-object p0
.end method
