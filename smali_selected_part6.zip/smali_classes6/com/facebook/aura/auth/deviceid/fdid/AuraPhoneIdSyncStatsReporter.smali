.class public final Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/Hhd;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;->INSTANCE:Lcom/facebook/aura/auth/deviceid/fdid/AuraPhoneIdSyncStatsReporter;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public report(LX/HhS;)V
    .locals 6

    .line 0
    instance-of v0, p1, LX/HhN;

    .line 1
    .line 2
    if-eqz v0, :cond_8

    .line 3
    .line 4
    :try_start_0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getDeviceInstance()LX/ES4;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "phoneid_sync_stats"

    .line 11
    .line 12
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-interface {v2}, LX/I2T;->isSampled()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_8

    .line 21
    .line 22
    check-cast p1, LX/HhN;

    .line 23
    .line 24
    iget-wide v3, p1, LX/HhS;->A00:J

    .line 25
    .line 26
    const-wide/16 v5, -0x1

    .line 27
    .line 28
    cmp-long v0, v3, v5

    .line 29
    .line 30
    if-eqz v0, :cond_7

    .line 31
    .line 32
    iget-wide v0, p1, LX/HhS;->A02:J

    .line 33
    .line 34
    sub-long/2addr v3, v0

    .line 35
    long-to-int v0, v3

    .line 36
    int-to-long v0, v0

    .line 37
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    const-string v0, "duration"

    .line 42
    .line 43
    invoke-interface {v2, v0, v1}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 44
    .line 45
    .line 46
    iget-object v1, p1, LX/HhS;->A03:Ljava/lang/String;

    .line 47
    .line 48
    const-string/jumbo v0, "src_pkg"

    .line 49
    .line 50
    .line 51
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1}, LX/HhS;->A00()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const-string/jumbo v0, "status"

    .line 59
    .line 60
    .line 61
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    iget-object v1, p1, LX/HhN;->A06:Ljava/lang/String;

    .line 65
    .line 66
    const-string/jumbo v0, "sync_medium"

    .line 67
    .line 68
    .line 69
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p1, LX/HhN;->A01:LX/Fle;

    .line 73
    .line 74
    if-eqz v0, :cond_0

    .line 75
    .line 76
    iget-object v1, v0, LX/Fle;->A01:Ljava/lang/String;

    .line 77
    .line 78
    if-eqz v1, :cond_0

    .line 79
    .line 80
    const-string v0, "phone_id"

    .line 81
    .line 82
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    :cond_0
    iget-object v0, p1, LX/HhN;->A08:LX/Fle;

    .line 86
    .line 87
    if-eqz v0, :cond_1

    .line 88
    .line 89
    iget-object v1, v0, LX/Fle;->A01:Ljava/lang/String;

    .line 90
    .line 91
    if-eqz v1, :cond_1

    .line 92
    .line 93
    const-string v0, "prev_phone_id"

    .line 94
    .line 95
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    :cond_1
    iget-object v0, p1, LX/HhN;->A02:Ljava/lang/Integer;

    .line 99
    .line 100
    if-eqz v0, :cond_2

    .line 101
    .line 102
    invoke-static {v0}, LX/Hha;->A00(Ljava/lang/Integer;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    const-string v0, "failure_reason"

    .line 107
    .line 108
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    :cond_2
    iget-object v1, p1, LX/HhN;->A04:Ljava/lang/String;

    .line 112
    .line 113
    if-eqz v1, :cond_3

    .line 114
    .line 115
    const-string v0, "ordered_pkgs_to_inquire"

    .line 116
    .line 117
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    :cond_3
    iget v0, p1, LX/HhN;->A00:I

    .line 121
    .line 122
    if-ltz v0, :cond_4

    .line 123
    .line 124
    int-to-long v0, v0

    .line 125
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    const-string v0, "query_sequence"

    .line 130
    .line 131
    invoke-interface {v2, v0, v1}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 132
    .line 133
    .line 134
    :cond_4
    iget-object v1, p1, LX/HhN;->A03:Ljava/lang/String;

    .line 135
    .line 136
    if-eqz v1, :cond_5

    .line 137
    .line 138
    const-string v0, "entry_point"

    .line 139
    .line 140
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    iget-boolean v0, p1, LX/HhN;->A07:Z

    .line 144
    .line 145
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    const-string v0, "has_phone_id_synced"

    .line 150
    .line 151
    invoke-interface {v2, v0, v1}, LX/I2T;->A3P(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 152
    .line 153
    .line 154
    :cond_5
    iget-object v1, p1, LX/HhN;->A05:Ljava/lang/String;

    .line 155
    .line 156
    if-eqz v1, :cond_6

    .line 157
    .line 158
    const-string/jumbo v0, "sync_session_id"

    .line 159
    .line 160
    .line 161
    invoke-interface {v2, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    :cond_6
    invoke-interface {v2}, LX/I2T;->AQ5()V

    .line 165
    .line 166
    .line 167
    return-void

    .line 168
    :cond_7
    const-string v0, "End timestamp not initialized yet."

    .line 169
    .line 170
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 175
    :catchall_0
    move-exception v0

    .line 176
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 177
    .line 178
    .line 179
    return-void

    .line 180
    :cond_8
    return-void
.end method
