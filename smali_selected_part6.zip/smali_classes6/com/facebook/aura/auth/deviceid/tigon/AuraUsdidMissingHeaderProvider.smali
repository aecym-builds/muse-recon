.class public final Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/IXu;


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider$Companion;

.field public static final HEADER_NAME:Ljava/lang/String; = "X-Meta-USDID-Missing"

.field public static final TAG:Ljava/lang/String; = "AuraUsdidMissingHeaderProvider"


# instance fields
.field public final headerName:Ljava/lang/String;

.field public final isEnabled:Z

.field public final jwsManager$delegate:LX/0RH;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "jwsManager"

    .line 1
    .line 2
    const-string v1, "getJwsManager()Lcom/facebook/secure/usdid/jws/UsdidJWSManager;"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider$Companion;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->Companion:Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider$Companion;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const v1, 0x1000c

    .line 4
    .line 5
    .line 6
    new-instance v0, LX/0Ek;

    .line 7
    .line 8
    invoke-direct {v0, v1}, LX/0Ek;-><init>(I)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->jwsManager$delegate:LX/0RH;

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->isEnabled:Z

    .line 15
    .line 16
    const-string v0, "X-Meta-USDID-Missing"

    .line 17
    .line 18
    iput-object v0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->headerName:Ljava/lang/String;

    .line 19
    .line 20
    return-void
.end method

.method private final getJwsManager()LX/Fjt;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->jwsManager$delegate:LX/0RH;

    .line 1
    .line 2
    invoke-interface {p0}, LX/Fks;->AMR()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    check-cast p0, LX/Fjt;

    .line 10
    .line 11
    return-object p0
.end method


# virtual methods
.method public getHeaderName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->headerName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getHeaderValue()Ljava/lang/String;
    .locals 4

    .line 0
    const-string v3, ""

    .line 1
    .line 2
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->getJwsManager()LX/Fjt;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, LX/Fjt;->A04()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    :catch_0
    move-exception v2

    .line 12
    const-string v1, "Failed to read the USDID lite token"

    .line 13
    .line 14
    const-string v0, "AuraUsdidMissingHeaderProvider"

    .line 15
    .line 16
    invoke-static {v0, v2, v1}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    move-object v0, v3

    .line 20
    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    const-string v3, "1"

    .line 27
    .line 28
    :cond_0
    return-object v3
.end method

.method public isEnabled()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidMissingHeaderProvider;->isEnabled:Z

    .line 1
    .line 2
    return p0
.end method
