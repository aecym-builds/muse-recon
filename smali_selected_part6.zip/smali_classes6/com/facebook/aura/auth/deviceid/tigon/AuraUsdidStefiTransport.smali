.class public final Lcom/facebook/aura/auth/deviceid/tigon/AuraUsdidStefiTransport;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getHost()Ljava/lang/String;
    .locals 2

    .line 0
    sget-object p0, Lcom/facebook/aura/network/sandbox/AuraSandbox;->INSTANCE:Lcom/facebook/aura/network/sandbox/AuraSandbox;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/network/sandbox/AuraSandbox;->getHttpHost()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v0, "https://api.accounts.meta.com"

    .line 7
    .line 8
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/network/sandbox/AuraSandbox;->rewriteUrl(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-string v0, "://"

    .line 13
    .line 14
    invoke-static {v1, v0, v1}, LX/AdT;->A0Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method

.method public getTigonService()Lcom/facebook/tigon/TigonXplatService;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/network/tigon/AuraTigonServiceProvider;->INSTANCE:Lcom/facebook/aura/network/tigon/AuraTigonServiceProvider;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/network/tigon/AuraTigonServiceProvider;->getTigonXplatService()Lcom/facebook/tigon/TigonXplatService;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
