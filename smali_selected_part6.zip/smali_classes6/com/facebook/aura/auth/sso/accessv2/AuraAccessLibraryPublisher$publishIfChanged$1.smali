.class public final Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/I3Q;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/I3Q<",
        "LX/I3D;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $fingerprint:Ljava/lang/String;

.field public final synthetic $generation:J

.field public final synthetic $snapshot:Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;JLjava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$snapshot:Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$generation:J

    .line 3
    .line 4
    iput-object p4, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$fingerprint:Ljava/lang/String;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public onFailure(Ljava/lang/Throwable;)V
    .locals 8

    .line 0
    const/4 v7, 0x0

    .line 1
    invoke-static {p1, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v1, "AuraAccessLibraryPublisher"

    .line 5
    .line 6
    const-string v0, "Access Library save threw"

    .line 7
    .line 8
    invoke-static {v1, p1, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$snapshot:Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;

    .line 14
    .line 15
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;->session:LX/AHE;

    .line 16
    .line 17
    iget-wide v3, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$generation:J

    .line 18
    .line 19
    iget-object v5, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$fingerprint:Ljava/lang/String;

    .line 20
    .line 21
    const/4 v6, 0x0

    .line 22
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->access$onSaveFinished(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;LX/AHE;JLjava/lang/String;LX/I3D;Z)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public onSuccess(LX/I3D;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$snapshot:Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;

    .line 3
    .line 4
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;->session:LX/AHE;

    .line 5
    .line 6
    iget-wide v3, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$generation:J

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->$fingerprint:Ljava/lang/String;

    .line 9
    .line 10
    const/16 v8, 0x10

    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    const/4 v7, 0x0

    .line 14
    move-object v6, p1

    .line 15
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->onSaveFinished$default(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;LX/AHE;JLjava/lang/String;LX/I3D;ZILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p1, LX/I3D;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;->onSuccess(LX/I3D;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method
