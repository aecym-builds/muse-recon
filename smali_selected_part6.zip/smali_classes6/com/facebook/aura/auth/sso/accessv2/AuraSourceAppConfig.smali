.class public final Lcom/facebook/aura/auth/sso/accessv2/AuraSourceAppConfig;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getLogger()LX/FyC;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v0, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->INSTANCE:Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->getInstance()Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    new-instance v0, LX/FyC;

    .line 13
    .line 14
    invoke-direct {v0, p0, v1}, LX/FyC;-><init>(LX/ES4;Lcom/facebook/quicklog/QuickPerformanceLogger;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method
