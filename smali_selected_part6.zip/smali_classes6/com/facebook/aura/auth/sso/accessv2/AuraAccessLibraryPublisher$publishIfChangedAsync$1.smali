.class public final Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChangedAsync$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChangedAsync$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChangedAsync$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    invoke-static {v0}, LX/602;->A02(Landroid/content/Context;)Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v1, v0}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->access$publishIfChanged(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
