.class public final Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    sget-wide v2, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 1
    .line 2
    const-wide/16 v0, 0x1

    .line 3
    .line 4
    add-long/2addr v2, v0

    .line 5
    sput-wide v2, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 8
    .line 9
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ACCESS_LIBRARY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v0, "published_frl_fingerprint"

    .line 22
    .line 23
    invoke-virtual {v1, v0}, LX/Df3;->Ab6(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1}, LX/Df3;->apply()V

    .line 27
    .line 28
    .line 29
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v2, v0}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->access$removeActiveAccount(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;Landroid/content/Context;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method
