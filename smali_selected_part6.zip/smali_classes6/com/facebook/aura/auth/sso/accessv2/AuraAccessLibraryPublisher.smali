.class public final Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/auth/signout/SignOutCleanupHandler;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

.field public static final executor$delegate:Lkotlin/Lazy;

.field public static sessionGeneration:J


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$executor$2;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$executor$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getSessionGeneration$p()J
    .locals 2

    .line 0
    sget-wide v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static final synthetic access$onSaveFinished(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;LX/AHE;JLjava/lang/String;LX/I3D;Z)V
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->onSaveFinished(LX/AHE;JLjava/lang/String;LX/I3D;Z)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$publishIfChanged(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->publishIfChanged(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$publishedFingerprintPrefs(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;)LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ACCESS_LIBRARY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public static final synthetic access$removeActiveAccount(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->removeActiveAccount(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$setSessionGeneration$p(J)V
    .locals 0

    .line 0
    sput-wide p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 1
    .line 2
    return-void
.end method

.method private final getExecutor()Ljava/util/concurrent/ExecutorService;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A16(Lkotlin/Lazy;)Ljava/util/concurrent/ExecutorService;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method private final onSaveFinished(LX/AHE;JLjava/lang/String;LX/I3D;Z)V
    .locals 2

    .line 0
    sget-wide v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 1
    .line 2
    cmp-long v0, p2, v1

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    if-nez p6, :cond_1

    .line 15
    .line 16
    if-eqz p5, :cond_0

    .line 17
    .line 18
    iget-object v1, p5, LX/I3D;->A02:LX/Fwr;

    .line 19
    .line 20
    const-string v0, "Access Library save failed: "

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const-string v0, "AuraAccessLibraryPublisher"

    .line 27
    .line 28
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void

    .line 32
    :cond_1
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ACCESS_LIBRARY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 35
    .line 36
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const-string v0, "published_frl_fingerprint"

    .line 45
    .line 46
    invoke-virtual {v1, v0, p4}, LX/Df3;->AZD(Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1}, LX/Df3;->apply()V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public static synthetic onSaveFinished$default(Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;LX/AHE;JLjava/lang/String;LX/I3D;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x10

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-static {p5}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p6

    .line 8
    :cond_0
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->onSaveFinished(LX/AHE;JLjava/lang/String;LX/I3D;Z)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method private final publishIfChanged(Landroid/content/Context;)V
    .locals 9

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getCurrentSessionSnapshot()Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;

    .line 3
    .line 4
    .line 5
    move-result-object v7

    .line 6
    if-eqz v7, :cond_0

    .line 7
    .line 8
    sget-wide v2, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->sessionGeneration:J

    .line 9
    .line 10
    iget-object v6, v7, Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;->frlFingerprint:Ljava/lang/String;

    .line 11
    .line 12
    if-eqz v6, :cond_0

    .line 13
    .line 14
    sget-object v1, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ACCESS_LIBRARY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    const-string v1, "published_frl_fingerprint"

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-interface {v4, v1, v0}, LX/BVu;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    sget-object v5, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->INSTANCE:Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;

    .line 36
    .line 37
    invoke-virtual {v5}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->getMetaAccessToken()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    invoke-virtual {v5}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->getMetaAccountId()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    if-eqz v4, :cond_1

    .line 46
    .line 47
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    if-eqz v1, :cond_1

    .line 54
    .line 55
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_1

    .line 60
    .line 61
    invoke-virtual {v5}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->frlFingerprint()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_0

    .line 70
    .line 71
    sget-object v0, LX/Fx9;->A00:LX/0RH;

    .line 72
    .line 73
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisherKt;->ACTIVE_ACCOUNT_ONLY:Ljava/util/Set;

    .line 74
    .line 75
    new-instance p0, LX/Eio;

    .line 76
    .line 77
    invoke-direct {p0, v0, v1}, LX/Eio;-><init>(Ljava/util/Set;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    new-instance v8, LX/Fwy;

    .line 81
    .line 82
    invoke-direct {v8, v4}, LX/Fwy;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    const-string v4, "hatch_android_access_library_publish"

    .line 86
    .line 87
    const/4 v0, 0x0

    .line 88
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 89
    .line 90
    .line 91
    sget-object v0, LX/Fx9;->A03:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 92
    .line 93
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    invoke-static {}, LX/EYw;->A10()LX/FyC;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    const v0, 0x5fb2c3c

    .line 102
    .line 103
    .line 104
    invoke-virtual {v1, v0, v5, v4}, LX/FyC;->A01(IILjava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sget-object v4, LX/Fx9;->A01:LX/FG6;

    .line 108
    .line 109
    const/4 v1, 0x5

    .line 110
    new-instance v0, LX/ID3;

    .line 111
    .line 112
    invoke-direct {v0, p1, p0, v8, v1}, LX/ID3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 113
    .line 114
    .line 115
    invoke-interface {v4, v0}, LX/FG6;->Ah5(Ljava/util/concurrent/Callable;)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    invoke-static {v4}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    const/4 v0, 0x2

    .line 123
    new-instance v1, LX/IDQ;

    .line 124
    .line 125
    invoke-direct {v1, v5, v0}, LX/IDQ;-><init>(II)V

    .line 126
    .line 127
    .line 128
    sget-object v0, LX/I9m;->A01:LX/I9m;

    .line 129
    .line 130
    invoke-static {v1, v4, v0}, LX/F0M;->A01(LX/I3Q;Lcom/google/common/util/concurrent/ListenableFuture;Ljava/util/concurrent/Executor;)V

    .line 131
    .line 132
    .line 133
    new-instance v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;

    .line 134
    .line 135
    invoke-direct {v1, v7, v2, v3, v6}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChanged$1;-><init>(Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;JLjava/lang/String;)V

    .line 136
    .line 137
    .line 138
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 139
    .line 140
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    invoke-static {v1, v4, v0}, LX/F0M;->A01(LX/I3Q;Lcom/google/common/util/concurrent/ListenableFuture;Ljava/util/concurrent/Executor;)V

    .line 145
    .line 146
    .line 147
    :cond_0
    return-void

    .line 148
    :cond_1
    const-string v1, "AuraAccessLibraryPublisher"

    .line 149
    .line 150
    const-string v0, "Skipping publish: FRL credentials incomplete"

    .line 151
    .line 152
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    return-void
.end method

.method private final publishedFingerprintPrefs()LX/BVu;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraDevicePrefs;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;->ACCESS_LIBRARY:Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/common/prefs/AuraDevicePrefs;->get(Lcom/facebook/aura/common/prefs/AuraDevicePrefStore;)LX/BVu;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method private final removeActiveAccount(Landroid/content/Context;)V
    .locals 4

    .line 0
    sget-object v0, LX/Fx9;->A00:LX/0RH;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisherKt;->ACTIVE_ACCOUNT_ONLY:Ljava/util/Set;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    new-instance p0, LX/Eio;

    .line 6
    .line 7
    invoke-direct {p0, v1, v0}, LX/Eio;-><init>(Ljava/util/Set;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "hatch_android_access_library_publish"

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    sget-object v0, LX/Fx9;->A03:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    invoke-static {}, LX/EYw;->A10()LX/FyC;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const v0, 0x5fb3754

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, v0, v3, v2}, LX/FyC;->A01(IILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sget-object v2, LX/Fx9;->A01:LX/FG6;

    .line 33
    .line 34
    const/16 v1, 0x9

    .line 35
    .line 36
    new-instance v0, LX/ID1;

    .line 37
    .line 38
    invoke-direct {v0, v1, p1, p0}, LX/ID1;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-interface {v2, v0}, LX/FG6;->Ah5(Ljava/util/concurrent/Callable;)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    const/4 v0, 0x1

    .line 49
    new-instance v1, LX/IDQ;

    .line 50
    .line 51
    invoke-direct {v1, v3, v0}, LX/IDQ;-><init>(II)V

    .line 52
    .line 53
    .line 54
    sget-object v0, LX/I9m;->A01:LX/I9m;

    .line 55
    .line 56
    invoke-static {v1, v2, v0}, LX/F0M;->A01(LX/I3Q;Lcom/google/common/util/concurrent/ListenableFuture;Ljava/util/concurrent/Executor;)V

    .line 57
    .line 58
    .line 59
    new-instance v1, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$removeActiveAccount$1;

    .line 60
    .line 61
    invoke-direct {v1}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$removeActiveAccount$1;-><init>()V

    .line 62
    .line 63
    .line 64
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 65
    .line 66
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-static {v1, v2, v0}, LX/F0M;->A01(LX/I3Q;Lcom/google/common/util/concurrent/ListenableFuture;Ljava/util/concurrent/Executor;)V

    .line 71
    .line 72
    .line 73
    return-void
.end method


# virtual methods
.method public cleanup()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;->INSTANCE:Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$cleanup$1;

    .line 7
    .line 8
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final publishIfChangedAsync(Landroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher;->executor$delegate:Lkotlin/Lazy;

    .line 5
    .line 6
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    new-instance v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChangedAsync$1;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisher$publishIfChangedAsync$1;-><init>(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
