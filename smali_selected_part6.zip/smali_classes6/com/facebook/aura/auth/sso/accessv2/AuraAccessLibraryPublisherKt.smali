.class public abstract Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisherKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ACTIVE_ACCOUNT_ONLY:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LX/FyZ;",
            ">;"
        }
    .end annotation
.end field

.field public static final LOG_LOCATION:Ljava/lang/String; = "hatch_android_access_library_publish"

.field public static final PUBLISHED_FRL_FINGERPRINT_KEY:Ljava/lang/String; = "published_frl_fingerprint"

.field public static final TAG:Ljava/lang/String; = "AuraAccessLibraryPublisher"

.field public static final THREAD_NAME:Ljava/lang/String; = "AuraAccessLibraryPublisher"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, LX/FyZ;->A03:LX/FyZ;

    .line 1
    .line 2
    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisherKt;->ACTIVE_ACCOUNT_ONLY:Ljava/util/Set;

    .line 7
    .line 8
    return-void
.end method

.method public static final synthetic access$getACTIVE_ACCOUNT_ONLY$p()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/sso/accessv2/AuraAccessLibraryPublisherKt;->ACTIVE_ACCOUNT_ONLY:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method
