.class public abstract Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccountKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ACCOUNT_TYPE:Ljava/lang/String; = "com.facebook.aura"

.field public static final TAG:Ljava/lang/String; = "AuraSystemAccount"
