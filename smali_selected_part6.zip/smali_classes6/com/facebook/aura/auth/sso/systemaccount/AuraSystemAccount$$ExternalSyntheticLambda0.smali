.class public final synthetic Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroid/accounts/AccountManager;


# direct methods
.method public synthetic constructor <init>(Landroid/accounts/AccountManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda0;->f$0:Landroid/accounts/AccountManager;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda0;->f$0:Landroid/accounts/AccountManager;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->cleanup$lambda$0(Landroid/accounts/AccountManager;)Lkotlin/Unit;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
