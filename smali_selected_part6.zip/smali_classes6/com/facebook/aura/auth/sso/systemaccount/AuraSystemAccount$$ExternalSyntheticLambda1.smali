.class public final synthetic Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function0;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;->f$1:Ljava/lang/String;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;->f$1:Ljava/lang/String;

    .line 3
    .line 4
    invoke-static {v1, v0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->run$lambda$0(Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
