.class public final synthetic Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroid/accounts/AccountManager;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:LX/AHE;


# direct methods
.method public synthetic constructor <init>(Landroid/accounts/AccountManager;Ljava/lang/String;LX/AHE;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$0:Landroid/accounts/AccountManager;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$2:LX/AHE;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$0:Landroid/accounts/AccountManager;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;->f$2:LX/AHE;

    .line 5
    .line 6
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->addIfMissingAsync$lambda$0(Landroid/accounts/AccountManager;Ljava/lang/String;LX/AHE;)Lkotlin/Unit;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method
