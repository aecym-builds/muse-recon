.class public final synthetic Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/executors/AuraExecutors;->CORE_POOL_SIZE:I

    .line 1
    .line 2
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;

    .line 7
    .line 8
    invoke-direct {v0, p0}, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;-><init>(Ljava/util/concurrent/Executor;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
