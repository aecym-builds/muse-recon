.class public final Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/auth/signout/SignOutCleanupHandler;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;

.field public static final executor$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->INSTANCE:Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda3;

    .line 8
    .line 9
    invoke-direct {v0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda3;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->executor$delegate:Lkotlin/Lazy;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final accountManager()Landroid/accounts/AccountManager;
    .locals 0

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-object p0
.end method

.method public static final addIfMissingAsync$lambda$0(Landroid/accounts/AccountManager;Ljava/lang/String;LX/AHE;)Lkotlin/Unit;
    .locals 3

    .line 0
    const-string v2, "com.facebook.aura"

    .line 1
    .line 2
    invoke-virtual {p0, v2}, Landroid/accounts/AccountManager;->getAccountsByType(Ljava/lang/String;)[Landroid/accounts/Account;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    array-length v0, v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    new-instance v1, Landroid/accounts/Account;

    .line 13
    .line 14
    invoke-direct {v1, p1, v2}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-virtual {p0, v1, v0, v0}, Landroid/accounts/AccountManager;->addAccountExplicitly(Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 19
    .line 20
    .line 21
    :cond_0
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 22
    .line 23
    invoke-virtual {v0, p2}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    sget-object v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->INSTANCE:Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;

    .line 30
    .line 31
    invoke-direct {v0, p0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->removeAll(Landroid/accounts/AccountManager;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 35
    .line 36
    return-object v0
.end method

.method public static final cleanup$lambda$0(Landroid/accounts/AccountManager;)Lkotlin/Unit;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->INSTANCE:Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;

    .line 1
    .line 2
    invoke-direct {v0, p0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->removeAll(Landroid/accounts/AccountManager;)V

    .line 3
    .line 4
    .line 5
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object v0
.end method

.method public static final executor_delegate$lambda$0()Ljava/util/concurrent/Executor;
    .locals 2

    .line 0
    sget v0, Lcom/facebook/aura/executors/AuraExecutors;->CORE_POOL_SIZE:I

    .line 1
    .line 2
    invoke-static {}, LX/EYu;->A12()Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    new-instance v0, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lcom/facebook/aura/executors/AuraExecutors$SerialExecutor;-><init>(Ljava/util/concurrent/Executor;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method private final getExecutor()Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->executor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method private final removeAll(Landroid/accounts/AccountManager;)V
    .locals 3

    .line 0
    const-string v0, "com.facebook.aura"

    .line 1
    .line 2
    invoke-virtual {p1, v0}, Landroid/accounts/AccountManager;->getAccountsByType(Ljava/lang/String;)[Landroid/accounts/Account;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    array-length v2, p0

    .line 10
    const/4 v1, 0x0

    .line 11
    :goto_0
    if-ge v1, v2, :cond_0

    .line 12
    .line 13
    aget-object v0, p0, v1

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Landroid/accounts/AccountManager;->removeAccountExplicitly(Landroid/accounts/Account;)Z

    .line 16
    .line 17
    .line 18
    add-int/lit8 v1, v1, 0x1

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    return-void
.end method

.method private final run(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->executor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;

    .line 7
    .line 8
    invoke-direct {v0, p2, p1}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static final run$lambda$0(Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .locals 2

    .line 0
    :try_start_0
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    :catch_0
    move-exception p0

    .line 5
    const-string v1, "System account "

    .line 6
    .line 7
    const-string v0, " failed"

    .line 8
    .line 9
    invoke-static {v1, p1, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v0, "AuraSystemAccount"

    .line 14
    .line 15
    invoke-static {v0, p0, v1}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final addIfMissingAsync(LX/AHE;Ljava/lang/String;)V
    .locals 2

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->accountManager()Landroid/accounts/AccountManager;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;

    .line 8
    .line 9
    invoke-direct {v1, v0, p2, p1}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda2;-><init>(Landroid/accounts/AccountManager;Ljava/lang/String;LX/AHE;)V

    .line 10
    .line 11
    .line 12
    const-string v0, "add"

    .line 13
    .line 14
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->run(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public cleanup()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->accountManager()Landroid/accounts/AccountManager;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    new-instance v1, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda0;

    .line 5
    .line 6
    invoke-direct {v1, v0}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount$$ExternalSyntheticLambda0;-><init>(Landroid/accounts/AccountManager;)V

    .line 7
    .line 8
    .line 9
    const-string v0, "remove"

    .line 10
    .line 11
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/auth/sso/systemaccount/AuraSystemAccount;->run(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
