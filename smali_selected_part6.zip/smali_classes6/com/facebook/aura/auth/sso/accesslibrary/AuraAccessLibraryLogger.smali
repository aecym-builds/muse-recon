.class public final Lcom/facebook/aura/auth/sso/accesslibrary/AuraAccessLibraryLogger;
.super LX/FyD;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, LX/FyD;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getLogger()LX/FyL;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    const-string v0, "fx_access_library"

    .line 7
    .line 8
    invoke-interface {p0, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    new-instance v0, LX/FyK;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p0, v0, LX/I8F;->A00:LX/I2T;

    .line 18
    .line 19
    return-object v0
.end method

.method public getQplHelper()LX/I1U;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->INSTANCE:Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/qpl/AuraQuickPerformanceLogger;->getInstance()Lcom/facebook/quicklog/QuickPerformanceLogger;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, LX/I1U;

    .line 7
    .line 8
    invoke-direct {v0, p0}, LX/I1U;-><init>(Lcom/facebook/quicklog/QuickPerformanceLogger;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
