.class public final Lcom/facebook/aura/auth/sso/accesslibrary/AuraDebugAccessLibraryLoggerProvider;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/sso/accesslibrary/AuraDebugAccessLibraryLoggerProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/sso/accesslibrary/AuraDebugAccessLibraryLoggerProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/sso/accesslibrary/AuraDebugAccessLibraryLoggerProvider;->INSTANCE:Lcom/facebook/aura/auth/sso/accesslibrary/AuraDebugAccessLibraryLoggerProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getAccessLibraryLogger(Landroid/content/Context;LX/0HH;LX/09L;)LX/FyD;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/auth/sso/accesslibrary/AuraAccessLibraryLogger;

    .line 1
    .line 2
    invoke-direct {p0}, LX/FyD;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method
