.class public final Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Landroid/graphics/Bitmap;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1"
    f = "ApprovalNotificationIcon.kt"
    l = {
        0x26
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $sizePx:I

.field public final synthetic $uri:Landroid/net/Uri;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/net/Uri;ILX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "I",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$uri:Landroid/net/Uri;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$sizePx:I

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$uri:Landroid/net/Uri;

    .line 1
    .line 2
    iget p0, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$sizePx:I

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;-><init>(Landroid/net/Uri;ILX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v1, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-object p1

    .line 13
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sget-object v3, Lcom/facebook/aura/common/image/AuraBitmapLoader;->INSTANCE:Lcom/facebook/aura/common/image/AuraBitmapLoader;

    .line 17
    .line 18
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$uri:Landroid/net/Uri;

    .line 19
    .line 20
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->$sizePx:I

    .line 21
    .line 22
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v6

    .line 26
    iput v1, p0, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;->label:I

    .line 27
    .line 28
    const-string v5, "AgentApprovalNotification"

    .line 29
    .line 30
    const/4 v7, 0x0

    .line 31
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/common/image/AuraBitmapLoader;->load(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/Integer;Landroid/graphics/Bitmap$Config;LX/2M4;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    if-ne p1, v2, :cond_0

    .line 36
    .line 37
    return-object v2

    .line 38
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    throw v0
.end method
