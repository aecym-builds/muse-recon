.class public final Lcom/facebook/aura/appmodules/AuraAppModules;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

.field public static final downloadManager$delegate:Lkotlin/Lazy;

.field public static final executor$delegate:Lkotlin/Lazy;

.field public static final manager$delegate:Lkotlin/Lazy;

.field public static final playDownloaderExecutor$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules$manager$2;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$manager$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->manager$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules$executor$2;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$executor$2;

    .line 16
    .line 17
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->executor$delegate:Lkotlin/Lazy;

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules$playDownloaderExecutor$2;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$playDownloaderExecutor$2;

    .line 24
    .line 25
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->playDownloaderExecutor$delegate:Lkotlin/Lazy;

    .line 30
    .line 31
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;

    .line 32
    .line 33
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->downloadManager$delegate:Lkotlin/Lazy;

    .line 38
    .line 39
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$createManager(Lcom/facebook/aura/appmodules/AuraAppModules;Landroid/content/Context;)LX/H0H;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/appmodules/AuraAppModules;->createManager(Landroid/content/Context;)LX/H0H;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$createPlayDownloader(Lcom/facebook/aura/appmodules/AuraAppModules;Landroid/content/Context;LX/H0F;LX/H0N;Ljava/util/concurrent/Executor;)LX/H0D;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/appmodules/AuraAppModules;->createPlayDownloader(Landroid/content/Context;LX/H0F;LX/H0N;Ljava/util/concurrent/Executor;)LX/H0D;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getPlayDownloaderExecutor(Lcom/facebook/aura/appmodules/AuraAppModules;)Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->playDownloaderExecutor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method private final createManager(Landroid/content/Context;)LX/H0H;
    .locals 12

    .line 0
    sget-object v0, Lcom/facebook/aura/common/prefs/AuraPrefsStorage;->INSTANCE:Lcom/facebook/aura/common/prefs/AuraPrefsStorage;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/common/prefs/AuraPrefsStorage;->getFactory()LX/BAl;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    sget-object v0, LX/H0F;->A01:LX/H0v;

    .line 7
    .line 8
    move-object v8, p1

    .line 9
    invoke-static {p1, v0}, LX/H0v;->A00(Landroid/content/Context;LX/H0v;)LX/H0F;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-static {p1}, LX/H17;->A00(Landroid/content/Context;)LX/H0N;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    sget-object v0, LX/H0E;->A05:LX/H0h;

    .line 18
    .line 19
    invoke-virtual {v0, p1, v1, v2}, LX/H0h;->A00(Landroid/content/Context;LX/H0N;LX/H0p;)LX/H0E;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    sget-object v1, Lcom/facebook/aura/appmodules/AuraAppModules;->downloadManager$delegate:Lkotlin/Lazy;

    .line 24
    .line 25
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 30
    .line 31
    new-instance v4, Lcom/facebook/aura/appmodules/AuraAppModuleDownloadActionManager;

    .line 32
    .line 33
    invoke-direct {v4, p1, v3, v0}, Lcom/facebook/aura/appmodules/AuraAppModuleDownloadActionManager;-><init>(Landroid/content/Context;LX/BAl;LX/H0b;)V

    .line 34
    .line 35
    .line 36
    const-class v0, Landroid/net/ConnectivityManager;

    .line 37
    .line 38
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, Landroid/net/ConnectivityManager;

    .line 43
    .line 44
    new-instance v2, LX/H0r;

    .line 45
    .line 46
    invoke-direct {v2, p1, v0, v4, p0}, LX/H0r;-><init>(Landroid/content/Context;Landroid/net/ConnectivityManager;LX/H0Z;LX/H0E;)V

    .line 47
    .line 48
    .line 49
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v11

    .line 53
    check-cast v11, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 54
    .line 55
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->executor$delegate:Lkotlin/Lazy;

    .line 56
    .line 57
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    sget-object v6, LX/0wV;->A00:LX/0wV;

    .line 62
    .line 63
    new-instance v3, LX/H1F;

    .line 64
    .line 65
    invoke-direct {v3, p0}, LX/H1F;-><init>(LX/H0E;)V

    .line 66
    .line 67
    .line 68
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    check-cast v5, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 77
    .line 78
    new-instance v1, LX/H0J;

    .line 79
    .line 80
    invoke-direct/range {v1 .. v7}, LX/H0J;-><init>(LX/H0r;LX/H1F;LX/H0Z;LX/H0b;Ljava/util/Collection;Ljava/util/concurrent/Executor;)V

    .line 81
    .line 82
    .line 83
    new-instance v7, LX/H0H;

    .line 84
    .line 85
    move-object v9, v1

    .line 86
    move-object v10, v4

    .line 87
    invoke-direct/range {v7 .. v13}, LX/H0H;-><init>(Landroid/content/Context;LX/H0J;LX/H0Z;LX/H0b;LX/H0E;Ljava/util/concurrent/Executor;)V

    .line 88
    .line 89
    .line 90
    return-object v7
.end method

.method private final createPlayDownloader(Landroid/content/Context;LX/H0F;LX/H0N;Ljava/util/concurrent/Executor;)LX/H0D;
    .locals 5

    .line 0
    sget-object v0, Lcom/facebook/aura/installsource/AuraInstallSourceDetector;->INSTANCE:Lcom/facebook/aura/installsource/AuraInstallSourceDetector;

    .line 1
    .line 2
    move-object v2, p1

    .line 3
    invoke-virtual {v0, p1}, Lcom/facebook/aura/installsource/AuraInstallSourceDetector;->isPlayStoreInstall(Landroid/content/Context;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    return-object v1

    .line 11
    :cond_0
    new-instance v1, LX/H1G;

    .line 12
    .line 13
    invoke-direct {v1, p1}, LX/H1G;-><init>(Landroid/content/Context;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, LX/H15;

    .line 17
    .line 18
    invoke-direct {v0, p1, v1}, LX/H15;-><init>(Landroid/content/Context;LX/H1G;)V

    .line 19
    .line 20
    .line 21
    new-instance p1, LX/H0k;

    .line 22
    .line 23
    move-object v4, p3

    .line 24
    invoke-direct {p1, v2, p3, v0}, LX/H0k;-><init>(Landroid/content/Context;LX/H0N;LX/H15;)V

    .line 25
    .line 26
    .line 27
    new-instance v3, LX/H1R;

    .line 28
    .line 29
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    new-instance v1, LX/H0D;

    .line 33
    .line 34
    move-object p0, p2

    .line 35
    move-object p2, p4

    .line 36
    invoke-direct/range {v1 .. v7}, LX/H0D;-><init>(Landroid/content/Context;LX/H1R;LX/H0N;LX/H0p;LX/H0k;Ljava/util/concurrent/Executor;)V

    .line 37
    .line 38
    .line 39
    return-object v1
.end method

.method private final getDownloadManager()Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->downloadManager$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 7
    .line 8
    return-object p0
.end method

.method private final getExecutor()Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->executor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method

.method private final getPlayDownloaderExecutor()Ljava/util/concurrent/Executor;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->playDownloaderExecutor$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-static {p0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method


# virtual methods
.method public final deferInstall(Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, LX/H0I;->A04:LX/H18;

    .line 5
    .line 6
    invoke-virtual {v0}, LX/H18;->A00()LX/H0I;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iget-object v0, v0, LX/H0I;->A00:LX/GGU;

    .line 15
    .line 16
    invoke-virtual {v0, v1}, LX/GGU;->A05(Landroid/content/Context;)Z

    .line 17
    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->downloadManager$delegate:Lkotlin/Lazy;

    .line 20
    .line 21
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 26
    .line 27
    invoke-static {p1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    sget-object v1, LX/H0T;->A03:LX/H0T;

    .line 32
    .line 33
    new-instance v0, LX/H0a;

    .line 34
    .line 35
    invoke-direct {v0, v1, v2}, LX/H0a;-><init>(LX/H0T;Ljava/util/Set;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0, v0}, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->deferInstall(LX/H0a;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final getManager()LX/H0H;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->manager$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, LX/H0H;

    .line 7
    .line 8
    return-object p0
.end method

.method public final isDeclared(Ljava/lang/String;)Z
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/Ehs;->A00(Ljava/lang/String;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-ltz v0, :cond_0

    .line 9
    .line 10
    const/4 p0, 0x1

    .line 11
    :cond_0
    return p0
.end method

.method public final isInstalled(Ljava/lang/String;)Z
    .locals 2

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->splitNames:[Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-static {p1, v0}, LX/B82;->A0H(Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, 0x1

    .line 21
    if-ne v1, v0, :cond_0

    .line 22
    .line 23
    return v0

    .line 24
    :cond_0
    return p0
.end method

.method public final isObtainable(Ljava/lang/String;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/Ehs;->A00(Ljava/lang/String;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-ltz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appmodules/AuraAppModules;->isInstalled(Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    sget-object v1, Lcom/facebook/aura/installsource/AuraInstallSourceDetector;->INSTANCE:Lcom/facebook/aura/installsource/AuraInstallSourceDetector;

    .line 17
    .line 18
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v1, v0}, Lcom/facebook/aura/installsource/AuraInstallSourceDetector;->isPlayStoreInstall(Landroid/content/Context;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    :cond_0
    const/4 v2, 0x1

    .line 29
    :cond_1
    return v2
.end method
