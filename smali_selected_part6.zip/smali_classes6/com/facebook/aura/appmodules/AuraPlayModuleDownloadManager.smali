.class public final Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H0b;


# instance fields
.field public final name:Ljava/lang/String;

.field public final playDownloader:LX/H0D;


# direct methods
.method public constructor <init>(LX/H0D;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 4
    .line 5
    const-string v0, "AuraPlay"

    .line 6
    .line 7
    iput-object v0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->name:Ljava/lang/String;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public backgroundInit()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-static {p0}, LX/H0D;->A01(LX/H0D;)V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method public deferInstall(LX/H0a;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object p1, p1, LX/H0a;->A01:Ljava/util/Set;

    .line 9
    .line 10
    iget-object p0, v0, LX/H0D;->A0A:LX/Fmp;

    .line 11
    .line 12
    invoke-static {p1}, LX/001;->A13(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {p0, v0}, LX/Fmp;->A8q(Ljava/util/List;)LX/FWb;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public getName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public isRetryable(LX/H0g;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/H0g<",
            "LX/Eg5;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 5
    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    invoke-virtual {p1}, LX/H0g;->A03()Ljava/lang/Exception;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    instance-of v0, v1, Lcom/facebook/voltron/download/google/GooglePlayDownloader$CancelledException;

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    instance-of v0, v1, Lcom/google/android/play/core/splitinstall/SplitInstallException;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    check-cast v1, Lcom/google/android/gms/common/api/ApiException;

    .line 21
    .line 22
    iget-object v0, v1, Lcom/google/android/gms/common/api/ApiException;->mStatus:Lcom/google/android/gms/common/api/Status;

    .line 23
    .line 24
    iget v1, v0, Lcom/google/android/gms/common/api/Status;->A00:I

    .line 25
    .line 26
    const/4 v0, -0x5

    .line 27
    if-eq v1, v0, :cond_1

    .line 28
    .line 29
    const/4 v0, -0x2

    .line 30
    if-eq v1, v0, :cond_1

    .line 31
    .line 32
    if-eqz v1, :cond_1

    .line 33
    .line 34
    :cond_0
    const/4 v0, 0x1

    .line 35
    return v0

    .line 36
    :cond_1
    const/4 v0, 0x0

    .line 37
    return v0

    .line 38
    :cond_2
    return v1
.end method

.method public startDownload(LX/H0a;)LX/H0g;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/H0a;",
            ")",
            "LX/H0g<",
            "LX/Eg5;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v4, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 5
    .line 6
    if-eqz v4, :cond_0

    .line 7
    .line 8
    new-instance v3, LX/H0i;

    .line 9
    .line 10
    invoke-direct {v3}, LX/H0i;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-object v2, p1, LX/H0a;->A01:Ljava/util/Set;

    .line 14
    .line 15
    iget-object v1, v4, LX/H0D;->A0A:LX/Fmp;

    .line 16
    .line 17
    invoke-static {v2}, LX/001;->A13(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-interface {v1, v0}, LX/Fmp;->A8q(Ljava/util/List;)LX/FWb;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v2, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    new-instance v1, LX/H0t;

    .line 32
    .line 33
    invoke-direct {v1, v3, p1}, LX/H0t;-><init>(LX/H0i;LX/H0a;)V

    .line 34
    .line 35
    .line 36
    monitor-enter v4

    .line 37
    :try_start_0
    iget-object v0, v4, LX/H0D;->A0C:Ljava/util/Queue;

    .line 38
    .line 39
    invoke-interface {v0, v1}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    invoke-static {v4}, LX/H0D;->A02(LX/H0D;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    .line 44
    .line 45
    monitor-exit v4

    .line 46
    iget-object v0, v3, LX/H0i;->A00:LX/H0j;

    .line 47
    .line 48
    return-object v0

    .line 49
    :catchall_0
    move-exception v0

    .line 50
    monitor-exit v4

    .line 51
    throw v0

    .line 52
    :cond_0
    const/4 v2, 0x0

    .line 53
    const/4 p1, 0x4

    .line 54
    new-instance v1, LX/Eg5;

    .line 55
    .line 56
    move-object v3, v2

    .line 57
    move-object v4, v2

    .line 58
    move-object p0, v2

    .line 59
    invoke-direct/range {v1 .. v6}, LX/Eg5;-><init>(Ljava/lang/Exception;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;I)V

    .line 60
    .line 61
    .line 62
    new-instance v0, LX/H0j;

    .line 63
    .line 64
    invoke-direct {v0}, LX/H0j;-><init>()V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v1}, LX/H0j;->A06(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    return-object v0
.end method

.method public startUninstall(LX/H0a;LX/H0i;)LX/H0g;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/H0a;",
            "LX/H0i<",
            "Ljava/lang/Integer;",
            ">;)",
            "LX/H0g<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object p0, p0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;->playDownloader:LX/H0D;

    .line 4
    .line 5
    if-nez p0, :cond_0

    .line 6
    .line 7
    invoke-static {}, LX/EYt;->A0c()Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget-object v0, p2, LX/H0i;->A00:LX/H0j;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, LX/H0j;->A06(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :goto_0
    iget-object v0, p2, LX/H0i;->A00:LX/H0j;

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_0
    iget-object v1, p0, LX/H0D;->A0A:LX/Fmp;

    .line 20
    .line 21
    iget-object v0, p1, LX/H0a;->A01:Ljava/util/Set;

    .line 22
    .line 23
    invoke-static {v0}, LX/001;->A13(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-interface {v1, v0}, LX/Fmp;->A8r(Ljava/util/List;)LX/FWb;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-static {p1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget-object p0, p0, LX/H0D;->A0D:Ljava/util/concurrent/Executor;

    .line 35
    .line 36
    const/16 v1, 0x8

    .line 37
    .line 38
    new-instance v0, LX/IEJ;

    .line 39
    .line 40
    invoke-direct {v0, p2, v1}, LX/IEJ;-><init>(Ljava/lang/Object;I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p1, v0, p0}, LX/FWb;->A06(LX/FW1;Ljava/util/concurrent/Executor;)LX/FWa;

    .line 44
    .line 45
    .line 46
    const/4 v1, 0x3

    .line 47
    new-instance v0, LX/IDa;

    .line 48
    .line 49
    invoke-direct {v0, p2, v1}, LX/IDa;-><init>(Ljava/lang/Object;I)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p1, v0, p0}, LX/FWb;->A0A(LX/FWj;Ljava/util/concurrent/Executor;)V

    .line 53
    .line 54
    .line 55
    goto :goto_0
.end method
