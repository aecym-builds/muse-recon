.class public final Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;
    .locals 4

    .line 0
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    sget-object v3, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 5
    .line 6
    sget-object v0, LX/H0F;->A01:LX/H0v;

    .line 7
    .line 8
    invoke-static {p0, v0}, LX/H0v;->A00(Landroid/content/Context;LX/H0v;)LX/H0F;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-static {p0}, LX/H17;->A00(Landroid/content/Context;)LX/H0N;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sget-object v0, Lcom/facebook/aura/appmodules/AuraAppModules;->playDownloaderExecutor$delegate:Lkotlin/Lazy;

    .line 17
    .line 18
    invoke-static {v0}, LX/EYt;->A15(Lkotlin/Lazy;)Ljava/util/concurrent/Executor;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v3, p0, v2, v1, v0}, Lcom/facebook/aura/appmodules/AuraAppModules;->access$createPlayDownloader(Lcom/facebook/aura/appmodules/AuraAppModules;Landroid/content/Context;LX/H0F;LX/H0N;Ljava/util/concurrent/Executor;)LX/H0D;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    new-instance v0, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 27
    .line 28
    invoke-direct {v0, v1}, Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;-><init>(LX/H0D;)V

    .line 29
    .line 30
    .line 31
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/appmodules/AuraAppModules$downloadManager$2;->invoke()Lcom/facebook/aura/appmodules/AuraPlayModuleDownloadManager;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
