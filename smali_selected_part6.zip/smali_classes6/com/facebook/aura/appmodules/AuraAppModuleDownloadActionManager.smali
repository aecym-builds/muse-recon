.class public final Lcom/facebook/aura/appmodules/AuraAppModuleDownloadActionManager;
.super LX/H0Z;
.source ""


# instance fields
.field public final voltronDownloadManager:LX/H0b;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/BAl;LX/H0b;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, LX/H0Z;-><init>(Landroid/content/Context;LX/BAl;)V

    .line 4
    .line 5
    .line 6
    iput-object p3, p0, Lcom/facebook/aura/appmodules/AuraAppModuleDownloadActionManager;->voltronDownloadManager:LX/H0b;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public areDownloadsEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public getPackagingPreference(Ljava/lang/String;)LX/0TS;
    .locals 0

    .line 0
    sget-object p0, LX/0TS;->A02:LX/0TS;

    .line 1
    .line 2
    return-object p0
.end method

.method public getVoltronDownloadManager()LX/H0b;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/appmodules/AuraAppModuleDownloadActionManager;->voltronDownloadManager:LX/H0b;

    .line 1
    .line 2
    return-object p0
.end method

.method public isSystemPrefetchEnabled(Ljava/lang/String;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
