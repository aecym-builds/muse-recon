.class public final Lcom/facebook/animated/webp/WebPImageDecoder;
.super LX/HV5;
.source ""

# interfaces
.implements LX/HTC;


# direct methods
.method public constructor <init>(LX/HV8;ZZZ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1, p3, p2, p4}, LX/HV5;-><init>(LX/HV8;ZZZ)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final decode(LX/HRD;ILX/HSM;LX/HVU;)LX/HSy;
    .locals 7

    .line 0
    invoke-static {p1, p4}, LX/603;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p1, LX/HRD;->A0C:LX/HT2;

    .line 4
    .line 5
    invoke-static {v0}, LX/EYu;->A0Q(LX/HT2;)LX/HT2;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    invoke-static {v3}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :try_start_0
    invoke-virtual {v3}, LX/HT2;->A04()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v5

    .line 16
    move-object v4, v5

    .line 17
    check-cast v4, LX/HR9;

    .line 18
    .line 19
    monitor-enter v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 20
    :try_start_1
    invoke-static {v4}, LX/HR9;->A00(LX/HR9;)LX/HHX;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-interface {v0}, LX/HHX;->getByteBuffer()Ljava/nio/ByteBuffer;

    .line 25
    .line 26
    .line 27
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 28
    :try_start_2
    monitor-exit v5

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-static {}, LX/HRc;->A00()V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/nio/Buffer;->rewind()Ljava/nio/Buffer;

    .line 35
    .line 36
    .line 37
    invoke-static {v0}, Lcom/facebook/animated/webp/WebPImage;->nativeCreateFromDirectByteBuffer(Ljava/nio/ByteBuffer;)Lcom/facebook/animated/webp/WebPImage;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    iget-object v1, p4, LX/HVU;->A00:Landroid/graphics/Bitmap$Config;

    .line 42
    .line 43
    iput-object v1, v2, Lcom/facebook/animated/webp/WebPImage;->mDecodeBitmapConfig:Landroid/graphics/Bitmap$Config;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    monitor-enter v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 47
    :try_start_3
    invoke-static {v4}, LX/HR9;->A01(LX/HR9;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v4}, LX/HR9;->A00(LX/HR9;)LX/HHX;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-interface {v0}, LX/HHX;->getNativePtr()J

    .line 55
    .line 56
    .line 57
    move-result-wide v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 58
    :try_start_4
    monitor-exit v5

    .line 59
    invoke-virtual {v4}, LX/HR9;->A03()I

    .line 60
    .line 61
    .line 62
    move-result v6

    .line 63
    invoke-static {}, LX/HRc;->A00()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 64
    .line 65
    .line 66
    const-wide/16 v4, 0x0

    .line 67
    .line 68
    cmp-long v0, v1, v4

    .line 69
    .line 70
    invoke-static {v0}, LX/003;->A1B(I)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    :try_start_5
    invoke-static {v0}, LX/H2H;->A02(Z)V

    .line 75
    .line 76
    .line 77
    invoke-static {v1, v2, v6}, Lcom/facebook/animated/webp/WebPImage;->nativeCreateFromNativeMemory(JI)Lcom/facebook/animated/webp/WebPImage;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    iget-object v1, p4, LX/HVU;->A00:Landroid/graphics/Bitmap$Config;

    .line 82
    .line 83
    iput-object v1, v2, Lcom/facebook/animated/webp/WebPImage;->mDecodeBitmapConfig:Landroid/graphics/Bitmap$Config;

    .line 84
    .line 85
    :goto_0
    iget-object v0, p1, LX/HRD;->A09:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {p0, v1, v2, p4, v0}, LX/HV5;->A01(Landroid/graphics/Bitmap$Config;LX/HWm;LX/HVU;Ljava/lang/String;)LX/HSX;

    .line 88
    .line 89
    .line 90
    move-result-object v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 91
    invoke-virtual {v3}, LX/HT2;->close()V

    .line 92
    .line 93
    .line 94
    return-object v0

    .line 95
    :catchall_0
    move-exception v0

    .line 96
    :try_start_6
    monitor-exit v5

    .line 97
    goto :goto_1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 98
    :catchall_1
    move-exception v0

    .line 99
    :try_start_7
    monitor-exit v5
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 100
    :goto_1
    :try_start_8
    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 101
    :catchall_2
    move-exception v1

    .line 102
    :try_start_9
    throw v1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 103
    :catchall_3
    move-exception v0

    .line 104
    invoke-static {v3, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    throw v0
.end method
