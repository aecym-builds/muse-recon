.class public final Lcom/facebook/animated/gif/GifImageDecoder;
.super LX/HV5;
.source ""

# interfaces
.implements LX/HTC;


# direct methods
.method public constructor <init>(LX/HV8;ZZZ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1, p3, p2, p4}, LX/HV5;-><init>(LX/HV8;ZZZ)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static A00()Ljava/io/EOFException;
    .locals 2

    .line 0
    const-string v1, "Unexpected end of gif file"

    .line 1
    .line 2
    new-instance v0, Ljava/io/EOFException;

    .line 3
    .line 4
    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method


# virtual methods
.method public final decode(LX/HRD;ILX/HSM;LX/HVU;)LX/HSy;
    .locals 22

    .line 0
    const-string v21, "Invalid image: "

    .line 1
    .line 2
    const-string v20, "Image validation failed: "

    .line 3
    .line 4
    const/4 v8, 0x0

    .line 5
    move-object/from16 v13, p1

    .line 6
    .line 7
    invoke-static {v13, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    move-object/from16 v9, p4

    .line 12
    .line 13
    invoke-static {v9, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    iget-object v0, v13, LX/HRD;->A0C:LX/HT2;

    .line 17
    .line 18
    invoke-static {v0}, LX/EYu;->A0Q(LX/HT2;)LX/HT2;

    .line 19
    .line 20
    .line 21
    move-result-object v19

    .line 22
    invoke-static/range {v19 .. v19}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :try_start_0
    const-string v18, "GIF too large: "

    .line 26
    .line 27
    const-string v17, "GIF invalid logical screen size: "

    .line 28
    .line 29
    invoke-virtual {v13}, LX/HRD;->A06()Ljava/io/InputStream;

    .line 30
    .line 31
    .line 32
    move-result-object v7

    .line 33
    if-nez v7, :cond_0

    .line 34
    .line 35
    const-string v0, "No input stream available"

    .line 36
    .line 37
    new-instance v1, LX/HTo;

    .line 38
    .line 39
    invoke-direct {v1, v8, v0}, LX/HTm;-><init>(ZLjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    :goto_0
    iget-boolean v0, v1, LX/HTm;->A01:Z

    .line 43
    .line 44
    if-eqz v0, :cond_28

    .line 45
    .line 46
    invoke-virtual/range {v19 .. v19}, LX/HT2;->A04()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    move-object v1, v4

    .line 51
    check-cast v1, LX/HR9;

    .line 52
    .line 53
    monitor-enter v4

    .line 54
    goto/16 :goto_a
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    .line 55
    .line 56
    :cond_0
    :try_start_1
    const/16 v0, 0x100

    .line 57
    .line 58
    new-array v6, v0, [B

    .line 59
    .line 60
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 61
    .line 62
    .line 63
    move-result-object v12

    .line 64
    const/4 v14, 0x0

    .line 65
    const/4 v0, 0x6

    .line 66
    invoke-virtual {v7, v6, v8, v0}, Ljava/io/InputStream;->read([BII)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    const/4 v0, -0x1

    .line 71
    if-eq v1, v0, :cond_25

    .line 72
    .line 73
    aget-byte v0, v6, v8

    .line 74
    .line 75
    int-to-char v1, v0

    .line 76
    const/16 v0, 0x47

    .line 77
    .line 78
    if-ne v0, v1, :cond_24

    .line 79
    .line 80
    const/4 v5, 0x1

    .line 81
    aget-byte v0, v6, v5

    .line 82
    .line 83
    int-to-char v1, v0

    .line 84
    const/16 v0, 0x49

    .line 85
    .line 86
    if-ne v0, v1, :cond_24

    .line 87
    .line 88
    const/4 v4, 0x2

    .line 89
    aget-byte v0, v6, v4

    .line 90
    .line 91
    int-to-char v1, v0

    .line 92
    const/16 v0, 0x46

    .line 93
    .line 94
    if-ne v0, v1, :cond_24

    .line 95
    .line 96
    aget-byte v0, v6, v2

    .line 97
    .line 98
    int-to-char v1, v0

    .line 99
    const/16 v0, 0x38

    .line 100
    .line 101
    if-ne v0, v1, :cond_24

    .line 102
    .line 103
    const/4 v0, 0x4

    .line 104
    aget-byte v0, v6, v0

    .line 105
    .line 106
    int-to-char v1, v0

    .line 107
    const/16 v0, 0x37

    .line 108
    .line 109
    if-eq v0, v1, :cond_1

    .line 110
    .line 111
    const/16 v0, 0x39

    .line 112
    .line 113
    if-ne v0, v1, :cond_24

    .line 114
    .line 115
    :cond_1
    const/4 v0, 0x5

    .line 116
    aget-byte v0, v6, v0

    .line 117
    .line 118
    int-to-char v1, v0

    .line 119
    const/16 v0, 0x61

    .line 120
    .line 121
    if-ne v0, v1, :cond_24

    .line 122
    .line 123
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 124
    .line 125
    .line 126
    move-result v3

    .line 127
    const/4 v11, -0x1

    .line 128
    if-eq v3, v11, :cond_23

    .line 129
    .line 130
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-eq v0, v11, :cond_22

    .line 135
    .line 136
    shl-int/lit8 v0, v0, 0x8

    .line 137
    .line 138
    or-int/2addr v3, v0

    .line 139
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    if-eq v2, v11, :cond_21

    .line 144
    .line 145
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    if-eq v0, v11, :cond_20

    .line 150
    .line 151
    shl-int/lit8 v0, v0, 0x8

    .line 152
    .line 153
    or-int/2addr v2, v0

    .line 154
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    if-eq v1, v11, :cond_1f

    .line 159
    .line 160
    and-int/lit16 v0, v1, 0x80

    .line 161
    .line 162
    if-eqz v0, :cond_2

    .line 163
    .line 164
    const/4 v14, 0x1

    .line 165
    :cond_2
    and-int/lit8 v0, v1, 0x7

    .line 166
    .line 167
    shl-int v10, v4, v0

    .line 168
    .line 169
    const-wide/16 v0, 0x2

    .line 170
    .line 171
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 172
    .line 173
    .line 174
    if-eqz v14, :cond_3

    .line 175
    .line 176
    mul-int/lit8 v0, v10, 0x3

    .line 177
    .line 178
    int-to-long v0, v0

    .line 179
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 180
    .line 181
    .line 182
    :cond_3
    filled-new-array {v8, v8}, [I

    .line 183
    .line 184
    .line 185
    move-result-object v10

    .line 186
    :cond_4
    :goto_1
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 187
    .line 188
    .line 189
    move-result v1

    .line 190
    if-eq v1, v11, :cond_1e

    .line 191
    .line 192
    const/16 v0, 0x21

    .line 193
    .line 194
    if-eq v1, v0, :cond_8

    .line 195
    .line 196
    const/16 v0, 0x2c

    .line 197
    .line 198
    if-eq v1, v0, :cond_5

    .line 199
    .line 200
    const/16 v0, 0x3b

    .line 201
    .line 202
    if-ne v1, v0, :cond_26

    .line 203
    .line 204
    goto/16 :goto_7

    .line 205
    .line 206
    :cond_5
    invoke-static {v10, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-virtual {v12, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    const-wide/16 v0, 0x8

    .line 214
    .line 215
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 216
    .line 217
    .line 218
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-eq v1, v11, :cond_13

    .line 223
    .line 224
    and-int/lit16 v0, v1, 0x80

    .line 225
    .line 226
    if-eqz v0, :cond_6

    .line 227
    .line 228
    and-int/lit8 v0, v1, 0x7

    .line 229
    .line 230
    shl-int v0, v4, v0

    .line 231
    .line 232
    mul-int/lit8 v0, v0, 0x3

    .line 233
    .line 234
    int-to-long v0, v0

    .line 235
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 236
    .line 237
    .line 238
    :cond_6
    const-wide/16 v0, 0x1

    .line 239
    .line 240
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 241
    .line 242
    .line 243
    :cond_7
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 244
    .line 245
    .line 246
    move-result v14

    .line 247
    if-eq v14, v11, :cond_12

    .line 248
    .line 249
    const/4 v1, 0x0

    .line 250
    if-lez v14, :cond_4

    .line 251
    .line 252
    :goto_2
    sub-int v0, v14, v1

    .line 253
    .line 254
    invoke-virtual {v7, v6, v1, v0}, Ljava/io/InputStream;->read([BII)I

    .line 255
    .line 256
    .line 257
    move-result v0

    .line 258
    if-eq v0, v11, :cond_11

    .line 259
    .line 260
    add-int/2addr v1, v0

    .line 261
    if-ge v1, v14, :cond_7

    .line 262
    .line 263
    goto :goto_2

    .line 264
    :cond_8
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 265
    .line 266
    .line 267
    move-result v1

    .line 268
    if-eq v1, v11, :cond_1d

    .line 269
    .line 270
    if-eq v1, v5, :cond_d

    .line 271
    .line 272
    const/16 v0, 0xf9

    .line 273
    .line 274
    if-eq v1, v0, :cond_b

    .line 275
    .line 276
    const/16 v0, 0xff

    .line 277
    .line 278
    if-ne v1, v0, :cond_e

    .line 279
    .line 280
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 281
    .line 282
    .line 283
    move-result v11

    .line 284
    const/4 v15, -0x1

    .line 285
    if-eq v11, v15, :cond_17

    .line 286
    .line 287
    const/4 v1, 0x0

    .line 288
    if-lez v11, :cond_9

    .line 289
    .line 290
    :goto_3
    sub-int v0, v11, v1

    .line 291
    .line 292
    invoke-virtual {v7, v6, v1, v0}, Ljava/io/InputStream;->read([BII)I

    .line 293
    .line 294
    .line 295
    move-result v0

    .line 296
    if-eq v0, v15, :cond_14

    .line 297
    .line 298
    add-int/2addr v1, v0

    .line 299
    if-ge v1, v11, :cond_9

    .line 300
    .line 301
    goto :goto_3

    .line 302
    :cond_9
    sget-object v16, LX/HTn;->A00:[C

    .line 303
    .line 304
    const/16 v14, 0xb

    .line 305
    .line 306
    const/4 v11, 0x0

    .line 307
    :goto_4
    aget-char v1, v16, v11

    .line 308
    .line 309
    aget-byte v0, v6, v11

    .line 310
    .line 311
    int-to-char v0, v0

    .line 312
    if-ne v1, v0, :cond_e

    .line 313
    .line 314
    add-int/lit8 v11, v11, 0x1

    .line 315
    .line 316
    if-ge v11, v14, :cond_a

    .line 317
    .line 318
    goto :goto_4

    .line 319
    :cond_a
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 320
    .line 321
    .line 322
    move-result v14

    .line 323
    const/4 v11, -0x1

    .line 324
    if-eq v14, v15, :cond_16

    .line 325
    .line 326
    const/4 v1, 0x0

    .line 327
    if-lez v14, :cond_4

    .line 328
    .line 329
    :goto_5
    sub-int v0, v14, v1

    .line 330
    .line 331
    invoke-virtual {v7, v6, v1, v0}, Ljava/io/InputStream;->read([BII)I

    .line 332
    .line 333
    .line 334
    move-result v0

    .line 335
    if-eq v0, v15, :cond_15

    .line 336
    .line 337
    add-int/2addr v1, v0

    .line 338
    if-ge v1, v14, :cond_a

    .line 339
    .line 340
    goto :goto_5

    .line 341
    :cond_b
    const-wide/16 v0, 0x1

    .line 342
    .line 343
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 344
    .line 345
    .line 346
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 347
    .line 348
    .line 349
    move-result v0

    .line 350
    if-eq v0, v11, :cond_1a

    .line 351
    .line 352
    and-int/lit8 v0, v0, 0x1c

    .line 353
    .line 354
    shr-int/2addr v0, v4

    .line 355
    aput v0, v10, v8

    .line 356
    .line 357
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 358
    .line 359
    .line 360
    move-result v1

    .line 361
    if-eq v1, v11, :cond_19

    .line 362
    .line 363
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 364
    .line 365
    .line 366
    move-result v0

    .line 367
    if-eq v0, v11, :cond_18

    .line 368
    .line 369
    shl-int/lit8 v0, v0, 0x8

    .line 370
    .line 371
    or-int/2addr v1, v0

    .line 372
    mul-int/lit8 v0, v1, 0xa

    .line 373
    .line 374
    aput v0, v10, v5

    .line 375
    .line 376
    if-nez v0, :cond_c

    .line 377
    .line 378
    const/16 v0, 0x64

    .line 379
    .line 380
    aput v0, v10, v5

    .line 381
    .line 382
    :cond_c
    const-wide/16 v0, 0x2

    .line 383
    .line 384
    invoke-virtual {v7, v0, v1}, Ljava/io/InputStream;->skip(J)J

    .line 385
    .line 386
    .line 387
    goto/16 :goto_1

    .line 388
    .line 389
    :cond_d
    invoke-static {v10, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 390
    .line 391
    .line 392
    move-result-object v0

    .line 393
    invoke-virtual {v12, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 394
    .line 395
    .line 396
    :cond_e
    invoke-virtual {v7}, Ljava/io/InputStream;->read()I

    .line 397
    .line 398
    .line 399
    move-result v14

    .line 400
    const/4 v11, -0x1

    .line 401
    if-eq v14, v11, :cond_1c

    .line 402
    .line 403
    const/4 v1, 0x0

    .line 404
    if-lez v14, :cond_4

    .line 405
    .line 406
    :goto_6
    sub-int v0, v14, v1

    .line 407
    .line 408
    invoke-virtual {v7, v6, v1, v0}, Ljava/io/InputStream;->read([BII)I

    .line 409
    .line 410
    .line 411
    move-result v0

    .line 412
    if-eq v0, v11, :cond_1b

    .line 413
    .line 414
    add-int/2addr v1, v0

    .line 415
    if-ge v1, v14, :cond_e

    .line 416
    .line 417
    goto :goto_6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 418
    :goto_7
    :try_start_2
    const-string v10, " x "

    .line 419
    .line 420
    if-lez v3, :cond_10

    .line 421
    .line 422
    if-lez v2, :cond_10
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    .line 423
    .line 424
    :try_start_3
    mul-int v11, v3, v2

    .line 425
    .line 426
    invoke-virtual {v12}, Ljava/util/AbstractCollection;->size()I

    .line 427
    .line 428
    .line 429
    move-result v0

    .line 430
    mul-int/2addr v11, v0

    .line 431
    const v0, 0x5f5e100

    .line 432
    .line 433
    .line 434
    if-le v11, v0, :cond_f

    .line 435
    .line 436
    invoke-virtual {v12}, Ljava/util/AbstractCollection;->size()I

    .line 437
    .line 438
    .line 439
    move-result v6

    .line 440
    const-string v5, " frames = "

    .line 441
    .line 442
    const-string v4, " pixels"

    .line 443
    .line 444
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 445
    .line 446
    .line 447
    move-result-object v1

    .line 448
    move-object/from16 v0, v18

    .line 449
    .line 450
    invoke-static {v0, v10, v1, v3, v2}, LX/004;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;II)V

    .line 451
    .line 452
    .line 453
    invoke-static {v10, v5, v1, v6, v11}, LX/004;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;II)V

    .line 454
    .line 455
    .line 456
    invoke-static {v4, v1}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 457
    .line 458
    .line 459
    move-result-object v0

    .line 460
    new-instance v1, LX/HTo;

    .line 461
    .line 462
    invoke-direct {v1, v8, v0}, LX/HTm;-><init>(ZLjava/lang/String;)V

    .line 463
    .line 464
    .line 465
    goto :goto_8
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 466
    :cond_f
    :try_start_4
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V

    .line 467
    .line 468
    .line 469
    sget-object v1, LX/HTl;->A00:LX/HTl;

    .line 470
    .line 471
    goto/16 :goto_0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 472
    .line 473
    :cond_10
    :try_start_5
    move-object/from16 v0, v17

    .line 474
    .line 475
    invoke-static {v0, v10, v3, v2}, LX/Gi8;->A0l(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 476
    .line 477
    .line 478
    move-result-object v0

    .line 479
    new-instance v1, LX/HTo;

    .line 480
    .line 481
    invoke-direct {v1, v8, v0}, LX/HTm;-><init>(ZLjava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 482
    .line 483
    .line 484
    :goto_8
    :try_start_6
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V

    .line 485
    .line 486
    .line 487
    goto/16 :goto_0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 488
    .line 489
    :cond_11
    :try_start_7
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 490
    .line 491
    .line 492
    move-result-object v0

    .line 493
    goto :goto_9

    .line 494
    :cond_12
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 495
    .line 496
    .line 497
    move-result-object v0

    .line 498
    goto :goto_9

    .line 499
    :cond_13
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    goto :goto_9

    .line 504
    :cond_14
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 505
    .line 506
    .line 507
    move-result-object v0

    .line 508
    goto :goto_9

    .line 509
    :cond_15
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 510
    .line 511
    .line 512
    move-result-object v0

    .line 513
    goto :goto_9

    .line 514
    :cond_16
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 515
    .line 516
    .line 517
    move-result-object v0

    .line 518
    goto :goto_9

    .line 519
    :cond_17
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 520
    .line 521
    .line 522
    move-result-object v0

    .line 523
    goto :goto_9

    .line 524
    :cond_18
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    goto :goto_9

    .line 529
    :cond_19
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 530
    .line 531
    .line 532
    move-result-object v0

    .line 533
    goto :goto_9

    .line 534
    :cond_1a
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 535
    .line 536
    .line 537
    move-result-object v0

    .line 538
    goto :goto_9

    .line 539
    :cond_1b
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 540
    .line 541
    .line 542
    move-result-object v0

    .line 543
    goto :goto_9

    .line 544
    :cond_1c
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 545
    .line 546
    .line 547
    move-result-object v0

    .line 548
    goto :goto_9

    .line 549
    :cond_1d
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 550
    .line 551
    .line 552
    move-result-object v0

    .line 553
    goto :goto_9

    .line 554
    :cond_1e
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 555
    .line 556
    .line 557
    move-result-object v0

    .line 558
    goto :goto_9

    .line 559
    :cond_1f
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 560
    .line 561
    .line 562
    move-result-object v0

    .line 563
    goto :goto_9

    .line 564
    :cond_20
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 565
    .line 566
    .line 567
    move-result-object v0

    .line 568
    goto :goto_9

    .line 569
    :cond_21
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 570
    .line 571
    .line 572
    move-result-object v0

    .line 573
    goto :goto_9

    .line 574
    :cond_22
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 575
    .line 576
    .line 577
    move-result-object v0

    .line 578
    goto :goto_9

    .line 579
    :cond_23
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 580
    .line 581
    .line 582
    move-result-object v0

    .line 583
    goto :goto_9

    .line 584
    :cond_24
    const-string v0, "Illegal header for gif"

    .line 585
    .line 586
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 587
    .line 588
    .line 589
    move-result-object v0

    .line 590
    goto :goto_9

    .line 591
    :cond_25
    invoke-static {}, Lcom/facebook/animated/gif/GifImageDecoder;->A00()Ljava/io/EOFException;

    .line 592
    .line 593
    .line 594
    move-result-object v0

    .line 595
    goto :goto_9

    .line 596
    :cond_26
    const-string v2, "Unknown block header ["

    .line 597
    .line 598
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v1

    .line 602
    const-string v0, "]"

    .line 603
    .line 604
    invoke-static {v2, v1, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 605
    .line 606
    .line 607
    move-result-object v0

    .line 608
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 609
    .line 610
    .line 611
    move-result-object v0

    .line 612
    :goto_9
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 613
    :catchall_0
    move-exception v1

    .line 614
    :try_start_8
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    .line 615
    :catchall_1
    move-exception v0

    .line 616
    :try_start_9
    invoke-static {v7, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 617
    .line 618
    .line 619
    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 620
    :catch_0
    :try_start_a
    move-exception v0

    .line 621
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 622
    .line 623
    .line 624
    move-result-object v1

    .line 625
    const-string v0, "Error parsing GIF: "

    .line 626
    .line 627
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 628
    .line 629
    .line 630
    move-result-object v0

    .line 631
    new-instance v1, LX/HTo;

    .line 632
    .line 633
    invoke-direct {v1, v8, v0}, LX/HTm;-><init>(ZLjava/lang/String;)V

    .line 634
    .line 635
    .line 636
    goto/16 :goto_0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    .line 637
    .line 638
    :goto_a
    :try_start_b
    invoke-static {v1}, LX/HR9;->A00(LX/HR9;)LX/HHX;

    .line 639
    .line 640
    .line 641
    move-result-object v0

    .line 642
    invoke-interface {v0}, LX/HHX;->getByteBuffer()Ljava/nio/ByteBuffer;

    .line 643
    .line 644
    .line 645
    move-result-object v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    .line 646
    :try_start_c
    monitor-exit v4

    .line 647
    if-eqz v2, :cond_27

    .line 648
    .line 649
    invoke-static {}, Lcom/facebook/animated/gif/GifImage;->ensure()V

    .line 650
    .line 651
    .line 652
    invoke-virtual {v2}, Ljava/nio/Buffer;->rewind()Ljava/nio/Buffer;

    .line 653
    .line 654
    .line 655
    const v1, 0x7fffffff

    .line 656
    .line 657
    .line 658
    iget-boolean v0, v9, LX/HVU;->A03:Z

    .line 659
    .line 660
    invoke-static {v2, v1, v0}, Lcom/facebook/animated/gif/GifImage;->nativeCreateFromDirectByteBuffer(Ljava/nio/ByteBuffer;IZ)Lcom/facebook/animated/gif/GifImage;

    .line 661
    .line 662
    .line 663
    move-result-object v2

    .line 664
    iget-object v1, v9, LX/HVU;->A00:Landroid/graphics/Bitmap$Config;

    .line 665
    .line 666
    iput-object v1, v2, Lcom/facebook/animated/gif/GifImage;->mDecodeBitmapConfig:Landroid/graphics/Bitmap$Config;

    .line 667
    .line 668
    goto :goto_b

    .line 669
    :cond_27
    monitor-enter v4
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 670
    :try_start_d
    invoke-static {v1}, LX/HR9;->A01(LX/HR9;)V

    .line 671
    .line 672
    .line 673
    invoke-static {v1}, LX/HR9;->A00(LX/HR9;)LX/HHX;

    .line 674
    .line 675
    .line 676
    move-result-object v0

    .line 677
    invoke-interface {v0}, LX/HHX;->getNativePtr()J

    .line 678
    .line 679
    .line 680
    move-result-wide v2
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    .line 681
    :try_start_e
    monitor-exit v4

    .line 682
    invoke-virtual {v1}, LX/HR9;->A03()I

    .line 683
    .line 684
    .line 685
    move-result v6

    .line 686
    invoke-static {}, Lcom/facebook/animated/gif/GifImage;->ensure()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_4

    .line 687
    .line 688
    .line 689
    const-wide/16 v4, 0x0

    .line 690
    .line 691
    cmp-long v0, v2, v4

    .line 692
    .line 693
    invoke-static {v0}, LX/003;->A1B(I)Z

    .line 694
    .line 695
    .line 696
    move-result v0

    .line 697
    :try_start_f
    invoke-static {v0}, LX/H2H;->A02(Z)V

    .line 698
    .line 699
    .line 700
    const v1, 0x7fffffff

    .line 701
    .line 702
    .line 703
    iget-boolean v0, v9, LX/HVU;->A03:Z

    .line 704
    .line 705
    invoke-static {v2, v3, v6, v1, v0}, Lcom/facebook/animated/gif/GifImage;->nativeCreateFromNativeMemory(JIIZ)Lcom/facebook/animated/gif/GifImage;

    .line 706
    .line 707
    .line 708
    move-result-object v2

    .line 709
    iget-object v1, v9, LX/HVU;->A00:Landroid/graphics/Bitmap$Config;

    .line 710
    .line 711
    iput-object v1, v2, Lcom/facebook/animated/gif/GifImage;->mDecodeBitmapConfig:Landroid/graphics/Bitmap$Config;

    .line 712
    .line 713
    :goto_b
    iget-object v0, v13, LX/HRD;->A09:Ljava/lang/String;

    .line 714
    .line 715
    move-object/from16 v3, p0

    .line 716
    .line 717
    invoke-virtual {v3, v1, v2, v9, v0}, LX/HV5;->A01(Landroid/graphics/Bitmap$Config;LX/HWm;LX/HVU;Ljava/lang/String;)LX/HSX;

    .line 718
    .line 719
    .line 720
    move-result-object v0
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    .line 721
    invoke-virtual/range {v19 .. v19}, LX/HT2;->close()V

    .line 722
    .line 723
    .line 724
    return-object v0

    .line 725
    :catchall_2
    move-exception v0

    .line 726
    :try_start_10
    monitor-exit v4

    .line 727
    goto :goto_c
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_2

    .line 728
    :catchall_3
    move-exception v0

    .line 729
    :try_start_11
    monitor-exit v4

    .line 730
    goto :goto_c
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_3

    .line 731
    :cond_28
    :try_start_12
    const-string v2, "GifImageDecoder"

    .line 732
    .line 733
    iget-object v1, v1, LX/HTm;->A00:Ljava/lang/String;

    .line 734
    .line 735
    move-object/from16 v0, v20

    .line 736
    .line 737
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 738
    .line 739
    .line 740
    move-result-object v0

    .line 741
    invoke-static {v2, v0}, LX/H2K;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 742
    .line 743
    .line 744
    move-object/from16 v0, v21

    .line 745
    .line 746
    invoke-static {v0, v1}, LX/Gi8;->A1C(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 747
    .line 748
    .line 749
    move-result-object v0

    .line 750
    :goto_c
    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_4

    .line 751
    :catchall_4
    move-exception v2

    .line 752
    :try_start_13
    throw v2
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_5

    .line 753
    :catchall_5
    move-exception v1

    .line 754
    move-object/from16 v0, v19

    .line 755
    .line 756
    invoke-static {v0, v2}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 757
    .line 758
    .line 759
    throw v1
.end method
