.class public abstract synthetic Lcom/facebook/acra/util/JavaProcFileReader-IA;
.super Ljava/lang/Object;
.source ""
