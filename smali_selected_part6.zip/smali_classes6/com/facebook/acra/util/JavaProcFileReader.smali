.class public Lcom/facebook/acra/util/JavaProcFileReader;
.super Lcom/facebook/acra/util/ProcFileReader;
.source ""


# static fields
.field public static final FD_DIR:Ljava/lang/String;

.field public static final FD_DIR_STRING:Ljava/lang/String; = "/fd/"

.field public static final LS_SYMLINK_ARROW:Ljava/lang/String; = " -> "

.field public static final PIPE_STRING:Ljava/lang/String; = "pipe"

.field public static final PROC_LINE_BUFFER:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "[B>;"
        }
    .end annotation
.end field

.field public static final PROC_LINE_READ_LIMIT:I = 0x80

.field public static final PROC_MEMINFO_READ_LIMIT:I = 0x1000

.field public static final PROC_OPEN_FD_LIMITS_FORMAT:[I

.field public static final PROC_SCHED_BUFFER:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "[B>;"
        }
    .end annotation
.end field

.field public static final PROC_SCHED_READ_LIMIT:I = 0x4000

.field public static final PROC_STAT_BUFFER:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "[B>;"
        }
    .end annotation
.end field

.field public static final PROC_STAT_READ_LIMIT:I = 0x200

.field public static final SOCKET_STRING:Ljava/lang/String; = "socket"

.field public static final TAG:Ljava/lang/String; = "JavaProcFileReader"

.field public static sInstance:Lcom/facebook/acra/util/JavaProcFileReader;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/acra/util/JavaProcFileReader$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/acra/util/JavaProcFileReader$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_LINE_BUFFER:Ljava/lang/ThreadLocal;

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/acra/util/JavaProcFileReader$2;

    .line 8
    .line 9
    invoke-direct {v0}, Lcom/facebook/acra/util/JavaProcFileReader$2;-><init>()V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_STAT_BUFFER:Ljava/lang/ThreadLocal;

    .line 13
    .line 14
    new-instance v0, Lcom/facebook/acra/util/JavaProcFileReader$3;

    .line 15
    .line 16
    invoke-direct {v0}, Lcom/facebook/acra/util/JavaProcFileReader$3;-><init>()V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_SCHED_BUFFER:Ljava/lang/ThreadLocal;

    .line 20
    .line 21
    const-string v2, "/proc/"

    .line 22
    .line 23
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    const-string v0, "/fd"

    .line 28
    .line 29
    invoke-static {v2, v1, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->FD_DIR:Ljava/lang/String;

    .line 34
    .line 35
    const/4 v0, 0x6

    .line 36
    new-array v0, v0, [I

    .line 37
    .line 38
    fill-array-data v0, :array_0

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_OPEN_FD_LIMITS_FORMAT:[I

    .line 42
    .line 43
    return-void

    :array_0
    .array-data 4
        0x20
        0x20
        0x120
        0x1120
        0x1120
        0x120
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static equalsAscii([BIILjava/lang/String;)Z
    .locals 5

    .line 0
    sub-int/2addr p2, p1

    .line 1
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v4

    .line 5
    const/4 v3, 0x0

    .line 6
    if-ne p2, v4, :cond_1

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_0
    if-ge v2, v4, :cond_0

    .line 10
    .line 11
    add-int v0, p1, v2

    .line 12
    .line 13
    aget-byte v1, p0, v0

    .line 14
    .line 15
    invoke-virtual {p3, v2}, Ljava/lang/String;->charAt(I)C

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-ne v1, v0, :cond_1

    .line 20
    .line 21
    add-int/lit8 v2, v2, 0x1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v3, 0x1

    .line 25
    :cond_1
    return v3
.end method

.method public static findNewLineOrEnd([BI)I
    .locals 3

    .line 0
    array-length v2, p0

    .line 1
    if-lt p1, v2, :cond_1

    .line 2
    .line 3
    const/4 p1, -0x1

    .line 4
    :cond_0
    return p1

    .line 5
    :cond_1
    :goto_0
    add-int/lit8 v0, v2, -0x1

    .line 6
    .line 7
    if-ge p1, v0, :cond_0

    .line 8
    .line 9
    aget-byte v1, p0, p1

    .line 10
    .line 11
    const/16 v0, 0xa

    .line 12
    .line 13
    if-eq v1, v0, :cond_0

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    add-int/lit8 p1, p1, 0x1

    .line 18
    .line 19
    goto :goto_0
.end method

.method public static declared-synchronized getInstance()Lcom/facebook/acra/util/JavaProcFileReader;
    .locals 2

    .line 0
    const-class v1, Lcom/facebook/acra/util/JavaProcFileReader;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->sInstance:Lcom/facebook/acra/util/JavaProcFileReader;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/acra/util/JavaProcFileReader;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->sInstance:Lcom/facebook/acra/util/JavaProcFileReader;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    .line 14
    :cond_0
    monitor-exit v1

    .line 15
    return-object v0

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    throw v0
.end method

.method public static matchesKey([BIILjava/lang/String;)Z
    .locals 8

    .line 0
    sub-int v7, p2, p1

    .line 1
    .line 2
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result v6

    .line 6
    sub-int/2addr p2, v6

    .line 7
    const/4 v5, 0x0

    .line 8
    if-lt p2, p1, :cond_2

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    :goto_0
    if-ge v2, v6, :cond_0

    .line 12
    .line 13
    add-int v0, p2, v2

    .line 14
    .line 15
    aget-byte v1, p0, v0

    .line 16
    .line 17
    invoke-virtual {p3, v2}, Ljava/lang/String;->charAt(I)C

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-ne v1, v0, :cond_2

    .line 22
    .line 23
    add-int/lit8 v2, v2, 0x1

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v4, 0x1

    .line 27
    if-eq v7, v6, :cond_1

    .line 28
    .line 29
    const/16 v3, 0xe

    .line 30
    .line 31
    add-int/lit8 v0, v6, 0xe

    .line 32
    .line 33
    if-ne v7, v0, :cond_2

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    :goto_1
    add-int v0, p1, v2

    .line 37
    .line 38
    aget-byte v1, p0, v0

    .line 39
    .line 40
    const-string/jumbo v0, "se.statistics."

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-ne v1, v0, :cond_2

    .line 48
    .line 49
    add-int/lit8 v2, v2, 0x1

    .line 50
    .line 51
    if-ge v2, v3, :cond_1

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_1
    return v4

    .line 55
    :cond_2
    return v5
.end method

.method public static meminfoField([BII)I
    .locals 1

    .line 0
    const-string v0, "MemFree"

    .line 1
    .line 2
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    :cond_0
    return p0

    .line 10
    :cond_1
    const-string v0, "Active(file)"

    .line 11
    .line 12
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    const/4 p0, 0x1

    .line 19
    return p0

    .line 20
    :cond_2
    const-string v0, "Inactive(file)"

    .line 21
    .line 22
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    const/4 p0, 0x2

    .line 29
    return p0

    .line 30
    :cond_3
    const-string v0, "Dirty"

    .line 31
    .line 32
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_4

    .line 37
    .line 38
    const/4 p0, 0x3

    .line 39
    return p0

    .line 40
    :cond_4
    const-string v0, "Writeback"

    .line 41
    .line 42
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    const/4 p0, -0x1

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    const/4 p0, 0x4

    .line 50
    return p0
.end method

.method public static parseDecimalMilliseconds([BII)J
    .locals 19

    .line 0
    move/from16 v6, p1

    .line 1
    .line 2
    :goto_0
    const/16 v4, 0x9

    .line 3
    .line 4
    const/16 v3, 0x20

    .line 5
    .line 6
    move/from16 v5, p2

    .line 7
    .line 8
    if-ge v6, v5, :cond_1

    .line 9
    .line 10
    aget-byte v0, p0, v6

    .line 11
    .line 12
    if-eq v0, v3, :cond_0

    .line 13
    .line 14
    if-ne v0, v4, :cond_1

    .line 15
    .line 16
    :cond_0
    add-int/lit8 v6, v6, 0x1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    const-wide/16 v17, -0x1

    .line 20
    .line 21
    if-eq v6, v5, :cond_9

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    const-wide/16 v15, 0x0

    .line 25
    .line 26
    const-wide/16 v13, 0x0

    .line 27
    .line 28
    const/4 v12, 0x0

    .line 29
    :goto_1
    const/16 v9, 0x39

    .line 30
    .line 31
    const-wide/16 v10, 0xa

    .line 32
    .line 33
    const/16 v8, 0x30

    .line 34
    .line 35
    if-ge v6, v5, :cond_2

    .line 36
    .line 37
    aget-byte v0, p0, v6

    .line 38
    .line 39
    if-lt v0, v8, :cond_2

    .line 40
    .line 41
    if-gt v0, v9, :cond_2

    .line 42
    .line 43
    add-int/lit8 v6, v6, 0x1

    .line 44
    .line 45
    add-int/lit8 v0, v0, -0x30

    .line 46
    .line 47
    int-to-long v0, v0

    .line 48
    const-wide v8, 0x8637bd05af6L

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    sub-long/2addr v8, v0

    .line 54
    div-long/2addr v8, v10

    .line 55
    cmp-long v7, v13, v8

    .line 56
    .line 57
    if-gtz v7, :cond_9

    .line 58
    .line 59
    mul-long/2addr v13, v10

    .line 60
    add-long/2addr v13, v0

    .line 61
    add-int/lit8 v12, v12, 0x1

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    if-eqz v12, :cond_9

    .line 65
    .line 66
    const/4 v7, 0x6

    .line 67
    if-ge v6, v5, :cond_4

    .line 68
    .line 69
    aget-byte v1, p0, v6

    .line 70
    .line 71
    const/16 v0, 0x2e

    .line 72
    .line 73
    if-ne v1, v0, :cond_4

    .line 74
    .line 75
    add-int/lit8 v6, v6, 0x1

    .line 76
    .line 77
    :goto_2
    if-ge v6, v5, :cond_3

    .line 78
    .line 79
    aget-byte v0, p0, v6

    .line 80
    .line 81
    if-lt v0, v8, :cond_3

    .line 82
    .line 83
    if-gt v0, v9, :cond_3

    .line 84
    .line 85
    if-eq v2, v7, :cond_9

    .line 86
    .line 87
    mul-long/2addr v15, v10

    .line 88
    add-int/lit8 v6, v6, 0x1

    .line 89
    .line 90
    add-int/lit8 v0, v0, -0x30

    .line 91
    .line 92
    int-to-long v0, v0

    .line 93
    add-long/2addr v15, v0

    .line 94
    add-int/lit8 v2, v2, 0x1

    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_3
    if-nez v2, :cond_4

    .line 98
    .line 99
    return-wide v17

    .line 100
    :cond_4
    :goto_3
    if-ge v6, v5, :cond_6

    .line 101
    .line 102
    aget-byte v1, p0, v6

    .line 103
    .line 104
    if-eq v1, v3, :cond_5

    .line 105
    .line 106
    if-eq v1, v4, :cond_5

    .line 107
    .line 108
    const/16 v0, 0xd

    .line 109
    .line 110
    if-ne v1, v0, :cond_6

    .line 111
    .line 112
    :cond_5
    add-int/lit8 v6, v6, 0x1

    .line 113
    .line 114
    goto :goto_3

    .line 115
    :cond_6
    if-eq v6, v5, :cond_7

    .line 116
    .line 117
    return-wide v17

    .line 118
    :cond_7
    :goto_4
    add-int/lit8 v0, v2, 0x1

    .line 119
    .line 120
    if-ge v2, v7, :cond_8

    .line 121
    .line 122
    mul-long/2addr v15, v10

    .line 123
    move v2, v0

    .line 124
    goto :goto_4

    .line 125
    :cond_8
    const-wide v3, 0x7fffffffffffffffL

    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    sub-long/2addr v3, v15

    .line 131
    const-wide/32 v1, 0xf4240

    .line 132
    .line 133
    .line 134
    div-long/2addr v3, v1

    .line 135
    cmp-long v0, v13, v3

    .line 136
    .line 137
    if-gtz v0, :cond_9

    .line 138
    .line 139
    mul-long/2addr v13, v1

    .line 140
    add-long/2addr v13, v15

    .line 141
    return-wide v13

    .line 142
    :cond_9
    return-wide v17
.end method

.method public static parseMeminfo([BI[J)I
    .locals 11

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x5

    .line 2
    if-lt v1, v0, :cond_7

    .line 3
    .line 4
    array-length v0, p0

    .line 5
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 6
    .line 7
    .line 8
    move-result v6

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v10, 0x0

    .line 11
    :goto_0
    if-ge v3, v6, :cond_6

    .line 12
    .line 13
    move v5, v3

    .line 14
    :goto_1
    if-ge v5, v6, :cond_0

    .line 15
    .line 16
    aget-byte v1, p0, v5

    .line 17
    .line 18
    const/16 v0, 0xa

    .line 19
    .line 20
    if-eq v1, v0, :cond_0

    .line 21
    .line 22
    add-int/lit8 v5, v5, 0x1

    .line 23
    .line 24
    goto :goto_1

    .line 25
    :cond_0
    move v2, v3

    .line 26
    :goto_2
    if-ge v2, v5, :cond_1

    .line 27
    .line 28
    aget-byte v1, p0, v2

    .line 29
    .line 30
    const/16 v0, 0x3a

    .line 31
    .line 32
    if-eq v1, v0, :cond_1

    .line 33
    .line 34
    add-int/lit8 v2, v2, 0x1

    .line 35
    .line 36
    goto :goto_2

    .line 37
    :cond_1
    const/4 v9, -0x1

    .line 38
    if-ge v2, v5, :cond_4

    .line 39
    .line 40
    invoke-static {p0, v3, v2}, Lcom/facebook/acra/util/JavaProcFileReader;->meminfoField([BII)I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    if-ltz v8, :cond_4

    .line 45
    .line 46
    :goto_3
    add-int/lit8 v2, v2, 0x1

    .line 47
    .line 48
    if-ge v2, v5, :cond_2

    .line 49
    .line 50
    aget-byte v1, p0, v2

    .line 51
    .line 52
    const/16 v0, 0x20

    .line 53
    .line 54
    if-ne v1, v0, :cond_2

    .line 55
    .line 56
    goto :goto_3

    .line 57
    :cond_2
    move v7, v2

    .line 58
    :goto_4
    if-ge v7, v5, :cond_3

    .line 59
    .line 60
    aget-byte v1, p0, v7

    .line 61
    .line 62
    const/16 v0, 0x30

    .line 63
    .line 64
    if-lt v1, v0, :cond_3

    .line 65
    .line 66
    const/16 v0, 0x39

    .line 67
    .line 68
    if-gt v1, v0, :cond_3

    .line 69
    .line 70
    add-int/lit8 v7, v7, 0x1

    .line 71
    .line 72
    goto :goto_4

    .line 73
    :cond_3
    invoke-static {p0, v2, v7}, Lcom/facebook/acra/util/JavaProcFileReader;->parseUnsignedDecimal([BII)J

    .line 74
    .line 75
    .line 76
    move-result-wide v3

    .line 77
    const-wide/16 v1, 0x0

    .line 78
    .line 79
    cmp-long v0, v3, v1

    .line 80
    .line 81
    if-ltz v0, :cond_5

    .line 82
    .line 83
    invoke-static {p0, v5}, Lcom/facebook/acra/util/JavaProcFileReader;->trimLineEnd([BI)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    const-string v0, " kB"

    .line 88
    .line 89
    invoke-static {p0, v7, v1, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_5

    .line 94
    .line 95
    aput-wide v3, p2, v8

    .line 96
    .line 97
    const/4 v0, 0x1

    .line 98
    shl-int/2addr v0, v8

    .line 99
    or-int/2addr v0, v10

    .line 100
    move v10, v0

    .line 101
    :cond_4
    add-int/lit8 v3, v5, 0x1

    .line 102
    .line 103
    goto :goto_0

    .line 104
    :cond_5
    return v9

    .line 105
    :cond_6
    return v10

    .line 106
    :cond_7
    const-string v0, "outKb must hold at least 5 values"

    .line 107
    .line 108
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0
.end method

.method public static parseSchedCounters([BI[J)I
    .locals 9

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x3

    .line 2
    if-lt v1, v0, :cond_5

    .line 3
    .line 4
    array-length v0, p0

    .line 5
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 6
    .line 7
    .line 8
    move-result v7

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v8, 0x0

    .line 11
    :goto_0
    if-ge v2, v7, :cond_4

    .line 12
    .line 13
    move v6, v2

    .line 14
    :goto_1
    if-ge v6, v7, :cond_0

    .line 15
    .line 16
    aget-byte v1, p0, v6

    .line 17
    .line 18
    const/16 v0, 0xa

    .line 19
    .line 20
    if-eq v1, v0, :cond_0

    .line 21
    .line 22
    add-int/lit8 v6, v6, 0x1

    .line 23
    .line 24
    goto :goto_1

    .line 25
    :cond_0
    invoke-static {p0, v2, v6}, Lcom/facebook/acra/util/JavaProcFileReader;->schedCounterField([BII)I

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    if-ltz v5, :cond_2

    .line 30
    .line 31
    :goto_2
    if-ge v2, v6, :cond_1

    .line 32
    .line 33
    aget-byte v1, p0, v2

    .line 34
    .line 35
    const/16 v0, 0x3a

    .line 36
    .line 37
    if-eq v1, v0, :cond_1

    .line 38
    .line 39
    add-int/lit8 v2, v2, 0x1

    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_1
    add-int/lit8 v0, v2, 0x1

    .line 43
    .line 44
    invoke-static {p0, v0, v6}, Lcom/facebook/acra/util/JavaProcFileReader;->parseDecimalMilliseconds([BII)J

    .line 45
    .line 46
    .line 47
    move-result-wide v3

    .line 48
    if-eq v2, v6, :cond_3

    .line 49
    .line 50
    const-wide/16 v1, 0x0

    .line 51
    .line 52
    cmp-long v0, v3, v1

    .line 53
    .line 54
    if-ltz v0, :cond_3

    .line 55
    .line 56
    aput-wide v3, p2, v5

    .line 57
    .line 58
    const/4 v0, 0x1

    .line 59
    shl-int/2addr v0, v5

    .line 60
    or-int/2addr v0, v8

    .line 61
    move v8, v0

    .line 62
    :cond_2
    add-int/lit8 v2, v6, 0x1

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    const/4 v8, -0x1

    .line 66
    :cond_4
    return v8

    .line 67
    :cond_5
    const-string v0, "outNanos must hold at least 3 values"

    .line 68
    .line 69
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    throw v0
.end method

.method public static parseSchedStat([BI[J)Z
    .locals 14

    .line 0
    array-length v0, p0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 2
    .line 3
    .line 4
    move-result v9

    .line 5
    const/4 v13, 0x0

    .line 6
    const/4 v8, 0x0

    .line 7
    const/4 v7, 0x0

    .line 8
    :cond_0
    :goto_0
    if-ge v7, v9, :cond_1

    .line 9
    .line 10
    aget-byte v1, p0, v7

    .line 11
    .line 12
    const/16 v0, 0x20

    .line 13
    .line 14
    if-ne v1, v0, :cond_1

    .line 15
    .line 16
    add-int/lit8 v7, v7, 0x1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    const-wide/16 v11, 0x0

    .line 20
    .line 21
    const/4 v10, 0x0

    .line 22
    :goto_1
    if-ge v7, v9, :cond_2

    .line 23
    .line 24
    aget-byte v1, p0, v7

    .line 25
    .line 26
    const/16 v0, 0x30

    .line 27
    .line 28
    if-lt v1, v0, :cond_2

    .line 29
    .line 30
    const/16 v0, 0x39

    .line 31
    .line 32
    if-gt v1, v0, :cond_2

    .line 33
    .line 34
    add-int/lit8 v0, v1, -0x30

    .line 35
    .line 36
    int-to-long v5, v0

    .line 37
    const-wide v3, 0x7fffffffffffffffL

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    sub-long/2addr v3, v5

    .line 43
    const-wide/16 v1, 0xa

    .line 44
    .line 45
    div-long/2addr v3, v1

    .line 46
    cmp-long v0, v11, v3

    .line 47
    .line 48
    if-gtz v0, :cond_3

    .line 49
    .line 50
    mul-long/2addr v11, v1

    .line 51
    add-long/2addr v11, v5

    .line 52
    add-int/lit8 v7, v7, 0x1

    .line 53
    .line 54
    add-int/lit8 v10, v10, 0x1

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_2
    if-eqz v10, :cond_3

    .line 58
    .line 59
    aput-wide v11, p2, v8

    .line 60
    .line 61
    add-int/lit8 v8, v8, 0x1

    .line 62
    .line 63
    const/4 v0, 0x2

    .line 64
    if-lt v8, v0, :cond_0

    .line 65
    .line 66
    const/4 v13, 0x1

    .line 67
    :cond_3
    return v13
.end method

.method public static parseThreadReadBytes([BI)J
    .locals 8

    .line 0
    array-length v0, p0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 2
    .line 3
    .line 4
    move-result v7

    .line 5
    const/4 v4, 0x0

    .line 6
    :goto_0
    const-wide/16 v5, -0x1

    .line 7
    .line 8
    if-ge v4, v7, :cond_4

    .line 9
    .line 10
    move v3, v4

    .line 11
    :goto_1
    if-ge v3, v7, :cond_0

    .line 12
    .line 13
    aget-byte v1, p0, v3

    .line 14
    .line 15
    const/16 v0, 0xa

    .line 16
    .line 17
    if-eq v1, v0, :cond_0

    .line 18
    .line 19
    add-int/lit8 v3, v3, 0x1

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_0
    move v2, v4

    .line 23
    :goto_2
    if-ge v2, v3, :cond_1

    .line 24
    .line 25
    aget-byte v1, p0, v2

    .line 26
    .line 27
    const/16 v0, 0x3a

    .line 28
    .line 29
    if-eq v1, v0, :cond_1

    .line 30
    .line 31
    add-int/lit8 v2, v2, 0x1

    .line 32
    .line 33
    goto :goto_2

    .line 34
    :cond_1
    if-ge v2, v3, :cond_2

    .line 35
    .line 36
    const-string v0, "read_bytes"

    .line 37
    .line 38
    invoke-static {p0, v4, v2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->equalsAscii([BIILjava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    :goto_3
    add-int/lit8 v2, v2, 0x1

    .line 45
    .line 46
    if-ge v2, v3, :cond_3

    .line 47
    .line 48
    aget-byte v1, p0, v2

    .line 49
    .line 50
    const/16 v0, 0x20

    .line 51
    .line 52
    if-ne v1, v0, :cond_3

    .line 53
    .line 54
    goto :goto_3

    .line 55
    :cond_2
    add-int/lit8 v4, v3, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_3
    invoke-static {p0, v2, v3}, Lcom/facebook/acra/util/JavaProcFileReader;->parseUnsignedDecimal([BII)J

    .line 59
    .line 60
    .line 61
    move-result-wide v3

    .line 62
    const-wide/16 v1, 0x0

    .line 63
    .line 64
    cmp-long v0, v3, v1

    .line 65
    .line 66
    if-ltz v0, :cond_4

    .line 67
    .line 68
    return-wide v3

    .line 69
    :cond_4
    return-wide v5
.end method

.method public static parseThreadStatFaults([BI[J)Z
    .locals 14

    .line 0
    array-length v0, p0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 2
    .line 3
    .line 4
    move-result v11

    .line 5
    add-int/lit8 v2, v11, -0x1

    .line 6
    .line 7
    :goto_0
    if-ltz v2, :cond_0

    .line 8
    .line 9
    aget-byte v1, p0, v2

    .line 10
    .line 11
    const/16 v0, 0x29

    .line 12
    .line 13
    if-eq v1, v0, :cond_1

    .line 14
    .line 15
    add-int/lit8 v2, v2, -0x1

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v2, -0x1

    .line 19
    :cond_1
    const/4 v13, 0x0

    .line 20
    if-ltz v2, :cond_7

    .line 21
    .line 22
    const/4 v12, 0x1

    .line 23
    add-int/lit8 v10, v2, 0x1

    .line 24
    .line 25
    const-wide/16 v8, -0x1

    .line 26
    .line 27
    const-wide/16 v6, -0x1

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    :goto_1
    const/16 v4, 0x9

    .line 31
    .line 32
    if-gt v5, v4, :cond_4

    .line 33
    .line 34
    :goto_2
    const/16 v3, 0x20

    .line 35
    .line 36
    if-ge v10, v11, :cond_2

    .line 37
    .line 38
    aget-byte v0, p0, v10

    .line 39
    .line 40
    if-ne v0, v3, :cond_2

    .line 41
    .line 42
    add-int/lit8 v10, v10, 0x1

    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_2
    move v2, v10

    .line 46
    :goto_3
    if-ge v2, v11, :cond_5

    .line 47
    .line 48
    aget-byte v1, p0, v2

    .line 49
    .line 50
    if-eq v1, v3, :cond_5

    .line 51
    .line 52
    const/16 v0, 0xa

    .line 53
    .line 54
    if-eq v1, v0, :cond_5

    .line 55
    .line 56
    add-int/lit8 v2, v2, 0x1

    .line 57
    .line 58
    goto :goto_3

    .line 59
    :cond_3
    if-ne v5, v4, :cond_6

    .line 60
    .line 61
    invoke-static {p0, v10, v2}, Lcom/facebook/acra/util/JavaProcFileReader;->parseUnsignedDecimal([BII)J

    .line 62
    .line 63
    .line 64
    move-result-wide v6

    .line 65
    :cond_4
    const-wide/16 v1, 0x0

    .line 66
    .line 67
    cmp-long v0, v8, v1

    .line 68
    .line 69
    if-ltz v0, :cond_7

    .line 70
    .line 71
    cmp-long v0, v6, v1

    .line 72
    .line 73
    if-ltz v0, :cond_7

    .line 74
    .line 75
    aput-wide v8, p2, v13

    .line 76
    .line 77
    aput-wide v6, p2, v12

    .line 78
    .line 79
    return v12

    .line 80
    :cond_5
    if-eq v10, v2, :cond_7

    .line 81
    .line 82
    const/4 v0, 0x7

    .line 83
    if-ne v5, v0, :cond_3

    .line 84
    .line 85
    invoke-static {p0, v10, v2}, Lcom/facebook/acra/util/JavaProcFileReader;->parseUnsignedDecimal([BII)J

    .line 86
    .line 87
    .line 88
    move-result-wide v8

    .line 89
    :cond_6
    add-int/lit8 v5, v5, 0x1

    .line 90
    .line 91
    move v10, v2

    .line 92
    goto :goto_1

    .line 93
    :cond_7
    return v13
.end method

.method public static parseThreadStateChar([BI)I
    .locals 5

    .line 0
    array-length v0, p0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 2
    .line 3
    .line 4
    move-result v4

    .line 5
    add-int/lit8 v3, v4, -0x1

    .line 6
    .line 7
    :goto_0
    if-ltz v3, :cond_1

    .line 8
    .line 9
    aget-byte v1, p0, v3

    .line 10
    .line 11
    const/16 v0, 0x29

    .line 12
    .line 13
    if-ne v1, v0, :cond_0

    .line 14
    .line 15
    add-int/lit8 v2, v3, 0x2

    .line 16
    .line 17
    if-ge v2, v4, :cond_1

    .line 18
    .line 19
    add-int/lit8 v0, v3, 0x1

    .line 20
    .line 21
    aget-byte v1, p0, v0

    .line 22
    .line 23
    const/16 v0, 0x20

    .line 24
    .line 25
    if-ne v1, v0, :cond_1

    .line 26
    .line 27
    aget-byte v0, p0, v2

    .line 28
    .line 29
    and-int/lit16 v0, v0, 0xff

    .line 30
    .line 31
    return v0

    .line 32
    :cond_0
    add-int/lit8 v3, v3, -0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const/4 v0, 0x0

    .line 36
    return v0
.end method

.method public static parseUnsignedDecimal([BII)J
    .locals 11

    .line 0
    :goto_0
    if-le p2, p1, :cond_1

    .line 1
    .line 2
    add-int/lit8 v0, p2, -0x1

    .line 3
    .line 4
    aget-byte v1, p0, v0

    .line 5
    .line 6
    const/16 v0, 0xd

    .line 7
    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    const/16 v0, 0x20

    .line 11
    .line 12
    if-ne v1, v0, :cond_1

    .line 13
    .line 14
    :cond_0
    add-int/lit8 p2, p2, -0x1

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_1
    const-wide/16 v9, -0x1

    .line 18
    .line 19
    if-ge p1, p2, :cond_3

    .line 20
    .line 21
    const-wide/16 v7, 0x0

    .line 22
    .line 23
    :goto_1
    if-ge p1, p2, :cond_2

    .line 24
    .line 25
    aget-byte v1, p0, p1

    .line 26
    .line 27
    const/16 v0, 0x30

    .line 28
    .line 29
    if-lt v1, v0, :cond_3

    .line 30
    .line 31
    const/16 v0, 0x39

    .line 32
    .line 33
    if-gt v1, v0, :cond_3

    .line 34
    .line 35
    add-int/lit8 v0, v1, -0x30

    .line 36
    .line 37
    int-to-long v3, v0

    .line 38
    const-wide v5, 0x7fffffffffffffffL

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    sub-long/2addr v5, v3

    .line 44
    const-wide/16 v1, 0xa

    .line 45
    .line 46
    div-long/2addr v5, v1

    .line 47
    cmp-long v0, v7, v5

    .line 48
    .line 49
    if-gtz v0, :cond_3

    .line 50
    .line 51
    mul-long/2addr v7, v1

    .line 52
    add-long/2addr v7, v3

    .line 53
    add-int/lit8 p1, p1, 0x1

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_2
    return-wide v7

    .line 57
    :cond_3
    return-wide v9
.end method

.method public static readProcFileHead(Ljava/lang/String;[B)I
    .locals 3

    .line 0
    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    .line 1
    .line 2
    invoke-direct {v2, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 3
    .line 4
    .line 5
    :try_start_1
    invoke-virtual {v2, p1}, Ljava/io/InputStream;->read([B)I

    .line 6
    .line 7
    .line 8
    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 9
    :try_start_2
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 10
    .line 11
    .line 12
    return v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_0

    .line 13
    :catchall_0
    move-exception v1

    .line 14
    :try_start_3
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 15
    .line 16
    .line 17
    goto :goto_0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 18
    :catchall_1
    move-exception v0

    .line 19
    :try_start_4
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 20
    .line 21
    .line 22
    :goto_0
    throw v1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_4 .. :try_end_4} :catch_0

    .line 23
    :catch_0
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public static schedCounterField([BII)I
    .locals 5

    .line 0
    :goto_0
    const/16 v4, 0x9

    .line 1
    .line 2
    const/16 v3, 0x20

    .line 3
    .line 4
    if-ge p1, p2, :cond_1

    .line 5
    .line 6
    aget-byte v0, p0, p1

    .line 7
    .line 8
    if-eq v0, v3, :cond_0

    .line 9
    .line 10
    if-ne v0, v4, :cond_1

    .line 11
    .line 12
    :cond_0
    add-int/lit8 p1, p1, 0x1

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_1
    move v2, p1

    .line 16
    :goto_1
    if-ge v2, p2, :cond_2

    .line 17
    .line 18
    aget-byte v1, p0, v2

    .line 19
    .line 20
    if-eq v1, v3, :cond_2

    .line 21
    .line 22
    if-eq v1, v4, :cond_2

    .line 23
    .line 24
    const/16 v0, 0x3a

    .line 25
    .line 26
    if-eq v1, v0, :cond_2

    .line 27
    .line 28
    add-int/lit8 v2, v2, 0x1

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_2
    const-string/jumbo v0, "sum_sleep_runtime"

    .line 32
    .line 33
    .line 34
    invoke-static {p0, p1, v2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->matchesKey([BIILjava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_4

    .line 39
    .line 40
    const/4 v1, 0x0

    .line 41
    :cond_3
    return v1

    .line 42
    :cond_4
    const-string/jumbo v0, "sum_block_runtime"

    .line 43
    .line 44
    .line 45
    invoke-static {p0, p1, v2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->matchesKey([BIILjava/lang/String;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_5

    .line 50
    .line 51
    const/4 v1, 0x1

    .line 52
    return v1

    .line 53
    :cond_5
    const-string v0, "iowait_sum"

    .line 54
    .line 55
    invoke-static {p0, p1, v2, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->matchesKey([BIILjava/lang/String;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    const/4 v1, -0x1

    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    const/4 v1, 0x2

    .line 63
    return v1
.end method

.method public static startsWithOffset([BI[B)Z
    .locals 5

    .line 0
    array-length v0, p0

    .line 1
    sub-int/2addr v0, p1

    .line 2
    array-length v4, p2

    .line 3
    const/4 v3, 0x0

    .line 4
    if-lt v0, v4, :cond_1

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    :goto_0
    if-ge v2, v4, :cond_0

    .line 8
    .line 9
    add-int v0, v2, p1

    .line 10
    .line 11
    aget-byte v1, p0, v0

    .line 12
    .line 13
    aget-byte v0, p2, v2

    .line 14
    .line 15
    if-ne v1, v0, :cond_1

    .line 16
    .line 17
    add-int/lit8 v2, v2, 0x1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v3, 0x1

    .line 21
    :cond_1
    return v3
.end method

.method public static trimLineEnd([BI)I
    .locals 3

    .line 0
    array-length v0, p0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    :goto_0
    if-lez v2, :cond_1

    .line 6
    .line 7
    add-int/lit8 v0, v2, -0x1

    .line 8
    .line 9
    aget-byte v1, p0, v0

    .line 10
    .line 11
    const/16 v0, 0xa

    .line 12
    .line 13
    if-eq v1, v0, :cond_0

    .line 14
    .line 15
    if-nez v1, :cond_1

    .line 16
    .line 17
    :cond_0
    add-int/lit8 v2, v2, -0x1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_1
    return v2
.end method

.method public static trimWchan([BI)I
    .locals 4

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/acra/util/JavaProcFileReader;->trimLineEnd([BI)I

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    const/4 v0, 0x1

    .line 5
    if-ne v3, v0, :cond_0

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aget-byte v1, p0, v2

    .line 9
    .line 10
    const/16 v0, 0x30

    .line 11
    .line 12
    if-ne v1, v0, :cond_0

    .line 13
    .line 14
    return v2

    .line 15
    :cond_0
    return v3
.end method


# virtual methods
.method public getOpenFDCount()I
    .locals 1

    .line 0
    :try_start_0
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->FD_DIR:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A0N(Ljava/lang/String;)Ljava/io/File;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Ljava/io/File;->list()[Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    array-length v0, v0

    .line 13
    return v0

    .line 14
    :cond_0
    const/4 v0, -0x1

    .line 15
    return v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    :catch_0
    move-exception v0

    .line 17
    sget-object p0, Lcom/facebook/acra/util/JavaProcFileReader;->TAG:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {p0, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v0, -0x2

    .line 27
    return v0
.end method

.method public getOpenFDLimits()Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;
    .locals 19

    .line 0
    const/16 v12, 0x2000

    .line 1
    .line 2
    new-array v11, v12, [B

    .line 3
    .line 4
    const-string v0, "Max open files"

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    const/4 v10, 0x2

    .line 11
    new-array v9, v10, [Ljava/lang/String;

    .line 12
    .line 13
    const/16 v18, 0x0

    .line 14
    .line 15
    :try_start_0
    const-string v0, "/proc/self/limits"

    .line 16
    .line 17
    new-instance v3, Ljava/io/FileInputStream;

    .line 18
    .line 19
    invoke-direct {v3, v0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const/16 v0, 0x1fff

    .line 23
    .line 24
    const/4 v8, 0x0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :try_start_1
    invoke-virtual {v3, v11, v8, v0}, Ljava/io/InputStream;->read([BII)I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    aput-byte v8, v11, v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 30
    .line 31
    :try_start_2
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    .line 32
    .line 33
    .line 34
    const/4 v7, 0x0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 35
    :goto_0
    const/16 v17, 0x1

    .line 36
    .line 37
    add-int/lit8 v1, v2, -0x1

    .line 38
    .line 39
    sub-int/2addr v1, v7

    .line 40
    array-length v0, v4

    .line 41
    if-le v1, v0, :cond_1

    .line 42
    .line 43
    invoke-static {v11, v7}, Lcom/facebook/acra/util/JavaProcFileReader;->findNewLineOrEnd([BI)I

    .line 44
    .line 45
    .line 46
    move-result v6

    .line 47
    invoke-static {v11, v7, v4}, Lcom/facebook/acra/util/JavaProcFileReader;->startsWithOffset([BI[B)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_12

    .line 52
    .line 53
    sget-object v5, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_OPEN_FD_LIMITS_FORMAT:[I

    .line 54
    .line 55
    array-length v0, v5

    .line 56
    move/from16 p0, v0

    .line 57
    .line 58
    invoke-static {v8, v8}, Ljava/lang/Math;->max(II)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v10, v0}, Ljava/lang/Math;->max(II)I

    .line 63
    .line 64
    .line 65
    move-result v13

    .line 66
    move v4, v7

    .line 67
    const/4 v3, 0x0

    .line 68
    const/4 v2, 0x0

    .line 69
    :goto_1
    move/from16 v0, p0

    .line 70
    .line 71
    if-ge v3, v0, :cond_10

    .line 72
    .line 73
    aget v0, v5, v3

    .line 74
    .line 75
    and-int/lit16 v1, v0, 0x200

    .line 76
    .line 77
    if-nez v1, :cond_b

    .line 78
    .line 79
    and-int/lit16 v1, v0, 0x400

    .line 80
    .line 81
    if-eqz v1, :cond_0

    .line 82
    .line 83
    aget-byte v14, v11, v7

    .line 84
    .line 85
    const/16 v1, 0x22

    .line 86
    .line 87
    if-eq v14, v1, :cond_b

    .line 88
    .line 89
    and-int/lit16 v0, v0, -0x401

    .line 90
    .line 91
    :cond_0
    :goto_2
    and-int/lit16 v1, v0, 0xff

    .line 92
    .line 93
    int-to-char v15, v1

    .line 94
    if-lt v4, v6, :cond_2

    .line 95
    .line 96
    const-string v0, "Ran off end of data @"

    .line 97
    .line 98
    invoke-static {v0, v4}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    const-string v0, "NewProcReader"

    .line 103
    .line 104
    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 105
    .line 106
    .line 107
    :cond_1
    return-object v18

    .line 108
    :cond_2
    and-int/lit16 v1, v0, 0x200

    .line 109
    .line 110
    if-eqz v1, :cond_3

    .line 111
    .line 112
    move v14, v4

    .line 113
    :goto_3
    if-ge v14, v6, :cond_6

    .line 114
    .line 115
    aget-byte v7, v11, v14

    .line 116
    .line 117
    const/16 v1, 0x29

    .line 118
    .line 119
    if-eq v7, v1, :cond_6

    .line 120
    .line 121
    add-int/lit8 v14, v14, 0x1

    .line 122
    .line 123
    goto :goto_3

    .line 124
    :cond_3
    and-int/lit16 v1, v0, 0x400

    .line 125
    .line 126
    move v7, v4

    .line 127
    if-nez v1, :cond_4

    .line 128
    .line 129
    const/4 v14, -0x1

    .line 130
    goto :goto_5

    .line 131
    :cond_4
    :goto_4
    aget-byte v14, v11, v7

    .line 132
    .line 133
    const/16 v1, 0x22

    .line 134
    .line 135
    if-eq v14, v1, :cond_5

    .line 136
    .line 137
    if-ge v7, v6, :cond_5

    .line 138
    .line 139
    add-int/lit8 v7, v7, 0x1

    .line 140
    .line 141
    goto :goto_4

    .line 142
    :cond_5
    add-int/lit8 v1, v7, 0x1

    .line 143
    .line 144
    move v14, v7

    .line 145
    move v7, v1

    .line 146
    goto :goto_5

    .line 147
    :cond_6
    add-int/lit8 v7, v14, 0x1

    .line 148
    .line 149
    :goto_5
    if-ge v7, v6, :cond_7

    .line 150
    .line 151
    aget-byte v1, v11, v7

    .line 152
    .line 153
    if-eq v1, v15, :cond_7

    .line 154
    .line 155
    add-int/lit8 v7, v7, 0x1

    .line 156
    .line 157
    goto :goto_5

    .line 158
    :cond_7
    if-gez v14, :cond_8

    .line 159
    .line 160
    move v14, v7

    .line 161
    :cond_8
    if-ge v7, v6, :cond_9

    .line 162
    .line 163
    add-int/lit8 v7, v7, 0x1

    .line 164
    .line 165
    and-int/lit16 v1, v0, 0x100

    .line 166
    .line 167
    if-eqz v1, :cond_9

    .line 168
    .line 169
    :goto_6
    if-ge v7, v6, :cond_9

    .line 170
    .line 171
    aget-byte v1, v11, v7

    .line 172
    .line 173
    if-ne v1, v15, :cond_9

    .line 174
    .line 175
    add-int/lit8 v7, v7, 0x1

    .line 176
    .line 177
    goto :goto_6

    .line 178
    :cond_9
    and-int/lit16 v1, v0, 0x7000

    .line 179
    .line 180
    if-eqz v1, :cond_11

    .line 181
    .line 182
    if-ge v14, v12, :cond_a

    .line 183
    .line 184
    const/16 v16, 0x1

    .line 185
    .line 186
    aget-byte v15, v11, v14

    .line 187
    .line 188
    aput-byte v8, v11, v14

    .line 189
    .line 190
    :goto_7
    and-int/lit16 v0, v0, 0x1000

    .line 191
    .line 192
    if-eqz v0, :cond_e

    .line 193
    .line 194
    if-ge v2, v10, :cond_e

    .line 195
    .line 196
    move v1, v4

    .line 197
    :goto_8
    if-ge v1, v12, :cond_c

    .line 198
    .line 199
    aget-byte v0, v11, v1

    .line 200
    .line 201
    if-eq v0, v8, :cond_d

    .line 202
    .line 203
    add-int/lit8 v1, v1, 0x1

    .line 204
    .line 205
    goto :goto_8

    .line 206
    :cond_a
    const/16 v16, 0x0

    .line 207
    .line 208
    const/4 v15, 0x0

    .line 209
    goto :goto_7

    .line 210
    :cond_b
    add-int/lit8 v4, v7, 0x1

    .line 211
    .line 212
    goto :goto_2

    .line 213
    :cond_c
    const/16 v1, 0x2000

    .line 214
    .line 215
    :cond_d
    sub-int/2addr v1, v4

    .line 216
    new-instance v0, Ljava/lang/String;

    .line 217
    .line 218
    invoke-direct {v0, v11, v4, v1}, Ljava/lang/String;-><init>([BII)V

    .line 219
    .line 220
    .line 221
    aput-object v0, v9, v2

    .line 222
    .line 223
    :cond_e
    if-eqz v16, :cond_f

    .line 224
    .line 225
    aput-byte v15, v11, v14

    .line 226
    .line 227
    :cond_f
    add-int/lit8 v2, v2, 0x1

    .line 228
    .line 229
    if-lt v2, v13, :cond_11

    .line 230
    .line 231
    :cond_10
    invoke-static {v9, v8}, LX/EYu;->A09([Ljava/lang/String;I)I

    .line 232
    .line 233
    .line 234
    move-result v2

    .line 235
    move/from16 v0, v17

    .line 236
    .line 237
    invoke-static {v9, v0}, LX/EYu;->A09([Ljava/lang/String;I)I

    .line 238
    .line 239
    .line 240
    move-result v1

    .line 241
    new-instance v0, Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;

    .line 242
    .line 243
    invoke-direct {v0, v2, v1}, Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;-><init>(II)V

    .line 244
    .line 245
    .line 246
    return-object v0

    .line 247
    :cond_11
    add-int/lit8 v3, v3, 0x1

    .line 248
    .line 249
    move v4, v7

    .line 250
    goto/16 :goto_1

    .line 251
    .line 252
    :cond_12
    add-int/lit8 v7, v6, 0x1

    .line 253
    .line 254
    goto/16 :goto_0

    .line 255
    .line 256
    :catchall_0
    move-exception v1

    .line 257
    :try_start_3
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    .line 258
    .line 259
    .line 260
    goto :goto_9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 261
    :catchall_1
    move-exception v0

    .line 262
    :try_start_4
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 263
    .line 264
    .line 265
    :goto_9
    throw v1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    .line 266
    :catch_0
    move-exception v2

    .line 267
    sget-object v1, Lcom/facebook/acra/util/JavaProcFileReader;->TAG:Ljava/lang/String;

    .line 268
    .line 269
    const-string v0, "Failed to read /proc/self/limits"

    .line 270
    .line 271
    invoke-static {v1, v2, v0}, LX/FnY;->A0K(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 272
    .line 273
    .line 274
    return-object v18
.end method

.method public getOpenFileDescriptors()Ljava/lang/String;
    .locals 9

    .line 0
    const-string/jumbo v8, "socket"

    .line 1
    .line 2
    .line 3
    const-string v7, "pipe"

    .line 4
    .line 5
    const-string v4, "\n"

    .line 6
    .line 7
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    :try_start_0
    sget-object v1, Lcom/facebook/acra/util/JavaProcFileReader;->FD_DIR:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {}, LX/EYt;->A1X()[Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    const-string v1, "/system/bin/ls"

    .line 22
    .line 23
    const-string v0, "-l"

    .line 24
    .line 25
    filled-new-array {v1, v0, v2}, [Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, Lcom/facebook/acra/util/CommandOutputCollector;->collect([Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v6

    .line 37
    invoke-static {}, LX/001;->A16()Ljava/util/LinkedHashMap;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    const/4 v2, 0x1

    .line 42
    :goto_0
    array-length v0, v6

    .line 43
    if-ge v2, v0, :cond_5

    .line 44
    .line 45
    aget-object p0, v6, v2

    .line 46
    .line 47
    const-string v0, " -> "

    .line 48
    .line 49
    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    const/4 v1, -0x1

    .line 54
    if-eq v0, v1, :cond_4

    .line 55
    .line 56
    add-int/lit8 v0, v0, 0x4

    .line 57
    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    const-string v0, "/fd/"

    .line 63
    .line 64
    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-ne v0, v1, :cond_0

    .line 69
    .line 70
    move-object v1, p0

    .line 71
    goto :goto_1

    .line 72
    :cond_0
    add-int/lit8 v0, v0, 0x4

    .line 73
    .line 74
    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    :goto_1
    invoke-virtual {v1, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_1

    .line 83
    .line 84
    move-object p0, v7

    .line 85
    goto :goto_2

    .line 86
    :cond_1
    invoke-virtual {v1, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_2

    .line 91
    .line 92
    move-object p0, v8

    .line 93
    :cond_2
    :goto_2
    invoke-virtual {v5, p0}, Ljava/util/AbstractMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    check-cast v1, Lcom/facebook/acra/util/JavaProcFileReader$Counter;

    .line 98
    .line 99
    if-nez v1, :cond_3

    .line 100
    .line 101
    new-instance v1, Lcom/facebook/acra/util/JavaProcFileReader$Counter;

    .line 102
    .line 103
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v5, p0, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    :cond_3
    iget v0, v1, Lcom/facebook/acra/util/JavaProcFileReader$Counter;->count:I

    .line 110
    .line 111
    add-int/lit8 v0, v0, 0x1

    .line 112
    .line 113
    iput v0, v1, Lcom/facebook/acra/util/JavaProcFileReader$Counter;->count:I

    .line 114
    .line 115
    :cond_4
    add-int/lit8 v2, v2, 0x1

    .line 116
    .line 117
    goto :goto_0

    .line 118
    :cond_5
    invoke-static {v5}, LX/002;->A19(Ljava/util/AbstractMap;)Ljava/util/Iterator;

    .line 119
    .line 120
    .line 121
    move-result-object v2

    .line 122
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_6

    .line 127
    .line 128
    invoke-static {v2}, LX/001;->A18(Ljava/util/Iterator;)Ljava/util/Map$Entry;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    invoke-static {v1}, LX/001;->A0w(Ljava/util/Map$Entry;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    const-string v0, " "

    .line 140
    .line 141
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Lcom/facebook/acra/util/JavaProcFileReader$Counter;

    .line 149
    .line 150
    iget v0, v0, Lcom/facebook/acra/util/JavaProcFileReader$Counter;->count:I

    .line 151
    .line 152
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    goto :goto_3

    .line 159
    :cond_6
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    return-object v2
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    .line 164
    :catch_0
    move-exception v1

    .line 165
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->TAG:Ljava/lang/String;

    .line 166
    .line 167
    const-string v2, "Exception caught while reading open file descriptors"

    .line 168
    .line 169
    invoke-static {v0, v1, v2}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    if-eqz v0, :cond_7

    .line 177
    .line 178
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    :cond_7
    return-object v2
.end method

.method public readMeminfo([J)I
    .locals 1

    .line 0
    array-length p0, p1

    .line 1
    const/4 v0, 0x5

    .line 2
    if-lt p0, v0, :cond_1

    .line 3
    .line 4
    const/16 v0, 0x1000

    .line 5
    .line 6
    new-array p0, v0, [B

    .line 7
    .line 8
    const-string v0, "/proc/meminfo"

    .line 9
    .line 10
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-gtz v0, :cond_0

    .line 15
    .line 16
    const/4 v0, -0x1

    .line 17
    return v0

    .line 18
    :cond_0
    invoke-static {p0, v0, p1}, Lcom/facebook/acra/util/JavaProcFileReader;->parseMeminfo([BI[J)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const-string v0, "outKb must hold at least 5 values"

    .line 24
    .line 25
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    throw v0
.end method

.method public readSchedCounters(I[J)I
    .locals 1

    .line 0
    array-length p0, p2

    .line 1
    const/4 v0, 0x3

    .line 2
    if-lt p0, v0, :cond_1

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_SCHED_BUFFER:Ljava/lang/ThreadLocal;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, [B

    .line 11
    .line 12
    const-string/jumbo v0, "sched"

    .line 13
    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-gtz v0, :cond_0

    .line 24
    .line 25
    const/4 v0, -0x1

    .line 26
    return v0

    .line 27
    :cond_0
    invoke-static {p0, v0, p2}, Lcom/facebook/acra/util/JavaProcFileReader;->parseSchedCounters([BI[J)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    return v0

    .line 32
    :cond_1
    const-string v0, "outNanos must hold at least 3 values"

    .line 33
    .line 34
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    throw v0
.end method

.method public readSchedStat(I[J)Z
    .locals 1

    .line 0
    array-length p0, p2

    .line 1
    const/4 v0, 0x2

    .line 2
    if-lt p0, v0, :cond_1

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_LINE_BUFFER:Ljava/lang/ThreadLocal;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, [B

    .line 11
    .line 12
    const-string/jumbo v0, "schedstat"

    .line 13
    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-gtz v0, :cond_0

    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    return v0

    .line 27
    :cond_0
    invoke-static {p0, v0, p2}, Lcom/facebook/acra/util/JavaProcFileReader;->parseSchedStat([BI[J)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    return v0

    .line 32
    :cond_1
    const-string v0, "outNanos must hold at least 2 values"

    .line 33
    .line 34
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    throw v0
.end method

.method public readThreadName(I)Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_LINE_BUFFER:Ljava/lang/ThreadLocal;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, [B

    .line 7
    .line 8
    const-string v0, "comm"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/4 v0, 0x0

    .line 19
    if-lez v1, :cond_0

    .line 20
    .line 21
    invoke-static {p0, v1}, Lcom/facebook/acra/util/JavaProcFileReader;->trimLineEnd([BI)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-static {p0, v0, v1}, LX/EYv;->A0v([BII)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    :cond_0
    return-object v0
.end method

.method public readThreadReadBytes(I)J
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_STAT_BUFFER:Ljava/lang/ThreadLocal;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, [B

    .line 7
    .line 8
    const-string v0, "io"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-gtz v0, :cond_0

    .line 19
    .line 20
    const-wide/16 v0, -0x1

    .line 21
    .line 22
    return-wide v0

    .line 23
    :cond_0
    invoke-static {p0, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->parseThreadReadBytes([BI)J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    return-wide v0
.end method

.method public readThreadStatFaults(I[J)I
    .locals 3

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x2

    .line 2
    if-lt v1, v0, :cond_3

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_STAT_BUFFER:Ljava/lang/ThreadLocal;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    check-cast v1, [B

    .line 11
    .line 12
    const-string/jumbo v0, "stat"

    .line 13
    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0, v1}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/4 p1, 0x0

    .line 24
    if-gtz v0, :cond_0

    .line 25
    .line 26
    return p1

    .line 27
    :cond_0
    invoke-static {v1, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->parseThreadStateChar([BI)I

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-eqz p0, :cond_1

    .line 32
    .line 33
    invoke-static {v1, v0, p2}, Lcom/facebook/acra/util/JavaProcFileReader;->parseThreadStatFaults([BI[J)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_2

    .line 38
    .line 39
    :cond_1
    const-wide/16 v1, -0x1

    .line 40
    .line 41
    aput-wide v1, p2, p1

    .line 42
    .line 43
    const/4 v0, 0x1

    .line 44
    aput-wide v1, p2, v0

    .line 45
    .line 46
    :cond_2
    return p0

    .line 47
    :cond_3
    const-string v0, "outFaults must hold at least 2 values"

    .line 48
    .line 49
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    throw v0
.end method

.method public readThreadStateChar(I)I
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/util/JavaProcFileReader;->PROC_LINE_BUFFER:Ljava/lang/ThreadLocal;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, [B

    .line 7
    .line 8
    const-string/jumbo v0, "stat"

    .line 9
    .line 10
    .line 11
    invoke-static {p1, v0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-gtz v0, :cond_0

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    return v0

    .line 23
    :cond_0
    invoke-static {p0, v0}, Lcom/facebook/acra/util/JavaProcFileReader;->parseThreadStateChar([BI)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    return v0
.end method

.method public readWchan(I[B)I
    .locals 0

    .line 0
    const-string/jumbo p0, "wchan"

    .line 1
    .line 2
    .line 3
    invoke-static {p1, p0}, Lcom/facebook/acra/util/ProcFileReader;->threadFilePath(ILjava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p0, p2}, Lcom/facebook/acra/util/JavaProcFileReader;->readProcFileHead(Ljava/lang/String;[B)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    if-gez p0, :cond_0

    .line 12
    .line 13
    const/4 p0, -0x1

    .line 14
    return p0

    .line 15
    :cond_0
    invoke-static {p2, p0}, Lcom/facebook/acra/util/JavaProcFileReader;->trimWchan([BI)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method
