.class public abstract Lcom/facebook/acra/util/ProcFileReader;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CANNOT_DETERMINE_OPEN_FDS:I = -0x1

.field public static final MEMINFO_ACTIVE_FILE_KB_INDEX:I = 0x1

.field public static final MEMINFO_ALL_AVAILABLE:I = 0x1f

.field public static final MEMINFO_DIRTY_KB_INDEX:I = 0x3

.field public static final MEMINFO_FIELD_COUNT:I = 0x5

.field public static final MEMINFO_FREE_KB_INDEX:I = 0x0

.field public static final MEMINFO_INACTIVE_FILE_KB_INDEX:I = 0x2

.field public static final MEMINFO_READ_FAILED:I = -0x1

.field public static final MEMINFO_WRITEBACK_KB_INDEX:I = 0x4

.field public static final SCHEDSTAT_FIELD_COUNT:I = 0x2

.field public static final SCHEDSTAT_RUN_NANOS_INDEX:I = 0x0

.field public static final SCHEDSTAT_WAIT_NANOS_INDEX:I = 0x1

.field public static final SCHED_COUNTERS_ALL_AVAILABLE:I = 0x7

.field public static final SCHED_COUNTERS_READ_FAILED:I = -0x1

.field public static final SCHED_COUNTER_FIELD_COUNT:I = 0x3

.field public static final SCHED_IOWAIT_SUM_AVAILABLE:I = 0x4

.field public static final SCHED_IOWAIT_SUM_NANOS_INDEX:I = 0x2

.field public static final SCHED_SUM_BLOCK_RUNTIME_AVAILABLE:I = 0x2

.field public static final SCHED_SUM_BLOCK_RUNTIME_NANOS_INDEX:I = 0x1

.field public static final SCHED_SUM_SLEEP_RUNTIME_AVAILABLE:I = 0x1

.field public static final SCHED_SUM_SLEEP_RUNTIME_NANOS_INDEX:I = 0x0

.field public static final SECURITY_EXCEPTION:I = -0x2

.field public static final THREAD_FAULTS_FIELD_COUNT:I = 0x2

.field public static final THREAD_FAULTS_MAJOR_INDEX:I = 0x1

.field public static final THREAD_FAULTS_MINOR_INDEX:I = 0x0

.field public static final THREAD_READ_BYTES_UNAVAILABLE:J = -0x1L

.field public static final THREAD_STATE_UNAVAILABLE:I = 0x0

.field public static final WCHAN_READ_FAILED:I = -0x1


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getProcFileReader()Lcom/facebook/acra/util/ProcFileReader;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/util/NativeProcFileReader;->sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {}, Lcom/facebook/acra/util/NativeProcFileReader;->getInstance()Lcom/facebook/acra/util/NativeProcFileReader;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :cond_0
    invoke-static {}, Lcom/facebook/acra/util/JavaProcFileReader;->getInstance()Lcom/facebook/acra/util/JavaProcFileReader;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public static threadFilePath(ILjava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 0
    const-string v1, "/proc/self/task/"

    .line 1
    .line 2
    const-string v0, "/"

    .line 3
    .line 4
    invoke-static {v1, v0, p1, p0}, LX/Gi8;->A0o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method


# virtual methods
.method public abstract getOpenFDCount()I
.end method

.method public abstract getOpenFDLimits()Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;
.end method

.method public abstract getOpenFileDescriptors()Ljava/lang/String;
.end method

.method public abstract readMeminfo([J)I
.end method

.method public abstract readSchedCounters(I[J)I
.end method

.method public abstract readSchedStat(I[J)Z
.end method

.method public abstract readThreadName(I)Ljava/lang/String;
.end method

.method public abstract readThreadReadBytes(I)J
.end method

.method public abstract readThreadStatFaults(I[J)I
.end method

.method public abstract readThreadStateChar(I)I
.end method

.method public abstract readWchan(I[B)I
.end method
