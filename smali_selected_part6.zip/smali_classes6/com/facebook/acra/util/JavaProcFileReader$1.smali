.class public Lcom/facebook/acra/util/JavaProcFileReader$1;
.super Ljava/lang/ThreadLocal;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal<",
        "[B>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic initialValue()Ljava/lang/Object;
    .locals 0

    .line 0
    const/16 p0, 0x80

    .line 1
    .line 2
    new-array p0, p0, [B

    .line 3
    .line 4
    return-object p0
.end method

.method public initialValue()[B
    .locals 0

    .line 268435456
    const/16 p0, 0x80

    .line 268435457
    .line 268435458
    new-array p0, p0, [B

    .line 268435459
    .line 268435460
    return-object p0
.end method
