.class public Lcom/facebook/acra/util/AttachmentUtil;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "AttachmentUtil"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static compressToBase64String([B)Ljava/lang/String;
    .locals 4

    .line 0
    invoke-static {}, LX/EYt;->A0L()Ljava/io/ByteArrayOutputStream;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    new-instance v2, Ljava/util/zip/GZIPOutputStream;

    .line 5
    .line 6
    invoke-direct {v2, v3}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 7
    .line 8
    .line 9
    :try_start_0
    array-length v0, p0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v2, p0, v1, v0}, Ljava/io/OutputStream;->write([BII)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->finish()V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    .line 26
    .line 27
    .line 28
    return-object v0

    .line 29
    :catchall_0
    move-exception v1

    .line 30
    :try_start_1
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 31
    .line 32
    .line 33
    throw v1

    .line 34
    :catchall_1
    move-exception v0

    .line 35
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 36
    .line 37
    .line 38
    throw v1
.end method

.method public static loadAttachment(Ljava/io/InputStream;I)Ljava/lang/String;
    .locals 4

    .line 0
    new-array v3, p1, [B

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    const/4 v1, 0x0

    .line 4
    :goto_0
    sub-int v0, p1, v2

    .line 5
    .line 6
    if-lez v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0, v3, v2, v0}, Ljava/io/InputStream;->read([BII)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v0, -0x1

    .line 13
    if-eq v1, v0, :cond_1

    .line 14
    .line 15
    add-int/2addr v2, v1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    if-nez v1, :cond_1

    .line 18
    .line 19
    const-string v0, ""

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    invoke-static {v3}, Lcom/facebook/acra/util/AttachmentUtil;->compressToBase64String([B)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public static sortPruneOldFiles(Ljava/io/File;I)[Ljava/io/File;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    invoke-static {p0, p1}, Lcom/facebook/acra/util/AttachmentUtil;->sortPruneOldFiles([Ljava/io/File;I)[Ljava/io/File;

    .line 268435461
    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public static sortPruneOldFiles([Ljava/io/File;I)[Ljava/io/File;
    .locals 6

    .line 0
    array-length v5, p0

    .line 1
    if-eqz v5, :cond_1

    .line 2
    .line 3
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    const/4 v3, 0x0

    .line 8
    :cond_0
    aget-object v2, p0, v3

    .line 9
    .line 10
    invoke-virtual {v2}, Ljava/io/File;->lastModified()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    invoke-static {v2, v4, v0, v1}, LX/EYt;->A1M(Ljava/lang/Object;Ljava/util/AbstractMap;J)V

    .line 15
    .line 16
    .line 17
    add-int/lit8 v3, v3, 0x1

    .line 18
    .line 19
    if-lt v3, v5, :cond_0

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/acra/util/AttachmentUtil$1;

    .line 22
    .line 23
    invoke-direct {v0, v4}, Lcom/facebook/acra/util/AttachmentUtil$1;-><init>(Ljava/util/Map;)V

    .line 24
    .line 25
    .line 26
    invoke-static {p0, v0}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    .line 27
    .line 28
    .line 29
    if-le v5, p1, :cond_1

    .line 30
    .line 31
    :goto_0
    if-ge p1, v5, :cond_1

    .line 32
    .line 33
    aget-object v0, p0, p1

    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 36
    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    aput-object v0, p0, p1

    .line 40
    .line 41
    add-int/lit8 p1, p1, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    return-object p0
.end method

.method public static validateGzip(Ljava/io/File;)Z
    .locals 4

    .line 0
    const/4 v1, 0x1

    .line 1
    :try_start_0
    invoke-static {p0}, LX/EYt;->A0O(Ljava/io/File;)Ljava/io/FileInputStream;

    .line 2
    .line 3
    .line 4
    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 5
    :try_start_1
    new-instance v3, Ljava/util/zip/GZIPInputStream;

    .line 6
    .line 7
    invoke-direct {v3, p0}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 8
    .line 9
    .line 10
    :try_start_2
    invoke-static {v3}, LX/EYu;->A0V(Ljava/io/InputStream;)Ljava/io/BufferedReader;

    .line 11
    .line 12
    .line 13
    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 14
    :goto_0
    :try_start_3
    invoke-virtual {v2}, Ljava/io/Reader;->ready()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    goto :goto_0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 24
    :cond_0
    :try_start_4
    invoke-virtual {v2}, Ljava/io/Reader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 25
    .line 26
    .line 27
    :try_start_5
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 28
    .line 29
    .line 30
    :try_start_6
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 31
    .line 32
    .line 33
    return v1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_0

    .line 34
    :catchall_0
    move-exception v1

    .line 35
    :try_start_7
    invoke-virtual {v2}, Ljava/io/Reader;->close()V

    .line 36
    .line 37
    .line 38
    goto :goto_1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 39
    :catchall_1
    move-exception v0

    .line 40
    :try_start_8
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    :goto_1
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 44
    :catchall_2
    move-exception v1

    .line 45
    :try_start_9
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    .line 46
    .line 47
    .line 48
    goto :goto_2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 49
    :catchall_3
    move-exception v0

    .line 50
    :try_start_a
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 51
    .line 52
    .line 53
    :goto_2
    throw v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    .line 54
    :catchall_4
    move-exception v1

    .line 55
    :try_start_b
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    .line 56
    .line 57
    .line 58
    goto :goto_3
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 59
    :catchall_5
    move-exception v0

    .line 60
    :try_start_c
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 61
    .line 62
    .line 63
    :goto_3
    throw v1
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_0

    .line 64
    :catch_0
    move-exception v0

    .line 65
    const/4 v3, 0x0

    .line 66
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    const-string v1, "AttachmentUtil"

    .line 71
    .line 72
    const-string v0, "Failed to validate gzip file"

    .line 73
    .line 74
    invoke-static {v1, v0, v2}, LX/I1w;->A00(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    return v3
.end method
