.class public Lcom/facebook/acra/util/NativeProcFileReader;
.super Lcom/facebook/acra/util/ProcFileReader;
.source ""


# static fields
.field public static sInstance:Lcom/facebook/acra/util/NativeProcFileReader;

.field public static final sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    invoke-static {}, LX/8mk;->A0s()Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    sput-object v0, Lcom/facebook/acra/util/NativeProcFileReader;->sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/acra/util/NativeProcFileReader;->sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    const-string p0, "Class is not ready"

    .line 13
    .line 14
    invoke-static {p0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    throw p0
.end method

.method public static declared-synchronized getInstance()Lcom/facebook/acra/util/NativeProcFileReader;
    .locals 2

    .line 0
    const-class v1, Lcom/facebook/acra/util/NativeProcFileReader;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    sget-object v0, Lcom/facebook/acra/util/NativeProcFileReader;->sInstance:Lcom/facebook/acra/util/NativeProcFileReader;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/acra/util/NativeProcFileReader;

    .line 8
    .line 9
    invoke-direct {v0}, Lcom/facebook/acra/util/NativeProcFileReader;-><init>()V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lcom/facebook/acra/util/NativeProcFileReader;->sInstance:Lcom/facebook/acra/util/NativeProcFileReader;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    .line 14
    :cond_0
    monitor-exit v1

    .line 15
    return-object v0

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    throw v0
.end method

.method private native getOpenFDLimitsNative()[I
.end method

.method public static isReady()Z
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/util/NativeProcFileReader;->sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public static nativeLibraryLoaded()V
    .locals 3

    .line 0
    const-class v2, Lcom/facebook/acra/util/NativeProcFileReader;

    .line 1
    .line 2
    monitor-enter v2

    .line 3
    :try_start_0
    sget-object v1, Lcom/facebook/acra/util/NativeProcFileReader;->sReadyToUse:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    .line 10
    .line 11
    .line 12
    monitor-exit v2

    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw v0
.end method

.method private native readSchedCountersNative(I[J)I
.end method

.method private native readSchedStatNative(I[J)Z
.end method

.method private native readThreadStatFaultsNative(I[J)I
.end method


# virtual methods
.method public native getOpenFDCount()I
.end method

.method public getOpenFDLimits()Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/util/NativeProcFileReader;->getOpenFDLimitsNative()[I

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const/4 v0, 0x0

    .line 5
    aget p0, v1, v0

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    aget v1, v1, v0

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;

    .line 11
    .line 12
    invoke-direct {v0, p0, v1}, Lcom/facebook/acra/util/ProcFileReader$OpenFDLimits;-><init>(II)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public native getOpenFileDescriptors()Ljava/lang/String;
.end method

.method public readMeminfo([J)I
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/util/JavaProcFileReader;->getInstance()Lcom/facebook/acra/util/JavaProcFileReader;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0, p1}, Lcom/facebook/acra/util/ProcFileReader;->readMeminfo([J)I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public readSchedCounters(I[J)I
    .locals 2

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x3

    .line 2
    if-lt v1, v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/acra/util/NativeProcFileReader;->readSchedCountersNative(I[J)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0

    .line 9
    :cond_0
    const-string v0, "outNanos must hold at least 3 values"

    .line 10
    .line 11
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    throw v0
.end method

.method public readSchedStat(I[J)Z
    .locals 2

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x2

    .line 2
    if-lt v1, v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/acra/util/NativeProcFileReader;->readSchedStatNative(I[J)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0

    .line 9
    :cond_0
    const-string v0, "outNanos must hold at least 2 values"

    .line 10
    .line 11
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    throw v0
.end method

.method public readThreadName(I)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/util/JavaProcFileReader;->getInstance()Lcom/facebook/acra/util/JavaProcFileReader;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0, p1}, Lcom/facebook/acra/util/ProcFileReader;->readThreadName(I)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public readThreadReadBytes(I)J
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/util/JavaProcFileReader;->getInstance()Lcom/facebook/acra/util/JavaProcFileReader;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0, p1}, Lcom/facebook/acra/util/ProcFileReader;->readThreadReadBytes(I)J

    .line 5
    .line 6
    .line 7
    move-result-wide p0

    .line 8
    return-wide p0
.end method

.method public readThreadStatFaults(I[J)I
    .locals 2

    .line 0
    array-length v1, p2

    .line 1
    const/4 v0, 0x2

    .line 2
    if-lt v1, v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/acra/util/NativeProcFileReader;->readThreadStatFaultsNative(I[J)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0

    .line 9
    :cond_0
    const-string v0, "outFaults must hold at least 2 values"

    .line 10
    .line 11
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    throw v0
.end method

.method public native readThreadStateChar(I)I
.end method

.method public readWchan(I[B)I
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/util/JavaProcFileReader;->getInstance()Lcom/facebook/acra/util/JavaProcFileReader;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/acra/util/ProcFileReader;->readWchan(I[B)I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method
