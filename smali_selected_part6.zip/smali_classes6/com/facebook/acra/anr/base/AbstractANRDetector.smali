.class public abstract Lcom/facebook/acra/anr/base/AbstractANRDetector;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/acra/anr/IANRDetector;


# instance fields
.field public final mANRConfig:LX/Fvc;

.field public mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

.field public mANRReportTime:J

.field public mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;

.field public mDetectorStartTime:J

.field public mInAnr:Z

.field public volatile mInForegroundV1:Z

.field public volatile mInForegroundV2:Z

.field public final mStateLock:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LX/Fvc;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iput-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mStateLock:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 10
    .line 11
    return-void
.end method

.method public static isTest()Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    return v0
.end method


# virtual methods
.method public anrHasEnded(Z)V
    .locals 4

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 3
    .line 4
    .line 5
    move-result-wide v2

    .line 6
    iget-wide v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportTime:J

    .line 7
    .line 8
    sub-long/2addr v2, v0

    .line 9
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 10
    .line 11
    iget-object v1, v0, LX/Fvc;->A03:LX/Ft8;

    .line 12
    .line 13
    iput-wide v2, v1, LX/Ft8;->A0B:J

    .line 14
    .line 15
    invoke-static {v1}, LX/Ft8;->A00(LX/Ft8;)V

    .line 16
    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    iput-boolean v0, v1, LX/Ft8;->A0R:Z

    .line 20
    .line 21
    :cond_0
    return-void
.end method

.method public abstract collectStackTrace()V
.end method

.method public getANRReceivedTime()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public getANRReceivedUpTime()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public getDetectorStartTime()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mDetectorStartTime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public getReadyTime()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public getSwitchTime()J
    .locals 1

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    return-wide v0
.end method

.method public inAnrState()Z
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mStateLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInAnr:Z

    .line 4
    .line 5
    monitor-exit v1

    .line 6
    return v0

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    throw v0
.end method

.method public isDebuggerConnected()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public isInForegroundV1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 1
    .line 2
    return p0
.end method

.method public logMainThreadUnblocked(J)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 1
    .line 2
    iget-object p0, p0, LX/Fvc;->A03:LX/Ft8;

    .line 3
    .line 4
    iput-wide p1, p0, LX/Ft8;->A07:J

    .line 5
    .line 6
    invoke-static {p0}, LX/Ft8;->A00(LX/Ft8;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public nativeLibraryLoaded(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public abstract notifyStateListeners(LX/Ftc;)V
.end method

.method public processMonitorStarted()V
    .locals 2

    .line 0
    invoke-virtual {p0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->shouldCollectAndUploadANRReportsNow()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 7
    .line 8
    iget-object p0, v0, LX/Fvc;->A03:LX/Ft8;

    .line 9
    .line 10
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    iput-wide v0, p0, LX/Ft8;->A0A:J

    .line 15
    .line 16
    invoke-static {p0}, LX/Ft8;->A00(LX/Ft8;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public processMonitorStopped(I)V
    .locals 2

    .line 0
    invoke-virtual {p0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->shouldCollectAndUploadANRReportsNow()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 7
    .line 8
    iget-object p0, v0, LX/Fvc;->A03:LX/Ft8;

    .line 9
    .line 10
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    iput-wide v0, p0, LX/Ft8;->A09:J

    .line 15
    .line 16
    iput p1, p0, LX/Ft8;->A01:I

    .line 17
    .line 18
    invoke-static {p0}, LX/Ft8;->A00(LX/Ft8;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void
.end method

.method public reportSoftError(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-interface {p0, p1, p2}, Lcom/facebook/acra/anr/ANRReportProvider;->reportSoftError(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method public setANRReportProvider(Lcom/facebook/acra/anr/ANRReportProvider;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 1
    .line 2
    return-void
.end method

.method public setCheckIntervalMs(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public setInAnrState(Z)V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mStateLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInAnr:Z

    .line 4
    .line 5
    monitor-exit v1

    .line 6
    return-void

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    throw v0
.end method

.method public declared-synchronized setListener(Lcom/facebook/acra/anr/ANRDetectorListener;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iput-object p1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    monitor-exit p0

    .line 4
    return-void

    .line 5
    :catchall_0
    move-exception v0

    .line 6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    throw v0
.end method

.method public shouldCollectAndUploadANRReports()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-interface {p0}, Lcom/facebook/acra/anr/ANRReportProvider;->shouldCollectAndUploadANRReports()Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0

    .line 9
    :cond_0
    const/4 p0, 0x1

    .line 10
    return p0
.end method

.method public shouldCollectAndUploadANRReportsNow()Z
    .locals 1

    .line 0
    invoke-virtual {p0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->shouldCollectAndUploadANRReports()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV2:Z

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    :cond_0
    const/4 v0, 0x1

    .line 15
    return v0

    .line 16
    :cond_1
    const/4 v0, 0x0

    .line 17
    return v0
.end method

.method public start()V
    .locals 2

    .line 0
    const-wide/16 v0, -0x1

    .line 1
    .line 2
    invoke-virtual {p0, v0, v1}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->start(J)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public abstract start(J)V
.end method

.method public startReport(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Z)V
    .locals 27

    .line 0
    move-object/from16 v7, p0

    .line 1
    .line 2
    monitor-enter v7

    .line 3
    :try_start_0
    iget-object v6, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;

    .line 4
    .line 5
    monitor-exit v7

    .line 6
    if-eqz v6, :cond_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    invoke-interface {v6}, Lcom/facebook/acra/anr/ANRDetectorListener;->getBlackBoxTraceId()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v19

    .line 12
    invoke-interface {v6}, Lcom/facebook/acra/anr/ANRDetectorListener;->getLongStallTraceId()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v20

    .line 16
    invoke-interface {v6}, Lcom/facebook/acra/anr/ANRDetectorListener;->onStartANRDataCapture()V

    .line 17
    .line 18
    .line 19
    :goto_0
    invoke-virtual {v7}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->collectStackTrace()V

    .line 20
    .line 21
    .line 22
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    iput-wide v0, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportTime:J

    .line 27
    .line 28
    iget-object v0, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 29
    .line 30
    iget-object v8, v0, LX/Fvc;->A03:LX/Ft8;

    .line 31
    .line 32
    iget-object v0, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 33
    .line 34
    invoke-static {v0}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    iget-boolean v5, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 39
    .line 40
    iget-boolean v4, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV2:Z

    .line 41
    .line 42
    iget-wide v2, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRReportTime:J

    .line 43
    .line 44
    iget-wide v0, v7, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mDetectorStartTime:J

    .line 45
    .line 46
    const/4 v9, 0x0

    .line 47
    move-object/from16 v21, p1

    .line 48
    .line 49
    move-object/from16 v22, p2

    .line 50
    .line 51
    move-object/from16 v12, p3

    .line 52
    .line 53
    move/from16 p3, p4

    .line 54
    .line 55
    move-object v10, v9

    .line 56
    move-object v11, v9

    .line 57
    move-object v13, v9

    .line 58
    move-object v14, v9

    .line 59
    move-object v15, v9

    .line 60
    move-object/from16 v16, v9

    .line 61
    .line 62
    move-object/from16 v17, v9

    .line 63
    .line 64
    move-object/from16 v18, v9

    .line 65
    .line 66
    move-wide/from16 v23, v2

    .line 67
    .line 68
    move-wide/from16 v25, v0

    .line 69
    .line 70
    move/from16 p1, v5

    .line 71
    .line 72
    move/from16 p2, v4

    .line 73
    .line 74
    invoke-virtual/range {v8 .. v30}, LX/Ft8;->A01(LX/Epr;LX/Epr;LX/Ftc;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJZZZZ)V

    .line 75
    .line 76
    .line 77
    if-eqz v6, :cond_0

    .line 78
    .line 79
    invoke-interface {v6}, Lcom/facebook/acra/anr/ANRDetectorListener;->onEndANRDataCapture()V

    .line 80
    .line 81
    .line 82
    :cond_0
    return-void

    .line 83
    :cond_1
    const/16 v20, 0x0

    .line 84
    .line 85
    move-object/from16 v19, v20

    .line 86
    .line 87
    goto :goto_0

    .line 88
    :catchall_0
    move-exception v0

    .line 89
    :try_start_1
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 90
    throw v0
.end method

.method public abstract stop(Lcom/facebook/acra/anr/IANRDetector$ANRDetectorStopListener;)V
.end method
