.class public Lcom/facebook/acra/anr/SigquitRecord;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ERROR_READING_TIME_INFO:J = -0x1L

.field public static final TAG:Ljava/lang/String; = "SigquitRecord"

.field public static final sRecords:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/facebook/acra/anr/SigquitRecord;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final callbackUptimeMs:J

.field public final sigquitUptimeMs:J


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    sput-object v0, Lcom/facebook/acra/anr/SigquitRecord;->sRecords:Ljava/util/ArrayList;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(JJ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/acra/anr/SigquitRecord;->callbackUptimeMs:J

    .line 4
    .line 5
    iput-wide p3, p0, Lcom/facebook/acra/anr/SigquitRecord;->sigquitUptimeMs:J

    .line 6
    .line 7
    return-void
.end method

.method public static convertRawBytesToLong([B)J
    .locals 8

    .line 0
    const-wide/16 v6, 0x0

    .line 1
    .line 2
    const/4 v5, 0x0

    .line 3
    const/4 v4, 0x0

    .line 4
    :cond_0
    aget-byte v0, p0, v5

    .line 5
    .line 6
    int-to-long v2, v0

    .line 7
    const-wide/16 v0, 0xff

    .line 8
    .line 9
    and-long/2addr v2, v0

    .line 10
    shl-long/2addr v2, v4

    .line 11
    add-long/2addr v6, v2

    .line 12
    add-int/lit8 v4, v4, 0x8

    .line 13
    .line 14
    add-int/lit8 v5, v5, 0x1

    .line 15
    .line 16
    const/16 v0, 0x8

    .line 17
    .line 18
    if-lt v5, v0, :cond_0

    .line 19
    .line 20
    return-wide v6
.end method

.method public static declared-synchronized getRecordsJson(Ljava/lang/Long;)Ljava/lang/String;
    .locals 9

    .line 0
    const-class v8, Lcom/facebook/acra/anr/SigquitRecord;

    .line 1
    .line 2
    monitor-enter v8

    .line 3
    :try_start_0
    new-instance v6, Lorg/json/JSONArray;

    .line 4
    .line 5
    invoke-direct {v6}, Lorg/json/JSONArray;-><init>()V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/facebook/acra/anr/SigquitRecord;->sRecords:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v7

    .line 14
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    check-cast v5, Lcom/facebook/acra/anr/SigquitRecord;

    .line 25
    .line 26
    if-eqz p0, :cond_1

    .line 27
    .line 28
    iget-wide v3, v5, Lcom/facebook/acra/anr/SigquitRecord;->callbackUptimeMs:J

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    .line 31
    .line 32
    .line 33
    move-result-wide v1

    .line 34
    cmp-long v0, v3, v1

    .line 35
    .line 36
    if-lez v0, :cond_1

    .line 37
    .line 38
    :cond_0
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    if-nez v0, :cond_2

    .line 43
    .line 44
    const-string v0, ""

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    invoke-static {}, LX/EYt;->A1E()Lorg/json/JSONObject;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    const-string v2, "callback_uptime_ms"

    .line 52
    .line 53
    iget-wide v0, v5, Lcom/facebook/acra/anr/SigquitRecord;->callbackUptimeMs:J

    .line 54
    .line 55
    invoke-virtual {v3, v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 56
    .line 57
    .line 58
    const-string/jumbo v2, "sigquit_uptime_ms"

    .line 59
    .line 60
    .line 61
    iget-wide v0, v5, Lcom/facebook/acra/anr/SigquitRecord;->sigquitUptimeMs:J

    .line 62
    .line 63
    invoke-virtual {v3, v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v6, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 67
    .line 68
    .line 69
    goto :goto_0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 70
    :catch_0
    :try_start_1
    const-string v0, "\"json error\""
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 71
    .line 72
    :cond_2
    :goto_1
    monitor-exit v8

    .line 73
    return-object v0

    .line 74
    :catchall_0
    move-exception v0

    .line 75
    :try_start_2
    monitor-exit v8
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 76
    throw v0
.end method

.method public static readSigquitUptimeMs(Ljava/lang/String;)J
    .locals 7

    .line 0
    const-string v3, "SigquitRecord"

    .line 1
    .line 2
    const-wide/16 v5, -0x1

    .line 3
    .line 4
    :try_start_0
    new-instance v4, Ljava/io/FileInputStream;

    .line 5
    .line 6
    invoke-direct {v4, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const/16 v2, 0x8
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    :try_start_1
    new-array v1, v2, [B

    .line 12
    .line 13
    invoke-virtual {v4, v1}, Ljava/io/InputStream;->read([B)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eq v0, v2, :cond_0

    .line 18
    .line 19
    const-string v1, "Corrupted file %s"

    .line 20
    .line 21
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {v3, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    .line 27
    .line 28
    :try_start_2
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    .line 29
    .line 30
    .line 31
    return-wide v5
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 32
    :cond_0
    :try_start_3
    invoke-static {v1}, Lcom/facebook/acra/anr/SigquitRecord;->convertRawBytesToLong([B)J

    .line 33
    .line 34
    .line 35
    move-result-wide v0

    .line 36
    invoke-static {v0, v1}, LX/EYv;->A0O(J)J

    .line 37
    .line 38
    .line 39
    move-result-wide v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 40
    :try_start_4
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    .line 41
    .line 42
    .line 43
    return-wide v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    .line 44
    :catchall_0
    move-exception v1

    .line 45
    :try_start_5
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    .line 46
    .line 47
    .line 48
    goto :goto_0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 49
    :catchall_1
    move-exception v0

    .line 50
    :try_start_6
    invoke-static {v1, v0}, LX/I5v;->A00(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 51
    .line 52
    .line 53
    :goto_0
    throw v1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    filled-new-array {p0, v0}, [Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    const-string v0, "Could not read from file %s"

    .line 60
    .line 61
    invoke-static {v3, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    return-wide v5
.end method

.method public static updateRecords(JLjava/lang/String;)V
    .locals 5

    .line 0
    if-eqz p2, :cond_1

    .line 1
    .line 2
    const-class v4, Lcom/facebook/acra/anr/SigquitRecord;

    .line 3
    .line 4
    monitor-enter v4

    .line 5
    :try_start_0
    sget-object v3, Lcom/facebook/acra/anr/SigquitRecord;->sRecords:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-lez v0, :cond_0

    .line 12
    .line 13
    invoke-static {v3}, LX/001;->A0E(Ljava/util/AbstractCollection;)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-virtual {v3, v0}, Ljava/util/AbstractList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Lcom/facebook/acra/anr/SigquitRecord;

    .line 22
    .line 23
    iget-wide v1, v0, Lcom/facebook/acra/anr/SigquitRecord;->callbackUptimeMs:J

    .line 24
    .line 25
    cmp-long v0, v1, p0

    .line 26
    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    :goto_0
    monitor-exit v4

    .line 30
    goto :goto_1

    .line 31
    :cond_0
    invoke-static {p2}, Lcom/facebook/acra/anr/SigquitRecord;->readSigquitUptimeMs(Ljava/lang/String;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v1

    .line 35
    new-instance v0, Lcom/facebook/acra/anr/SigquitRecord;

    .line 36
    .line 37
    invoke-direct {v0, p0, p1, v1, v2}, Lcom/facebook/acra/anr/SigquitRecord;-><init>(JJ)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :goto_1
    return-void

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    throw v0

    .line 48
    :cond_1
    return-void
.end method
