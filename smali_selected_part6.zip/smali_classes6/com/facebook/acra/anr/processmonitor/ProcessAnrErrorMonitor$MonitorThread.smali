.class public Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;
.super Ljava/lang/Thread;
.source ""


# instance fields
.field public final mAm:Landroid/app/ActivityManager;

.field public final mDelay:J

.field public mFirstCheck:Z

.field public final mId:J

.field public volatile mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

.field public final mMonitorLock:Ljava/lang/Object;

.field public mPauseRequested:Z

.field public final mProcessesInAnr:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public mStopRequested:Z

.field public final synthetic this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;


# direct methods
.method public static bridge synthetic -$$Nest$mpauseRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->pauseRequested()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$mresumeRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->resumeRequested()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$mstopRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->stopRequested()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public constructor <init>(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;Landroid/app/ActivityManager;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;JJ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 1
    .line 2
    const-string v1, "ProcessAnrErrorMonitorThread:"

    .line 3
    .line 4
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 9
    .line 10
    iget-object v0, v0, LX/Fth;->A03:Ljava/lang/String;

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    :cond_0
    const-string/jumbo v0, "unknown"

    .line 15
    .line 16
    .line 17
    :cond_1
    invoke-static {v1, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-direct {p0, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 29
    .line 30
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mProcessesInAnr:Ljava/util/Set;

    .line 35
    .line 36
    iput-object p2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mAm:Landroid/app/ActivityManager;

    .line 37
    .line 38
    iput-object p3, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 39
    .line 40
    iput-wide p4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mId:J

    .line 41
    .line 42
    iput-wide p6, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mDelay:J

    .line 43
    .line 44
    const/4 v0, 0x1

    .line 45
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mFirstCheck:Z

    .line 46
    .line 47
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;Landroid/app/ActivityManager;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;JJLcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor-IA;)V
    .locals 0

    .line 268435456
    invoke-direct/range {p0 .. p7}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;-><init>(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;Landroid/app/ActivityManager;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;JJ)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method private maybeCallIterationListener()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 5
    .line 6
    invoke-interface {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onCheckPerformed()V

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
.end method

.method private maybeLogAnrStateFromOtherProcesses(Ljava/util/LinkedList;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/LinkedList<",
            "Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    check-cast v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;

    .line 19
    .line 20
    iget-object v1, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 29
    .line 30
    filled-new-array {v1, p2}, [Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v0, "Error found in process \'%s\' different from process being searched \'%s\'"

    .line 35
    .line 36
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iget-object v1, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 40
    .line 41
    if-eqz v1, :cond_0

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mProcessesInAnr:Ljava/util/Set;

    .line 44
    .line 45
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    iget-object v3, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 52
    .line 53
    iget-object v2, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 54
    .line 55
    iget-object v1, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mErrorMsg:Ljava/lang/String;

    .line 56
    .line 57
    iget-object v0, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mTag:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {v3, v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onErrorDetectOnOtherProcess(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_0

    .line 64
    .line 65
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mProcessesInAnr:Ljava/util/Set;

    .line 66
    .line 67
    iget-object v0, v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 68
    .line 69
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_1
    return-void
.end method

.method private monitorLoop()V
    .locals 12

    .line 0
    iget-wide v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mDelay:J

    .line 1
    .line 2
    const/4 v6, 0x0

    .line 3
    const-wide/16 v10, 0x0

    .line 4
    .line 5
    cmp-long v0, v1, v10

    .line 6
    .line 7
    if-gtz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 10
    .line 11
    if-nez v0, :cond_7

    .line 12
    .line 13
    :cond_0
    iget-wide v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mDelay:J

    .line 14
    .line 15
    iget-object v5, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 16
    .line 17
    monitor-enter v5

    .line 18
    cmp-long v0, v1, v10

    .line 19
    .line 20
    if-lez v0, :cond_1

    .line 21
    .line 22
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 23
    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_1
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 28
    .line 29
    if-nez v0, :cond_2

    .line 30
    .line 31
    :goto_0
    const/4 v0, 0x1

    .line 32
    goto :goto_1

    .line 33
    :cond_2
    const/4 v0, 0x0

    .line 34
    :goto_1
    iget-boolean v9, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 35
    .line 36
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 37
    .line 38
    .line 39
    move-result-wide v7

    .line 40
    if-eqz v0, :cond_3

    .line 41
    .line 42
    goto :goto_3

    .line 43
    :goto_2
    iget-wide v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mDelay:J

    .line 44
    .line 45
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 46
    .line 47
    .line 48
    move-result-wide v3

    .line 49
    sub-long/2addr v3, v7

    .line 50
    sub-long/2addr v1, v3

    .line 51
    const-wide/16 v3, 0x1

    .line 52
    .line 53
    cmp-long v0, v1, v3

    .line 54
    .line 55
    if-gez v0, :cond_4

    .line 56
    .line 57
    :cond_3
    monitor-exit v5

    .line 58
    goto :goto_6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 59
    :cond_4
    :goto_3
    :try_start_1
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 60
    .line 61
    invoke-virtual {v0, v1, v2}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 62
    .line 63
    .line 64
    :catch_0
    cmp-long v0, v1, v10

    .line 65
    .line 66
    if-lez v0, :cond_5

    .line 67
    .line 68
    :try_start_2
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 69
    .line 70
    if-nez v0, :cond_6

    .line 71
    .line 72
    goto :goto_4

    .line 73
    :cond_5
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 74
    .line 75
    if-nez v0, :cond_6

    .line 76
    .line 77
    :goto_4
    const/4 v0, 0x1

    .line 78
    goto :goto_5

    .line 79
    :cond_6
    const/4 v0, 0x0

    .line 80
    :goto_5
    iget-boolean v9, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 81
    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    cmp-long v0, v1, v10

    .line 85
    .line 86
    if-lez v0, :cond_4

    .line 87
    .line 88
    goto :goto_2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 89
    :catchall_0
    move-exception v0

    .line 90
    :try_start_3
    monitor-exit v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 91
    throw v0

    .line 92
    :cond_7
    new-instance v5, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;

    .line 93
    .line 94
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 95
    .line 96
    .line 97
    iput-boolean v6, v5, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mAnrConfirmed:Z

    .line 98
    .line 99
    iput v6, v5, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 100
    .line 101
    :cond_8
    invoke-virtual {p0, v5}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->checkIteration(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-eqz v0, :cond_d

    .line 106
    .line 107
    iget-object v4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 108
    .line 109
    monitor-enter v4

    .line 110
    :try_start_4
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 111
    .line 112
    if-nez v0, :cond_c

    .line 113
    .line 114
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 115
    .line 116
    iget v3, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mPollingTime:I

    .line 117
    .line 118
    :cond_9
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mPauseRequested:Z

    .line 119
    .line 120
    if-eqz v0, :cond_a

    .line 121
    .line 122
    const/4 v3, 0x0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 123
    :cond_a
    :try_start_5
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 124
    .line 125
    int-to-long v0, v3

    .line 126
    invoke-virtual {v2, v0, v1}, Ljava/lang/Object;->wait(J)V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 127
    .line 128
    .line 129
    :catch_1
    :try_start_6
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mPauseRequested:Z

    .line 130
    .line 131
    if-eqz v0, :cond_b

    .line 132
    .line 133
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 134
    .line 135
    if-eqz v0, :cond_9

    .line 136
    .line 137
    :cond_b
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 138
    .line 139
    :cond_c
    monitor-exit v4

    .line 140
    if-eqz v0, :cond_8
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 141
    .line 142
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 143
    .line 144
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->STOP_REQUESTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 145
    .line 146
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 147
    .line 148
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :goto_6
    if-eqz v9, :cond_7

    .line 153
    .line 154
    :cond_d
    return-void

    .line 155
    :catchall_1
    move-exception v0

    .line 156
    :try_start_7
    monitor-exit v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 157
    throw v0
.end method

.method private pauseRequested()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    const/4 v0, 0x1

    .line 4
    :try_start_0
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mPauseRequested:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    .line 9
    .line 10
    .line 11
    monitor-exit v1

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    throw v0
.end method

.method private resumeRequested()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    const/4 v0, 0x0

    .line 4
    :try_start_0
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mPauseRequested:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    .line 9
    .line 10
    .line 11
    monitor-exit v1

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    throw v0
.end method

.method private stopRequested()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    const/4 v0, 0x1

    .line 4
    :try_start_0
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mStopRequested:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    .line 9
    .line 10
    .line 11
    monitor-exit v1

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    throw v0
.end method


# virtual methods
.method public checkIteration(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;)Z
    .locals 8

    .line 0
    const/4 v3, 0x1

    .line 1
    const/4 v4, 0x0

    .line 2
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 3
    .line 4
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 9
    .line 10
    .line 11
    move-result-wide v6

    .line 12
    :goto_0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mAm:Landroid/app/ActivityManager;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->checkProcessError(Landroid/app/ActivityManager;)Ljava/util/LinkedList;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 21
    .line 22
    iget-object v0, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 23
    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    sub-long/2addr v0, v6

    .line 31
    invoke-static {v2, v0, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->-$$Nest$mlogDuration(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;J)V

    .line 32
    .line 33
    .line 34
    :cond_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mFirstCheck:Z

    .line 35
    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 39
    .line 40
    const-string v1, "Starting process monitor checks for process \'%s\'"

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 43
    .line 44
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 45
    .line 46
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v2, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iput-boolean v4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mFirstCheck:Z

    .line 54
    .line 55
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 56
    .line 57
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->MONITOR_STARTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 60
    .line 61
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 62
    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_1
    const-wide/16 v6, 0x0

    .line 66
    .line 67
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    :cond_2
    :goto_1
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-nez v0, :cond_5

    .line 73
    .line 74
    invoke-virtual {v5}, Ljava/util/LinkedList;->getFirst()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v7

    .line 78
    check-cast v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;

    .line 79
    .line 80
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 81
    .line 82
    iget-object v1, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 83
    .line 84
    iget-object v0, v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_5

    .line 91
    .line 92
    iget-boolean v0, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mAnrConfirmed:Z

    .line 93
    .line 94
    if-nez v0, :cond_7

    .line 95
    .line 96
    iput-boolean v3, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mAnrConfirmed:Z

    .line 97
    .line 98
    iput v4, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 99
    .line 100
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v1, v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mErrorMsg:Ljava/lang/String;

    .line 103
    .line 104
    iget-object v0, v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mTag:Ljava/lang/String;

    .line 105
    .line 106
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    const-string v0, "ANR detected Short msg: %s Tag: %s"

    .line 111
    .line 112
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    iget-object v6, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 116
    .line 117
    sget-object v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 118
    .line 119
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 120
    .line 121
    iget-object v1, v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mErrorMsg:Ljava/lang/String;

    .line 122
    .line 123
    iget-object v0, v7, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mTag:Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {v6, v4, v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :cond_3
    :goto_2
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-nez v0, :cond_4

    .line 133
    .line 134
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 135
    .line 136
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 137
    .line 138
    invoke-direct {p0, v5, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->maybeLogAnrStateFromOtherProcesses(Ljava/util/LinkedList;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    :cond_4
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->maybeCallIterationListener()V

    .line 142
    .line 143
    .line 144
    return v3

    .line 145
    :cond_5
    iget-boolean v0, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mAnrConfirmed:Z

    .line 146
    .line 147
    if-eqz v0, :cond_6

    .line 148
    .line 149
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 150
    .line 151
    const-string v0, "On error cleared"

    .line 152
    .line 153
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 157
    .line 158
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->ERROR_CLEARED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 159
    .line 160
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 161
    .line 162
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 163
    .line 164
    .line 165
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 166
    .line 167
    iget-boolean v3, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContinuousMonitoring:Z

    .line 168
    .line 169
    if-eqz v3, :cond_3

    .line 170
    .line 171
    iput-boolean v4, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mAnrConfirmed:Z

    .line 172
    .line 173
    iput v4, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :cond_6
    iget v0, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 177
    .line 178
    add-int/lit8 v1, v0, 0x1

    .line 179
    .line 180
    iput v1, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 181
    .line 182
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 183
    .line 184
    iget v0, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksBeforeError:I

    .line 185
    .line 186
    if-lez v0, :cond_3

    .line 187
    .line 188
    if-lt v1, v0, :cond_3

    .line 189
    .line 190
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->MAX_NUMBER_BEFORE_ERROR:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 191
    .line 192
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 193
    .line 194
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 195
    .line 196
    .line 197
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 198
    .line 199
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 200
    .line 201
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 202
    .line 203
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    const-string v0, "Stopping checks for \'%s\' because of MAX_NUMBER_BEFORE_ERROR"

    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_7
    iget v0, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 211
    .line 212
    add-int/lit8 v1, v0, 0x1

    .line 213
    .line 214
    iput v1, p1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrCheckState;->mCount:I

    .line 215
    .line 216
    iget v0, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksAfterError:I

    .line 217
    .line 218
    if-lez v0, :cond_3

    .line 219
    .line 220
    if-lt v1, v0, :cond_3

    .line 221
    .line 222
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->MAX_NUMBER_AFTER_ERROR:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 223
    .line 224
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 225
    .line 226
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 227
    .line 228
    .line 229
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 230
    .line 231
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 232
    .line 233
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 234
    .line 235
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    const-string v0, "Stopping checks for \'%s\' because of MAX_NUMBER_AFTER_ERROR"

    .line 240
    .line 241
    :goto_3
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 242
    .line 243
    .line 244
    const/4 v3, 0x0

    .line 245
    goto :goto_2

    .line 246
    :catch_0
    move-exception v3

    .line 247
    invoke-virtual {v3}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    instance-of v0, v0, Landroid/os/DeadObjectException;

    .line 252
    .line 253
    if-nez v0, :cond_8

    .line 254
    .line 255
    invoke-virtual {v3}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    instance-of v0, v0, Landroid/os/RemoteException;

    .line 260
    .line 261
    if-nez v0, :cond_8

    .line 262
    .line 263
    throw v3

    .line 264
    :cond_8
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 265
    .line 266
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;->ERROR_QUERYING_ACTIVITY_MANAGER:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;

    .line 267
    .line 268
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 269
    .line 270
    invoke-virtual {v2, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 271
    .line 272
    .line 273
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 274
    .line 275
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->this$0:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 276
    .line 277
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 278
    .line 279
    filled-new-array {v0, v3}, [Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    const-string v0, "Stopping checks for \'%s\' because of ERROR_QUERYING_ACTIVITY_MANAGER"

    .line 284
    .line 285
    invoke-static {v2, v0, v1}, LX/FnY;->A0F(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    return v4
.end method

.method public getMonitorId()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mId:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public hasListener()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 1
    .line 2
    invoke-static {p0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public run()V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->monitorLoop()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public setListener(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    iput-object p1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mMonitorLock:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    .line 8
    .line 9
    .line 10
    monitor-exit v1

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v0

    .line 13
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    throw v0
.end method
