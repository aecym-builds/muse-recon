.class public final enum Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $VALUES:[Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

.field public static final enum MONITORING_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

.field public static final enum MONITORING_NO_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

.field public static final enum NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const-string v1, "NOT_MONITORING"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 4
    .line 5
    invoke-direct {v4, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v4, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 9
    .line 10
    const-string v1, "MONITORING_NO_ERROR_DETECTED"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->MONITORING_NO_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 19
    .line 20
    const-string v2, "MONITORING_ERROR_DETECTED"

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 24
    .line 25
    invoke-direct {v0, v2, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->MONITORING_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 29
    .line 30
    filled-new-array {v4, v3, v0}, [Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sput-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->$VALUES:[Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 35
    .line 36
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 0
    const-class v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->$VALUES:[Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 1
    .line 2
    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 7
    .line 8
    return-object v0
.end method
