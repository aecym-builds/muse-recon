.class public Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEFAULT_POLLING_TIME_MS:I = 0x1f4

.field public static final LOG_TAG:Ljava/lang/String; = "ProcessAnrErrorMonitor"

.field public static final UNLIMITED_NUMBER_OF_CHECKS:I


# instance fields
.field public final mContext:Landroid/content/Context;

.field public final mContinuousMonitoring:Z

.field public mCurrentMonitorThreadId:J

.field public mDurationWritePos:I

.field public mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

.field public mFullHistoryData:Z

.field public final mMaxNumberOfChecksAfterError:I

.field public final mMaxNumberOfChecksBeforeError:I

.field public final mMyUid:I

.field public final mPollingTime:I

.field public final mProcessName:Ljava/lang/String;

.field public final mQueryDurationHistory:[J

.field public mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;


# direct methods
.method public static bridge synthetic -$$Nest$fgetmContinuousMonitoring(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContinuousMonitoring:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmMaxNumberOfChecksAfterError(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksAfterError:I

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmMaxNumberOfChecksBeforeError(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksBeforeError:I

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmPollingTime(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mPollingTime:I

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmProcessName(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmQueryDurationHistory(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)[J
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$mlogDuration(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;J)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->logDuration(J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$sfgetLOG_TAG()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;II)V
    .locals 5

    .line 536870912
    const/4 v3, 0x0

    .line 536870913
    const/16 v4, 0x1f4

    .line 536870914
    .line 536870915
    move-object v0, p0

    .line 536870916
    move-object v1, p1

    .line 536870917
    move-object v2, p2

    .line 536870918
    move p1, p3

    .line 536870919
    move p2, p4

    .line 536870920
    move p0, v3

    .line 536870921
    move p3, v3

    .line 536870922
    invoke-direct/range {v0 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;-><init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V

    .line 536870923
    .line 536870924
    .line 536870925
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;ZII)V
    .locals 6

    .line 0
    const/4 v5, 0x0

    .line 1
    const/16 v4, 0x1f4

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    move-object v1, p1

    .line 5
    move-object v2, p2

    .line 6
    move v3, p3

    .line 7
    move p0, p4

    .line 8
    move p1, p5

    .line 9
    move p2, v5

    .line 10
    invoke-direct/range {v0 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;-><init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V
    .locals 3

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContext:Landroid/content/Context;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 268435462
    .line 268435463
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 268435464
    .line 268435465
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 268435466
    .line 268435467
    iput p4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mPollingTime:I

    .line 268435468
    .line 268435469
    iput-boolean p5, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContinuousMonitoring:Z

    .line 268435470
    .line 268435471
    iput p6, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksBeforeError:I

    .line 268435472
    .line 268435473
    iput p7, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMaxNumberOfChecksAfterError:I

    .line 268435474
    .line 268435475
    invoke-static {}, Landroid/os/Process;->myUid()I

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    iput v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMyUid:I

    .line 268435480
    .line 268435481
    const/4 v2, 0x0

    .line 268435482
    if-lez p8, :cond_1

    .line 268435483
    .line 268435484
    new-array v0, p8, [J

    .line 268435485
    .line 268435486
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 268435487
    .line 268435488
    :goto_0
    const/4 v0, 0x0

    .line 268435489
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mFullHistoryData:Z

    .line 268435490
    .line 268435491
    iput v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mDurationWritePos:I

    .line 268435492
    .line 268435493
    if-eqz p3, :cond_0

    .line 268435494
    .line 268435495
    const-wide/16 v0, 0x0

    .line 268435496
    .line 268435497
    invoke-virtual {p0, v2, v0, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->startMonitoringAfterDelay(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;J)V

    .line 268435498
    .line 268435499
    .line 268435500
    :cond_0
    return-void

    .line 268435501
    :cond_1
    iput-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 268435502
    .line 268435503
    goto :goto_0
.end method

.method private logDuration(J)V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 1
    .line 2
    if-eqz v4, :cond_1

    .line 3
    .line 4
    monitor-enter v4

    .line 5
    :try_start_0
    iget-object v3, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 6
    .line 7
    iget v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mDurationWritePos:I

    .line 8
    .line 9
    aput-wide p1, v3, v0

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    add-int/lit8 v1, v0, 0x1

    .line 13
    .line 14
    iput v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mDurationWritePos:I

    .line 15
    .line 16
    array-length v0, v3

    .line 17
    if-lt v1, v0, :cond_0

    .line 18
    .line 19
    iput-boolean v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mFullHistoryData:Z

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    iput v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mDurationWritePos:I

    .line 23
    .line 24
    :cond_0
    monitor-exit v4

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    throw v0

    .line 29
    :cond_1
    return-void
.end method


# virtual methods
.method public checkProcessError(Landroid/app/ActivityManager;)Ljava/util/LinkedList;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/ActivityManager;",
            ")",
            "Ljava/util/LinkedList<",
            "Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-virtual {p1}, Landroid/app/ActivityManager;->getProcessesInErrorState()Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {}, LX/EYt;->A11()Ljava/util/LinkedList;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    check-cast v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;

    .line 25
    .line 26
    iget v1, v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;->condition:I

    .line 27
    .line 28
    const/4 v0, 0x2

    .line 29
    if-ne v1, v0, :cond_0

    .line 30
    .line 31
    iget v1, v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;->uid:I

    .line 32
    .line 33
    iget v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mMyUid:I

    .line 34
    .line 35
    if-ne v1, v0, :cond_0

    .line 36
    .line 37
    new-instance v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;

    .line 38
    .line 39
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 40
    .line 41
    .line 42
    iget-object v0, v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;->shortMsg:Ljava/lang/String;

    .line 43
    .line 44
    iput-object v0, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mErrorMsg:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v0, v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;->tag:Ljava/lang/String;

    .line 47
    .line 48
    iput-object v0, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mTag:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v1, v3, Landroid/app/ActivityManager$ProcessErrorStateInfo;->processName:Ljava/lang/String;

    .line 51
    .line 52
    iput-object v1, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$AnrErrorState;->mProcessName:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mProcessName:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    invoke-virtual {v5, v2}, Ljava/util/LinkedList;->addFirst(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-virtual {v5, v2}, Ljava/util/LinkedList;->addLast(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_2
    return-object v5
.end method

.method public getDurationHistory()LX/Epr;
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 1
    .line 2
    if-eqz v4, :cond_0

    .line 3
    .line 4
    monitor-enter v4

    .line 5
    :try_start_0
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mQueryDurationHistory:[J

    .line 6
    .line 7
    array-length v1, v2

    .line 8
    new-array v3, v1, [J

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-static {v2, v0, v3, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 12
    .line 13
    .line 14
    iget v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mDurationWritePos:I

    .line 15
    .line 16
    iget-boolean v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mFullHistoryData:Z

    .line 17
    .line 18
    new-instance v0, LX/Epr;

    .line 19
    .line 20
    invoke-direct {v0, v3, v2, v1}, LX/Epr;-><init>([JIZ)V

    .line 21
    .line 22
    .line 23
    monitor-exit v4

    .line 24
    return-object v0

    .line 25
    :catchall_0
    move-exception v0

    .line 26
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    throw v0

    .line 28
    :cond_0
    const/4 v0, 0x0

    .line 29
    return-object v0
.end method

.method public declared-synchronized getErrorCheckThread()Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    monitor-exit p0

    .line 4
    return-object v0

    .line 5
    :catchall_0
    move-exception v0

    .line 6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    throw v0
.end method

.method public declared-synchronized getState()Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    monitor-exit p0

    .line 4
    return-object v0

    .line 5
    :catchall_0
    move-exception v0

    .line 6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    throw v0
.end method

.method public pause()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 2
    .line 3
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 4
    .line 5
    if-eq v1, v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->-$$Nest$mpauseRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    throw v0
.end method

.method public resume()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 2
    .line 3
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 4
    .line 5
    if-eq v1, v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->-$$Nest$mresumeRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    throw v0
.end method

.method public declared-synchronized setErrorCheckThread(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iput-object p1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    monitor-exit p0

    .line 4
    return-void

    .line 5
    :catchall_0
    move-exception v0

    .line 6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    throw v0
.end method

.method public startMonitoring(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V
    .locals 2

    .line 0
    const-wide/16 v0, 0x0

    .line 1
    .line 2
    invoke-virtual {p0, p1, v0, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->startMonitoringAfterDelay(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;J)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public startMonitoringAfterDelay(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;J)V
    .locals 11

    .line 0
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->LOG_TAG:Ljava/lang/String;

    .line 1
    .line 2
    const-string/jumbo v1, "startMonitoring with delay: %d"

    .line 3
    .line 4
    .line 5
    move-wide v9, p2

    .line 6
    invoke-static {p2, p3}, LX/EYt;->A1Y(J)[Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v2, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    move-object v4, p0

    .line 14
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContext:Landroid/content/Context;

    .line 15
    .line 16
    const-string v0, "activity"

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    check-cast v5, Landroid/app/ActivityManager;

    .line 23
    .line 24
    monitor-enter v4

    .line 25
    move-object v6, p1

    .line 26
    if-nez p1, :cond_0

    .line 27
    .line 28
    const-wide/16 v1, 0x0

    .line 29
    .line 30
    cmp-long v0, p2, v1

    .line 31
    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 36
    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    iget-object v0, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 40
    .line 41
    invoke-static {v0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_2

    .line 46
    .line 47
    if-eqz p1, :cond_1

    .line 48
    .line 49
    goto :goto_2

    .line 50
    :cond_1
    const-string v0, "Listener cannot be null"

    .line 51
    .line 52
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    goto :goto_1

    .line 57
    :goto_0
    const-string v0, "Cannot delay and wait for listener at the same time"

    .line 58
    .line 59
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    :goto_1
    throw v0

    .line 64
    :cond_2
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 65
    .line 66
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 67
    .line 68
    if-eq v0, v2, :cond_3

    .line 69
    .line 70
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 71
    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->-$$Nest$mstopRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V

    .line 75
    .line 76
    .line 77
    :cond_3
    iget-wide v7, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mCurrentMonitorThreadId:J

    .line 78
    .line 79
    const-wide/16 v0, 0x1

    .line 80
    .line 81
    add-long/2addr v7, v0

    .line 82
    iput-wide v7, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mCurrentMonitorThreadId:J

    .line 83
    .line 84
    new-instance v3, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 85
    .line 86
    invoke-direct/range {v3 .. v10}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;-><init>(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;Landroid/app/ActivityManager;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;JJ)V

    .line 87
    .line 88
    .line 89
    iput-object v3, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 90
    .line 91
    if-eqz p1, :cond_4

    .line 92
    .line 93
    sget-object v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->MONITORING_NO_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 94
    .line 95
    :cond_4
    iput-object v2, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 96
    .line 97
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 98
    .line 99
    .line 100
    goto :goto_3

    .line 101
    :goto_2
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 102
    .line 103
    invoke-virtual {v0, p1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->setListener(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V

    .line 104
    .line 105
    .line 106
    :goto_3
    monitor-exit v4

    .line 107
    return-void
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 108
    :catchall_0
    move-exception v0

    .line 109
    :try_start_1
    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 110
    throw v0
.end method

.method public startMonitoringForTest(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;
    .locals 8

    .line 0
    move-object v2, p0

    .line 1
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContext:Landroid/content/Context;

    .line 2
    .line 3
    const-string v0, "activity"

    .line 4
    .line 5
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    check-cast v3, Landroid/app/ActivityManager;

    .line 10
    .line 11
    monitor-enter v2

    .line 12
    :try_start_0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 15
    .line 16
    if-eq v1, v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->-$$Nest$mstopRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    iget-wide v5, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mCurrentMonitorThreadId:J

    .line 26
    .line 27
    const-wide/16 v0, 0x1

    .line 28
    .line 29
    add-long/2addr v5, v0

    .line 30
    iput-wide v5, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mCurrentMonitorThreadId:J

    .line 31
    .line 32
    const-wide/16 v7, 0x0

    .line 33
    .line 34
    new-instance v1, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 35
    .line 36
    move-object v4, p1

    .line 37
    invoke-direct/range {v1 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;-><init>(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;Landroid/app/ActivityManager;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;JJ)V

    .line 38
    .line 39
    .line 40
    iput-object v1, v2, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 41
    .line 42
    monitor-exit v2

    .line 43
    return-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    :catchall_0
    move-exception v0

    .line 45
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 46
    throw v0
.end method

.method public stopMonitoring()V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 2
    .line 3
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 4
    .line 5
    if-eq v1, v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->-$$Nest$mstopRequested(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    throw v0
.end method

.method public updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;)V
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-virtual {p0, p1, p2, v0, v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435458
    .line 268435459
    .line 268435460
    return-void
.end method

.method public declared-synchronized updateStateAndMaybeCallListener(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$StateChangeReason;Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .line 0
    const-string v5, "Unexpected state change reason: "

    .line 1
    .line 2
    monitor-enter p0

    .line 3
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mErrorCheckThread:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-wide v2, v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$MonitorThread;->mId:J

    .line 8
    .line 9
    iget-wide v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mCurrentMonitorThreadId:J

    .line 10
    .line 11
    cmp-long v4, v2, v0

    .line 12
    .line 13
    if-eqz v4, :cond_0

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    packed-switch v0, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    invoke-static {p1, v5}, LX/EYu;->A0Y(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    throw v0

    .line 28
    :pswitch_0
    if-eqz p2, :cond_2

    .line 29
    .line 30
    invoke-interface {p2}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onStart()V

    .line 31
    .line 32
    .line 33
    goto :goto_1

    .line 34
    :pswitch_1
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mContinuousMonitoring:Z

    .line 35
    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->MONITORING_NO_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 39
    .line 40
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 44
    .line 45
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 46
    .line 47
    :goto_0
    if-eqz p2, :cond_2

    .line 48
    .line 49
    invoke-interface {p2}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onErrorCleared()V

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :pswitch_2
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->MONITORING_ERROR_DETECTED:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 54
    .line 55
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 56
    .line 57
    if-eqz p2, :cond_2

    .line 58
    .line 59
    invoke-interface {p2, p3, p4}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onErrorDetected(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    goto :goto_1

    .line 63
    :pswitch_3
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 64
    .line 65
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 66
    .line 67
    if-eqz p2, :cond_2

    .line 68
    .line 69
    invoke-interface {p2}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onMaxChecksReachedBeforeError()V

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :pswitch_4
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 74
    .line 75
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 76
    .line 77
    if-eqz p2, :cond_2

    .line 78
    .line 79
    invoke-interface {p2}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onMaxChecksReachedAfterError()V

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :pswitch_5
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 84
    .line 85
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 86
    .line 87
    goto :goto_1

    .line 88
    :pswitch_6
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;->NOT_MONITORING:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 89
    .line 90
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->mState:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor$State;

    .line 91
    .line 92
    if-eqz p2, :cond_2

    .line 93
    .line 94
    invoke-interface {p2}, Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;->onCheckFailed()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 95
    .line 96
    .line 97
    :cond_2
    :goto_1
    monitor-exit p0

    .line 98
    return-void

    .line 99
    :catchall_0
    :try_start_1
    move-exception v0

    .line 100
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 101
    throw v0

    .line 102
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method
