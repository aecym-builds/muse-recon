.class public Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;
.super Lcom/facebook/acra/anr/base/AbstractANRDetector;
.source ""

# interfaces
.implements Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;


# static fields
.field public static final LOG_TAG:Ljava/lang/String; = "ProcessErrorMonitorANRDetector"

.field public static final START_DELAY_MS:I = 0xfa0

.field public static sInstance:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;


# instance fields
.field public final mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

.field public final mAnrRecoveredLock:Ljava/lang/Object;

.field public mDetectorStartTime:J

.field public volatile mErrorCleared:Z

.field public mFirstStart:Z

.field public mInAnr:Z

.field public final mNotifyANRRecoveredRunnable:Ljava/lang/Runnable;

.field public final mReportLock:Ljava/lang/Object;

.field public mShouldReport:Z


# direct methods
.method public static bridge synthetic -$$Nest$fgetmErrorCleared(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mErrorCleared:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$mendAndProcessANRDataCapture(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->endAndProcessANRDataCapture()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public constructor <init>(LX/Fvc;I)V
    .locals 9

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/base/AbstractANRDetector;-><init>(LX/Fvc;)V

    .line 1
    .line 2
    .line 3
    const/4 v5, 0x1

    .line 4
    iput-boolean v5, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mFirstStart:Z

    .line 5
    .line 6
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mReportLock:Ljava/lang/Object;

    .line 11
    .line 12
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrRecoveredLock:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v1, p1, LX/Fvc;->A01:Landroid/content/Context;

    .line 19
    .line 20
    iget-object v2, p1, LX/Fvc;->A04:Ljava/lang/String;

    .line 21
    .line 22
    const/4 v3, 0x0

    .line 23
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 24
    .line 25
    move v4, p2

    .line 26
    move v6, v3

    .line 27
    move v7, v3

    .line 28
    move v8, v3

    .line 29
    invoke-direct/range {v0 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;-><init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 33
    .line 34
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$1;

    .line 35
    .line 36
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$1;-><init>(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V

    .line 37
    .line 38
    .line 39
    iput-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mNotifyANRRecoveredRunnable:Ljava/lang/Runnable;

    .line 40
    .line 41
    return-void
.end method

.method private declared-synchronized endAndProcessANRDataCapture()V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mInAnr:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mInAnr:Z

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mNotifyANRRecoveredRunnable:Ljava/lang/Runnable;

    .line 9
    .line 10
    invoke-static {v0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$ThreadProvider;->runOnNewThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    .line 13
    :cond_0
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception v0

    .line 16
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 17
    throw v0
.end method

.method public static declared-synchronized getInstance(LX/Fvc;I)Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;
    .locals 2

    .line 0
    const-class v1, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    sget-object v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->sInstance:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;-><init>(LX/Fvc;I)V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->sInstance:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    .line 14
    :cond_0
    monitor-exit v1

    .line 15
    return-object v0

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    throw v0
.end method

.method public static declared-synchronized resetInstance()V
    .locals 2

    .line 0
    const-class v1, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    const/4 v0, 0x0

    .line 4
    :try_start_0
    sput-object v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->sInstance:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    monitor-exit v1

    .line 7
    return-void

    .line 8
    :catchall_0
    move-exception v0

    .line 9
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 10
    throw v0
.end method


# virtual methods
.method public collectStackTrace()V
    .locals 2

    .line 0
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-string v0, "ANR detected by ProcessErrorMonitorAnrDetector"

    .line 13
    .line 14
    new-instance p0, Lcom/facebook/acra/anr/ANRException;

    .line 15
    .line 16
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->setStackTrace([Ljava/lang/StackTraceElement;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->LOG_TAG:Ljava/lang/String;

    .line 23
    .line 24
    const-string v0, "Generating ANR Report"

    .line 25
    .line 26
    invoke-static {v1, p0, v0}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public notifyStateListeners(LX/Ftc;)V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 1
    .line 2
    iget-object v3, v0, LX/Fvc;->A00:LX/Fug;

    .line 3
    .line 4
    sget-object v2, LX/Ftc;->A03:LX/Ftc;

    .line 5
    .line 6
    if-ne p1, v2, :cond_2

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrRecoveredLock:Ljava/lang/Object;

    .line 9
    .line 10
    monitor-enter v1

    .line 11
    :try_start_0
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 18
    .line 19
    iget-boolean v0, v0, LX/Fth;->A04:Z

    .line 20
    .line 21
    :goto_0
    iput-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV2:Z

    .line 22
    .line 23
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 30
    .line 31
    iget-boolean v0, v0, LX/Fth;->A04:Z

    .line 32
    .line 33
    :goto_1
    iput-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 34
    .line 35
    check-cast v3, LX/Fuf;

    .line 36
    .line 37
    iget-object v0, v3, LX/Fuf;->A00:LX/FtB;

    .line 38
    .line 39
    invoke-static {v0, v2}, LX/FtB;->A00(LX/FtB;LX/Ftc;)V

    .line 40
    .line 41
    .line 42
    monitor-exit v1

    .line 43
    return-void

    .line 44
    :catchall_0
    move-exception v0

    .line 45
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    throw v0

    .line 47
    :cond_2
    sget-object v2, LX/Ftc;->A02:LX/Ftc;

    .line 48
    .line 49
    if-eq p1, v2, :cond_3

    .line 50
    .line 51
    sget-object v2, LX/Ftc;->A04:LX/Ftc;

    .line 52
    .line 53
    :cond_3
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrRecoveredLock:Ljava/lang/Object;

    .line 54
    .line 55
    monitor-enter v1

    .line 56
    :try_start_1
    check-cast v3, LX/Fuf;

    .line 57
    .line 58
    iget-object v0, v3, LX/Fuf;->A00:LX/FtB;

    .line 59
    .line 60
    invoke-static {v0, v2}, LX/FtB;->A00(LX/FtB;LX/Ftc;)V

    .line 61
    .line 62
    .line 63
    monitor-exit v1

    .line 64
    return-void

    .line 65
    :catchall_1
    move-exception v0

    .line 66
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 67
    throw v0
.end method

.method public onCheckFailed()V
    .locals 0

    .line 0
    return-void
.end method

.method public onCheckPerformed()V
    .locals 0

    .line 0
    return-void
.end method

.method public onErrorCleared()V
    .locals 3

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v2, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mShouldReport:Z

    .line 2
    .line 3
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mErrorCleared:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mErrorCleared:Z

    .line 9
    .line 10
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->notifyStateListeners(LX/Ftc;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 16
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mReportLock:Ljava/lang/Object;

    .line 17
    .line 18
    monitor-enter v1

    .line 19
    :try_start_1
    invoke-virtual {p0, v2}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->anrHasEnded(Z)V

    .line 20
    .line 21
    .line 22
    monitor-exit v1

    .line 23
    return-void

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    throw v0

    .line 27
    :catchall_1
    move-exception v0

    .line 28
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 29
    throw v0
.end method

.method public onErrorDetectOnOtherProcess(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    return p0
.end method

.method public onErrorDetected(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 0
    monitor-enter p0

    .line 1
    const/4 v4, 0x1

    .line 2
    :try_start_0
    iput-boolean v4, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mInAnr:Z

    .line 3
    .line 4
    const/4 v3, 0x0

    .line 5
    iput-boolean v3, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mErrorCleared:Z

    .line 6
    .line 7
    sget-object v0, LX/Ftc;->A03:LX/Ftc;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->notifyStateListeners(LX/Ftc;)V

    .line 10
    .line 11
    .line 12
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV2:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    :cond_0
    invoke-virtual {p0}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->shouldCollectAndUploadANRReportsNow()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mShouldReport:Z

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 30
    .line 31
    iget-object v2, v0, LX/Fvc;->A03:LX/Ft8;

    .line 32
    .line 33
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 34
    .line 35
    .line 36
    move-result-wide v0

    .line 37
    iput-object p1, v2, LX/Ft8;->A0O:Ljava/lang/String;

    .line 38
    .line 39
    iput-object p2, v2, LX/Ft8;->A0P:Ljava/lang/String;

    .line 40
    .line 41
    iput-wide v0, v2, LX/Ft8;->A08:J

    .line 42
    .line 43
    invoke-static {v2}, LX/Ft8;->A00(LX/Ft8;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 47
    :try_start_1
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mShouldReport:Z

    .line 48
    .line 49
    if-eqz v0, :cond_2

    .line 50
    .line 51
    invoke-static {}, LX/EYt;->A0L()Ljava/io/ByteArrayOutputStream;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v0}, Lcom/facebook/acra/anr/StackTraceDumper;->dumpStackTraces(Ljava/io/OutputStream;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    iget-object v1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mReportLock:Ljava/lang/Object;

    .line 63
    .line 64
    monitor-enter v1

    .line 65
    const/4 v0, 0x0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 66
    :try_start_2
    invoke-virtual {p0, v2, v0, v0, v3}, Lcom/facebook/acra/anr/base/AbstractANRDetector;->startReport(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Z)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 67
    .line 68
    .line 69
    :catch_0
    :try_start_3
    monitor-exit v1

    .line 70
    goto :goto_0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 71
    :catchall_0
    move-exception v0

    .line 72
    :try_start_4
    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 73
    :try_start_5
    throw v0

    .line 74
    :cond_2
    if-eqz v4, :cond_3

    .line 75
    .line 76
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 77
    .line 78
    iget-object v2, v0, LX/Fvc;->A03:LX/Ft8;

    .line 79
    .line 80
    iget-boolean v1, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV1:Z

    .line 81
    .line 82
    iget-boolean v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mInForegroundV2:Z

    .line 83
    .line 84
    iput-boolean v1, v2, LX/Ft8;->A0S:Z

    .line 85
    .line 86
    iput-boolean v0, v2, LX/Ft8;->A0T:Z

    .line 87
    .line 88
    invoke-static {v2}, LX/Ft8;->A00(LX/Ft8;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 89
    .line 90
    .line 91
    :cond_3
    :goto_0
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 92
    .line 93
    iget-object v1, v0, LX/Fvc;->A02:Landroid/os/Handler;

    .line 94
    .line 95
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;

    .line 96
    .line 97
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;-><init>(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 101
    .line 102
    .line 103
    return-void

    .line 104
    :catchall_1
    move-exception v2

    .line 105
    iget-object v0, p0, Lcom/facebook/acra/anr/base/AbstractANRDetector;->mANRConfig:LX/Fvc;

    .line 106
    .line 107
    iget-object v1, v0, LX/Fvc;->A02:Landroid/os/Handler;

    .line 108
    .line 109
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;

    .line 110
    .line 111
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;-><init>(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 115
    .line 116
    .line 117
    throw v2

    .line 118
    :catchall_2
    move-exception v0

    .line 119
    :try_start_6
    monitor-exit p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 120
    throw v0
.end method

.method public onMaxChecksReachedAfterError()V
    .locals 0

    .line 0
    return-void
.end method

.method public onMaxChecksReachedBeforeError()V
    .locals 0

    .line 0
    return-void
.end method

.method public onStart()V
    .locals 0

    .line 0
    return-void
.end method

.method public pause()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->pause()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public resume()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->resume()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public declared-synchronized start(J)V
    .locals 5

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-wide v3, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mDetectorStartTime:J

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    cmp-long v0, v3, v1

    .line 6
    .line 7
    if-gtz v0, :cond_0

    .line 8
    .line 9
    iput-wide p1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mDetectorStartTime:J

    .line 10
    .line 11
    :cond_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mFirstStart:Z

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mFirstStart:Z

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 19
    .line 20
    const-wide/16 v0, 0xfa0

    .line 21
    .line 22
    invoke-virtual {v2, p0, v0, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->startMonitoringAfterDelay(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    .line 24
    .line 25
    :cond_1
    monitor-exit p0

    .line 26
    return-void

    .line 27
    :catchall_0
    move-exception v0

    .line 28
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 29
    throw v0
.end method

.method public stop(Lcom/facebook/acra/anr/IANRDetector$ANRDetectorStopListener;)V
    .locals 1

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->mAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->stopMonitoring()V

    .line 4
    .line 5
    .line 6
    monitor-exit p0

    .line 7
    if-eqz p1, :cond_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    .line 9
    invoke-interface {p1}, Lcom/facebook/acra/anr/IANRDetector$ANRDetectorStopListener;->onStop()V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 15
    throw v0
.end method
