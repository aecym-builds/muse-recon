.class public Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;


# direct methods
.method public constructor <init>(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;->this$0:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector$2;->this$0:Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;->-$$Nest$mendAndProcessANRDataCapture(Lcom/facebook/acra/anr/processmonitor/detector/ProcessErrorMonitorANRDetector;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
