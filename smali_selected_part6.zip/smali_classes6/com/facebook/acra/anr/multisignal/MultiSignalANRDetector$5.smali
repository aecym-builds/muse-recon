.class public Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

.field public final synthetic val$curTime:J

.field public final synthetic val$inForegroundV1:Z

.field public final synthetic val$inForegroundV2:Z

.field public final synthetic val$logData:Ljava/lang/String;

.field public final synthetic val$tracesFileName:Ljava/lang/String;

.field public final synthetic val$uptime:J


# direct methods
.method public constructor <init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;JLjava/lang/String;JZZ)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    iput-object p2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$tracesFileName:Ljava/lang/String;

    .line 1
    .line 2
    iput-wide p3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$uptime:J

    .line 3
    .line 4
    iput-object p5, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$logData:Ljava/lang/String;

    .line 5
    .line 6
    iput-wide p6, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$curTime:J

    .line 7
    .line 8
    iput-boolean p8, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$inForegroundV1:Z

    .line 9
    .line 10
    iput-boolean p9, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$inForegroundV2:Z

    .line 11
    .line 12
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 13
    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 1
    .line 2
    invoke-static {v3}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$mgetActionOnSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;->IGNORE:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 7
    .line 8
    if-ne v2, v0, :cond_2

    .line 9
    .line 10
    iget-object v1, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 11
    .line 12
    const-string v0, "Ignoring new sigquit"

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$tracesFileName:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-static {v0}, LX/EYt;->A0N(Ljava/lang/String;)Ljava/io/File;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 26
    .line 27
    .line 28
    :cond_0
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 29
    .line 30
    iget-object v0, v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 31
    .line 32
    invoke-interface {v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->cleanupAppStateFile()V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 36
    .line 37
    iget-boolean v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 38
    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    iget-object v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 42
    .line 43
    iget-object v2, v0, LX/Fvc;->A03:LX/Ft8;

    .line 44
    .line 45
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$uptime:J

    .line 46
    .line 47
    iput-wide v0, v2, LX/Ft8;->A06:J

    .line 48
    .line 49
    invoke-static {v2}, LX/Ft8;->A00(LX/Ft8;)V

    .line 50
    .line 51
    .line 52
    :cond_1
    return-void

    .line 53
    :cond_2
    iget-wide v0, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedTime:J

    .line 54
    .line 55
    iput-wide v0, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 56
    .line 57
    iget-wide v0, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedUptime:J

    .line 58
    .line 59
    iput-wide v0, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 60
    .line 61
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;->CLEAR_CURRENT_ERROR_STATE:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 62
    .line 63
    iget-object v1, v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 64
    .line 65
    if-ne v2, v0, :cond_3

    .line 66
    .line 67
    const-string v0, "Will clear error state"

    .line 68
    .line 69
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 73
    .line 74
    invoke-static {v0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$merrorCleared(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 75
    .line 76
    .line 77
    :goto_0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 78
    .line 79
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$uptime:J

    .line 80
    .line 81
    iput-wide v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackUptime:J

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$logData:Ljava/lang/String;

    .line 84
    .line 85
    iput-object v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitData:Ljava/lang/String;

    .line 86
    .line 87
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$tracesFileName:Ljava/lang/String;

    .line 88
    .line 89
    iput-object v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 90
    .line 91
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$curTime:J

    .line 92
    .line 93
    iput-wide v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackTime:J

    .line 94
    .line 95
    sget-object v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 96
    .line 97
    iget-boolean v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$inForegroundV1:Z

    .line 98
    .line 99
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$inForegroundV2:Z

    .line 100
    .line 101
    invoke-virtual {v2, v3, v1, v0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;ZZ)V

    .line 102
    .line 103
    .line 104
    iget-wide v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->val$uptime:J

    .line 105
    .line 106
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 107
    .line 108
    iget-object v0, v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 109
    .line 110
    invoke-virtual {v0}, LX/Fvc;->A00()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-static {v1, v2, v0}, Lcom/facebook/acra/anr/SigquitRecord;->updateRecords(JLjava/lang/String;)V

    .line 115
    .line 116
    .line 117
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 118
    .line 119
    invoke-static {v0, v3}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$mmaybeStartReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :cond_3
    const-string v0, "Will start new report"

    .line 124
    .line 125
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    goto :goto_0
.end method
