.class public Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public mUptimeMillisWhenSomethingCouldRunOnMainThread:J

.field public final synthetic this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;


# direct methods
.method public constructor <init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    iput-boolean v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForMainThreadBlockedCheck:Z

    .line 4
    .line 5
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->MT_UNBLOCKED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 11
    .line 12
    iget-boolean v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 17
    .line 18
    iget-object v2, v0, LX/Fvc;->A03:LX/Ft8;

    .line 19
    .line 20
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->mUptimeMillisWhenSomethingCouldRunOnMainThread:J

    .line 21
    .line 22
    iput-wide v0, v2, LX/Ft8;->A07:J

    .line 23
    .line 24
    invoke-static {v2}, LX/Ft8;->A00(LX/Ft8;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 28
    .line 29
    invoke-static {v1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$misCurrentStateNoAnrDetected(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-static {v1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$merrorCleared(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    return-void
.end method

.method public setUptimeMillis(J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->mUptimeMillisWhenSomethingCouldRunOnMainThread:J

    .line 1
    .line 2
    return-void
.end method
