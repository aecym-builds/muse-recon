.class public Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

.field public final synthetic val$appStateUpdater:LX/Fug;


# direct methods
.method public constructor <init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;LX/Fug;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    iput-object p2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;->val$appStateUpdater:LX/Fug;

    .line 1
    .line 2
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 0
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 5
    .line 6
    iget-boolean v0, v0, LX/Fth;->A04:Z

    .line 7
    .line 8
    if-nez v0, :cond_2

    .line 9
    .line 10
    :cond_0
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 15
    .line 16
    iget-boolean v0, v0, LX/Fth;->A04:Z

    .line 17
    .line 18
    if-nez v0, :cond_2

    .line 19
    .line 20
    :cond_1
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    iput-boolean v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mMovedToBackground:Z

    .line 24
    .line 25
    :cond_2
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;->val$appStateUpdater:LX/Fug;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 28
    .line 29
    iget-object v0, v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mForegroundTransitionListener:LX/Fv3;

    .line 30
    .line 31
    iget-object v1, v1, LX/Fug;->A00:Ljava/util/List;

    .line 32
    .line 33
    monitor-enter v1

    .line 34
    :try_start_0
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    monitor-exit v1

    .line 38
    return-void

    .line 39
    :catchall_0
    move-exception v0

    .line 40
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    throw v0
.end method
