.class public Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$7;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;


# direct methods
.method public constructor <init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$7;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$7;->this$0:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->-$$Nest$mmainThreadUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
