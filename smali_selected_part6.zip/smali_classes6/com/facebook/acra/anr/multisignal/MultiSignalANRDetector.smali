.class public Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;
.implements Lcom/facebook/acra/anr/IANRDetector;


# static fields
.field public static final MULTI_SIGNAL_DETECTOR_THREAD_NAME:Ljava/lang/String; = "MultiSignalANRDetectorThread"

.field public static final sInstances:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LX/Fvc;",
            "Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

.field public mANRReportTime:J

.field public final mAnrDetectorConfig:LX/Fvc;

.field public mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;

.field public final mAnrStagesListener:LX/FvP;

.field public final mConfirmationExpiredRunnable:Ljava/lang/Runnable;

.field public mCurrentState:LX/Ftc;

.field public mDetectorStartTime:J

.field public mDurationHistoryAtSigquitTime:LX/Epr;

.field public mDurationHistoryAtTracesAvailableTime:LX/Epr;

.field public mErrorCheckCounter:I

.field public final mErrorMonitorListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

.field public final mForegroundTransitionListener:LX/Fv3;

.field public mHasPendingReport:Z

.field public mLastSigquitReceivedTime:J

.field public mLastSigquitReceivedUptime:J

.field public mLogTag:Ljava/lang/String;

.field public mLostErrorDetectionTime:J

.field public mMovedToBackground:Z

.field public mNativeHookInPlace:Z

.field public final mNativeLibraryInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final mNativeLibraryInitializedCV:Landroid/os/ConditionVariable;

.field public final mOnMainThreadUnblockedRunnable:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

.field public volatile mPaused:Z

.field public mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

.field public mProcessAnrErrorMonitorPaused:Z

.field public final mProcessingThread:Landroid/os/HandlerThread;

.field public final mProcessingThreadHandler:Landroid/os/Handler;

.field public mRunning:Z

.field public volatile mSigQuitCode:Ljava/lang/Long;

.field public volatile mSigQuitPid:Ljava/lang/Long;

.field public volatile mSigQuitUid:Ljava/lang/Long;

.field public mSigquitCallbackTime:J

.field public mSigquitCallbackUptime:J

.field public mSigquitData:Ljava/lang/String;

.field public final mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

.field public mSigquitFileName:Ljava/lang/String;

.field public final mSigquitHook:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;",
            ">;"
        }
    .end annotation
.end field

.field public mSigquitReceivedTime:J

.field public mSigquitReceivedUptime:J

.field public final mStartStopLock:Ljava/lang/Object;

.field public mStartedInForegroundV1:Z

.field public mStartedInForegroundV2:Z

.field public mSystemErrorMessage:Ljava/lang/String;

.field public mSystemErrorTag:Ljava/lang/String;

.field public mSystemErrorUptime:J

.field public final mTracesHook:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;",
            ">;"
        }
    .end annotation
.end field

.field public mWaitingForConfirmation:Z

.field public mWaitingForMainThreadBlockedCheck:Z


# direct methods
.method public static bridge synthetic -$$Nest$fgetmAnrDetectorConfig(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)LX/Fvc;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmAnrStagesListener(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)LX/FvP;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrStagesListener:LX/FvP;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmConfirmationExpiredRunnable(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Ljava/lang/Runnable;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mConfirmationExpiredRunnable:Ljava/lang/Runnable;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmErrorCheckCounter(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mErrorCheckCounter:I

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmForegroundTransitionListener(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)LX/Fv3;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mForegroundTransitionListener:LX/Fv3;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmHasPendingReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmLastSigquitReceivedTime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedTime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static bridge synthetic -$$Nest$fgetmLastSigquitReceivedUptime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedUptime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static bridge synthetic -$$Nest$fgetmLogTag(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmLostErrorDetectionTime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLostErrorDetectionTime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static bridge synthetic -$$Nest$fgetmMovedToBackground(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mMovedToBackground:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmNativeLibraryInitializedCV(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Landroid/os/ConditionVariable;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitializedCV:Landroid/os/ConditionVariable;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmProcessAnrErrorMonitor(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmProcessAnrErrorMonitorPaused(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitorPaused:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmProcessingThreadHandler(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Landroid/os/Handler;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmRunning(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetmSigquitDetector(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Lcom/facebook/acra/anr/sigquit/SigquitDetector;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmStartStopLock(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetmWaitingForConfirmation(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForConfirmation:Z

    .line 1
    .line 2
    return p0
.end method

.method public static bridge synthetic -$$Nest$fputmErrorCheckCounter(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mErrorCheckCounter:I

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmLostErrorDetectionTime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLostErrorDetectionTime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmMovedToBackground(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mMovedToBackground:Z

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmProcessAnrErrorMonitorPaused(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitorPaused:Z

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitCallbackTime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackTime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitCallbackUptime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackUptime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitData(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitData:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitFileName(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitReceivedTime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSigquitReceivedUptime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSystemErrorMessage(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorMessage:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSystemErrorTag(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorTag:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmSystemErrorUptime(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorUptime:J

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmWaitingForConfirmation(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForConfirmation:Z

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$fputmWaitingForMainThreadBlockedCheck(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForMainThreadBlockedCheck:Z

    .line 1
    .line 2
    return-void
.end method

.method public static bridge synthetic -$$Nest$merrorCleared(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->errorCleared()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$mgetActionOnSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->getActionOnSigquit()Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$misCurrentStateNoAnrDetected(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->isCurrentStateNoAnrDetected()Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static bridge synthetic -$$Nest$misDebuggerConnected(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public static bridge synthetic -$$Nest$mmainThreadUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mainThreadUnblocked()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$mmaybeStartReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->maybeStartReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$mtriggerSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->triggerSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static constructor <clinit>()V
    .locals 1

    .line 0
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    sput-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->sInstances:Ljava/util/Map;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(LX/Fvc;LX/FvP;)V
    .locals 9

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    const-string v0, "MultiSignalANRDetector"

    .line 268435460
    .line 268435461
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 268435462
    .line 268435463
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object v0

    .line 268435467
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 268435468
    .line 268435469
    const/4 v3, 0x0

    .line 268435470
    invoke-static {v3}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 268435471
    .line 268435472
    .line 268435473
    move-result-object v0

    .line 268435474
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 268435475
    .line 268435476
    new-instance v0, Landroid/os/ConditionVariable;

    .line 268435477
    .line 268435478
    invoke-direct {v0}, Landroid/os/ConditionVariable;-><init>()V

    .line 268435479
    .line 268435480
    .line 268435481
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitializedCV:Landroid/os/ConditionVariable;

    .line 268435482
    .line 268435483
    invoke-static {}, LX/EYt;->A1B()Ljava/util/concurrent/atomic/AtomicReference;

    .line 268435484
    .line 268435485
    .line 268435486
    move-result-object v0

    .line 268435487
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 268435488
    .line 268435489
    invoke-static {}, LX/EYt;->A1B()Ljava/util/concurrent/atomic/AtomicReference;

    .line 268435490
    .line 268435491
    .line 268435492
    move-result-object v0

    .line 268435493
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mTracesHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 268435494
    .line 268435495
    const/4 v0, 0x0

    .line 268435496
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtSigquitTime:LX/Epr;

    .line 268435497
    .line 268435498
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtTracesAvailableTime:LX/Epr;

    .line 268435499
    .line 268435500
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

    .line 268435501
    .line 268435502
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 268435503
    .line 268435504
    .line 268435505
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mOnMainThreadUnblockedRunnable:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

    .line 268435506
    .line 268435507
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$1;

    .line 268435508
    .line 268435509
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$1;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 268435510
    .line 268435511
    .line 268435512
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mConfirmationExpiredRunnable:Ljava/lang/Runnable;

    .line 268435513
    .line 268435514
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$2;

    .line 268435515
    .line 268435516
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$2;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 268435517
    .line 268435518
    .line 268435519
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mErrorMonitorListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 268435520
    .line 268435521
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$3;

    .line 268435522
    .line 268435523
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$3;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 268435524
    .line 268435525
    .line 268435526
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mForegroundTransitionListener:LX/Fv3;

    .line 268435527
    .line 268435528
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 268435529
    .line 268435530
    invoke-static {p0}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->getInstance(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 268435531
    .line 268435532
    .line 268435533
    move-result-object v0

    .line 268435534
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 268435535
    .line 268435536
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 268435537
    .line 268435538
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 268435539
    .line 268435540
    iget-object v1, p1, LX/Fvc;->A01:Landroid/content/Context;

    .line 268435541
    .line 268435542
    iget-object v2, p1, LX/Fvc;->A04:Ljava/lang/String;

    .line 268435543
    .line 268435544
    const/16 v4, 0x1f4

    .line 268435545
    .line 268435546
    const/4 v5, 0x1

    .line 268435547
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 268435548
    .line 268435549
    move v6, v3

    .line 268435550
    move v7, v3

    .line 268435551
    move v8, v3

    .line 268435552
    invoke-direct/range {v0 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;-><init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V

    .line 268435553
    .line 268435554
    .line 268435555
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 268435556
    .line 268435557
    iput-object p2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrStagesListener:LX/FvP;

    .line 268435558
    .line 268435559
    const-string v1, "MultiSignalANRDetectorThread:"

    .line 268435560
    .line 268435561
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 268435562
    .line 268435563
    if-eqz v0, :cond_0

    .line 268435564
    .line 268435565
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 268435566
    .line 268435567
    iget-object v0, v0, LX/Fth;->A03:Ljava/lang/String;

    .line 268435568
    .line 268435569
    if-nez v0, :cond_1

    .line 268435570
    .line 268435571
    :cond_0
    const-string/jumbo v0, "unknown"

    .line 268435572
    .line 268435573
    .line 268435574
    :cond_1
    invoke-static {v1, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 268435575
    .line 268435576
    .line 268435577
    move-result-object v1

    .line 268435578
    new-instance v0, Landroid/os/HandlerThread;

    .line 268435579
    .line 268435580
    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 268435581
    .line 268435582
    .line 268435583
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThread:Landroid/os/HandlerThread;

    .line 268435584
    .line 268435585
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 268435586
    .line 268435587
    .line 268435588
    invoke-static {v0}, LX/EYu;->A0F(Landroid/os/HandlerThread;)Landroid/os/Handler;

    .line 268435589
    .line 268435590
    .line 268435591
    move-result-object v0

    .line 268435592
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 268435593
    .line 268435594
    return-void
.end method

.method public constructor <init>(LX/Fvc;Lcom/facebook/acra/anr/sigquit/SigquitDetector;Landroid/os/HandlerThread;LX/FvP;)V
    .locals 9

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v0, "MultiSignalANRDetector"

    .line 4
    .line 5
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 6
    .line 7
    invoke-static {}, LX/001;->A0t()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    invoke-static {v3}, LX/EYt;->A17(Z)Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    new-instance v0, Landroid/os/ConditionVariable;

    .line 21
    .line 22
    invoke-direct {v0}, Landroid/os/ConditionVariable;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitializedCV:Landroid/os/ConditionVariable;

    .line 26
    .line 27
    invoke-static {}, LX/EYt;->A1B()Ljava/util/concurrent/atomic/AtomicReference;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 32
    .line 33
    invoke-static {}, LX/EYt;->A1B()Ljava/util/concurrent/atomic/AtomicReference;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mTracesHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtSigquitTime:LX/Epr;

    .line 41
    .line 42
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtTracesAvailableTime:LX/Epr;

    .line 43
    .line 44
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

    .line 45
    .line 46
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mOnMainThreadUnblockedRunnable:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

    .line 50
    .line 51
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$1;

    .line 52
    .line 53
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$1;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 54
    .line 55
    .line 56
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mConfirmationExpiredRunnable:Ljava/lang/Runnable;

    .line 57
    .line 58
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$2;

    .line 59
    .line 60
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$2;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 61
    .line 62
    .line 63
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mErrorMonitorListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 64
    .line 65
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$3;

    .line 66
    .line 67
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$3;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 68
    .line 69
    .line 70
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mForegroundTransitionListener:LX/Fv3;

    .line 71
    .line 72
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 73
    .line 74
    iput-object p2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 75
    .line 76
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 77
    .line 78
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 79
    .line 80
    iget-object v1, p1, LX/Fvc;->A01:Landroid/content/Context;

    .line 81
    .line 82
    iget-object v2, p1, LX/Fvc;->A04:Ljava/lang/String;

    .line 83
    .line 84
    const/16 v4, 0x1f4

    .line 85
    .line 86
    const/4 v5, 0x1

    .line 87
    new-instance v0, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 88
    .line 89
    move v6, v3

    .line 90
    move v7, v3

    .line 91
    move v8, v3

    .line 92
    invoke-direct/range {v0 .. v8}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;-><init>(Landroid/content/Context;Ljava/lang/String;ZIZIII)V

    .line 93
    .line 94
    .line 95
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 96
    .line 97
    iput-object p3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThread:Landroid/os/HandlerThread;

    .line 98
    .line 99
    iput-object p4, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrStagesListener:LX/FvP;

    .line 100
    .line 101
    invoke-virtual {p3}, Ljava/lang/Thread;->start()V

    .line 102
    .line 103
    .line 104
    invoke-static {p3}, LX/EYu;->A0F(Landroid/os/HandlerThread;)Landroid/os/Handler;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 109
    .line 110
    return-void
.end method

.method private addActivityManagerConfirmationDataToReport()V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 1
    .line 2
    iget-object v4, v0, LX/Fvc;->A03:LX/Ft8;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorMessage:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorTag:Ljava/lang/String;

    .line 7
    .line 8
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorUptime:J

    .line 9
    .line 10
    iput-object v3, v4, LX/Ft8;->A0O:Ljava/lang/String;

    .line 11
    .line 12
    iput-object v2, v4, LX/Ft8;->A0P:Ljava/lang/String;

    .line 13
    .line 14
    iput-wide v0, v4, LX/Ft8;->A08:J

    .line 15
    .line 16
    invoke-static {v4}, LX/Ft8;->A00(LX/Ft8;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method private addInfoToReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 1
    .line 2
    if-ne p1, v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->addSigquitDataToReport()V

    .line 5
    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->AM_CONFIRMED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 9
    .line 10
    if-ne p1, v0, :cond_1

    .line 11
    .line 12
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->addActivityManagerConfirmationDataToReport()V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_1
    const-string v0, "Event should be SIGQUIT_RECEIVED or AM_CONFIRMED"

    .line 17
    .line 18
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    throw v0
.end method

.method private addSigquitDataToReport()V
    .locals 13

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 1
    .line 2
    iget-object v10, v0, LX/Fvc;->A03:LX/Ft8;

    .line 3
    .line 4
    iget-object v12, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitData:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 7
    .line 8
    iget-wide v7, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackUptime:J

    .line 9
    .line 10
    iget-wide v5, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackTime:J

    .line 11
    .line 12
    iget-wide v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 13
    .line 14
    iget-wide v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 15
    .line 16
    iget-object v9, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtSigquitTime:LX/Epr;

    .line 17
    .line 18
    iget-object v11, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtTracesAvailableTime:LX/Epr;

    .line 19
    .line 20
    iput-object v12, v10, LX/Ft8;->A0M:Ljava/lang/String;

    .line 21
    .line 22
    iput-object v0, v10, LX/Ft8;->A0N:Ljava/lang/String;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    iput-object v0, v10, LX/Ft8;->A0Q:Ljava/lang/String;

    .line 26
    .line 27
    const/4 v0, 0x1

    .line 28
    iput-boolean v0, v10, LX/Ft8;->A0V:Z

    .line 29
    .line 30
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iput-object v0, v10, LX/Ft8;->A0H:Ljava/lang/Long;

    .line 35
    .line 36
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    iput-object v0, v10, LX/Ft8;->A0G:Ljava/lang/Long;

    .line 41
    .line 42
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    iput-object v0, v10, LX/Ft8;->A0J:Ljava/lang/Long;

    .line 47
    .line 48
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, v10, LX/Ft8;->A0I:Ljava/lang/Long;

    .line 53
    .line 54
    iput-object v9, v10, LX/Ft8;->A0C:LX/Epr;

    .line 55
    .line 56
    iput-object v11, v10, LX/Ft8;->A0D:LX/Epr;

    .line 57
    .line 58
    invoke-static {v10}, LX/Ft8;->A00(LX/Ft8;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method private errorCleared()V
    .locals 5

    .line 0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 1
    .line 2
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 3
    .line 4
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v4, 0x0

    .line 9
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v0, "Clearing error state has pending report %b"

    .line 14
    .line 15
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 23
    .line 24
    .line 25
    move-result-wide v2

    .line 26
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportTime:J

    .line 27
    .line 28
    sub-long/2addr v2, v0

    .line 29
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 30
    .line 31
    iget-object v0, v0, LX/Fvc;->A03:LX/Ft8;

    .line 32
    .line 33
    iput-wide v2, v0, LX/Ft8;->A0B:J

    .line 34
    .line 35
    invoke-static {v0}, LX/Ft8;->A00(LX/Ft8;)V

    .line 36
    .line 37
    .line 38
    iput-boolean v4, v0, LX/Ft8;->A0R:Z

    .line 39
    .line 40
    iput-boolean v4, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 41
    .line 42
    :cond_0
    const/4 v2, 0x0

    .line 43
    iput-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorMessage:Ljava/lang/String;

    .line 44
    .line 45
    iput-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorTag:Ljava/lang/String;

    .line 46
    .line 47
    const-wide/16 v0, 0x0

    .line 48
    .line 49
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSystemErrorUptime:J

    .line 50
    .line 51
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 52
    .line 53
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 54
    .line 55
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackUptime:J

    .line 56
    .line 57
    iput-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitData:Ljava/lang/String;

    .line 58
    .line 59
    iput-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 60
    .line 61
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackTime:J

    .line 62
    .line 63
    return-void
.end method

.method private getActionOnSigquit()Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 1
    .line 2
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 3
    .line 4
    if-eq p0, v0, :cond_0

    .line 5
    .line 6
    sget-object v0, LX/Ftc;->A05:LX/Ftc;

    .line 7
    .line 8
    if-eq p0, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, LX/Ftc;->A06:LX/Ftc;

    .line 11
    .line 12
    if-eq p0, v0, :cond_0

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;->IGNORE:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;->START_REPORT:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$ActionOnSigquit;

    .line 18
    .line 19
    return-object v0
.end method

.method public static getInstance(LX/Fvc;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->getInstance(LX/Fvc;LX/FvP;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static getInstance(LX/Fvc;LX/FvP;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;
    .locals 3

    .line 268435456
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->sInstances:Ljava/util/Map;

    .line 268435457
    .line 268435458
    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object v2

    .line 268435462
    check-cast v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 268435463
    .line 268435464
    if-nez v2, :cond_0

    .line 268435465
    .line 268435466
    new-instance v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 268435467
    .line 268435468
    invoke-direct {v2, p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;-><init>(LX/Fvc;LX/FvP;)V

    .line 268435469
    .line 268435470
    .line 268435471
    invoke-interface {v0, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435472
    .line 268435473
    .line 268435474
    :cond_0
    const-string v1, "Lacrima"

    .line 268435475
    .line 268435476
    const-string v0, "MultiSignalANRDetector"

    .line 268435477
    .line 268435478
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 268435479
    .line 268435480
    .line 268435481
    move-result-object v0

    .line 268435482
    iput-object v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 268435483
    .line 268435484
    return-object v2
.end method

.method public static getTestInstance(LX/Fvc;Lcom/facebook/acra/anr/sigquit/SigquitDetector;Landroid/os/HandlerThread;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public static getTestInstance(LX/Fvc;Lcom/facebook/acra/anr/sigquit/SigquitDetector;Landroid/os/HandlerThread;LX/FvP;)Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;
    .locals 0

    .line 268435456
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    throw p0
.end method

.method public static getTraceDataFromHook(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->sInstances:Ljava/util/Map;

    .line 1
    .line 2
    invoke-static {v0}, LX/007;->A13(Ljava/util/Map;)Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;

    .line 17
    .line 18
    iget-object v0, v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-direct {v1, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->triggerSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void

    .line 30
    :cond_1
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$8;

    .line 31
    .line 32
    invoke-direct {v0, v1, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$8;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method private isCurrentStateNoAnrDetected()Z
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 1
    .line 2
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 3
    .line 4
    invoke-static {p0, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method private isCurrentStateUnconfirmed()Z
    .locals 2

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 1
    .line 2
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 3
    .line 4
    if-eq p0, v0, :cond_0

    .line 5
    .line 6
    sget-object v1, LX/Ftc;->A0B:LX/Ftc;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    if-ne p0, v1, :cond_1

    .line 10
    .line 11
    :cond_0
    const/4 v0, 0x1

    .line 12
    :cond_1
    return v0
.end method

.method private isDebuggerConnected()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public static isTest()Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    return v0
.end method

.method private logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 3
    .line 4
    filled-new-array {p1, v0}, [Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-string v0, "Unexpected event %s received in state %s"

    .line 9
    .line 10
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 14
    .line 15
    if-eq p1, v0, :cond_0

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    const-string v0, "Unexpected event "

    .line 22
    .line 23
    invoke-static {p1, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v0, " received in state "

    .line 28
    .line 29
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/002;->A0z(Ljava/lang/Object;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const-string v0, "Unexpected event"

    .line 43
    .line 44
    invoke-interface {v2, v0, v1}, Lcom/facebook/acra/anr/ANRReportProvider;->reportSoftError(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    return-void
.end method

.method private mainThreadUnblocked()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 1
    .line 2
    const-string v0, "Running on the main thread"

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mOnMainThreadUnblockedRunnable:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;

    .line 8
    .line 9
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    iput-wide v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$OnMainThreadUnblockedRunnable;->mUptimeMillisWhenSomethingCouldRunOnMainThread:J

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 16
    .line 17
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method private maybeStartMainThreadBlockedCheck()V
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForMainThreadBlockedCheck:Z

    .line 1
    .line 2
    if-nez v0, :cond_1

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 5
    .line 6
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 7
    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, LX/Ftc;->A05:LX/Ftc;

    .line 11
    .line 12
    if-ne v1, v0, :cond_1

    .line 13
    .line 14
    :cond_0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 15
    .line 16
    const-string v0, "Posting main thread check"

    .line 17
    .line 18
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForMainThreadBlockedCheck:Z

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 25
    .line 26
    iget-object v1, v0, LX/Fvc;->A02:Landroid/os/Handler;

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$7;

    .line 29
    .line 30
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$7;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 34
    .line 35
    .line 36
    :cond_1
    return-void
.end method

.method private maybeStartReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 4

    .line 0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 1
    .line 2
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 3
    .line 4
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v3, 0x0

    .line 9
    filled-new-array {p1, v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v0, "On maybeStartReport event: %s has pending report %b"

    .line 14
    .line 15
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->addInfoToReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :cond_1
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV2:Z

    .line 27
    .line 28
    if-nez v0, :cond_2

    .line 29
    .line 30
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV1:Z

    .line 31
    .line 32
    if-eqz v0, :cond_4

    .line 33
    .line 34
    :cond_2
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->shouldUploadAnrReports()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->maybeStartTimerForActivityManagerConfirmation()V

    .line 39
    .line 40
    .line 41
    if-eqz v0, :cond_3

    .line 42
    .line 43
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 44
    .line 45
    const-string v0, "Reporting ANR start"

    .line 46
    .line 47
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_3
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 52
    .line 53
    iget-object v2, v0, LX/Fvc;->A03:LX/Ft8;

    .line 54
    .line 55
    iget-boolean v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV1:Z

    .line 56
    .line 57
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV2:Z

    .line 58
    .line 59
    iput-boolean v1, v2, LX/Ft8;->A0S:Z

    .line 60
    .line 61
    iput-boolean v0, v2, LX/Ft8;->A0T:Z

    .line 62
    .line 63
    invoke-static {v2}, LX/Ft8;->A00(LX/Ft8;)V

    .line 64
    .line 65
    .line 66
    :cond_4
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 67
    .line 68
    if-ne p1, v0, :cond_0

    .line 69
    .line 70
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 71
    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    invoke-static {v0}, LX/EYt;->A0N(Ljava/lang/String;)Ljava/io/File;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 79
    .line 80
    .line 81
    return-void

    .line 82
    :goto_0
    :try_start_0
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->startReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 83
    .line 84
    .line 85
    return-void
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    :catch_0
    move-exception v2

    .line 87
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 88
    .line 89
    const-string v0, "Error starting ANR report"

    .line 90
    .line 91
    invoke-static {v1, v2, v0}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    iput-boolean v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 95
    .line 96
    return-void
.end method

.method private maybeStartTimerForActivityManagerConfirmation()V
    .locals 4

    .line 0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForConfirmation:Z

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->isCurrentStateUnconfirmed()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 11
    .line 12
    const-string v0, "Starting timer for AM confirmation"

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mWaitingForConfirmation:Z

    .line 19
    .line 20
    iget-object v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 21
    .line 22
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mConfirmationExpiredRunnable:Ljava/lang/Runnable;

    .line 23
    .line 24
    const-wide/16 v0, 0x7530

    .line 25
    .line 26
    invoke-virtual {v3, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method private setASLState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;ZZ)V
    .locals 6

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 1
    .line 2
    invoke-static {p1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v5

    .line 6
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 7
    .line 8
    iget-object v4, v0, LX/Fvc;->A00:LX/Fug;

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    if-eqz v5, :cond_0

    .line 12
    .line 13
    new-instance v3, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$6;

    .line 14
    .line 15
    invoke-direct {v3, p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$6;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 19
    .line 20
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 21
    .line 22
    if-eq v1, v0, :cond_1

    .line 23
    .line 24
    sget-object v0, LX/Ftc;->A05:LX/Ftc;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    if-ne v1, v0, :cond_2

    .line 28
    .line 29
    :cond_1
    const/4 v2, 0x1

    .line 30
    :cond_2
    if-eqz v5, :cond_5

    .line 31
    .line 32
    if-eqz v2, :cond_5

    .line 33
    .line 34
    check-cast v4, LX/Fuf;

    .line 35
    .line 36
    iget-object v0, v4, LX/Fuf;->A00:LX/FtB;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/FtB;->A00(LX/FtB;LX/Ftc;)V

    .line 39
    .line 40
    .line 41
    if-eqz v3, :cond_3

    .line 42
    .line 43
    invoke-virtual {v3}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$6;->run()V

    .line 44
    .line 45
    .line 46
    :cond_3
    :goto_0
    iput-boolean p2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV1:Z

    .line 47
    .line 48
    iput-boolean p3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV2:Z

    .line 49
    .line 50
    :cond_4
    return-void

    .line 51
    :cond_5
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 52
    .line 53
    if-nez v0, :cond_8

    .line 54
    .line 55
    const/4 p3, 0x0

    .line 56
    :goto_1
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 57
    .line 58
    if-nez v0, :cond_7

    .line 59
    .line 60
    const/4 p2, 0x0

    .line 61
    :goto_2
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 62
    .line 63
    check-cast v4, LX/Fuf;

    .line 64
    .line 65
    iget-object v0, v4, LX/Fuf;->A00:LX/FtB;

    .line 66
    .line 67
    invoke-static {v0, v1}, LX/FtB;->A00(LX/FtB;LX/Ftc;)V

    .line 68
    .line 69
    .line 70
    if-eqz v3, :cond_6

    .line 71
    .line 72
    invoke-virtual {v3}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$6;->run()V

    .line 73
    .line 74
    .line 75
    :cond_6
    if-eqz v2, :cond_4

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_7
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 79
    .line 80
    iget-boolean p2, v0, LX/Fth;->A04:Z

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_8
    sget-object v0, LX/Ftt;->A04:LX/Fth;

    .line 84
    .line 85
    iget-boolean p3, v0, LX/Fth;->A04:Z

    .line 86
    .line 87
    goto :goto_1
.end method

.method private setCurrentAnrStateFromNoAnrDetected(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_2

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    if-eq v1, v0, :cond_1

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq v1, v0, :cond_0

    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void

    .line 16
    :cond_1
    sget-object v0, LX/Ftc;->A05:LX/Ftc;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_2
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 20
    .line 21
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 22
    .line 23
    return-void
.end method

.method private setCurrentAnrStateFromNoSigquitAmConfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_1

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    if-eq v1, v0, :cond_2

    .line 8
    .line 9
    const/4 v0, 0x4

    .line 10
    if-eq v1, v0, :cond_0

    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    sget-object v0, LX/Ftc;->A07:LX/Ftc;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    sget-object v0, LX/Ftc;->A06:LX/Ftc;

    .line 23
    .line 24
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 25
    .line 26
    return-void
.end method

.method private setCurrentAnrStateFromNoSigquitAmConfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_1

    .line 5
    .line 6
    const/4 v0, 0x4

    .line 7
    if-eq v1, v0, :cond_0

    .line 8
    .line 9
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_1
    sget-object v0, LX/Ftc;->A08:LX/Ftc;

    .line 17
    .line 18
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 19
    .line 20
    return-void
.end method

.method private setCurrentAnrStateFromSigquitReceivedAmConfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    const/4 v0, 0x3

    .line 5
    if-eq v1, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x4

    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_1
    sget-object v0, LX/Ftc;->A08:LX/Ftc;

    .line 18
    .line 19
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 20
    .line 21
    return-void
.end method

.method private setCurrentAnrStateFromSigquitReceivedAmConfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    const/4 v0, 0x4

    .line 5
    if-eq v1, v0, :cond_0

    .line 6
    .line 7
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 12
    .line 13
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 14
    .line 15
    return-void
.end method

.method private setCurrentAnrStateFromSigquitReceivedAmExpiredMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_1

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    if-eq v1, v0, :cond_2

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq v1, v0, :cond_0

    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    sget-object v0, LX/Ftc;->A07:LX/Ftc;

    .line 23
    .line 24
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 25
    .line 26
    return-void
.end method

.method private setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    if-eq v1, v0, :cond_2

    .line 8
    .line 9
    const/4 v0, 0x2

    .line 10
    if-eq v1, v0, :cond_3

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    if-eq v1, v0, :cond_1

    .line 14
    .line 15
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void

    .line 19
    :cond_1
    sget-object v0, LX/Ftc;->A0B:LX/Ftc;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    sget-object v0, LX/Ftc;->A07:LX/Ftc;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_3
    sget-object v0, LX/Ftc;->A09:LX/Ftc;

    .line 26
    .line 27
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 28
    .line 29
    return-void
.end method

.method private setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    if-eqz v1, :cond_1

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    if-eq v1, v0, :cond_2

    .line 8
    .line 9
    const/4 v0, 0x2

    .line 10
    if-eq v1, v0, :cond_0

    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->logUnexpectedStateTransition(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    sget-object v0, LX/Ftc;->A0A:LX/Ftc;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    sget-object v0, LX/Ftc;->A08:LX/Ftc;

    .line 23
    .line 24
    :goto_0
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 25
    .line 26
    return-void
.end method

.method private shouldUploadAnrReports()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-interface {p0}, Lcom/facebook/acra/anr/ANRReportProvider;->shouldCollectAndUploadANRReports()Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0

    .line 9
    :cond_0
    const/4 p0, 0x1

    .line 10
    return p0
.end method

.method private startReport(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 39

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object/from16 v5, p0

    .line 2
    .line 3
    iput-boolean v0, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mHasPendingReport:Z

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iput-wide v0, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportTime:J

    .line 10
    .line 11
    iget-object v7, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;

    .line 12
    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v7, :cond_5

    .line 15
    .line 16
    invoke-interface {v7}, Lcom/facebook/acra/anr/ANRDetectorListener;->getBlackBoxTraceId()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v29

    .line 20
    invoke-interface {v7}, Lcom/facebook/acra/anr/ANRDetectorListener;->getLongStallTraceId()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v30

    .line 24
    invoke-interface {v7}, Lcom/facebook/acra/anr/ANRDetectorListener;->onStartANRDataCapture()V

    .line 25
    .line 26
    .line 27
    :goto_0
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->SIGQUIT_RECEIVED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 28
    .line 29
    const-wide/16 v16, 0x0

    .line 30
    .line 31
    move-object/from16 v13, p1

    .line 32
    .line 33
    if-ne v13, v0, :cond_4

    .line 34
    .line 35
    iget-object v6, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitData:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v4, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitFileName:Ljava/lang/String;

    .line 38
    .line 39
    iget-wide v0, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackUptime:J

    .line 40
    .line 41
    iget-wide v2, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitCallbackTime:J

    .line 42
    .line 43
    iget-wide v8, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 44
    .line 45
    iget-wide v11, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 46
    .line 47
    if-nez v6, :cond_3

    .line 48
    .line 49
    if-nez v4, :cond_3

    .line 50
    .line 51
    :goto_1
    invoke-static {}, LX/EYt;->A0L()Ljava/io/ByteArrayOutputStream;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    invoke-static {v6}, Lcom/facebook/acra/anr/StackTraceDumper;->dumpStackTraces(Ljava/io/OutputStream;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    const/16 p1, 0x0

    .line 63
    .line 64
    :goto_2
    iget-object v10, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 65
    .line 66
    iget-object v10, v10, LX/Fvc;->A03:LX/Ft8;

    .line 67
    .line 68
    move-object/from16 v19, v10

    .line 69
    .line 70
    iget-object v10, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 71
    .line 72
    invoke-static {v10}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v37

    .line 76
    iget-boolean v10, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV1:Z

    .line 77
    .line 78
    move/from16 v18, v10

    .line 79
    .line 80
    iget-boolean v10, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartedInForegroundV2:Z

    .line 81
    .line 82
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 83
    .line 84
    .line 85
    move-result-wide v33

    .line 86
    iget-wide v14, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDetectorStartTime:J

    .line 87
    .line 88
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 89
    .line 90
    .line 91
    move-result-object v22

    .line 92
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 93
    .line 94
    .line 95
    move-result-object v23

    .line 96
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 97
    .line 98
    .line 99
    move-result-object v24

    .line 100
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 101
    .line 102
    .line 103
    move-result-object v25

    .line 104
    iget-object v9, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtSigquitTime:LX/Epr;

    .line 105
    .line 106
    iget-object v8, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtTracesAvailableTime:LX/Epr;

    .line 107
    .line 108
    iget-object v3, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 109
    .line 110
    iget-object v2, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitCode:Ljava/lang/Long;

    .line 111
    .line 112
    iget-object v1, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitPid:Ljava/lang/Long;

    .line 113
    .line 114
    iget-object v0, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitUid:Ljava/lang/Long;

    .line 115
    .line 116
    move-object/from16 v26, v2

    .line 117
    .line 118
    move-object/from16 v27, v1

    .line 119
    .line 120
    move-object/from16 v28, v0

    .line 121
    .line 122
    move-object/from16 v31, v6

    .line 123
    .line 124
    move-object/from16 v32, v4

    .line 125
    .line 126
    move-wide/from16 v35, v14

    .line 127
    .line 128
    move/from16 v38, v18

    .line 129
    .line 130
    move/from16 p0, v10

    .line 131
    .line 132
    move-object/from16 v18, v19

    .line 133
    .line 134
    move-object/from16 v19, v9

    .line 135
    .line 136
    move-object/from16 v20, v8

    .line 137
    .line 138
    move-object/from16 v21, v3

    .line 139
    .line 140
    invoke-virtual/range {v18 .. v40}, LX/Ft8;->A01(LX/Epr;LX/Epr;LX/Ftc;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJZZZZ)V

    .line 141
    .line 142
    .line 143
    sget-object v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;->AM_CONFIRMED:Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;

    .line 144
    .line 145
    if-ne v13, v0, :cond_0

    .line 146
    .line 147
    invoke-direct {v5}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->addActivityManagerConfirmationDataToReport()V

    .line 148
    .line 149
    .line 150
    :cond_0
    iget-wide v2, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLostErrorDetectionTime:J

    .line 151
    .line 152
    cmp-long v0, v2, v16

    .line 153
    .line 154
    if-eqz v0, :cond_1

    .line 155
    .line 156
    iget-object v0, v5, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 157
    .line 158
    iget-object v1, v0, LX/Fvc;->A03:LX/Ft8;

    .line 159
    .line 160
    const/4 v0, 0x3

    .line 161
    iput-wide v2, v1, LX/Ft8;->A09:J

    .line 162
    .line 163
    iput v0, v1, LX/Ft8;->A01:I

    .line 164
    .line 165
    invoke-static {v1}, LX/Ft8;->A00(LX/Ft8;)V

    .line 166
    .line 167
    .line 168
    :cond_1
    if-eqz v7, :cond_2

    .line 169
    .line 170
    invoke-interface {v7}, Lcom/facebook/acra/anr/ANRDetectorListener;->onEndANRDataCapture()V

    .line 171
    .line 172
    .line 173
    :cond_2
    return-void

    .line 174
    :cond_3
    const/16 p1, 0x1

    .line 175
    .line 176
    goto :goto_2

    .line 177
    :cond_4
    const-wide/16 v11, 0x0

    .line 178
    .line 179
    const-wide/16 v0, 0x0

    .line 180
    .line 181
    const-wide/16 v2, 0x0

    .line 182
    .line 183
    const-wide/16 v8, 0x0

    .line 184
    .line 185
    goto/16 :goto_1

    .line 186
    .line 187
    :cond_5
    move-object/from16 v29, v4

    .line 188
    .line 189
    move-object/from16 v30, v4

    .line 190
    .line 191
    goto/16 :goto_0
.end method

.method private triggerSigquit(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 6
    .line 7
    invoke-interface {v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->doNotIgnoreNextSiguit()V

    .line 8
    .line 9
    .line 10
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    const/4 v0, 0x3

    .line 15
    invoke-static {p0, v0}, Landroid/os/Process;->sendSignal(II)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public getANRReceivedTime()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedTime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public getANRReceivedUpTime()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitReceivedUptime:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public getCurrentState()LX/Ftc;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public getErrorMonitorListener()Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public nativeLibraryLoaded(Z)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->shouldUploadAnrReports()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-interface {v2, v1, v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->init(LX/Fvc;Z)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 14
    .line 15
    invoke-interface {v1, v0, p1}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->installSignalHandler(Landroid/os/Handler;Z)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitialized:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeLibraryInitializedCV:Landroid/os/ConditionVariable;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/os/ConditionVariable;->open()V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public onHookedMethods(Z)V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v1

    .line 3
    :try_start_0
    iput-boolean p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeHookInPlace:Z

    .line 4
    .line 5
    monitor-exit v1

    .line 6
    return-void

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    throw v0
.end method

.method public onSigquit(ZJJJ)V
    .locals 2

    .line 0
    :try_start_0
    const-string v0, "SigquitDetected"

    .line 1
    .line 2
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mPaused:Z

    .line 6
    .line 7
    if-nez v0, :cond_2

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mTracesHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedUptime:J

    .line 31
    .line 32
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 33
    .line 34
    .line 35
    move-result-wide v0

    .line 36
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLastSigquitReceivedTime:J

    .line 37
    .line 38
    if-eqz p1, :cond_1

    .line 39
    .line 40
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitCode:Ljava/lang/Long;

    .line 45
    .line 46
    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitPid:Ljava/lang/Long;

    .line 51
    .line 52
    invoke-static {p6, p7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigQuitUid:Ljava/lang/Long;

    .line 57
    .line 58
    :cond_1
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 59
    .line 60
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->getDurationHistory()LX/Epr;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtSigquitTime:LX/Epr;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 65
    .line 66
    :cond_2
    :goto_0
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :catchall_0
    move-exception v0

    .line 71
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 72
    .line 73
    .line 74
    throw v0
.end method

.method public onSigquitTracesAvailable(Ljava/lang/String;Ljava/lang/String;ZZ)V
    .locals 8

    .line 0
    :try_start_0
    const-string v0, "Sigquit traces available"

    .line 1
    .line 2
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    move-object v2, p0

    .line 6
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mPaused:Z

    .line 7
    .line 8
    if-nez v0, :cond_2

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 11
    .line 12
    const-string v0, "On onSigquitTracesAvailable call"

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 18
    .line 19
    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 20
    :try_start_1
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    monitor-exit v1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    :try_start_2
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mTracesHook:Ljava/util/concurrent/atomic/AtomicReference;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;

    .line 35
    .line 36
    move-object v3, p2

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    invoke-interface {v0, p2}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$TraceDataHook;->handleTracesExternally(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 44
    .line 45
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->getDurationHistory()LX/Epr;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    iput-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDurationHistoryAtTracesAvailableTime:LX/Epr;

    .line 50
    .line 51
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 52
    .line 53
    .line 54
    move-result-wide v4

    .line 55
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 56
    .line 57
    .line 58
    move-result-wide v7

    .line 59
    iget-object v0, v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 60
    .line 61
    new-instance v1, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;

    .line 62
    .line 63
    move-object v6, p1

    .line 64
    move p1, p3

    .line 65
    move p2, p4

    .line 66
    invoke-direct/range {v1 .. v10}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$5;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;Ljava/lang/String;JLjava/lang/String;JZZ)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 70
    .line 71
    .line 72
    goto :goto_0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 73
    :catchall_0
    move-exception v0

    .line 74
    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 75
    :try_start_4
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 76
    :cond_2
    :goto_0
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :catchall_1
    move-exception v0

    .line 81
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 82
    .line 83
    .line 84
    throw v0
.end method

.method public pause()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mPaused:Z

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->pause()V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->stopDetector()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public resume()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mPaused:Z

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->resume()V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 9
    .line 10
    invoke-interface {v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->startDetector()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public setANRReportProvider(Lcom/facebook/acra/anr/ANRReportProvider;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mANRReportProvider:Lcom/facebook/acra/anr/ANRReportProvider;

    .line 1
    .line 2
    return-void
.end method

.method public setAnrErrorMonitor(Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;)V
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public setCheckIntervalMs(J)V
    .locals 0

    .line 0
    return-void
.end method

.method public setCurrentAnrState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-virtual {p0, p1, v0, v0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;ZZ)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public setCurrentAnrState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;ZZ)V
    .locals 4

    .line 268435456
    iget-object v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 268435459
    .line 268435460
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v1

    .line 268435464
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object v0

    .line 268435468
    filled-new-array {v2, p1, v1, v0}, [Ljava/lang/Object;

    .line 268435469
    .line 268435470
    .line 268435471
    move-result-object v1

    .line 268435472
    const-string v0, "Transitioning from %s event %s inFgV1: %b inFgV2: %b"

    .line 268435473
    .line 268435474
    invoke-static {v3, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 268435475
    .line 268435476
    .line 268435477
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 268435478
    .line 268435479
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 268435480
    .line 268435481
    .line 268435482
    move-result v0

    .line 268435483
    packed-switch v0, :pswitch_data_0

    .line 268435484
    .line 268435485
    .line 268435486
    :pswitch_0
    const-string v0, "Unknown state: "

    .line 268435487
    .line 268435488
    invoke-static {v1, v0}, LX/EYy;->A0h(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 268435489
    .line 268435490
    .line 268435491
    move-result-object v0

    .line 268435492
    throw v0

    .line 268435493
    :pswitch_1
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromNoAnrDetected(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435494
    .line 268435495
    .line 268435496
    goto :goto_0

    .line 268435497
    :pswitch_2
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435498
    .line 268435499
    .line 268435500
    goto :goto_0

    .line 268435501
    :pswitch_3
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromSigquitReceivedAmConfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435502
    .line 268435503
    .line 268435504
    goto :goto_0

    .line 268435505
    :pswitch_4
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromSigquitReceivedAmConfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435506
    .line 268435507
    .line 268435508
    goto :goto_0

    .line 268435509
    :pswitch_5
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromNoSigquitAmConfirmedMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435510
    .line 268435511
    .line 268435512
    goto :goto_0

    .line 268435513
    :pswitch_6
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromNoSigquitAmConfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435514
    .line 268435515
    .line 268435516
    goto :goto_0

    .line 268435517
    :pswitch_7
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromSigquitReceivedAmUnconfirmedMtUnblocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435518
    .line 268435519
    .line 268435520
    goto :goto_0

    .line 268435521
    :pswitch_8
    invoke-direct {p0, p1}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setCurrentAnrStateFromSigquitReceivedAmExpiredMtBlocked(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;)V

    .line 268435522
    .line 268435523
    .line 268435524
    :goto_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->setASLState(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$Event;ZZ)V

    .line 268435525
    .line 268435526
    .line 268435527
    invoke-direct {p0}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->maybeStartMainThreadBlockedCheck()V

    .line 268435528
    .line 268435529
    .line 268435530
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mCurrentState:LX/Ftc;

    .line 268435531
    .line 268435532
    if-eq v1, v2, :cond_0

    .line 268435533
    .line 268435534
    sget-object v0, LX/Ftc;->A04:LX/Ftc;

    .line 268435535
    .line 268435536
    if-eq v1, v0, :cond_0

    .line 268435537
    .line 268435538
    if-eq v2, v0, :cond_0

    .line 268435539
    .line 268435540
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 268435541
    .line 268435542
    iget-object v1, v0, LX/Fvc;->A03:LX/Ft8;

    .line 268435543
    .line 268435544
    iput-object v2, v1, LX/Ft8;->A0E:LX/Ftc;

    .line 268435545
    .line 268435546
    iget-boolean v0, v1, LX/Ft8;->A0R:Z

    .line 268435547
    .line 268435548
    if-eqz v0, :cond_0

    .line 268435549
    .line 268435550
    invoke-static {v1}, LX/Ft8;->A00(LX/Ft8;)V

    .line 268435551
    .line 268435552
    .line 268435553
    :cond_0
    return-void

    .line 268435554
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_7
        :pswitch_8
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method public setInternalState(LX/Ftc;)V
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public setListener(Lcom/facebook/acra/anr/ANRDetectorListener;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorListener:Lcom/facebook/acra/anr/ANRDetectorListener;

    .line 1
    .line 2
    return-void
.end method

.method public start()V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v4

    .line 3
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 8
    .line 9
    const-string v0, "Starting"

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 16
    .line 17
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    iput-wide v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mDetectorStartTime:J

    .line 22
    .line 23
    iget-object v3, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 24
    .line 25
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mErrorMonitorListener:Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;

    .line 26
    .line 27
    const-wide/16 v0, 0x0

    .line 28
    .line 29
    invoke-virtual {v3, v2, v0, v1}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->startMonitoringAfterDelay(Lcom/facebook/acra/anr/processmonitor/ProcessErrorStateListener;J)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 33
    .line 34
    iget-object v2, v0, LX/Fvc;->A00:LX/Fug;

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 37
    .line 38
    new-instance v0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;

    .line 39
    .line 40
    invoke-direct {v0, p0, v2}, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$4;-><init>(Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;LX/Fug;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    :cond_0
    monitor-exit v4

    .line 47
    return-void

    .line 48
    :catchall_0
    move-exception v0

    .line 49
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 50
    throw v0
.end method

.method public startForTesting()V
    .locals 0

    .line 0
    invoke-static {}, LX/EYu;->A0W()Ljava/lang/AssertionError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    throw p0
.end method

.method public stop(Lcom/facebook/acra/anr/IANRDetector$ANRDetectorStopListener;)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mStartStopLock:Ljava/lang/Object;

    .line 1
    .line 2
    monitor-enter v2

    .line 3
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mLogTag:Ljava/lang/String;

    .line 8
    .line 9
    const-string v0, "Stopping"

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    iput-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mRunning:Z

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessAnrErrorMonitor:Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/acra/anr/processmonitor/ProcessAnrErrorMonitor;->stopMonitoring()V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mProcessingThreadHandler:Landroid/os/Handler;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mConfirmationExpiredRunnable:Ljava/lang/Runnable;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 27
    .line 28
    .line 29
    iget-boolean v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mNativeHookInPlace:Z

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mSigquitDetector:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 34
    .line 35
    invoke-interface {v0}, Lcom/facebook/acra/anr/sigquit/SigquitDetector;->stopDetector()V

    .line 36
    .line 37
    .line 38
    :cond_0
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mAnrDetectorConfig:LX/Fvc;

    .line 39
    .line 40
    iget-object v1, v0, LX/Fvc;->A00:LX/Fug;

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector;->mForegroundTransitionListener:LX/Fv3;

    .line 43
    .line 44
    iget-object v1, v1, LX/Fug;->A00:Ljava/util/List;

    .line 45
    .line 46
    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 47
    :try_start_1
    invoke-interface {v1, v0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    monitor-exit v1

    .line 51
    if-eqz p1, :cond_1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :catchall_0
    move-exception v0

    .line 55
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 56
    :try_start_2
    throw v0

    .line 57
    :goto_0
    invoke-interface {p1}, Lcom/facebook/acra/anr/IANRDetector$ANRDetectorStopListener;->onStop()V

    .line 58
    .line 59
    .line 60
    :cond_1
    monitor-exit v2

    .line 61
    return-void

    .line 62
    :catchall_1
    move-exception v0

    .line 63
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 64
    throw v0
.end method
