.class public abstract synthetic Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$9;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $SwitchMap$com$facebook$reliability$anr$AnrState:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    invoke-static {}, LX/Ftc;->values()[LX/Ftc;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v2, v0, [I

    .line 6
    .line 7
    sput-object v2, Lcom/facebook/acra/anr/multisignal/MultiSignalANRDetector$9;->$SwitchMap$com$facebook$reliability$anr$AnrState:[I

    .line 8
    .line 9
    :try_start_0
    const/4 v1, 0x0

    .line 10
    const/4 v0, 0x1

    .line 11
    aput v0, v2, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    .line 13
    :catch_0
    :try_start_1
    const/4 v1, 0x3

    .line 14
    const/4 v0, 0x2

    .line 15
    aput v0, v2, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 16
    .line 17
    :catch_1
    :try_start_2
    const/4 v1, 0x4

    .line 18
    const/4 v0, 0x3

    .line 19
    aput v0, v2, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 20
    .line 21
    :catch_2
    :try_start_3
    const/4 v1, 0x5

    .line 22
    const/4 v0, 0x4

    .line 23
    aput v0, v2, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 24
    .line 25
    :catch_3
    :try_start_4
    const/16 v1, 0x8

    .line 26
    .line 27
    const/4 v0, 0x5

    .line 28
    aput v0, v2, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 29
    .line 30
    :catch_4
    :try_start_5
    const/16 v1, 0x9

    .line 31
    .line 32
    const/4 v0, 0x6

    .line 33
    aput v0, v2, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 34
    .line 35
    :catch_5
    :try_start_6
    const/4 v1, 0x6

    .line 36
    const/4 v0, 0x7

    .line 37
    aput v0, v2, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 38
    .line 39
    :catch_6
    :try_start_7
    const/4 v1, 0x7

    .line 40
    const/16 v0, 0x8

    .line 41
    .line 42
    aput v0, v2, v1
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 43
    .line 44
    :catch_7
    return-void
.end method
