.class public Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/acra/anr/sigquit/SigquitDetector;


# static fields
.field public static final TAG:Ljava/lang/String; = "SigquitDetectorLacrima"

.field public static sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;


# instance fields
.field public mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

.field public mMainThreadHandler:Landroid/os/Handler;

.field public mNotifyJavaOnSigquit:Z


# direct methods
.method public static bridge synthetic -$$Nest$fgetmListener(Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;)Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$smnativeAddSignalHandler()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeAddSignalHandler()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$smnativeHookMethods()Z
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeHookMethods()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    return v0
.end method

.method public static bridge synthetic -$$Nest$smnativeWaitForSignal()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeWaitForSignal()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public constructor <init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 4
    .line 5
    return-void
.end method

.method public static getInstance(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)Lcom/facebook/acra/anr/sigquit/SigquitDetector;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 10
    .line 11
    :cond_0
    return-object v0
.end method

.method public static native nativeAddSignalHandler()V
.end method

.method public static native nativeCleanupAppStateFile()V
.end method

.method public static native nativeHookMethods()Z
.end method

.method public static native nativeInit(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZZLjava/lang/String;ZZZZZI)V
.end method

.method public static native nativeSendNextSigquitTraceUnconditionally()V
.end method

.method public static native nativeStartDetector()V
.end method

.method public static native nativeStopDetector()V
.end method

.method public static native nativeWaitForSignal()V
.end method

.method private onSigquit(ZJJJ)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 1
    .line 2
    invoke-interface/range {p0 .. p7}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;->onSigquit(ZJJJ)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method private onSigquitTracesAvailable(Ljava/lang/String;Ljava/lang/String;ZZ)V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->TAG:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-static {p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string/jumbo v0, "sigquitDetected inFgV1: %b inFgV2: %b"

    .line 15
    .line 16
    .line 17
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 21
    .line 22
    invoke-interface {v0, p1, p2, p3, p4}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;->onSigquitTracesAvailable(Ljava/lang/String;Ljava/lang/String;ZZ)V

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public cleanupAppStateFile()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeCleanupAppStateFile()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public doNotIgnoreNextSiguit()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeSendNextSigquitTraceUnconditionally()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public init(LX/Fvc;Z)V
    .locals 18

    .line 0
    sget-object v1, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->TAG:Ljava/lang/String;

    .line 1
    .line 2
    const-string v0, "nativeInit"

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    move-object/from16 v2, p1

    .line 8
    .line 9
    iget-object v0, v2, LX/Fvc;->A02:Landroid/os/Handler;

    .line 10
    .line 11
    move-object/from16 v3, p0

    .line 12
    .line 13
    iput-object v0, v3, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mMainThreadHandler:Landroid/os/Handler;

    .line 14
    .line 15
    const/4 v12, 0x0

    .line 16
    iput-boolean v12, v3, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mNotifyJavaOnSigquit:Z

    .line 17
    .line 18
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    .line 20
    const-string v5, ""

    .line 21
    .line 22
    iget-object v7, v2, LX/Fvc;->A05:Ljava/lang/String;

    .line 23
    .line 24
    const-string v8, ".stacktrace"

    .line 25
    .line 26
    iget-object v1, v2, LX/Fvc;->A04:Ljava/lang/String;

    .line 27
    .line 28
    const-string v0, ":"

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    const-string v0, ":browser"

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    const/4 v9, 0x0

    .line 43
    if-eqz v0, :cond_1

    .line 44
    .line 45
    :cond_0
    const/4 v9, 0x1

    .line 46
    :cond_1
    const/4 v11, 0x1

    .line 47
    invoke-virtual {v2}, LX/Fvc;->A00()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v14

    .line 51
    move/from16 v10, p2

    .line 52
    .line 53
    move-object v6, v5

    .line 54
    move v13, v12

    .line 55
    move v15, v12

    .line 56
    move/from16 v16, v12

    .line 57
    .line 58
    move/from16 v17, v12

    .line 59
    .line 60
    move/from16 p0, v12

    .line 61
    .line 62
    move/from16 p1, v12

    .line 63
    .line 64
    move/from16 p2, v12

    .line 65
    .line 66
    invoke-static/range {v3 .. v20}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeInit(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZZLjava/lang/String;ZZZZZI)V

    .line 67
    .line 68
    .line 69
    return-void
.end method

.method public installSignalHandler(Landroid/os/Handler;Z)V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$1;

    .line 1
    .line 2
    invoke-direct {v2, p0, p2}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$1;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;Z)V

    .line 3
    .line 4
    .line 5
    iget-boolean v0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mNotifyJavaOnSigquit:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const-string v1, "LacrimaSigquitNotifier"

    .line 10
    .line 11
    new-instance v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$2;

    .line 12
    .line 13
    invoke-direct {v0, p0, v1}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$2;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v1, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->mMainThreadHandler:Landroid/os/Handler;

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$3;

    .line 22
    .line 23
    invoke-direct {v0, p0, p1, v2}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima$3;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;Landroid/os/Handler;Ljava/lang/Runnable;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public startDetector()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeStartDetector()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public stopDetector()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorLacrima;->nativeStopDetector()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
