.class public Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/acra/anr/sigquit/SigquitDetector;


# static fields
.field public static final TAG:Ljava/lang/String; = "SigquitDetectorAcra"

.field public static sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;


# instance fields
.field public mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

.field public mMainThreadHandler:Landroid/os/Handler;


# direct methods
.method public static bridge synthetic -$$Nest$fgetmListener(Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;)Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 1
    .line 2
    return-object p0
.end method

.method public static bridge synthetic -$$Nest$smnativeAddSignalHandler()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeAddSignalHandler()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static bridge synthetic -$$Nest$smnativeHookMethods()Z
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeHookMethods()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    return v0
.end method

.method public constructor <init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 4
    .line 5
    return-void
.end method

.method public static getInstance(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)Lcom/facebook/acra/anr/sigquit/SigquitDetector;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->sInstance:Lcom/facebook/acra/anr/sigquit/SigquitDetector;

    .line 10
    .line 11
    :cond_0
    return-object v0
.end method

.method public static native nativeAddSignalHandler()V
.end method

.method public static native nativeCleanupAppStateFile()V
.end method

.method public static native nativeHookMethods()Z
.end method

.method public static native nativeInit(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZZLjava/lang/String;Z)V
.end method

.method public static native nativeSendNextSigquitTraceUnconditionally()V
.end method

.method public static native nativeStartDetector()V
.end method

.method public static native nativeStopDetector()V
.end method

.method public static native nativeWaitForSignal()V
.end method

.method private onSigquit(ZJJJ)V
    .locals 0

    .line 0
    return-void
.end method

.method private onSigquitTracesAvailable(Ljava/lang/String;Ljava/lang/String;ZZ)V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->TAG:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-static {p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string/jumbo v0, "sigquitDetected inFgV1: %b inFgV2: %b"

    .line 15
    .line 16
    .line 17
    invoke-static {v2, v0, v1}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->mListener:Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;

    .line 21
    .line 22
    invoke-interface {v0, p1, p2, p3, p4}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorListener;->onSigquitTracesAvailable(Ljava/lang/String;Ljava/lang/String;ZZ)V

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public cleanupAppStateFile()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeCleanupAppStateFile()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public doNotIgnoreNextSiguit()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeSendNextSigquitTraceUnconditionally()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public init(LX/Fvc;Z)V
    .locals 12

    .line 0
    iget-object v0, p1, LX/Fvc;->A02:Landroid/os/Handler;

    .line 1
    .line 2
    move-object v2, p0

    .line 3
    iput-object v0, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->mMainThreadHandler:Landroid/os/Handler;

    .line 4
    .line 5
    sget-object v1, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->TAG:Ljava/lang/String;

    .line 6
    .line 7
    const-string v0, "nativeInit"

    .line 8
    .line 9
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 13
    .line 14
    const-string v4, ""

    .line 15
    .line 16
    iget-object v6, p1, LX/Fvc;->A05:Ljava/lang/String;

    .line 17
    .line 18
    const-string v7, ".stacktrace"

    .line 19
    .line 20
    iget-object v1, p1, LX/Fvc;->A04:Ljava/lang/String;

    .line 21
    .line 22
    const-string v0, ":"

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    const-string v0, ":browser"

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    const/4 v8, 0x0

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    :cond_0
    const/4 v8, 0x1

    .line 40
    :cond_1
    const/4 v10, 0x1

    .line 41
    const/4 v11, 0x0

    .line 42
    invoke-virtual {p1}, LX/Fvc;->A00()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    move v9, p2

    .line 47
    move-object v5, v4

    .line 48
    move p0, v11

    .line 49
    move p2, v11

    .line 50
    invoke-static/range {v2 .. v14}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeInit(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZZLjava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public installSignalHandler(Landroid/os/Handler;Z)V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra$1;

    .line 1
    .line 2
    invoke-direct {v2, p0, p2}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra$1;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;Z)V

    .line 3
    .line 4
    .line 5
    iget-object v1, p0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->mMainThreadHandler:Landroid/os/Handler;

    .line 6
    .line 7
    new-instance v0, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra$2;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1, v2}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra$2;-><init>(Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;Landroid/os/Handler;Ljava/lang/Runnable;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public startDetector()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeStartDetector()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public stopDetector()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/acra/anr/sigquit/SigquitDetectorAcra;->nativeStopDetector()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
