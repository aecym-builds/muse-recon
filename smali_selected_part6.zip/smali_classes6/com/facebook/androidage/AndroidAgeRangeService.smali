.class public final Lcom/facebook/androidage/AndroidAgeRangeService;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final A00:LX/Fjg;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;)V
    .locals 6

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    const-string v1, "Amazon"

    .line 8
    .line 9
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const-string v1, "SD4930UR"

    .line 18
    .line 19
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    :cond_0
    :try_start_0
    const-string v0, "content://amzn_appstore/getUserAgeData"

    .line 28
    .line 29
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    move-object v3, v2

    .line 38
    move-object v4, v2

    .line 39
    move-object v5, v2

    .line 40
    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    .line 48
    .line 49
    new-instance v0, LX/Fjj;

    .line 50
    .line 51
    invoke-direct {v0, p1, p2}, Lcom/facebook/age/strategy/BaseAmazonStrategy;-><init>(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;)V

    .line 52
    .line 53
    .line 54
    goto :goto_1

    .line 55
    :catch_0
    :cond_1
    :try_start_1
    const-string v0, "com.google.android.play.agesignals.AgeSignalsManager"

    .line 56
    .line 57
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    goto :goto_0
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    .line 61
    :catch_1
    new-instance v0, LX/FjN;

    .line 62
    .line 63
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 64
    .line 65
    .line 66
    goto :goto_2

    .line 67
    :goto_0
    new-instance v0, Lcom/facebook/age/strategy/GoogleSystemStrategy;

    .line 68
    .line 69
    invoke-direct {v0, p1, p2}, Lcom/facebook/age/strategy/GoogleSystemStrategy;-><init>(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/osage/OsAgeCollector$NoAgeRangeMock;)V

    .line 70
    .line 71
    .line 72
    :goto_1
    check-cast v0, LX/Fjg;

    .line 73
    .line 74
    :goto_2
    iput-object v0, p0, Lcom/facebook/androidage/AndroidAgeRangeService;->A00:LX/Fjg;

    .line 75
    .line 76
    return-void
.end method


# virtual methods
.method public final A00(Landroid/app/Activity;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "LX/2M4<",
            "-",
            "LX/FjT;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 v3, 0x2

    .line 1
    instance-of v0, p2, LX/Gru;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, LX/Gru;

    .line 7
    .line 8
    iget v1, v0, LX/Gru;->$t:I

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v3, :cond_1

    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :cond_1
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object v4, p2

    .line 17
    check-cast v4, LX/Gru;

    .line 18
    .line 19
    iget v2, v4, LX/Gru;->A00:I

    .line 20
    .line 21
    const/high16 v1, -0x80000000

    .line 22
    .line 23
    and-int v0, v2, v1

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    sub-int/2addr v2, v1

    .line 28
    iput v2, v4, LX/Gru;->A00:I

    .line 29
    .line 30
    :goto_0
    iget-object v1, v4, LX/Gru;->A02:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 33
    .line 34
    iget v0, v4, LX/Gru;->A00:I

    .line 35
    .line 36
    const/4 v2, 0x1

    .line 37
    if-eqz v0, :cond_4

    .line 38
    .line 39
    if-ne v0, v2, :cond_3

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_2
    new-instance v4, LX/Gru;

    .line 43
    .line 44
    invoke-direct {v4, p0, p2, v3}, LX/Gru;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :try_start_0
    iget-object v1, p0, Lcom/facebook/androidage/AndroidAgeRangeService;->A00:LX/Fjg;

    .line 57
    .line 58
    const/4 v0, 0x0

    .line 59
    iput-object v0, v4, LX/Gru;->A01:Ljava/lang/Object;

    .line 60
    .line 61
    iput v2, v4, LX/Gru;->A00:I

    .line 62
    .line 63
    invoke-interface {v1, p1, v4}, LX/Fjg;->Abb(Landroid/app/Activity;LX/2M4;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    if-ne v1, v3, :cond_5

    .line 68
    .line 69
    return-object v3

    .line 70
    :goto_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    :cond_5
    check-cast v1, LX/FjT;

    .line 74
    .line 75
    return-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 76
    :catch_0
    sget-object v1, LX/FkO;->A02:Ljava/lang/Integer;

    .line 77
    .line 78
    new-instance v0, LX/FjQ;

    .line 79
    .line 80
    invoke-direct {v0, v1}, LX/FjQ;-><init>(Ljava/lang/Integer;)V

    .line 81
    .line 82
    .line 83
    return-object v0
.end method

.method public final A01(LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/FjS;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/16 v3, 0xb

    .line 1
    .line 2
    instance-of v0, p1, LX/Gsl;

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v0, p1

    .line 7
    check-cast v0, LX/Gsl;

    .line 8
    .line 9
    iget v1, v0, LX/Gsl;->$t:I

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    if-eq v1, v3, :cond_1

    .line 13
    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :cond_1
    if-eqz v0, :cond_2

    .line 16
    .line 17
    move-object v4, p1

    .line 18
    check-cast v4, LX/Gsl;

    .line 19
    .line 20
    iget v2, v4, LX/Gsl;->A00:I

    .line 21
    .line 22
    const/high16 v1, -0x80000000

    .line 23
    .line 24
    and-int v0, v2, v1

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    sub-int/2addr v2, v1

    .line 29
    iput v2, v4, LX/Gsl;->A00:I

    .line 30
    .line 31
    :goto_0
    iget-object v3, v4, LX/Gsl;->A01:Ljava/lang/Object;

    .line 32
    .line 33
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 34
    .line 35
    iget v0, v4, LX/Gsl;->A00:I

    .line 36
    .line 37
    const/4 v1, 0x1

    .line 38
    if-eqz v0, :cond_4

    .line 39
    .line 40
    if-ne v0, v1, :cond_3

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_2
    new-instance v4, LX/Gsl;

    .line 44
    .line 45
    invoke-direct {v4, p0, p1, v3}, LX/Gsl;-><init>(Ljava/lang/Object;LX/2M4;I)V

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    throw v0

    .line 54
    :cond_4
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :try_start_0
    iget-object v0, p0, Lcom/facebook/androidage/AndroidAgeRangeService;->A00:LX/Fjg;

    .line 58
    .line 59
    iput v1, v4, LX/Gsl;->A00:I

    .line 60
    .line 61
    invoke-interface {v0, v4}, LX/Fjg;->Abc(LX/2M4;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    if-ne v3, v2, :cond_5

    .line 66
    .line 67
    return-object v2

    .line 68
    :goto_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_5
    move-object v2, v3

    .line 72
    check-cast v2, LX/FjS;

    .line 73
    .line 74
    goto :goto_2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 75
    :catch_0
    sget-object v0, LX/FkO;->A02:Ljava/lang/Integer;

    .line 76
    .line 77
    new-instance v2, LX/FjO;

    .line 78
    .line 79
    invoke-direct {v2, v0}, LX/FjO;-><init>(Ljava/lang/Integer;)V

    .line 80
    .line 81
    .line 82
    :goto_2
    instance-of v0, v2, LX/FjP;

    .line 83
    .line 84
    if-nez v0, :cond_6

    .line 85
    .line 86
    instance-of v0, v2, LX/FjO;

    .line 87
    .line 88
    if-nez v0, :cond_6

    .line 89
    .line 90
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    throw v0

    .line 95
    :cond_6
    return-object v2
.end method
