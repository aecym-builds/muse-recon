.class public final Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;
.super Landroid/app/job/JobService;
.source ""

# interfaces
.implements LX/FfH;


# instance fields
.field public A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final onCreate()V
    .locals 3

    .line 0
    const-string v2, "com.facebook.analytics2.logger.legacy.uploader.LollipopUpload"

    .line 1
    .line 2
    :try_start_0
    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "null cannot be cast to non-null type com.facebook.analytics2.logger.service.ILollipopUpload"

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/I1c;->A0g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    check-cast v1, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 16
    .line 17
    iput-object v1, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 18
    .line 19
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    invoke-static {p0}, LX/FdQ;->A00(Landroid/content/Context;)LX/FdQ;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iput-object v0, v1, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;->A00:LX/FdQ;

    .line 27
    .line 28
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 29
    :catch_0
    move-exception p0

    .line 30
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    const-string v1, "LollipopUploadSafeService"

    .line 35
    .line 36
    const-string v0, "LollipopUpload failed to be created, className %s"

    .line 37
    .line 38
    invoke-static {v1, v0, p0, v2}, LX/FnY;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 0
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-object v0, v1, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;->A00:LX/FdQ;

    .line 9
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 12
    .line 13
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    return v0

    .line 6
    :cond_0
    iget-object v1, v0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;->A00:LX/FdQ;

    .line 7
    .line 8
    invoke-static {v1}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, LX/FdY;

    .line 12
    .line 13
    invoke-direct {v0, p0, p3}, LX/FdY;-><init>(Landroid/app/Service;I)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v1, p1, v0}, LX/FdQ;->A02(Landroid/content/Intent;LX/FdY;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 8

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v4, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 5
    .line 6
    if-eqz v4, :cond_3

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-string v3, "PostLolliopUploadService"

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    const-string v0, "Job with no build ID, cancelling job"

    .line 18
    .line 19
    invoke-static {v3, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :goto_0
    const/4 v7, 0x0

    .line 23
    if-nez v2, :cond_2

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const-string v0, "Stale job parameters, cancelling jobId: %d"

    .line 34
    .line 35
    invoke-static {v1, v3, v0}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    return v7

    .line 39
    :cond_0
    :try_start_0
    const-string v0, "__VERSION_CODE"

    .line 40
    .line 41
    invoke-virtual {v1, v0, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 42
    .line 43
    .line 44
    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    invoke-static {}, Lcom/facebook/common/build/BuildConstants;->A01()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eq v0, v1, :cond_1

    .line 50
    .line 51
    const-string v0, "Job with old build ID: %d, cancelling job"

    .line 52
    .line 53
    invoke-static {v1, v3, v0}, LX/EYt;->A1H(ILjava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_1
    const/4 v2, 0x1

    .line 58
    goto :goto_0

    .line 59
    :catch_0
    move-exception v1

    .line 60
    const-string v0, "Corrupt bundle, cancelling job"

    .line 61
    .line 62
    invoke-static {v3, v1, v0}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_2
    :try_start_1
    iget-object v6, v4, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;->A00:LX/FdQ;

    .line 67
    .line 68
    invoke-static {v6}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    const-string v0, "action"

    .line 80
    .line 81
    invoke-virtual {v1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    new-instance v0, Landroid/os/Bundle;

    .line 90
    .line 91
    invoke-direct {v0, v1}, Landroid/os/Bundle;-><init>(Landroid/os/PersistableBundle;)V

    .line 92
    .line 93
    .line 94
    new-instance v1, LX/Fi3;

    .line 95
    .line 96
    invoke-direct {v1, v0}, LX/Fi3;-><init>(Landroid/os/Bundle;)V

    .line 97
    .line 98
    .line 99
    new-instance v0, LX/FfB;

    .line 100
    .line 101
    invoke-direct {v0, p1, v4, p0}, LX/FfB;-><init>(Landroid/app/job/JobParameters;Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;LX/FfH;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v6, v1, v0, v2, v5}, LX/FdQ;->A04(LX/Fi3;LX/Fdb;Ljava/lang/String;I)V

    .line 105
    .line 106
    .line 107
    const/4 v7, 0x1

    .line 108
    return v7
    :try_end_1
    .catch Lcom/facebook/analytics2/logger/interfaces/IllegalRemoteArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    .line 109
    :catch_1
    move-exception v1

    .line 110
    const-string v0, "Misunderstood job service extras: %s"

    .line 111
    .line 112
    invoke-static {v3, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 113
    .line 114
    .line 115
    return v7

    .line 116
    :cond_3
    return v5
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/analytics2/logger/service/LollipopUploadSafeService;->A00:Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object p0, v0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUpload;->A00:LX/FdQ;

    .line 9
    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-virtual {p0, v0}, LX/FdQ;->A03(I)V

    .line 17
    .line 18
    .line 19
    :cond_0
    const/4 v0, 0x1

    .line 20
    return v0
.end method
