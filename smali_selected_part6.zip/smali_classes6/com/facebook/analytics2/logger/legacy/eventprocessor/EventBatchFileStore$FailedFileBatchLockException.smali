.class public Lcom/facebook/analytics2/logger/legacy/eventprocessor/EventBatchFileStore$FailedFileBatchLockException;
.super Ljava/lang/RuntimeException;
.source ""


# static fields
.field public static final serialVersionUID:J = 0x1L
