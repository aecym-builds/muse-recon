.class public Lcom/facebook/analytics2/logger/legacy/uploader/UploadProcessor$HttpResponseException;
.super Ljava/io/IOException;
.source ""


# static fields
.field public static final serialVersionUID:J = 0x1L


# instance fields
.field public final mStatusCode:I


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/analytics2/logger/legacy/uploader/UploadProcessor$HttpResponseException;->mStatusCode:I

    .line 4
    .line 5
    return-void
.end method
