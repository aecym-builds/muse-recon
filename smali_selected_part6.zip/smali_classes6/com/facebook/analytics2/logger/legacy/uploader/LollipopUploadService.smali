.class public Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;
.super Landroid/app/job/JobService;
.source ""


# instance fields
.field public A00:LX/FdQ;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final onCreate()V
    .locals 1

    .line 0
    invoke-static {p0}, LX/FdQ;->A00(Landroid/content/Context;)LX/FdQ;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iput-object v0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 5
    .line 6
    return-void
.end method

.method public final onDestroy()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 2
    .line 3
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    .line 0
    :try_start_0
    iget-object v1, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 1
    .line 2
    invoke-static {v1}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    new-instance v0, LX/FdY;

    .line 6
    .line 7
    invoke-direct {v0, p0, p3}, LX/FdY;-><init>(Landroid/app/Service;I)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, p1, v0}, LX/FdQ;->A02(Landroid/content/Intent;LX/FdY;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    :catch_0
    move-exception p0

    .line 16
    const-string v1, "PostLolliopUploadService"

    .line 17
    .line 18
    const-string v0, "Invalid service intent: %s"

    .line 19
    .line 20
    invoke-static {v1, v0, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x2

    .line 24
    return v0
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 7

    .line 0
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const-string v3, "PostLolliopUploadService"

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    const-string v0, "Job with no build ID, cancelling job"

    .line 10
    .line 11
    invoke-static {v3, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    :goto_0
    const/4 v6, 0x0

    .line 15
    if-nez v2, :cond_2

    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v0, "Stale job parameters, cancelling jobId: %d"

    .line 26
    .line 27
    invoke-static {v1, v3, v0}, LX/FnY;->A03(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return v6

    .line 31
    :cond_0
    :try_start_0
    const-string v0, "__VERSION_CODE"

    .line 32
    .line 33
    invoke-virtual {v1, v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 34
    .line 35
    .line 36
    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    invoke-static {}, Lcom/facebook/common/build/BuildConstants;->A01()I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eq v0, v1, :cond_1

    .line 42
    .line 43
    const-string v0, "Job with old build ID: %d, cancelling job"

    .line 44
    .line 45
    invoke-static {v1, v3, v0}, LX/EYt;->A1H(ILjava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_1
    const/4 v2, 0x1

    .line 50
    goto :goto_0

    .line 51
    :catch_0
    move-exception v1

    .line 52
    const-string v0, "Corrupt bundle, cancelling job"

    .line 53
    .line 54
    invoke-static {v3, v1, v0}, LX/FnY;->A0J(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    :try_start_1
    iget-object v5, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 59
    .line 60
    if-nez v5, :cond_3

    .line 61
    .line 62
    invoke-static {p0}, LX/FdQ;->A00(Landroid/content/Context;)LX/FdQ;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    iput-object v5, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 67
    .line 68
    :cond_3
    invoke-static {v5}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    const-string v0, "action"

    .line 80
    .line 81
    invoke-virtual {v1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    new-instance v0, Landroid/os/Bundle;

    .line 90
    .line 91
    invoke-direct {v0, v1}, Landroid/os/Bundle;-><init>(Landroid/os/PersistableBundle;)V

    .line 92
    .line 93
    .line 94
    new-instance v1, LX/Fi3;

    .line 95
    .line 96
    invoke-direct {v1, v0}, LX/Fi3;-><init>(Landroid/os/Bundle;)V

    .line 97
    .line 98
    .line 99
    new-instance v0, LX/FfE;

    .line 100
    .line 101
    invoke-direct {v0, p1, p0}, LX/FfE;-><init>(Landroid/app/job/JobParameters;Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v5, v1, v0, v2, v4}, LX/FdQ;->A04(LX/Fi3;LX/Fdb;Ljava/lang/String;I)V

    .line 105
    .line 106
    .line 107
    const/4 v6, 0x1

    .line 108
    return v6
    :try_end_1
    .catch Lcom/facebook/analytics2/logger/interfaces/IllegalRemoteArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    .line 109
    :catch_1
    move-exception v1

    .line 110
    const-string v0, "Misunderstood job service extras: %s"

    .line 111
    .line 112
    invoke-static {v3, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 113
    .line 114
    .line 115
    return v6
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadService;->A00:LX/FdQ;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getJobId()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, v0}, LX/FdQ;->A03(I)V

    .line 9
    .line 10
    .line 11
    :cond_0
    const/4 v0, 0x1

    .line 12
    return v0
.end method
