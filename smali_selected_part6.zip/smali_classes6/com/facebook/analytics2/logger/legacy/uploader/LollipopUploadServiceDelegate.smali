.class public Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadServiceDelegate;
.super LX/FfC;
.source ""


# instance fields
.field public A00:LX/FdQ;


# direct methods
.method public constructor <init>(LX/Ff8;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, LX/FfC;-><init>(LX/Ff8;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final A00()V
    .locals 1

    .line 0
    invoke-super {p0}, LX/FfC;->A00()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/LollipopUploadServiceDelegate;->A00:LX/FdQ;

    .line 5
    .line 6
    return-void
.end method
