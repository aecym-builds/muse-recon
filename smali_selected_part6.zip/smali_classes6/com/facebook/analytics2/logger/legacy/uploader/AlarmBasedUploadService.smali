.class public Lcom/facebook/analytics2/logger/legacy/uploader/AlarmBasedUploadService;
.super Landroid/app/Service;
.source ""


# instance fields
.field public A00:LX/FdQ;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public final onCreate()V
    .locals 1

    .line 0
    invoke-static {p0}, LX/FdQ;->A00(Landroid/content/Context;)LX/FdQ;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iput-object v0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/AlarmBasedUploadService;->A00:LX/FdQ;

    .line 5
    .line 6
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const-string v1, "com.facebook.analytics2.logger.UPLOAD_NOW"

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v1, p0, Lcom/facebook/analytics2/logger/legacy/uploader/AlarmBasedUploadService;->A00:LX/FdQ;

    .line 20
    .line 21
    invoke-static {v1}, LX/FK1;->A00(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    new-instance v0, LX/FdY;

    .line 25
    .line 26
    invoke-direct {v0, p0, p3}, LX/FdY;-><init>(Landroid/app/Service;I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, p1, v0}, LX/FdQ;->A02(Landroid/content/Intent;LX/FdY;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    return v0
.end method
