.class public Lcom/facebook/analytics2/logger/legacy/uploader/PrivacyControlledUploader;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FiE;


# static fields
.field public static final A02:Ljava/io/IOException;


# instance fields
.field public A00:LX/FiJ;

.field public A01:LX/FiE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    const-string v0, "Upload is skipped due to privacy control."

    .line 1
    .line 2
    invoke-static {v0}, LX/EYt;->A0R(Ljava/lang/String;)Ljava/io/IOException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/analytics2/logger/legacy/uploader/PrivacyControlledUploader;->A02:Ljava/io/IOException;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final upload(LX/FiG;LX/FiY;LX/Fi7;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/analytics2/logger/legacy/uploader/PrivacyControlledUploader;->A01:LX/FiE;

    .line 1
    .line 2
    invoke-interface {p0, p1, p2, p3}, LX/FiE;->upload(LX/FiG;LX/FiY;LX/Fi7;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
