.class public Lcom/facebook/analytics2/logger/legacy/batchsupport/CrossProcessBatchLockState$FailedFileCreationException;
.super Ljava/lang/RuntimeException;
.source ""
