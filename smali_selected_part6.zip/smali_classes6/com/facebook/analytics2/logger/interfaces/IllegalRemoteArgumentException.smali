.class public Lcom/facebook/analytics2/logger/interfaces/IllegalRemoteArgumentException;
.super Ljava/lang/Exception;
.source ""


# static fields
.field public static final serialVersionUID:J = 0x1L
