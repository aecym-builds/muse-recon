.class public Lcom/facebook/analytics2/logger/interfaces/DefaultFalcoAcsProvider;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getClaim()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public init()V
    .locals 0

    .line 0
    return-void
.end method

.method public isACSEnabled()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method
