.class public Lcom/facebook/analytics2/logger/interfaces/DefaultFFDBProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/FiI;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getFFDBToken()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method
